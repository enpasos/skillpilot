# SPDX-License-Identifier: Apache-2.0
import pathlib,subprocess,json,hashlib,sys,datetime
r=pathlib.Path.cwd();o=r/'tmp/cross-subject-requires/physics72-whole-positive-independent-supplement-20261014-v1';kind=sys.argv[1]
argv=([sys.executable,str(o/'capture_inputs.py')] if kind=='freshness' else [str(r/'app/node_modules/.bin/tsx'),str(o/'native_bind_check.mts'),kind])
before={str(p.relative_to(r)):'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest() for p in [o/('capture_inputs.py' if kind=='freshness' else 'native_bind_check.mts'),r/'app/scripts/lib/crossSubjectRequiresInventory.ts',r/'app/scripts/lib/crossSubjectRequiresReview.ts']}
p=subprocess.run(argv,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(o/(kind+'.stdout.raw.txt')).write_bytes(p.stdout);(o/(kind+'.stderr.raw.txt')).write_bytes(p.stderr)
receipt={'argv':argv,'cwd':str(r),'exitCode':p.returncode,'timestampUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'executedSourceHashesBefore':before,'stdoutSha256':'sha256:'+hashlib.sha256(p.stdout).hexdigest(),'stderrSha256':'sha256:'+hashlib.sha256(p.stderr).hexdigest()}
(o/(kind+'.execution.actual.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(p.stdout.decode(),end='');print(p.stderr.decode(),end='',file=sys.stderr);sys.exit(p.returncode)
