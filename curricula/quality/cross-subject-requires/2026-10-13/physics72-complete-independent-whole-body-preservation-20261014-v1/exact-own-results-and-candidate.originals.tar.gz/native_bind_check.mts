// SPDX-License-Identifier: Apache-2.0
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildRequiresInventory, assertFreshRequiresInventory, fingerprint, stableJson, fileFingerprint } from '../../../app/scripts/lib/crossSubjectRequiresInventory.ts';
import { validateRequiresDecisions } from '../../../app/scripts/lib/crossSubjectRequiresReview.ts';
const root=process.cwd(), out=dirname(fileURLToPath(import.meta.url));
const read=(p:string)=>JSON.parse(readFileSync(resolve(root,p),'utf8'));
const author='tmp/cross-subject-requires/physics-whole-positive-coverage-intake-root-20261014-v1/72-native-proposal.bound.inert.json';
if(fileFingerprint(resolve(root,author))!=='sha256:1adad1696aa75541db2113300619c48df2829831aa6fa62f9fc917635c6588c5') throw Error('Root72 exact author artifact changed');
const ledger=read(author), inputs=read(resolve(out,'whole-current-Goal-P.exact-input.json'));
const batchName=process.argv[2]??'batch01';
const own=read(resolve(out,batchName+'.manual.json'));
const inv=buildRequiresInventory(root,read('curricula/quality/cross-subject-requires/math-physics.config.json'));
const inventorySha256=assertFreshRequiresInventory(inv,resolve(root,'curricula/quality/cross-subject-requires/math-physics.inventory.json'));
const records=own.map((r:any)=>{
 const x=inputs[r.index],d=ledger.decisions.find((d:any)=>d.dependentGoalId===x.goalId);
 if(!d)throw Error('Absent author decision');
 const p=x.wholeCurrentP,briefs=p.applicationCaseBriefs??[];
 if(briefs.length!==r.solves.length)throw Error('Literal brief solve count mismatch '+x.goalId);
 if(!r.fresh||!r.mathNecessity)throw Error('Incomplete substantive judgment');
 return {...r,goalId:x.goalId,title:x.wholeCurrentGoal.title,reviewInput:d.reviewInput,proposalBindingSha256:fingerprint(d.proposalBinding),
 currentProfileOwner:x.currentProfileOwner,currentProfileFingerprint:x.currentProfileOwner.profileFingerprint,
 wholeGoalSha256:fingerprint(x.wholeCurrentGoal),wholeProfileBodySha256:fingerprint(p),
 allRequiredExpectationIds:p.coverageExpectations.requiredExpectationIds,allDeclaredExpectationIds:p.expectations.map((e:any)=>e.id),
 allApplicationCaseIds:briefs.map((b:any)=>b.id),allVariationAxisIds:p.variationAxes.map((a:any)=>a.id),
 literalBriefSolves:briefs.map((b:any,i:number)=>({caseId:b.id,briefSha256:fingerprint(b),solution:r.solves[i],materialBoundary:'Own analytic solution; any unspecified numbers, apparatus state, diagram or observation instantiated here is synthetic, not measured/historical evidence.'})),
 ownFreshTransfer:{classification:'own_synthetic_instantiation_not_empirical_or_historical_data',solution:r.fresh},
 wholeContentLeafInventoryFile:'all72-whole-content-leaf-inventories.actual.json',
 nativeDirectInheritedContext:'direct-inherited-whole-prerequisite-contexts.actual.json',
 boundary:'Independent informed AI Requires supplement only. No human/P/source/quality/M7 acceptance; original decisions preserved. Didactic prerequisite content is not transitive learner mastery.'};
});
const independent={schemaVersion:1,authorLedgerSha256:fileFingerprint(resolve(root,author)),inventorySha256,
 reviewer:'/root/physics72_whole_positive_independent_supplement',blind:false,humanReviewer:false,
 exposureDisclosure:'Current Root scope-preserving negative proposal and historical negative existence are known; whole current bodies and own solves determine each new judgment. Independent of new Root assembler/original authors; no model-diversity claim.',
 decisions:records.map((r:any)=>({decisionId:ledger.decisions.find((d:any)=>d.dependentGoalId===r.goalId).decisionId,decision:r.verdict,reviewer:'/root/physics72_whole_positive_independent_supplement',rationale:r.mathNecessity+(r.gap?' Precise gap: '+r.gap:''),reviewInput:r.reviewInput,proposalBindingSha256:r.proposalBindingSha256})),
 substantiveRecords:batchName+'.content-bound-judgments.actual.json',noActiveWrites:true};
const result=validateRequiresDecisions(inv,ledger,{familyIds:['canonical-gymnasium'],requireComplete:false,independentReview:independent,
 authorLedgerSha256:independent.authorLedgerSha256,inventorySha256,sourcePathExists:(p:string)=>existsSync(resolve(root,p))});
const counts=Object.fromEntries(['approved','rejected','pending'].map(v=>[v,records.filter((r:any)=>r.verdict===v).length]));
writeFileSync(resolve(out,batchName+'.content-bound-judgments.actual.json'),JSON.stringify({role:'Actual whole current Goal/P scientific Requires review; leaf inventories alone are not scientific approval',records,counts},null,2)+'\n');
writeFileSync(resolve(out,batchName+'.native-independent-review.inert.json'),JSON.stringify(independent,null,2)+'\n');
writeFileSync(resolve(out,batchName+'.native-validation.actual.json'),JSON.stringify({authorPath:author,authorSha256:independent.authorLedgerSha256,inventorySha256,counts,result,sourceModules:{inventory:fileFingerprint(resolve(root,'app/scripts/lib/crossSubjectRequiresInventory.ts')),review:fileFingerprint(resolve(root,'app/scripts/lib/crossSubjectRequiresReview.ts'))},nativeValidationIsTechnicalBindingOnly:true},null,2)+'\n');
console.log(JSON.stringify({batch:batchName,counts,errors:result.errors,required:result.required,reviewed:result.reviewed,open:result.open}));
if(result.errors.length)process.exitCode=1;
