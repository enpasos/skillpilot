# SPDX-License-Identifier: Apache-2.0
import pathlib,json,hashlib,sys,datetime
r=pathlib.Path.cwd();o=r/'tmp/cross-subject-requires/physics72-whole-positive-independent-supplement-20261014-v1';batch=sys.argv[1]
paths=[p for p in o.iterdir() if p.is_file() and (p.name.startswith(batch+'.') or p.name in ['whole-current-Goal-P.exact-input.json','all72-whole-content-leaf-inventories.actual.json','direct-inherited-whole-prerequisite-contexts.actual.json','input-freshness.actual.json','capture_inputs.py','native_bind_check.mts','run_capture.py','seal_batch.py']) and p.name!=batch+'.seal.actual.json']
files=[]
for p in sorted(paths):
 if p.suffix=='.json':json.loads(p.read_text())
 files.append({'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()})
res={'batch':batch,'timestampUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'historicalSourceDecisionsPreserved':True,'sourceMainWrites':False,'noHumanApproval':True,'noAdoption':True,'scope':'exact Root72; batch-specific judgments only'}
(o/(batch+'.seal.actual.json')).write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({'batch':batch,'sealedFiles':len(files),'sha256':'sha256:'+hashlib.sha256((o/(batch+'.seal.actual.json')).read_bytes()).hexdigest()}))
