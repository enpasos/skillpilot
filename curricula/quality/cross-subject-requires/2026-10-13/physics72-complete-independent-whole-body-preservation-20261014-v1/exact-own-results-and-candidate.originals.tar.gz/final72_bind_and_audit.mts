// SPDX-License-Identifier: Apache-2.0
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {buildRequiresInventory,assertFreshRequiresInventory,fingerprint,stableJson,fileFingerprint} from '../../../app/scripts/lib/crossSubjectRequiresInventory.ts';
import {validateRequiresDecisions} from '../../../app/scripts/lib/crossSubjectRequiresReview.ts';
const root=process.cwd(),out=dirname(fileURLToPath(import.meta.url));
const read=(p:string)=>JSON.parse(readFileSync(resolve(root,p),'utf8'));
const save=(n:string,d:any)=>writeFileSync(resolve(out,n),JSON.stringify(d,null,2)+'\n');
const author='tmp/cross-subject-requires/physics-whole-positive-coverage-intake-root-20261014-v1/72-native-proposal.bound.inert.json';
const authorHash=fileFingerprint(resolve(root,author));
if(authorHash!=='sha256:1adad1696aa75541db2113300619c48df2829831aa6fa62f9fc917635c6588c5')throw Error('ExactRoot72 proposal mismatch');
const ledger=read(author), inputs=read(resolve(out,'whole-current-Goal-P.exact-input.json'));
const leaves=read(resolve(out,'all72-whole-content-leaf-inventories.actual.json'));
const freshness=read(resolve(out,'input-freshness.actual.json'));
const pool=read('tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/currentGoalPositivePool.private.json');
const allManual=[] as any[], originals=[] as any[];
for(let b=1;b<=6;b++){
 const n='batch'+String(b).padStart(2,'0');
 const manual=read(resolve(out,n+'.manual.json'));
 const sealed=read(resolve(out,n+'.seal.actual.json'));
 for(const f of sealed.files)if(fileFingerprint(resolve(root,f.path))!==f.sha256)throw Error('Previously sealed batch file changed: '+f.path);
 allManual.push(...manual.map((r:any)=>({...r,batch:n})));
 originals.push({batch:n,sealSha256:fileFingerprint(resolve(out,n+'.seal.actual.json')),manualSha256:fileFingerprint(resolve(out,n+'.manual.json'))});
}
if(allManual.length!==72||new Set(allManual.map(r=>r.index)).size!==72)throw Error('72 science records incomplete/duplicated');
const inv=buildRequiresInventory(root,read('curricula/quality/cross-subject-requires/math-physics.config.json'));
const inventorySha256=assertFreshRequiresInventory(inv,resolve(root,'curricula/quality/cross-subject-requires/math-physics.inventory.json'));
const sourceEndchecks=Object.entries(freshness.actualSourceFiles).map(([p,h])=>({path:p,sha256:fileFingerprint(resolve(root,p)),expectedSha256:h}));
if(sourceEndchecks.some(f=>f.sha256!==f.expectedSha256))throw Error('A protected actual Main/input source changed during review');
const actualGoals:any={};
for(const l of inv.families[0].landscapes)for(const g of read(l.path).goals)actualGoals[g.id]=g;
function typedLeaves(v:any,path=''):any[]{
 if(Array.isArray(v))return v.length?v.flatMap((x,i)=>typedLeaves(x,path+'/'+i)):[{path,value:[],kind:'emptyArray'}];
 if(v&&typeof v==='object')return Object.keys(v).length?Object.entries(v).flatMap(([k,x])=>typedLeaves(x,path+'/'+k)):[{path,value:{},kind:'emptyObject'}];
 return [{path,value:v,kind:v===null?'NoneType':typeof v==='string'?'str':typeof v==='boolean'?'bool':Number.isInteger(v)?'int':'float'}];
}
const records=allManual.sort((a,b)=>a.index-b.index).map(r=>{
 const x=inputs[r.index],p=x.wholeCurrentP,d=ledger.decisions.find((v:any)=>v.dependentGoalId===x.goalId);
 const reviewer=r.reviewer??'/root/physics72_whole_positive_independent_supplement';
 if(!d||stableJson(x.wholeCurrentGoal)!==stableJson(actualGoals[x.goalId]))throw Error('Actual whole goal mismatch');
 const owner=x.currentProfileOwner,raw=readFileSync(resolve(root,owner.recordFile.path),'utf8').split(/\r?\n/)[owner.recordLine-1],rec=JSON.parse(raw);
 if(rec.goalId!==x.goalId||rec.profileFingerprint!==owner.profileFingerprint||stableJson(rec.profile)!==stableJson(p))throw Error('Current P owner/body mismatch');
 if(fileFingerprint(resolve(root,owner.config.path))!==owner.config.sha256||fileFingerprint(resolve(root,owner.recordFile.path))!==owner.recordFile.sha256)throw Error('Current owner config/file mismatch');
 const row=leaves.find((v:any)=>v.goalId===x.goalId);
 if(stableJson(row.wholeGoalLeaves)!==stableJson(typedLeaves(x.wholeCurrentGoal))||stableJson(row.wholeProfileLeaves)!==stableJson(typedLeaves(p)))throw Error('Complete typed leaf inventory mismatch');
 if((p.applicationCaseBriefs??[]).length!==r.solves.length)throw Error('Incomplete literal brief solve count');
 if(!r.fresh||!r.mathNecessity||(!['approved','rejected','pending'].includes(r.verdict)))throw Error('Incomplete scientific case');
 const o=x.occurrences,effective=inv.effectivePrerequisiteSets[o.effectiveRequiresRef],originIndices=inv.prerequisiteOriginSets[o.prerequisiteOriginsRef];
 return {...r,scientificReviewer:reviewer,technicalAssembler:'/root/physics72_whole_positive_independent_supplement',goalId:x.goalId,title:x.wholeCurrentGoal.title,
 originalAuthorDecision:d.decision,originalAuthorRationalePreserved:d.rationale,reviewInput:d.reviewInput,proposalBindingSha256:fingerprint(d.proposalBinding),
 currentProfileOwner:owner,currentProfileFingerprint:rec.profileFingerprint,wholeGoalSha256:fingerprint(x.wholeCurrentGoal),wholeProfileBodySha256:fingerprint(p),
 allRequiredExpectationIds:p.coverageExpectations.requiredExpectationIds,allDeclaredExpectationIds:p.expectations.map((e:any)=>e.id),allVariationAxisIds:p.variationAxes.map((a:any)=>a.id),
 allLiteralCaseIds:p.applicationCaseBriefs.map((b:any)=>b.id),literalBriefSolves:p.applicationCaseBriefs.map((b:any,i:number)=>({caseId:b.id,exactBriefSha256:fingerprint(b),solution:r.solves[i],dataClassification:'Analytic current-literal solution; all independently supplied unspecified numeric/diagram material is explicitly synthetic, never newly observed empirical or historical data.'})),
 ownFreshTransfer:{classification:'own_synthetic_discriminating_transfer_not_empirical_or_historical_data',solution:r.fresh},
 fullLeafInventory:{artifact:'all72-whole-content-leaf-inventories.actual.json',goalLeafCount:row.wholeGoalLeaves.length,profileLeafCount:row.wholeProfileLeaves.length,rowSha256:fingerprint(row),personalFullBodyReader:reviewer},
 directedDAGContext:{directRequires:x.wholeCurrentGoal.requires,effectiveRequiresKeys:effective,origins:originIndices.map((i:number)=>inv.prerequisiteOriginTable[i]),masteryNeverDerivedTransitively:true},
 scopeBoundary:'Exactly current canonical Gymnasium Math↔Physics Sek I/II; no Goal/P/scope/edge/source/quality/human/adoption/publication mutation.'};
});
const counts=Object.fromEntries(['approved','rejected','pending'].map(v=>[v,records.filter(r=>r.verdict===v).length]));
const review={schemaVersion:1,role:'Independent informed whole-current-Goal/P scientific Requires supplement for exact Root72; inert',authorLedgerSha256:authorHash,inventorySha256,
 exposureDisclosure:'Previous negative verdicts and Root scope-preserving proposed decisions known; each new judgment comes from personally read current whole bodies plus literal/fresh casework. Distinct from Root assembler/original authors. Sixty cases read by parent scientific reviewer and twelve by named child reviewer; no blind, model-diversity, or human-review claim.',
 decisions:records.map(r=>({decisionId:ledger.decisions.find((d:any)=>d.dependentGoalId===r.goalId).decisionId,decision:r.verdict,reviewer:r.scientificReviewer,rationale:r.mathNecessity+(r.gap?' Precise remaining gap: '+r.gap:''),reviewInput:r.reviewInput,proposalBindingSha256:r.proposalBindingSha256})),
 scientificRecords:'all72-content-bound-scientific-judgments.actual.json',humanReviewer:false,blind:false,automaticApproval:false,noActiveWrites:true};
const result=validateRequiresDecisions(inv,ledger,{familyIds:['canonical-gymnasium'],requireComplete:false,independentReview:review,authorLedgerSha256:authorHash,inventorySha256,sourcePathExists:(p:string)=>existsSync(resolve(root,p))});
if(result.errors.length)throw Error(result.errors.join('\n'));
if(result.reviewed!==counts.approved)throw Error('Native approved coverage differs from actual scientific approvals');
const comparedMathIds=[...new Set(records.flatMap(r=>r.mathComparisons))].sort() as string[];
const comparedMath=comparedMathIds.map(id=>{
 const goal=pool.goals[id],profile=pool.profiles[id],owner=pool.owners[id];
 if(stableJson(goal)!==stableJson(actualGoals[id]))throw Error('Compared whole Math goal stale');
 const rec=JSON.parse(readFileSync(resolve(root,owner.recordFile.path),'utf8').split(/\r?\n/)[owner.recordLine-1]);
 if(stableJson(profile)!==stableJson(rec.profile)||rec.profileFingerprint!==owner.profileFingerprint)throw Error('Compared whole Math P stale');
 return {goalId:id,wholeCurrentGoal:goal,wholeCurrentProfile:profile,currentProfileOwner:owner,wholeGoalSha256:fingerprint(goal),wholeProfileBodySha256:fingerprint(profile),goalLeafInventory:typedLeaves(goal),profileLeafInventory:typedLeaves(profile),useBoundary:'Whole-body comparison only; candidate mentions and partial matches do not adopt a prerequisite.'};
});
save('all72-content-bound-scientific-judgments.actual.json',{schemaVersion:1,counts,records,individualScientificApprovalOnly:true,noHumanOrSourcePQualityM7Acceptance:true});
save('all72-native-independent-review.inert.json',review);
save('all72-native-validation.actual.json',{authorPath:author,authorSha256:authorHash,inventorySha256,counts,result,preparedAuthorGraphCycleCount:ledger.proposedGraphCycles.length,actualActiveGraphDiagnostics:inv.activeGraphDiagnostics,technicalNativeValidationIsNotScientificApproval:true,protectedSourceFileCount:sourceEndchecks.length});
save('whole-compared-Math-current-bodies-and-owners.actual.json',{count:comparedMath.length,records:comparedMath});
save('all72-binding-coverage-freshness.actual.json',{count:72,counts,allCaseIdsExactlyBound:true,allRequiredExpectationIdsExactlyBound:true,wholeTypedContentLeaves:records.reduce((s,r)=>s+r.fullLeafInventory.goalLeafCount+r.fullLeafInventory.profileLeafCount,0),literalCaseCount:records.reduce((s,r)=>s+r.literalBriefSolves.length,0),ownFreshTransferCount:72,readers:[...new Set(records.map(r=>r.scientificReviewer))],protectedSources:sourceEndchecks,originalBatchSeals:originals,unresolvedScientificGoalIds:records.filter(r=>r.verdict!=='approved').map(r=>({goalId:r.goalId,verdict:r.verdict,gap:r.gap})),sourceMainWrites:false,originalVerdictsPreserved:true});
console.log(JSON.stringify({count:72,counts,literalCases:records.reduce((s,r)=>s+r.literalBriefSolves.length,0),freshTransfers:72,wholeContentLeaves:records.reduce((s,r)=>s+r.fullLeafInventory.goalLeafCount+r.fullLeafInventory.profileLeafCount,0),comparedWholeMath:comparedMath.length,nativeErrors:result.errors.length,nativeReviewed:result.reviewed,nativeOpen:result.open,sourceEndchecks:sourceEndchecks.length}));
