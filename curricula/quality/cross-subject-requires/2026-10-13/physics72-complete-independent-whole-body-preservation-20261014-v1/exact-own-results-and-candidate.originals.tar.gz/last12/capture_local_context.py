# SPDX-License-Identifier: Apache-2.0
"""Read-only source comparison and exact last-twelve review input capture."""
import datetime
import hashlib
import json
from pathlib import Path

R = Path.cwd()
O = R / 'tmp/cross-subject-requires/physics72-whole-positive-independent-supplement-20261014-v1'
S = O / 'last12'
load = lambda p: json.loads(Path(p).read_text())
sha = lambda p: 'sha256:' + hashlib.sha256(Path(p).read_bytes()).hexdigest()
write = lambda name, v: (S / name).write_text(json.dumps(v, ensure_ascii=False, indent=2) + '\n')
pool_path = R / 'tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/currentGoalPositivePool.private.json'
pool = load(pool_path)
inputs = load(O / 'whole-current-Goal-P.exact-input.json')
inv = load(R / 'curricula/quality/cross-subject-requires/math-physics.inventory.json')
math_ids = ['4b67bed9-06da-40b2-a306-24e9e7dfd390', '4eeab7d5-eeb3-579b-845e-1c52ffe9e89f', '80c232f1-8f72-5829-9dbe-5a610ccab3be', 'ffd1ae26-c461-4439-9b18-d835c8f38e1a']
all_goals = {}
sources = {str(pool_path.relative_to(R)): sha(pool_path), 'AGENTS.md': sha(R / 'AGENTS.md')}
for landscape in inv['families'][0]['landscapes']:
    path = R / landscape['path']
    all_goals.update({g['id']: g for g in load(path)['goals']})
    sources[landscape['path']] = sha(path)
closures = []
selected_ids = set(math_ids)
for index in range(60, 72):
    x = inputs[index]
    seen, stack = set(), [x['goalId']]
    while stack:
        gid = stack.pop()
        occ = pool['occurrences'][gid]
        for key in inv['effectivePrerequisiteSets'][occ['effectiveRequiresRef']]:
            rid = key.rsplit(':', 1)[1]
            if rid not in seen:
                seen.add(rid)
                stack.append(rid)
    selected_ids.add(x['goalId'])
    selected_ids.update(k.rsplit(':', 1)[1] for k in inv['effectivePrerequisiteSets'][x['occurrences']['effectiveRequiresRef']])
    closures.append({'index': index, 'goalId': x['goalId'], 'closureIsNoMasteryInference': True,
                     'closure': [{'goalId': gid, 'title': pool['goals'][gid]['title'],
                                  'directRequires': pool['goals'][gid].get('requires', []),
                                  'effectiveRequiresKeys': inv['effectivePrerequisiteSets'][pool['occurrences'][gid]['effectiveRequiresRef']],
                                  'originRecords': [inv['prerequisiteOriginTable'][i] for i in inv['prerequisiteOriginSets'][pool['occurrences'][gid]['prerequisiteOriginsRef']]]}
                                 for gid in sorted(seen)]})
checks, errors = [], []
for gid in sorted(selected_ids):
    owner, profile = pool['owners'].get(gid), pool['profiles'].get(gid)
    check = {'goalId': gid, 'wholeGoalMatchesActualMain': all_goals.get(gid) == pool['goals'][gid], 'owner': owner}
    if owner:
        path = R / owner['recordFile']['path']
        raw = path.read_bytes().splitlines(keepends=True)[owner['recordLine'] - 1]
        rec = json.loads(raw)
        check.update({'wholePMatchesActualOwner': rec['goalId'] == gid and rec['profile'] == profile,
                      'ownerFingerprintExact': rec['profileFingerprint'] == owner['profileFingerprint'],
                      'recordFileHashExact': sha(path) == owner['recordFile']['sha256'],
                      'configHashExact': sha(R / owner['config']['path']) == owner['config']['sha256'],
                      'rawOwnerLineNoNewlineSha256': 'sha256:' + hashlib.sha256(raw.rstrip(b'\r\n')).hexdigest()})
        check['ownerLineHashExact'] = check['rawOwnerLineNoNewlineSha256'] == owner['recordLineSha256']
        sources[owner['recordFile']['path']] = sha(path)
        sources[owner['config']['path']] = sha(R / owner['config']['path'])
    target = next((x for x in inputs[60:72] if x['goalId'] == gid), None)
    if target:
        check['wholeTargetInputGoalMatchesActualMain'] = target['wholeCurrentGoal'] == all_goals[gid]
        check['wholeTargetInputPMatchesActualOwner'] = target['wholeCurrentP'] == profile
        check['wholeTargetInputOwnerMatchesExactPool'] = target['currentProfileOwner'] == owner
    if any(v is False for v in check.values()):
        errors.append(gid)
    checks.append(check)
for name in ['whole-current-Goal-P.exact-input.json', 'direct-inherited-whole-prerequisite-contexts.actual.json', 'all72-whole-content-leaf-inventories.actual.json']:
    sources[str((O / name).relative_to(R))] = sha(O / name)
author = R / 'tmp/cross-subject-requires/physics-whole-positive-coverage-intake-root-20261014-v1/72-native-proposal.bound.inert.json'
sources[str(author.relative_to(R))] = sha(author)
if sha(author) != 'sha256:1adad1696aa75541db2113300619c48df2829831aa6fa62f9fc917635c6588c5':
    errors.append('Root72 author artifact differs')
write('own-last12.exact-input.json', inputs[60:72])
write('own-compared-math.exact-input.json', [{k: pool[k].get(gid) for k in ['goals', 'profiles', 'owners', 'occurrences']} for gid in math_ids])
write('recursive-prerequisite-closure.actual.json', closures)
write('own-main-owner-freshness.actual.json', {'timestampUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'scopeIndices': list(range(60, 72)), 'checks': checks, 'errors': errors, 'sourceFileHashes': sources,
      'technicalExactnessIsNotPersonalScientificReading': True, 'sourceMainWrites': False})
print(json.dumps({'reviewIndices': [60, 71], 'checkedGoalOwners': len(checks), 'errors': errors}))
raise SystemExit(bool(errors))
