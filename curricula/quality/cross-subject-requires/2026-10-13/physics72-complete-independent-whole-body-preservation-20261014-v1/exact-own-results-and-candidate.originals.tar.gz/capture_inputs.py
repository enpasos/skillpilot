# SPDX-License-Identifier: Apache-2.0
import json,pathlib,hashlib,sys
R=pathlib.Path.cwd();O=R/'tmp/cross-subject-requires/physics72-whole-positive-independent-supplement-20261014-v1';B=R/'tmp/cross-subject-requires/physics-whole-positive-coverage-intake-root-20261014-v1'
load=lambda p:json.loads(pathlib.Path(p).read_text());sha=lambda p:'sha256:'+hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();fp=lambda v:'sha256:'+hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
write=lambda n,d:(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
d=load(B/'72-whole-current-Goal-P.private.json');pool=load(R/'tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/currentGoalPositivePool.private.json');inv=load(R/'curricula/quality/cross-subject-requires/math-physics.inventory.json'); goals={}
for f in inv['families'][0]['landscapes']:
 for g in load(R/f['path'])['goals']:goals[g['id']]=g
errors=[]; checks=[]; allsource={}; contexts=[]
for gid,g in pool['goals'].items():
 if gid not in goals or goals[gid]!=g:errors.append('poolGoalMismatch:'+gid)
for gid,p in pool['profiles'].items():
 owner=pool['owners'][gid];file=R/owner['recordFile']['path'];raw=file.read_bytes().splitlines(keepends=True)[owner['recordLine']-1]; rec=json.loads(raw)
 if rec['goalId']!=gid or rec['profile']!=p or rec['profileFingerprint']!=owner['profileFingerprint']:errors.append('poolProfileMismatch:'+gid)
 if sha(file)!=owner['recordFile']['sha256'] or sha(R/owner['config']['path'])!=owner['config']['sha256']:errors.append('poolOwnerMismatch:'+gid)
 allsource[str(file.relative_to(R))]=sha(file);allsource[owner['config']['path']]=sha(R/owner['config']['path'])
for x in d:
 gid=x['goalId'];owner=x['currentProfileOwner'];file=R/owner['recordFile']['path'];raw=file.read_bytes().splitlines(keepends=True)[owner['recordLine']-1];rec=json.loads(raw)
 if x['wholeCurrentGoal']!=goals[gid] or x['wholeCurrentP']!=rec['profile']:errors.append('intakeBodyMismatch:'+gid)
 if sha(file)!=owner['recordFile']['sha256'] or sha(R/owner['config']['path'])!=owner['config']['sha256']:errors.append('intakeOwnerMismatch:'+gid)
 # metadata line hash uses raw text without trailing newline, preserve both checks
 checks.append({'goalId':gid,'actualWholeGoalExact':x['wholeCurrentGoal']==goals[gid],'actualWholePExact':x['wholeCurrentP']==rec['profile'],'ownerExact':owner,'rawLineWithNewlineSha256':'sha256:'+hashlib.sha256(raw).hexdigest(),'rawLineWithoutNewlineSha256':'sha256:'+hashlib.sha256(raw.rstrip(b'\r\n')).hexdigest()})
 occ=x['occurrences'];eff=inv['effectivePrerequisiteSets'][occ['effectiveRequiresRef']];origins=inv['prerequisiteOriginSets'][occ['prerequisiteOriginsRef']]
 ids=[k.rsplit(':',1)[1] for k in eff]
 contexts.append({'goalId':gid,'directRequires':goals[gid].get('requires',[]),'effectiveRequiresKeys':eff,'originSet':origins,'wholePrerequisiteGoalP':[{'goalId':rid,'goal':goals.get(rid),'profile':pool['profiles'].get(rid),'owner':pool['owners'].get(rid)} for rid in ids]})
for f in inv['families'][0]['landscapes']:allsource[f['path']]=sha(R/f['path'])
allsource['curricula/quality/cross-subject-requires/math-physics.inventory.json']=sha(R/'curricula/quality/cross-subject-requires/math-physics.inventory.json')
allsource['AGENTS.md']=sha(R/'AGENTS.md')
for f in B.iterdir():allsource[str(f.relative_to(R))]=sha(f)
write('input-freshness.actual.json',{'errors':errors,'intakeCount':len(d),'fullPoolGoalCount':len(pool['goals']),'fullPoolProfileCount':len(pool['profiles']),'actualSourceFiles':allsource,'currentOwnerChecks':checks,'technicalComparisonNotPersonalReading':True})
write('whole-current-Goal-P.exact-input.json',d);write('direct-inherited-whole-prerequisite-contexts.actual.json',contexts)
# Complete typed leaf inventory is audit evidence, never proof of personal reading on its own.
def leaves(v,path=''):
 if isinstance(v,dict):
  if not v:yield {'path':path,'value':{},'kind':'emptyObject'}
  for k,w in v.items():yield from leaves(w,path+'/'+k)
 elif isinstance(v,list):
  if not v:yield {'path':path,'value':[],'kind':'emptyArray'}
  for i,w in enumerate(v):yield from leaves(w,path+'/'+str(i))
 else:yield {'path':path,'value':v,'kind':type(v).__name__}
write('all72-whole-content-leaf-inventories.actual.json',[{'goalId':x['goalId'],'wholeGoalLeaves':list(leaves(x['wholeCurrentGoal'])),'wholeProfileLeaves':list(leaves(x['wholeCurrentP'])),'wholeGoalSemanticSha256':fp(x['wholeCurrentGoal']),'wholeProfileSemanticSha256':fp(x['wholeCurrentP'])} for x in d])
print(json.dumps({'errors':errors,'count':len(d),'poolGoals':len(pool['goals']),'poolProfiles':len(pool['profiles']),'prerequisiteContexts':len(contexts),'sourceFiles':len(allsource)}));sys.exit(bool(errors))
