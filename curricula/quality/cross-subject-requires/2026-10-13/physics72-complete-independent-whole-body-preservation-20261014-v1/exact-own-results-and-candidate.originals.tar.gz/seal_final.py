# SPDX-License-Identifier: Apache-2.0
import pathlib,json,hashlib,datetime
R=pathlib.Path.cwd();O=pathlib.Path(__file__).resolve().parent
load=lambda p:json.loads(pathlib.Path(p).read_text());sha=lambda p:'sha256:'+hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();fp=lambda v:'sha256:'+hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
coverage=load(O/'all72-binding-coverage-freshness.actual.json');errors=[]
for f in coverage['protectedSources']:
 if sha(R/f['path'])!=f['expectedSha256']:errors.append('Protected source changed: '+f['path'])
for b in range(1,7):
 for f in load(O/f'batch{b:02d}.seal.actual.json')['files']:
  if sha(R/f['path'])!=f['sha256']:errors.append('Sealed batch file changed: '+f['path'])
math=load(O/'whole-compared-Math-current-bodies-and-owners.actual.json')['records'];ours=load(O/'own-arithmetic-and-compared-Math-casework.actual.json')['comparedMathWholeProfileCasework'];child=load(O/'last12/compared-math-literal-and-fresh-casework.actual.json');childmap={r['goalId']:r for r in child['records']}
mathcoverage=[]
for m in math:
 gid=m['goalId'];p=m['wholeCurrentProfile']
 if gid in ours:
  c=ours[gid];answers=c['literalSolutions'];fresh=c['ownFreshTransfer'];producer='/root/physics72_whole_positive_independent_supplement';artifact='own-arithmetic-and-compared-Math-casework.actual.json'
 elif gid in childmap:
  c=childmap[gid];producer=child['reviewer'];artifact='last12/compared-math-literal-and-fresh-casework.actual.json'
  # Preserve child record structure; all literal IDs are exactly bound by its own source receipt.
  answers=c.get('literalBriefSolutions',c.get('literalCaseSolutions',c.get('literalCases',c.get('literalBriefSolves',[]))))
  fresh=c.get('ownFreshTransfer',c.get('freshTransfer',c.get('fresh',None)))
 else:errors.append('No own full Math casework: '+gid);continue
 if gid in ours and len(answers)!=len(p['applicationCaseBriefs']):errors.append('Own math literal count mismatch: '+gid)
 mathcoverage.append({'goalId':gid,'scientificProducer':producer,'wholeCurrentProfileOwner':m['currentProfileOwner'],'wholeProfileBodySha256':m['wholeProfileBodySha256'],'requiredExpectationIds':p['coverageExpectations']['requiredExpectationIds'],'literalCaseIds':[b['id'] for b in p['applicationCaseBriefs']],'literalCaseCount':len(p['applicationCaseBriefs']),'caseworkArtifact':artifact,'caseworkRecordSha256':fp(c),'wholeBodyComparisonNotAutomaticPrerequisite':True})
if len(mathcoverage)!=13:errors.append('13 whole Math coverage incomplete')
(O/'all13-compared-Math-casework-binding.actual.json').write_text(json.dumps({'count':13,'records':mathcoverage,'errors':errors,'ownLiteralAndFreshMathSupport':True},ensure_ascii=False,indent=2)+'\n')
for n in ['final72','arithmetic']:
 e=load(O/(n+'.execution.actual.json'))
 if e['exitCode']!=0:errors.append('Execution failed:'+n)
 if sha(O/(n+'.stdout.raw.txt'))!=e['stdoutSha256'] or sha(O/(n+'.stderr.raw.txt'))!=e['stderrSha256']:errors.append('Raw execution receipt changed:'+n)
if errors:raise RuntimeError('\n'.join(errors))
files=[]
for p in sorted(O.rglob('*')):
 if not p.is_file() or p.name=='final-artifact-seal.actual.json':continue
 if p.suffix=='.json':load(p)
 files.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)})
seal={'role':'Final exact-byte seal for independent current whole Goal/P Physics72 scientific Requires supplement','timestampUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':{'approved':57,'rejected':8,'pending':7},'scientificGoalCount':72,'literalBriefSolutions':173,'ownFreshTransfers':72,'wholeContentLeaves':6902,'comparedWholeMathGoalP':13,'sourceEndchecksUnchanged':539,'originalSixBatchSealsStillExact':True,'nativeErrors':0,'nativeActualApprovals':57,'remainingSubstantiveItems':15,'noActiveAdoptionOrSourceMainPChanges':True,'humanOrSourceQualityApproval':False,'files':files,'fileCount':len(files)}
(O/'final-artifact-seal.actual.json').write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'fileCount':len(files),'finalSealSha256':sha(O/'final-artifact-seal.actual.json'),'counts':seal['counts'],'remainingScientificItems':15}))
