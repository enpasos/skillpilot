# SPDX-License-Identifier: Apache-2.0
# Own exact/numerical audit of calculations used in current full-profile review.
import json,pathlib,math,hashlib,subprocess,sys
from fractions import Fraction as F
O=pathlib.Path(__file__).resolve().parent
cases={
 'entropy16to4':{'subsystemPerKB':math.log(4)-math.log(16),'totalPerKB':2+math.log(4)-math.log(16),'allowed':2-math.log(4)>0},
 'entropy9to3OwnTransfer':{'totalPerKB':1+math.log(3)-math.log(9),'allowed':1-math.log(3)>=0},
 'detectorUnequalDurationsOwnSynthetic':{'backgroundPerSecond':F(30,120),'sourcePerSecond':F(24,30),'sourceExpectedPer120Seconds':F(24,30)*120},
 'voltmeterOwnSynthetic':{'range6V_at18of30':F(6)*F(18,30),'range15V_at18of30':F(15)*F(18,30)},
 'wheelAxleLiteral':{'pathFactor':F(40,10),'forceFactor':F(10,40),'productFactor':F(40,10)*F(10,40)},
 'weightScaleLiteral':{'sum':sum([203,202,204,203,202]),'mean':F(sum([203,202,204,203,202]),5),'range':204-202,'meanAfter3gZeroCorrection':F(1014,5)-3},
 'motionOutlierOwnSynthetic':{'meanWith':sum([F(10),F(101,10),F(99,10),F(10),F(30)])/5,'rangeWith':F(30)-F(99,10),'meanWithout':sum([F(10),F(101,10),F(99,10),F(10)])/4,'rangeWithout':F(101,10)-F(99,10)},
 'sampleInterval50HzLiteral':{'seconds':F(1,50),'milliseconds':F(1000,50),'pulseMilliseconds':8,'coarseIntervalExceedsPulse':F(1000,50)>8},
 'massUnitsLiteralAndOwnTransfer':{'fourKgInG':4000,'tenGInKg':F(10,1000),'quarterKgInG':F(250,1000)*1000},
 'nonProportionalStraightOwnSynthetic':{'quotientsAperV':[F(2,10)/1,F(3,10)/2,F(4,10)/3]},
 'crossProductsInOwnSolutions':{'xCrossMinusZ':[0,1,0],'zCrossY':[-1,0,0],'yCrossZ':[1,0,0]},
}
# calculate cross products independently from arithmetic definition, not solely expected tuples
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
actual=[cross([1,0,0],[0,0,-1]),cross([0,0,1],[0,1,0]),cross([0,1,0],[0,0,1])]
assert actual==list(cases['crossProductsInOwnSolutions'].values())
assert cases['wheelAxleLiteral']['productFactor']==1
assert cases['weightScaleLiteral']['mean']==F(1014,5)
assert cases['motionOutlierOwnSynthetic']['meanWith']==14
# These Math P literal solutions and new transfers are analytic, not evidence of real measurement.
math_solutions={
 '2231c29b-eb4e-51ae-9cb1-eb033bf16099':{'literalSolutions':['Direction equal and supporting lines nonintersecting: parallel; right-angle marked: perpendicular; neither condition: neither, independent of sheet orientation.','Two disjoint short segments with unequal supporting directions are not parallel; supporting lines meeting at a right angle after extension make segments perpendicular.'],'ownFreshTransfer':'Rotate both segments and their right-angle marker; relation remains perpendicular. A near-right-angle appearance without a defining condition is not proof.'},
 'c31d3a7a-778b-5ae3-9aa4-7b5674047f83':{'literalSolutions':['Align set-square edge with oblique g, translate without rotation to P, draw p through P. Direction preserved, p parallel g.','Choose A/B equally far from Q on h; equal-radius arcs from A/B intersect S. QA=QB and SA=SB place Q/S on perpendicular bisector of AB, so QS is perpendicular h.'],'ownFreshTransfer':'For point off h, a circle centred at P intersects h at A/B; equal-radius arcs then construct second equidistant point, giving perpendicular through P. This full compass proof is broader than lens principal-ray tracing.'},
 '093397e0-eec8-45bb-9a5a-a24827876df5':{'literalSolutions':['300g/4=75g per serving; times10=750g; scaling back10→4 gives300g.','3.2cm/8km=0.4cm per km, times14km=5.6cm, larger than3.2cm.','PlanA7×2.50=17.50EUR, proportional without base fee. PlanB has fixed4EUR, violates equal-factor scaling; rule-of-three method rejected there.'],'ownFreshTransfer':'A stationary detector expectation of24counts in30s gives0.8count/s, hence96 in120s. If source intensity drifts, fixed proportional scaling needs qualification.'},
 '3c1d6ce7-099e-4267-9ff2-3d1526209a89':{'literalSolutions':['3^4=81, so log_3(81)=4; 2^(−3)=1/8, so log_2(1/8)=−3.','2^2<7<2^3, log_2(7)≈2.807354922 between2and3. Base1 and negative real argument are excluded.'],'ownFreshTransfer':'log_3(1/9)=−2 because3^(−2)=1/9. Natural-log entropy step9→3 decreases bykB ln3; numerical evaluation is explicit, not a title-based qualitative exemption.'},
 '80c232f1-8f72-5829-9dbe-5a610ccab3be':{'literalSolutions':['Midpoint time2..4h gives3h; midpoint temperature0..10°C gives5°C. Read point as after3h temperature5°C.','A at2×100EUR=200EUR; B at3.5×100EUR=350EUR; difference150EUR; A/B categories, horizontal axis quantity.'],'ownFreshTransfer':'A meter scale0..30 at18 in6V range gives3.6V, but full Math P also contains categorical/quantitative chart-axis roles, so whole-atom necessity for a voltmeter cannot be inferred from the scale fragment alone.'},
 'c1f50bcc-7848-4e49-b9de-0ec030cc6bca':{'literalSolutions':['Exclude0/0 computation, check(0,0) separately;12/2=30/5=48/8=6L/min, so displayed pairs fit y=6x.','5/2=10/4=2.50EUR/kg,18/7 differs, so final pair refutes proportionality.','Reversed columns do not reverse roles:90/1.5=180/3=300/5=60km/h, zero row separately compatible.'],'ownFreshTransfer':'Pairs(1V,.20A),(2V,.30A),(3V,.40A) have differentI/U despite lying on a rising affine line; this rejects the shortcut rising straight line alone proves proportionality.'},
 'c63bbffd-8d1c-5fe2-a428-db194e6fe592':{'literalSolutions':['a+b=(1,3);a−b=(5,−5), since−b=(2,−4), with corresponding endpoints from origin.','AB=(3,−3,2),BC=(−2,3,3),AC=(1,0,5);AB+BC=AC andAC−AB=BC.'],'ownFreshTransfer':'Planar common-scale arrows3east/4north have graphical resultant5northeast. Full Math P additionally requires component subtraction and3D route reconstruction; field graphical addition does not automatically require that whole atom.'},
 'fe07241a-b779-5f35-a82d-7aa51ae74f42':{'literalSolutions':['48749 rounds nearest hundred to48700; natural inputs48650..48749 round to48700 under given half-up rule.','2483917 nearest10000 gives2480000 for rough overview; capacity planning can require exact value or finer justified rounding, e.g. nearest100 gives2483900.'],'ownFreshTransfer':'Natural number-rounding scope does not itself authorize a0.5°C decimal measurement-grid rule; that is a distinct verified scope/granularity gap.'},
 'f2e42af5-67a6-477e-82ea-e65b09cc6cb3':{'literalSolutions':['2.35m,228cm=2.28m,.0024km=2.4m; order2.28<2.35<2.4m.','1h20min=80min, not120min; compared75min first is5min longer, unchanged physical duration.'],'ownFreshTransfer':'0.250kg=250g exceeds240g. For50Hz, sampling interval1/50s=20ms, so unit comparison is valid but reciprocal relation is an additional explicit operation, not justified solely by unit-conversion title.'},
 'ca623958-c204-5d1b-bdd0-3f76765674cb':{'literalSolutions':['1.8km+.650km−.4km=2.05km remaining, like lengths in common unit.','12kg/8=1.5kg per box, notkg²; division by pure count retains mass dimension.'],'ownFreshTransfer':'Synthetic sound-speed differences1500−1400=100m/s and5000−900=4100m/s preserve velocity units. A ratio of two velocities is dimensionless and needs separate scope consideration beyond scalar division by count.'}
}
def cv(x):
 if isinstance(x,F):return {'exactRational':str(x),'decimal':float(x)}
 if isinstance(x,dict):return {k:cv(v) for k,v in x.items()}
 if isinstance(x,list):return [cv(v) for v in x]
 return x
(O/'own-arithmetic-and-compared-Math-casework.actual.json').write_text(json.dumps({'role':'Executed own analytic arithmetic audit and personally read compared whole Math P literal solutions; no empirical/historical data or approval by tests','physicsProbes':cv(cases),'comparedMathWholeProfileCasework':math_solutions,'sourceSha256':'sha256:'+hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'executedArithmeticProbeFamilies':len(cases),'comparedMathWholePCaseworkCount':len(math_solutions),'assertionsPassed':True}))
