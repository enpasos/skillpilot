# SPDX-License-Identifier: Apache-2.0
import pathlib,subprocess,json,hashlib,sys,datetime
r=pathlib.Path.cwd();o=pathlib.Path(__file__).resolve().parent;kind=sys.argv[1]
module=o/('own_math_casework.py' if kind=='arithmetic' else 'final72_bind_and_audit.mts')
argv=([sys.executable,str(module)] if kind=='arithmetic' else [str(r/'app/node_modules/.bin/tsx'),str(module)])
paths=[module,r/'app/scripts/lib/crossSubjectRequiresInventory.ts',r/'app/scripts/lib/crossSubjectRequiresReview.ts']
before={str(p.relative_to(r)):'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
p=subprocess.run(argv,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(o/(kind+'.stdout.raw.txt')).write_bytes(p.stdout);(o/(kind+'.stderr.raw.txt')).write_bytes(p.stderr)
(o/(kind+'.execution.actual.json')).write_text(json.dumps({'argv':argv,'cwd':str(r),'exitCode':p.returncode,'timestampUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'executedSourceHashesBefore':before,'stdoutSha256':'sha256:'+hashlib.sha256(p.stdout).hexdigest(),'stderrSha256':'sha256:'+hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n')
print(p.stdout.decode(),end='');print(p.stderr.decode(),end='',file=sys.stderr);sys.exit(p.returncode)
