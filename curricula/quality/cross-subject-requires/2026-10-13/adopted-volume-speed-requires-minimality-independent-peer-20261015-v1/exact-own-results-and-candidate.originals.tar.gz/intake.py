#!/usr/bin/env python3
# Apache-2.0. Read-only independent intake; writes only this owned capsule.
import json, pathlib, hashlib, datetime, shutil
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'tmp/cross-subject-requires/adopted-volume-speed-requires-minimality-author-20261015-v1'
def read(p): return json.loads((ROOT/p).read_text())
def put(n,x): (OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p): return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
registryPath='curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
registry=read(registryPath)
authorGoals=json.loads((AUTHOR/'whole-selected-Goals.exact.json').read_text())
ids={x['id'] for x in authorGoals}
subjects=[x for x in registry['subjects'] if x['subject'] in ['mathematik','physik']]
goals={}; selected=[]; owners=[]; kinds={}; inputFiles={registryPath}
for s in subjects:
 inputFiles.update([s['landscapePath'],s['semanticKindLedgerPath']])
 landscape=read(s['landscapePath']); goals.update({g['id']:g for g in landscape['goals']})
 ledger=read(s['semanticKindLedgerPath']); kinds.update({d['goalId']:d for d in ledger['decisions']})
 for path in s['positiveEvidenceConfigPaths']:
  c=read(path)
  chosen=ids.intersection(c.get('scope',{}).get('goalIds',[]))
  if not chosen: continue
  inputFiles.update([path,c['reviewPath'],c['reviewCriteriaPath']])
  raw=(ROOT/c['reviewPath']).read_text().splitlines()
  for i,line in enumerate(raw,1):
   r=json.loads(line)
   if r['goalId'] not in chosen: continue
   owners.append({'goalId':r['goalId'],'registryPath':registryPath,'configPath':path,'reviewPath':c['reviewPath'],'line':i,'record':r,'semanticKindDecision':kinds[r['goalId']]})
  selected.append({'path':path,'config':c})
assert len(owners)==len(ids)==12
assert {x['goalId'] for x in owners}==ids
actualGoals=[goals[g['id']] for g in authorGoals]
assert actualGoals==authorGoals
authorP=json.loads((AUTHOR/'registered-whole-P.exact.json').read_text())
assert sorted(owners,key=lambda x:x['goalId'])==sorted(authorP,key=lambda x:x['goalId'])
put('whole-selected-Goals.actual.json',actualGoals)
put('registered-whole-P.actual.json',sorted(owners,key=lambda x:x['goalId']))
put('selected-current-P-configs.actual.json',selected)
put('whole-orientation-Goal.actual.json',goals['65365dce-f33f-49d8-9516-42f75883aa86'])
for name in ['exact-direct-source-claims.json','selected-program-placements.exact.json']:
 shutil.copyfile(AUTHOR/name,OUT/name)
claims=read(str((OUT/'exact-direct-source-claims.json').relative_to(ROOT)))
checks=[]
for z in claims:
 inputFiles.update([z['mappingPath'],z['sourceExtractionPath']])
 extraction=read(z['sourceExtractionPath'])
 sourceGoals=extraction.get('goals',extraction.get('sourceGoals',[]))
 actual=next((g for g in sourceGoals if g['id']==z['sourceGoal']['id']),None)
 checks.append({'goalId':z['mapping']['canonicalGoalId'],'sourceGoalId':z['sourceGoal']['id'],'sourceExtractionPath':z['sourceExtractionPath'],'sourceGoalExact':actual==z['sourceGoal']})
put('source-extraction-current-checks.actual.json',checks)
put('input-file-hashes.before.json',[{'path':p,'sha256':sha(ROOT/p),'bytes':(ROOT/p).stat().st_size} for p in sorted(inputFiles)])
put('intake-receipt.actual.json',{'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actualSelectedGoalsEqualAuthorNeutral':True,'actualRegisteredWholePEqualAuthorNeutral':True,'recordCount':len(owners),'sourceClaimChecks':len(checks),'sourceGoalsAllExact':all(x['sourceGoalExact'] for x in checks),'noAuthorReportOrJudgmentOpenedByScript':True,'scope':'canonical Gymnasium Mathematik/Physik only; selective P ownership scan'})
print(json.dumps(read(str((OUT/'intake-receipt.actual.json').relative_to(ROOT))),indent=2))
