#!/usr/bin/env python3
# Apache-2.0. Additive post-lock binding and history verification only.
import pathlib,json,hashlib,datetime,shutil
OUT=pathlib.Path(__file__).resolve().parent;ROOT=OUT.parents[2]
AUTHOR=ROOT/'tmp/cross-subject-requires/adopted-volume-speed-requires-minimality-author-20261015-v1'
def read(p): return json.loads(p.read_text())
def sha(p): return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x): (OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
prior=read(OUT/'input-file-hashes.before.json')
stable=[{**x,'actualSha256':sha(ROOT/x['path']),'unchanged':sha(ROOT/x['path'])==x['sha256']} for x in prior]
claims=read(OUT/'exact-direct-source-claims.json');checks=[]
for z in claims:
 mapping=read(ROOT/z['mappingPath']);extraction=read(ROOT/z['sourceExtractionPath'])
 sg=next(g for g in extraction.get('sourceGoals',extraction.get('goals',[])) if g['id']==z['sourceGoal']['id'])
 passage=next((p for p in extraction.get('passages',[]) if p['id']==sg.get('passageId')),None)
 checks.append({'goalId':z['mapping']['canonicalGoalId'],'sourceGoalId':sg['id'],'mappingPath':z['mappingPath'],'sourceExtractionPath':z['sourceExtractionPath'],'mappingExact':z['mapping'] in mapping['mappings'],'sourceGoalExact':sg==z['sourceGoal'],'passageExact':passage==z['passage']})
put('source-mapping-passage-current-checks.actual.json',checks)
landscapes=[read(ROOT/('curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_'+s+'.de.json')) for s in ['MATHEMATIK','PHYSIK']]
goals={g['id']:g for l in landscapes for g in l['goals']};parents={g:[] for g in goals}
for g in goals.values():
 for c in g.get('contains',[]):parents[c].append(g['id'])
def ancestors(g):
 done=set();todo=[g]
 while todo:
  a=todo.pop()
  for p in parents[a]:
   if p not in done:done.add(p);todo.append(p)
 return done
placements=[]
for row in read(OUT/'selected-program-placements.exact.json'):
 ids=ancestors(row['goalId'])|{row['goalId']}
 actual=[p for l in landscapes for p in l.get('goalPlacements',[]) if p['goalId'] in ids]
 units={p['unitId'] for p in actual};actualUnits=[u for l in landscapes for u in l.get('programUnits',[]) if u['id'] in units]
 canon=lambda a:sorted(json.dumps(x,sort_keys=True,ensure_ascii=False) for x in a)
 placements.append({'goalId':row['goalId'],'selfAndAncestorPlacementsExact':canon(actual)==canon(row['selfAndAncestorPlacements']),'unitsExact':canon(actualUnits)==canon(row['units'])})
put('placements-current-checks.actual.json',placements)
seal=read(AUTHOR/'SEAL.json');authorChecks=[{'path':x['path'],'sha256':x['sha256'],'actualSha256':sha(ROOT/x['path']),'match':sha(ROOT/x['path'])==x['sha256']} for x in seal['files']]
put('author-seal-current-check.actual.json',{'sealSha256':sha(AUTHOR/'SEAL.json'),'files':authorChecks,'pass':all(x['match'] for x in authorChecks)})
post=OUT/'post-lock-author-and-history';post.mkdir(exist_ok=True)
for n in ['REPORT.txt','own-judgment-lock.txt','worked-cases.txt','proposed-requires-only.author.json','prior-genuine-KEEP-history.exact-excerpts.json','SEAL.json']:shutil.copyfile(AUTHOR/n,post/n)
history=read(post/'prior-genuine-KEEP-history.exact-excerpts.json');hist=[]
for row in history:
 d=read(ROOT/row['path']);records=d if isinstance(d,list) else d.get('judgments',d.get('goals',d.get('records',[])))
 hist.append({'path':row['path'],'recordedFileSha256':row['sha256'],'actualFileSha256':sha(ROOT/row['path']),'fileHashExact':sha(ROOT/row['path'])==row['sha256'],'goalId':row['goalId'],'exactExcerptRecordCount':len(row['exactRelevantRecords'])})
put('prior-history-binding-check.actual.json',hist)
own=read(OUT/'independent-virtual-changes.json');author=read(post/'proposed-requires-only.author.json')
same=all(next(x['requires'] for x in own if x['goalId']==a['goalId'])==a['after'] for a in author)
put('post-lock-comparison.actual.json',{'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preAuthorLock':read(OUT/'PRE_AUTHOR_LOCK.json'),'proposedExactOrderedArraysAgree':same,'substantiveJudgmentChanged':False,'historyBindings':hist,'independenceLimit':'Before-lock full German semantic projection, neutral full exact P records/native fingerprints, and all 26 case solutions; complete English-only projection reread after author comparison. No new independent opinion is claimed by this supplementary bilingual confirmation. Initial registry/config path names and historical scope/authority labels were exposed, but substantive author rationale and old verdicts were first opened after PRE_AUTHOR_LOCK.'})
summary={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allInputsStable':all(x['unchanged'] for x in stable),'inputFiles':len(stable),'all193SourceGoalsMappingsPassagesExact':all(x['mappingExact'] and x['sourceGoalExact'] and x['passageExact'] for x in checks),'all12PlacementsAndUnitsExact':all(x['selfAndAncestorPlacementsExact'] and x['unitsExact'] for x in placements),'author19SealedFilesExact':all(x['match'] for x in authorChecks),'authorExactOrderedArraysAgree':same,'priorGenuineHistoryFilesExact':all(x['fileHashExact'] for x in hist)}
put('input-file-hashes.after.json',stable);put('postcheck-receipt.actual.json',summary)
print(json.dumps(summary,indent=2))
assert all(v for k,v in summary.items() if k not in ['atUTC','inputFiles'])
