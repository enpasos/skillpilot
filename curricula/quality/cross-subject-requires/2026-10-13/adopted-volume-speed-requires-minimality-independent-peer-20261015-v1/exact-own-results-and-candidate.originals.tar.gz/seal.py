#!/usr/bin/env python3
# Apache-2.0. Seal a finite curated capsule; self-manifest excluded explicitly.
import pathlib,json,hashlib,datetime
OUT=pathlib.Path(__file__).resolve().parent;ROOT=OUT.parents[2]
files=[]
for p in sorted(OUT.rglob('*')):
 if p.name=='SEAL.json' and p.parent==OUT:continue
 assert not p.is_symlink(),p
 if not p.is_file():continue
 assert p.suffix not in ['.pyc','.class','.jar'],p
 assert not any(v in p.parts for v in ['node_modules','__pycache__','.cache']),p
 if p.suffix=='.json':json.loads(p.read_text())
 files.append({'path':str(p.relative_to(ROOT)),'sha256':'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
assert len(files)<60
seal={'sealedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authority':'bounded genuine independent scientific AI peer evidence; exact ordered arrays accepted within stated limits; no Main writes or human/M7/host acceptance','root':str(OUT.relative_to(ROOT)),'manifestScope':'all owned files except root SEAL.json; finite reports/exact selected inputs/scripts/receipts/history, no caches/classes/jars/full governance/private fixtures','fileCount':len(files),'totalBytes':sum(x['bytes'] for x in files),'files':files}
(OUT/'SEAL.json').write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n')
for x in files:assert 'sha256:'+hashlib.sha256((ROOT/x['path']).read_bytes()).hexdigest()==x['sha256']
print(json.dumps({'fileCount':len(files),'bytes':seal['totalBytes'],'sealSha256':'sha256:'+hashlib.sha256((OUT/'SEAL.json').read_bytes()).hexdigest(),'allManifestEntriesVerified':True},indent=2))
