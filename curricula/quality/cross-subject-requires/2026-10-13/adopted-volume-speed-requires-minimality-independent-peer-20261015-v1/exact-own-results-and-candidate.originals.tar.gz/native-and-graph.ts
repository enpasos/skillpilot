// Apache-2.0. Native selective read-only review checks; virtual variants only.
import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {dirname,resolve} from 'node:path'
import {fileURLToPath} from 'node:url'
import {buildCrossLandscapeGraph,findCrossLandscapeCycles} from '../../../app/scripts/lib/crossLandscapeGraph.ts'
import {fingerprintGoalForPositiveEvidence,fingerprintPositiveGoalEvidenceProfile,fingerprintPositiveGoalEvidenceReviewInput,validatePositiveGoalEvidenceRecordSemantics} from '../../../app/scripts/positiveGoalEvidenceProfileModel.ts'
import {fingerprintSemanticKindSourceGoal} from '../../../app/scripts/goalBookModel.ts'
const out=dirname(fileURLToPath(import.meta.url)), root=resolve(out,'../../..')
const read=(p:string)=>JSON.parse(readFileSync(resolve(root,p),'utf8'))
const local=(p:string)=>JSON.parse(readFileSync(resolve(out,p),'utf8'))
const put=(p:string,x:any)=>writeFileSync(resolve(out,p),JSON.stringify(x,null,2)+'\n')
const hash=(b:any)=>'sha256:'+createHash('sha256').update(b).digest('hex')
const registry=read('curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json')
const subjects=registry.subjects.filter((x:any)=>['mathematik','physik'].includes(x.subject))
const landscapes=subjects.map((s:any)=>({...read(s.landscapePath),file:s.landscapePath}))
const graph=buildCrossLandscapeGraph(landscapes)
const owned=local('registered-whole-P.actual.json')
const fp=owned.map((x:any)=>{
 const config=read(x.configPath), node=graph.resolveReference(x.goalId,x.record.landscapeId)!, g:any=node.goal
 const resourceDigests:Record<string,string>={}, resources:any[]=[]
 for(const l of g.resourceLinks??[]) if(config.reviewedResourceTypes.includes(l.type)){
  const p='app/public'+l.url, bytes=readFileSync(resolve(root,p));resourceDigests[l.url]=hash(bytes);resources.push({path:p,sha256:hash(bytes),bytes:bytes.length})
 }
 const k=x.semanticKindDecision.semanticKind
 const actualGoalFingerprint=fingerprintGoalForPositiveEvidence(g,k)
 const actualProfileFingerprint=fingerprintPositiveGoalEvidenceProfile(x.record.profile)
 const actualReviewInputFingerprint=fingerprintPositiveGoalEvidenceReviewInput(g,x.record.reviewCriteriaFingerprint,resourceDigests,k)
 const actualKindSourceFingerprint=fingerprintSemanticKindSourceGoal(g)
 const errors=validatePositiveGoalEvidenceRecordSemantics(x.record,g,resourceDigests,k)
 if(actualKindSourceFingerprint!==x.semanticKindDecision.sourceFingerprint)errors.push('native Kind source fingerprint mismatch')
 return {goalId:g.id,configPath:x.configPath,reviewPath:x.reviewPath,line:x.line,reviewedResourceTypes:config.reviewedResourceTypes,semanticKindDecision:x.semanticKindDecision,actualGoalFingerprint,recordedGoalFingerprint:x.record.goalFingerprint,actualProfileFingerprint,recordedProfileFingerprint:x.record.profileFingerprint,actualReviewInputFingerprint,recordedReviewInputFingerprint:x.record.reviewInputFingerprint,actualKindSourceFingerprint,resources,errors}
})
put('native-current-bindings.actual.json',{atUTC:new Date().toISOString(),scope:'Exact registered config reviewedResourceTypes; native P and Kind helpers; 12 selected records only',rows:fp,pass:fp.every((r:any)=>r.errors.length===0)})
const ids=['f827b00f-af7f-52de-84aa-2a2bbaa035bd','ec7a0a68-730b-5c94-ac72-a937508f8303','5f548596-9bc3-532e-88a0-81d5029809e9','8d30d241-0247-48ac-83d3-4e0de61584d3','7c978529-ce62-5adc-897f-24ea80babbc8','2331caf2-ccb2-5492-9fc6-48763b848bae']
function closure(gr:any,id:string){
 const node=gr.owners.get(id)[0],seen=new Set<string>(),edges:any[]=[]
 function visit(key:string){if(seen.has(key))return;seen.add(key);for(const o of gr.effectiveOrigins.get(key)??[]){edges.push({dependentGoalId:gr.nodes.get(key).goal.id,requiredGoalId:gr.nodes.get(o.prerequisiteKey).goal.id,originGoalId:gr.nodes.get(o.declaredByKey).goal.id,kind:o.inherited?'contains-inherited':'direct',...o});visit(o.prerequisiteKey)}}
 visit(node.key)
 const ancestors=new Set<string>();for(const key of seen)for(const a of gr.ancestors(key))ancestors.add(a)
 return {rootId:id,countIncludingRoot:seen.size,goalIds:[...seen].map(k=>gr.nodes.get(k).goal.id).sort(),edges,goals:[...seen].map(k=>gr.nodes.get(k).goal).sort((a:any,b:any)=>a.id.localeCompare(b.id)),ancestorOrigins:[...ancestors].map(k=>gr.nodes.get(k).goal).sort((a:any,b:any)=>a.id.localeCompare(b.id))}
}
const current=ids.map(id=>closure(graph,id));put('current-effective-closures.actual.json',current)
const old=read('tmp/cross-subject-requires/adopted-volume-speed-requires-minimality-author-20261015-v1/current-effective-closures.exact.json')
const independentCurrentMatches=old.every((x:any)=>JSON.stringify(x.goalIds)===JSON.stringify(current.find(y=>y.rootId===x.rootId)!.goalIds))
const changes=[{goalId:ids[0],requires:['5c44b9ba-9b05-4774-95d5-073230d3fc4f',ids[4]]},{goalId:ids[3],requires:[ids[5],'8a691345-3216-522c-a898-d65e8e94db28','65365dce-f33f-49d8-9516-42f75883aa86']}]
const virtual=landscapes.map((l:any)=>({...l,goals:l.goals.map((g:any)=>{const c=changes.find(c=>c.goalId===g.id);return c?{...g,requires:c.requires}:g})}))
const cg=buildCrossLandscapeGraph(virtual),next=ids.map(id=>closure(cg,id));put('independent-virtual-changes.json',changes);put('independent-virtual-closures.actual.json',next)
const deltas=ids.map(id=>{const a=current.find(c=>c.rootId===id)!,b=next.find(c=>c.rootId===id)!;return{goalId:id,before:a.countIncludingRoot,after:b.countIncludingRoot,removed:a.goalIds.filter(x=>!b.goalIds.includes(x)),added:b.goalIds.filter(x=>!a.goalIds.includes(x))}})
const virtualBindings=changes.map(c=>{const x=owned.find((x:any)=>x.goalId===c.goalId),g=cg.owners.get(c.goalId)![0].goal as any,r=fp.find((r:any)=>r.goalId===c.goalId)!,digests:Record<string,string>={};for(const a of r.resources)digests[a.path.slice('app/public'.length)]=a.sha256;return {goalId:c.goalId,goalFingerprint:fingerprintGoalForPositiveEvidence(g,x.semanticKindDecision.semanticKind),profileFingerprint:fingerprintPositiveGoalEvidenceProfile(x.record.profile),reviewInputFingerprint:fingerprintPositiveGoalEvidenceReviewInput(g,x.record.reviewCriteriaFingerprint,digests,x.semanticKindDecision.semanticKind),oldReviewInputFingerprint:x.record.reviewInputFingerprint,kindSourceFingerprint:fingerprintSemanticKindSourceGoal(g),receiptWritten:false}})
put('independent-virtual-native-bindings.actual.json',virtualBindings)
const probes=[ids[0],ids[1],ids[3]].map(id=>{
 const node=cg.owners.get(id)![0],c=next.find(c=>c.rootId===id)!,mastered=new Set(c.goalIds.filter(x=>x!==id))
 const missing=(gr:any)=>{const n=gr.owners.get(id)[0];return(gr.effectiveRequires.get(n.key)??[]).map((k:string)=>gr.nodes.get(k).goal.id).filter((x:string)=>!mastered.has(x))}
 return{goalId:id,scenario:'Only the full virtual prerequisite closure is mastered; target remains unmastered',virtualMissing:missing(cg),currentMissing:missing(graph),masteryCount:mastered.size}
})
put('graph-probe-receipt.actual.json',{atUTC:new Date().toISOString(),helper:'app/scripts/lib/crossLandscapeGraph.ts',independentCurrentMatchesAuthorNeutral:independentCurrentMatches,currentDiagnostics:graph.diagnostics,currentCycles:findCrossLandscapeCycles(graph),virtualDiagnostics:cg.diagnostics,virtualCycles:findCrossLandscapeCycles(cg),deltas,probes,scope:'Canonical Mathematics/Physics two-landscape production graph helper, virtual in-memory variants; no runtime host or whole-repository CI claim'})
console.log(JSON.stringify({nativePAndKindAllCurrent:fp.every((r:any)=>!r.errors.length),independentCurrentMatchesAuthorNeutral:independentCurrentMatches,currentDiagnostics:graph.diagnostics.length,virtualDiagnostics:cg.diagnostics.length,currentCycles:findCrossLandscapeCycles(graph).length,virtualCycles:findCrossLandscapeCycles(cg).length,deltas:deltas.map(x=>({goalId:x.goalId,before:x.before,after:x.after})),probes},null,2))
if(!independentCurrentMatches||fp.some((r:any)=>r.errors.length)||graph.diagnostics.length||cg.diagnostics.length||findCrossLandscapeCycles(graph).length||findCrossLandscapeCycles(cg).length)process.exitCode=1
