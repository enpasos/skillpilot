"""Actual production checks for one source-reviewed target omission candidate.
SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent;T=R/'tmp/cross-subject-requires'
N=R/'tmp/ci-tools/node-v20.20.2-linux-x64/bin/node';J=R/'tmp/ci-tools/amazon-corretto-25.0.2.10.1/bin';A=T/'actual-root72-native-route-and-target-followup-root-20261016-v1';B=T/'current45-current-root-fresh-native-route-replay-root-20261015-v1'
def bind(p):
 raw=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(raw),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()}
def read(p):return json.loads(p.read_text())
def write(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def run(n,args):
 started=datetime.now(timezone.utc).isoformat();out=O/(n+'.stdout.txt');err=O/(n+'.stderr.txt');assert not out.exists()and not err.exists()
 with out.open('wb')as stdout,err.open('wb')as stderr:p=subprocess.run(list(map(str,args)),cwd=R,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',TSX_DISABLE_CACHE='1'),stdout=stdout,stderr=stderr)
 result={'argv':list(map(str,args)),'startedUTC':started,'completedUTC':datetime.now(timezone.utc).isoformat(),'exitCode':p.returncode,'stdout':bind(out),'stderr':bind(err),'actualAdoptedOneViewDelta':True,'actualProductionSourcesReadonly':True,'learnerOrConsentWrites':False};write(n+'.execution.actual.json',result)
 print(n,p.returncode,flush=True)
 if p.returncode:print(err.read_text()[-4000:],flush=True);raise SystemExit(p.returncode)
for p in [R/'.git/index',R/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json',R/'curricula/DE/Gymnasium/composition-views/mathematik/de-bw-seki.view.json']:
 try:
  with p.open('ab')as f:f.write(b'')
  raise AssertionError('Source unexpectedly writable')
 except OSError as e:assert e.errno==30,(str(p),e.errno)
loader=R/'app/node_modules/tsx/dist/loader.mjs'
run('frontend-targets',[N,'--import',loader,O/'check-view-targets.mts'])
run('normal-composition-views',[N,'--import',loader,R/'app/scripts/validateCompositionViews.ts'])
run('normal-math-scope-coverage',[N,'--import',loader,R/'app/scripts/reportCanonicalMathScopeCoverage.ts'])
run('normal-source-coverage',[N,'--import',loader,R/'app/scripts/generateCurriculumSourceCoverageAudit.ts','--check'])
cache=read(A/'verified-production-cache-bindings.actual.json')
for row in [*cache['productionSources'],*cache['productionClassFiles'],*cache['dependencyJars']]:
 p=Path(row['path'])if Path(row['path']).is_absolute()else R/row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'].removeprefix('sha256:')
classes=O/'harness-classes';classes.mkdir();classpath=str(B/'production-classes')+':'+':'.join(r['path']for r in cache['dependencyJars'])
run('fresh-two-harness-javac',[J/'javac','-encoding','UTF-8','-cp',classpath,'-d',classes,O/'AdoptedNativeAudit.java',O/'CurrentFortyMathOnlyRouteAudit.java'])
classpath=str(classes)+':'+classpath
run('native-two-projections',[J/'java','-Xmx3g','-cp',classpath,'AdoptedNativeAudit',R,O])
run('native-single-Math-route',[J/'java','-Xmx3g','-cp',classpath,'CurrentFortyMathOnlyRouteAudit',R,O])
before={p['key']:p for p in read(A/'native-learner-projections.actual.json')};after=read(O/'native-learner-projections.actual.json');assert len(after)==2
mid='57fbbf31-9b8c-5408-9af5-fbc73acd12bb'
for row in after:
 old=before[row['key']];assert not row.get('nativeProjectionError')
 expected=set(old['targetGoalIds'])|({mid}if not row['physicsOnly']else set())
 assert set(row['targetGoalIds'])==expected
 assert set(row['compositionViewIds'])==set(old['compositionViewIds'])
 if row['physicsOnly']:assert mid not in row['targetGoalIds']
plan=read(O/'native-empty-Math-ordered-frontier-plans.actual.json');assert len(plan)==1
assert plan[0]['mathGoalId']=='7c978529-ce62-5adc-897f-24ea80babbc8'
assert plan[0]['completeEmptySyntheticMathFrontierRoute']and not plan[0]['missingTargetAtomicMathIds']and not plan[0]['remainingUnlearnableAtomicIds']
write('CANDIDATE-TECHNICAL-RESULT.actual.json',{'actualTwoBWPhysicsConfigurations':2,'PhysicsOnlyOriginalTargetUniverseExact':True,'MathSelectedOnlyAddsExisting57Target':True,'allOriginalPhysicsTargetsExact':True,'actualNativeMathRouteFromEmptyComplete':True,'nativeRoute':plan[0],'normalThreeOwningCLIsZero':True,'sourceGateOrProductCodeChanged':False,'sourceAndTargetScientificPeerAlreadySealed':True,'actualConsentPersistenceOrLearnerWrites':False,'RootAdopted':True})
print('One-view candidate normal checks and native targeted route pass.',flush=True)
