// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict'
import {readFileSync,writeFileSync} from 'node:fs'
import {normalizeCanonicalLandscape} from '../../../app/src/utils/authoring/canonicalAuthoring'
import {normalizeCompositionView,collectCompositionProjectionRoleGoalIds,compileCompositionView} from '../../../app/src/utils/authoring/compositionViewAuthoring'
const root='/home/enpasos/projects/skillpilot',base=root+'/tmp/cross-subject-requires/bw-seki-volume-units-target-omission-author-root-20261016-v1'
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'))
const math=normalizeCanonicalLandscape(read(root+'/curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'))
const physics=normalizeCanonicalLandscape(read(root+'/curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'))
const by=new Map([...math.goals,...physics.goals].map(g=>[g.id,g]))
const roots=new Map([math,physics].map(l=>[l.landscapeId,l.goals.find(g=>g.tags?.includes('root'))!.id]))
const before=normalizeCompositionView(read(base+'/de-bw-seki.view.original.json')),candidate=normalizeCompositionView(read(root+'/curricula/DE/Gymnasium/composition-views/mathematik/de-bw-seki.view.json'))
assert.deepEqual(candidate.scope,before.scope)
const roles=(v:typeof candidate)=>collectCompositionProjectionRoleGoalIds(v.rootNodes,by,roots)
const a=roles(before),b=roles(candidate),id='57fbbf31-9b8c-5408-9af5-fbc73acd12bb'
assert(!a.targetGoalIds.has(id));assert(b.targetGoalIds.has(id))
assert.deepEqual([...b.targetGoalIds].sort(),[...a.targetGoalIds,id].sort())
assert.deepEqual([...b.prerequisiteOnlyGoalIds].sort(),[...a.prerequisiteOnlyGoalIds].sort())
const compiled=compileCompositionView(candidate,math,{landscapeId:'joint',title:'joint',goals:[...math.goals,...physics.goals]},new Map([math,physics].map(l=>[l.landscapeId,l])))
assert.deepEqual(compiled.findings.filter(f=>f.severity==='error'),[])
const result={actualProductionRoleCompiler:true,scopeUnchanged:true,beforeTargetCount:a.targetGoalIds.size,afterTargetCount:b.targetGoalIds.size,onlyAddedTarget:id,supportSetUnchanged:true,compilationErrors:0,originalPhysicsTargetsUnaffected:true,learnerOrConsentWrites:false}
writeFileSync(base+'/frontend-target-comparison.actual.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
