"""Use actual complete Root source with this lane as the only writable path.
SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
import hashlib,subprocess,sys
R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent
B=R/'tmp/ci-tools/hermetic-consumer-tools-20261015-v1/root/usr/bin/bwrap'
assert Path.cwd().resolve()==O and O.resolve()==O
assert hashlib.sha256(B.read_bytes()).hexdigest()=='e318903862396f96de3df57264e0158682b952fd3fb53ac23d876413e7b30f71'
import json
mounts=[]
for row in json.loads((O/'GENERATED-STATUS-MOUNT-PLAN.actual.json').read_text()):mounts+=['--bind',str(R/row['ownBacking']),str(R/row['target'])]
argv=[str(B),'--die-with-parent','--new-session','--unshare-user','--unshare-pid','--unshare-ipc','--unshare-uts','--unshare-net','--cap-drop','ALL','--ro-bind','/','/','--bind',str(O),str(O),*mounts,'--tmpfs','/tmp','--proc','/proc','--dev','/dev','--chdir',str(O),'--',*sys.argv[1:]]
raise SystemExit(subprocess.run(argv).returncode)
