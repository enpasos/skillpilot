from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,os
R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent;N=R/'tmp/ci-tools/node-v20.20.2-linux-x64/bin/node'
def b(p):
 raw=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(raw),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()}
results=[]
for label,name,args in [('generate-source-audit','generateCurriculumSourceCoverageAudit.ts',[]),('generate-full21-quality-status','generateCurriculumQualityStatus.ts',[]),('check-generated-source-audit','generateCurriculumSourceCoverageAudit.ts',['--check']),('check-generated-full21-quality-status','generateCurriculumQualityStatus.ts',['--check']),('actual-ten-protected-floors','checkCurriculumMaturityFloors.ts',[]),('actual-inventory-check','generateCrossSubjectRequiresInventory.ts',['--check'])]:
 argv=[str(N),'--import',str(R/'app/node_modules/tsx/dist/loader.mjs'),str(R/'app/scripts'/name),*args];out=O/(label+'.stdout.txt');err=O/(label+'.stderr.txt');start=datetime.now(timezone.utc).isoformat()
 with out.open('xb')as stdout,err.open('xb')as stderr:p=subprocess.run(argv,cwd=R/'app',env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',TSX_DISABLE_CACHE='1'),stdout=stdout,stderr=stderr)
 result={'label':label,'argv':argv,'startedUTC':start,'completedUTC':datetime.now(timezone.utc).isoformat(),'exitCode':p.returncode,'stdout':b(out),'stderr':b(err),'actualRootAdoptedView':True,'onlyDefaultStatusOutputsPrivate':True};(O/(label+'.execution.actual.json')).write_text(json.dumps(result,indent=2)+'\n');results.append(result);print(label,p.returncode,flush=True)
 if p.returncode:print(err.read_text()[-4000:]);raise SystemExit(p.returncode)
(O/'ACTUAL-NORMAL-GENERATION-CHECKS.actual.json').write_text(json.dumps({'results':results,'allPass':True,'sourceOrVerifierChanged':False,'finalFullCIClaimed':False},indent=2)+'\n')
