/* SPDX-License-Identifier: Apache-2.0 */
import com.skillpilot.backend.landscape.*;
import com.skillpilot.backend.service.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import org.springframework.transaction.*;

/** Pure native projection/frontier simulation. Synthetic estimates only, no learner. */
public class CurrentFortyMathOnlyRouteAudit {
 @SuppressWarnings("unchecked") public static void main(String[] args)throws Exception {
  Path root=Path.of(args[0]),base=Path.of(args[1]);var mapper=new AdoptedNativeAudit.BindingMapper(root);
  LandscapeProperties props=new LandscapeProperties();props.setDirectory(root.resolve("curricula").toString());
  GoalMappingService mappings=new GoalMappingService(props,mapper);LandscapeService landscapes=new LandscapeService(props,mapper,mappings);
  Map<String,LearningGoal> globals=new LinkedHashMap<>();Map<String,List<String>> contains=new LinkedHashMap<>();Set<String> mathIds=new LinkedHashSet<>(),physicsIds=new LinkedHashSet<>();
  for(String lid:List.of(AdoptedNativeAudit.MATH,AdoptedNativeAudit.PHYSICS))for(LearningGoal g:landscapes.getById(lid).getGoals()){globals.put(g.getId(),g);contains.put(g.getId(),g.getContains()==null?List.of():g.getContains());(lid.equals(AdoptedNativeAudit.MATH)?mathIds:physicsIds).add(g.getId());}
  CompositionViewService views=new CompositionViewService(props,mapper,()->contains);
  PlatformTransactionManager forbidden=new PlatformTransactionManager(){public TransactionStatus getTransaction(TransactionDefinition d){throw new IllegalStateException("No audit transactions");}public void commit(TransactionStatus s){throw new IllegalStateException("No audit commit");}public void rollback(TransactionStatus s){throw new IllegalStateException("No audit rollback");}};
  LearnerService service=new LearnerService(null,null,null,null,landscapes,mappings,null,views,mapper,null,forbidden);
  Method project=LearnerService.class.getDeclaredMethod("computeGoalProjection",String.class,String.class,boolean.class);project.setAccessible(true);
  Method mastery=LearnerService.class.getDeclaredMethod("computeEffectivePrereqMastery",String.class,Map.class,Map.class,Map.class,Set.class);mastery.setAccessible(true);
  Method effective=LearnerService.class.getDeclaredMethod("computeEffectiveRequires",Map.class);effective.setAccessible(true);
  Map<String,List<String>> requirements=(Map<String,List<String>>)effective.invoke(service,globals);
  var routes=mapper.readValue(base.resolve("all29-Math-learning-route-contexts.actual.json").toFile(),AdoptedNativeAudit.ROWS);
  List<Map<String,Object>> configurations=new ArrayList<>(),plans=new ArrayList<>();int done=0,checks=0;
  for(var config:mapper.readValue(base.resolve("Math-only-detour-configurations.prepared.json").toFile(),AdoptedNativeAudit.ROWS)){
   Object projection=project.invoke(service,AdoptedNativeAudit.ROOT_ID,mapper.writeValueAsString(config.get("personalCurriculum")),false);
   Set<String> targets=(Set<String>)AdoptedNativeAudit.value(projection,"targetGoalIds");Map<String,LearningGoal> lookup=(Map<String,LearningGoal>)AdoptedNativeAudit.value(projection,"structuralGoals");
   if(targets.stream().anyMatch(physicsIds::contains))throw new IllegalStateException("Explicit Math-only configuration exposes Physics target");
   Method check=LearnerService.class.getDeclaredMethod("checkPrerequisite",LearningGoal.class,String.class,projection.getClass(),Map.class,Map.class,boolean.class,Set.class);check.setAccessible(true);
   var configRow=new LinkedHashMap<String,Object>(config);configRow.put("targetGoalIds",targets);configRow.put("prerequisiteOnlyGoalIds",AdoptedNativeAudit.value(projection,"prerequisiteOnlyGoalIds"));configRow.put("compositionViewIds",AdoptedNativeAudit.value(projection,"compositionViewIds"));configRow.put("PhysicsTargets",0);configurations.add(configRow);
   for(var route:routes){
    String guard=(String)route.get("mathGoalId");List<String> atoms=(List<String>)route.get("atomicLearningGoalIds");var remaining=new LinkedHashSet<String>(atoms);List<String> missing=atoms.stream().filter(id->!targets.contains(id)).toList();
    Map<String,Double> simulated=new LinkedHashMap<>();List<String> ordered=new ArrayList<>();boolean progress;
    do{progress=false;for(String atom:new ArrayList<>(remaining)){
     if(!targets.contains(atom))continue;LearningGoal goal=lookup.get(atom);if(goal==null)throw new IllegalStateException("Target has no native definition "+atom);
     boolean ready=true;Map<String,Double> readiness=new HashMap<>();
     for(String ref:requirements.getOrDefault(atom,List.of())){String rid=ref.substring(ref.lastIndexOf(':')+1);if(!mathIds.contains(rid))throw new IllegalStateException("Math requires foreign subject "+rid);readiness.put(rid,(double)mastery.invoke(service,rid,globals,simulated,new HashMap<>(),new HashSet<>()));}
     for(String ref:requirements.getOrDefault(atom,List.of())){checks++;Object result=check.invoke(service,goal,ref,projection,lookup,readiness,false,new HashSet<>(atoms));if(!(boolean)AdoptedNativeAudit.value(result,"met")){ready=false;break;}}
     if(ready){simulated.put(atom,1.0);ordered.add(atom);remaining.remove(atom);progress=true;}
    }}while(progress&&!remaining.isEmpty());
    double value=(double)mastery.invoke(service,guard,globals,simulated,new HashMap<>(),new HashSet<>());boolean complete=missing.isEmpty()&&remaining.isEmpty()&&value>=0.9;
    Map<String,Object> row=new LinkedHashMap<>();row.put("configurationKey",config.get("key"));row.put("mathGoalId",guard);row.put("completeEmptySyntheticMathFrontierRoute",complete);row.put("missingTargetAtomicMathIds",missing);row.put("orderedHypotheticallyLearnableAtomicIds",ordered);row.put("remainingUnlearnableAtomicIds",new ArrayList<>(remaining));row.put("nativeGuardReadinessAfterOrderedSyntheticCompletions",value);row.put("startingSyntheticMasteryEntries",0);row.put("noNonRouteEstimatesIntroduced",true);row.put("nativeMethods",List.of("computeGoalProjection","computeEffectiveRequires","computeEffectivePrereqMastery","checkPrerequisite"));row.put("actualLearningMasteryPersistenceOrConsent",false);plans.add(row);
   }
   if(++done%40==0)System.out.println("Explicit Math-only projections/frontier simulations "+done);
  }
  mapper.verify();AdoptedNativeAudit.write(mapper,base,"native-Math-only-projections.actual.json",configurations);AdoptedNativeAudit.write(mapper,base,"native-empty-Math-ordered-frontier-plans.actual.json",plans);AdoptedNativeAudit.write(mapper,base,"native-Math-only-read-inputs.actual.json",mapper.bindings.values());
  AdoptedNativeAudit.write(mapper,base,"native-Math-only-ordered-frontier-summary.actual.json",Map.of("explicitMathOnlyConfigurations",configurations.size(),"nativeFromEmptySyntheticPlans",plans.size(),"nativePrerequisiteChecks",checks,"completePlans",plans.stream().filter(r->Boolean.TRUE.equals(r.get("completeEmptySyntheticMathFrontierRoute"))).count(),"actualStartingMasteryEntries",0,"syntheticCompletionNotHumanLearningEvidence",true,"learnerStateConsentRepositoriesTransactions",0));
  System.out.println("Math-only native plans "+plans.size()+", prerequisite checks "+checks+"; no learners/consent/persistence.");
 }
}
