import {buildAudit} from '../../../app/scripts/generateCurriculumSourceCoverageAudit'
import {writeFileSync} from 'node:fs'
const audit=await buildAudit();writeFileSync(new URL('./baseline-source-before-BW.actual.json',import.meta.url),JSON.stringify(audit,null,2)+'\n',{flag:'wx'});console.log('Actual owning source audit builder completed for exact pre-BW view baseline; all other actual Root source unchanged.')
