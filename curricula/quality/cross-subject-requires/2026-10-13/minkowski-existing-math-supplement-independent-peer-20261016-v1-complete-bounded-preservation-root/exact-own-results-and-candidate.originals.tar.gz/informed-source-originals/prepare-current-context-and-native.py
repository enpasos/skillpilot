"""Read current native context for an inactive, existing-goal supplement.
SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
B = R / 'tmp/cross-subject-requires/current45-current-root-fresh-native-route-replay-root-20261015-v1'
J = R / 'tmp/ci-tools/amazon-corretto-25.0.2.10.1/bin'
N = R / 'tmp/ci-tools/node-v20.20.2-linux-x64/bin/node'

def bind(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(R)), 'bytes': len(raw), 'sha256': 'sha256:' + hashlib.sha256(raw).hexdigest()}

def read(path):
    return json.loads(path.read_bytes())

def write(name, data):
    with (O / name).open('x') as f:
        f.write(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

def run(label, argv):
    stdout_path, stderr_path = O / (label + '.stdout.txt'), O / (label + '.stderr.txt')
    started = datetime.now(timezone.utc).isoformat()
    env = dict(os.environ, PATH=str(N.parent) + ':' + str(J) + ':' + os.environ['PATH'], TMPDIR='/tmp', TSX_DISABLE_CACHE='1', GIT_OPTIONAL_LOCKS='0')
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        result = subprocess.run([str(x) for x in argv], cwd=R, env=env, stdout=stdout, stderr=stderr)
    receipt = {'startedUTC': started, 'completedUTC': datetime.now(timezone.utc).isoformat(),
               'argv': [str(x) for x in argv], 'exitCode': result.returncode,
               'stdout': bind(stdout_path), 'stderr': bind(stderr_path),
               'RootReadonly': True, 'sourceOverlays': [], 'TMPDIR': '/tmp'}
    write(label + '.execution.actual.json', receipt)
    print(label, result.returncode, flush=True)
    if result.returncode:
        print(stderr_path.read_text()[-5000:], flush=True)
        raise SystemExit(result.returncode)
    return receipt

assert os.statvfs(R).f_flag & os.ST_RDONLY
source_rows = read(B / 'current-production-java-inputs.actual.json')
class_rows = read(B / 'fresh-current-production-classes.actual.json')
jars = read(B / 'actual-dependency-jars.actual.json')
assert len(source_rows) == 452 and len(class_rows) == 884 and len(jars) == 161
assert {str(p.relative_to(R)) for p in (R / 'backend/src/main/java').rglob('*.java')} == {r['path'] for r in source_rows}
assert {str(p.relative_to(R)) for p in (B / 'production-classes').rglob('*.class')} == {r['path'] for r in class_rows}
for row in [*source_rows, *class_rows, *jars]:
    p = Path(row['path']) if Path(row['path']).is_absolute() else R / row['path']
    raw = p.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['sha256'].removeprefix('sha256:')
write('VERIFIED-CURRENT-PRODUCTION-CACHE.actual.json', {
    'productionSources': bind(B / 'current-production-java-inputs.actual.json'),
    'classes': bind(B / 'fresh-current-production-classes.actual.json'),
    'jars': bind(B / 'actual-dependency-jars.actual.json'),
    'currentSourceSetExact': 452, 'classSetExact': 884, 'dependencyJarCount': 161,
    'freshProductionJavac': False,
})
classpath = str(B / 'production-classes') + ':' + ':'.join(row['path'] for row in jars)
(O / 'harness-classes').mkdir()
run('fresh-context-harness-javac', [J / 'javac', '-cp', classpath, '-d', O / 'harness-classes', O / 'ExistingPreparationContext.java'])
run('actual-scope-and-runtime-goals', [J / 'java', '-Xmx3g', '-cp', str(O / 'harness-classes') + ':' + classpath, 'ExistingPreparationContext', R, O])
run('actual-registered-native-admission', [N, R / 'app/scripts/runCompositionSupplementNativeAcceptance.cjs'])
envelope = read(O / 'actual-registered-native-admission.stdout.txt')
assert envelope['receipt']['producerContract'] == 'registered-gymnasium-native-acceptance-v2'
write('CURRENT-NATIVE-ADMISSION-SUMMARY.actual.json', {
    'receiptSha256': envelope['receiptSha256'],
    'actualRegisteredEnvelope': bind(O / 'actual-registered-native-admission.stdout.txt'),
    'ordinaryAcceptedGoals': len(envelope['receipt']['goals']),
    'currentGoalIds': sorted(g for g in envelope['receipt']['goals'] if g in ['25593605-5e13-55cc-9a05-8f3d737e15e9', '6ebb6182-f221-5f4c-b112-4ac72b104321']),
    'realNativeProducerNotAuthoredReceipt': True,
    'supplementOrSourceReviewAcceptedByNativeRun': False,
})
for row in read(O / 'PROTECTED-AND-SOURCE-INPUTS.before.actual.json'):
    assert bind(R / row['path']) == row
print('Current actual scope/runtime context and real registered native admission complete.', flush=True)
