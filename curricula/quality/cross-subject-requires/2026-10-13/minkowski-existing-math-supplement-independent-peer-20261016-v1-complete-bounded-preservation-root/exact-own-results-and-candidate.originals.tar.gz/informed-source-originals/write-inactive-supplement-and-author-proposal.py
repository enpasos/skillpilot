"""Create an actual inactive supplement plus a truthful author-only review proposal.
SPDX-License-Identifier: Apache-2.0
Own didactic content: CC-BY-4.0, attribution SkillPilot.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json

R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent
M='68a8ac50-f5f5-4e24-8aa9-5e408ca01ced';P='7f6fc60c-9fcc-4cc2-b07e-f897a1d0338a'
CONTENT='25593605-5e13-55cc-9a05-8f3d737e15e9';ORI='65365dce-f33f-49d8-9516-42f75883aa86';PHYS='6ebb6182-f221-5f4c-b112-4ac72b104321'
prefix='DE/Gymnasium/quality/cross-subject-requires/2026-10-16/minkowski-coordinate-preparation-v1'
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def bind(p):
 raw=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(raw),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()}
def write(p,d):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x')as f:f.write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
context=json.loads((O/'ACTUAL-SCOPE-AND-RUNTIME-GOALS.actual.json').read_text())
native=json.loads((O/'ACTUAL-REGISTERED-PUBLIC-NATIVE-GOAL-AND-ORIENTATION-BINDINGS.actual.json').read_text())
scope=context['requestedExplicitMathScope'];assert scope==context['requestedExplicitPhysicsScope']
assert PHYS in context['actualPhysicsTargetGoalIds']
for owner in [M,P]:assert any(s['landscapeId']==owner and s['strictCompletionReady'] and not s['issues'] for s in native['actualRegisteredNativeSnapshot']['receipt']['report']['subjects'])
supplement={'$schema':'https://skillpilot.com/schemas/composition-supplement/v1/composition-supplement.schema.json',
 'supplementFormatVersion':'1.0','supplementId':'he-g9-sekii-gk-minkowski-coordinates-v1','landscapeId':M,'language':'de',
 'label':'Koordinaten für Raumzeitdiagramme','labelEn':'Coordinates for spacetime diagrams',
 'scope':scope,'compatibleBaseViewIds':[context['actualMathView']['viewId']],
 'rootNodes':[{'kind':'structure','id':'minkowski-coordinate-preparation','label':'Koordinaten für Raumzeitdiagramme',
  'children':[{'kind':'goalEntry','goalId':ORI,'projectionRole':'target'},{'kind':'goalEntry','goalId':CONTENT,'projectionRole':'target'}]}],
 'reviewPath':prefix+'/accepted-inference-review.json'}
path=O/'candidate/curricula/DE/Gymnasium/composition-supplements/mathematik/he-g9-sekii-gk-minkowski-coordinates-v1.supplement.json'
write(path,supplement)
source=R/'curricula/DE/Gymnasium/input/HE/upper-secondary/source-extraction/DE_HE_PHYSIK_SEKII_KC2024.source-extraction.json'
extraction=json.loads(source.read_text());sourceBinding={'sourceId':extraction['extractionId'],'subject':'Physics','edition':'KC Physik gymnasiale Oberstufe, Ausgabe 2024',
 'cohort':'Gymnasiale Oberstufe nach KC2024; konkret ausgewähltes GK-Themenfeld Q4.4; keine Aussage zu einem einzelnen Abiturjahrgang',
 'anchor':'Q4.4 Spezielle Relativitätstheorie, gedruckte Seite46: Minkowski-Diagramme unter grundlegendes Niveau (GK und LK)',
 'officialUrl':extraction['sourceDocument']['url'],'retainedEvidence':{'path':str(source.relative_to(R/'curricula')),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}}
authorizations=[{'goalId':ORI,'classification':'reviewed-mathematics-orientation-preparation','regularMathematicsSourceCoverageClaim':False,
 'physicsDependentGoalIds':[PHYS],'decision':'accepted','orientationRationale':'Die bestehende Mathematik-Orientierung eröffnet einen persönlichen Zugang zur Bedeutung verständlicher Darstellungen. Sie dient der Motivation vor der Koordinatenvorbereitung; sie prüft weder Vorwissen noch Rechnen und bestätigt keine mathematische Beherrschung.',
 'completionContract':'orientation-binary-completion-v1'},
 {'goalId':CONTENT,'classification':'reviewed-didactic-mathematics-supplement-motivated-by-physics','regularMathematicsSourceCoverageClaim':False,
 'physicsDependentGoalIds':[PHYS],'decision':'accepted',
 'mandatoryOperation':'Aus frischen Ereigniskoordinaten unabhängig Punktlagen in einem konsistent skalierten x/ct-System konstruieren und daraus die verlangten Welt- und Gleichzeitigkeitslinien darstellen; Ereignisse, begrenztes Zeichnungsfenster und Modellfortsetzung auseinanderhalten.',
 'mathematicalInference':'Das geordnete Koordinatenpaar legt eine Punktlage fest. Aus zwei passenden Punkten wird ein linearer geometrischer Träger konstruiert; dessen Modellfortsetzung endet nicht an den gewählten Punkten oder am Bildrand. Dies ist die ganze Darstellungskompetenz255936 einschließlich Punktlage, Skala sowie Strecke/Gerade; Raumzeitinterpretation und Gleichzeitigkeit werden erst in Physik gelernt.',
 'inputAvailability':{'mode':'supplied','decision':'accepted','rationale':'Die aktuelle vollständige Physik-P gibt x/ct-Konvention, gleiche Längenskalen und die jeweilige Gleichzeitigkeitsfamilie ct=±0,5x ausdrücklich vor. Sie gibt kein fertig konstruiertes frisches Diagramm vor. Die mathematischen Konstruktionsoperationen müssen bereits verfügbar sein; eine Lorentzherleitung wird dadurch nicht als neue Voraussetzung erfunden.'},
 'wholePerformanceAlternatives':'Ein fertiges Diagramm nur zu lesen erfüllt die ganze Physik-P nicht: beide Fälle verlangen eigene Konstruktionen aus Ereignis-/Bewegungsangaben beziehungsweise ein selbst erzeugtes Ereignispaar. Rechnerisches Vergleichen kann die eigenständige diagrammatische Konstruktion ergänzen, ersetzt sie aber nicht. Weitere mögliche Mathematikbedarfe werden nicht durch dieses Supplement oder durch Graph-Erreichbarkeit als beherrscht erklärt.',
 'minimality':'Das Supplement enthält ausschließlich255936 und dessen bestehende typisierte Orientierungs-Voraussetzung. Es wählt das gesamte Mathematikfach nicht aus. Beide vollständigen Mathematik-P-Fälle und eine neue Skalen-/Objektvariation sind gesondert gelöst; Segment-/Geradenfortsetzung wird nicht aus dem Profil gestrichen. Die wissenschaftliche Autorbegründung zur ganzen Kompetenz bleibt bis zur eigenen unabhängigen Gegenprüfung eine Autorposition.'}]
proposal={'contract':'inactive-author-only-didactic-supplement-proposal-v1','createdUTC':datetime.now(timezone.utc).isoformat(),
 'status':'AUTHOR_SUPPORT_ONLY; distinct independent scientific/source/scope review pending; no accepted joint inference review exists',
 'supplement':bind(path),'supplementSha256':digest(supplement),'ownerLandscapeId':M,'authorId':'root-minkowski-preparation-author-20261016-v1',
 'scope':scope,'compatibleBaseViewIds':supplement['compatibleBaseViewIds'],
 'mathGoalBindings':native['mathGoalBindings'],'mathTeachingClosureSha256':native['mathTeachingClosureSha256'],
 'baseViewBindings':[{'viewId':context['actualMathView']['viewId'],'viewSha256':digest(context['actualMathView'])}],
 'physicsContext':{'landscapeId':P,'viewId':context['actualPhysicsView']['viewId'],'viewSha256':digest(context['actualPhysicsView']),'scope':scope},
 'physicsGoalBindings':native['physicsGoalBindings'],'sourceBindings':[sourceBinding],'targetAuthorizations':authorizations,
 'nativeEnvelopeSha256':native['actualRegisteredNativeSnapshot']['receiptSha256'],
 'realPublicNativeBindingReceipt':bind(O/'ACTUAL-REGISTERED-PUBLIC-NATIVE-GOAL-AND-ORIENTATION-BINDINGS.actual.json'),
 'authorScientificLock':bind(O/'OWN-SUBSTANTIVE-WHOLE-SUPPLEMENT-AUTHOR-LOCK.actual.json'),
 'noInventedReviewerOrAcceptedJointArtifact':True,'ordinaryMathSourceClaim':False,'RootRegistryChanged':False,'humanHostOrLearnerAcceptance':False}
write(O/'AUTHOR-ONLY-INACTIVE-DIDACTIC-REVIEW-PROPOSAL.actual.json',proposal)
print(json.dumps({'inactiveSupplement':bind(path),'authorProposal':bind(O/'AUTHOR-ONLY-INACTIVE-DIDACTIC-REVIEW-PROPOSAL.actual.json'),'jointAcceptance':False}),flush=True)
