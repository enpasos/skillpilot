"""Whole-profile case work and first independent-author opinion for preparation.
SPDX-License-Identifier: Apache-2.0
Own didactic case work: CC-BY-4.0, attribution SkillPilot.
"""
from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib
import json

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
M = '25593605-5e13-55cc-9a05-8f3d737e15e9'
ORIENTATION = '65365dce-f33f-49d8-9516-42f75883aa86'
P = '6ebb6182-f221-5f4c-b112-4ac72b104321'

def bind(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(R)), 'bytes': len(raw), 'sha256': 'sha256:' + hashlib.sha256(raw).hexdigest()}

def write(name, data):
    with (O / name).open('x') as f:
        f.write(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

lookup = json.loads((R / 'tmp/cross-subject-requires/current92-whole-integration-neutral-reader-root-20261016-v1/NEUTRAL-COMPLETE-MATH-PHYSICS-LOOKUP.actual.json').read_bytes())
current = {}
for subject in ['MATHEMATIK', 'PHYSIK']:
    current.update({g['id']: g for g in json.loads((R / f'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_{subject}.de.json').read_bytes())['goals']})
for goal_id in [M, ORIENTATION, P]:
    assert lookup[goal_id]['goal'] == current[goal_id]
contexts = {goal_id: lookup[goal_id] for goal_id in [M, ORIENTATION, P]}
write('WHOLE-CURRENT-GOAL-KIND-P-CONTEXTS.actual.json', contexts)

# Exact operations from both mandatory Physics cases and a fresh changed-speed
# example. q=ct-beta*x differs from ct' only by positive gamma, so q preserves
# simultaneity and ordering without interpreting the diagram as Euclidean space.
checks = []
def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({'check': label, 'actualExact': str(actual), 'expectedExact': str(expected)})

beta = F(1, 2)
q_a, q_b = F(0) - beta * -1, F(0) - beta * 1
check('first-case q(A)', q_a, F(1, 2))
check('first-case q(B)', q_b, F(-1, 2))
check('B is assigned earlier by moving-frame time', q_b < q_a, True)
check('rest-worldline x at arbitrary ct=4', F(0), F(0))
check('moving-worldline x at ct=4', beta * 4, F(2))
check('light worldlines at ct=4', (F(-4), F(4)), (F(-4), F(4)))
check('first-case same S-time', F(0), F(0))

beta2 = F(-1, 2)
a2, b2 = (F(-2), F(1)), (F(2), F(-1))
check('second-case A on moving simultaneity line', a2[1] - beta2 * a2[0], F(0))
check('second-case B on moving simultaneity line', b2[1] - beta2 * b2[0], F(0))
check('second-case S-time difference in length/c', b2[1] - a2[1], F(-2))
check('second-case reversed origin worldline at ct=4', beta2 * 4, F(-2))

beta3 = F(3, 5)
a3, b3 = (F(0), F(0)), (F(5), F(3))
check('fresh A simultaneity invariant', a3[1] - beta3 * a3[0], F(0))
check('fresh B simultaneity invariant', b3[1] - beta3 * b3[0], F(0))
check('fresh body-worldline point', beta3 * 5, F(3))
check('fresh S-time difference in length/c', b3[1] - a3[1], F(3))
check('fresh gamma squared', F(1) / (1 - beta3 * beta3), F(25, 16))

# Mandatory whole Mathematics P: scaled points plus BOTH finite segment and
# infinite line, followed by a new scale and new line/segment instructions.
check('Math case1 A in grid steps of2', (F(2, 2), F(6, 2)), (F(1), F(3)))
check('Math case1 B in grid steps of2', (F(8, 2), F(2, 2)), (F(4), F(1)))
check('Math case2 line slope CD', F(7 - 4, 5 - 1), F(3, 4))
check('Math case2 line intercept', F(4) - F(3, 4), F(13, 4))
check('Math case2 independently extended point', F(3, 4) * 9 + F(13, 4), F(10))
check('fresh unequal-axis physical point offsets', (F(6, 2), F(3, 1)), (F(3), F(3)))
check('fresh line through E(2,1),F(6,3)', F(3-1, 6-2), F(1, 2))

casework = {
    'authorId': 'root-minkowski-preparation-author-20261016-v1',
    'PhysicsWholeMandatoryCases': [
        {'caseId': 'draw-from-events', 'solution': 'Choose equal x/ct length scales. Plot A=(-1,0),B=(1,0). Draw rest x=0, moving origin x=0.5ct and light x=±ct. Through A and B draw supplied-family simultaneity lines ct=0.5x+k, k=+0.5 and -0.5 respectively. A and B are simultaneous in S, not in S-prime; positive-gamma frame time is ordered by q=ct-0.5x, so B is earlier. An inclined body worldline encodes changing x with time; it is not a diagonal spatial path.',
         'allExpectedOutputsAddressed': ['event plotting and consistent scale', 'rest/moving/light worldlines', 'given simultaneity convention applied', 'two frame simultaneity and ordering', 'spacetime vs spatial interpretation']},
        {'caseId': 'construct-simultaneous-pair-reversed-motion', 'solution': 'For supplied ct=-0.5x choose A=(-2,+1),B=(+2,-1); both have q=ct+0.5x=0 and are simultaneous in S-double-prime. The moving origin follows x=-0.5ct. In S, ct(B)-ct(A)=-2 length units, hence t(B)-t(A)=-2/c in corresponding time units, so B is earlier. Motion reversal changes both worldline and simultaneity inclinations consistently, without changing event identity.',
         'allExpectedOutputsAddressed': ['independently constructed events', 'reversed origin worldline', 'two-system time assignment', 'dimensionally correct time difference', 'consistent reversal and event identity']},
    ],
    'PhysicsFreshVariation': {'given': 'Change speed to +0.6c and supply simultaneity family ct=0.6x+k. Construct a pair simultaneous in the moving system with one event at the origin and another at x=5.',
        'solution': 'A=(0,0),B=(5,3) share k=0. Draw origin worldline x=0.6ct, e.g. through (3,5); keep both light rays x=±ct and equal axis length scales. A and B are simultaneous in the moving system but B is 3/c later in S. Their transformed times are gamma*(ct-0.6x)=0 with gamma=1.25. Replacing the axes by unrelated scales without correcting slopes would corrupt the supplied light convention.',
        'transfer': 'Changed speed, unequal event coordinates, nonzero S-time separation and construction from a new simultaneity family.'},
    'MathematicsWholeMandatoryCases': [
        {'caseId': 'points-and-segment', 'solution': 'For a grid unit worth2, A(2,6) lies1 grid step right and3 up; B(8,2) lies4 right and1 up. Join just the interval between the two marked endpoints. The endpoint condition defines a finite segment; adding continuation arrows would answer a different object instruction.'},
        {'caseId': 'points-and-line-transfer', 'solution': 'Choose a new suitable scale covering C(1,4),D(5,7). Plot x first and y second. The line has slope3/4 and intercept13/4; extend in both directions beyond C,D with continuation arrows. For example (9,10) lies on its continuation. C,D determine the line but do not terminate it.'},
    ],
    'MathematicsFreshVariation': {'given': 'Use horizontal grid steps worth2 and vertical steps worth1. Plot E(2,1),F(6,3); draw the finite EF segment and, separately, the complete line determined by E,F.',
        'solution': 'E has grid offsets(1,1),F(3,3); their physical slope is1/2 although equal visual grid offsets have slope1. Keep endpoints only for EF, and extend beyond both for the line. A later Minkowski task must use equal physical length scales on x,ct to infer its advertised light slopes; arbitrary display scaling does not change event coordinates.'},
    'orientation': {'goalId': ORIENTATION, 'semanticKind': 'orientation',
        'proposedPurpose': 'Invite an accessible link between reading a diagram and making space/time relationships understandable, with room for the learner\u2019s own interest or reaction.',
        'completion': 'Existing motivational conversation and separate accepted closure; binary completion marker only. No test, prior-knowledge quiz, calculation or subject-matter mastery certification.'},
    'numericChecks': checks,
    'notClaimed': ['real learner work or consent', 'new P/Kind/D/Source approval', 'complete prerequisite set for all Physics outputs', 'independent peer agreement'],
}
write('OWN-WHOLE-P-MANDATORY-AND-FRESH-CASEWORK.actual.json', casework)

opinion = {
    'lockedUTC': datetime.now(timezone.utc).isoformat(),
    'authorId': casework['authorId'], 'independentPeerSeen': False,
    'proposedSupplementTargets': [ORIENTATION, M],
    'exactIntendedMathAndPhysicsScope': {'schoolForm': 'Gymnasium', 'jurisdiction': 'DE-HE', 'stage': 'SekII', 'durationModel': 'G9', 'courseProfile': 'GK'},
    'PhysicsDependentGoalId': P,
    'wholeMathNecessityOpinion': 'AUTHOR SUPPORT: event placement from ordered pairs, independent scale handling and constructing the required rest/moving/light/simultaneity lines are reusable prior Mathematics. The bounded drawing window and chosen events must not be mistaken for endpoints of the model line; this is the same point/segment/line distinction assessed by whole255936. Physical interpretation, worldline identity and relativity of simultaneity remain new Physics. This support is submitted for distinct review, not treated as accepted agreement.',
    'alternativeAndMinimalityOpinion': 'The proposed bundle teaches only the current complete local Math closure of255936, plus its separately typed existing orientation. It does not enroll ordinary Mathematics. A supplied finished spacetime diagram does not meet the whole Physics P, which requires constructing fresh event/worldline diagrams. Supplied simultaneity equations remove a need to derive Lorentz transformations; they do not supply independent coordinate placement or line construction. Other arithmetic/sign preparation and the current Physics prerequisite19aef remain independent obligations: this two-target bundle does not certify the full Physics frontier or the complete cross-subject Requires set.',
    'regularMathematicsSourceCoverageClaim': False,
    'sourceOpinion': 'The locally rendered official KC Physik2024 printed46 places Minkowski diagrams within Q4.4 at grundlegendes Niveau (GK and LK). Selected-target presence and the exact requested HE/G9/SekII/GK scope must be proved with the actual learner view resolver. This authorizes a proposed Physics-motivated didactic preparation inference, not a claim that coordinate geometry is ordinary HE SekII Mathematics or that every course must select Q4.4.',
    'whyDifferentFromPendingFourFiveGoalProposal': 'The planned four/five-goal polygon bundles are conditional on whole-prerequisite necessity, now under independent8d30 review. This separate existing direct255936 Physics guard supports an actual independently reviewable authored supplement without prejudging that open polygon review. Remaining100 route gaps and thirteen new-goal gates remain in scope.',
    'casework': bind(O / 'OWN-WHOLE-P-MANDATORY-AND-FRESH-CASEWORK.actual.json'),
    'wholeContexts': bind(O / 'WHOLE-CURRENT-GOAL-KIND-P-CONTEXTS.actual.json'),
    'officialPageInspected': {'localSource': bind(R / 'curricula/DE/Gymnasium/input/HE/upper-secondary/kernkurriculum_gymnasiale_oberstufe-physik.pdf'), 'raster': bind(O / 'he-phys-kc2024-p46.png'), 'printedPage': 46, 'courseLevelReadFromPage': 'grundlegendes Niveau (Grundkurs und Leistungskurs)'},
    'pendingBeforeAdmission': ['distinct whole-goal and exact-source/scope reviewer', 'registered current native bindings including typed orientation', 'exact final schema-conforming accepted review artifact', 'actual selected supplement source QA with Math unselected/selected', 'actual explicit-offer, selection, persistence, return and stale-removal lifecycle'],
    'RootWritesOrNewAuthorization': False,
}
write('OWN-SUBSTANTIVE-WHOLE-SUPPLEMENT-AUTHOR-LOCK.actual.json', opinion)
print('Own whole casework locked; author proposal only, no independent acceptance.', flush=True)
