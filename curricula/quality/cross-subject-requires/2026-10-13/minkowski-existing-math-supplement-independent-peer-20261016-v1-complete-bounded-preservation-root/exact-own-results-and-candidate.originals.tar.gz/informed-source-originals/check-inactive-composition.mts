// SPDX-License-Identifier: Apache-2.0
import {readFileSync,writeFileSync} from 'node:fs'
import {resolve,dirname} from 'node:path'
import {fileURLToPath} from 'node:url'
import {normalizeCanonicalLandscape} from '../../../app/src/utils/authoring/canonicalAuthoring'
import {normalizeCompositionView,compileCompositionView} from '../../../app/src/utils/authoring/compositionViewAuthoring'

const O=dirname(fileURLToPath(import.meta.url)),R=resolve(O,'../../..')
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'))
const s=read(resolve(O,'candidate/curricula/DE/Gymnasium/composition-supplements/mathematik/he-g9-sekii-gk-minkowski-coordinates-v1.supplement.json'))
const math=read(resolve(R,'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'))
const physics=read(resolve(R,'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'))
const global={...math,goals:[...math.goals,...physics.goals]}
// This is the runtime view conversion from CompositionSupplementService, not an
// ordinary source offering or an admitted supplement.
const view={viewId:'supplement:'+s.supplementId,landscapeId:s.landscapeId,language:s.language,scope:s.scope,rootNodes:s.rootNodes}
const compiled=compileCompositionView(normalizeCompositionView(view),normalizeCanonicalLandscape(math),normalizeCanonicalLandscape(global))
const errors=compiled.findings.filter(f=>f.severity==='error')
if(errors.length)throw Error(JSON.stringify(errors))
writeFileSync(resolve(O,'INACTIVE-SUPPLEMENT-COMPOSITION-CHECK.actual.json'),JSON.stringify({
 actualCurrentCompiler:true,errors,findings:compiled.findings,
 scope:s.scope,targets:['25593605-5e13-55cc-9a05-8f3d737e15e9','65365dce-f33f-49d8-9516-42f75883aa86'],
 officialMathematicsSourceOrIndependentScientificApproval:false,
 runtimeSupplementAdmissionOrLearnerWrites:false,
},null,2)+'\n',{flag:'wx'})
console.log('Inactive runtime-shape supplement composition: zero compiler errors.')
