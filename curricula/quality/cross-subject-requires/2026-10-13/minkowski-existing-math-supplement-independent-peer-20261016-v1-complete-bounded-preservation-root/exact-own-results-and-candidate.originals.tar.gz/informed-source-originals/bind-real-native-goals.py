"""Reuse the verified driver for one public-native binding helper.
SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
import hashlib,json,os,subprocess
from datetime import datetime,timezone
R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent
B=R/'tmp/cross-subject-requires/current45-current-root-fresh-native-route-replay-root-20261015-v1'
J=R/'tmp/ci-tools/amazon-corretto-25.0.2.10.1/bin';N=R/'tmp/ci-tools/node-v20.20.2-linux-x64/bin/node'
def bind(p):
 b=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(b),'sha256':'sha256:'+hashlib.sha256(b).hexdigest()}
def run(label,argv):
 out=O/(label+'.stdout.txt');err=O/(label+'.stderr.txt');start=datetime.now(timezone.utc).isoformat()
 with out.open('xb') as stdout,err.open('xb') as stderr:
  p=subprocess.run([str(v) for v in argv],cwd=R,env=dict(os.environ,PATH=str(N.parent)+':'+str(J)+':'+os.environ['PATH'],TMPDIR='/tmp',TSX_DISABLE_CACHE='1'),stdout=stdout,stderr=stderr)
 receipt={'startedUTC':start,'completedUTC':datetime.now(timezone.utc).isoformat(),'argv':[str(v) for v in argv],'exitCode':p.returncode,'stdout':bind(out),'stderr':bind(err),'RootReadonly':True,'sourceOverlays':[],'TMPDIR':'/tmp'}
 with (O/(label+'.execution.actual.json')).open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
 print(label,p.returncode,flush=True)
 if p.returncode:print(err.read_text()[-6000:],flush=True);raise SystemExit(p.returncode)
assert os.statvfs(R).f_flag & os.ST_RDONLY
for n in ['current-production-java-inputs.actual.json','fresh-current-production-classes.actual.json','actual-dependency-jars.actual.json']:
 for row in json.loads((B/n).read_text()):
  p=Path(row['path']) if Path(row['path']).is_absolute() else R/row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'].removeprefix('sha256:')
jars=json.loads((B/'actual-dependency-jars.actual.json').read_text());cp=str(B/'production-classes')+':'+':'.join(r['path'] for r in jars)
run('fresh-public-binding-helper-javac',[J/'javac','-cp',cp,'-d',O/'harness-classes',O/'ExistingPreparationNativeBindings.java'])
run('actual-public-native-content-and-orientation-binding',[J/'java','-Xmx3g','-cp',str(O/'harness-classes')+':'+cp,'com.skillpilot.backend.service.ExistingPreparationNativeBindings',R,O])
