/* SPDX-License-Identifier: Apache-2.0 */
import com.fasterxml.jackson.databind.*;
import com.skillpilot.backend.landscape.*;
import com.skillpilot.backend.service.*;
import java.nio.file.*;
import java.util.*;

/** Production scope/Goal readers only. No repositories or learner writes. */
public final class ExistingPreparationContext {
    public static void main(String[] args) throws Exception {
        Path root=Path.of(args[0]), out=Path.of(args[1]);
        ObjectMapper mapper=new ObjectMapper();
        LandscapeProperties props=new LandscapeProperties(); props.setDirectory(root.resolve("curricula").toString());
        GoalMappingService mappings=new GoalMappingService(props,mapper);
        LandscapeService landscapes=new LandscapeService(props,mapper,mappings);
        Map<String,List<String>> contains=new LinkedHashMap<>();
        for(String owner:List.of(CompositionSupplementService.MATH,CompositionSupplementService.PHYSICS))
            for(LearningGoal g:landscapes.getById(owner).getGoals()) contains.put(g.getId(),g.getContains()==null?List.of():g.getContains());
        CompositionViewService views=new CompositionViewService(props,mapper,()->contains);
        Map<String,String> scope=Map.of("schoolForm","Gymnasium","jurisdiction","DE-HE","stage","SekII","durationModel","G9","courseProfile","GK");
        Map<String,Object> math=views.findLearnerScopeView(CompositionSupplementService.MATH,scope);
        Map<String,Object> physics=views.findLearnerScopeView(CompositionSupplementService.PHYSICS,scope);
        if(math==null||physics==null) throw new IllegalStateException("No exact reviewed learner anchor");
        Set<String> physicsTargets=views.resolvedTargetGoalIds(physics);
        if(!physicsTargets.contains("6ebb6182-f221-5f4c-b112-4ac72b104321")) throw new IllegalStateException("Minkowski is not a Physics target");
        Map<String,Object> goals=new LinkedHashMap<>();
        for(String id:List.of("25593605-5e13-55cc-9a05-8f3d737e15e9","65365dce-f33f-49d8-9516-42f75883aa86","6ebb6182-f221-5f4c-b112-4ac72b104321"))
            goals.put(id,landscapes.getGoalDefinition(id));
        Map<String,Object> result=new LinkedHashMap<>();
        result.put("requestedExplicitMathScope",scope); result.put("requestedExplicitPhysicsScope",scope);
        result.put("actualMathView",math); result.put("actualPhysicsView",physics);
        result.put("actualPhysicsTargetGoalIds",physicsTargets); result.put("runtimeGoalDefinitions",goals);
        result.put("actualFindLearnerScopeView",true); result.put("learnerOrMasteryOrConsentWrites",false);
        Path target=out.resolve("ACTUAL-SCOPE-AND-RUNTIME-GOALS.actual.json");
        if(Files.exists(target)) throw new IllegalStateException("Preserve original output");
        mapper.writerWithDefaultPrettyPrinter().writeValue(target.toFile(),result);
        System.out.println("Actual scope anchors: "+math.get("viewId")+" / "+physics.get("viewId")+"; Physics targets="+physicsTargets.size());
    }
}
