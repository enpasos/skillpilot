/* SPDX-License-Identifier: Apache-2.0 */
package com.skillpilot.backend.service;
import com.fasterxml.jackson.databind.*;
import com.skillpilot.backend.landscape.*;
import java.nio.file.*;
import java.util.*;

/** Read-only authoring helper using the actual registered acceptance methods. */
public final class ExistingPreparationNativeBindings {
    public static void main(String[] args) throws Exception {
        Path root=Path.of(args[0]), out=Path.of(args[1]);
        ObjectMapper mapper=new ObjectMapper();
        LandscapeProperties properties=new LandscapeProperties(); properties.setDirectory(root.resolve("curricula").toString());
        GoalMappingService mappings=new GoalMappingService(properties,mapper);
        LandscapeService landscapes=new LandscapeService(properties,mapper,mappings);
        RegisteredNativeSupplementAcceptance nativeGate=new RegisteredNativeSupplementAcceptance(root,mapper);
        CompositionSupplementService supplements=new CompositionSupplementService(properties,mapper,landscapes);
        List<String> targets=List.of("65365dce-f33f-49d8-9516-42f75883aa86","25593605-5e13-55cc-9a05-8f3d737e15e9");
        Map<String,Object> result=nativeGate.withSnapshot(()->{
            Map<String,Object> value=new LinkedHashMap<>(); List<Map<String,String>> bindings=new ArrayList<>();
            for(String id:targets) {
                LearningGoal goal=landscapes.getGoalDefinition(id);
                Map<String,String> binding=new LinkedHashMap<>();
                binding.put("goalId",id);binding.put("goalSha256",CompositionSupplementService.sha(mapper.valueToTree(goal)));
                boolean orientation=id.equals(targets.getFirst());
                binding.put("semanticKind",orientation?"orientation":"curricularAtomic");
                binding.put(orientation?"orientationContextBindingSha256":"nativeAcceptanceSha256",orientation?
                    nativeGate.requireOrientationAccepted(CompositionSupplementService.MATH,goal):nativeGate.requireAccepted(CompositionSupplementService.MATH,goal));
                bindings.add(binding);
            }
            LearningGoal physics=landscapes.getGoalDefinition("6ebb6182-f221-5f4c-b112-4ac72b104321");
            value.put("mathGoalBindings",bindings);
            value.put("physicsGoalBindings",List.of(Map.of("goalId",physics.getId(),"goalSha256",CompositionSupplementService.sha(mapper.valueToTree(physics)),
                "semanticKind","curricularAtomic","nativeAcceptanceSha256",nativeGate.requireAccepted(CompositionSupplementService.PHYSICS,physics))));
            value.put("mathTeachingClosureSha256",supplements.teachingClosureSha256(new LinkedHashSet<>(targets)));
            value.put("actualRegisteredNativeSnapshot",nativeGate.currentSnapshotForQa());
            value.put("orientationContexts",nativeGate.currentOrientationBindingsForQa());
            value.put("actualPublicRegisteredNativeMethods",true);
            value.put("authoredReceiptOrPermissiveTestGateUsed",false);
            value.put("supplementOrIndependentScientificAcceptanceClaimed",false);
            return value;
        });
        Path file=out.resolve("ACTUAL-REGISTERED-PUBLIC-NATIVE-GOAL-AND-ORIENTATION-BINDINGS.actual.json");
        if(Files.exists(file))throw new IllegalStateException("Preserve original");
        mapper.writerWithDefaultPrettyPrinter().writeValue(file.toFile(),result);
        System.out.println("Real registered native content/orientation bindings obtained; no supplement admitted.");
    }
}
