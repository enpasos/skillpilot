# SPDX-License-Identifier: Apache-2.0
# Standalone scientific coordinate diagrams, drawn from explicitly solved numeric data.
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,html,json
L=Path(__file__).resolve().parent;W,H=1260,960;im=Image.new('RGB',(W,H),'white');draw=ImageDraw.Draw(im);fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';font=ImageFont.truetype(fontpath,13);small=ImageFont.truetype(fontpath,11);titlefont=ImageFont.truetype(fontpath,15);svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1260" height="960" viewBox="0 0 1260 960"><rect width="1260" height="960" fill="white"/>']
def text(x,y,t,c='black',size=13):
 draw.text((x,y),t,fill=c,font=titlefont if size==15 else small if size==11 else font);svg.append(f'<text x="{x}" y="{y+size}" fill="{c}" font-family="DejaVu Sans,sans-serif" font-size="{size}">{html.escape(t)}</text>')
def line(p,q,c='black',width=1,arrow=False):
 draw.line([p,q],fill=c,width=width);svg.append(f'<line x1="{p[0]}" y1="{p[1]}" x2="{q[0]}" y2="{q[1]}" stroke="{c}" stroke-width="{width}"/>')
 if arrow:
  angle=math.atan2(q[1]-p[1],q[0]-p[0]);v=[q,(q[0]-8*math.cos(angle-.45),q[1]-8*math.sin(angle-.45)),(q[0]-8*math.cos(angle+.45),q[1]-8*math.sin(angle+.45))];draw.polygon(v,fill=c);svg.append('<polygon points="'+' '.join(f'{x},{y}' for x,y in v)+f'" fill="{c}"/>')
def panel(col,row,title,xlim,ylim,xt,yt,ratio=1,physics=False):
 left=col*420+48;top=row*440+95;availx=340;availy=310;sx=min(availx/(xlim[1]-xlim[0]),availy/(ratio*(ylim[1]-ylim[0])));sy=sx*ratio
 def p(x,y):return(left+(x-xlim[0])*sx,top+(ylim[1]-y)*sy)
 text(col*420+15,row*440+50,title,size=15)
 for x in range(int(xlim[0]),int(xlim[1])+1,xt):a=p(x,ylim[0]);b=p(x,ylim[1]);line(a,b,'#dddddd');text(a[0]-5,a[1]+4,str(x),size=11)
 for y in range(int(ylim[0]),int(ylim[1])+1,yt):a=p(xlim[0],y);b=p(xlim[1],y);line(a,b,'#dddddd');text(a[0]-27,a[1]-6,str(y),size=11)
 line(p(xlim[0],0),p(xlim[1],0),'#303030',1,True);line(p(0,ylim[0]),p(0,ylim[1]),'#303030',1,True);text(p(xlim[1],0)[0]-9,p(xlim[1],0)[1]+10,'x');text(p(0,ylim[1])[0]+7,p(0,ylim[1])[1]-18,'u=ct' if physics else 'y')
 def pt(v,n,c='black'):
  a=p(*v);draw.ellipse((a[0]-3,a[1]-3,a[0]+3,a[1]+3),fill=c);svg.append(f'<circle cx="{a[0]}" cy="{a[1]}" r="3" fill="{c}"/>');text(a[0]+5,a[1]-17,n+' '+str(v),c,size=11)
 def seg(v,w,c='#18657b'):line(p(*v),p(*w),c,2)
 def full(v,w,c='#18657b'):line(p(*v),p(*w),c,2,True);line(p(*w),p(*v),c,2,True)
 return pt,seg,full
text(18,8,'Own independent complete-case constructions: Math whole P and Minkowski whole P',size=15)
pt,seg,full=panel(0,0,'M1: scale 2; finite AB',(0,10),(0,10),2,2);pt((2,6),'A');pt((8,2),'B');seg((2,6),(8,2));text(20,440,'Endpoint marks; no extension past A or B.',size=11)
pt,seg,full=panel(1,0,'M2: changed scale 1; full CD',(0,10),(0,10),1,1);pt((1,4),'C');pt((5,7),'D');full((0,3.25),(8.8,9.85),'#753e95');text(440,440,'Both arrows; C and D are not endpoints.',size=11)
pt,seg,full=panel(2,0,'M3 fresh: signed, x-step4 / y-step2',(-8,12),(-6,6),4,2,2);pt((-4,2),'A');pt((8,-4),'B');seg((-4,2),(8,-4));pt((-4,-2),'C','#753e95');pt((4,2),'D','#753e95');full((-8,-4),(12,6),'#753e95');text(860,440,'Blue finite AB; purple unbounded CD.',size=11)
pt,seg,full=panel(0,1,'P1: beta +0.5; equal scales',(-3,3),(-3,3),1,1,physics=True);full((-3,-3),(3,3),'#aaaaaa');full((-3,3),(3,-3),'#aaaaaa');full((0,-3),(0,3),'#263f80');full((-1.5,-3),(1.5,3),'#18657b');full((-3,-1),(3,2),'#b74738');full((-3,-2),(3,1),'#9b601b');pt((-1,0),'A','#b74738');pt((1,0),'B','#9b601b');text(20,885,'Blue worldlines; red/brown S-prime time slices.',size=11);text(20,903,'Same S-time; S-prime assigns B earlier.',size=11)
pt,seg,full=panel(1,1,'P2: beta -0.5; equal scales',(-3,3),(-3,3),1,1,physics=True);full((-3,-3),(3,3),'#aaaaaa');full((-3,3),(3,-3),'#aaaaaa');full((-1.5,3),(1.5,-3),'#18657b');full((-3,1.5),(3,-1.5),'#b74738');pt((-2,1),'A');pt((2,-1),'B');text(440,885,'S-double-prime simultaneous: u=-0.5x.',size=11);text(440,903,'S: delta u=-2; B earlier by 2/c.',size=11)
pt,seg,full=panel(2,1,'P3 fresh: beta +0.25; shifted slice',(-5,5),(-2,5),1,1,physics=True);full((-2,-2),(5,5),'#aaaaaa');full((-5,5),(2,-2),'#aaaaaa');full((-.5,-2),(1.25,5),'#18657b');full((-5,-.25),(5,2.25),'#b74738');pt((-4,0),'A');pt((4,2),'B');pt((0,1),'Q','#b74738');text(860,885,'Red slice u=0.25x+1; same S-star time.',size=11);text(860,903,'S: delta u=+2; B later by 2/c.',size=11)
text(18,945,'Grey: straight light-line supports x=+/-ct. Event identity and spacetime meaning stay Physics.',size=13)
svg.append('</svg>');(L/'OWN-COMPLETE-MATH-PHYSICS-CASES.svg').write_text('\n'.join(svg)+'\n');im.save(L/'OWN-COMPLETE-MATH-PHYSICS-CASES.png');print('Own six complete numeric diagrams generated as SVG and PNG.')
