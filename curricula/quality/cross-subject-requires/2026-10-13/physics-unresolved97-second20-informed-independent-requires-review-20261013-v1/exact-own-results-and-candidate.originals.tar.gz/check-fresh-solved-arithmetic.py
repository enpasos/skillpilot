# SPDX-License-Identifier: Apache-2.0
import pathlib,json,math,datetime
out=pathlib.Path(__file__).resolve().parent
xs=json.loads((out/'forty-fresh-own-solved-countercases.actual.json').read_text())['probes'];assert len(xs)==40
checks=[]
def ck(n,k,e):
 a=xs[n-1]['calculatedResults'][k]
 def near(a,e):
  if isinstance(e,list):return len(a)==len(e)and all(near(v,w)for v,w in zip(a,e))
  return math.isclose(a,e,rel_tol=1e-10,abs_tol=1e-16)
 assert near(a,e),(n,k,a,e)
 checks.append({'probeId':xs[n-1]['probeId'],'quantity':k,'reported':a,'recomputedFromOwnGivenInputs':e,'pass':True})
ck(1,'single_V_m',6e-6/(2*3e-11));ck(2,'inside',(6e-6+4e-6)/(2*3e-11))
ck(3,'sum',[a+b for a,b in zip([1,2,4],[2,3,1])]);ck(4,'middleDifference',5-1)
ck(5,'atTau',50*(1-math.exp(-1)));ck(6,'atCommonTau',[v*(1-math.exp(-1))for v in[50,25,12.5]])
ck(7,'length_m',325/100);ck(8,'correctUnrequiredMinutes',1*60+25)
ck(9,'theta_arcmin',1.22*480e-9/.004*180/math.pi*60);ck(10,'ratioSecondToFirst',(720e-9/.006)/(480e-9/.004))
ck(11,'totals',[a+b for a,b in zip([-12,-8,-5],[10,5,3])]);ck(12,'changedTotal',-8+7)
ck(13,'hubbleGyr',3.086e19/((6270-2100)/(90-30))/3.156e7/1e9);ck(14,'tangentBackTime',1/(1.2/12))
ck(15,'orthogonalMomentum',math.hypot(511,511));ck(16,'invariantSquared',1080*1080-(580-500)**2)
ck(17,'lambdaMinRatio',25/50);ck(18,'ratioSigma2',((28-2)/(18-2))**2)
ck(19,'secondFrequency_Hz',1/(2*.001));ck(20,'pulseRMS_V',math.sqrt(.25*4**2+.75*0**2))
ck(21,'frequencies_Hz',[3e8/v for v in[.15,.003,.06]]);ck(22,'resolutionShortToLong',.4/.8)
ck(23,'delta_e',(2+2+2)/3);ck(24,'neutralSums_e',[2/3-2/3,-1/3+1/3])
ck(25,'netProtons',4*2+4*1-2*2);ck(26,'remaining_MeV',.026*931.5-.75)
ck(27,'frequencies_Hz',[n*3e8/(2*.6)for n in[1,2,3]]);ck(28,'nodeSpacing',math.pi/5)
ck(29,'densityIn_bSquared',[abs(v)**2 for v in[2,-2]]);ck(30,'probabilities',[(1*4)/(1*4+3*1),(3*1)/(1*4+3*1)])
ck(31,'P0',(1+math.cos(math.pi/2))/2);ck(32,'coherentP',[(1+math.cos(5*math.pi/3))/2,(1-math.cos(5*math.pi/3))/2])
R=.5*.3**3/(2e-7);P=4*math.pi**2*4e-5/(2*math.pi)**2
ck(33,'BH_T',math.sqrt(P/R));R2=.3*.2**3/1e-7;P2=4*math.pi**2*1.2e-5/math.pi**2;ck(34,'m',math.sqrt(P2*R2))
ck(35,'f_Hz',3e8/(520e-9));ck(36,'intensityFactor',2**2)
ck(37,'deltaPhi',4*math.pi*(3e-21*2000)/(1200e-9));ck(38,'maxDelay_ms',(1800000/3e8)*1000)
ck(39,'expectedA',.42*250);ck(40,'expectations',[.25*360,.75*360])
# Additional independent checks for symbolic identities and positive-root physical branches.
extra=[]
for x,t in[(.13,0),(.51,2e-10),(1.2,7e-10)]:
 lhs=math.sin(5*x-1.5e9*t)+math.sin(5*x+1.5e9*t);rhs=2*math.sin(5*x)*math.cos(1.5e9*t)
 assert math.isclose(lhs,rhs,rel_tol=1e-12,abs_tol=1e-12)
 extra.append({'x_m':x,'t_s':t,'sum':lhs,'product':rhs,'pass':True})
assert math.isclose(xs[32]['calculatedResults']['m']/xs[32]['calculatedResults']['BH_T'],R,rel_tol=1e-12)
assert math.isclose(xs[32]['calculatedResults']['m']*xs[32]['calculatedResults']['BH_T'],P,rel_tol=1e-12)
report={'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'probeCount':40,'actualQuantityChecks':len(checks),'allPass':True,'checks':checks,'additionalStandingWaveIdentityChecks':extra,'GaussPositiveRootRatioAndProductVerified':True,'movingAnnihilationEnergyMomentumPhysicalBoundChecked':1080**2-80**2>=1022**2,'scope':'Arithmetic/model checks of actual own solved cases only; not overall QA, experiment, empirical data, learner or Source/P/Kind/M7 authority.'}
(out/'fresh-solved-arithmetic.actual.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'probeCount':40,'actualQuantityChecks':len(checks),'allPass':True,'ownHubbleTimeGyr':xs[12]['calculatedResults']['hubbleGyr']}))
