# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,sys
O=Path(__file__).resolve().parent
a=json.loads((O/'all-claimed-whole-prerequisite-contexts.actual.json').read_text())
assigned={x['wholeGoal']['id']for x in json.loads((O/'twenty-complete-review-contexts.actual.json').read_text())}
a=[x for x in a if x['goalId']not in assigned]
start=int(sys.argv[1]);rows=[];used=0
for i,x in enumerate(a[start:],start):
 row={**x,'extraContextIndex':i,'wholeGoal':{k:v for k,v in x['wholeGoal'].items()if k!='resourceLinks'},'resourceLinksRetainedInFullBoundContextFile':True}
 size=len(json.dumps(row,ensure_ascii=False))
 if rows and used+size>23000:break
 rows.append(row);used+=size
print(json.dumps({'nextExtraContextIndex':start+len(rows),'extraWholeContextCount':len(a),'records':rows},ensure_ascii=False,separators=(',',':')))
