import pathlib,json,sys
old=set();base=pathlib.Path('tmp/cross-subject-requires/physics-unresolved97-whole-body-successor-author-20261013-v1')
for p in (base/'batch-001-v2/evidence/readings').glob('*.complete-source-semantics.v2.json'):
 for z in json.loads(p.read_text())['completePassages']:old.add(json.dumps(z['wholePassage'],ensure_ascii=False,sort_keys=True))
ps={}
for p in sorted((base/'batch-002/readings').glob('*.complete-source-semantics.json')):
 x=json.loads(p.read_text());n=int(p.name[:2])
 for z in x['completePassages']:
  k=json.dumps(z['wholePassage'],ensure_ascii=False,sort_keys=True)
  ps.setdefault(k,{'wholePassage':z['wholePassage'],'usedByIndices':[],'sourceFile':z['sourceFile']['path']})['usedByIndices'].append(n)
new=[v for k,v in ps.items()if k not in old];seen={}
def comp(v,path='$'):
 if isinstance(v,str)and len(v)>90:
  if v in seen:return{'identicalCompleteValueAt':seen[v]}
  seen[v]=path;return v
 if isinstance(v,dict):return{k:comp(z,path+'.'+k)for k,z in v.items()}
 if isinstance(v,list):return[comp(z,path+'['+str(i)+']')for i,z in enumerate(v)]
 return v
start=int(sys.argv[1]);out=[];sz=0
for i,z in enumerate(new[start:],start):
 z={**z,'newSourcePassageIndex':i};n=len(json.dumps(z,ensure_ascii=False))
 if out and sz+n>33000:break
 out.append(z);sz+=n
print(json.dumps(comp({'nextIndex':start+len(out),'newWholePassageCount':len(new),'priorWholePassagesIdentical':len(ps)-len(new),'records':out}),ensure_ascii=False))
