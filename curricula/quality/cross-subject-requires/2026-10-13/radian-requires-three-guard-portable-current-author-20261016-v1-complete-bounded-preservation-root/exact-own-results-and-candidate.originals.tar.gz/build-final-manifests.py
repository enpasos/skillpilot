from pathlib import Path
import json,hashlib,datetime
R=Path('/home/enpasos/projects/skillpilot');L=R/'tmp/cross-subject-requires/radian-requires-three-guard-portable-current-author-20261016-v1';P=L/'payload';O=json.loads((L/'registered-portable-overlay.inputs.json').read_text());Q=O['qualityLogicalPath'];q=P/Q;gid='8d30d241-0247-48ac-83d3-4e0de61584d3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def dump(n,x):(L/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def file(p):return {'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)}
def diff(a,b,p=''):
 if type(a)!=type(b):return [p]
 if isinstance(a,dict):return [z for k in sorted(set(a)|set(b)) for z in ([p+'/'+k] if k not in a or k not in b else diff(a[k],b[k],p+'/'+k))]
 if isinstance(a,list):return [p] if len(a)!=len(b) else [z for i,(x,y) in enumerate(zip(a,b)) for z in diff(x,y,p+'/'+str(i))]
 return [] if a==b else [p]
math=O['productOverlays'][0]['target'];base=load(R/math);new=load(P/math);assert len(base['goals'])==len(new['goals'])==1254;assert [g['id'] for g in base['goals']]==[g['id'] for g in new['goals']];goaldeltas=[g['id'] for g,h in zip(base['goals'],new['goals']) if g!=h];assert goaldeltas==[gid];a=next(g for g in base['goals'] if g['id']==gid);b=next(g for g in new['goals'] if g['id']==gid);assert diff(a,b)==['/requires'];assert b['requires']==['4eeab7d5-eeb3-579b-845e-1c52ffe9e89f','ee48e811-4c9c-5080-9836-8403fc9f0810','65365dce-f33f-49d8-9516-42f75883aa86']
regpath=O['productOverlays'][2]['target'];oldreg=load(R/regpath);newreg=load(P/regpath);assert oldreg['subjects'][1]==newreg['subjects'][1];m=oldreg['subjects'][0];mn=newreg['subjects'][0];assert set(mn['resolutionIndexPaths'])-set(m['resolutionIndexPaths'])=={Q+'/D/resolution-index.json'};assert all(x in mn['resolutionIndexPaths'] for x in m['resolutionIndexPaths']);assert mn['resolutionSupersessions'][:-1]==m.get('resolutionSupersessions',[]);assert mn['resolutionSupersessions'][-1]['goalId']==gid
products=[]
for o in O['productOverlays']:
 assert sha(R/o['target'])==o['baselineTargetSha256'];assert sha(R/o['source'])==o['sourceSha256'];products.append({**o,'jsonChangedPointers':diff(load(R/o['target']),load(R/o['source']))})
assert products[-1]['jsonChangedPointers']==['/inputs/canonical/sha256']
for key,n in [('semanticAtomicityConfigPath','A'),('memoryReviewConfigPath','M')]:
 orig=R/load(R/m[key])['reviewPath'];old=orig.read_text().splitlines(keepends=True);cur=(q/(n+'/full.review.jsonl')).read_text().splitlines(keepends=True);assert len(old)==len(cur)==807;assert [json.loads(z)['goalId'] for z,w in zip(old,cur) if z!=w]==[gid]
A=R/'tmp/cross-subject-requires/radian-whole-math-requires-author-20261016-v1';native=load(A/'native-current-whole-inputs.actual.json');oldP=next(x for x in native['goals'] if x['goal']['id']==gid)['positiveEvidenceOwner'];retained=''.join(z for z in (R/oldP['config']['reviewPath']).read_text().splitlines(keepends=True) if z.strip() and json.loads(z)['goalId']!=gid);assert retained==(q/'P/retained-twelve.review.jsonl').read_text();assert load(A/'quality-current-path-candidate/P.single-owning-record.json')==json.loads((q/'P/8d30.current.review.jsonl').read_text())
sourcecheck=load(L/'INITIAL-SEALED-INPUT-VERIFICATION.actual.json');verified=[]
extra=R/'tmp/cross-subject-requires/radian-whole-math-requires-independent-peer-20261016-v1/SEAL.science-and-requires.actual.json';entries=list(sourcecheck['artifacts'])+[{'path':str(extra.relative_to(R)),'sha256':'9662d8df8cc9d9ff9afe4ee4f96bf929b0b4454329cb70618d5395244f4b2e75'}]
for item in entries:
 p=R/item['path'];assert sha(p)==item['sha256'];s=load(p);count=0
 for member in s.get('members',[]):
  f=R/member['path'];assert sha(f)==member['sha256'];assert f.stat().st_size==member['bytes'];count+=1
 verified.append({'path':item['path'],'sha256':sha(p),'memberCount':count})
# Source-bound original D bytes are unchanged except the three declared transport pointers.
sealed=load(A/'SEAL.D-inputs.actual.json');copied=[]
for item in sealed['members']:
 f=R/item['path']
 try:rel=f.relative_to(A/'native-D-prepared/8d30')
 except ValueError:continue
 t=q/'D'/rel
 if str(rel)=='batch-manifest.json':assert diff(load(f),load(t))==['/configDigest','/configPath','/source/baseGoalBookConfigPath']
 else:assert f.read_bytes()==t.read_bytes()
 copied.append(str(rel))
views=R/'curricula/DE/Gymnasium/composition-views/mathematik';generated=L/'reader-cache/composition-views-mathematik';assert all(f.read_bytes()==(generated/f.relative_to(views)).read_bytes() for f in views.rglob('*') if f.is_file());outputs=[line.split()[1] for line in (L/'executions/math-duration-policy-current-write.stdout.txt').read_text().splitlines() if line.startswith('ok ')];assert len(outputs)==18
protected=[]
adopt=R/'tmp/cross-subject-requires/ten-view-targets-and-empty-math-test-actual-adoption-root-20261016-v1'
for n,k in [('ADOPTION.actual.json','files'),('NORMAL-GENERATED-STATUS-ADOPTION.actual.json','normalGeneratedStatusFilesAdopted')]:
 for row in load(adopt/n)[k]:
  x=row['actual'];f=R/x['path'];assert sha(f)==x['sha256'].removeprefix('sha256:');protected.append(file(f))
assert len(protected)==15;assert sha(R/'.git/index')=='6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8';assert sha(R/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json')=='a1309a6143dcce96eea9ad0d2b39299995bc59ce322a02c52a5783857706fe24'
receipt=load(L/'executions/native-fixed-minimal-persistent-current807-478.stdout.txt');inputs={x['path'] for x in receipt['receipt']['sourceInputs'] if x['kind']=='file'};post=[]
for f in sorted(P.rglob('*')):
 if not f.is_file():continue
 assert not f.is_symlink();target=str(f.relative_to(P));baseline=R/target
 if target in [x['target'] for x in products]:role='existing-product-postimage'
 elif target in inputs:role='registered-native-reader-dependency'
 elif target.startswith(Q+'/provenance/') or target==Q+'/ATTRIBUTION.txt':role='bounded-whole-goal-scientific-provenance'
 elif target==Q+'/M/full.report.md':role='normal-owning-memory-report'
 else:role='normal-standalone-D-reproduction-and-reviewed-material'
 post.append({'source':str(f.relative_to(R)),'target':target,'bytes':f.stat().st_size,'sha256':sha(f),'baselineTargetSha256':sha(baseline) if baseline.is_file() else None,'role':role})
assert not (q/'private-full807.book-model.json').exists();assert not (q/'provenance/author-bounded-source-context.original.json').exists();assert not any('/node_modules/' in x['target'] or '/executions/' in x['target'] for x in post)
model=L/'reader-cache/private-full807.book-model.json';bm=load(model);assert len(bm['pages'])==807;assert all(p.get('positiveEvidence') is not None or p.get('evidenceProfile') is not None for p in bm['pages']) if any('positiveEvidence' in p or 'evidenceProfile' in p for p in bm['pages']) else True
integrity={'verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'canonicalOnly8dRequires':True,'unchangedCompleteGoalFields':{k:v for k,v in b.items() if k!='requires'},'newRequires':b['requires'],'all2018CanonicalIdsStable':True,'Math1254Physics764Ordinary807_478Unchanged':True,'existingProductDeltas':products,'allOriginalScienceAndDSealsVerified':verified,'exactDInputMembersRetained':copied,'AMOther806RawLinesExact':load(L/'A-M-exact-retained-line-boundary.actual.json'),'PWholeCurrentRowExactAuthorOpinion':True,'retained12POriginalRawLinesExact':True,'oldDIndexRetainedOnly8dSupersession':True,'unchanged18GeneratorOutputs':[file(views/n) for n in outputs],'all88ViewCopyFilesByteExact':True,'protectedRoot15PostimagesUnchanged':protected,'RootIndexUnchanged':file(R/'.git/index'),'RootMathUnchanged':file(R/math),'RootPhysicsUnchanged':file(R/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'),'RootWrites':False,'sourceOrHostHumanApprovalCreated':False}
dump('FINAL-INTEGRITY.actual.json',integrity)
manifest={'schemaVersion':1,'scope':'Exact minimal active owner transport plus bounded actual single-goal scientific review material, to be adopted by parent only after its normal owning checks. No Root mutation by this author.','qualityLogicalRoot':Q,'payloadRoot':str(P.relative_to(R)),'postimageFileCount':len(post),'postimageBytes':sum(x['bytes'] for x in post),'existingProductCount':len(products),'files':post,'RootDeletes':[],'historicalRootReviewFilesChanged':False,'noReaderExecutionCacheInstallation':True,'tmpOnlyRetained':[file(model),file(L/'reader-cache/author-bounded-source-context.original.json')],'consumptionBoundary':{'privateFull807Config':'Persistent: standalone D validation directly reads it in loadBatchEvidenceSourceConfig to validate current exact P ownership, and preparation uses it.','privateFull807BookModel':'TMP only: generated full-book reader output; neither registered-native nor standalone D check reads it. Both checks pass with file absent and all original cross-subject-requires TMP lanes masked.','singleGoalDBundle':'Persistent: normal standalone owning check verifies every declared subset model/bundle artifact; actual reviewed V3/PDF, criteria, contracts and independent records retained.','nativeReceiptAndExecutions':'TMP audit only. Never installed into Root.','sourceExtractedText':'TMP only. Persistent provenance has exact original hash, source-file/document hashes and scoped record bindings; no complete official PDF text copied.'}}
dump('PORTABLE-ROOT-POSTIMAGES.actual.json',manifest)
print(json.dumps({'manifest':file(L/'PORTABLE-ROOT-POSTIMAGES.actual.json'),'integrity':file(L/'FINAL-INTEGRITY.actual.json'),'files':len(post),'bytes':sum(x['bytes'] for x in post),'existingProducts':len(products)},indent=2))
