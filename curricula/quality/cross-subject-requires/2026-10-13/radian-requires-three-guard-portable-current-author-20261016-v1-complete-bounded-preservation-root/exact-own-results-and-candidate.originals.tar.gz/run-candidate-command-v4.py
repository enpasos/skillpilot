from pathlib import Path
import sys,json,hashlib,subprocess,os,time,datetime
R=Path('/home/enpasos/projects/skillpilot');L=R/'tmp/cross-subject-requires/radian-requires-three-guard-portable-current-author-20261016-v1';O=json.loads((L/'registered-portable-overlay.inputs.json').read_text());label=sys.argv[1];assert label.replace('-','').replace('_','').isalnum();mode=sys.argv[2];assert mode in ['quality-write','native-readonly','view-write'];command=sys.argv[3:];assert command
E=L/'executions';E.mkdir(exist_ok=True);assert not (E/(label+'.execution.actual.json')).exists();alias=L/'.namespace/cross-subject-requires-baseline';alias.mkdir(parents=True,exist_ok=True);csr=R/'curricula/DE/Gymnasium/quality/cross-subject-requires';args=[str(R/'tmp/ci-tools/hermetic-consumer-tools-20261015-v1/root/usr/bin/bwrap'),'--ro-bind','/','/','--bind',str(L),str(L),'--ro-bind',str(csr),str(alias),'--tmpfs',str(csr)]
for old in sorted(csr.iterdir()):
 assert old.is_dir();args+=['--ro-bind',str(old),str(csr/old.name)]
args+=['--bind' if mode=='quality-write' else '--ro-bind',str(R/O['qualityPayloadDirectory']),str(R/O['qualityLogicalPath'])]
for x in O['productOverlays']:
 s=R/x['source'];t=R/x['target'];assert hashlib.sha256(s.read_bytes()).hexdigest()==x['sourceSha256'];assert hashlib.sha256(t.read_bytes()).hexdigest()==x['baselineTargetSha256'];args+=['--ro-bind',str(s),str(t)]

if mode=='view-write':args+=['--bind',str(L/'reader-cache/composition-views-mathematik'),str(R/'curricula/DE/Gymnasium/composition-views/mathematik')]
args+=['--tmpfs','/tmp','--proc','/proc','--dev','/dev','--die-with-parent','--chdir',str(R)]+command
env={**os.environ,'TMPDIR':'/tmp','PATH':str(R/'tmp/ci-tools/node-v20.20.2-linux-x64/bin')+':'+str(R/'tmp/ci-tools/poppler-root/usr/bin')+':'+os.environ.get('PATH',''),'LD_LIBRARY_PATH':str(R/'tmp/ci-tools/poppler-root/usr/lib/x86_64-linux-gnu')}
start=time.monotonic();began=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(args,cwd=R,env=env,capture_output=True);(E/(label+'.stdout.txt')).write_bytes(p.stdout);(E/(label+'.stderr.txt')).write_bytes(p.stderr);record={'startedAt':began,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':args,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'mode':mode,'RootWrites':False,'TMPDIR':'/tmp','policyCanonicalBindingChanged':True,'policyRulesOrFloorsChanged':False};(E/(label+'.execution.actual.json')).write_text(json.dumps(record,indent=2)+'\n');print(label,p.returncode);print(p.stdout.decode()[-2500:] if len(p.stdout)<2500 else 'Complete stdout saved ('+str(len(p.stdout))+' bytes).');print(p.stderr.decode()[-2500:]);sys.exit(p.returncode)
