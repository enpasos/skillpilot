import type { GoalPlacementContext } from '../../landscapeTypes'
import { goalMatchesApplicabilityContext, parseApplicabilityContexts, toSelectedApplicabilityScope, resolveApplicabilityBranchScope } from '../applicabilityContexts'
import {
  STATE_LOOKING_TITLE_PATTERN,
  asRecord,
  asString,
  buildCanonicalGraphIndex,
  normalizeCanonicalLandscape,
  type CanonicalAuthoringLandscape,
} from './canonicalAuthoring'

export type CompositionViewNode =
  | CompositionStructureNode
  | CompositionCanonicalSubtreeNode
  | CompositionGoalEntryNode
  | CompositionLandscapeEntryNode

export type CompositionProjectionRole = 'target' | 'prerequisiteOnly'

export interface CompositionStructureNode extends Record<string, unknown> {
  kind: 'structure'
  id: string
  label: string
  children: CompositionViewNode[]
}

export interface CompositionCanonicalSubtreeNode extends Record<string, unknown> {
  kind: 'canonicalSubtree'
  goalId: string
  displayLabel?: string
  projectionRole?: CompositionProjectionRole
}

export interface CompositionGoalEntryNode extends Record<string, unknown> {
  kind: 'goalEntry'
  goalId: string
  displayLabel?: string
  projectionRole?: CompositionProjectionRole
}

export interface CompositionLandscapeEntryNode extends Record<string, unknown> {
  kind: 'landscapeEntry'
  landscapeId: string
  displayLabel?: string
}

export interface CompositionView extends Record<string, unknown> {
  viewId: string
  landscapeId: string
  scope: GoalPlacementContext
  rootNodes: CompositionViewNode[]
}

export interface CompositionViewFinding {
  code: string
  severity: 'error' | 'warning'
  message: string
  nodePath?: string
  goalId?: string
}

export interface CompiledCompositionPreviewNode {
  runtimeId: string
  kind: 'structure' | 'goal'
  label: string
  sourceGoalId?: string
  children: CompiledCompositionPreviewNode[]
}

export interface CompositionCompileResult {
  projectionPurpose?: 'runtime' | 'quality-review'
  runtimeAdmissible?: boolean
  compiledRootNodes: CompiledCompositionPreviewNode[]
  findings: CompositionViewFinding[]
}

export const getCompositionProjectionRole = (
  node: CompositionCanonicalSubtreeNode | CompositionGoalEntryNode,
): CompositionProjectionRole => (
  node.projectionRole === 'prerequisiteOnly' ? 'prerequisiteOnly' : 'target'
)

type CompositionProjectionRoleSource = 'landscapeEntry' | 'canonicalSubtree' | 'goalEntry'

interface CompositionProjectionRoleAssignment {
  role: CompositionProjectionRole
  source: CompositionProjectionRoleSource
  distance: number
}

const COMPOSITION_PROJECTION_ROLE_SOURCE_PRIORITY: Record<CompositionProjectionRoleSource, number> = {
  landscapeEntry: 0,
  canonicalSubtree: 1,
  goalEntry: 2,
}

const isMoreSpecificCompositionProjectionRoleAssignment = (
  candidate: CompositionProjectionRoleAssignment,
  current: CompositionProjectionRoleAssignment | undefined,
): boolean => {
  if (!current) return true

  const candidatePriority = COMPOSITION_PROJECTION_ROLE_SOURCE_PRIORITY[candidate.source]
  const currentPriority = COMPOSITION_PROJECTION_ROLE_SOURCE_PRIORITY[current.source]
  if (candidatePriority !== currentPriority) {
    return candidatePriority > currentPriority
  }

  if (candidate.distance !== current.distance) {
    return candidate.distance < current.distance
  }

  return candidate.role === 'target' && current.role === 'prerequisiteOnly'
}

export const collectCompositionProjectionRoleGoalIds = (
  nodes: CompositionViewNode[],
  goalById: ReadonlyMap<string, { contains?: readonly string[] }>,
  rootGoalIdByLandscapeId: ReadonlyMap<string, string> = new Map(),
): { targetGoalIds: Set<string>, prerequisiteOnlyGoalIds: Set<string> } => {
  const assignmentByGoalId = new Map<string, CompositionProjectionRoleAssignment>()

  const assignGoal = (goalId: string, assignment: CompositionProjectionRoleAssignment) => {
    if (isMoreSpecificCompositionProjectionRoleAssignment(
      assignment,
      assignmentByGoalId.get(goalId),
    )) {
      assignmentByGoalId.set(goalId, assignment)
    }
  }

  const assignSubtree = (
    rootGoalId: string,
    role: CompositionProjectionRole,
    source: Extract<CompositionProjectionRoleSource, 'landscapeEntry' | 'canonicalSubtree'>,
  ) => {
    const shortestDistanceByGoalId = new Map<string, number>()
    const queue: Array<{ goalId: string, distance: number }> = [{ goalId: rootGoalId, distance: 0 }]

    for (let index = 0; index < queue.length; index += 1) {
      const { goalId, distance } = queue[index]
      const knownDistance = shortestDistanceByGoalId.get(goalId)
      if (knownDistance !== undefined && knownDistance <= distance) continue
      shortestDistanceByGoalId.set(goalId, distance)
      assignGoal(goalId, { role, source, distance })

      const goal = goalById.get(goalId)
      ;(goal?.contains ?? []).forEach((childId) => {
        queue.push({ goalId: childId, distance: distance + 1 })
      })
    }
  }

  const visitNode = (node: CompositionViewNode) => {
    if (node.kind === 'structure') {
      node.children.forEach(visitNode)
      return
    }

    if (node.kind === 'landscapeEntry') {
      const rootGoalId = rootGoalIdByLandscapeId.get(node.landscapeId)
      if (rootGoalId) assignSubtree(rootGoalId, 'target', 'landscapeEntry')
      return
    }

    const role = getCompositionProjectionRole(node)
    if (node.kind === 'canonicalSubtree') {
      assignSubtree(node.goalId, role, 'canonicalSubtree')
    } else {
      assignGoal(node.goalId, { role, source: 'goalEntry', distance: 0 })
    }
  }

  nodes.forEach(visitNode)
  const targetGoalIds = new Set<string>()
  const prerequisiteOnlyGoalIds = new Set<string>()
  assignmentByGoalId.forEach((assignment, goalId) => {
    if (assignment.role === 'prerequisiteOnly') {
      prerequisiteOnlyGoalIds.add(goalId)
    } else {
      targetGoalIds.add(goalId)
    }
  })
  return { targetGoalIds, prerequisiteOnlyGoalIds }
}

const normalizeScope = (value: unknown): GoalPlacementContext => {
  const record = asRecord(value)
  const scope: GoalPlacementContext = {}
  Object.entries(record).forEach(([key, entry]) => {
    if (typeof entry === 'string' && entry.trim() !== '') {
      scope[key] = entry
    }
  })
  return scope
}

const normalizeCompositionNode = (value: unknown, pathLabel: string): CompositionViewNode => {
  const record = asRecord(value)
  if (record.kind === 'canonicalSubtree') {
    const displayLabel = asString(record.displayLabel)
    return {
      ...record,
      kind: 'canonicalSubtree',
      goalId: asString(record.goalId),
      ...(displayLabel.trim() ? { displayLabel } : {}),
    }
  }

  if (record.kind === 'goalEntry') {
    const displayLabel = asString(record.displayLabel)
    return {
      ...record,
      kind: 'goalEntry',
      goalId: asString(record.goalId),
      ...(displayLabel.trim() ? { displayLabel } : {}),
    }
  }

  if (record.kind === 'landscapeEntry') {
    const displayLabel = asString(record.displayLabel)
    return {
      ...record,
      kind: 'landscapeEntry',
      landscapeId: asString(record.landscapeId),
      ...(displayLabel.trim() ? { displayLabel } : {}),
    }
  }

  const children = Array.isArray(record.children) ? record.children : []
  return {
    ...record,
    kind: 'structure',
    id: asString(record.id, `structure-${pathLabel}`),
    label: asString(record.label, 'New Structure'),
    children: children.map((child, index) => normalizeCompositionNode(child, `${pathLabel}-${index}`)),
  }
}

export const normalizeCompositionView = (value: unknown): CompositionView => {
  const record = asRecord(value)
  const rootNodes = Array.isArray(record.rootNodes) ? record.rootNodes : []
  return {
    ...record,
    viewId: asString(record.viewId, 'new-view'),
    landscapeId: asString(record.landscapeId),
    scope: normalizeScope(record.scope),
    rootNodes: rootNodes.map((node, index) => normalizeCompositionNode(node, `root-${index}`)),
  }
}

export const createEmptyCompositionView = (): CompositionView => ({
  viewId: 'new-view',
  landscapeId: '',
  scope: {
    schoolForm: 'Gymnasium',
  },
  rootNodes: [],
})

const getLandscapeRootGoal = (landscape: CanonicalAuthoringLandscape) =>
  landscape.goals.find((goal) => (goal.tags ?? []).includes('root')) ?? null

const isGenericStructureLabel = (label: string): boolean => {
  const normalized = label.trim().toLowerCase()
  return normalized === ''
    || normalized === 'new structure'
    || normalized === 'new node'
    || /^structure\s*\d*$/iu.test(normalized)
    || /^cluster\s*\d*$/iu.test(normalized)
    || /^node\s*\d*$/iu.test(normalized)
}

const stringifyNodePath = (path: number[]): string => (
  path.length === 0 ? 'root' : path.join('.')
)

export const compileCompositionView = (
  view: CompositionView,
  landscape: CanonicalAuthoringLandscape | null,
  goalUniverse: CanonicalAuthoringLandscape | null = null,
  landscapeUniverseById: Map<string, CanonicalAuthoringLandscape> | null = null,
  options: { purpose?: 'runtime' | 'quality-review', selectedScope?: unknown } = {},
): CompositionCompileResult => {
  const findings: CompositionViewFinding[] = []
  const hasScopeDiscriminator = ['jurisdiction', 'stage', 'courseProfile', 'durationModel']
    .some((key) => ((view.scope[key] ?? '') as string).trim())

  if (!(view.viewId ?? '').trim()) {
    findings.push({ code: 'CPV-001', severity: 'error', message: 'viewId fehlt.' })
  }
  if (!(view.landscapeId ?? '').trim()) {
    findings.push({ code: 'CPV-001', severity: 'error', message: 'landscapeId fehlt.' })
  }
  if (!(view.scope.schoolForm ?? '').trim()) {
    findings.push({ code: 'CPV-001', severity: 'error', message: 'scope.schoolForm fehlt.' })
  }
  if (!hasScopeDiscriminator) {
    findings.push({
      code: 'CPV-001',
      severity: 'error',
      message: 'Mindestens einer der Scope-Keys jurisdiction, stage, courseProfile oder durationModel muss gesetzt sein.',
    })
  }
  if (view.rootNodes.length === 0) {
    findings.push({ code: 'CPV-001', severity: 'error', message: 'Keine rootNodes definiert.' })
  }

  const canonicalLandscape = landscape ? normalizeCanonicalLandscape(landscape) : null
  if (!canonicalLandscape) {
    findings.push({ code: 'CPV-001', severity: 'error', message: 'Kein kanonischer Graph geladen.' })
    return { compiledRootNodes: [], findings, projectionPurpose: options.purpose ?? 'runtime', runtimeAdmissible: false }
  }

  const canonicalGoalUniverse = goalUniverse ? normalizeCanonicalLandscape(goalUniverse) : canonicalLandscape

  if (view.landscapeId && canonicalLandscape.landscapeId && view.landscapeId !== canonicalLandscape.landscapeId) {
    findings.push({
      code: 'CPV-001',
      severity: 'error',
      message: `view.landscapeId (${view.landscapeId}) passt nicht zum geladenen kanonischen Graphen (${canonicalLandscape.landscapeId}).`,
    })
  }

  const index = buildCanonicalGraphIndex(canonicalGoalUniverse)
  const rootGoalIdByLandscapeId = new Map<string, string>()
  const canonicalRootGoal = getLandscapeRootGoal(canonicalLandscape)
  if (canonicalRootGoal) {
    rootGoalIdByLandscapeId.set(canonicalLandscape.landscapeId, canonicalRootGoal.id)
  }
  landscapeUniverseById?.forEach((candidateLandscape, landscapeId) => {
    const rootGoal = getLandscapeRootGoal(candidateLandscape)
    if (rootGoal) rootGoalIdByLandscapeId.set(landscapeId, rootGoal.id)
  })
  const { targetGoalIds: effectiveTargetGoalIds } = collectCompositionProjectionRoleGoalIds(
    view.rootNodes,
    index.goalById,
    rootGoalIdByLandscapeId,
  )
  const selectedScope = toSelectedApplicabilityScope(options.selectedScope ?? view.scope)
  // Review inventory enumerates canonical bodies; it is never a runtime projection.
  effectiveTargetGoalIds.forEach((goalId) => {
    const goal = index.goalById.get(goalId)
    if (!goal) return
    const parsed = parseApplicabilityContexts(goal)
    if (parsed.errors.length) findings.push({ code: 'CPV-216', severity: 'error', goalId,
      message: parsed.errors.join(' ') })
    else if (options.purpose !== 'quality-review' && !(Array.isArray(view.resolvedCourseProfileViews)
      && Array.isArray(view.mergedFromViewIds) && String(view.viewId).startsWith('merged:')
      ? view.resolvedCourseProfileViews.map(normalizeCompositionView).some((source) =>
        (view.mergedFromViewIds as unknown[]).includes(source.viewId)
        && collectCompositionProjectionRoleGoalIds(source.rootNodes, index.goalById, rootGoalIdByLandscapeId).targetGoalIds.has(goalId)
        && goalMatchesApplicabilityContext(goal, resolveApplicabilityBranchScope(selectedScope, source.scope)))
      : goalMatchesApplicabilityContext(goal, resolveApplicabilityBranchScope(selectedScope, view.scope)))) {
      findings.push({ code: 'CPV-216', severity: 'error', goalId,
        message: 'Target has no exact applicability context for this complete selected scope.' })
    }
  })
  const structureIds = new Set<string>()
  const subtreeRootsByPath = new Map<string, { goalId: string, visibleGoalIds: Set<string> }>()
  const goalOccurrenceCount = new Map<string, number>()
  const goalParentKeys = new Map<string, Set<string>>()

  const noteGoalOccurrence = (goalId: string, parentKey: string | null) => {
    goalOccurrenceCount.set(goalId, (goalOccurrenceCount.get(goalId) ?? 0) + 1)
    if (!parentKey) return
    const parents = goalParentKeys.get(goalId) ?? new Set<string>()
    parents.add(parentKey)
    goalParentKeys.set(goalId, parents)
  }

  const validateNode = (node: CompositionViewNode, path: number[]) => {
    const pathKey = stringifyNodePath(path)

    if (node.kind === 'structure') {
      if (!(node.id ?? '').trim()) {
        findings.push({ code: 'CPV-001', severity: 'error', nodePath: pathKey, message: 'Structure node ohne id.' })
      } else if (structureIds.has(node.id)) {
        findings.push({ code: 'CPV-001', severity: 'error', nodePath: pathKey, message: `Doppelte structure id: ${node.id}` })
      } else {
        structureIds.add(node.id)
      }

      if (!(node.label ?? '').trim()) {
        findings.push({ code: 'CPV-001', severity: 'error', nodePath: pathKey, message: 'Structure node ohne label.' })
      } else if (isGenericStructureLabel(node.label)) {
        findings.push({ code: 'CPV-101', severity: 'warning', nodePath: pathKey, message: 'Sehr generisches structure label.' })
      }

      if (node.children.length === 0) {
        findings.push({ code: 'CPV-007', severity: 'error', nodePath: pathKey, message: 'Leerer structure node ohne Kinder.' })
      }

      node.children.forEach((child, indexOfChild) => validateNode(child, [...path, indexOfChild]))
      return
    }

    if (node.kind === 'landscapeEntry') {
      if (!(node.landscapeId ?? '').trim()) {
        findings.push({ code: 'CPV-001', severity: 'error', nodePath: pathKey, message: 'landscapeEntry ohne landscapeId.' })
        return
      }

      if (!landscapeUniverseById) {
        return
      }

      const referencedLandscape = landscapeUniverseById.get(node.landscapeId)
      if (!referencedLandscape) {
        findings.push({
          code: 'CPV-002',
          severity: 'error',
          nodePath: pathKey,
          message: `Fehlende kanonische Landscape-Referenz: ${node.landscapeId}`,
        })
        return
      }

      const rootGoal = getLandscapeRootGoal(referencedLandscape)
      if (!rootGoal) {
        findings.push({
          code: 'CPV-002',
          severity: 'error',
          nodePath: pathKey,
          message: `Referenzierte Landscape ${node.landscapeId} hat keinen Root-Knoten.`,
        })
      }
      return
    }

    if (
      node.projectionRole !== undefined
      && node.projectionRole !== 'target'
      && node.projectionRole !== 'prerequisiteOnly'
    ) {
      findings.push({
        code: 'CPV-008',
        severity: 'error',
        nodePath: pathKey,
        message: `Ungültige projectionRole: ${String(node.projectionRole)}`,
      })
    }

    if (node.kind === 'goalEntry') {
      if (!(node.goalId ?? '').trim()) {
        findings.push({ code: 'CPV-001', severity: 'error', nodePath: pathKey, message: 'goalEntry ohne goalId.' })
        return
      }

      const referencedGoal = index.goalById.get(node.goalId)
      if (!referencedGoal) {
        findings.push({
          code: 'CPV-002',
          severity: 'error',
          nodePath: pathKey,
          goalId: node.goalId,
          message: `Fehlende kanonische Ziel-Referenz: ${node.goalId}`,
        })
        return
      }

      if (referencedGoal.semanticKind === 'curricularArea') {
        findings.push({
          code: 'CPV-009',
          severity: 'error',
          nodePath: pathKey,
          goalId: node.goalId,
          message: 'goalEntry darf keinen als curricularArea klassifizierten kanonischen Cluster als opakes Ziel einblenden; verwende canonicalSubtree oder eine explizite fachliche Struktur aus atomaren Zielen.',
        })
      }

      if (STATE_LOOKING_TITLE_PATTERN.test(referencedGoal.title)) {
        findings.push({
          code: 'CPV-102',
          severity: 'warning',
          nodePath: pathKey,
          goalId: node.goalId,
          message: 'Referenziertes kanonisches Ziel wirkt noch phasen- oder landesspezifisch benannt.',
        })
      }
      return
    }

    if (!(node.goalId ?? '').trim()) {
      findings.push({ code: 'CPV-001', severity: 'error', nodePath: pathKey, message: 'canonicalSubtree ohne goalId.' })
      return
    }

    const referencedGoal = index.goalById.get(node.goalId)
    if (!referencedGoal) {
      findings.push({ code: 'CPV-002', severity: 'error', nodePath: pathKey, goalId: node.goalId, message: `Fehlender kanonischer Root: ${node.goalId}` })
      return
    }

    if (STATE_LOOKING_TITLE_PATTERN.test(referencedGoal.title)) {
      findings.push({ code: 'CPV-102', severity: 'warning', nodePath: pathKey, goalId: node.goalId, message: 'Referenzierter kanonischer Root wirkt noch phasen- oder landesspezifisch benannt.' })
    }

    if (getCompositionProjectionRole(node) === 'prerequisiteOnly') {
      return
    }

    subtreeRootsByPath.set(pathKey, {
      goalId: node.goalId,
      visibleGoalIds: new Set<string>(),
    })
  }

  view.rootNodes.forEach((node, indexOfNode) => validateNode(node, [indexOfNode]))

  const compileGoalSubtree = (
    goalId: string,
    parentKey: string | null,
    pathKey: string,
    displayLabel?: string,
  ): CompiledCompositionPreviewNode | null => {
    const goal = index.goalById.get(goalId)
    if (!goal || !effectiveTargetGoalIds.has(goalId)) return null
    noteGoalOccurrence(goal.id, parentKey)
    const runtimeId = `${pathKey}/goal:${goal.id}`
    return {
      runtimeId,
      kind: 'goal',
      label: displayLabel?.trim() || goal.title,
      sourceGoalId: goal.id,
      children: (index.childrenById.get(goal.id) ?? [])
        .map((childId) => compileGoalSubtree(childId, goal.id, `${runtimeId}/${childId}`))
        .filter((child): child is CompiledCompositionPreviewNode => child !== null),
    }
  }

  const compileNode = (
    node: CompositionViewNode,
    parentKey: string | null,
    path: number[],
  ): CompiledCompositionPreviewNode | null => {
    const pathKey = stringifyNodePath(path)
    if (node.kind === 'structure') {
      const runtimeId = `structure:${node.id || pathKey}`
      const children = node.children
        .map((child, indexOfChild) => compileNode(child, runtimeId, [...path, indexOfChild]))
        .filter((child): child is CompiledCompositionPreviewNode => child !== null)
      if (children.length === 0) return null
      return {
        runtimeId,
        kind: 'structure',
        label: node.label,
        children,
      }
    }

    if (node.kind === 'landscapeEntry') {
      const referencedLandscape = landscapeUniverseById?.get(node.landscapeId)
      const rootGoal = referencedLandscape ? getLandscapeRootGoal(referencedLandscape) : null
      if (rootGoal?.id) {
        noteGoalOccurrence(rootGoal.id, parentKey)
      }
      return {
        runtimeId: `landscape:${pathKey}`,
        kind: 'goal',
        label: node.displayLabel?.trim() || rootGoal?.title || referencedLandscape?.title || node.landscapeId,
        sourceGoalId: rootGoal?.id,
        children: [],
      }
    }

    if (node.kind === 'goalEntry') {
      if (getCompositionProjectionRole(node) === 'prerequisiteOnly') return null
      const goal = index.goalById.get(node.goalId)
      if (!goal || !effectiveTargetGoalIds.has(goal.id)) return null
      noteGoalOccurrence(goal.id, parentKey)
      return {
        runtimeId: `goalEntry:${pathKey}`,
        kind: 'goal',
        label: node.displayLabel?.trim() || goal.title,
        sourceGoalId: goal.id,
        children: [],
      }
    }

    if (getCompositionProjectionRole(node) === 'prerequisiteOnly') return null
    const compiledSubtree = compileGoalSubtree(node.goalId, parentKey, pathKey, node.displayLabel)
    const reference = subtreeRootsByPath.get(pathKey)
    if (reference && compiledSubtree) {
      const collectVisibleGoals = (compiled: CompiledCompositionPreviewNode): void => {
        if (compiled.sourceGoalId) reference.visibleGoalIds.add(compiled.sourceGoalId)
        compiled.children.forEach(collectVisibleGoals)
      }
      collectVisibleGoals(compiledSubtree)
    }
    return compiledSubtree
  }

  const compiledRootNodes = view.rootNodes
    .map((node, indexOfNode) => compileNode(node, null, [indexOfNode]))
    .filter((node): node is CompiledCompositionPreviewNode => node !== null)

  // Diagnose reference overlap from the actual projected subtree. Hidden
  // prerequisite-only goals do not create a visible occurrence or parent.
  const subtreeEntries = Array.from(subtreeRootsByPath.entries())
  for (let leftIndex = 0; leftIndex < subtreeEntries.length; leftIndex += 1) {
    const [leftPath, leftEntry] = subtreeEntries[leftIndex]
    for (let rightIndex = leftIndex + 1; rightIndex < subtreeEntries.length; rightIndex += 1) {
      const [rightPath, rightEntry] = subtreeEntries[rightIndex]
      const overlap = Array.from(leftEntry.visibleGoalIds).filter((goalId) => rightEntry.visibleGoalIds.has(goalId))
      if (overlap.length === 0) continue
      findings.push({
        code: 'CPV-004',
        severity: 'error',
        nodePath: `${leftPath} <> ${rightPath}`,
        message: `Überlappende kanonische Teilbäume (${leftEntry.goalId} / ${rightEntry.goalId}); gemeinsame Ziele: ${overlap.slice(0, 5).join(', ')}${overlap.length > 5 ? ' ...' : ''}`,
      })
    }
  }

  goalOccurrenceCount.forEach((count, goalId) => {
    if (count > 1) {
      findings.push({
        code: 'CPV-005',
        severity: 'error',
        goalId,
        message: `Kanonisches Ziel erscheint mehrfach im kompilierten Baum: ${goalId}`,
      })
    }
  })

  goalParentKeys.forEach((parents, goalId) => {
    if (parents.size > 1) {
      findings.push({
        code: 'CPV-006',
        severity: 'error',
        goalId,
        message: `Kanonisches Ziel hat mehr als einen sichtbaren Parent im kompilierten Baum: ${goalId}`,
      })
    }
  })

  return {
    compiledRootNodes,
    projectionPurpose: options.purpose ?? 'runtime',
    runtimeAdmissible: options.purpose !== 'quality-review' && !findings.some((item) => item.severity === 'error'),
    findings: findings.sort((left, right) => {
      const leftKey = `${left.severity}:${left.code}:${left.nodePath ?? ''}:${left.goalId ?? ''}:${left.message}`
      const rightKey = `${right.severity}:${right.code}:${right.nodePath ?? ''}:${right.goalId ?? ''}:${right.message}`
      return leftKey.localeCompare(rightKey, 'de', { numeric: true, sensitivity: 'base' })
    }),
  }
}
