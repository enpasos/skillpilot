#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import json,hashlib,subprocess,datetime
from pathlib import Path
B=Path(__file__).resolve().parent;R=B.parents[2];A=B.parent/'ideal-gas-minimal-successor-author-root-20261014-v1';OLD=B.parent/'remaining18-independent-science-peer-20261014-v1'
def read(p):return json.loads(p.read_text())
def bind(p):
 raw=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(raw),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()}
def dump(name,obj):
 p=B/name
 if p.exists():raise RuntimeError('Refuse overwrite')
 p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
before=read(B/'input-bindings.before.json');current=[]
for prior in before['files']:
 now=bind(R/prior['path']);assert now==prior,prior['path'];current.append(now)
author=[]
for prior in before['authorFiles']:
 assert bind(R/prior['path'])==prior,prior['path'];author.append(prior)
old=[]
for prior in before['priorReviewFiles']:
 assert bind(R/prior['path'])==prior,prior['path'];old.append(prior)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==before['gitHead']
# Extra baseline mathematics was read after initial capture; compare whole
# bodies directly against current Main and retain the exact owner line now.
extra=read(B/'existing-math-baseline-unit-operations.actual.json');extra_checks=[]
math=read(R/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json')
byid={g['id']:g for g in math['goals']}
for row in extra['wholeCurrentBaselineBodies']:
 assert byid[row['goal']['id']]==row['goal']
 lines=(R/row['ownerReviewPath']).read_text().splitlines();line=lines[row['line']-1];rec=json.loads(line)
 assert rec['goalId']==row['goal']['id'] and rec['profile']==row['profile']
 extra_checks.append({'goalId':rec['goalId'],'wholeGoalAndPStillCurrent':True,'ownerConfig':bind(R/row['ownerConfig']),'reviewFile':bind(R/row['ownerReviewPath']),'line':row['line'],'lineSha256':'sha256:'+hashlib.sha256(line.encode()).hexdigest()})
native=read(B/'native-independent-validation.actual.json');science=read(B/'independent-scientific-verdict.actual.json');execution=read(B/'native-command-execution.actual.json')
assert science['scientificVerdict']=='approved' and execution['allExitedZero'] and native['fullNativeReview']['errors']==[]
assert native['boundedOneCaseNativeReview']=={'errors':[],'required':1,'reviewed':1,'open':0}
assert all(c['stdout']['bytes']>0 and c['stderr']['bytes']==0 for c in execution['commands'])
dump('final-freshness-and-preservation.actual.json',{'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headBefore':before['gitHead'],'headAfter':head,'allBoundMainInputsUnchanged':True,'boundInputCount':len(current),'inputBindings':current,'originalAuthorFilesUnchanged':author,'originalIndependentReviewFilesUnchanged':old,'extraWholeBaselineMathematicsCurrent':extra_checks,'originalRejectionStillRejected':read(OLD/'native-independent-review.bound.inert.json')['decisions'][16]['decision']=='rejected','ownWritesRestrictedTo':str(B.relative_to(R)),'noClaimOfCleanWorkingTree':True})
(B/'review-summary.md').write_text('Approved the exact one-edge ideal-gas successor, adding57fbb only.\n\nThe whole volume-conversion competence is required by the unchanged Goal/P and not supplied by the current mechanics/energy corridor. The actual forward chain57fbb→f2e42→541485 retains the needed whole equation prerequisite without a duplicate direct edge. Both literal physics cases, all prescribed57/f2/541 cases and three new independent transfers are solved in the scientific verdict.\n\nNative preparation reproduced the original7596-byte packet exactly. Full native review:0 errors,1285 required,1 reviewed,1284 open. Bounded case:1 required,1 reviewed,0 open. Global missing/ambiguous references and cycles:0. Actual stdout/stderr/exit codes and byte hashes are retained.\n\nThe original two-edge rejection and its sealed files remain unchanged. No Main/source/quality/config/index/HEAD changes, source/placement/P/Kind/D/Human/M7/adoption approval or publication.\n')
files=[bind(p) for p in sorted(B.rglob('*')) if p.is_file() and p.name not in ['artifact-seal.final.json','completion.handoff.json']]
dump('artifact-seal.final.json',{'schemaVersion':'private-informed-independent-review-seal-v1','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'count':len(files),'excludesSelfAndFollowingHandoff':True})
dump('completion.handoff.json',{'schemaVersion':'ideal-gas-minimal-successor-independent-handoff-v1','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'identity':science['identity'],'scope':'One exact canonical Gymnasium Mathematics→Physics ideal-gas successor, Sek I/II context','goalId':science['goalId'],'authorProposal':bind(A/'native-proposal.bound.inert.json'),'scientificVerdict':'approved','acceptedNewDirectForeignIds':science['acceptedNewDirectForeignIds'],'wholeGoalPAndScopesUnchanged':True,'scientificVerdictAndOwnSolvedWork':bind(B/'independent-scientific-verdict.actual.json'),'nativeIndependentReview':bind(B/'native-independent-review.bound.inert.json'),'nativeValidation':bind(B/'native-independent-validation.actual.json'),'nativeResults':native,'actualStdoutStderrExitBytes':bind(B/'native-command-execution.actual.json'),'currentWholeReader':bind(B/'actual-whole-current-reader.private.json'),'freshnessAndOriginalPreservation':bind(B/'final-freshness-and-preservation.actual.json'),'seal':bind(B/'artifact-seal.final.json'),'originalExactTwoEdgeRejection':{'path':str((OLD/'native-independent-review.bound.inert.json').relative_to(R)),'sha256':bind(OLD/'native-independent-review.bound.inert.json')['sha256'],'decisionIndex':16,'decision':'rejected','unchanged':True},'boundary':{'MainCanonicalPQualityConfigIndexHeadWrites':False,'sourceOrPlacementApproval':False,'PKindDHumanM7AdoptionApproval':False,'humanApprovalInvented':False,'modelDiversityClaim':False,'absoluteBlindFirstPassClaim':False,'floorReductions':False,'commitPushDeployPublication':False},'licensing':{'technical':'Apache-2.0','ownDidacticSolutions':'CC-BY-4.0; SkillPilot attribution','thirdPartySources':'Original grants/rights retained'}})
print(json.dumps({'scientificVerdict':'approved','nativeErrors':0,'boundedOneCase':native['boundedOneCaseNativeReview'],'boundMainInputsUnchanged':len(current),'authorFilesUnchanged':len(author),'priorSealedReviewFilesUnchanged':len(old),'ownArtifactsSealed':len(files),'handoff':str((B/'completion.handoff.json').relative_to(R)),'handoffSha256':bind(B/'completion.handoff.json')['sha256']}))
