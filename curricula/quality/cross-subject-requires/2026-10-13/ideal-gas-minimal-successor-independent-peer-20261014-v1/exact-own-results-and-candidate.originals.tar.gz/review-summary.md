Approved the exact one-edge ideal-gas successor, adding57fbb only.

The whole volume-conversion competence is required by the unchanged Goal/P and not supplied by the current mechanics/energy corridor. The actual forward chain57fbb→f2e42→541485 retains the needed whole equation prerequisite without a duplicate direct edge. Both literal physics cases, all prescribed57/f2/541 cases and three new independent transfers are solved in the scientific verdict.

Native preparation reproduced the original7596-byte packet exactly. Full native review:0 errors,1285 required,1 reviewed,1284 open. Bounded case:1 required,1 reviewed,0 open. Global missing/ambiguous references and cycles:0. Actual stdout/stderr/exit codes and byte hashes are retained.

The original two-edge rejection and its sealed files remain unchanged. No Main/source/quality/config/index/HEAD changes, source/placement/P/Kind/D/Human/M7/adoption approval or publication.
