#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import subprocess,json,hashlib,datetime
from pathlib import Path
B=Path(__file__).resolve().parent;R=B.parents[2];records=[]
commands=[('prepare',['./node_modules/.bin/tsx','scripts/prepareCrossSubjectRequiresProposal.ts','--ledger','tmp/cross-subject-requires/ideal-gas-minimal-successor-author-root-20261014-v1/author-ledger.unbound.inert.json','--output','tmp/cross-subject-requires/ideal-gas-minimal-successor-independent-peer-20261014-v1/reprepared-author-proposal.receipted.native.json']),('validate',['./node_modules/.bin/tsx','../tmp/cross-subject-requires/ideal-gas-minimal-successor-independent-peer-20261014-v1/native-independent-validation.mts'])]
for name,cmd in commands:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,cwd=R/'app',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 for stream,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
  out=B/f'native-{name}.{stream}.log';assert not out.exists();out.write_bytes(raw)
 records.append({'name':name,'argv':cmd,'cwd':str(R/'app'),'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'stdout':{'path':str((B/f'native-{name}.stdout.log').relative_to(R)),'bytes':len(p.stdout),'sha256':'sha256:'+hashlib.sha256(p.stdout).hexdigest(),'text':p.stdout.decode()},'stderr':{'path':str((B/f'native-{name}.stderr.log').relative_to(R)),'bytes':len(p.stderr),'sha256':'sha256:'+hashlib.sha256(p.stderr).hexdigest(),'text':p.stderr.decode()}})
 if p.returncode:break
receipt=B/'native-command-execution.actual.json';assert not receipt.exists();receipt.write_text(json.dumps({'commands':records,'allExitedZero':all(x['exitCode']==0 for x in records),'actualSubprocessCapturedStreams':True},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'commands':[{'name':x['name'],'exitCode':x['exitCode'],'stdoutBytes':x['stdout']['bytes'],'stderrBytes':x['stderr']['bytes']} for x in records],'lastStdout':records[-1]['stdout']['text']}))
raise SystemExit(0 if all(x['exitCode']==0 for x in records) and len(records)==2 else 1)
