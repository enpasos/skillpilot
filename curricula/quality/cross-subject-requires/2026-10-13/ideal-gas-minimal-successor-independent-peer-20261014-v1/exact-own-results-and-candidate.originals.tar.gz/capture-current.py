#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import json,hashlib,subprocess
from pathlib import Path
B=Path(__file__).resolve().parent;R=B.parents[2]
A=B.parent/'ideal-gas-minimal-successor-author-root-20261014-v1'
OLD=B.parent/'remaining18-independent-science-peer-20261014-v1'
G='cd1903a5-d70a-5320-9124-b6b24917ba14';V='57fbbf31-9b8c-5408-9af5-fbc73acd12bb';U='f2e42af5-67a6-477e-82ea-e65b09cc6cb3';E='54148506-c23f-41b8-959b-068dd194cf15'
def read(p):return json.loads((R/p).read_text())
def bind(p):
 p=Path(p);p=p if p.is_absolute() else R/p;raw=p.read_bytes()
 return {'path':str(p.relative_to(R)),'bytes':len(raw),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()}
def dump(name,x):
 p=B/name
 if p.exists():raise RuntimeError('Refuse overwrite')
 p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
cfgpath='curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
cfg=read(cfgpath);goals={};profiles={};owners={};files={cfgpath:bind(cfgpath)}
physics=set()
for s in cfg['subjects']:
 if s['subject'] not in ['mathematik','physik']:continue
 files[s['landscapePath']]=bind(s['landscapePath'])
 for g in read(s['landscapePath'])['goals']:
  goals[g['id']]=g
  if s['subject']=='physik':physics.add(g['id'])
 for cp in s['positiveEvidenceConfigPaths']:
  pc=read(cp);rp=pc['reviewPath'];scope=set(pc['scope'].get('goalIds',[]))
  for n,line in enumerate((R/rp).read_text().splitlines(),1):
   row=json.loads(line);gid=row['goalId']
   if gid not in scope:continue
   assert gid not in profiles
   profiles[gid]=row['profile'];owners[gid]={'config':bind(cp),'reviewFile':bind(rp),'line':n,'lineSha256':'sha256:'+hashlib.sha256(line.encode()).hexdigest(),'status':row['status'],'authority':row['reviewAuthority']}
invpath='curricula/quality/cross-subject-requires/math-physics.inventory.json';inv=read(invpath)
occ={g['goalId']:next(o for o in g['occurrences'] if o['selected']) for f in inv['families'] for g in f['goals'] if any(o['selected'] for o in g['occurrences'])}
adj={gid:[(k.split(':')[-1],'effective_requires') for k in inv['effectivePrerequisiteSets'][o['effectiveRequiresRef']]]+[(k.split(':')[-1],'contains_of_required_cluster') for k in goals[gid].get('contains',[])] for gid,o in occ.items() if gid in goals}
def paths(start):
 seen={start:[]};queue=[start]
 for node in queue:
  for to,kind in adj.get(node,[]):
   if to not in seen:seen[to]=seen[node]+[{'from':node,'to':to,'kind':kind}];queue.append(to)
 return seen
closure=paths(G);pids=[gid for gid in closure if gid in physics and gid!=G]
selected=list(dict.fromkeys([G,V,U,E]+pids))
for gid in selected:
 if gid in owners:
  for key in ['config','reviewFile']:files[owners[gid][key]['path']]=owners[gid][key]
root=read(A/'whole-current-and-own-solved-work.json')
assert goals[G]==root['unchangedWholeGoal'];assert profiles[G]==root['unchangedWholeP']
old=read(OLD/'actual-current-whole-reader.private.json')['records'][16]
assert old['goal']==goals[G] and old['profile']==profiles[G]
for pid in [V,E]:
 n=next(p for p in old['prospectiveWholePrerequisites'] if p['goalId']==pid)
 assert goals[pid]==n['goal'] and profiles[pid]==n['profile']
assert bind(A/'native-proposal.bound.inert.json')['sha256']=='sha256:87d343f9922c78f8ca88f8e7ceb17d6e7cd84cf0a02bff5bd5aeed204895445d'
d=read(A/'native-proposal.bound.inert.json')['decisions'][0]
assert d['prerequisiteGoalIds']==[V] and d['reviewInput']==occ[G]['reviewInput']
assert d['proposalBinding']['baselineRequires']==goals[G]['requires']
assert d['proposalBinding']['proposedRequires']==goals[G]['requires']+[V]
source=[]
def contains(v,body):
 if isinstance(v,dict):return v==body or any(contains(w,body) for w in v.values())
 if isinstance(v,list):return any(contains(w,body) for w in v)
 return False
def verify(path,body):
 assert contains(read(path),body),(path,body.get('id'));files[path]=bind(path)
for sr in old['sources']['refreshedSourceRecords']:
 verify(sr['sourceFile']['path'],sr['wholeCurrentRecord']);source.append(sr)
nomold=read(B.parent/'remaining18-whole-science-author-20261014-v1/nominee-whole-reader.current.inert.json')
nomsource=[]
for pid in [V,U,E]:
 row=next(n for n in nomold['records'] if n['goalId']==pid)
 assert row['wholeGoal']==goals[pid] and row['wholePositiveProfile']==profiles[pid]
 for ss in row['explicitCurrentSourceSelection']:
  for w in ss['wholeMappingRows']:verify(ss['mappingFile']['path'],w)
  for w in ss['wholeSourceGoals']+ss['wholePassages']:verify(ss['sourceFile']['path'],w)
 nomsource.append({'goalId':pid,'sources':row['explicitCurrentSourceSelection']})
for ref in d['sourceRefs']:files[ref['path']]=bind(ref['path'])
for p in [invpath,'curricula/quality/cross-subject-requires/math-physics.config.json']:files[p]=bind(p)
dump('actual-whole-current-reader.private.json',{'goalId':G,'wholeBodies':[{'goalId':gid,'goal':goals[gid],'profile':profiles.get(gid),'owner':owners.get(gid),'occurrence':occ[gid]} for gid in selected],'allGoalAndPExactToCurrentMain':True,'missingActiveProfileMeaning':'Orientation nodes outside active curricular positive-evidence selection have profile=null; no mathematical competency inferred from them.','physicsBaselineClosureGoalIds':pids,'baselineCandidatePaths':{pid:closure.get(pid) for pid in [V,U,E]},'volumeToEquationPath':paths(V).get(E),'unitsToEquationPath':paths(U).get(E),'physicalSourceObjects':source,'mathNomineeSourceObjects':nomsource,'sourceObjectsVerifiedAsCurrent':True,'sourceObjectsAreNotApproval':True})
dump('input-bindings.before.json',{'gitHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'files':list(files.values()),'authorFiles':[bind(p) for p in sorted(A.rglob('*')) if p.is_file()],'priorReviewFiles':[bind(p) for p in sorted(OLD.rglob('*')) if p.is_file()]})
print(json.dumps({'wholeCurrentBodies':len(selected),'baselinePhysicsBodies':len(pids),'baselineNomineePaths':{pid:closure.get(pid) for pid in [V,U,E]},'volumeToEquationForwardPath':paths(V).get(E),'boundInputFiles':len(files),'failures':0}))
