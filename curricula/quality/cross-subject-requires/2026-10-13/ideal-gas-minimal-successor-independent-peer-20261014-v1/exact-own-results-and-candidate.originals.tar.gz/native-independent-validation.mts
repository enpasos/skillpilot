// SPDX-License-Identifier: Apache-2.0
import {readFileSync,writeFileSync,existsSync} from 'node:fs'
import {resolve} from 'node:path'
import {buildRequiresInventory,assertFreshRequiresInventory,bytesFingerprint,fingerprint,stableJson,readActiveLandscapes} from '../../../app/scripts/lib/crossSubjectRequiresInventory.ts'
import {validateRequiresDecisions} from '../../../app/scripts/lib/crossSubjectRequiresReview.ts'
import {buildCrossLandscapeGraph,findCrossLandscapeCycles} from '../../../app/scripts/lib/crossLandscapeGraph.ts'
const repo=resolve(process.cwd(),'..')
const b='tmp/cross-subject-requires/ideal-gas-minimal-successor-independent-peer-20261014-v1'
const a='tmp/cross-subject-requires/ideal-gas-minimal-successor-author-root-20261014-v1/native-proposal.bound.inert.json'
const read=(p:string)=>JSON.parse(readFileSync(resolve(repo,p),'utf8'))
const write=(p:string,v:unknown)=>writeFileSync(resolve(repo,b,p),JSON.stringify(v,null,2)+'\n',{flag:'wx'})
const raw=readFileSync(resolve(repo,a));const packet=JSON.parse(raw.toString())
if(bytesFingerprint(raw)!=='sha256:87d343f9922c78f8ca88f8e7ceb17d6e7cd84cf0a02bff5bd5aeed204895445d')throw new Error('Root author proposal changed')
const reprepared=readFileSync(resolve(repo,b,'reprepared-author-proposal.receipted.native.json'))
const firstPrepared=readFileSync(resolve(repo,b,'reprepared-author-proposal.native.json'))
if(!raw.equals(reprepared)||!raw.equals(firstPrepared))throw new Error('Native re-preparation not byte-exact')
const config=read('curricula/quality/cross-subject-requires/math-physics.config.json')
const invpath='curricula/quality/cross-subject-requires/math-physics.inventory.json';const inv=read(invpath)
const fresh=buildRequiresInventory(repo,config);const invsha=assertFreshRequiresInventory(fresh,resolve(repo,invpath))
const review=read(b+'/native-independent-review.unbound.inert.json');const d=packet.decisions[0]
const goal='cd1903a5-d70a-5320-9124-b6b24917ba14';const volume='57fbbf31-9b8c-5408-9af5-fbc73acd12bb';const units='f2e42af5-67a6-477e-82ea-e65b09cc6cb3';const equation='54148506-c23f-41b8-959b-068dd194cf15'
if(d.prerequisiteGoalIds.length!==1||d.prerequisiteGoalIds[0]!==volume)throw new Error('Unexpected successor set')
review.decisions=review.decisions.map((r:any)=>({...r,proposalBindingSha256:fingerprint(d.proposalBinding)}))
const opts={familyIds:['canonical-gymnasium'],sourcePathExists:(p:string)=>existsSync(resolve(repo,p)),independentReview:review,authorLedgerSha256:bytesFingerprint(raw),inventorySha256:invsha}
const actual=validateRequiresDecisions(inv,packet,opts)
if(actual.errors.length||actual.reviewed!==1)throw new Error('Native full-inventory review failed: '+actual.errors.join(';'))
const selected={...inv,families:inv.families.map((f:any)=>({...f,goals:f.goals.map((g:any)=>({...g,reviewRequired:g.goalId===goal}))}))}
const bounded=validateRequiresDecisions(selected,packet,{...opts,requireComplete:true})
if(bounded.errors.length||bounded.required!==1||bounded.reviewed!==1||bounded.open!==0)throw new Error('Native bounded case failed')
const landscapes=readActiveLandscapes(repo,{...config,excludedDirectories:['quality']})
const baseline=buildCrossLandscapeGraph(landscapes)
const canonicalPaths=new Set(config.families[0].paths)
const modified=landscapes.map(l=>({...l,goals:l.goals.map(g=>g.id===goal&&canonicalPaths.has(l.file)?{...g,requires:d.proposalBinding.proposedRequires}:g)}))
const graph=buildCrossLandscapeGraph(modified)
const refs=graph.diagnostics.filter(x=>['missing_reference','ambiguous_reference'].includes(x.code));const cycles=findCrossLandscapeCycles(graph)
if(refs.length||cycles.length)throw new Error('Invalid proposed global graph')
function path(g:any,from:string,to:string){
 const s=g.owners.get(from)?.find((n:any)=>canonicalPaths.has(n.file));const t=g.owners.get(to)?.find((n:any)=>canonicalPaths.has(n.file))
 if(!s||!t)throw new Error('Missing canonical owner')
 const seen=new Map<string,any[]>([[s.key,[]]]);const queue=[s.key]
 for(const k of queue){
  if(k===t.key)return seen.get(k)
  const edges=[...(g.effectiveRequires.get(k)??[]).map((v:string)=>({to:v,kind:'effective_requires'})),...(g.contains.get(k)??[]).map((v:string)=>({to:v,kind:'contains_of_required_cluster'}))]
  for(const e of edges)if(!seen.has(e.to)){seen.set(e.to,[...seen.get(k)!,{from:k,...e}]);queue.push(e.to)}
 }
 return null
}
const paths={baselineToVolume:path(baseline,goal,volume),baselineToUnits:path(baseline,goal,units),baselineToEquation:path(baseline,goal,equation),volumeToEquation:path(graph,volume,equation),proposedToVolume:path(graph,goal,volume),proposedToEquation:path(graph,goal,equation)}
if(paths.baselineToVolume!==null||paths.baselineToUnits!==null||paths.baselineToEquation!==null)throw new Error('Unexpected existing baseline nominee path')
if(paths.volumeToEquation?.length!==2||!paths.proposedToVolume||!paths.proposedToEquation)throw new Error('Expected minimal forward chain not reproduced')
const occurrence=(id:string)=>inv.families.flatMap((f:any)=>f.goals).find((g:any)=>g.goalId===id).occurrences.find((o:any)=>o.selected)
const bindings=[goal,volume,units,equation].map(id=>({goalId:id,actualCurrentReviewInput:occurrence(id).reviewInput,actualDirectRequires:occurrence(id).directRequires,actualScope:occurrence(id).scope,technicalRole:occurrence(id).technicalRole,semanticKind:occurrence(id).semanticKind}))
if(stableJson(occurrence(goal).reviewInput)!==stableJson(d.reviewInput))throw new Error('Current proposal binding stale')
write('native-independent-review.bound.inert.json',review)
write('native-directed-minimality.actual.json',{paths,bindings,semantics:'Forward effective requires plus contains descendants of a required cluster only; no inverse mastery or reverse dependency inference.'})
write('native-independent-validation.actual.json',{authorProposalSha256:bytesFingerprint(raw),repreparedAuthorSha256:bytesFingerprint(reprepared),nativeRepreparationByteExact:true,currentInventorySha256:invsha,inventoryRebuiltAndFresh:true,fullNativeReview:actual,boundedOneCaseNativeReview:bounded,globalProposedGraph:{missingReferences:refs.filter(x=>x.code==='missing_reference').length,ambiguousReferences:refs.filter(x=>x.code==='ambiguous_reference').length,cycles:cycles.length},exactCurrentBindings:bindings,independentScienceApprovedSeparately:read(b+'/independent-scientific-verdict.actual.json').scientificVerdict==='approved',nativeZeroErrorsAloneNotApproval:true,sourcePKindDHumanM7AdoptionApproval:false})
console.log(JSON.stringify({nativeErrors:actual.errors.length,fullNativeRequired:actual.required,fullNativeReviewed:actual.reviewed,fullNativeOpen:actual.open,boundedOneCase:bounded,nativeRepreparationByteExact:true,missingReferences:refs.length,globalCycles:cycles.length,forwardVolumeToEquation:paths.volumeToEquation.map((p:any)=>({from:p.from.split(':').at(-1),to:p.to.split(':').at(-1),kind:p.kind}))}))
