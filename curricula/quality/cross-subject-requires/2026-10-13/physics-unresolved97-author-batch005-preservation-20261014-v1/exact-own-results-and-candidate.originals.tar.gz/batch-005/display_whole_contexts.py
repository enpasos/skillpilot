import json,sys
from pathlib import Path
j=json.loads(Path('tmp/cross-subject-requires/gymnasium-unresolved97-informed-reader-20261013-v1/informed-batch-005.json').read_text())
for n in map(int,sys.argv[1:]):
 r=j['records'][n-81];w=r['wholeCurrentGoalAndPositiveBody'];g=w['wholeCurrentCanonicalGoal']
 print(json.dumps({'index':n,'goal':{k:v for k,v in g.items() if k not in ['resourceLinks','dimensionTags','tags','weight','shortKey','semanticAtomic','type']},'wholeP':w['positiveBodyOwner']['wholePositiveProfile'],'history':[{'bindingRole':h['originalBinding']['role'],'authorReason':h['wholeOriginalProposal']['rationale'],'authorDecision':h['wholeOriginalProposal']['decision'],'authorNominees':h['wholeOriginalProposal']['prerequisiteGoalIds'],'wholeReviewReason':h['wholeOriginalIndependentReview']['rationale'],'reviewVerdict':h['wholeOriginalIndependentReview']['decision'],'Psuitability':h['wholeOriginalIndependentReview'].get('positiveEvidenceReview',{}).get('suitabilityRationale')} for h in r['originalIndependentHistory']],'distinctDissent':r['unresolvedDistinctFourthBatchDissent']},ensure_ascii=False))
