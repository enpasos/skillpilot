import json,sys
from pathlib import Path
allr=[r for sub in ['mathematik','physik'] for r in json.loads(Path('tmp/cross-subject-requires/gymnasium-whole-positive-body-review-inputs-20261013-v1',sub,'whole-goals-and-positive-profiles.current.json').read_text())['records']]
for prefix in sys.argv[1:]:
 r=next(r for r in allr if r['goalId'].startswith(prefix));g=r['wholeCurrentCanonicalGoal']
 print(json.dumps({'wholeGoal':{k:v for k,v in g.items() if k not in ['resourceLinks','dimensionTags','tags','weight','shortKey','semanticAtomic','type']},'wholeP':r['positiveBodyOwner']['wholePositiveProfile']},ensure_ascii=False))
