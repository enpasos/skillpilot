# SPDX-License-Identifier: Apache-2.0
"""Actual own synthetic calculations and aperture amplitude model. No experiment."""
import cmath,datetime,json,math
from pathlib import Path
B=Path(__file__).parent
def near(a,b):return math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-12)
def aperture(u,weighted=False,N=20000):
    # Midpoint quadrature of actual independently summed aperture amplitudes.
    zs=[-1+(j+.5)*2/N for j in range(N)]
    weights=[1-abs(z) if weighted else 1 for z in zs]
    a=sum(w*cmath.exp(1j*math.pi*u*z) for z,w in zip(zs,weights))/sum(weights)
    return {'u':u,'sampleCount':N,'weight':'triangular1-abs(z)' if weighted else 'uniform','normalizedAmplitude':[a.real,a.imag],'normalizedIntensity':abs(a)**2}
h=6.63e-34;me=9.11e-31;e=1.6e-19
aperture_models=[aperture(0),aperture(1),aperture(1.4303),aperture(1,True)]
photo_f=3e8/450e-9
def electron(U):
 p=math.sqrt(2*me*e*U);lam=h/p
 return {'U_V':U,'p_kg_m_s':p,'lambda_m':lam,'radii_m':[lam*.10/d for d in [.20e-9,.12e-9]]}
freq=1/(2*math.pi*math.sqrt(.012*3e-6))
A=[1.98,1.99,2,2.01,2.02]*2;C=[1.940,1.960,1.980,2,2.020]*2
probes={
81:[{'gaps_eV':[-3-(-8),-1-(-8)],'emitted_eV':-3-(-8)}, {'allowedIntegerL':3==int(3),'fractionalNotAllowed':2.5!=int(2.5)}],
82:[{'spacings_V':[12.4-7.2,17.6-12.4],'conservativeBounds_V':[5.2-.2,5.2+.2]}, {'offsets_V':[8.1-7.2,13.3-12.4,18.5-17.6],'newSpacings_V':[13.3-8.1,18.5-13.3]}],
83:[{'sinusoidalAmplitude_V':40*.003*200,'period_s':2*math.pi/200}, {'smoothExtrema_s':[-math.sqrt(.02),math.sqrt(.02)],'smoothExtrema_V':[-2*math.sqrt(.02)*math.exp(-.5),2*math.sqrt(.02)*math.exp(-.5)],'cornerOneSidedDerivative_Wb_s':[-.001,.001]}],
84:[{'opticalChange_m':18*500e-9,'mirrorChange_m':18*500e-9/2,'phaseChange_rad':36*math.pi}, {'opticalChange_m':24*500e-9,'indexChange':24*500e-9/.05,'badDoublePass':24*500e-9/(2*.05)}],
85:[{'f_Hz':photo_f,'E_J':h*photo_f,'p_kg_m_s':h/(450e-9)}, {'p_kg_m_s':2*h/(450e-9),'lambda_m':h/(2*h/(450e-9)),'E_J':2*h*photo_f,'f_Hz':2*photo_f}],
86:[{'energies_Wh':[10*3,40*3],'ratio':40/10}, {'loss_W':15-12,'eta':12/15,'maximumWater_W':12}],
87:[{'slope_cm_g':1.8/80,'at120_prediction_cm':1.8/80*120,'residual_cm':2.8-1.8/80*120}, {'meanTenCycleTimes_s':[(9+9.2)/2,(13.5+13.7)/2,(18+18.2)/2],'meanPeriods_s':[(9+9.2)/20,(13.5+13.7)/20,(18+18.2)/20],'periodReadLimit_s':.2/10}],
88:[{'k_m_inv':2*math.pi/.6,'omega_s_inv':2*math.pi*3,'v_m_s':.6*3,'s_origin_m':.04}, {'lambda_m':2*math.pi/(5*math.pi),'f_Hz':12*math.pi/(2*math.pi),'phaseVelocity_m_s':-12/5,'shiftedPhase_rad':5*math.pi*.1-math.pi/6}],
89:[electron(4000),electron(9000)],
90:[{'sigma_C_m2':[6e-9/.003,-6e-9/.003],'sigmaDoubleArea':6e-9/.006}, {'Q_C':-4e-6*.005,'otherSigma_C_m2':15e-9/.005}],
91:[{'RC_s':2000*.5e-6,'fc_Hz':1/(2*math.pi*2000*.5e-6),'HC':[1/math.sqrt(1+r*r) for r in [.2,1,5]],'HR':[r/math.sqrt(1+r*r) for r in [.2,1,5]]}, {'input_V':2,'lowOutputC_V':2/math.sqrt(1.04),'lowOutputR_V':.4/math.sqrt(1.04),'squaredMagnitudeSums':[(1/math.sqrt(1+r*r))**2+(r/math.sqrt(1+r*r))**2 for r in [.2,1,5]]}],
92:[{'boxGaps_eV':[3*3.4,5*3.4],'hydrogenGaps_eV':[-13.6/4+13.6,-13.6/9+13.6/4]}, {'finiteIonizationPossible':5>=4,'finiteBoxEscapePossible':False}],
93:[{'A_kg':15*.18,'B_kg':[5*.35,5*.70],'factorThreshold':15*.18/5}, {'years5_kg':[200+120*.3*5,380+70*.3*5],'years20_kg':[200+120*.3*20,380+70*.3*20],'breakEvenYears':(380-200)/((120-70)*.3)}],
94:[{'LC_s2':.012*3e-6,'sqrtLC_s':math.sqrt(.012*3e-6),'f_Hz':freq,'T_s':1/freq,'omega_s_inv':2*math.pi*freq}, {'newLC_s2':(.012/3)*(3*3e-6),'energyVoltageFactor':2**2}],
95:[{'depths_m':[1500*t/2 for t in [40e-6,100e-6]]}, {'axialLengths_mm':[1500*t/2*1000 for t in [1e-6,.3e-6]],'hypotheticalEchoAmplitudes':[.40,.05]}],
96:[{'firstMinima_m':[-2*500e-9/.00025,2*500e-9/.00025],'centralWidth_m':4*500e-9/.00025,'sideLocation_m':1.4303*2*500e-9/.00025,'sideIntensity':(math.sin(math.pi*1.4303)/(math.pi*1.4303))**2,'uniformActualModels':aperture_models[:3]}, {'halfWidthCentral_m':4*500e-9/.000125,'weightedActualModel':aperture_models[3]}],
97:[{'rulerEstimate_mm':84,'stipulatedUncertainty_mm':.5,'range_mm':[83.5,84.5]}, {'seriesA_s':A,'seriesB_s':C,'means_s':[sum(A)/len(A),sum(C)/len(C)],'halfRanges_s':[(max(A)-min(A))/2,(max(C)-min(C))/2]}]
}
checks={
'BohrPositiveDirection':probes[81][0]['gaps_eV']==[5,7],
'FranckHertzSpacingInvariant':all(near(v,5.2) for v in probes[82][0]['spacings_V']+probes[82][1]['newSpacings_V']),
'FranckHertzOffsetAll':all(near(v,.9) for v in probes[82][1]['offsets_V']),
'PulseCornerDerivativeDifferent':probes[83][1]['cornerOneSidedDerivative_Wb_s'][0]!=probes[83][1]['cornerOneSidedDerivative_Wb_s'][1],
'MichelsonTwoPass':near(2*probes[84][0]['mirrorChange_m'],probes[84][0]['opticalChange_m']),
'GasCellDimensionlessReconstruction':near(probes[84][1]['indexChange']*.05,probes[84][1]['opticalChange_m']),
'PhotonEnergyMomentum':near(probes[85][0]['E_J']/probes[85][0]['p_kg_m_s'],3e8),
'SourceBoundaryLoss':near(15,probes[86][1]['loss_W']+12),
'PendulumNonproportional':not near(.91/.2,1.81/.8),
'ShiftedWavePhase':near(probes[88][1]['shiftedPhase_rad'],math.pi/3),
'ElectronVoltageRootRatio':near(probes[89][1]['p_kg_m_s']/probes[89][0]['p_kg_m_s'],1.5),
'ElectronWavelengthInverse':near(probes[89][1]['lambda_m']/probes[89][0]['lambda_m'],2/3),
'DensityReconstruction':near(probes[90][1]['Q_C']/.005,-4e-6),
'FilterComplementaryPowerMagnitude':all(near(v,1) for v in probes[91][1]['squaredMagnitudeSums']),
'BoxVsCoulombOppositeTrends':probes[92][0]['boxGaps_eV'][1]>probes[92][0]['boxGaps_eV'][0] and probes[92][0]['hydrogenGaps_eV'][1]<probes[92][0]['hydrogenGaps_eV'][0],
'ClimateOrderingReverses':probes[93][1]['years5_kg'][0]<probes[93][1]['years5_kg'][1] and probes[93][1]['years20_kg'][0]>probes[93][1]['years20_kg'][1],
'ThomsonProductConstant':near(probes[94][0]['LC_s2'],probes[94][1]['newLC_s2']),
'UltrasoundPulseHalfPath':near(probes[95][0]['depths_m'][0],.03),
'UniformApertureCenter':near(aperture_models[0]['normalizedIntensity'],1),
'UniformApertureCancellation':aperture_models[1]['normalizedIntensity']<1e-20,
'ActualApertureSideMatchesSinc':abs(aperture_models[2]['normalizedIntensity']-probes[96][0]['sideIntensity'])<1e-8,
'ChangedWeightRemovesUniformZero':aperture_models[3]['normalizedIntensity']>.16,
'UncertaintyMeanAndSpread':near(probes[97][1]['means_s'][0],2) and near(probes[97][1]['means_s'][1],1.98) and near(probes[97][1]['halfRanges_s'][0],.02) and near(probes[97][1]['halfRanges_s'][1],.04)
}
errors=[k for k,v in checks.items() if not v]
report={'role':'OWN INFORMED AUTHOR','checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'positions81to97':probes,'probeCount':34,'actualApertureModels':4,'actualApertureMethod':'20000 independently summed complex amplitudes at midpoint samples per model; normalized uniform/triangular weights','meaningfulConsistencyChecks':checks,'errors':errors,'noExperimentOrIndependentApprovalCreated':True}
p=B/'thirtyfour-fresh-author-probe-calculations-and-aperture-model.actual.json'
if p.exists():raise RuntimeError('Refuse overwrite')
p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'freshSolvedProbes':34,'actualApertureModels':4,'checks':len(checks),'errors':errors}));raise SystemExit(bool(errors))
