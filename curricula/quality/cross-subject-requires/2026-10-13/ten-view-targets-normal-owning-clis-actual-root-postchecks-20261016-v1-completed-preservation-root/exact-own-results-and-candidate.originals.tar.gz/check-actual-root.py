"""Bounded normal owning CLI checks of the fifteen actually adopted postimages.
SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime, timezone
import errno
import hashlib
import json
import os
import subprocess

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
A = R / 'tmp/cross-subject-requires/ten-view-targets-and-empty-math-test-actual-adoption-root-20261016-v1'
N = R / 'tmp/ci-tools/node-v20.20.2-linux-x64/bin/node'
LOADER = R / 'app/node_modules/tsx/dist/loader.mjs'
INDEX = '6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8'


def now():
    return datetime.now(timezone.utc).isoformat()


def bind(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(R)), 'bytes': len(raw),
            'sha256': 'sha256:' + hashlib.sha256(raw).hexdigest()}


def read(path):
    return json.loads(path.read_text())


def write(name, value):
    with (O / name).open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def verify_actual_postimages():
    product = read(A / 'ADOPTION.actual.json')
    status = read(A / 'NORMAL-GENERATED-STATUS-ADOPTION.actual.json')
    assert product['actualProductFiles'] == 11 and len(product['files']) == 11
    assert product['existingMathViewsChanged'] == 10 and product['newTests'] == 1
    assert len(status['normalGeneratedStatusFilesAdopted']) == 4
    rows = [*product['files'], *status['normalGeneratedStatusFilesAdopted']]
    actual = []
    for row in rows:
        current = bind(R / row['actual']['path'])
        assert current == row['actual'], (current, row['actual'])
        adopted_from = row.get('candidate', row.get('normalGeneratorOutput'))
        assert current['sha256'] == adopted_from['sha256']
        assert current['bytes'] == adopted_from['bytes']
        actual.append(current)
    assert len({row['path'] for row in actual}) == 15
    assert hashlib.sha256((R / '.git/index').read_bytes()).hexdigest() == INDEX
    return actual


commands = [
    ('normal-composition-views', 'validateCompositionViews.ts', []),
    ('normal-math-scope-coverage', 'reportCanonicalMathScopeCoverage.ts', []),
    ('normal-source-coverage-check', 'generateCurriculumSourceCoverageAudit.ts', ['--check']),
    ('normal-full21-quality-status-check', 'generateCurriculumQualityStatus.ts', ['--check']),
    ('normal-ten-protected-maturity-floors', 'checkCurriculumMaturityFloors.ts', []),
    ('normal-active-cross-subject-inventory-check', 'generateCrossSubjectRequiresInventory.ts', ['--check']),
]
assert Path.cwd().resolve() == O
assert os.statvfs(R).f_flag & os.ST_RDONLY
assert not os.statvfs(O).f_flag & os.ST_RDONLY
postimages_before = verify_actual_postimages()
probe_paths = [R / '.git/index', *[R / row['path'] for row in postimages_before],
               *[R / 'app/scripts' / name for _, name, _ in commands],
               R / 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json',
               R / 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json']
probes = []
for path in probe_paths:
    try:
        with path.open('ab') as stream:
            stream.write(b'')
        raise AssertionError('Root path unexpectedly writable: ' + str(path))
    except OSError as error:
        assert error.errno == errno.EROFS, (str(path), error.errno)
        probes.append({'path': str(path.relative_to(R)), 'errno': error.errno})
node_version = subprocess.run([N, '--version'], check=True, capture_output=True, text=True).stdout.strip()
assert node_version == 'v20.20.2'
script_bindings = [bind(R / 'app/scripts' / name) for _, name, _ in commands]
write('PREFLIGHT.actual.json', {
    'recordedUTC': now(), 'actualRootNoSourceOverlays': True,
    'mounts': {'rootReadonly': True, 'onlyRepositoryWritableLane': str(O.relative_to(R)),
               'ephemeralSystemMounts': ['/tmp', '/proc', '/dev']},
    'readonlyProbes': probes, 'adoptedPostimagesVerified': postimages_before,
    'adoptionManifests': [bind(A / 'ADOPTION.actual.json'), bind(A / 'NORMAL-GENERATED-STATUS-ADOPTION.actual.json')],
    'owningCliSources': script_bindings, 'nodeVersion': node_version, 'node': bind(N),
    'tsxLoader': bind(LOADER), 'RootIndexSha256': INDEX,
    'bwrap': bind(R / 'tmp/ci-tools/hermetic-consumer-tools-20261015-v1/root/usr/bin/bwrap'),
})
results = []
for label, name, args in commands:
    argv = [str(N), '--import', str(LOADER), str(R / 'app/scripts' / name), *args]
    stdout_path = O / (label + '.stdout.txt')
    stderr_path = O / (label + '.stderr.txt')
    started = now()
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        result = subprocess.run(argv, cwd=R / 'app', env=dict(os.environ, GIT_OPTIONAL_LOCKS='0',
                                TSX_DISABLE_CACHE='1', TMPDIR=str(O)), stdout=stdout, stderr=stderr)
    receipt = {'label': label, 'argv': argv, 'cwd': 'app', 'startedUTC': started,
               'completedUTC': now(), 'exitCode': result.returncode,
               'stdout': bind(stdout_path), 'stderr': bind(stderr_path),
               'actualAdoptedRootSources': True, 'sourceOverlays': [],
               'generatedDefaultsWritten': False, 'productionSourcesReadonly': True}
    write(label + '.execution.actual.json', receipt)
    results.append(receipt)
    print(label, result.returncode, flush=True)
    if result.returncode:
        print(stderr_path.read_text()[-4000:], flush=True)

postimages_after = verify_actual_postimages()
assert postimages_before == postimages_after
assert script_bindings == [bind(R / 'app/scripts' / name) for _, name, _ in commands]
quality = read(R / 'docs/qa-ci/status/curriculum-quality-status.json')
assert len(quality['curricula']) == 21
policy = read(R / 'app/scripts/config/curriculum-maturity-floor-policy.json')
assert len(policy['floors']) == 10
bounded_subjects = [{'subject': row['subject'], 'landscapeId': row['landscapeId'], 'maturity': row['maturity']}
                    for row in quality['curricula'] if row['subject'] in ('Mathematik', 'Physik')]
summary = {'recordedUTC': now(), 'scope': 'canonical Gymnasium Math/Physics; normal registered owning CLI checks',
           'actualRootNoSourceOverlays': True, 'adoptedProductPostimagesExact': 11,
           'normalGeneratedStatusPostimagesExact': 4, 'all15PostimagesUnchangedAfterChecks': True,
           'normalOwningCliChecks': results, 'allSixPass': all(row['exitCode'] == 0 for row in results),
           'fullRegisteredQualityCurricula': len(quality['curricula']), 'protectedMaturityFloors': len(policy['floors']),
           'boundedCanonicalSubjectStatus': bounded_subjects, 'RootIndexSha256BeforeAndAfter': INDEX,
           'sourceStatusVerifierOrPolicyWrites': False, 'defaultRegeneration': False,
           'newScientificHumanHostOrLearnerAcceptance': False, 'fullCIOrGoalComplete': False,
           'harnessOnlyFixes': []}
write('ACTUAL-ROOT-NORMAL-POSTCHECKS.actual.json', summary)
write('HANDOFF.actual.json', {
    'recordedUTC': now(), 'scope': summary['scope'], 'role': 'read-only actual-Root normal owning CLI postchecks',
    'authoritativeReceipts': [bind(O / 'PREFLIGHT.actual.json'), bind(O / 'ACTUAL-ROOT-NORMAL-POSTCHECKS.actual.json')],
    'allSixPass': summary['allSixPass'], 'all15AdoptedPostimagesExactBeforeAndAfter': True,
    'RootIndexSha256': INDEX, 'actualRootNoSourceOverlays': True, 'fullCIOrGoalComplete': False,
})
sealed_paths = sorted(path for path in O.iterdir() if path.is_file() and path.name != 'SEAL.actual.json')
write('SEAL.actual.json', {'sealedUTC': now(), 'files': [bind(path) for path in sealed_paths],
                          'scope': 'only this bounded verification lane; no source/cache copies',
                          'fullCIOrGoalComplete': False})
for path in [*sealed_paths, O / 'SEAL.actual.json']:
    path.chmod(0o444)
print(json.dumps({'allSixPass': summary['allSixPass'], 'HANDOFF': bind(O / 'HANDOFF.actual.json'),
                  'SEAL': bind(O / 'SEAL.actual.json')}, indent=2), flush=True)
raise SystemExit(0 if summary['allSixPass'] else 1)
