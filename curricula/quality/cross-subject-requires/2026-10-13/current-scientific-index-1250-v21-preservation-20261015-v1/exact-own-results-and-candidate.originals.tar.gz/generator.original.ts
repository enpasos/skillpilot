// SPDX-License-Identifier: Apache-2.0
import { readFileSync, mkdirSync, writeFileSync, existsSync } from 'node:fs'
import { basename, resolve } from 'node:path'
import { bytesFingerprint, fingerprint, stableJson } from '../../app/scripts/lib/crossSubjectRequiresInventory'
import { validateRequiresDecisions } from '../../app/scripts/lib/crossSubjectRequiresReview'

const root = resolve(process.cwd())
const sourceDir = 'curricula/quality/cross-subject-requires/2026-10-13/canonical-review-candidates'
const output = 'tmp/cross-subject-requires/canonical-gymnasium-effective-review-index-20261015-v21'
// Additive technical successor. Only run after the root operator explicitly completes actual Main adoption.
mkdirSync(resolve(root, output), { recursive: true })
const inputs = new Map<string, { path: string; sha256: string; bytes: number }>()
function read(path: string): any {
  const raw = readFileSync(resolve(root, path))
  inputs.set(path, { path, sha256: bytesFingerprint(raw), bytes: raw.length })
  return JSON.parse(raw.toString('utf8'))
}
const operationGate = read(`${output}/actual-Main-operation-gate.json`)
if (operationGate.actualMainAdoptionComplete !== true || operationGate.finalGenerationAuthorizedByRoot !== true)
  throw new Error('Actual Main adoption and root final-generation signal required; no private result may be labelled current Main')
const inventoryPath = 'curricula/quality/cross-subject-requires/math-physics.inventory.json'
const inventory = read(inventoryPath)
const family = inventory.families.find((f: any) => f.familyId === 'canonical-gymnasium')
if (!family || inventory.families.length !== 1) throw new Error('Expected Gymnasium-only inventory')
const currentGoals = new Map<string, any>(family.goals.filter((g: any) => g.reviewRequired).map((g: any) => [g.goalId, g]))
const landscapeGoals = new Map<string, { subject: string; goal: any }>()
for (const [subject, suffix] of [['mathematics', 'MATHEMATIK'], ['physics', 'PHYSIK']]) {
  const landscape = read(`curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_${suffix}.de.json`)
  for (const goal of landscape.goals) landscapeGoals.set(goal.id, { subject, goal })
}
const artifactIndex = read(`${sourceDir}/artifact-index.json`)
const archiveBindings = new Map<string, any>(artifactIndex.artifacts.map((a: any) => [a.storedPath, a]))
// Read actual current owner files, not an earlier selected-review audit.
const registryPath = 'curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
const registry = read(registryPath)
const jsonlCache = new Map<string, any[]>()
function readJsonl(path: string): any[] {
  if (jsonlCache.has(path)) return jsonlCache.get(path)!
  const raw = readFileSync(resolve(root, path))
  inputs.set(path, { path, sha256: bytesFingerprint(raw), bytes: raw.length })
  const values = raw.toString('utf8').split(/\r?\n/).filter(l => l.trim()).map(l => JSON.parse(l))
  jsonlCache.set(path, values)
  return values
}
const currentOwners = new Map<string, any[]>()
for (const subject of registry.subjects.filter((s: any) => ['mathematik', 'physik'].includes(s.subject))) {
  for (const path of subject.positiveEvidenceConfigPaths) {
    const config = read(path)
    if (!Array.isArray(config.scope?.goalIds)) throw new Error(`Explicit P-owner scope missing: ${path}`)
    const profiles = readJsonl(config.reviewPath)
    for (const goalId of config.scope.goalIds) {
      if (!currentGoals.has(goalId)) continue
      const matches = profiles.filter((p: any) => p.goalId === goalId)
      if (matches.length !== 1) throw new Error(`Expected one P record in owner: ${path}:${goalId}`)
      const record = matches[0]
      const owners = currentOwners.get(goalId) ?? []
      owners.push({ config: inputs.get(path), review: inputs.get(config.reviewPath),
        profileBodySha256: fingerprint(record.profile), profileFingerprint: record.profileFingerprint,
        completeRecordSha256: fingerprint(record) })
      currentOwners.set(goalId, owners)
    }
  }
}
for (const goalId of currentGoals.keys()) {
  if (currentOwners.get(goalId)?.length !== 1) throw new Error(`Exactly one current P owner required: ${goalId}`)
}
function selectedPositiveBinding(decision: any, record: any, role: string) {
  const owners = currentOwners.get(decision.dependentGoalId)!
  const p = record.positiveEvidenceReview
  const conditionalBody = record.proposedProfileBodySha256 ?? p?.exactProposedProfileBodySha256
    ?? decision.profileAmendmentProposedBodySha256 ?? null
  const originalBody = record.oldNativeProfileBodySha256 ?? p?.currentProfileBodySha256
    ?? decision.nativeProfileRead?.profileBodySha256 ?? null
  const directFingerprint = p?.profileFingerprint ?? record.currentWholePositiveEvidenceBinding?.profileFingerprint
    ?? decision.currentWholePositiveEvidenceBinding?.profileFingerprint ?? null
  const directBody = record.currentWholePositiveEvidenceBinding?.wholeCurrentProfileBodySha256
    ?? decision.currentWholePositiveEvidenceBinding?.wholeCurrentProfileBodySha256 ?? null
  const conditionalSatisfied = conditionalBody ? owners.every(o => o.profileBodySha256 === conditionalBody) : null
  // A proposed body is deliberately different from the author's old/current P.
  // Its explicit condition controls; old direct bindings remain recorded as history.
  const directMatches = directFingerprint ? owners.every(o => o.profileFingerprint === directFingerprint) : null
  const directBodyMatches = directBody ? owners.every(o => o.profileBodySha256 === directBody) : null
  const binding: any = { selectedExplicitProposedProfileBodySha256: conditionalBody,
    originalProfileBodySha256: originalBody,
    actualCurrentOwners: owners,
    explicitConditionalProfileSatisfied: conditionalSatisfied,
    originalProfileStillActive: originalBody ? owners.some(o => o.profileBodySha256 === originalBody) : null,
    explicitDirectProfileFingerprint: directFingerprint, explicitDirectProfileFingerprintMatches: directMatches,
    explicitDirectProfileBodySha256: directBody, explicitDirectProfileBodyMatches: directBodyMatches,
    explicitSelectedProfileBindingSatisfied: conditionalBody ? conditionalSatisfied : directMatches !== false && directBodyMatches !== false,
    absenceOfAnExplicitProfileConditionDoesNotCreateNewWholeBodyScientificApproval: true }
  if (role === 'self-induction41-two-exact-current-whole-Goal-P-independent-peer' || role === 'five-existing-math45-exact-current-whole-Goal-P-independent-peer' || role === 'eye-current-exact-whole-Goal-P-independent-peer') {
    const authorCondition = decision.positiveEvidenceCondition
    const peerCondition = record.positiveEvidenceCondition
    if (!authorCondition || !peerCondition || (role === 'five-existing-math45-exact-current-whole-Goal-P-independent-peer'
      ? Object.keys(authorCondition).some(key => stableJson(authorCondition[key]) !== stableJson(peerCondition[key]))
      : stableJson(authorCondition) !== stableJson(peerCondition)))
      throw new Error(`Fresh exact whole Goal/P condition missing or divergent: ${decision.dependentGoalId}`)
    for (const field of ['wholeGoalStableJsonSha256', 'wholeProfileStableJsonSha256', 'profileFingerprint'])
      if (typeof authorCondition[field] !== 'string' || !authorCondition[field].startsWith('sha256:'))
        throw new Error(`Fresh exact whole Goal/P condition missing ${field}: ${decision.dependentGoalId}`)
    const actualGoalBodySha256 = fingerprint(landscapeGoals.get(decision.dependentGoalId)!.goal)
    const goalMatches = actualGoalBodySha256 === authorCondition.wholeGoalStableJsonSha256
    const bodyMatches = owners.every(o => o.profileBodySha256 === authorCondition.wholeProfileStableJsonSha256)
    const fpMatches = owners.every(o => o.profileFingerprint === authorCondition.profileFingerprint)
    Object.assign(binding, {
      explicitDirectProfileFingerprint: authorCondition.profileFingerprint,
      explicitDirectProfileFingerprintMatches: fpMatches,
      explicitDirectProfileBodySha256: authorCondition.wholeProfileStableJsonSha256,
      explicitDirectProfileBodyMatches: bodyMatches,
      explicitSelectedProfileBindingSatisfied: goalMatches && bodyMatches && fpMatches,
      exactWholeGoalCondition: { sourceField: 'positiveEvidenceCondition',
        authorAndIndependentPeerConditionsExact: true,
        requiredWholeGoalStableJsonSha256: authorCondition.wholeGoalStableJsonSha256,
        actualWholeGoalStableJsonSha256: actualGoalBodySha256, currentWholeGoalMatches: goalMatches,
        requiresNativeProposalBindingAlsoChecked: true },
    })
  }
  return binding
}

const pairs: any[] = []
const histories = new Map<string, any[]>()
function addPair(reviewName: string, role: string, authorOverride?: string) {
  const reviewPath = (reviewName.startsWith('tmp/') || reviewName.startsWith('curricula/')) ? reviewName : `${sourceDir}/${reviewName}`
  const review = read(reviewPath)
  const authorPath = authorOverride ?? `${sourceDir}/${basename(review.candidatePacketPath)}`
  const author = read(authorPath)
  if (inputs.get(authorPath)!.sha256 !== review.authorLedgerSha256) throw new Error(`Author binding mismatch: ${reviewName}`)
  for (const path of [reviewPath, authorPath]) {
    const historical = archiveBindings.get(path)
    if (historical && historical.sha256 !== inputs.get(path)!.sha256) throw new Error(`Archive drift: ${path}`)
  }
  const technical = validateRequiresDecisions(inventory, author, {
    familyIds: ['canonical-gymnasium'], independentReview: review,
    authorLedgerSha256: inputs.get(authorPath)!.sha256,
    inventorySha256: inputs.get(inventoryPath)!.sha256,
    reviewedInventorySha256: author.baselineInventorySha256 ?? review.inventorySha256,
    sourcePathExists: path => existsSync(resolve(root, path)),
  })
  pairs.push({ role, author: inputs.get(authorPath), review: inputs.get(reviewPath),
    historicalInventorySha256: review.inventorySha256,
    currentTechnicalValidation: technical })
  const authors = new Map<string, any>(author.decisions.map((a: any) => [a.decisionId, a]))
  for (let i = 0; i < review.decisions.length; i++) {
    const record = review.decisions[i]
    const decision = authors.get(record.decisionId)
    if (!decision) throw new Error(`Missing exact author decision: ${record.decisionId}`)
    const current: any = currentGoals.get(decision.dependentGoalId)
    if (!current) throw new Error(`Outside canonical curricular scope: ${record.decisionId}`)
    const baselineMatches = current.occurrences.some((o: any) => o.selected && stableJson(o.reviewInput) === stableJson(decision.reviewInput))
    const proposedMatches = !!decision.proposalBinding && current.occurrences.some((o: any) => o.selected
      && stableJson(o.reviewInput) === stableJson(decision.proposalBinding.proposed)
      && stableJson(o.directRequires) === stableJson(decision.proposalBinding.proposedRequires))
    const decisionErrors = technical.errors.filter((e: string) => e.includes(decision.dependentGoalId))
    const globalErrors = technical.errors.filter((e: string) => ![...currentGoals.keys()].some(id => e.includes(id)))
    const approvedBindings = record.decision === 'approved'
      && ['add', 'retain', 'remove', 'replace', 'no_cross_subject_required'].includes(decision.decision)
      && decision.applicability?.universality === 'allDependentScopes' && record.rationale?.trim()
      && stableJson(record.reviewInput) === stableJson(decision.reviewInput)
      && (!decision.proposalBinding || record.proposalBindingSha256 === fingerprint(decision.proposalBinding))
      && record.reviewer?.trim() && record.reviewer.trim().toLowerCase() !== decision.author?.trim().toLowerCase()
      && decisionErrors.length === 0 && globalErrors.length === 0 && (baselineMatches || proposedMatches)
    const item = {
      role, decisionId: decision.decisionId, dependentGoalId: decision.dependentGoalId,
      authorPath, authorSha256: inputs.get(authorPath)!.sha256,
      reviewPath, reviewSha256: inputs.get(reviewPath)!.sha256, reviewRecordIndex: i,
      independentScientificVerdict: record.decision,
      requiresDecision: decision.decision, proposedForeignPrerequisiteIds: decision.prerequisiteGoalIds,
      originalReviewInput: decision.reviewInput, currentMatchesBaseline: baselineMatches,
      currentMatchesProposed: proposedMatches, technicallyCurrentApprovedBinding: !!approvedBindings,
      technicalErrors: [...globalErrors, ...decisionErrors],
      positiveEvidenceBodyBinding: selectedPositiveBinding(decision, record, role),
      nativeQualityOrAdoptionApprovalCreated: false,
    }
    const existing = histories.get(decision.dependentGoalId) ?? []
    existing.push(item)
    histories.set(decision.dependentGoalId, existing)
  }
}
addPair('math-reverse-807.parallel-independent-review.json', 'primary')
for (let batch = 1; batch <= 7; batch++) {
  const n = String(batch).padStart(3, '0')
  const name = batch <= 3 ? `physics-batch-${n}.independent-review.json`
    : batch === 6 ? 'physics-batch-006-corrected-author.parallel-independent-review.json'
      : `physics-batch-${n}.parallel-independent-review.json`
  addPair(name, 'primary')
}
addPair('physics-batch-004.independent-review.json', 'distinct-fourth-batch-peer')
for (const name of [
  'physics-batch-001-six-revised-v2-after-action-validation.independent-review.json',
  'physics-batch-002-resolved-three-v2.independent-review.json',
  'physics-batch-002-thermo-two-v2.independent-review.json',
  'physics-pending20-revision-author-v1.parallel-independent-review.json',
  'physics-energy-gradient-revision-author-20261013-v2.parallel-independent-review.json',
  'physics-pending5-revision-author-20261013-v3.parallel-independent-review.json',
  'physics-clausius-revision-author-20261013-v4.parallel-independent-review.json',
]) addPair(name, 'revision-history')

addPair("tmp/cross-subject-requires/physics-unresolved97-first20-informed-independent-requires-review-20261013-v1/native-independent-requires-review.inert.json", "unresolved97-whole-body-successor-peer", "tmp/cross-subject-requires/physics-unresolved97-whole-body-successor-author-20261013-v1/batch-001-v2/native-proposal")
addPair("tmp/cross-subject-requires/physics-unresolved97-second20-informed-independent-requires-review-20261013-v1/native-independent-requires-review.inert.json", "unresolved97-whole-body-successor-peer", "tmp/cross-subject-requires/physics-unresolved97-whole-body-successor-author-20261013-v1/batch-002-v2/native-proposal")
addPair("tmp/cross-subject-requires/physics-unresolved97-third20-informed-independent-requires-review-20261013-v1/native-independent-requires-review.inert.json", "unresolved97-whole-body-successor-peer", "tmp/cross-subject-requires/physics-unresolved97-whole-body-successor-author-20261013-v1/batch-003-final-v1/native-proposal")
addPair("tmp/cross-subject-requires/physics-unresolved97-fourth20-informed-independent-requires-review-20261014-v1/native-independent-requires-review.inert.json", "unresolved97-whole-body-successor-peer", "tmp/cross-subject-requires/physics-unresolved97-whole-body-successor-author-20261013-v1/batch-004-final-v1/native-proposal")
addPair("tmp/cross-subject-requires/physics-unresolved97-last17-informed-independent-requires-review-20261013-v1/native-independent-requires-review.inert.json", "unresolved97-whole-body-successor-peer", "tmp/cross-subject-requires/physics-unresolved97-whole-body-successor-author-20261013-v1/batch-005-final-v1/native-proposal")

addPair("tmp/cross-subject-requires/remaining18-independent-science-peer-20261014-v1/native-independent-review.bound.inert.json", "remaining18-whole-body-successor-peer", "tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/native-proposal.bound.inert.json")

addPair("tmp/cross-subject-requires/ideal-gas-minimal-successor-independent-peer-20261014-v1/native-independent-review.bound.inert.json", "ideal-gas-minimal-successor-peer", "tmp/cross-subject-requires/ideal-gas-minimal-successor-author-root-20261014-v1/native-proposal.bound.inert.json")

addPair("tmp/cross-subject-requires/physics72-whole-positive-independent-supplement-20261014-v1/all72-native-independent-review.inert.json", "physics72-current-whole-body-supplement-peer", "tmp/cross-subject-requires/physics-whole-positive-coverage-intake-root-20261014-v1/72-native-proposal.bound.inert.json")

addPair('curricula/quality/cross-subject-requires/2026-10-13/eight-scope-guard-successor-independent-peer-20261014-v1/eight-scope-guard.requires.native-independent-review.json', 'adopted-eight-current-semantic-scope-peer', 'curricula/quality/cross-subject-requires/2026-10-13/portable-eight-scope-guard-successor-author-20261014-v1/native-output/eight-scope-guard.requires.bound.json')

addPair('curricula/quality/cross-subject-requires/2026-10-13/p72-fifteen-after-peer-independent-science-20261014-v1/fresh-native-independent-review.bound.actual.json', 'P72-fifteen-fresh-current-one-approved-peer', 'tmp/cross-subject-requires/p72-fifteen-after-peer-successor-author-20261014-v1/fifteen-current-native.bound.inert.json')

addPair('tmp/cross-subject-requires/approved-existing-math-edges-independent-current-P-Kind-technical-peer-20261014-v1/f47-whole-f2-requires.native-independent-review.pending.json', 'fresh-f47-whole-competence-scope-dissent', 'tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/native-proposal.bound.inert.json')

addPair('curricula/quality/cross-subject-requires/2026-10-13/approved-existing-math-nine-safe-subset-independent-peer-20261015-v1/nine-current.requires.native-independent-review.json', 'actually-adopted-nine-fresh-current-whole-Goal-P-peer', 'tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/native-proposal.bound.inert.json')
addPair('curricula/quality/cross-subject-requires/2026-10-13/fresh-fifteen-current-Goal-P-independent-peer-20261015-v1/native-independent-fifteen.bound.actual.json', 'fresh-fifteen-current-whole-Goal-P-peer', 'curricula/quality/cross-subject-requires/2026-10-13/fresh-fifteen-stale-current-Goal-P-author-root-20261015-v1/fifteen-current-author.native-bound.inert.json')

addPair('curricula/quality/cross-subject-requires/2026-10-13/gravity-corrected-P-fresh-requires-independent-peer-20261015-v1/gravity-corrected-current-P.requires.native-independent-review.json', 'fresh-gravity-corrected-current-P-peer', 'curricula/quality/cross-subject-requires/2026-10-13/gravity-corrected-P-fresh-requires-author-root-20261015-v1/fresh-requires.author.native-bound.json')

addPair('curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/broad-fivea-two-owner-portable-v1/requires/two-current.requires.portable-metadata-independent-review.json', 'two-current-whole-P-negative-minimality-peer-portable-successor', 'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/broad-fivea-two-owner-portable-v1/requires/two-current-author.portable.native-bound.json')

addPair('curricula/quality/cross-subject-requires/2026-10-13/ideal-gas-direct-guard-whole-P-independent-peer-20261015-v2/native-independent-review.bound.inert.json', 'fresh-ideal-gas-direct-guard-whole-P-pending-peer', 'curricula/quality/cross-subject-requires/2026-10-13/ideal-gas-direct-guard-minimality-successor-root-20261015-v2/native-proposal.bound.inert.json')

addPair('curricula/quality/cross-subject-requires/2026-10-13/two-local-assessments-and-current68-fresh-independent-peer-20261015-v1/68c90.native-independent-review.actual.json', 'fresh68-current-active-whole-P-no-additional-direct-math-peer', 'curricula/quality/cross-subject-requires/2026-10-13/68c90-current-whole-P-requires-successor-author-root-20261015-v1/fresh-author.native-bound.inert.json')

// Additive exact successor. Only these seven actually reviewed goals receive this role.
const releasedSevenRole = 'released87-seven-math-exact-current-whole-Goal-P-independent-peer'
const releasedSevenGoalIds = new Set([
  '3e53a39b-1c75-4034-a647-8de85719e1fb', 'fc047e6e-5d6d-460f-99fc-ade3a23b9a8e',
  'f2e42af5-67a6-477e-82ea-e65b09cc6cb3', '7156558c-57f1-4372-9ba7-0640c3f7cb3a',
  '42e19186-6769-41ac-a7bf-ab39bdb50661', '3010d965-b9b9-4dc5-9d04-d706725e9a30',
  '3c1d6ce7-099e-4267-9ff2-3d1526209a89',
])
addPair('curricula/quality/cross-subject-requires/2026-10-13/released87-seven-math-current-requires-independent-root-20261015-v1/seven-current.requires.native-independent-review.actual.json', releasedSevenRole,
  'curricula/quality/cross-subject-requires/2026-10-13/seven-math-released87-current-requires-author-20261015-v1/seven.requires-author.native-bound.actual.json')
const actualReleasedSevenIds = [...histories].filter(([, history]) => history.some(h => h.role === releasedSevenRole)).map(([id]) => id)
if (stableJson([...releasedSevenGoalIds].sort()) !== stableJson(actualReleasedSevenIds.sort())) throw new Error('Fresh successor must bind exactly the declared seven goals')

// New scientific inputs are imported byte-exact. Only their two goal IDs may select this role.
const selfInductionRole = 'self-induction41-two-exact-current-whole-Goal-P-independent-peer'
const selfInductionGoalIds = new Set(['37f28bc4-def2-57cf-a06b-191dfd228205', '692db5b6-8be1-5c7b-8307-3a02afb21ea0'])
const selfInductionPrefix = 'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/self-induction-current-portable-v1/current-owner-integration-v1'
addPair(`${selfInductionPrefix}/Requires/two-goal-current-owner-independent-peer-v001.json`, selfInductionRole,
  `${selfInductionPrefix}/Requires/two-goal-current-owner-author-v002.bound.json`)
const actualSelfInductionIds = [...histories].filter(([, h]) => h.some(r => r.role === selfInductionRole)).map(([id]) => id)
if (stableJson([...selfInductionGoalIds].sort()) !== stableJson(actualSelfInductionIds.sort()))
  throw new Error('Fresh successor must bind exactly the two approved self-induction goals')
if (inputs.get(`${selfInductionPrefix}/Requires/two-goal-current-owner-author-v002.bound.json`)!.sha256 !== 'sha256:026d07c979de18570a5b496efefc6c7db91d7b9bee44958fbe48e9c797f722e0'
  || inputs.get(`${selfInductionPrefix}/Requires/two-goal-current-owner-independent-peer-v001.json`)!.sha256 !== 'sha256:4feb72ef57b44d946fe3ef3510f62af7d31bab0d0dbe385f245b121486552ad5')
  throw new Error('Fresh two-goal native author or genuine peer source drift')

// Five separately reviewed actual current successors; no source approval is manufactured here.
const fiveExistingRole = 'five-existing-math45-exact-current-whole-Goal-P-independent-peer'
const fiveExistingGoalIds = new Set(['09029573-864f-40ca-bf8a-cee7bf6dcb73', '1b7e800a-1c0d-5faa-886b-7ef2f3b8348c', '215f5558-562c-5686-b649-931f324c7983', 'b2fb9a25-4d26-5cf2-a917-823909dcb6bd', 'd18d4190-ddc1-5181-b1b6-e79947b737c2'])
const fiveExistingPrefix = 'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/five-existing-math-current-portable-v1'
addPair(`${fiveExistingPrefix}/Requires/five-portable-independent-peer.v2.json`, fiveExistingRole,
  `${fiveExistingPrefix}/Requires/five-portable-author.native-bound.json`)
const actualFiveExistingIds = [...histories].filter(([, h]) => h.some(r => r.role === fiveExistingRole)).map(([id]) => id)
if (stableJson([...fiveExistingGoalIds].sort()) !== stableJson(actualFiveExistingIds.sort())) throw new Error('Fresh portable successor must bind exactly the five genuinely reviewed goals')
if (inputs.get(`${fiveExistingPrefix}/Requires/five-portable-author.native-bound.json`)!.sha256 !== 'sha256:2236b88543a11f9254bf3c0dba767a0b3f8657d6156f5a9ab168e7e40184cf69'
  || inputs.get(`${fiveExistingPrefix}/Requires/five-portable-independent-peer.v2.json`)!.sha256 !== 'sha256:f60a21841096b4fb52c44102345b37a1cf53f4caa65427dbfef0c16e2ebda49a') throw new Error('Exact portable five author/peer bytes drifted')

const statusOverlayPath = `${sourceDir}/physics-pending20-plus-energy-v2.current-status-after-clausius-v4.json`
const overlay = read(statusOverlayPath)
const exactOverlay = new Map<string, any>()
for (const record of overlay.effectiveDecisions) {
  if (inputs.get(record.reviewPath)?.sha256 !== record.reviewSha256) throw new Error(`Overlay review mismatch: ${record.dependentGoalId}`)
  const exact = histories.get(record.dependentGoalId)?.find(r => r.reviewPath === record.reviewPath && r.independentScientificVerdict === record.decision)
  if (!exact) throw new Error(`Missing overlay decision: ${record.dependentGoalId}`)
  exactOverlay.set(record.dependentGoalId, exact)
}
const eyeRole = 'eye-current-exact-whole-Goal-P-independent-peer'
const eyeGoalId = '90e1e6cf-4092-41d6-81f7-5206f9d68f84'
addPair('tmp/cross-subject-requires/eye-current-no-extra-math-native-independent-code-peer-20261015-v1/one-current-eye.native-independent-review.inert.json', eyeRole, 'tmp/cross-subject-requires/eye-current-no-extra-math-native-author-root-20261015-v1/one-current-eye.author.native-bound.inert.json')
const exactEyeHistory = histories.get(eyeGoalId)!.filter(h => h.role === eyeRole)
if(exactEyeHistory.length !== 1 || !exactEyeHistory[0].technicallyCurrentApprovedBinding || !exactEyeHistory[0].positiveEvidenceBodyBinding.explicitSelectedProfileBindingSatisfied) throw new Error('The one fresh Eye record is not independently current for the exact whole Goal/P')
const adoptionPath = 'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-13/physics-first10-v1/adoption-state.json'
const adoption = read(adoptionPath)
const adopted = new Set<string>(adoption.goalIds)
const currentPConditions = read('tmp/cross-subject-requires/current-active-positive-body-binding-audit-root-20261015-v1/full-current-owner-and-selected-profile-binding-audit.actual.json')
// Historical v10-selected audit retained intact; current conditions are computed per newly selected record.
const records: any[] = []
for (const [goalId, current] of currentGoals) {
  const history = histories.get(goalId) ?? []
  if (!history.length) throw new Error(`Missing whole-goal decision history: ${goalId}`)
  const primary = history.find(h => h.role === 'primary')
  if (!primary) throw new Error(`Missing primary decision: ${goalId}`)
  const peer = history.find(h => h.role === 'distinct-fourth-batch-peer')
  const explicitRevision = history.filter(h => h.role === eyeRole).at(-1)
    ?? (fiveExistingGoalIds.has(goalId) ? history.filter(h => h.role === fiveExistingRole).at(-1) : undefined)
    ?? (selfInductionGoalIds.has(goalId) ? history.filter(h => h.role === selfInductionRole).at(-1) : undefined)
    ?? (releasedSevenGoalIds.has(goalId) ? history.filter(h => h.role === releasedSevenRole).at(-1) : undefined)
    ?? history.filter(h => h.role === 'fresh68-current-active-whole-P-no-additional-direct-math-peer').at(-1)
    ?? history.filter(h => h.role === 'fresh-ideal-gas-direct-guard-whole-P-pending-peer').at(-1)
    ?? history.filter(h => h.role === 'two-current-whole-P-negative-minimality-peer-portable-successor').at(-1)
    ?? history.filter(h => h.role === 'fresh-gravity-corrected-current-P-peer').at(-1)
    ?? history.filter(h => h.role === 'fresh-fifteen-current-whole-Goal-P-peer').at(-1)
    ?? history.filter(h => h.role === 'actually-adopted-nine-fresh-current-whole-Goal-P-peer').at(-1)
    ?? history.filter(h => h.role === 'fresh-f47-whole-competence-scope-dissent').at(-1)
    ?? history.filter(h => h.role === 'adopted-eight-current-semantic-scope-peer').at(-1)
    ?? history.filter(h => h.role === 'P72-fifteen-fresh-current-one-approved-peer').at(-1)
    ?? history.filter(h => h.role === 'physics72-current-whole-body-supplement-peer').at(-1)
    ?? history.filter(h => h.role === 'ideal-gas-minimal-successor-peer').at(-1)
    ?? history.filter(h => h.role === 'remaining18-whole-body-successor-peer').at(-1)
    ?? history.filter(h => h.role === 'unresolved97-whole-body-successor-peer').at(-1)
    ?? exactOverlay.get(goalId)
    ?? history.filter(h => h.role === 'revision-history').at(-1)
  const selected = explicitRevision ?? primary
  const source = landscapeGoals.get(goalId)!
  const foreign = (source.goal.requires ?? []).filter((id: string) => landscapeGoals.get(id)?.subject !== source.subject)
  const fourthBatchDissent = !!peer && peer.independentScientificVerdict !== primary.independentScientificVerdict
  records.push({
    goalId, subject: source.subject, title: source.goal.title,
    selectedRecord: selected, selectionBasis: exactOverlay.has(goalId) ? 'explicit preserved twenty-goal current overlay'
      : explicitRevision ? 'later exact revision of this same goal; originals preserved' : 'primary exact record',
    originalDecisionHistory: history,
    unresolvedDistinctFourthBatchDissent: fourthBatchDissent && (!explicitRevision || !explicitRevision.technicallyCurrentApprovedBinding),
    historicalDistinctFourthBatchVerdictsRemainSeparate: true,
    fourthBatchDisagreementReconciledHere: false,
    effectiveCurrentScientificBindingAccepted: selected.technicallyCurrentApprovedBinding && !(fourthBatchDissent && !explicitRevision)
      && selected.positiveEvidenceBodyBinding.explicitSelectedProfileBindingSatisfied,
    explicitReviewedProfileCondition: selected.positiveEvidenceBodyBinding,
    historicalEarlierSelectedPCondition: currentPConditions.records.find((r: any) => r.goalId === goalId)?.explicitConditionalBodySha256 ?? null,
    activeForeignRequires: foreign,
    firstTenAdoptionRecorded: adopted.has(goalId),
    firstTenAdoptionEvidence: adopted.has(goalId) ? inputs.get(adoptionPath) : null,
    otherNativeQualityOrAdoptionApprovedByThisIndex: false,
  })
}
if (records.length !== 1285 || records.filter(r => r.subject === 'mathematics').length !== 807
  || records.filter(r => r.subject === 'physics').length !== 478) throw new Error('Incorrect full Gymnasium coverage')
if (records.filter(r => r.effectiveCurrentScientificBindingAccepted).length !== 1250) throw new Error('Expected1250currentaccepted /35pending after exactEyeP-onlyadoption')
const count = (items: any[], field: string) => Object.fromEntries([...new Set(items.map(i => i[field]))].map(v => [String(v), items.filter(i => i[field] === v).length]))
const currentMainM7Path = operationGate.currentMainM7ReceiptPath
const currentMainM7ReportPath = operationGate.currentMainM7ReportPath
if (typeof currentMainM7Path !== 'string' || typeof currentMainM7ReportPath !== 'string')
  throw new Error('Root must supply current actual Main M7 evidence paths')
const currentMainM7 = read(currentMainM7Path)
const currentMainM7Report = read(currentMainM7ReportPath)
if (currentMainM7.actualMainExecution !== true || currentMainM7.exitCode !== 0 || currentMainM7Report.blockingIssueCount !== 0)
  throw new Error('Current actual Main M7 evidence is not passing')
const currentMainAdoption = read(operationGate.actualMainAdoptionReceiptPath)
const currentMainTargetManifest = read(operationGate.actualMainTargetManifestPath)
const physicsCompositionViews = operationGate.physicsCompositionViewPaths.map((path: string) => ({ path, view: read(path) }))
const mathIds = new Set([...landscapeGoals].filter(([, x]) => x.subject === 'mathematics').map(([id]) => id))
function supportCount(value: any): number {
  if (Array.isArray(value)) return value.reduce((n, v) => n + supportCount(v), 0)
  if (value && typeof value === 'object') return Number(value.projectionRole === 'prerequisiteOnly' && mathIds.has(value.goalId))
    + Object.values(value).reduce<number>((n, v) => n + supportCount(v), 0)
  return 0
}
const currentMathSupports = physicsCompositionViews.map(({ path, view }: any) => ({ file: inputs.get(path), count: supportCount(view) }))
if (currentMathSupports.length !== 69 || currentMathSupports.some((v: any) => v.count === 0))
  throw new Error('Expected exact 69 Physics composition views with authored Math supports')
const summary = {
  currentSelectedProfileConditions: {
    actualCurrentOrdinaryGoalsAndUniquePOwners: currentOwners.size,
    explicitProposedBodyConditions: records.filter(r => r.explicitReviewedProfileCondition.selectedExplicitProposedProfileBodySha256).length,
    unmetExplicitProposedBodyConditions: records.filter(r => r.explicitReviewedProfileCondition.explicitConditionalProfileSatisfied === false).length,
    directFingerprintOrBodyMismatchesWithoutProposedBodyCondition: records.filter(r => !r.explicitReviewedProfileCondition.selectedExplicitProposedProfileBodySha256 && !r.explicitReviewedProfileCondition.explicitSelectedProfileBindingSatisfied).map(r => r.goalId),
    computedFromEachSelectedExactAuthorPeerAndActualCurrentActiveP: true,
    fresh68CurrentActiveWholePExplicitBindingUsedInsteadOfEarlierPendingRecord: true,
    historicalV10SelectedTwentyConditionalBodiesRetainedUnchanged: inputs.get('tmp/cross-subject-requires/current-active-positive-body-binding-audit-root-20261015-v1/full-current-owner-and-selected-profile-binding-audit.actual.json'),
  },
  actualFreshFifteenIndependentPeer: read('curricula/quality/cross-subject-requires/2026-10-13/fresh-fifteen-current-Goal-P-independent-peer-20261015-v1/HANDOFF.actual.json'),
  fresh68CurrentActiveWholePScientificPeer: read('curricula/quality/cross-subject-requires/2026-10-13/two-local-assessments-and-current68-fresh-independent-peer-20261015-v1/HANDOFF.actual.json'),
  earlier68PendingWholePReviewsRemainUnchanged: true,
  actualNineAdoptedRequiresSets: 9, actualNineAddedDirectMathEdges: 10,
  actualCurrentActiveCrossSubjectReferences: records.reduce((n, r) => n + r.activeForeignRequires.length, 0),
  actualCurrentPhysicsGoalsWithForeignRequires: records.filter(r => r.subject === 'physics' && r.activeForeignRequires.length).length,
  actualCurrentReferencedMathGoals: new Set(records.flatMap(r => r.activeForeignRequires)).size,
  freshSingleRecordF47DissentSelectedWithoutCopyingOldOtherSeventeenVerdicts: true,
  conditional26PrivateMathContextReviewNotAppliedToMainBindings: read('curricula/quality/cross-subject-requires/2026-10-13/remaining26-scope-successors-independent-peer-20261014-v1/HANDOFF.json'),
  conditional26CurrentMainUnknownPrivateNomineeErrorsAreNotWaived: true,
  completeGoalBindingRequiresAllDependentScopesNotOnlyBoundedSubset: true,
  historicalEarlierCafThreeAdoption: read('tmp/cross-subject-requires/caf5-three-atomic-exact-main-adoption-root-20261014-v1/adoption.actual.json'),
  actualCurrentMainNativeM7: currentMainM7,
  actualCurrentMainNativeM7Report: currentMainM7Report ? { binding: inputs.get(currentMainM7ReportPath), blockingIssueCount: currentMainM7Report.blockingIssueCount } : null,
  historicalEarlierMainNativeM7: read('tmp/cross-subject-requires/two-minimality-exact-main-adoption-root-20261015-v1/actual-Main-native-M7.execution.actual.json'),
  historicalV18MainM7Receipt: read('tmp/cross-subject-requires/released87-exact-main-adoption-root-20261015-v1/actual-Main-M7-strict.v2.execution.actual.json'),
  selfInduction41HistoricalMainAdoption: read('curricula/quality/cross-subject-requires/2026-10-13/self-induction41-exact-main-adoption-root-20261015-v1/HANDOFF.actual.json'),
  currentRuntime43ActualMainAdoption: { receipt: inputs.get(operationGate.actualMainAdoptionReceiptPath), value: currentMainAdoption, targetManifest: inputs.get(operationGate.actualMainTargetManifestPath) },
  eyeCurrentPOnlyActualMainAdoption: read('tmp/cross-subject-requires/eye-current-P-five-exact-main-adoption-root-20261015-v1/adoption.actual.json'),
  eyeOneFreshCurrentScientificRecord: { goalId: eyeGoalId, role: eyeRole, newScientificJudgmentsCreatedHere: false, peer: read('tmp/cross-subject-requires/eye-current-no-extra-math-native-independent-code-peer-20261015-v1/HANDOFF.actual.json') },
  fiveExisting45FreshCurrentPairOnly: { goalIds: [...fiveExistingGoalIds], role: fiveExistingRole, newScientificJudgmentsCreatedHere: false },
  selfInduction41FreshTwoCurrentRequiresPairOnly: { goalIds: [...selfInductionGoalIds], role: selfInductionRole, newScientificJudgmentsCreatedHere: false },
  released87ActualLocalMainAdoption: read('tmp/cross-subject-requires/released87-exact-main-adoption-root-20261015-v1/adoption.actual.json'),
  released87FreshSevenCurrentRequiresPairOnly: { goalIds: [...releasedSevenGoalIds], role: releasedSevenRole, newScientificJudgmentsCreatedHere: false },
  actualCurrentMainLandscapeGoals: { mathematics: [...landscapeGoals.values()].filter(g => g.subject === 'mathematics').length, physics: [...landscapeGoals.values()].filter(g => g.subject === 'physics').length },
  actualCurrentTwoOwnerMinimalityAdoption: read('tmp/cross-subject-requires/two-minimality-exact-main-adoption-root-20261015-v1/HANDOFF.actual.json'),
  historicalFourSetsAdoption: read('curricula/quality/cross-subject-requires/2026-10-13/four-sets-exact-main-adoption-root-20261015-v1/HANDOFF.actual.json'),
  actualFourAddedDirectMathEdges: 7, actualFourChangedPhysicsRequiresSets: 4,
  actualCurrentAuthoredMathPrerequisiteOnlyReferences: currentMathSupports.reduce((n: number, v: any) => n + v.count, 0),
  actualCurrentMathSupportViews: currentMathSupports,
  actualCurrentP20Adoption: read('curricula/quality/cross-subject-requires/2026-10-13/twenty-P-exact-main-adoption-root-20261015-v1/HANDOFF.actual.json'),
  actualCurrentNineAdoption: read('tmp/cross-subject-requires/safe-nine-exact-main-adoption-root-20261015-v1/adoption.actual.json'),
  freshEightSemanticRequiresApprovalIsNotWholeGoalOrNationwideSourceAcceptance: true,
  schemaVersion: 'canonical-gymnasium-effective-scientific-review-index-v21', recordedAt: new Date().toISOString(),
  scope: 'Gymnasium Mathematik/Physik Sek I/II only', previousGoalTurn: "Technical index successor after actual Eye P-only adoption and accepted runtime43/CI source integration. Only Eye selects a new sealed independent whole-Goal/P/Kind/Requires scientific judgment; all1284 other selected scientific identities and previous verdicts remain historical and unchanged. Current P-owner files, exact complete profile conditions,45 references and4954 support declarations are recomputed from actual Main. Source/target/13newMath/fullCI/human/host acceptance is not created by this index.",
  currentInventory: inputs.get(inventoryPath), originalReviewInventoryHashesPreserved: true,
  fullGoalUniverse: { mathematics: 807, physics: 478, total: records.length },
  selectedScientificVerdicts: count(records.map(r => r.selectedRecord), 'independentScientificVerdict'),
  selectedRequiresDecisions: count(records.map(r => r.selectedRecord), 'requiresDecision'),
  currentScientificBindingAccepted: count(records, 'effectiveCurrentScientificBindingAccepted'),
  unresolvedFourthBatchDissent: records.filter(r => r.unresolvedDistinctFourthBatchDissent).map(r => r.goalId),
  recordedActiveFirstTenAdoptions: records.filter(r => r.firstTenAdoptionRecorded).length,
  originalVerdictsUnchangedAndNoSyntheticMergedPeerApproval: true, noActiveSourceChanges: true,
  new53PeerApprovalsRemainOriginalExactBoundRecords: true,
  remaining18ExactPeerApprovals: 17, remaining18ExactPeerRejections: 1,
  historicalOneEdgeIdealGasIndependentApprovalPreserved: 1,
  currentIdealGasSingleEdgeSufficiencyNotAccepted: true,
  freshIdealGasDirectGuardWholePPeer: read('curricula/quality/cross-subject-requires/2026-10-13/ideal-gas-direct-guard-whole-P-independent-peer-20261015-v2/HANDOFF.actual.json'),
  historicalMinimalIdealGasExactEarlierVerification: read("tmp/cross-subject-requires/ideal-gas-and-IV-P3-A-root-intake-20261014-v1/root-actual-exact-verification.json"),
  currentPeerSealAnd578InputVerification: read("tmp/cross-subject-requires/remaining18-root-intake-20261014-v1/actual-seal-and-current-input-verification.json"),
  reviewedAddProposalDoesNotProveActualEdgeAdoption: true,
  nativeGatesNotSatisfiedByScientificVerdicts: true,
  currentPhysics72WholePositiveSupplement: { total: 72, completedAndSealed: 72, remaining: 0, exactOriginalVerdicts: { approved: 57, rejected: 8, pending: 7 }, rootExactIntake: read('tmp/cross-subject-requires/physics72-final-dissent-followup-intake-root-20261014-v1/actual-seal-and-current-input-verification.json'), literalBriefsSolved: 173, ownFreshTransfersSolved: 72, fullMathComparisons: 13, actualScientificReaderAttribution: { mainIndependentPeer: 60, separatelyDelegatedIndependentLast12Peer: 12 }, earlierNegativeVerdictsRemainPreserved: true, dissentCasesRequireGenuineAuthorsAndIndependentSuccessors: 15 },
  wholePositiveBodyReviewExtent: {
    mathematicsPrimaryFullBodiesRead: 46,
    mathematicsSupplementalFullBodiesRead: 761,
    mathematicsPrimaryBodiesNotFullyRead: 0,
    total807CurrentWholeBodiesReadAcrossSeparateReviews: true,
    supplementalEvidence: read('tmp/cross-subject-requires/math-761-whole-positive-body-cross-requires-review-20261013-v1/whole-scope-761.final-audit.continuation-05.json'),
    evidence: 'math-reverse-807.parallel-independent-review.json nativePositiveReviewExtent',
    descriptionBasedScientificCoverageDoesNotProveWholeTaskBodyCoverage: true,
    physicsWholePositiveBodyCompletenessNotEstablishedByThisIndex: true,
  },
  licensing: { technicalEvidence: 'Apache-2.0', ownDidacticJudgments: 'CC-BY-4.0', originalGrantsPreserved: true },
}
for (const [name, value] of [['effective-goal-index.json', { ...summary, records }],
  ['pairwise-current-technical-validation.json', { pairs }], ['summary.json', summary],
  ['actual-read-bindings.json', [...inputs.values()]]]) {
  writeFileSync(resolve(root, output, name), JSON.stringify(value, null, 2) + '\n')
  JSON.parse(readFileSync(resolve(root, output, name), 'utf8'))
}
const freshness = [...inputs.values()].map(item => ({ ...item, unchangedAfterIndexBuild: bytesFingerprint(readFileSync(resolve(root, item.path))) === item.sha256 }))
if (freshness.some(f => !f.unchangedAfterIndexBuild)) throw new Error('Input drift during index build')
writeFileSync(resolve(root, output, 'actual-post-build-input-freshness.json'), JSON.stringify(freshness, null, 2) + '\n')
console.log(JSON.stringify({ total: records.length, selectedScientificVerdicts: summary.selectedScientificVerdicts, currentScientificBindingAccepted: summary.currentScientificBindingAccepted, historicalDissentStillOpenWithPendingCurrentDecision: summary.unresolvedFourthBatchDissent.length, noActiveSourceChanges: true }))
