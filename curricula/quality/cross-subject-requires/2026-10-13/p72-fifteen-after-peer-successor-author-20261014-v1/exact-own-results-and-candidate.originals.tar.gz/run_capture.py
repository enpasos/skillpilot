# SPDX-License-Identifier: Apache-2.0
import datetime, hashlib, json, pathlib, subprocess, sys
out=pathlib.Path(__file__).parent.resolve();root=pathlib.Path.cwd();tag=sys.argv[1];cwd=pathlib.Path(sys.argv[2]);argv=sys.argv[3:]
def sha(data):return 'sha256:'+hashlib.sha256(data).hexdigest()
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
paths=[root/'app/scripts/lib/crossSubjectRequiresInventory.ts',root/'app/scripts/lib/crossSubjectRequiresReview.ts',root/'app/scripts/positiveGoalEvidenceProfileModel.ts',root/'app/scripts/prepareCrossSubjectRequiresProposal.ts']
for arg in argv:
 for candidate in [root/arg,cwd/arg]:
  if candidate.is_file():paths.append(candidate.resolve())
before={str(p):sha(p.read_bytes()) for p in paths if p.is_file()}
r=subprocess.run(argv,cwd=cwd,capture_output=True)
(out/(tag+'.stdout.raw.txt')).write_bytes(r.stdout);(out/(tag+'.stderr.raw.txt')).write_bytes(r.stderr)
record={'argv':argv,'cwd':str(cwd.resolve()),'startUtc':started,'endUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'executedInputsAndNativeModulesSha256Before':before,'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr),'actualExecution':True}
(out/(tag+'.execution.actual.json')).write_text(json.dumps(record,indent=2)+'\n')
sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr)
raise SystemExit(r.returncode)
