import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { bytesFingerprint } from '../../../app/scripts/lib/crossSubjectRequiresInventory'
import { reviewPositiveGoalEvidenceConfig } from '../../../app/scripts/positiveGoalEvidenceReview'
const out=dirname(fileURLToPath(import.meta.url)),root=resolve(out,'../../..'),lens='078ce4d2-3193-4cd0-ae59-4fb8ab16e9e5'
const bindings:any[]=[]
const json=(path:string)=>{const bytes=readFileSync(resolve(root,path));bindings.push({path,bytes:bytes.length,sha256:bytesFingerprint(bytes)});return JSON.parse(bytes.toString('utf8'))}
const prior=json('tmp/cross-subject-requires/eye-model-current-P-successor-independent-code-peer-20261015-v1/own-read-materials.json').currentRegisteredP.find((x:any)=>x.record.goalId===lens)
const physics=json('curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json').subjects.find((x:any)=>x.subject==='physik')
const owners=physics.positiveEvidenceConfigPaths.filter((path:string)=>json(path).scope.goalIds.includes(lens))
assert.deepEqual(owners,[prior.configPath])
const config=json(owners[0]);assert.equal(config.reviewPath,prior.reviewPath)
for(const path of [config.reviewPath,config.landscapePath,config.semanticKindLedgerPath,config.reviewCriteriaPath]) {
 const bytes=readFileSync(resolve(root,path));bindings.push({path,bytes:bytes.length,sha256:bytesFingerprint(bytes)})
}
const result=reviewPositiveGoalEvidenceConfig(owners[0]);assert.deepEqual(result.errors,[])
const current=result.records.filter(x=>x.goalId===lens);assert.equal(current.length,1);assert.deepEqual(current[0],prior.record)
for(const b of bindings)assert.equal(bytesFingerprint(readFileSync(resolve(root,b.path))),b.sha256,'Concurrent source drift')
writeFileSync(resolve(out,'current-lens-P-recheck.json'),JSON.stringify({status:'PASS',goalId:lens,ownerConfig:owners[0],ownerReview:config.reviewPath,
  completeCurrentLensRecordExactlyEqualsPriorIndependentRead:true,nativeValidationErrors:result.errors,
  priorAndCurrentProfileFingerprint:current[0].profileFingerprint,statusUnchanged:current[0].status,authorityUnchanged:current[0].reviewAuthority,bindings},null,2)+'\n')
console.log('PASS complete actual registered Lens P equals prior whole-content read; native current P validation errors0.')
