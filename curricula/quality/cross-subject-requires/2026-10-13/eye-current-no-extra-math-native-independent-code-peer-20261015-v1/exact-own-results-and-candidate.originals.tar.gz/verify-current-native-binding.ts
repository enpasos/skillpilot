import assert from 'node:assert/strict'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { assertFreshRequiresInventory, buildRequiresInventory, bytesFingerprint, fingerprint, stableJson } from '../../../app/scripts/lib/crossSubjectRequiresInventory'
import { validateRequiresDecisions } from '../../../app/scripts/lib/crossSubjectRequiresReview'
import { reviewPositiveGoalEvidenceConfig } from '../../../app/scripts/positiveGoalEvidenceReview'
import { fingerprintGoalForPositiveEvidence, fingerprintPositiveGoalEvidenceProfile, fingerprintPositiveGoalEvidenceReviewInput } from '../../../app/scripts/positiveGoalEvidenceProfileModel'
import { fingerprintSemanticKindSourceGoal } from '../../../app/scripts/goalBookModel'

// A technical transport of this reviewer's prior sealed complete-content judgment.
// No author judgment is substituted for that independent scientific decision.
const out = dirname(fileURLToPath(import.meta.url)), root = resolve(out, '../../..')
const eye = '90e1e6cf-4092-41d6-81f7-5206f9d68f84', lens = '078ce4d2-3193-4cd0-ae59-4fb8ab16e9e5'
const authorPath = 'tmp/cross-subject-requires/eye-current-no-extra-math-native-author-root-20261015-v1/one-current-eye.author.native-bound.inert.json'
const inventoryPath = 'curricula/quality/cross-subject-requires/math-physics.inventory.json'
const previous = 'tmp/cross-subject-requires/eye-model-current-P-successor-independent-code-peer-20261015-v1/'
const bindings = new Map<string, {path:string;bytes:number;sha256:string}>()
function bytes(path:string) {
  const value=readFileSync(resolve(root,path));const binding={path,bytes:value.length,sha256:bytesFingerprint(value)}
  const before=bindings.get(path);if(before)assert.deepEqual(binding,before,'Input drift while reading '+path)
  bindings.set(path,binding);return value
}
const json=(path:string)=>JSON.parse(bytes(path).toString('utf8'))
const authorBytes=bytes(authorPath), author=JSON.parse(authorBytes.toString('utf8'))
const authorHash=bytesFingerprint(authorBytes)
assert.equal(authorHash,'sha256:4ed8e4251259949170a1cb747b356391c170352d64bab8b2984ccea72ad72032')
assert.equal(author.decisions.length,1)
const decision=author.decisions[0]
assert.equal(decision.dependentGoalId,eye);assert.equal(decision.decision,'no_cross_subject_required')
assert.deepEqual(decision.prerequisiteGoalIds,[])

const priorHandoff=json(previous+'HANDOFF.actual.json'), priorRead=json(previous+'own-read-materials.json')
assert.equal(priorHandoff.goalId,eye)
assert.equal(priorHandoff.scientificJudgment.additionalDirectMathPrerequisite.split('.')[0],'none')
assert.deepEqual(priorHandoff.scientificJudgment.Requires,[lens])
const currentConfig=json('curricula/quality/cross-subject-requires/math-physics.config.json')
const currentInventory=buildRequiresInventory(root,currentConfig)
bytes(inventoryPath)
const currentInventoryHash=assertFreshRequiresInventory(currentInventory,resolve(root,inventoryPath))
assert.equal(currentInventoryHash,author.baselineInventorySha256)
const occurrence=currentInventory.families.find(x=>x.familyId==='canonical-gymnasium')!.goals.find(x=>x.goalId===eye)!
assert.equal(occurrence.reviewRequired,true)
assert.equal(occurrence.occurrences.filter(x=>x.selected).length,1)
assert.deepEqual(occurrence.occurrences.find(x=>x.selected)!.reviewInput,decision.reviewInput)

const rolloutPath='curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
const physics=json(rolloutPath).subjects.find((x:any)=>x.subject==='physik')
const ownerPaths=physics.positiveEvidenceConfigPaths.filter((path:string)=>json(path).scope.goalIds.includes(eye))
assert.deepEqual(ownerPaths,[decision.currentWholePositiveEvidenceBinding.configPath])
const ownerConfig=json(ownerPaths[0])
assert.equal(ownerConfig.reviewPath,decision.currentWholePositiveEvidenceBinding.reviewPath)
const currentGoal=json(ownerConfig.landscapePath).goals.find((x:any)=>x.id===eye)
const currentLens=json(ownerConfig.landscapePath).goals.find((x:any)=>x.id===lens)
const kind=json(ownerConfig.semanticKindLedgerPath).decisions.find((x:any)=>x.goalId===eye)
assert.equal(kind.semanticKind,'curricularAtomic');assert.equal(kind.decisionStatus,'authoritative')
assert.equal(kind.sourceFingerprint,fingerprintSemanticKindSourceGoal(currentGoal))
assert.deepEqual(currentGoal,priorRead.goals.find((x:any)=>x.id===eye))
assert.deepEqual(currentLens,priorRead.goals.find((x:any)=>x.id===lens))
assert.deepEqual(currentGoal.requires,[lens])
bytes(ownerConfig.reviewPath);bytes(ownerConfig.reviewCriteriaPath)
const nativeP=reviewPositiveGoalEvidenceConfig(ownerPaths[0])
assert.deepEqual(nativeP.errors,[]);assert.equal(nativeP.records.length,1)
const record=nativeP.records[0]
assert.deepEqual(record,priorRead.candidateP[0])
assert.equal(record.goalFingerprint,fingerprintGoalForPositiveEvidence(currentGoal,kind.semanticKind))
assert.equal(record.reviewInputFingerprint,fingerprintPositiveGoalEvidenceReviewInput(currentGoal,record.reviewCriteriaFingerprint,{},kind.semanticKind))
assert.equal(record.profileFingerprint,fingerprintPositiveGoalEvidenceProfile(record.profile))
assert.equal(record.status,'needs_human_review');assert.equal(record.reviewAuthority,'ai_candidate')

function checkWholeCondition(condition:any,goal:any,profile:any) {
  assert.equal(condition.wholeGoalStableJsonSha256,fingerprint(goal),'Complete Goal condition')
  assert.equal(condition.wholeProfileStableJsonSha256,fingerprint(profile),'Complete P condition')
  assert.equal(condition.profileFingerprint,fingerprintPositiveGoalEvidenceProfile(profile),'Native P fingerprint condition')
  assert.equal(condition.reviewInputFingerprint,record.reviewInputFingerprint)
  assert.deepEqual(condition.currentRequiresUnchanged,goal.requires)
  assert.equal(condition.noAdditionalDirectMath,true)
}
checkWholeCondition(decision.positiveEvidenceCondition,currentGoal,record.profile)
assert.equal(decision.currentWholePositiveEvidenceBinding.wholeCurrentProfileBodySha256,fingerprint(record.profile))
const reviewPath=resolve(out,'one-current-eye.native-independent-review.inert.json')
const review:any={
  schemaVersion:1,recordedAt:existsSync(reviewPath)?JSON.parse(readFileSync(reviewPath,'utf8')).recordedAt:new Date().toISOString(),
  role:'Independent native one-record technical transport of own previously sealed informed whole-Goal/P/Kind/Requires scientific judgment; no new content judgment',
  authorLedgerSha256:authorHash,inventorySha256:currentInventoryHash,
  priorIndependentJudgment:{path:previous+'HANDOFF.actual.json',sha256:bytesFingerprint(bytes(previous+'HANDOFF.actual.json')),
    sealManifestPath:previous+'SEALED-FILES.json',sealManifestSha256:bytesFingerprint(bytes(previous+'SEALED-FILES.json')),originalSealUnchanged:true},
  modelAuthority:'Independent AI reviewer; serving model/build not independently observed; no blind or human approval claim',
  decisions:[{
    decisionId:decision.decisionId,decision:'approved',reviewer:'/root/explicit_math_supplement_runtime_v2_independent_code_peer',
    rationale:'Transport of my separately sealed informed current Eye judgment. The complete unchanged qualitative Eye Goal and all3 P duties/4 transfer axes/3 briefs preserve a model of real focus versus retinal plane. Fixed relaxed accommodation, far-object classification, initially normal focus and a still-converging real-image range make the qualitative power/eye-length variation determinate. The complete existing direct Lens Goal/P provides principal rays, image position/type, focal geometry and qualitative variation. There is no compulsory numerical lens law, diopter/ratio arithmetic or derivative duty, so no additional direct whole Mathematics prerequisite is necessary. My private equations/numbers are counterexample checks, not new pupil obligations. Existing Lens requires and its own prerequisites remain in force without mastery backfill. This native one-record approval is conditional on the exact complete Goal/P hashes below and preserves all authored applicability/target/source scopes.',
    reviewInput:structuredClone(decision.reviewInput),positiveEvidenceCondition:structuredClone(decision.positiveEvidenceCondition),
    scientificApprovalScope:'Only exact current Eye whole Goal/P and no additional direct Math; original scientific seal controls. No new D, Kind, source, placement, target, M7, human, host or package acceptance.'
  }],
  nativeValidatorLimit:'validateRequiresDecisions binds Goal semantics/requires/scope and author/inventory bytes; it does not inspect positiveEvidenceCondition. Complete-P/Goal condition is independently checked here and carried explicitly in this sealed review.'
}
assert.equal(stableJson(review.decisions[0].positiveEvidenceCondition),stableJson(decision.positiveEvidenceCondition))
const options={familyIds:['canonical-gymnasium'],independentReview:review,authorLedgerSha256:authorHash,
  inventorySha256:currentInventoryHash,reviewedInventorySha256:author.baselineInventorySha256,
  sourcePathExists:(path:string)=>existsSync(resolve(root,path))}
const result=validateRequiresDecisions(currentInventory,author,options)
assert.deepEqual(result.errors,[]);assert.equal(result.reviewed,1)
const badHash=validateRequiresDecisions(currentInventory,author,{...options,authorLedgerSha256:'sha256:'+'0'.repeat(64)})
assert.equal(badHash.reviewed,0);assert.ok(badHash.errors.some(x=>x.includes('hash mismatch')))
const staleAuthor=structuredClone(author);staleAuthor.decisions[0].reviewInput.semanticSha256='sha256:'+'0'.repeat(64)
const staleResult=validateRequiresDecisions(currentInventory,staleAuthor,options)
assert.equal(staleResult.reviewed,0);assert.ok(staleResult.errors.some(x=>x.includes('Stale')))
const changedProfile=structuredClone(record.profile);changedProfile.expectations[0].essentialUnderstandingDe+=' TEST_ONLY_CHANGED_REQUIRED_DUTY'
assert.throws(()=>checkWholeCondition(review.decisions[0].positiveEvidenceCondition,currentGoal,changedProfile),/Complete P condition/)
assert.throws(()=>checkWholeCondition(review.decisions[0].positiveEvidenceCondition,{...currentGoal,requires:[]},record.profile),/Complete Goal condition/)
for(const path of ['app/scripts/lib/crossSubjectRequiresInventory.ts','app/scripts/lib/crossSubjectRequiresReview.ts','app/scripts/positiveGoalEvidenceReview.ts','app/scripts/positiveGoalEvidenceProfileModel.ts','app/scripts/goalEvidenceTaskMaterials.ts','app/scripts/goalBookModel.ts'])bytes(path)
for(const binding of bindings.values())assert.equal(bytesFingerprint(readFileSync(resolve(root,binding.path))),binding.sha256,'Read input changed before seal '+binding.path)
function persistOrVerify(path:string,value:unknown) {
  if(existsSync(path))assert.deepEqual(JSON.parse(readFileSync(path,'utf8')),value,'Existing review evidence differs; preserve this packet and create an additive successor')
  else writeFileSync(path,JSON.stringify(value,null,2)+'\n')
}
persistOrVerify(reviewPath,review)
persistOrVerify(resolve(out,'native-current-binding-proof.json'),{authorHash,currentInventoryHash,inventoryFresh:true,
  currentOwner:ownerPaths[0],currentOwnerReview:ownerConfig.reviewPath,reviewInput:decision.reviewInput,
  wholeCondition:decision.positiveEvidenceCondition,conditionExactlyMatchesAuthor:true,goalAndLensEqualPriorRead:true,
  completeCurrentPRecordEqualsPriorAcceptedCandidate:true,nativePValidation:nativeP.errors,currentKind:kind,
  nativeRequiresResult:result,onlyEyeReviewed:true,remainingInventoryGoalsNotApprovedHere:result.open,
  counterexamples:{wrongAuthorHash:badHash,staleDependentInput:staleResult,changedWholePDutyRejected:true,changedWholeGoalRequiresRejected:true},
  noMainWrites:true,originalScientificSealUnchanged:true})
persistOrVerify(resolve(out,'current-read-bindings.json'),[...bindings.values()])
console.log(JSON.stringify({status:'PASS',authorHash,currentInventoryHash,nativePErrorCount:nativeP.errors.length,nativeRequiresResult:result,onlyOneCurrentEyeApproved:true,completePConditionIndependentlyChecked:true}))
