import json,pathlib,sys
p=pathlib.Path(__file__).resolve().parent;r=json.loads((p/'all-provided-whole-source-passages.actual.json').read_text())['newWholePassages'];start=int(sys.argv[1]);out=[];sz=0
for i,z in enumerate(r[start:],start):
 a={k:v for k,v in z.items()};q={k:v for k,v in z['wholePassage'].items() if k!='sourceGoalIds'}
 if q.get('rawText')==q.get('text'):q['rawText']={'identicalCompleteTextAt':'text'}
 a['wholePassage']=q;s=json.dumps(a,ensure_ascii=False)
 if out and sz+len(s)>28000:break
 out.append({'newPassageIndex':i,**a});sz+=len(s)
print(json.dumps({'displayOnlyOmittedField':'sourceGoalIds, literal metadata retained in full input copy','nextIndex':start+len(out),'count':len(r),'records':out},ensure_ascii=False))
