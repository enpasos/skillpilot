# SPDX-License-Identifier: Apache-2.0
import json,pathlib,math
out=pathlib.Path(__file__).resolve().parent
probes=json.loads((out/'thirty-four-fresh-own-solved-countercases.actual.json').read_text())['probes'];checks=[]
def equal(a,b):
 if isinstance(a,list):return isinstance(b,list) and len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
 if isinstance(a,bool):return a is b
 return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-14)
def check(n,k,expect):
 p=next(p for p in probes if p['probeId'].startswith(f'own-peer-{n:02}-') and k in p['calculatedResults'])
 a=p['calculatedResults'][k];checks.append({'probeId':p['probeId'],'quantity':k,'reported':a,'independentlyCalculated':expect,'pass':equal(a,expect)})
check(81,'groundGaps_eV',[-4-(-7.5),-1.5-(-7.5)]);check(81,'allowed',[float(4).is_integer(),float(3.25).is_integer()])
check(82,'gaps_V',[9.4-4.8,14-9.4]);check(82,'gapInterval_V',[(9.4-.15)-(4.8+.15),(9.4+.15)-(4.8-.15)])
check(83,'voltageAmplitude_V',30*.004*150);check(83,'cornerOneSided_V',[-15*(-.002),-15*.002])
check(84,'mirrorDisplacement_um',25*520e-9/2/1e-6);check(84,'deltaN',15*520e-9/.04)
check(85,'E_J',6.63e-34*3e8/(480e-9));check(85,'lambda_nm',6.63e-34/4.14375e-27/1e-9)
check(86,'energies_Wh',[6*2.5,27*2.5]);check(86,'eta',13.5/18)
check(87,'predictedAt90_cm',.7/30*90);check(87,'period_s',[(sum(a)/len(a))/10 for a in [[10.9,11.1],[16.3,16.5],[21.8,22]]])
check(88,'phaseVelocity_m_s',2.5*1.2);check(88,'newPhase_rad',math.pi/8+6*math.pi/12)
check(89,'p_kg_m_s',math.sqrt(2*9.11e-31*1.6e-19*3600));check(89,'lambdaRatio',math.sqrt(3600/8100))
check(90,'sigma_C_m2',[9e-9/.006,-9e-9/.006]);check(90,'Q_C',-2.5e-6*.004)
check(91,'HC',[1/math.sqrt(1+r*r) for r in [.25,1,4]]);check(91,'new_fc_Hz',1/(2*math.pi*(2*600)*2e-6))
check(92,'boxFirstGap_eV',3*(13.6/4-13.6/9)/5);check(92,'kinetic_eV',7.5-6)
check(93,'B_interval_kg',[3*.3,3*.9]);check(93,'totalsAt20_kg',[260+20*140*.25,420+20*90*.25])
check(94,'omega_rad_s',math.sqrt(1/((15*1e-3)*(4*1e-6))));check(94,'energyRatio',(.5*(.25)*3**2)/(.5))
check(95,'homogeneousDepths_m',[1600*t*1e-6/2 for t in [35,80]]);check(95,'resolution_mm',[1600*t*1e-6/2*1000 for t in [.8,.25]])
check(96,'centralWidth_mm',2*1.6*650e-9/(.4e-3)*1000);check(96,'parabolicIntensityAt1',(3/(math.pi**2))**2)
check(97,'readingBound_mm',1/2);check(97,'means_s',[sum([1.42,1.43,1.44,1.45,1.46]*2)/10,sum([1.390,1.410,1.430,1.450,1.470]*2)/10])
symbolic=[]
for t in [-.36,-.18,0,.11,.39]:
 # Direct derivative of the pulse, separate from the report's simplified U.
 phiPrime=.003*math.exp(-t*t/.09)*(-2*t/.09);u=t*math.exp(-t*t/.09)
 symbolic.append({'time_s':t,'directMinusNDerivative':-15*phiPrime,'reportedPulseFormula':u,'pass':math.isclose(-15*phiPrime,u,abs_tol=1e-13)})
mod=json.loads((out/'own-96-four-aperture-amplitude-models.actual.json').read_text())
r={'role':'Executed numeric checks of 34 fresh solved science cases plus analytic pulse and four actual aperture models; no learner evidence or P approval','caseChecks':checks,'caseCheckCount':len(checks),'distinctProbesChecked':len(set(x['probeId']for x in checks)),'analyticPulseChecks':symbolic,'actualApertureModelsAllPass':mod['allPass'],'errors':[x for x in checks+symbolic if not x['pass']]}
(out/'own-numeric-and-symbolic-case-checks.actual.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['caseChecks','analyticPulseChecks']}));assert not r['errors'] and r['distinctProbesChecked']==34 and mod['allPass']
