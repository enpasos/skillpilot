import json,pathlib,sys
p=pathlib.Path(__file__).resolve().parent;x=json.loads((p/'twenty-complete-review-contexts.actual.json').read_text());n=int(sys.argv[1]);r=x[n-81]
out={k:v for k,v in r.items() if k not in ['wholeCurrentGoalAndPositiveBody','ownCandidate','directPrereqs']}
out['wholeGoal']={k:v for k,v in r['wholeGoal'].items()if k!='resourceLinks'}
out['directPrerequisiteIdsAndTitles']=[{'id':z['id'],'title':z['title']}for z in r['directPrereqs']]
out['originalIndependentHistory']=[{'originalBinding':z['originalBinding'],'wholeOriginalProposalRationale':z['wholeOriginalProposal'].get('rationale'),'wholeOriginalProposalAction':z['wholeOriginalProposal'].get('decision'),'wholeOriginalReviewScientificFields':{k:v for k,v in z.get('wholeOriginalIndependentReview',{}).items() if k in ['decision','reviewDisposition','rationale','nominatedMathematicsRead']}}for z in r['originalIndependentHistory']]
seen={}
def compact(v,path='$'):
 if isinstance(v,str) and len(v)>120:
  if v in seen:return {'identicalCompleteValueAlreadyAt':seen[v]}
  seen[v]=path;return v
 if isinstance(v,dict):return {k:compact(z,path+'.'+k)for k,z in v.items()}
 if isinstance(v,list):return [compact(z,path+'['+str(i)+']')for i,z in enumerate(v)]
 return v
print(json.dumps(compact(out),ensure_ascii=False))
