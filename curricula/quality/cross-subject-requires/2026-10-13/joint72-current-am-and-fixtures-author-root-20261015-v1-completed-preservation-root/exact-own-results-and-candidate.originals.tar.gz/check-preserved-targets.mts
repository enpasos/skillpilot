// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict'
import { readFileSync, readdirSync, writeFileSync, existsSync } from 'node:fs'
import { resolve } from 'node:path'
import { normalizeCanonicalLandscape } from '../../../app/src/utils/authoring/canonicalAuthoring.ts'
import { normalizeCompositionView, collectCompositionProjectionRoleGoalIds } from '../../../app/src/utils/authoring/compositionViewAuthoring.ts'

const R = '/home/enpasos/projects/skillpilot'
const O = resolve(import.meta.dirname)
const V = `${R}/tmp/cross-subject-requires/current-physics-next-joint-candidate-root-20261015-v1/candidate-v2`
const C = `${O}/candidate-v3`
const json = (p: string) => JSON.parse(readFileSync(p, 'utf8'))
const registry = 'curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
const beforeReg = json(`${V}/${registry}`)
const afterReg = json(`${C}/${registry}`)
const beforePhys = beforeReg.subjects.find((s: any) => s.subject === 'physik')
const afterPhys = afterReg.subjects.find((s: any) => s.subject === 'physik')
for (const key of ['semanticAtomicityConfigPath', 'memoryReviewConfigPath']) afterPhys[key] = beforePhys[key]
assert.deepEqual(afterReg, beforeReg, 'only the two current Physics A/M registry paths may change')
const math = normalizeCanonicalLandscape(json(`${R}/curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json`))
const phys = normalizeCanonicalLandscape(json(`${V}/curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json`))
const all = new Map([...math.goals, ...phys.goals].map(g => [g.id, g]))
const roots = new Map([math, phys].map(l => [l.landscapeId, l.goals.find(g => g.tags?.includes('root'))!.id]))
const results = []
for (const filename of readdirSync(`${R}/curricula/DE/Gymnasium/composition-views/physik`).filter(f => f.endsWith('.view.json')).sort()) {
  const rel = `curricula/DE/Gymnasium/composition-views/physik/${filename}`
  const priorPath = existsSync(`${V}/${rel}`) ? `${V}/${rel}` : `${R}/${rel}`
  const nextPath = existsSync(`${C}/${rel}`) ? `${C}/${rel}` : priorPath
  const prior = normalizeCompositionView(json(priorPath)), next = normalizeCompositionView(json(nextPath))
  assert.deepEqual(next.scope, prior.scope)
  const before = collectCompositionProjectionRoleGoalIds(prior.rootNodes, all, roots)
  const after = collectCompositionProjectionRoleGoalIds(next.rootNodes, all, roots)
  assert.deepEqual([...after.targetGoalIds].sort(), [...before.targetGoalIds].sort(), next.viewId)
  const added = [...after.prerequisiteOnlyGoalIds].filter(id => !before.prerequisiteOnlyGoalIds.has(id)).sort()
  const removed = [...before.prerequisiteOnlyGoalIds].filter(id => !after.prerequisiteOnlyGoalIds.has(id))
  assert.deepEqual(removed, [])
  assert.deepEqual(added, next.viewId === 'de-bw-gym-sekii-physics-gk' ? ['80c232f1-8f72-5829-9dbe-5a610ccab3be'] : [])
  results.push({viewId: next.viewId, targetCount: after.targetGoalIds.size, targetsAndScopeIdentical: true, addedPrerequisiteOnly: added})
}
assert.equal(results.length, 69)
writeFileSync(`${O}/all69-target-and-scope-conservation.actual.json`, JSON.stringify({views: results, allPhysicsTargetsAndScopesPreserved: true, onlyAMRegistryPathsChanged: true}, null, 2) + '\n')
console.log('All69 Physics target/scope sets preserved; exactly one explicit prerequisiteOnly addition; only two A/M registry fields changed.')
