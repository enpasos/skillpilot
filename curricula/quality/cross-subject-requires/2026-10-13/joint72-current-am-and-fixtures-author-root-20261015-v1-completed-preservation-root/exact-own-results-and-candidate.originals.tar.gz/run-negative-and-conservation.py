"""Prove that the actual regression rejects an equally sized wrong prerequisite set.

SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
V = R / 'tmp/cross-subject-requires/current-physics-next-joint-candidate-root-20261015-v1/candidate-v2'
p = V / 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'
x = json.loads(p.read_text())
g = next(g for g in x['goals'] if g['id'] == 'f827b00f-af7f-52de-84aa-2a2bbaa035bd')
assert g['requires'] == ['5c44b9ba-9b05-4774-95d5-073230d3fc4f', '7c978529-ce62-5adc-897f-24ea80babbc8']
g['requires'][1] = '5f548596-9bc3-532e-88a0-81d5029809e9'
wrong = O / 'same-count-old-volume.physics.json'
assert not wrong.exists()
wrong.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')
node = str(R / 'tmp/ci-tools/node-v20.20.2-linux-x64/bin/node')
argv = [sys.executable, str(O / 'run-current-overlay.v3.py'), '--same-count-old-volume', node, '--import', 'tsx', 'scripts/testPhysicsGoalBookInputs.ts']
started = datetime.now(timezone.utc).isoformat()
r = subprocess.run(argv, cwd=O, capture_output=True)
for stream, raw in [('stdout',r.stdout), ('stderr',r.stderr)]:
    (O / f'same-count-old-volume.{stream}.txt').write_bytes(raw)
receipt = {'argv':argv, 'startedUTC':started, 'completedUTC':datetime.now(timezone.utc).isoformat(),
    'actualExitCode':r.returncode, 'expectedRejection':True, 'foreignEdgeCountStill72':True,
    'changedOnlyOneRequiredEndpointOnControlledNegative':True, 'candidateBytesChanged':False,
    'OSRootRO':True, 'normalProductionTestCommand':True}
(O / 'same-count-old-volume.execution.actual.json').write_text(json.dumps(receipt,indent=2) + '\n')
assert r.returncode != 0
assert b'current adopted 72-relation fixture' in r.stderr, r.stderr.decode()
print('Normal regression rejected the same72-count Q2-volume endpoint substitution at the exact endpoint fixture.', flush=True)
argv = [node, str(R / 'app/node_modules/tsx/dist/cli.mjs'), str(O / 'check-preserved-targets.mts')]
r = subprocess.run(argv, cwd=O, capture_output=True)
for stream, raw in [('stdout',r.stdout), ('stderr',r.stderr)]:
    (O / f'conservation.{stream}.txt').write_bytes(raw)
(O / 'conservation.execution.actual.json').write_text(json.dumps({'argv':argv,'exitCode':r.returncode,'OSRootRO':True},indent=2) + '\n')
print(r.stdout.decode(),r.stderr.decode())
raise SystemExit(r.returncode)
