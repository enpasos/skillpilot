"""Execute normal owning checks against a read-only current candidate overlay.

SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
J = R / 'tmp/cross-subject-requires/current-physics-next-joint-candidate-root-20261015-v1'
V = J / 'candidate-v2'
C = O / 'candidate-v2'
E = O / 'execution-overlay'
DATE = 'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15'
REG = 'curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
PHYS = 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'
base = R / 'tmp/ci-tools/hermetic-consumer-tools-20261015-v1'
bwrap = base / 'root/usr/bin/bwrap'
merged = base / 'usr-bin-with-verified-tools'
assert hashlib.sha256(bwrap.read_bytes()).hexdigest() == 'e318903862396f96de3df57264e0158682b952fd3fb53ac23d876413e7b30f71'
assert hashlib.sha256((merged / 'bwrap').read_bytes()).hexdigest() == 'e318903862396f96de3df57264e0158682b952fd3fb53ac23d876413e7b30f71'
assert hashlib.sha256((merged / 'strace').read_bytes()).hexdigest() == '28f957c227012de0b18d1bd7fff2d396cb693ea60ed8013be68de071e84b5001'
args = sys.argv[1:]
negative = bool(args and args[0] == '--same-count-old-volume')
if negative:
    args.pop(0)
assert args
mounts = [(O / 'execution-overlay-v2/app/scripts', R / 'app/scripts'), (E / DATE, R / DATE)]
for row in json.loads((J / 'CANDIDATE.v2.actual.json').read_text())['files']:
    rel = row['target']
    if rel == REG or rel.startswith('app/scripts/') or rel.startswith(DATE + '/'):
        continue
    if (R / rel).is_file():
        src = V / rel
        if negative and rel == PHYS:
            src = O / 'same-count-old-volume.physics.json'
        mounts.append((src, R / rel))
mounts.append((C / REG, R / REG))
argv = [str(bwrap), '--die-with-parent', '--new-session', '--unshare-user',
        '--unshare-pid', '--unshare-ipc', '--unshare-uts', '--unshare-net',
        '--cap-drop', 'ALL', '--ro-bind', '/', '/', '--bind', str(O), str(O)]
for src, dest in mounts:
    assert src.is_file() or src.is_dir()
    assert not src.is_symlink()
    argv += ['--ro-bind', str(src), str(dest)]
argv += ['--tmpfs', '/run', '--ro-bind', '/usr/bin', '/run/skillpilot-host-usr-bin',
         '--ro-bind', str(merged), '/usr/bin', '--tmpfs', '/tmp',
         '--proc', '/proc', '--dev', '/dev', '--chdir', str(R / 'app'), '--', *args]
env = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'TSX_DISABLE_CACHE': '1'}
raise SystemExit(subprocess.run(argv, env=env).returncode)
