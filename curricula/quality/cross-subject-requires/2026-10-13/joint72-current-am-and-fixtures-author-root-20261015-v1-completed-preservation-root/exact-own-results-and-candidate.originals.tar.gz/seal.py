"""Seal the real bounded candidate, failed attempts and normal check evidence.

SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
T = R / 'tmp/cross-subject-requires'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
def b(p):
    return {'path':str(p.relative_to(O)), 'bytes':p.stat().st_size, 'sha256':'sha256:' + sha(p)}
def write(p, x):
    assert not p.exists()
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')

assert sha(O / 'CANDIDATE.v3.actual.json') == 'ad79db87c1448b32fe79576fd81f1ab8a7319bb84adb762a7a969712ae1cd4c2'
candidate = load(O / 'CANDIDATE.v3.actual.json')
for row in candidate['files']:
    p = R / row['candidate']['path']
    assert 'sha256:' + sha(p) == row['candidate']['sha256']
for name in ['full-A478', 'full-M478', 'physics-regression-72-v3']:
    assert load(O / f'{name}.execution.actual.json')['exitCode'] == 0
assert load(O / 'physics-regression-72.execution.actual.json')['exitCode'] == 1
assert load(O / 'physics-regression-72-v2.execution.actual.json')['exitCode'] == 1
assert load(O / 'same-count-old-volume.execution.actual.json')['actualExitCode'] != 0
assert b'current adopted 72-relation fixture' in (O / 'same-count-old-volume.stderr.txt').read_bytes()
assert load(O / 'all69-target-and-scope-conservation.actual.json')['allPhysicsTargetsAndScopesPreserved']
bindings = load(T / 'canonical-gymnasium-effective-review-index-20261015-v21/actual-read-bindings.json')
assert len(bindings) == 737
for row in bindings:
    p = R / row['path']
    assert p.stat().st_size == row['bytes'] and 'sha256:' + sha(p) == row['sha256'], row['path']
view_bindings = []
for p in sorted((R / 'curricula/DE/Gymnasium/composition-views').rglob('*.view.json')):
    view_bindings.append({'path':str(p.relative_to(R)), 'bytes':p.stat().st_size, 'sha256':'sha256:' + sha(p)})
assert len(view_bindings) == 348
assert sha(R / '.git/index') == '6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8'
joint = T / 'current-physics-next-joint-candidate-root-20261015-v1/CANDIDATE.v2.actual.json'
for row in load(joint)['files']:
    assert sha(R / row['candidate']['path']) == row['candidate']['sha256']
write(O / 'ROOT-AND-JOINT-PRESERVATION.after.actual.json', {'RootScientificBindingsVerified':737,
    'allRootViewBindings':view_bindings, 'RootGitIndexSha256':'sha256:' + sha(R / '.git/index'),
    'jointCandidateFilesUnchanged':228, 'RootAdopted':False})
write(O / 'HANDOFF.actual.json', {'contract':'bounded-joint72-current-am-registration-and-regression-author-handoff-v1',
    'completedUTC':datetime.now(timezone.utc).isoformat(),
    'candidate':b(O / 'CANDIDATE.v3.actual.json'), 'candidateFiles':10,
    'realCurrentD18AMPeerOpinionsPreserved':True, 'registrationOnlyPeerField':'reviewId',
    'other477RawRowsEachUnchanged':True, 'originalPeerAndHistoricalWholeLedgersUnchanged':True,
    'normalFullNativeACheckGoals':478, 'normalFullNativeMCheckGoals':478,
    'normalPhysicsGoalBookInputRegressionExit':0, 'same72CountWrongQ2EndpointRejected':True,
    'firstActualFailuresRetained':['historical f827 Kind test basis', 'missing BW SekII GK support for support-only Physics contexts'],
    'actualGraphPairsUnchangedFromJoint72':72, 'exactMathGoalIds':32,
    'all69SupportOccurrences':5118, 'newExplicitPrerequisiteOnlyRootOccurrences':1,
    'newSupportOnlyMathGoal':'80c232f1-8f72-5829-9dbe-5a610ccab3be',
    'newSupportViewId':'de-bw-gym-sekii-physics-gk',
    'all69PhysicsTargetsAndScopesConserved':True,
    'independentCurrentCandidatePeerComplete':False,
    'RootScientificBindingsVerified':737, 'RootViewsExact':348, 'RootGitIndexExact':True,
    'RootAdoptionOrFullM7OrFullCIOrSourceTargetHumanLearnerAcceptance':False,
    'temporaryExecutionDirectoriesExcludedFromCandidate':['execution-overlay', 'execution-overlay-v2', 'execution-overlay-v3'],
    'licenses':{'technicalScriptsAndTests':'Apache-2.0', 'ownCurriculumReviewContent':'CC-BY-4.0; SkillPilot; actual original reviewer identities retained'},
    'sealPath':'SEAL.actual.json'})
excluded = {'execution-overlay','execution-overlay-v2','execution-overlay-v3'}
files = [p for p in sorted(O.rglob('*')) if p.is_file() and p.relative_to(O).parts[0] not in excluded]
for p in files:
    assert not p.is_symlink()
    if p.suffix == '.json':
        json.loads(p.read_text())
    elif p.suffix == '.jsonl':
        for line in p.read_text().splitlines():
            if line.strip():json.loads(line)
write(O / 'ARTIFACTS.actual.json', {'files':[b(p) for p in files]})
write(O / 'SEAL.actual.json', {'contract':'actual-owned-output-seal-v1',
    'artifactListSha256':sha(O / 'ARTIFACTS.actual.json'), 'handoffSha256':sha(O / 'HANDOFF.actual.json'),
    'ownedFiles':len(files), 'temporaryExecutionDataIsNotCandidateOrScientificApproval':True})
print(json.dumps({'HANDOFF':sha(O/'HANDOFF.actual.json'), 'SEAL':sha(O/'SEAL.actual.json'), 'ownedFiles':len(files)}))
