"""Prepare current d18 registration and exact reviewed 72-edge regression data.

SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime, timezone
import copy
import errno
import hashlib
import json
import os
import re
import shutil

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
T = R / 'tmp/cross-subject-requires'
J = T / 'current-physics-next-joint-candidate-root-20261015-v1'
V = J / 'candidate-v2'
C = O / 'candidate'
PHYS = 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'
KIND = 'curricula/DE/Gymnasium/quality/release-model/physik.semantic-kinds.json'
REG = 'curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
BASE = 'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/joint72-d18-current-am-registration-v1'
DATE = 'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15'
TEST = 'app/scripts/testPhysicsGoalBookInputs.ts'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
def bind(p):
    return {'path': str(p.relative_to(R)), 'bytes': p.stat().st_size, 'sha256': 'sha256:' + sha(p)}
def write(p, x):
    assert p.is_relative_to(O)
    p.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
    json.loads(raw)
    p.write_bytes(raw)

assert not C.exists()
for p, mode in ((R / '.git/index', os.O_WRONLY), (R / 'tmp/cross-subject-requires/joint72-am-fixture-outside-canary', os.O_WRONLY | os.O_CREAT | os.O_EXCL)):
    try:
        fd = os.open(p, mode, 0o600)
    except OSError as e:
        assert e.errno == errno.EROFS, (str(p), e.errno)
    else:
        os.close(fd)
        raise AssertionError('Root must be OS read-only')
write(O / 'root-readonly-selfcheck.actual.json', {'RootExistingAndNewWritesDeniedEROFS': True, 'ownWrite': True})
assert sha(J / 'CANDIDATE.v2.actual.json') == 'a840b2a1fec3027f74c1bcd9487b3d40b79f0a7437e187da33beb3bfc1b6a014'
joint = load(J / 'CANDIDATE.v2.actual.json')
for row in joint['files']:
    p = R / row['candidate']['path']
    assert sha(p) == row['candidate']['sha256'], row['target']
analysis = T / 'hrd206-evolution-whole-p-successor-author-20261015-v1/D18-AM-REGISTRATION.separate-analysis.actual.json'
a = load(analysis)
registration = {'contract': 'transparent-exact-d18-campaign-registration-derivative-v1',
    'createdUTC': datetime.now(timezone.utc).isoformat(), 'sourceAnalysis': bind(analysis),
    'scientificNewOpinionCreatedByTransport': False, 'onlyMappedPeerField': 'reviewId',
    'RootAdopted': False, 'derivatives': []}
for d in a['exactDescriptors']:
    lane = d['lane']
    source_config = Path(d['currentConfigPath'])
    source_review = Path(d['currentWholeReviewFilePath'])
    peer_path = Path(d['actualPeerSourcePath'])
    assert 'sha256:' + sha(source_config) == d['currentConfigSha256']
    assert 'sha256:' + sha(source_review) == d['currentWholeReviewFileSha256']
    assert 'sha256:' + sha(peer_path) == d['actualPeerWholeFileSha256']
    lines = source_review.read_bytes().splitlines(keepends=True)
    assert len(lines) == 478
    idx = d['replaceOnlyZeroBasedLineIndex']
    assert json.loads(lines[idx])['goalId'] == d['replaceOnlyGoalId']
    others = b''.join(lines[:idx] + lines[idx+1:])
    assert 'sha256:' + hashlib.sha256(others).hexdigest() == d['allOtherRawLinesSha256']
    peer_records = [json.loads(l) for l in peer_path.read_bytes().splitlines() if l.strip()]
    assert peer_records == [d['actualPeerCompleteRecord']]
    mapped = copy.deepcopy(peer_records[0])
    mapped['reviewId'] = d['currentCampaignId']
    assert mapped == d['proposedCampaignMappedRegistrationRecord']
    assert {k:v for k,v in mapped.items() if k != 'reviewId'} == {k:v for k,v in peer_records[0].items() if k != 'reviewId'}
    new_line = (json.dumps(mapped, ensure_ascii=False, separators=(',', ':')) + '\n').encode()
    lines[idx] = new_line
    target_review = C / BASE / f'{lane}.review.jsonl'
    target_review.parent.mkdir(parents=True, exist_ok=True)
    target_review.write_bytes(b''.join(lines))
    assert len([json.loads(l) for l in target_review.read_bytes().splitlines()]) == 478
    assert b''.join(target_review.read_bytes().splitlines(keepends=True)[:idx] + target_review.read_bytes().splitlines(keepends=True)[idx+1:]) == others
    original_peer = C / BASE / 'original-peer' / f'{lane}.peer.review.jsonl'
    original_peer.parent.mkdir(parents=True, exist_ok=True)
    original_peer.write_bytes(peer_path.read_bytes())
    cfg = load(source_config)
    cfg['reviewPath'] = f'{BASE}/{lane}.review.jsonl'
    if 'reportPath' in cfg:
        cfg['reportPath'] = f'{BASE}/{lane}.report.md'
    write(C / BASE / f'{lane}.config.json', cfg)
    registration['derivatives'].append({'lane': lane, 'sourceConfig': bind(source_config),
        'sourceWholeReview': bind(source_review), 'exactOriginalPeerSource': bind(peer_path),
        'originalPeerRetainedAt': f'{BASE}/original-peer/{lane}.peer.review.jsonl',
        'retainedOtherRawLineCount': 477, 'retainedOtherRawLinesSha256': d['allOtherRawLinesSha256'],
        'replacedOldRecord': json.loads(source_review.read_bytes().splitlines()[idx]),
        'newRegistrationRecord': mapped, 'reviewIdIsCampaignBindingOnly': True,
        'mappedReviewIdFrom': peer_records[0]['reviewId'], 'mappedReviewIdTo': mapped['reviewId'],
        'derivedConfig': f'{BASE}/{lane}.config.json', 'derivedReview': f'{BASE}/{lane}.review.jsonl'})
write(C / BASE / 'REGISTRATION.actual.json', registration)
reg = load(V / REG)
phys = next(s for s in reg['subjects'] if s['subject'] == 'physik')
old_paths = {k:phys[k] for k in ('semanticAtomicityConfigPath', 'memoryReviewConfigPath')}
phys['semanticAtomicityConfigPath'] = f'{BASE}/A.config.json'
phys['memoryReviewConfigPath'] = f'{BASE}/M.config.json'
write(C / REG, reg)

# Bind the concrete reviewed add/replacement set, rather than just recomputing a count.
root_phys = load(R / PHYS)
next_phys = load(V / PHYS)
math_ids = {g['id'] for g in load(R / 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json')['goals']}
def pairs(land):
    return {(g['id'], x) for g in land['goals'] for x in g.get('requires', []) if x in math_ids}
old_pairs = pairs(root_phys)
new_pairs = pairs(next_phys)
eighteen = T / 'gymnasium-i02-i05-eighteen-current-integration-author-20261015-v1'
peer = T / 'gymnasium-i02-i05-eighteen-current-independent-peer-20261015-v1'
assert sha(peer / 'HANDOFF.actual.json') == '3550a4f7a05ad945a37226afa9e3fffe230fe7714634e3a67c9bada5851cd2fa'
manifest = load(eighteen / 'candidate-landing-manifest.actual.json')
e_phys = R / next(row['candidate']['path'] for row in manifest if row['destination'] == PHYS)
e_pairs = pairs(load(e_phys))
assert old_pairs <= e_pairs and len(e_pairs - old_pairs) == 27
f827 = 'f827b00f-af7f-52de-84aa-2a2bbaa035bd'
old_volume = (f827, '5f548596-9bc3-532e-88a0-81d5029809e9')
new_volume = (f827, '7c978529-ce62-5adc-897f-24ea80babbc8')
assert new_pairs == (e_pairs - {old_volume}) | {new_volume}
assert len(old_pairs) == 45 and len(new_pairs) == 72
source_text = (R / TEST).read_text()
start = source_text.index('const expectedForeignRequiresEdges = [\n')
end = source_text.index('\n]\nassert.deepEqual(', start) + 2
old_literal_pairs = set(re.findall(r"ownerId: '([^']+)', goalId: '([^']+)'", source_text[start:end]))
assert old_literal_pairs == old_pairs
new_edge_literal = 'const expectedForeignRequiresEdges = [\n' + ''.join("  { ownerId: '%s', goalId: '%s' },\n" % x for x in sorted(new_pairs)) + ']'
text = source_text[:start] + new_edge_literal + source_text[end:]
text = text.replace('current adopted 45-relation fixture', 'current adopted 72-relation fixture')
assert text.count("  29,\n  'Physics cross-subject prerequisites must resolve to exactly twenty-nine mathematics goals',") == 1
text = text.replace("  29,\n  'Physics cross-subject prerequisites must resolve to exactly twenty-nine mathematics goals',", "  32,\n  'Physics cross-subject prerequisites must resolve to exactly thirty-two mathematics goals',")
text = text.replace("const ATOMICITY_CONFIG_PATH = 'curricula/DE/Gymnasium/quality/semantic-atomicity/canonical-physics-full.config.json'", f"const ATOMICITY_CONFIG_PATH = '{BASE}/A.config.json'")
text = text.replace("const ATOMICITY_REVIEW_PATH = 'curricula/DE/Gymnasium/quality/semantic-atomicity/canonical-physics-full.review.jsonl'", f"const ATOMICITY_REVIEW_PATH = '{BASE}/A.review.jsonl'")
support_rows = []
support_details = []
def walk(nodes):
    for n in nodes:
        yield n
        yield from walk(n.get('children', []))
for original in sorted((R / 'curricula/DE/Gymnasium/composition-views/physik').glob('*.view.json')):
    rel = original.relative_to(R)
    p = V / rel if (V / rel).exists() else original
    view = load(p)
    roots = sorted((n['goalId'], n['kind']) for n in walk(view['rootNodes']) if n.get('projectionRole') == 'prerequisiteOnly' and n.get('goalId') in math_ids)
    assert len(roots) == len({g for g,k in roots}), view['viewId']
    fp = hashlib.sha256(''.join(f'{g}:{k}\n' for g,k in roots).encode()).hexdigest()
    support_rows.append("  ['%s', { count: %s, sha256: '%s' }],\n" % (view['viewId'], len(roots), fp))
    support_details.append({'viewId':view['viewId'], 'input':bind(p), 'count':len(roots), 'sha256':fp, 'exactRoots':[{'goalId':g,'kind':k} for g,k in roots]})
assert len(support_details) == 69 and sum(s['count'] for s in support_details) == 5117
start = text.index('const ADOPTED_PHYSICS_MATH_SUPPORT_ROOTS = new Map<string, { count: number; sha256: string }>([\n')
end = text.index('\n])\nconst RETAINED_HISTORICAL_MATH_SUPPORT_IDS', start) + 3
new_support = 'const ADOPTED_PHYSICS_MATH_SUPPORT_ROOTS = new Map<string, { count: number; sha256: string }>([\n' + ''.join(sorted(support_rows)) + '])'
text = text[:start] + new_support + text[end:]
assert text.count('authoredMathSupportRootOccurrences, 4954,') == 1
text = text.replace('authoredMathSupportRootOccurrences, 4954,', 'authoredMathSupportRootOccurrences, 5117,')
target_test = C / TEST
target_test.parent.mkdir(parents=True, exist_ok=True)
target_test.write_text(text)
write(O / 'exact-reviewed-fixture-inputs.actual.json', {'Root45':sorted(old_pairs), 'independentlyReviewed18Add27':sorted(e_pairs-old_pairs),
    'eighteenPeer':bind(peer/'HANDOFF.actual.json'), 'removedOldVolume':old_volume, 'newExistingJ6Volume':new_volume,
    'joint72':sorted(new_pairs), 'distinctMath':len({g for p,g in new_pairs}), 'all69SupportSets':support_details,
    'noTargetEnrollmentOrCompleteRouteInferred':True})

# Temporary physical execution data is kept outside curricula and excluded from the candidate.
E = O / 'execution-overlay'
shutil.copytree(R / 'app/scripts', E / 'app/scripts')
shutil.copytree(R / DATE, E / DATE)
for row in joint['files']:
    rel = row['target']
    if rel.startswith('app/scripts/') or rel.startswith(DATE + '/'):
        dest = E / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((R / row['candidate']['path']).read_bytes())
for p in C.rglob('*'):
    if p.is_file() and (str(p.relative_to(C)).startswith('app/scripts/') or str(p.relative_to(C)).startswith(DATE + '/')):
        dest = E / p.relative_to(C)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(p.read_bytes())
files=[]
for p in sorted(C.rglob('*')):
    if p.is_file():
        dest = R / p.relative_to(C)
        files.append({'target':str(p.relative_to(C)), 'preimage':bind(dest) if dest.is_file() else None, 'candidate':bind(p)})
write(O / 'CANDIDATE.actual.json', {'contract':'private-joint72-current-am-registration-and-meaningful-fixtures-v1',
    'scope':'canonical Gymnasium Math807 Physics478', 'RootAdopted':False, 'jointInputManifest':bind(J/'CANDIDATE.v2.actual.json'),
    'registryChangedOnlyPhysicsAMPaths':old_paths, 'wholeReviewsEach478RetainedOtherRows477':True,
    'registrationChangesNoScientificDecision':True, 'files':files})
assert sha(R / '.git/index') == '6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8'
print(json.dumps({'candidateFiles':len(files),'foreignEdges':72,'supportReferences':5117,'oldOtherRowsEach':477,'RootAdopted':False}))
