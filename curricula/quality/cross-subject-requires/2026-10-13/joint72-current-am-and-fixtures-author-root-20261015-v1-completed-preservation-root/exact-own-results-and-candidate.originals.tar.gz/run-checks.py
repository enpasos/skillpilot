"""Run actual native full A/M and the production Physics regression command.

SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
BASE = 'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/joint72-d18-current-am-registration-v1'
NODE = str(R / 'tmp/ci-tools/node-v20.20.2-linux-x64/bin/node')
WRAP = str(O / 'run-current-overlay.py')
records = []
cases = [
    ('full-A478', ['scripts/semanticAtomicityReview.ts', f'--config={BASE}/A.config.json', '--mode=check']),
    ('full-M478', ['scripts/memoryCardReview.ts', f'--config={BASE}/M.config.json', '--mode=check']),
    ('physics-regression-72', ['scripts/testPhysicsGoalBookInputs.ts']),
]
for name, tail in cases:
    receipt = O / f'{name}.execution.actual.json'
    assert not receipt.exists()
    argv = [sys.executable, WRAP, NODE, '--import', 'tsx', *tail]
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=O, capture_output=True)
    for stream, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (O / f'{name}.{stream}.txt').write_bytes(raw)
    record = {'name': name, 'argv': argv, 'startedUTC': started,
        'completedUTC': datetime.now(timezone.utc).isoformat(), 'exitCode': result.returncode,
        'OSRootRO': True, 'normalOwningCLI': True, 'RootAdopted': False}
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    print(json.dumps({'name':name, 'exitCode':result.returncode}), flush=True)
    if result.returncode:
        print(result.stdout.decode(), result.stderr.decode(), flush=True)
        raise SystemExit(result.returncode)
(O / 'normal-checks.actual.json').write_text(json.dumps(records, indent=2) + '\n')
