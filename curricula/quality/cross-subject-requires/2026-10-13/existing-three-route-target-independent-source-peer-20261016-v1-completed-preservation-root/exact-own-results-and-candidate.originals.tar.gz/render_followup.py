from pathlib import Path
import subprocess,os,json
R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent;env={**os.environ,'LD_LIBRARY_PATH':str(R/'tmp/ci-tools/poppler-root/usr/lib/x86_64-linux-gnu')};rows=[]
for name,p,pg in [('MV35','curricula/DE/Gymnasium/input/MV/Mathematik_Gymnasium_7_10_2019.pdf',35),('TH27','curricula/DE/Gymnasium/input/TH/lp_gy_mathematik_10.04.2019_TSP.pdf',27)]:
 a=[str(R/'tmp/ci-tools/poppler-root/usr/bin/pdftoppm'),'-f',str(pg),'-l',str(pg),'-scale-to','1500','-singlefile','-png',str(R/p),str(O/'own-original-renders'/name)];z=subprocess.run(a,env=env,capture_output=True);rows.append({'argv':a,'exit':z.returncode,'stderr':z.stderr.decode()});assert z.returncode==0
(O/'own-followup-render-execution.actual.json').write_text(json.dumps(rows,indent=2)+'\n')
