from pathlib import Path
import json,subprocess,hashlib,datetime
R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent;A=R/'tmp/cross-subject-requires/actual-root72-native-route-and-target-followup-root-20261016-v1';B=R/'tmp/cross-subject-requires/current45-current-root-fresh-native-route-replay-root-20261015-v1';J=R/'tmp/ci-tools/amazon-corretto-25.0.2.10.1/bin'
loads=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda n,x:(O/n).write_text(json.dumps(x,indent=2)+'\n')
rows=[]
for n in ['current-production-java-inputs.actual.json','fresh-current-production-classes.actual.json','actual-dependency-jars.actual.json']:
 for r in loads(B/n):
  p=Path(r['path']);p=p if p.is_absolute() else R/p;assert sha(p)==r['sha256'],r['path'];rows.append({'path':str(p),'sha256':r['sha256']})
write('native-verified-cache-inputs.actual.json',{'verifiedSourcesClassesJars':rows,'freshProductionCompilation':False})
jars=loads(B/'actual-dependency-jars.actual.json');cp=str(B/'production-classes')+':'+':'.join(r['path'] for r in jars);(O/'harness-classes').mkdir(exist_ok=True)
for n in ['AdoptedNativeAudit','CurrentFortyMathOnlyRouteAudit']:(O/(n+'.java')).write_bytes((A/(n+'.java')).read_bytes())
for n in ['all29-Math-learning-route-contexts.actual.json','Math-only-detour-configurations.prepared.json']:(O/n).write_bytes((A/n).read_bytes())
cmd=[str(J/'javac'),'-encoding','UTF-8','-cp',cp,'-d',str(O/'harness-classes'),str(O/'AdoptedNativeAudit.java'),str(O/'CurrentFortyMathOnlyRouteAudit.java')];p=subprocess.run(cmd,capture_output=True);(O/'native-javac.stdout.txt').write_bytes(p.stdout);(O/'native-javac.stderr.txt').write_bytes(p.stderr);write('native-javac.execution.json',{'argv':cmd,'exitCode':p.returncode});assert p.returncode==0
cmd=[str(J/'java'),'-Xmx3g','-cp',str(O/'harness-classes')+':'+cp,'CurrentFortyMathOnlyRouteAudit',str(R),str(O)];p=subprocess.run(cmd,capture_output=True);(O/'native-route.stdout.txt').write_bytes(p.stdout);(O/'native-route.stderr.txt').write_bytes(p.stderr);write('native-route.execution.json',{'argv':cmd,'exitCode':p.returncode,'completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'borrowedHarnessSources':str(A),'actualProductionNativeMethods':True,'learnerWrites':False});print(p.stdout.decode()[-2000:]);print(p.stderr.decode()[-2000:]);assert p.returncode==0
