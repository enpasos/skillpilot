from pathlib import Path
import subprocess,json,hashlib,sys,os,datetime
R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent;B=R/'tmp/ci-tools/hermetic-consumer-tools-20261015-v1/root/usr/bin/bwrap';assert Path.cwd().resolve()==O
label=sys.argv[1];args=sys.argv[2:];cmd=[str(B),'--die-with-parent','--new-session','--unshare-user','--unshare-pid','--unshare-ipc','--unshare-uts','--unshare-net','--cap-drop','ALL','--ro-bind','/','/','--bind',str(O),str(O),'--tmpfs','/tmp','--proc','/proc','--dev','/dev']
for m in json.loads((O/'candidate-manifest.actual.json').read_text()):cmd+=['--ro-bind',str(O/'candidate'/m['path']),str(R/m['path'])]
cmd+=['--chdir',str(R),'--',*args]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,capture_output=True);(O/(label+'.stdout.txt')).write_bytes(p.stdout);(O/(label+'.stderr.txt')).write_bytes(p.stderr);rec={'argv':cmd,'exitCode':p.returncode,'startedUTC':started,'completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdoutBytes':len(p.stdout),'stderrBytes':len(p.stderr),'RootReadOnly':True,'onlyOwnLaneWritable':str(O)};(O/(label+'.execution.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec));print(p.stdout.decode()[-3500:]);print(p.stderr.decode()[-1500:]);raise SystemExit(p.returncode)
