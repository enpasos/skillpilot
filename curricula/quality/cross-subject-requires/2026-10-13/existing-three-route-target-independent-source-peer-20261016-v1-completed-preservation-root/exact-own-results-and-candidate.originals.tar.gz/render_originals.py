from pathlib import Path
import subprocess,os,json
R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent;D=O/'own-original-renders';D.mkdir(exist_ok=True);env={**os.environ,'LD_LIBRARY_PATH':str(R/'tmp/ci-tools/poppler-root/usr/lib/x86_64-linux-gnu')};rows=[]
for name,p,page in [('BB52','curricula/DE/Gymnasium/input/BB/lower-secondary/Teil_C_Mathematik_2015_10_13_Ma_14.08.2023_Berlin_23_11.pdf',52),('BY3','curricula/DE/Gymnasium/input/BY/raw/Gymnasium_Mathematik_Jgst_7.pdf',3),('SH30','curricula/DE/Gymnasium/input/SH/Fachanforderungen_Mathematik_Sekundarstufe_2024_barrierearm.pdf',30),('SL38','curricula/DE/Gymnasium/input/SL/LP_MA_gym9_7_2023.pdf',38)]:
 args=[str(R/'tmp/ci-tools/poppler-root/usr/bin/pdftoppm'),'-f',str(page),'-l',str(page),'-scale-to','1500','-singlefile','-png',str(R/p),str(D/name)];z=subprocess.run(args,capture_output=True,env=env);rows.append({'argv':args,'exit':z.returncode,'stderr':z.stderr.decode()});assert z.returncode==0,z.stderr
(O/'own-original-render-execution.actual.json').write_text(json.dumps(rows,indent=2)+'\n')
