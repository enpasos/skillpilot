from pathlib import Path
import json,hashlib,subprocess,os,collections
R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent;A=R/'tmp/cross-subject-requires/existing-three-route-target-source-author-20261016-v1';B=R/'tmp/cross-subject-requires/actual-root72-native-route-and-target-followup-root-20261016-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,d): (O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
seal=json.loads((A/'SEAL.actual.json').read_text());checks=[{'path':x['path'],'hashOK':sha(R/x['path'])==x['sha256'],'sizeOK':(R/x['path']).stat().st_size==x['bytes']} for x in seal['files']];assert len(checks)==109 and all(x['hashOK'] and x['sizeOK'] for x in checks);write('author-seal-all109-own-verified.actual.json',checks)
n=json.loads((R/'tmp/cross-subject-requires/current92-whole-integration-neutral-reader-root-20261016-v1/NEUTRAL-COMPLETE-MATH-PHYSICS-LOOKUP.actual.json').read_text());ids=['fc047e6e-5d6d-460f-99fc-ade3a23b9a8e','3e53a39b-1c75-4034-a647-8de85719e1fb','88abc886-cce8-55cf-b86c-eb4ba45a92d7'];write('whole-three-neutral-goal-P-kind.actual.json',[{'goal':n[g]['goal'],'kind':n[g]['kind'],'wholeP':n[g]['positiveEvidenceOwner']['wholeP'],'pConfigPath':n[g]['positiveEvidenceOwner']['configPath'],'pRawPath':n[g]['positiveEvidenceOwner']['rawRecordsPath']} for g in ids])
r=json.loads((B/'candidate72-classified-native-route-occurrences.actual.json').read_text());u=[x for x in r if x['routeClassification']=='genuinely-uncovered' and x['occurrenceId']!='occurrence-1022'];assert len(u)==122;p=json.loads((B/'native-Math-only-projections.actual.json').read_text());ctx={x['mathGoalId']:x for x in json.loads((B/'all29-Math-learning-route-contexts.actual.json').read_text())};cells=[]
for (j,d,g),oset in __import__('itertools').groupby(sorted(u,key=lambda x:(str(x['requestedScope'].get('jurisdiction')),str(x['requestedScope'].get('durationModel')),x['mathPrerequisiteGoalId'])),key=lambda x:(x['requestedScope'].get('jurisdiction'),x['requestedScope'].get('durationModel'),x['mathPrerequisiteGoalId'])):
 occ=list(oset);opts=[]
 for x in p:
  s=x['requestedScope']
  if s.get('jurisdiction')==j and s.get('durationModel')==d:
   miss=sorted(set(ctx[g]['atomicLearningGoalIds'])-set(x['targetGoalIds']));opts.append({'scope':s,'compositionViewIds':x['compositionViewIds'],'missing':miss,'targetCount':len(x['targetGoalIds']),'key':x['key']})
 smallest=min(len(x['missing']) for x in opts);best=[x for x in opts if len(x['missing'])==smallest];cells.append({'jurisdiction':j,'durationModel':d,'guardGoalId':g,'occurrenceIds':[x['occurrenceId'] for x in occ],'allMinimumMissingScopeAlternatives':best,'minimumMissing':best[0]['missing']})
assert len(cells)==22;assert set(g for x in cells for g in x['minimumMissing'])==set(ids);write('own-derived-current122-gaps-22-source-cells.actual.json',{'routeFile':str(B/'candidate72-classified-native-route-occurrences.actual.json'),'routeSha256':sha(B/'candidate72-classified-native-route-occurrences.actual.json'),'excludedAlreadyRepaired':'occurrence-1022','unresolved':122,'cells':cells})
for x in cells: print(x['jurisdiction'],x['guardGoalId'][:8],x['minimumMissing'],[a['scope'] for a in x['allMinimumMissingScopeAlternatives']])
# Retained original official files, directly re-extracted in read-only sandbox.
discovery=json.loads((A/'source-record-discovery.actual.json').read_text());out=O/'own-official-text';out.mkdir(exist_ok=True);rows=[]
for q in discovery:
 if q['metadata']['stage']=='SekII':continue
 st=q['metadata']['jurisdiction']
 for d in q['metadata'].get('sourceDocuments',[]):
  if st=='DE-BY' and d['key']!='JGST7':continue
  if st=='DE-SL' and '_7_' not in d['key']:continue
  src=R/d['path'];dest=out/(st+'-'+d['key']+'.txt');env={**os.environ,'LD_LIBRARY_PATH':str(R/'tmp/ci-tools/poppler-root/usr/lib/x86_64-linux-gnu')};v=subprocess.run([str(R/'tmp/ci-tools/poppler-root/usr/bin/pdftotext'),'-layout',str(src),str(dest)],capture_output=True,env=env);assert v.returncode==0,v.stderr
  rows.append({'jurisdiction':st,'sourceDocument':d,'sourceSha256':sha(src),'textPath':str(dest.relative_to(R)),'textSha256':sha(dest)})
write('own-official-original-bindings.actual.json',rows)
protected=[R/'.git/index',*list((R/'curricula/DE/Gymnasium/canonical').glob('**/*Mathematik*.json')),*list((R/'curricula/DE/Gymnasium/canonical').glob('**/*Physik*.json'))]
protected+=list((R/'curricula/DE/Gymnasium/composition-views/mathematik').glob('*.json'))+list((R/'curricula/DE/Gymnasium/composition-views/physik').glob('*.json'))
write('protected-root-before.actual.json',[{'path':str(x.relative_to(R)),'sha256':sha(x)} for x in protected if x.is_file()])
