// SPDX-License-Identifier: Apache-2.0
// Read-only factual integration audit; no new subject-matter decisions or source writes.
import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { pathToFileURL } from 'node:url'
const root='/home/enpasos/projects/skillpilot'
const tmp=path.join(root,'tmp/cross-subject-requires')
const base=path.join(tmp,'current-science-index-proposal-versus-adoption-independent-audit-20261015-v1')
const indexRoot=path.join(tmp,'canonical-gymnasium-effective-review-index-20261015-v21')
const censusRoot=path.join(tmp,'current-science-proposal-versus-adoption-audit-root-20261015-v1')
const { stableJson,fingerprint,bytesFingerprint }=await import(pathToFileURL(path.join(root,'app/scripts/lib/crossSubjectRequiresInventory.ts')).href)
const { validateRequiresDecisions }=await import(pathToFileURL(path.join(root,'app/scripts/lib/crossSubjectRequiresReview.ts')).href)
const same=(a:any,b:any)=>stableJson(a)===stableJson(b)
const hash=(p:string)=>bytesFingerprint(fs.readFileSync(p))
const rel=(p:string)=>path.relative(root,p)
const bind=(p:string)=>({path:rel(p),bytes:fs.statSync(p).size,sha256:hash(p)})
const cache=new Map<string,any>()
const read=(p:string):any=>{const absolute=path.resolve(root,p);if(!cache.has(absolute))cache.set(absolute,JSON.parse(fs.readFileSync(absolute,'utf8')));return cache.get(absolute)}
const write=(name:string,data:any)=>{const out=path.join(base,name);if(!out.startsWith(base+'/'))throw new Error('Output outside own namespace');fs.writeFileSync(out,JSON.stringify(data,null,2)+'\n')}
const assert=(condition:any,message:string)=>{if(!condition)throw new Error(message)}
const indexPath=path.join(indexRoot,'effective-goal-index.json')
const before=[indexPath,path.join(indexRoot,'actual-read-bindings.json'),path.join(censusRoot,'HANDOFF.actual.json'),path.join(censusRoot,'audit.actual.json'),path.join(root,'.git/index'),path.join(tmp,'three-current-native-d-synthesis-and-fifteen-binding-audit-20261015-v1/SEAL.actual.json')].map(bind)
assert(hash(path.join(censusRoot,'HANDOFF.actual.json'))==='sha256:07c03c7056701d07f51f97404796fd683c303e27335e562dc2dc65f6b1686f8b','Root handoff differs from assignment')
const index=read(indexPath),rootAudit=read(path.join(censusRoot,'audit.actual.json')),rootHandoff=read(path.join(censusRoot,'HANDOFF.actual.json'))
const readBindings=read(path.join(indexRoot,'actual-read-bindings.json'))
assert(Array.isArray(readBindings)&&readBindings.length===737,'Expected737 read bindings')
const checkedReadBindings=readBindings.map((row:any)=>{const actual=bind(path.resolve(root,row.path));assert(actual.sha256==='sha256:'+row.sha256.replace(/^sha256:/,'')&&actual.bytes===row.bytes,'Read binding drift: '+row.path);return actual})
write('technical/737-actual-read-bindings.independently-verified.json',{actualCount:checkedReadBindings.length,allPassed:true,files:checkedReadBindings})
const mathPath=path.join(root,'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json')
const physicsPath=path.join(root,'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json')
assert(hash(mathPath)==='sha256:893a43d06900708643a33bf490820db6444078ec8284a1aa7086a8ecc30ce2ae','Math fingerprint changed')
assert(hash(physicsPath)==='sha256:38dcc3a7e4f910e6d7c8129d14d88cc198534f2bf7d449fc05ef5d5d7f97e637','Physics fingerprint changed')
const math=read(mathPath),physics=read(physicsPath)
const maps:any={mathematics:new Map(math.goals.map((g:any)=>[g.id,g])),physics:new Map(physics.goals.map((g:any)=>[g.id,g]))}
assert(maps.mathematics.size===math.goals.length&&maps.physics.size===physics.goals.length,'Duplicate canonical goals')
assert([...maps.mathematics.keys()].every(x=>!maps.physics.has(x)),'Canonical cross-subject ID collision')
const inventoryPath='curricula/quality/cross-subject-requires/math-physics.inventory.json'
const inventory=read(inventoryPath)
assert(inventory.families.length===1&&inventory.families[0].familyId==='canonical-gymnasium','Outside canonical Gymnasium')
const current=new Map(inventory.families[0].goals.filter((g:any)=>g.reviewRequired).map((g:any)=>[g.goalId,g]))
assert(current.size===1285&&index.records.length===1285&&new Set(index.records.map((r:any)=>r.goalId)).size===1285,'1285 universe mismatch')
assert(index.records.every((r:any)=>current.has(r.goalId)),'Index/current goal universe mismatch')
// Reconstruct actual selected P ownership from the current registry, not old receipts.
const registryPath='curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
const registry=read(registryPath)
const owners=new Map<string,any[]>()
const jsonlCache=new Map<string,any[]>()
const jsonl=(p:string)=>{if(!jsonlCache.has(p))jsonlCache.set(p,fs.readFileSync(path.resolve(root,p),'utf8').split(/\r?\n/).filter(l=>l.trim()).map(l=>JSON.parse(l)));return jsonlCache.get(p)!}
const kindIds:any={}
for(const subject of registry.subjects.filter((s:any)=>['mathematik','physik'].includes(s.subject))){
 const subjectName=subject.subject==='mathematik'?'mathematics':'physics'
 const kind=read(subject.semanticKindLedgerPath)
 kindIds[subjectName]=new Set(kind.decisions.filter((d:any)=>d.semanticKind==='curricularAtomic').map((d:any)=>d.goalId))
 for(const cp of subject.positiveEvidenceConfigPaths){
  const config=read(cp),records=jsonl(config.reviewPath)
  for(const goalId of config.scope.goalIds){
   if(!current.has(goalId))continue
   const matches=records.filter((r:any)=>r.goalId===goalId)
   assert(matches.length===1,'Nonunique actual P record: '+goalId)
   const record=matches[0];owners.set(goalId,[...(owners.get(goalId)??[]),{config:bind(path.resolve(root,cp)),review:bind(path.resolve(root,config.reviewPath)),profileBodySha256:fingerprint(record.profile),profileFingerprint:record.profileFingerprint,completeRecordSha256:fingerprint(record)}])
  }
 }
}
assert(kindIds.mathematics.size===807&&kindIds.physics.size===478,'Current Kind ordinary denominator differs')
for(const id of current.keys())assert(owners.get(id)?.length===1,'Exactly one P owner expected: '+id)
// Recompute the deterministic native checks for every original author/reviewer pair.
const pairs=read(path.join(indexRoot,'pairwise-current-technical-validation.json')).pairs
const pairBy=new Map<string,any>(),pairResults=[]
for(const pair of pairs){
 const author=read(pair.author.path),review=read(pair.review.path)
 assert(hash(path.resolve(root,pair.author.path))===pair.author.sha256,'Author changed')
 assert(hash(path.resolve(root,pair.review.path))===pair.review.sha256,'Review changed')
 const actual=validateRequiresDecisions(inventory,author,{familyIds:['canonical-gymnasium'],independentReview:review,authorLedgerSha256:pair.author.sha256,inventorySha256:hash(path.resolve(root,inventoryPath)),reviewedInventorySha256:author.baselineInventorySha256??review.inventorySha256,sourcePathExists:(p:string)=>fs.existsSync(path.resolve(root,p))})
 assert(same(actual,pair.currentTechnicalValidation),'Native technical result differs: '+pair.role)
 const globalErrors=actual.errors.filter((e:string)=>![...current.keys()].some((id:any)=>e.includes(id)))
 pairBy.set(pair.author.path+'\0'+pair.review.path,{author,review,technical:actual,globalErrors})
 pairResults.push({role:pair.role,author:pair.author,review:pair.review,nativeResultMatchesRecorded:true,required:actual.required,reviewed:actual.reviewed,open:actual.open,errorCount:actual.errors.length,globalErrors})
}
write('technical/native-all-pairs-replay.actual.json',{pairCount:pairResults.length,allMatchRecorded:true,scope:'Deterministic technical replay only; historical and pending errors are preserved, not treated as new scientific verdicts.',pairs:pairResults})
const deriveP=(author:any,peer:any,role:string,goal:any,actualOwners:any[])=>{
 const p=peer.positiveEvidenceReview
 const conditional=peer.proposedProfileBodySha256??p?.exactProposedProfileBodySha256??author.profileAmendmentProposedBodySha256??null
 const directFp=p?.profileFingerprint??peer.currentWholePositiveEvidenceBinding?.profileFingerprint??author.currentWholePositiveEvidenceBinding?.profileFingerprint??null
 const directBody=peer.currentWholePositiveEvidenceBinding?.wholeCurrentProfileBodySha256??author.currentWholePositiveEvidenceBinding?.wholeCurrentProfileBodySha256??null
 const exactRoles=['self-induction41-two-exact-current-whole-Goal-P-independent-peer','five-existing-math45-exact-current-whole-Goal-P-independent-peer','eye-current-exact-whole-Goal-P-independent-peer']
 let satisfied=conditional?actualOwners.every(o=>o.profileBodySha256===conditional):(!directFp||actualOwners.every(o=>o.profileFingerprint===directFp))&&(!directBody||actualOwners.every(o=>o.profileBodySha256===directBody))
 let exactWholeGoal:null|boolean=null
 if(exactRoles.includes(role)){
  const a=author.positiveEvidenceCondition,b=peer.positiveEvidenceCondition
  assert(a&&b,'Missing whole Goal/P condition')
  assert(role==='five-existing-math45-exact-current-whole-Goal-P-independent-peer'?Object.keys(a).every(k=>same(a[k],b[k])):same(a,b),'Author/peer whole Goal/P condition differs')
  exactWholeGoal=fingerprint(goal)===a.wholeGoalStableJsonSha256
  satisfied=exactWholeGoal&&actualOwners.every(o=>o.profileBodySha256===a.wholeProfileStableJsonSha256&&o.profileFingerprint===a.profileFingerprint)
 }
 return {satisfied,conditionalBody:conditional,directFingerprint:directFp,directBody,exactWholeGoal}
}
const rootRows=new Map(rootAudit.records.map((r:any)=>[r.goalId,r]))
const rows:any[]=[]
for(const record of index.records){
 const own=maps[record.subject],opposite=record.subject==='physics'?maps.mathematics:maps.physics
 const goal=own.get(record.goalId);assert(goal&&kindIds[record.subject].has(goal.id),'Goal not in current ordinary subject: '+record.goalId)
 assert(goal.title===record.title,'Title differs: '+goal.id)
 const inv:any=current.get(goal.id),occ=inv.occurrences.filter((o:any)=>o.selected)
 assert(occ.length===1&&same(occ[0].directRequires,goal.requires??[]),'Inventory/direct Goal requires drift: '+goal.id)
 const selected=record.selectedRecord,pair:any=pairBy.get(selected.authorPath+'\0'+selected.reviewPath)
 assert(pair,'Selected pair missing')
 const author=pair.author.decisions.find((d:any)=>d.decisionId===selected.decisionId)
 const peer=pair.review.decisions[selected.reviewRecordIndex]
 assert(author&&peer&&peer.decisionId===author.decisionId&&author.dependentGoalId===goal.id,'Selected original record identity differs')
 assert(hash(path.resolve(root,selected.authorPath))===selected.authorSha256&&hash(path.resolve(root,selected.reviewPath))===selected.reviewSha256,'Selected exact file hash differs')
 assert(peer.decision===selected.independentScientificVerdict&&author.decision===selected.requiresDecision&&same(author.prerequisiteGoalIds,selected.proposedForeignPrerequisiteIds),'Original selected opinions changed')
 const baselineMatches=occ.some((o:any)=>same(o.reviewInput,author.reviewInput))
 const proposedMatches=!!author.proposalBinding&&occ.some((o:any)=>same(o.reviewInput,author.proposalBinding.proposed)&&same(o.directRequires,author.proposalBinding.proposedRequires))
 assert(baselineMatches===selected.currentMatchesBaseline&&proposedMatches===selected.currentMatchesProposed,'Current baseline/proposal match flag differs')
 const decisionErrors=pair.technical.errors.filter((e:string)=>e.includes(goal.id))
 const errors=[...pair.globalErrors,...decisionErrors]
 const technical=peer.decision==='approved'&&['add','retain','remove','replace','no_cross_subject_required'].includes(author.decision)&&author.applicability?.universality==='allDependentScopes'&&!!peer.rationale?.trim()&&same(peer.reviewInput,author.reviewInput)&&(!author.proposalBinding||peer.proposalBindingSha256===fingerprint(author.proposalBinding))&&!!peer.reviewer?.trim()&&peer.reviewer.trim().toLowerCase()!==author.author?.trim().toLowerCase()&&errors.length===0&&(baselineMatches||proposedMatches)
 assert(!!technical===selected.technicallyCurrentApprovedBinding&&same(errors,selected.technicalErrors),'Selected technical acceptance differs')
 const actualOwners=owners.get(goal.id)!
 assert(same(actualOwners,selected.positiveEvidenceBodyBinding.actualCurrentOwners),'Current P owner binding differs')
 const p=deriveP(author,peer,selected.role,goal,actualOwners)
 assert(p.satisfied===selected.positiveEvidenceBodyBinding.explicitSelectedProfileBindingSatisfied,'Actual selected P condition differs')
 const primary=record.originalDecisionHistory.find((h:any)=>h.role==='primary'),fourth=record.originalDecisionHistory.find((h:any)=>h.role==='distinct-fourth-batch-peer')
 const fourthDissent=!!fourth&&fourth.independentScientificVerdict!==primary.independentScientificVerdict
 const explicitRevision=selected.role!=='primary'
 const accepted=!!technical&&!(fourthDissent&&!explicitRevision)&&p.satisfied
 assert(accepted===record.effectiveCurrentScientificBindingAccepted,'Effective selected acceptance flag differs')
 const currentForeign=[...new Set((goal.requires??[]).filter((id:string)=>opposite.has(id)))].sort()
 assert(same(currentForeign,[...record.activeForeignRequires].sort()),'Current canonical foreign set differs from index')
 const proposedForeign=[...new Set(author.prerequisiteGoalIds)].sort()
 const equal=same(currentForeign,proposedForeign)
 const actual={goalId:goal.id,subject:record.subject,title:goal.title,reviewBindingAccepted:accepted,selectedRequiresDecision:author.decision,currentForeignRequires:currentForeign,selectedProposedForeignRequires:proposedForeign,foreignSetEqual:equal,proposedIdsNotInCurrentOppositeSubject:proposedForeign.filter((id:any)=>!opposite.has(id)),currentMatchesBaseline:baselineMatches,currentMatchesProposedWholeBinding:proposedMatches,authorPath:selected.authorPath,authorSha256:selected.authorSha256,reviewPath:selected.reviewPath,reviewSha256:selected.reviewSha256,classification:!accepted?'pending_review_binding':equal?'accepted_review_foreign_set_current':'accepted_review_proposed_foreign_set_differs_from_current'}
 assert(same(actual,rootRows.get(goal.id)),'Root row disagrees with independent derivation: '+goal.id)
 rows.push({...actual,hasProposalBinding:!!author.proposalBinding,currentDirectRequires:goal.requires??[],actualSelectedPConditionSatisfied:p.satisfied,hasExplicitProposedPBodyCondition:!!p.conditionalBody,actualWholeGoalConditionMatches:p.exactWholeGoal,foreignIdsPresentOnlyInProposal:proposedForeign.filter((id:any)=>!currentForeign.includes(id)),foreignIdsPresentOnlyInCurrent:currentForeign.filter((id:any)=>!proposedForeign.includes(id)),foreignIdsCommonToBoth:currentForeign.filter((id:any)=>proposedForeign.includes(id))})
}
const accepted=rows.filter(r=>r.reviewBindingAccepted),different=accepted.filter(r=>!r.foreignSetEqual),sameForeign=accepted.filter(r=>r.foreignSetEqual)
const count=(items:any[],f:(x:any)=>string)=>Object.fromEntries([...new Set(items.map(f))].sort().map(k=>[k,items.filter(x=>f(x)===k).length]))
const activeFull=[]
for(const [subject,own]of Object.entries(maps)as any){const other=subject==='physics'?maps.mathematics:maps.physics;for(const g of own.values())for(const id of g.requires??[])if(other.has(id))activeFull.push({dependentGoalId:g.id,subject,prerequisiteGoalId:id})}
const acceptedWholeFalse=accepted.filter(r=>!r.currentMatchesProposedWholeBinding)
const noProposalBinding=acceptedWholeFalse.filter(r=>!r.hasProposalBinding)
const counts={universe:rows.length,acceptedReviewBindings:accepted.length,pendingReviewBindings:rows.length-accepted.length,acceptedReviewForeignSetEqualsCurrent:sameForeign.length,acceptedReviewForeignSetDiffersFromCurrent:different.length,differentByDecision:count(different,r=>r.selectedRequiresDecision),differentBySubject:count(different,r=>r.subject),differentWithUnknownProposedIds:different.filter(r=>r.proposedIdsNotInCurrentOppositeSubject.length).length}
assert(same(counts,rootAudit.counts)&&same(counts,rootHandoff.counts),'Root summary counters disagree')
assert(activeFull.length===45&&new Set(activeFull.map(x=>x.dependentGoalId)).size===36&&new Set(activeFull.map(x=>x.prerequisiteGoalId)).size===29,'Active canonical45/36/29 count differs')
assert(activeFull.every(x=>x.subject==='physics'),'Unexpected Mathematics-to-Physics direct edge')
// Literal contains-ancestor edge facts, without a didactic redundancy verdict.
const parents=new Map<string,string[]>()
for(const g of physics.goals)for(const child of g.contains??[])parents.set(child,[...(parents.get(child)??[]),g.id])
function ancestors(id:string){const seen=new Set<string>(),todo=[...(parents.get(id)??[])];while(todo.length){const a=todo.pop()!;if(seen.has(a))continue;seen.add(a);todo.push(...(parents.get(a)??[]))}return [...seen]}
const inheritedFacts=[]
for(const r of different){
 const inherited=new Map<string,string[]>()
 for(const ancestor of ancestors(r.goalId))for(const req of maps.physics.get(ancestor)?.requires??[])if(maps.mathematics.has(req))inherited.set(req,[...(inherited.get(req)??[]),ancestor])
 const alreadyViaAncestor=r.foreignIdsPresentOnlyInProposal.filter((id:string)=>inherited.has(id)).map((id:string)=>({prerequisiteGoalId:id,ancestorGoalIds:inherited.get(id)}))
 if(alreadyViaAncestor.length)inheritedFacts.push({goalId:r.goalId,title:r.title,alreadyRequiredLiterallyByContainsAncestor:alreadyViaAncestor})
}
const extras={acceptedWholeBindingFalse:acceptedWholeFalse.length,acceptedWholeBindingFalseWithForeignSetDifference:different.filter(r=>!r.currentMatchesProposedWholeBinding).length,acceptedWholeBindingFalseWithEqualForeignSet:noProposalBinding.map(r=>({goalId:r.goalId,title:r.title,requiresDecision:r.selectedRequiresDecision,currentForeignRequires:r.currentForeignRequires,currentMatchesBaseline:r.currentMatchesBaseline,hasProposalBinding:r.hasProposalBinding,meaning:'The selected author record has no proposalBinding. The generator intentionally computes currentMatchesProposed=false when no proposal object exists. This false value does not establish an unadopted whole-Goal change.'})),all1285CurrentMatchesProposedFalse:rows.filter(r=>!r.currentMatchesProposedWholeBinding).length,acceptedUnknownProposedOppositeSubjectIds:accepted.flatMap(r=>r.proposedIdsNotInCurrentOppositeSubject),pendingUnknownProposedOppositeSubjectIds:rows.filter(r=>!r.reviewBindingAccepted&&r.proposedIdsNotInCurrentOppositeSubject.length).map(r=>({goalId:r.goalId,ids:r.proposedIdsNotInCurrentOppositeSubject})),equalAcceptedWithEmptyForeignSet:sameForeign.filter(r=>r.currentForeignRequires.length===0).length,explicitProposedPBodyConditions:rows.filter(r=>r.hasExplicitProposedPBodyCondition).length,allActualSelectedPConditionsSatisfied:rows.every(r=>r.actualSelectedPConditionSatisfied),activeCanonicalForeignRefs:activeFull.length,activeCanonicalForeignOwners:new Set(activeFull.map(x=>x.dependentGoalId)).size,referencedCanonicalMathGoals:new Set(activeFull.map(x=>x.prerequisiteGoalId)).size,literalAncestorRedundancyFactCount:inheritedFacts.length}
assert(extras.acceptedWholeBindingFalse===111&&extras.acceptedWholeBindingFalseWithForeignSetDifference===109&&noProposalBinding.length===2,'111/109/2 distinction differs')
const priorBase=path.join(tmp,'three-current-native-d-synthesis-and-fifteen-binding-audit-20261015-v1')
const priorSeal=read(path.join(priorBase,'SEAL.actual.json'))
for(const f of priorSeal.files){const p=path.resolve(root,f.path);assert(hash(p)===f.sha256&&fs.statSync(p).size===f.bytes,'Prior D artifact changed: '+f.path)}
assert(priorSeal.files.length===27,'Prior D27 seal member count changed')
for(const b of before)assert(same(bind(path.resolve(root,b.path)),b),'Read-only snapshot changed: '+b.path)
write('independent-audit.actual.json',{completedUTC:new Date().toISOString(),status:'INDEPENDENT_READ_ONLY_FACTUAL_CENSUS_MATCHES_ROOT_WITH_NO_PROPOSAL_BINDING_CLARIFICATION',scope:'Canonical Gymnasium Mathematics/Physics current selected review index versus actual canonical direct foreign prerequisites. No science verdicts or source writes.',canonicalFingerprints:{mathematik:hash(mathPath),physik:hash(physicsPath)},index:bind(indexPath),rootHandoff:bind(path.join(censusRoot,'HANDOFF.actual.json')),verifiedActualReadBindings:checkedReadBindings.length,independentlyReplayedNativePairs:pairResults.length,currentOrdinaryUniverseBySubject:{mathematics:kindIds.mathematics.size,physics:kindIds.physics.size},counts,additionalFacts:extras,literalContainsAncestorFacts:{scope:'Literal prerequisite already named by a current contains ancestor; no source/scope/minimality verdict and no transitive closure or route acceptance.',records:inheritedFacts},activeCanonicalForeignReferences:activeFull,records:rows,preservation:{before,unchangedAfter:true,priorD27SealVerifiedUnchanged:true,priorD27Seal:bind(path.join(priorBase,'SEAL.actual.json')),allOriginalAuthorReviewerDecisionBytesPreserved:true},interpretation:['1250/1285 is current scientific review-binding completion only; it is not adoption, whole-goal, source/target, strictM7 or learner completion.','109 accepted Physics foreign sets differ from the current canonical graph: 108 add proposals and one replace. They are integration/reconciliation items, not authority for 109 literal edge additions or new scientific rejections. Effective inherited prerequisites, source/scope, granularity, DAG and route gates remain separate.','1141 accepted foreign sets match current graph; many are empty. Equality does not establish all other gates.','111 accepted currentMatchesProposed=false flags must not be conflated with109 foreign-set differences. The other2 selected no-cross decisions have no proposalBinding at all, so false here is the absence of a proposal to match, not evidence of different whole-Goal semantics.','All original selected scientific opinions and pending conditions remain unchanged. This audit only validates factual input, binding and direct-graph comparisons.'],noNewScienceVerdicts:true,noMainIndexDBRegistryActiveBundleSnapshotWrites:true,licensing:'Software Apache-2.0; derived factual curriculum evidence CC-BY-4.0, attribution SkillPilot; original rights preserved.'})
write('technical/input-code-bindings.actual.json',{files:[...before,bind(mathPath),bind(physicsPath),bind(path.join(root,inventoryPath)),bind(path.join(root,registryPath)),bind(path.join(indexRoot,'generator.original.ts')),bind(path.join(indexRoot,'pairwise-current-technical-validation.json')),bind(path.join(root,'app/scripts/lib/crossSubjectRequiresInventory.ts')),bind(path.join(root,'app/scripts/lib/crossSubjectRequiresReview.ts')),bind(path.join(root,'app/scripts/lib/crossLandscapeGraph.ts')),bind(path.join(tmp,'audit-current-science-proposals-versus-adoption-root-20261015-v1.py'))],nodeVersion:process.version,readOnlySourceFiles:true})
console.log(JSON.stringify({counts,additionalFacts:extras,pairs:pairResults.length,verifiedReadBindings:checkedReadBindings.length,all1285RootRowsMatch:true,priorD27SealVerified:true},null,2))
