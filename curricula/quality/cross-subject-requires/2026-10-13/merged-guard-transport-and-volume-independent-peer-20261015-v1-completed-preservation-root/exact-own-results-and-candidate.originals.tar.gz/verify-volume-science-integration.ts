import assert from 'node:assert/strict'
import {readFileSync,writeFileSync,readdirSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {dirname,join} from 'node:path'
import {fileURLToPath} from 'node:url'
import {normalizeCanonicalLandscape} from './workspace/app/src/utils/authoring/canonicalAuthoring'
import {normalizeCompositionView,collectCompositionProjectionRoleGoalIds,compileCompositionView} from './workspace/app/src/utils/authoring/compositionViewAuthoring'
import {loadRegisteredCurrentPositiveEvidenceOwners} from './workspace/app/scripts/currentPositiveEvidenceOwners'
import {fingerprintSemanticKindSourceGoal} from './workspace/app/scripts/goalBookModel'
import {validatePositiveGoalEvidenceRecordSemantics} from './workspace/app/scripts/positiveGoalEvidenceProfileModel'
import {collectRequiredTaskMaterialDigests} from './workspace/app/scripts/goalEvidenceTaskMaterials'
const R='/home/enpasos/projects/skillpilot',L=dirname(fileURLToPath(import.meta.url)),V=join(R,'tmp/cross-subject-requires/he-g9-volume-first-actual-preparation-author-20261015-v1')
const json=(p:string)=>JSON.parse(readFileSync(p,'utf8'));const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex')
const PH='f827b00f-af7f-52de-84aa-2a2bbaa035bd',OLD='5f548596-9bc3-532e-88a0-81d5029809e9',NEW='7c978529-ce62-5adc-897f-24ea80babbc8'
const mp='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json',pp='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json',kp='curricula/DE/Gymnasium/quality/release-model/physik.semantic-kinds.json'
const n=json(join(V,'fixed-neutral-review-input.actual.json'));const rawMath=json(join(R,mp)),basePhysics=json(join(R,pp)),rawPhysics=json(join(V,'candidate',pp));const kind=json(join(V,'candidate',kp))
assert.equal(rawMath.goals.length,1254);assert.equal(rawPhysics.goals.length,764)
assert.deepEqual(rawPhysics.goals.filter((g:any,i:number)=>JSON.stringify(g)!==JSON.stringify(basePhysics.goals[i])).map((g:any)=>g.id),[PH])
const g=rawPhysics.goals.find((g:any)=>g.id===PH);assert.deepEqual(g,n.candidateWholeGoal);assert.deepEqual(g.requires,['5c44b9ba-9b05-4774-95d5-073230d3fc4f',NEW]);assert(!g.requires.includes(OLD))
const priorP=readFileSync(join(R,n.priorPrivatePPath));const currentP=readFileSync(join(R,n.ownerReviewPath));assert.deepEqual(currentP,priorP);assert.deepEqual(JSON.parse(currentP.toString().trim()),n.candidateWholePRecord)
assert.deepEqual(g,json(join(R,n.priorPrivateWholeGoalPath)).goals.find((x:any)=>x.id===PH));assert.deepEqual(kind.decisions.find((x:any)=>x.goalId===PH),n.candidateKindDecision);assert.equal(n.candidateKindDecision.sourceFingerprint,fingerprintSemanticKindSourceGoal(g));assert.deepEqual(n.candidateKindDecision,json(join(R,n.priorPrivateKindPath)).decisions.find((x:any)=>x.goalId===PH))
const task=collectRequiredTaskMaterialDigests(g,join(V,'candidate'));assert.deepEqual(task.errors,[]);assert.deepEqual(validatePositiveGoalEvidenceRecordSemantics(n.candidateWholePRecord,g,task.digests,'curricularAtomic'),[])
const originalConfig=json(join(R,n.retainedOriginalConfigPath));const oldLines=readFileSync(join(R,originalConfig.reviewPath),'utf8').split(/(?<=\n)/).filter(Boolean).filter(x=>JSON.parse(x).goalId!==PH);const retainedConfigPath=json(join(V,'candidate-owner-registry-patch.actual.json')).newConfigPaths[0];const retainedConfig=json(join(R,retainedConfigPath));assert.equal(oldLines.length,7);assert.equal(oldLines.join(''),readFileSync(join(R,retainedConfig.reviewPath),'utf8'))
const math=normalizeCanonicalLandscape(rawMath),physics=normalizeCanonicalLandscape(rawPhysics);const by=new Map([...math.goals,...physics.goals].map(g=>[g.id,g]));const roots=new Map([math,physics].map(l=>[l.landscapeId,l.goals.find(g=>g.tags?.includes('root'))!.id]));const landscapes=new Map([math,physics].map(l=>[l.landscapeId,l]));const universe:any={landscapeId:'joint',title:'joint',goals:[...math.goals,...physics.goals]}
let changes=0;const compiled=[]
for(const name of readdirSync(join(R,'curricula/DE/Gymnasium/composition-views/physik')).filter(n=>n.endsWith('.view.json'))){
 const path='curricula/DE/Gymnasium/composition-views/physik/'+name;const before=json(join(R,path));const candidateFile=join(V,'candidate',path);let after:any
 try{after=json(candidateFile)}catch(e){after=before}
 const a=collectCompositionProjectionRoleGoalIds(normalizeCompositionView(before).rootNodes,by,roots),b=collectCompositionProjectionRoleGoalIds(normalizeCompositionView(after).rootNodes,by,roots)
 assert.deepEqual([...a.targetGoalIds].sort(),[...b.targetGoalIds].sort());const expected=structuredClone(before);let swap=0
 const visit=(nodes:any[])=>{for(const x of nodes){if(x.kind==='goalEntry'&&x.goalId===OLD){assert.equal(x.projectionRole,'prerequisiteOnly');x.goalId=NEW;swap++}if(x.children)visit(x.children)}};if(a.targetGoalIds.has(PH))visit(expected.rootNodes)
 assert.deepEqual(after,expected);assert.equal(swap,a.targetGoalIds.has(PH)?1:0);changes+=swap
 assert(!b.targetGoalIds.has(NEW));const c=compileCompositionView(normalizeCompositionView(after),physics,universe,landscapes);assert.deepEqual(c.findings.filter(x=>x.severity==='error'),[]);compiled.push({viewId:before.viewId,substitutions:swap,targets:a.targetGoalIds.size,compilerErrors:0})
}
assert.equal(compiled.length,69);assert.equal(changes,31)
const mb=new Map(math.goals.map(g=>[g.id,g]));const closure=new Set<string>();const visit=(id:string)=>{if(closure.has(id))return;closure.add(id);for(const req of mb.get(id)!.requires)visit(req)};visit(NEW);assert.equal(closure.size,25)
const mv=normalizeCompositionView(json(join(R,'curricula/DE/Gymnasium/composition-views/mathematik/de-he-seki-g9.view.json')));const roles=collectCompositionProjectionRoleGoalIds(mv.rootNodes,by,roots);for(const id of closure)assert(roles.targetGoalIds.has(id),id)
const registryPath=join(L,'workspace/curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json');const original=readFileSync(registryPath);let observed:any
try{writeFileSync(registryPath,readFileSync(join(V,'candidate-owner-registry.current.json')));observed=loadRegisteredCurrentPositiveEvidenceOwners({landscapePath:pp,landscapeId:physics.landscapeId,semanticKindLedgerPath:kp,atomicGoalIds:new Set(kind.decisions.filter((d:any)=>d.semanticKind==='curricularAtomic').map((d:any)=>d.goalId))});assert(observed.issues.some((s:string)=>s.includes('No unique registered current evidence source')))}finally{writeFileSync(registryPath,original)}
const out={goalId:PH,wholePRecordRawBytesEqualToExistingNative:true,wholeGoalAndKindEqualToExistingNative:true,normalPValidationErrors:[],other7SharedOwnerRawLinesExact:true,physicsViews:69,changedOnlyPrerequisiteOnlyRefs:31,targetSetsIdentical:true,compiled,currentMathGoalCount:1254,currentMathOrdinaryCount:807,mathRouteGoalCount:25,all25ActualMathTargetsWhenMathSelected:true,routeMinimalityCertified:false,authorCandidateRegistryCanonicalOwnerLookup:observed.issues,authorCandidateIntegrationBlocked:true,rootWritten:false}
writeFileSync(join(L,'VOLUME-INDEPENDENT-CHECKS.actual.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({...out,compiled:undefined}))
