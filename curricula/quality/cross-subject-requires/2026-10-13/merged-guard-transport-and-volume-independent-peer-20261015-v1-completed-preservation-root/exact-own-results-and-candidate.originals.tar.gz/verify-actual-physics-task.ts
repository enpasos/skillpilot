import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { collectRequiredTaskMaterialDigests, requiredTaskMaterialPayload } from './workspace/app/scripts/goalEvidenceTaskMaterials'
import { fingerprintPositiveGoalEvidenceReviewInput } from './workspace/app/scripts/positiveGoalEvidenceProfileModel'
const lane = dirname(fileURLToPath(import.meta.url))
const referenceRoot = '/home/enpasos/projects/skillpilot/tmp/cross-subject-requires/goalbook-actual-P-policy-current-kind-transport-repair-author-20261015-v1/native-root'
const landscape = JSON.parse(readFileSync(join(referenceRoot, 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'), 'utf8'))
const goal = landscape.goals.find((goal: any) => goal.id === 'f827b00f-af7f-52de-84aa-2a2bbaa035bd')
const config = JSON.parse(readFileSync(join(referenceRoot, 'private-native/physik.P.config.json'), 'utf8'))
const record = JSON.parse(readFileSync(join(referenceRoot, config.reviewPath), 'utf8').trim())
assert.deepEqual(config.reviewedResourceTypes, [])
const url = goal.resourceLinks.find((link: any) => link.type === 'task-material').url
const expected = 'sha256:1ffdd7f06dd21af0222d3ce1bd6b1f6408bd04ae05b1651e4a703a980ab5e289'
const filename = url.split('/').at(-1)
const sourcePath = `curricula/DE/Gymnasium/task-material/physik/${filename}`
const publicPath = `app/public${url}`
const sourceBytes = readFileSync(join(referenceRoot, sourcePath))
assert.deepEqual(sourceBytes, readFileSync(join(referenceRoot, publicPath)))
assert.equal(`sha256:${createHash('sha256').update(sourceBytes).digest('hex')}`, expected)
const root = mkdtempSync(join(lane, 'temp/actual-physics-task-'))
try {
  for (const path of [sourcePath, publicPath]) { mkdirSync(dirname(join(root,path)), {recursive:true}); writeFileSync(join(root,path),sourceBytes) }
  const state = collectRequiredTaskMaterialDigests(goal, root)
  assert.deepEqual(state.errors, [])
  assert.equal(state.digests[url], expected)
  assert.equal(requiredTaskMaterialPayload(goal, state.digests)[0].digest, expected)
  assert.equal(fingerprintPositiveGoalEvidenceReviewInput(goal, record.reviewCriteriaFingerprint, state.digests, 'curricularAtomic'), record.reviewInputFingerprint)
  assert.throws(() => requiredTaskMaterialPayload(goal, {}), /required task-material digest is missing/u)
  for (const path of [sourcePath, publicPath]) {
    for (const mode of ['missing', 'mutation', 'symlink-escape']) {
      rmSync(join(root,path));
      if (mode==='mutation') writeFileSync(join(root,path),'<svg xmlns="http://www.w3.org/2000/svg">changed</svg>')
      if (mode==='symlink-escape') symlinkSync(join(referenceRoot,path), join(root,path))
      assert.ok(collectRequiredTaskMaterialDigests(goal,root).errors.length>0, `${path} ${mode} must fail`)
      rmSync(join(root,path),{force:true});writeFileSync(join(root,path),sourceBytes)
    }
  }
  const foreign = structuredClone(goal)
  foreign.resourceLinks.find((link: any) => link.type==='task-material').url = url.replace('/physik/','/chemie/')
  assert.ok(collectRequiredTaskMaterialDigests(foreign,root).errors.length>0)
  console.log(JSON.stringify({goalId:goal.id,actualPhysicsTaskSha256:expected,optionalReviewedResourceTypes:config.reviewedResourceTypes,actualWholePInputFingerprintMatches:true,missingDigestRejected:true,sourceAndPublicMissingMutationSymlinkEscapeRejected:true,otherSubjectRejected:true,mathHelperGoalsImported:0,scientificOrDReviewAcceptance:false}))
} finally { rmSync(root,{recursive:true,force:true}) }
