from pathlib import Path
import json,subprocess,hashlib,datetime
L=Path(__file__).resolve().parent;V=Path('/home/enpasos/projects/skillpilot/tmp/cross-subject-requires/he-g9-volume-first-actual-preparation-author-20261015-v1')
for tag,file in [('fresh-existing-f827-resolution','existing-resolution-check.execution.actual.json'),('fresh-existing-f827-normal-P','normal-p-check.execution.actual.json')]:
 old=json.loads((V/file).read_text());r=subprocess.run(old['argv'],cwd=old['cwd'],capture_output=True)
 d={'argv':old['argv'],'cwd':old['cwd'],'exitCode':r.returncode,'completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'OSRootReadOnly':True}
 for kind,b in [('stdout',r.stdout),('stderr',r.stderr)]:
  p=L/f'{tag}.{kind}.raw.txt';p.write_bytes(b);d[kind]={'path':p.name,'sha256':hashlib.sha256(b).hexdigest()}
 (L/f'{tag}.execution.actual.json').write_text(json.dumps(d,indent=2)+'\n');print(tag,r.returncode,r.stdout.decode(),r.stderr.decode());assert r.returncode==0
