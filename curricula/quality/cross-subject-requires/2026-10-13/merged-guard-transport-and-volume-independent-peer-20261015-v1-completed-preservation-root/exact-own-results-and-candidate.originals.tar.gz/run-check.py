from pathlib import Path
import subprocess,sys,os,json,hashlib,datetime
L=Path(__file__).resolve().parent
name,script=sys.argv[1:3]
argv=[sys.executable,str(L/'run-root-readonly.py'),'/home/enpasos/projects/skillpilot/tmp/ci-tools/node-v20.20.2-linux-x64/bin/node','--import','tsx',str(L/script)]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(argv,cwd=L/'workspace/app',env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','TSX_DISABLE_CACHE':'1','TMPDIR':str(L/'temp')},capture_output=True)
d={'name':name,'argv':argv,'exitCode':r.returncode,'start':start,'finish':datetime.datetime.now(datetime.timezone.utc).isoformat()}
for k,b in [('stdout',r.stdout),('stderr',r.stderr)]:
 p=L/f'{name}.{k}.raw.txt';p.write_bytes(b);d[k]={'path':p.name,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
(L/f'{name}.execution.actual.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d));print(r.stdout.decode());print(r.stderr.decode());sys.exit(r.returncode)
