import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { buildGoalBookModel, type GoalBookBuildInput } from './workspace/app/scripts/goalBookModel'
import { loadDeepUnderstandingRolloutConfig } from './workspace/app/scripts/reportDeepUnderstandingRollout'
const root = resolve(dirname(fileURLToPath(import.meta.url)), 'workspace')
const bytes = (path: string) => readFileSync(resolve(root,path))
const json = (path: string) => JSON.parse(bytes(path).toString('utf8'))
const hash = (value: Uint8Array) => `sha256:${createHash('sha256').update(value).digest('hex')}`
const subject = loadDeepUnderstandingRolloutConfig().subjects.find(({subject}) => subject==='physik')!
const ids = ['09029573-864f-40ca-bf8a-cee7bf6dcb73','d18d4190-ddc1-5181-b1b6-e79947b737c2']
const producers = subject.positiveEvidenceConfigPaths.map(path => ({path,config:json(path)})).filter(({config}) => config.scope.goalIds.some((id: string) => ids.includes(id)))
assert.equal(producers.length,2)
assert.ok(producers.every(({config}) => config.reviewedResourceTypes.length===0 && config.scope.goalIds.length===1))
const qa = json(subject.visualizationQaPath)
qa.records = qa.records.filter(({goalId}: any) => ids.includes(goalId))
const assetDigests = Object.fromEntries(qa.records.map(({imageUrl}: any) => [imageUrl,hash(bytes(`app/public${imageUrl}`))]))
const external = 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
const input: GoalBookBuildInput = {
  landscape:json(subject.landscapePath),semanticKindLedger:json(subject.semanticKindLedgerPath),
  compositionView:{viewId:'private-merge-owner-producer-check',landscapeId:json(subject.landscapePath).landscapeId,scope:{schoolForm:'Gymnasium',stage:'SekII'},rootNodes:[{kind:'structure',id:'scope',label:'Technical check',children:ids.map(goalId => ({kind:'goalEntry',goalId}))}]},
  goalVisualizationQa:qa,goalVisualizationAssetDigests:assetDigests,
  externalLandscapeSources:[{path:external,landscape:json(external)}],
  evidenceReviewSources:producers.map(({config}) => ({path:config.reviewPath,text:bytes(config.reviewPath).toString('utf8')})),
  config:{bookId:'private-merge-owner-producer-check',title:'Technical merge regression',landscapePath:subject.landscapePath,semanticKindLedgerPath:subject.semanticKindLedgerPath,compositionViewPath:'private/merge-check.view.json',goalVisualizationQaPath:subject.visualizationQaPath,externalLandscapePaths:[external],publicationMode:'review',evidenceReviewPaths:producers.map(({config}) => config.reviewPath)},
}
const implicit = buildGoalBookModel(input)
const selected: GoalBookBuildInput = {...input,config:{...input.config,evidenceReviewConfigPaths:producers.map(({path}) => path)},evidenceReviewConfigSources:producers.map(({path,config})=>({path,bytes:bytes(path),reviewCriteriaDigest:hash(bytes(config.reviewCriteriaPath))}))}
const explicit = buildGoalBookModel(selected)
assert.equal(explicit.pages.length,2)
assert.deepEqual(explicit.pages.map(page=>page.evidenceReview),implicit.pages.map(page=>page.evidenceReview))
assert.deepEqual(explicit.pages.map(page=>page.visualization),implicit.pages.map(page=>page.visualization))
for (const source of explicit.source.evidenceReviewSources) {
  const producer = producers.find(({config}) => config.reviewPath===source.path)!
  assert.deepEqual(source.producerConfig?.reviewedResourceTypes,[])
  assert.equal(source.producerConfig?.digest,hash(bytes(producer.path)))
}
const reformatted = structuredClone(selected)
reformatted.evidenceReviewConfigSources![0].bytes = Buffer.concat([reformatted.evidenceReviewConfigSources![0].bytes,Buffer.from('\n')])
const reformattedModel = buildGoalBookModel(reformatted)
assert.notEqual(reformattedModel.digest,explicit.digest)
assert.deepEqual(reformattedModel.pages.map(page=>page.evidenceReview),explicit.pages.map(page=>page.evidenceReview))
const wrongOwner = structuredClone(selected)
wrongOwner.evidenceReviewConfigSources![0].bytes = Buffer.from(JSON.stringify({...producers[0].config,reviewId:'wrong-selected-owner'}))
assert.throws(()=>buildGoalBookModel(wrongOwner),/selected P producer owner/u)
assert.equal(buildGoalBookModel(input).digest,implicit.digest)
console.log('Merged canonical current-owner + explicit producer check passed: real090/d18 [] owners import identically through both paths; exact raw config bindings change Book digest only; wrong explicit owner rejected; image bindings retained.')
