from pathlib import Path
import hashlib,json,datetime
L=Path(__file__).resolve().parent;R=Path('/home/enpasos/projects/skillpilot');V=R/'tmp/cross-subject-requires/he-g9-volume-first-actual-preparation-author-20261015-v1'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=lambda p:json.loads(p.read_text())
base=j(R/'curricula/DE/Gymnasium/quality/release-model/physik.semantic-kinds.json');cand=j(V/'candidate/curricula/DE/Gymnasium/quality/release-model/physik.semantic-kinds.json')
assert len(base['decisions'])==len(cand['decisions'])==764
changed=[a['goalId'] for a,b in zip(base['decisions'],cand['decisions']) if a!=b];assert changed==['f827b00f-af7f-52de-84aa-2a2bbaa035bd']
extra={'other763PhysicsKindDecisionsExact':True,'changedKindDecisionIds':changed,'beforeAfterRootPreservationExact':j(L/'preservation.before.actual.json')==j(L/'preservation.after.actual.json')};(L/'final-additional-checks.actual.json').write_text(json.dumps(extra,indent=2)+'\n')
erratum={'contract':'peer-evidence-provenance-clarification-v1','appliesToCodeReviewSha256':h(L/'CODE-REVIEW.actual.json'),'correction':'The two initial bootstrap/audit failures were observed in tool command outputs before the capture runner existed. bootstrap-wrong-relative-cwd.stderr.raw.txt is a transcription of that tool output; initial-audit-wrong-view-glob.stderr.raw.txt is an abbreviated reconstruction, not direct raw process capture despite its historical filename. Both original failures remain visible in the session tool transcript. Treat only files produced by run-check.py/fresh-native-checks.py as captured raw process outputs. All candidate author raw failure histories were independently hash-verified in their original seals.','candidateCodeOrDataChanged':False,'judgmentChanged':False};(L/'REVIEW-EVIDENCE-PROVENANCE.actual.json').write_text(json.dumps(erratum,indent=2)+'\n')
handoff={'contract':'merged65-and-f827-independent-peer-handoff-v1','completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'codeVerdict':'BOUNDED_ACCEPT_NO_BLOCKING_CODE_FINDINGS','scienceVerdict':'BOUNDED_ACCEPT_CURRENT_WHOLE_F827_GOAL_P_KIND_AND_DIRECT_PREREQUISITE','originalAuthorIntegration':'BLOCKED_TMP_PATH_METADATA_REPRODUCED','portableV2Verdict':'BOUNDED_ACCEPT_EXACT_2CONFIG_4PATH_REPAIR_AND_NORMAL_OWNER807_478','reviews':[],'preservation':{'all737ScienceAnd348ViewsAnd924RootScriptsExactBeforeAfter':True,'forwardPhysicsToMath':45,'reverseMathToPhysics':0,'rootIndexSha256':j(L/'preservation.after.actual.json')['rootIndexSha256'],'onlyOwnLaneWritableDuringExecutableVerification':True,'outsideExistingAndNewErrno':30,'ownWriteSucceeded':True},'noRootOrOtherLaneMutation':True,'noGitStatusIndexStagingCommit':True,'limitations':'No aggregate/M7, other joint-goal scientific approval, new D campaign, formal whole-source review, real learner/host/human acceptance, Root adoption, publication or deployment. See substantive review boundaries and evidence provenance clarification.'}
for name in ['CODE-REVIEW.actual.json','VOLUME-SCIENCE-REVIEW.actual.json','PORTABLE-V2-REVIEW.actual.json','VOLUME-INDEPENDENT-CHECKS.actual.json','REVIEW-EVIDENCE-PROVENANCE.actual.json','preservation.before.actual.json','preservation.after.actual.json','final-additional-checks.actual.json']:
 p=L/name;handoff['reviews'].append({'path':name,'sha256':h(p),'bytes':p.stat().st_size})
(L/'HANDOFF.actual.json').write_text(json.dumps(handoff,ensure_ascii=False,indent=2)+'\n')
# Freeze review results, programs and captured command outputs; candidate code65 is
# bound explicitly through CANDIDATE and audited pre/post image manifests.
files=[]
for p in sorted(L.iterdir()):
 if p.is_file() and p.name!='SEAL.actual.json':
  if p.suffix in ['.json','.py','.ts','.cjs','.txt','.png']:files.append({'path':p.name,'sha256':h(p),'bytes':p.stat().st_size})
for p in files:
 if p['path'].endswith('.json'):j(L/p['path'])
seal={'contract':'frozen-independent-merged65-f827-review-seal-v1','status':'FROZEN_BOUNDED_PEER_REVIEW_NO_ROOT_ADOPTION','fileCount':len(files),'files':files,'codeManifestSha256':'33b50980b2bdbb2df459cd6f9ab63cd188a69ca418653b1019fe1ab5aa219860','volumeNeutralInputSha256':'17c3b7552fba9a6287be30723f4e982da42641409e9aa6dd845b6d9d3b6283cf','portableJointV2ManifestSha256':'a840b2a1fec3027f74c1bcd9487b3d40b79f0a7437e187da33beb3bfc1b6a014'}
(L/'SEAL.actual.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps({'HANDOFF':h(L/'HANDOFF.actual.json'),'SEAL':h(L/'SEAL.actual.json'),'files':len(files),'portableV2Review':h(L/'PORTABLE-V2-REVIEW.actual.json')}))
