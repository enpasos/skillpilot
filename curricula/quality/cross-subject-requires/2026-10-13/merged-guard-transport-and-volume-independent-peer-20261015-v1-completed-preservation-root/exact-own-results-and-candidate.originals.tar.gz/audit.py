from pathlib import Path
import hashlib,json,os,sys,errno
R=Path('/home/enpasos/projects/skillpilot');L=Path(__file__).resolve().parent
A=R/'tmp/cross-subject-requires/merge-current-p-guard-and-native-transport-author-20261015-v1';V=R/'tmp/cross-subject-requires/he-g9-volume-first-actual-preparation-author-20261015-v1'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=lambda p:json.loads(p.read_text())
if sys.argv[1]=='selftest':
 result={}
 for label,p in [('existing',R/'AGENTS.md'),('new',R/'tmp/cross-subject-requires/peer-new-canary-never-created')]:
  try:
   fd=os.open(p,os.O_WRONLY|os.O_CREAT,0o600);os.close(fd);raise AssertionError('outside writable')
  except OSError as e:assert e.errno==errno.EROFS;result[label]=e.errno
 p=L/'positive-canary';p.write_text('own lane');p.unlink();result['ownwrite']=True
 (L/'readonly-selftest.actual.json').write_text(json.dumps(result,indent=2)+'\n');print(result);sys.exit()
for lane,expected in [(A,'db380ff2d55db4456a443990625e1bdc3f1ea681620c79538af9ccac3b4c85e2'),(V,'d7cd48e9cb64114c5f3dc5355ad3cf5953d4a84d687926a0d129052b92f357f6')]:
 assert h(lane/'SEAL.actual.json')==expected
 for e in j(lane/'SEAL.actual.json')['files']:
  p=lane/e['path'];assert h(p)==e['sha256'].removeprefix('sha256:'),(p,'seal');assert p.stat().st_size==e['bytes']
C=j(A/'CANDIDATE.actual.json');assert len(C['files'])==65
for f in C['files']:
 p=R/f['path'];assert (h(p) if p.exists() else None)==f['preimageSha256'],('pre',p)
 assert h(A/f['candidatePath'])==f['afterSha256'];assert h(L/'workspace'/f['path'])==f['afterSha256']
science=j(V/'all737-current-scientific-input-bindings-rechecked.actual.json')['inputs'];assert len(science)==737
for e in science:assert h(R/e['path'])==e['expected'].removeprefix('sha256:'),(e['path'],'science')
views=sorted((R/'curricula/DE/Gymnasium/composition-views').rglob('*.view.json'));assert len(views)==348
prior=j(V/'prior-peer-source-bindings-rechecked.actual.json')['fileBindings']
for e in prior:assert h(R/e['path'])==e['recordedSha256'].removeprefix('sha256:')
physics=j(R/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json');math=j(R/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json')
mids={x['id'] for x in math['goals']};pids={x['id'] for x in physics['goals']}
payload={'codeSealFiles':len(j(A/'SEAL.actual.json')['files']),'volumeSealFiles':len(j(V/'SEAL.actual.json')['files']),'scienceCount':len(science),'priorFileBindingsCount':len(prior),'rootIndexSha256':h(R/'.git/index'),'rootViews':{str(p.relative_to(R)):h(p) for p in views},'rootScripts':{str(p.relative_to(R)):h(p) for p in (R/'app/scripts').rglob('*') if p.is_file()},'forward':sum(r in mids for g in physics['goals'] for r in g.get('requires',[])),'reverse':sum(r in pids for g in math['goals'] for r in g.get('requires',[])),'all65PrePostExact':True,'allSealsExact':True,'all737Exact':True}
phase=sys.argv[1]
if phase=='after':
 before=j(L/'preservation.before.actual.json');assert payload==before,'preservation drift'
(L/f'preservation.{phase}.actual.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps({k:v for k,v in payload.items() if k not in ['rootViews','rootScripts']}))
