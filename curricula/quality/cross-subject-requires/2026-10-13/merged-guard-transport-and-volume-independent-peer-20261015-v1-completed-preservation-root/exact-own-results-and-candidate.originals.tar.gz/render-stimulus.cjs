const fs = require('node:fs');
const path = require('node:path');
const {chromium} = require('/home/enpasos/projects/skillpilot/app/node_modules/playwright');
(async()=>{
 const source='/home/enpasos/projects/skillpilot/tmp/cross-subject-requires/he-g9-volume-first-actual-preparation-author-20261015-v1/candidate/curricula/DE/Gymnasium/task-material/physik/cuboid-rulers-1ffdd7f06dd21af0222d3ce1bd6b1f6408bd04ae05b1651e4a703a980ab5e289.svg';
 const browser=await chromium.launch({headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1200,height:900},deviceScaleFactor:1});
 await page.goto('file://'+source); await page.screenshot({path:path.join(__dirname,'stimulus.independent-render.png')});await browser.close();console.log('Rendered bound exact SVG using Chromium, 1200x900.');
})().catch(e=>{console.error(e);process.exit(1)});
