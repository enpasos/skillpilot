# SPDX-License-Identifier: Apache-2.0
"""Actual author arithmetic and bounded independent-ray thin-lens simulation."""
import datetime,json,math
from pathlib import Path
B=Path(__file__).parent
def rays(g,f,b=24,h=10):
    # Rays propagate from the object at(-g,h), lens plane x=0. The first
    # arrives parallel and leaves with slope-h/f; the central ray is undeviated.
    parallel=(h,-h/f);central=(0,-h/g)
    intersection_x=(central[0]-parallel[0])/(parallel[1]-central[1])
    intersection_y=parallel[0]+parallel[1]*intersection_x
    y_retina=[y+m*b for y,m in [parallel,central]]
    return {'g_mm':g,'f_mm':f,'retina_mm':b,'height_mm':h,'outgoingRayInterceptSlope':[parallel,central],
            'intersection_mm':[intersection_x,intersection_y],'retinaRayHeights_mm':y_retina,
            'retinaRaySeparation_mm':abs(y_retina[0]-y_retina[1])}
probes={
 41:[{'AU_m':6e6/4e-5,'low_m':5.98e6/4.1e-5,'high_m':6.02e6/3.9e-5,'relativeDefinitionDifference':(1.5e11-149597870700)/149597870700},
     {'radarDistance_m':3e8*500/2,'AU_m':3e8*500/2/.5,'timingAUUncertainty_m':3e8*2/2/.5}],
 42:[{'f_Hz':100*math.pi/(2*math.pi),'T_s':.02,'initialU_V':6*math.sin(math.pi/6),'initialI_A':.020*math.sin(math.pi/6)},
     {'f_Hz':100,'R_Ohm':8/.040,'initialU_V':8*math.cos(-math.pi/3),'initialI_A':.040*math.cos(-math.pi/3)}],
 43:[{'resistance_Ohm':[u/i for u,i in zip([1,2,3],[.02,.04,.06])],'copiedBad_Ohm':3/.08},
     {'lampResistance_Ohm':[u/i for u,i in zip([1,2,3],[.10,.16,.20])],'interpolated_R_Ohm':2.5/.18}],
 44:[{'providedBranches':[1.2<1.4,1.4<1.8<2.5,3.2>2.5]}, {'intervalCrossesProvidedBoundary':2.2<2.5<2.8}],
 45:[{'L_H':40*.015,'I_tau_A':.3*(1-math.exp(-1)),'I_2tau_A':.3*(1-math.exp(-2))},
     {'tau_s':.90/60,'I_tau_A':.25*math.exp(-1),'I_2tau_A':.25*math.exp(-2),'residualAt30ms_A':.080-.25*math.exp(-2)}],
 46:[{'radius_L16_T2':math.sqrt(16/2**4),'radius_L36_T2':math.sqrt(36/2**4)},
     {'radius_L9_T1':3,'radius_L9_T2':math.sqrt(9/2**4),'fourthRootSquared':((9/2**4)**.25)**2}],
 47:[{'theta_rad':1.22*600e-9/.12,'theta_arcsec':1.22*600e-9/.12*648000/math.pi,'separation_m':2e3*1.22*600e-9/.12},
     {'d_NA08_nm':.61*500/.8,'d_NA12_nm':.61*500/1.2,'eye_arcmin':1.22*500e-9/.003*10800/math.pi}],
 48:[{'K_J':2e-19*(300+700),'v_m_s':math.sqrt(2*2e-16/4e-26),'v_c':1e5/3e8},
     {'K_J':-2e-19*(-500),'v_m_s':math.sqrt(2*1e-16/4e-26),'relativistic_v_c':math.sqrt(1-1/2**2)}],
 49:[{'E_J':.5*24*.15**2,'Ep_J':.5*24*.09**2,'K_J':.5*24*(.15**2-.09**2),'v_m_s':math.sqrt(24/.75*(.15**2-.09**2))},
     {'E_J':.30*10*.12,'v_h007':math.sqrt(2*10*(.12-.07)),'v_h0115':math.sqrt(2*10*(.12-.115))}],
 50:[{'sigmaRatio':2e7/4e-4,'negativeExponentPositive':4e-4>0}, {'semiconductorFactor':2e-3/5e-5,'metalFactor':1.8e7/2e7}],
 51:[{'AU':2.4e12/1.5e11,'lightyear':2.4e12/9.5e15,'pc3_lightyear':3*3.26}, {'massRatio':3/.15,'luminosityRatio':24/.008}],
 52:[{'gap_LK_keV':-3-(-12),'gap_MK_keV':-1.5-(-12),'gap_ML_keV':-1.5-(-3)}, {'possible14':14>12,'possible10':10>12}],
 53:[{'sumQoverT_J_K':180/450-120/300,'netHeat_J':180-120}, {'oneReservoirSum_J_K':80/400,'firstLawNet_J':80-80}],
 54:[{'requiredF_mm':1/(1/360+1/24),'simulation':rays(360,22.5)},
     {'nearRequiredF_mm':1/(1/120+1/24),'farRequiredF_mm':1/(1/300+1/24),'nearDefocusedSimulation':rays(120,21),'farFocusedSimulation':rays(300,1/(1/300+1/24))}],
 55:[{'nominalPressureFactor':10,'nominalIntensityFactor':100,'differenceInterval_dB':[88-1-(68+1),88+1-(68-1)]},
     {'firstExposureRelative':3,'secondExposureRelative':10*.3,'equalModelBudgets':math.isclose(3,10*.3)}],
 56:[{'theta1mm_deg':math.degrees(math.asin(500e-9/.001)),'theta10microm_deg':math.degrees(math.asin(500e-9/10e-6))},
     {'betaBlue_deg':math.degrees(math.asin(.5/1.55)),'betaRed_deg':math.degrees(math.asin(.5/1.50))}],
 57:[{'lambda_mm':3,'V_x3':math.exp(-1),'V_x6':math.exp(-2),'V_rmQuadrupled_x3':math.exp(-.5)},
     {'lambda_riDoubled_mm':3/math.sqrt(2),'V_x3':math.exp(-math.sqrt(2))}],
 58:[{'groundAbsorption_eV':[1.2,3.8],'excitedAbsorption_eV':3.8-1.2}, {'cascade_eV':[3.8-1.2,1.2-0],'shiftedGaps_eV':[-1.2-(-3.8),-3.8-(-5)]}],
 59:[{'loss_W':640-576,'export_W':576-420,'input_Wh':640*.5,'AC_Wh':576*.5,'loss_Wh':(640-576)*.5},
     {'idealHours':36/9,'converterDC_W':9/.8,'actualHours':36/(9/.8)}],
 60:[{'E_N_C':[-27/r**2 for r in [.15,.30,.45]],'testForce_N':(-27/.30**2)*2e-9},
     {'outsideE_N_C':[9e9*2e-9/r**2 for r in [.2,.4]],'interiorFieldNotConcluded':True}],
}
# Independent consistency checks of physical budgets, units and inverse operations.
checks={
 'AUIntervalContainsCentral':probes[41][0]['low_m']<probes[41][0]['AU_m']<probes[41][0]['high_m'],
 'pairedOhmic50':all(math.isclose(v,50) for v in probes[43][0]['resistance_Ohm']),
 'RL_tau_model':math.isclose(probes[45][0]['I_tau_A']/.3,1-math.exp(-1)),
 'radiusFourthRootEquivalent':math.isclose(((9/16)**.25)**2,math.sqrt(9/16)),
 'linacEnergyBackcheck':math.isclose(.5*4e-26*probes[48][0]['v_m_s']**2,2e-16,abs_tol=1e-30),
 'springEnergy':math.isclose(probes[49][0]['E_J'],probes[49][0]['Ep_J']+.5*.75*probes[49][0]['v_m_s']**2),
 'clausiusCycle':math.isclose(probes[53][0]['sumQoverT_J_K'],0),
 'lensFocusedRayIntersection':math.isclose(probes[54][0]['simulation']['intersection_mm'][0],24),
 'lensFocusedRetinaCoincidence':probes[54][0]['simulation']['retinaRaySeparation_mm']<1e-12,
 'lensDefocusedRetinaDifferent':probes[54][1]['nearDefocusedSimulation']['retinaRaySeparation_mm']>.5,
 'SnellTwoColors':probes[56][1]['betaBlue_deg']<probes[56][1]['betaRed_deg'],
 'cascadeSignedShiftInvariance':all(math.isclose(a,b) for a,b in zip(probes[58][1]['cascade_eV'],probes[58][1]['shiftedGaps_eV'])),
 'PVTwoBoundaries':math.isclose(320,288+32) and math.isclose(288,210+78),
 'sphereInverseSquare':math.isclose(probes[60][1]['outsideE_N_C'][1]/probes[60][1]['outsideE_N_C'][0],.25),
}
errors=[k for k,v in checks.items() if not v]
report={'role':'OWN INFORMED AUTHOR worked-model verification, no independent quality/requires approval',
 'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'positions41to60':probes,'probeCount':40,
 'actualBoundedThinLensSimulation':'Two independently propagated ideal rays, numeric intersections and fixed-retina comparisons; no interactive UI or physical/clinical experiment claim',
 'meaningfulConsistencyChecks':checks,'errors':errors,'noPOrSourceMaterialApproval':True}
dest=B/'forty-fresh-author-probe-calculations-and-lens-simulation.actual.json'
if dest.exists():raise RuntimeError('Refuse overwrite')
dest.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'freshSolvedProbes':40,'actualLensModels':3,'consistencyChecks':len(checks),'errors':errors}))
raise SystemExit(bool(errors))
