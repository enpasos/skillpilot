#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import collections, datetime, hashlib, json, math
from pathlib import Path

B=Path(__file__).parent
INPUT=B.parent/'batch-003'
ROOT=Path('tmp/cross-subject-requires/gymnasium-unresolved97-informed-reader-20261013-v1')
def fp(p):return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def checks(rows):
    errors=[]
    for x in rows:
        p=Path(x['path'])
        if not p.exists():errors.append({'path':str(p),'error':'missing'});continue
        if fp(p)!=x['sha256'] or ('bytes' in x and p.stat().st_size!=x['bytes']):errors.append({'path':str(p),'error':'byte drift'})
    return {'checked':len(rows),'errors':errors}

root=checks(json.loads((ROOT/'actual-input-bindings.json').read_text()))
snapshot=json.loads((INPUT/'own-technical-input-prepare/input-snapshot.before.json').read_text())
preserved=checks([x for x in snapshot['files'] if x.get('exists')])
whole={r['goalId']:r for r in json.loads(Path('tmp/cross-subject-requires/gymnasium-whole-positive-body-review-inputs-20261013-v1/physik/whole-goals-and-positive-profiles.current.json').read_text())['records']}
packet=json.loads((B/'native-proposal').read_text())
idx=json.loads((B/'dossier-index.json').read_text())['authorDossiers'];rows=[]
for x in idx:
    d=json.loads(Path(x['path']).read_text());r=whole[x['goalId']];errors=[]
    if fp(Path(x['path']))!=x['sha256']:errors.append('dossier bytes changed')
    if d['wholeGoal']!=r['wholeCurrentCanonicalGoal']:errors.append('whole goal changed')
    if d['wholePositiveProfile']!=r['positiveBodyOwner']['wholePositiveProfile']:errors.append('whole P changed')
    if d['positiveOwner']!=r['positiveBodyOwner']:errors.append('positive owner changed')
    if d['currentPerGoalReviewInput']!=r['currentPerGoalReviewInput']:errors.append('review triple changed')
    o=d['positiveOwner'];raw=Path(o['recordPath']).read_bytes().splitlines(keepends=True)[o['recordLine']-1]
    if 'sha256:'+hashlib.sha256(raw).hexdigest()!=o['recordRawLineSha256']:errors.append('owner raw line including newline changed')
    if checks(d['sourceFileBindings'])['errors']:errors.append('source input changed')
    p=next(v for v in packet['decisions'] if v['dependentGoalId']==x['goalId'])
    if p['reviewInput']!=r['currentPerGoalReviewInput']:errors.append('native current triple mismatch')
    if len(d['freshSolvedAuthorProbes'])!=2:errors.append('two own worked probes missing')
    if d['wholePWitness']['allApplicationCaseIdsRead']!=[c['id'] for c in d['wholePositiveProfile']['applicationCaseBriefs']]:errors.append('case IDs incomplete')
    rows.append({'index':x['index'],'goalId':x['goalId'],'state':x['decision'],'errors':errors})

probeReport=json.loads((B/'forty-fresh-author-probe-calculations-and-lens-simulation.actual.json').read_text())
calcs=probeReport['positions41to60']
arithmetic_errors=probeReport['errors']
contextReport=json.loads((B/'native-whole-context-proof/native-current-owner-triples.actual.json').read_text())
contextErrors=contextReport['errors']
ctx=json.loads((B/'whole-prerequisites-and-math-nominees.actual.json').read_text())
combined={r['goalId']:r for sub in ['mathematik','physik'] for r in json.loads(Path('tmp/cross-subject-requires/gymnasium-whole-positive-body-review-inputs-20261013-v1',sub,'whole-goals-and-positive-profiles.current.json').read_text())['records']}
for item in ctx['records']:
    r=combined[item['goalId']]
    if item['wholeCurrentGoalAndPositiveBody']!=r:contextErrors.append(item['goalId']+':whole context drift')
    o=r['positiveBodyOwner']
    if checks([{'path':o['configPath'],'sha256':o['configSha256']},{'path':o['recordPath'],'sha256':o['recordFileSha256']}])['errors']:contextErrors.append(item['goalId']+':owner bytes drift')
    raw=Path(o['recordPath']).read_bytes().splitlines(keepends=True)[o['recordLine']-1]
    if 'sha256:'+hashlib.sha256(raw).hexdigest()!=o['recordRawLineSha256']:contextErrors.append(item['goalId']+':raw line drift')
report={'role':'OWN INFORMED AUTHOR technical input and arithmetic QA; not independent review','checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root627Fresh':root,'originalSnapshotFresh':preserved,'positions41to60WholeBodiesOwnersTriplesAndCases':rows,'stateCounts':dict(collections.Counter(x['state'] for x in rows)),'baselineInventorySha256':packet['baselineInventorySha256'],'proposedStateSha256':packet['proposedStateSha256'],'proposedGraphCycles':packet['proposedGraphCycles'],'freshWorkedArithmetic':calcs,'arithmeticErrors':arithmetic_errors,'authorDossiersCompleteWithin97':60,'notYetAuthored':37,'all97IndependentApprovalAndAdoptionOpen':True,'noNativePKindSourceHumanOrM7AuthorityCreated':True,'noActiveWrites':True,'sourcePointerClarification':'SourceRef.recordId on a source-file pointer associates this dossier dependent context. Exact actual source goal IDs and whole passages are separately bound in complete-source-semantics.json; the pointer alone asserts no exact-ID presence or coverage.','sourceLimitsRetained':['AU synthetic witnesses are not supplied historical data','SL incomplete extraction/formulas','spectrum rows contain unrelated nuclear/MS/optical subtopics','only curated legacy for Clausius cycle','all16 Source/Placement/Routing remain open'],'actualCommandLogsStored':True,'wholePrerequisiteNomineeContextProofCount':contextReport['proofCount'],'wholeContextErrors':contextErrors}
dest=B/'own-input-and-arithmetic-QA.actual.json'
if dest.exists():raise RuntimeError('Refuse overwrite')
dest.write_text(json.dumps(report,ensure_ascii=True,indent=2)+'\n')
errors=root['errors']+preserved['errors']+[e for v in rows for e in v['errors']]+arithmetic_errors+contextErrors
print(json.dumps({'rootBindings':root['checked'],'originalSnapshot':preserved['checked'],'wholeGoalPChecks':len(rows),'errors':errors,'stateCounts':report['stateCounts'],'authored':60,'remainingAuthoring':37,'approvalsCreated':0}))
raise SystemExit(bool(errors))
