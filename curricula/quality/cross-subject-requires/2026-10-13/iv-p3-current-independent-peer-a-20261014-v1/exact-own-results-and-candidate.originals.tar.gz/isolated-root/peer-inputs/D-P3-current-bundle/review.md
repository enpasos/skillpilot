# AI review input: Physik – aktuelles Kennlinienziel mit P3

- Book ID: `physics-iv-p3-current-peer-a-20261014-v1`
- Book edition: `curricular-atomic-v1`
- Publication mode: `review`
- BookModel digest: `sha256:38b57bfc4ce186e75739bed1dd8523691da2da56a333f45e01958ff8b09b1d5a`
- Selected goals: 1

The PDF and this Markdown are parallel review surfaces. The normalized JSON is authoritative for exact IDs, relationships, fingerprints, and evidence-profile fields.

## Page 1: Strom-Spannungs-Kennlinien einfacher Bauteile experimentell untersuchen und deuten

- Full learning-goal ID: `66256e22-44a3-5939-8862-821e29d6711d`
- Goal fingerprint: `sha256:726ad86f33f10e44be128ce796c0746610fac16ade219f5423617b912faf4b64`
- Page fingerprint: `sha256:6c48dc7c142e5827476d6f1c0860dddb7ad5ebd500c6c87ac79d89d88999c321`
- Topic path: Physik

### Canonical description

Die lernende Person kann unter sicheren Kleinspannungsbedingungen Stromstärke und Spannung an einfachen Bauteilen systematisch messen, Kennlinien erstellen und den Zusammenhang von Spannung, Stromstärke und Widerstand deuten.

### Visualization

/assets/goal-visualizations/physik/66256e22-44a3-5939-8862-821e29d6711d/66256e22-44a3-5939-8862-821e29d6711d.jpg

- original digest: `sha256:ce7d822c6609a2ccecf73352d5cca2f30c7b4fe1b319e8089427a18bed84c419`
- QA status: `approved`
- approved for public publication: `true`

### Direct prerequisites

- None

### Direct reverse prerequisites

- None

### Prerequisites outside this book

- Zusammenhang von Spannung und Stromstärke qualitativ erläutern — `53196a71-9dbd-4835-b2f9-ff21b8a8962c` (outside this book)
- Proportionale Zusammenhänge mit Quotientengleichheit prüfen — `c1f50bcc-7848-4e49-b9de-0ec030cc6bca` (outside this book)

### Direct reverse prerequisites outside this book

- Sek-I-Abschlussaufgaben Physik selbstständig lösen — `3631c8f7-ff48-57ff-b7ee-8397ff1d166a` (outside this book)
- Prüfungsaufgabe: Kennlinien und Widerstandsnetze untersuchen — `5a530302-1303-517f-82cc-9cd457b792a8` (outside this book)
- Prüfungsaufgabe: Leitfähigkeit, Kennlinien und Widerstandsnetze untersuchen — `924e1187-a067-5eb6-8d8d-85525ee6c837` (outside this book)

### Evidence-profile candidate

Status: `needs_human_review`; profile fingerprint: `sha256:09c5d88ce0a48cf28c34f160c12c5bd22ec4a3f6e2e1e3ae40117c56e7a2c3a1`
Contract: `positive-understanding-evidence-v2`; authority: `ai_candidate`; evidence level: `E1`; maximum claim scope: `G1`
Archetype: `experiment`

**Positive understanding expectations**

- `measurement-circuit-binds-voltage-and-current`
  - Essential understanding (DE): Jeder Kennlinienpunkt besteht aus Spannung am Bauteil und Stromstärke durch dasselbe Bauteil im selben Betriebszustand. Das Strommessgerät liegt im betreffenden Zweig, das Spannungsmessgerät erfasst die Potenzialdifferenz über dem Bauteil; eine falsche Anordnung verändert oder gefährdet den Messaufbau und liefert keine gültige Wertepaarung.
  - Essential understanding (EN): Each point on a characteristic consists of the voltage across the component and the current through that same component in the same operating state. The ammeter is in the relevant branch and the voltmeter measures the potential difference across the component; an incorrect arrangement changes or endangers the setup and does not yield a valid pair of values.
  - Observable performance (DE): Die lernende Person erklärt, konstruiert oder korrigiert für ein unbekanntes Bauteil eine sichere Kleinspannungs-Messschaltung, kennzeichnet die beiden gemessenen Größen am Bauteil und begründet, weshalb jedes protokollierte U-I-Paar denselben stabilen Betriebspunkt beschreiben muss. Fachliche Anleitung beim Aufbau und bei der Geräteverwendung ist zulässig; die Erklärung und eine frische Fehlerkorrektur oder Begründung müssen eigenes Verständnis zeigen.
  - Observable performance (EN): For an unfamiliar component, the learner explains, constructs, or corrects a safe low-voltage measuring circuit, labels the two measured quantities at the component, and explains why each recorded voltage-current pair must describe the same stable operating point. Physical guidance in setup and instrument use is permitted; the explanation and a fresh correction or justification must show the learner's own understanding.
- `controlled-sweep-produces-defensible-data`
  - Essential understanding (DE): Eine aussagekräftige Kennlinie entsteht durch systematische Änderung einer Größe bei kontrollierten Bedingungen, genügend Messpunkten und Einhaltung der bereitgestellten Bauteil- und Kleinspannungsgrenzen. Erwärmung, Polarität, Messbereich und Ableseunsicherheit können die Daten beeinflussen und müssen je nach Bauteil kontrolliert oder dokumentiert werden.
  - Essential understanding (EN): A defensible characteristic is produced by systematically varying one quantity under controlled conditions, taking enough data points, and respecting supplied component and safe-low-voltage limits. Heating, polarity, instrument range, and reading uncertainty can affect the data and must be controlled or documented as appropriate to the component.
  - Observable performance (DE): Die lernende Person führt für ein bereitgestelltes Kleinspannungsbauteil eine systematische Messreihe durch und plant oder prüft begründet Schrittfolge, Nullpunkt, Messbereiche, Wiederholungen oder Wartebedingungen. Sie dokumentiert Einheiten und Unsicherheiten und erklärt, welche Variable verändert und welche Bedingungen konstant gehalten werden. Die Messfolge oder eine Protokollstruktur darf angeleitet bereitgestellt werden; gültige Wertepaarung, sichere Datenerhebung und deren fachliche Begründung bleiben nachzuweisen.
  - Observable performance (EN): For a supplied low-voltage component, the learner carries out a systematic data series and plans or critically checks the step sequence, zero point, instrument ranges, repetitions, or waiting conditions. The learner records units and uncertainties and explains which variable is changed and which conditions are held constant. The sweep or a recording structure may be supplied with guidance; valid pairing, safe data acquisition, and their physical justification must still be demonstrated.
- `graph-shape-distinguishes-ohmic-and-nonohmic-behavior`
  - Essential understanding (DE): Bei festgelegter Achsenwahl zeigt ein ohmsches Bauteil unter konstanten Bedingungen eine Gerade durch den Ursprung; dann bleibt U/I konstant. Bei einer gekrümmten oder richtungsabhängigen Kennlinie ändert sich U/I mit dem Betriebspunkt. Für I über U ist die Steigung der ohmschen Ursprungsgeraden der Leitwert G=I/U in S, nicht die Materialleitfähigkeit in S/m. Bei einer nichtlinearen Kennlinie beschreibt eine Sekantensteigung ΔI/ΔU die Änderung zwischen zwei Betriebspunkten; eine lokale Steigung beschreibt die Änderung in einer kleinen Umgebung. Beide dürfen nicht mit I/U oder dem Widerstandsquotienten U/I gleichgesetzt werden.
  - Essential understanding (EN): With a stated choice of axes, an ohmic component under constant conditions gives a straight line through the origin, so U/I remains constant. For a curved or direction-dependent characteristic, U/I changes with the operating point. For current plotted against voltage, the slope of the ohmic line through the origin is conductance G=I/U in S, not material conductivity in S/m. For a nonlinear characteristic, a secant slope ΔI/ΔU describes change between two operating points; a local slope describes change in a small neighborhood. Neither may be equated with I/U or the resistance ratio U/I.
  - Observable performance (DE): Die lernende Person erstellt aus frischen Messdaten ein beschriftetes Diagramm, prüft Linearität und Ursprung, bestimmt oder vergleicht U/I an mehreren nichtverschwindenden Punkten, deutet die Form physikalisch und korrigiert eine Steigungsinterpretation anhand der Achsen. Wird eine nichtlineare Steigung verwendet, unterscheidet sie qualitativ oder anhand benachbarter Messpunkte die Steigung vom Quotienten zum Ursprung; eine Ableitungsrechnung ist dafür nicht erforderlich.
  - Observable performance (EN): The learner constructs a labelled graph from fresh measurements, checks linearity and the origin, determines or compares U/I at several nonzero points, interprets the shape physically, and corrects a slope interpretation using the axes. If a nonlinear slope is used, the learner distinguishes it from the ratio to the origin qualitatively or using neighboring measurements; derivative calculation is not required.
- `characteristic-supports-bounded-prediction-and-model-check`
  - Essential understanding (DE): Eine Kennlinie erlaubt Ablesen oder Interpolation nur im untersuchten Zustands- und Messbereich. Abweichende Kurven bei geänderter Temperatur, Polarität oder Bauteilart sind physikalische Information und nicht automatisch Messfehler; weite Extrapolation oder die Annahme eines konstanten Widerstands benötigen zusätzliche Begründung.
  - Essential understanding (EN): A characteristic supports reading or interpolation only within the investigated state and measurement range. Different curves when temperature, polarity, or component type changes are physical information rather than automatically measurement error; wide extrapolation or assuming constant resistance requires additional justification.
  - Observable performance (DE): Die lernende Person nutzt eine unbekannte Kennlinie für eine Vorhersage innerhalb des Messbereichs, nennt eine angemessene Unsicherheit, vergleicht sie mit einem neuen Datenpunkt und entscheidet begründet, ob Messstreuung, Zustandsänderung oder ein ungeeignetes ohmsches Modell die Abweichung erklärt.
  - Observable performance (EN): The learner uses an unfamiliar characteristic to make a prediction within the measured range, states an appropriate uncertainty, compares it with a new data point, and decides with justification whether scatter, a change of state, or an unsuitable ohmic model explains the discrepancy.

**Coverage expectations**

- required expectations: `measurement-circuit-binds-voltage-and-current`, `controlled-sweep-produces-defensible-data`, `graph-shape-distinguishes-ohmic-and-nonohmic-behavior`, `characteristic-supports-bounded-prediction-and-model-check`
- alternative expectation groups: None
- minimum independent demonstrations: 3
- fresh variation required: true
- independent transfer required: true

**Variation axes**

- `component-behavior`: Ohmscher Widerstand, Glühlampe oder polungsabhängiges einfaches Bauteil innerhalb bereitgestellter sicherer Grenzwerte / Ohmic resistor, filament lamp, or polarity-dependent simple component within supplied safe limits
- `state-and-control`: Konstante Temperatur, merkliche Erwärmung, auf- und absteigende Messfolge oder vertauschte Polarität / Constant temperature, appreciable heating, increasing and decreasing sweep, or reversed polarity
- `data-quality`: Dichte oder grobe Messpunktfolge, Wiederholungen, Ausreißer und unterschiedliche Messunsicherheiten / Dense or coarse sequence of points, repeated readings, outliers, and different measurement uncertainties
- `representation-and-task`: Messschaltung, Tabelle, U-über-I- oder I-über-U-Diagramm sowie Vorhersage oder Fehlerdiagnose / Measuring circuit, table, voltage-versus-current or current-versus-voltage graph, and prediction or fault diagnosis

**Application cases**

- `independent-circuit-and-controlled-acquisition`
  - Task demand (DE): Untersuche in einer Kleinspannungssimulation ein unbekanntes einfaches Bauteil: Ist I bei unverändertem Zustand proportional zu U? Bereitgestellt sind eine regelbare Gleichspannungsquelle von 0 bis 3,0 V mit Strombegrenzung auf 4,0 mA, ein Spannungsmessbereich 0 bis 5 V mit Ableseunsicherheit ±0,02 V und Strommessbereiche 0 bis 2 mA (±0,01 mA) beziehungsweise 0 bis 20 mA (±0,10 mA). Für das Bauteil gelten höchstens 3,0 V und 4,0 mA; im Simulationsmodell belasten die Messgeräte die Schaltung nicht. Baue die Messschaltung selbstständig oder mit fachlicher Anleitung auf, kennzeichne die Messgrößen und erkläre die Geräteanordnung. Plane oder prüfe eine bereitgestellte Spannungsfolge und die Messbereiche; begründe genügend Messpunkte sowie Kontrollen oder Wiederholungen. Führe die Messung durch und protokolliere selbst zusammengehörige Wertepaare mit Einheiten und Unsicherheiten; eine angeleitete Geräteverwendung und Protokollstruktur sind zulässig. Erstelle die Kennlinie, prüfe die Untersuchungsfrage und begründe eine Nachmessung oder eine begrenzte Vorhersage. Zeige dein eigenes Verständnis zusätzlich an einer frischen Änderung der Schaltung, Messfolge oder Wertepaarung. Ein Aufbau und Messplan ohne Vorlage ist eine stärkere zulässige Variante, keine allgemeine Voraussetzung für den Nachweis dieses Ziels.
  - Task demand (EN): Investigate an unfamiliar simple component in a low-voltage simulation: is I proportional to U when its state is unchanged? Available are an adjustable DC supply from 0 to 3.0 V with a 4.0 mA current limit, a voltage range of 0 to 5 V with reading uncertainty ±0.02 V, and current ranges of 0 to 2 mA (±0.01 mA) or 0 to 20 mA (±0.10 mA). The component limits are 3.0 V and 4.0 mA; in this simulation the meters do not load the circuit. Build the measuring circuit independently or with physical guidance, label the measured quantities, and explain the instrument arrangement. Plan or critically check a supplied voltage sequence and instrument ranges; justify sufficient data points and controls or repetitions. Carry out the measurements and personally record paired readings with units and uncertainties; guided instrument use and a recording structure are permitted. Plot the characteristic, test the investigation question, and justify a repeat measurement or bounded prediction. Additionally show your own understanding through a fresh change to the circuit, sweep, or value pairing. Designing the setup and sweep without a template is a valid stronger variant, not a universal prerequisite for demonstrating this goal.
  - Expected performance (DE): Die lernende Person erklärt das Strommessgerät im Bauteilzweig und das Spannungsmessgerät parallel zum Bauteil sowie die nichtbelastende Modellannahme; sie richtet die Schaltung gegebenenfalls angeleitet ein oder korrigiert sie. Sie verwendet sichere Messbereiche, erklärt eine notwendige Anpassung nach ersten Ablesungen und überschreitet keinen Messbereich. Sie führt eine sinnvolle Messfolge durch und begründet Nullpunkt, Paarung im gleichen Zustand, Temperatur beziehungsweise Wartezeit und Kontrollablesungen. Ihre selbst erhobenen Daten und ihr Diagramm tragen Einheiten und Unsicherheiten. Sie prüft Ursprungsverlauf und U/I außerhalb von U=I=0 und begründet die modell- und bereichsgebundene Schlussfolgerung. Fachliche Hilfe beim Aufbau, bei Messfolge, Geräteverwendung oder Protokoll ist zulässig; bloßes Kopieren eines Plans, einer Erklärung oder fertiger Werte liefert keine eigene Evidenz. Eine frische Veränderung prüft die selbstständig begründete Fehlererkennung oder Anpassung; die vollständig eigenständige Neukonstruktion des Versuchs ist dafür keine Pflicht. Andere nachvollziehbar sichere und aussagekräftige Messwege sind gleichwertig.
  - Expected performance (EN): The learner explains the ammeter in the component branch, the voltmeter in parallel with the component, and the nonloading model assumption, and sets up or corrects the circuit with guidance where appropriate. The learner uses safe instrument ranges, explains a necessary adjustment after initial readings, and does not exceed a meter range. The learner carries out a meaningful sweep and justifies the zero point, pairing in the same state, temperature or waiting time, and control readings. The learner-generated data and graph include units and uncertainties. The learner checks the origin and U/I outside U=I=0 and justifies a model- and range-limited conclusion. Physical help with setup, sweep, instrument use, or recording is permitted; simply copying a plan, explanation, or finished values is not the learner's own evidence. A fresh change tests independently justified fault recognition or adaptation; entirely unaided construction of a new experiment is not mandatory for this. Other defensibly safe and informative measuring approaches are equivalent.
  - Understanding focus (DE): Sichere eigene Datenerhebung, begründete Geräteanordnung und Betriebspunktpaarung, Kennlinie und physikalische Deutung bilden eine zusammenhängende Untersuchung. Curricular angemessene Anleitung ersetzt nicht die eigene Erklärung und den frischen Transfer.
  - Understanding focus (EN): Safe personal data acquisition, justified instrument arrangement and operating-point pairing, the characteristic, and physical interpretation form one coherent investigation. Curriculum-appropriate guidance does not replace the learner's explanation and fresh transfer.
- `resistor-data-with-one-mismatched-point`
  - Task demand (DE): Eine sichere Kleinspannungs-Messreihe an einem Widerstand enthält sechs zusammengehörige U-I-Paare und einen siebten Eintrag, dessen Stromwert versehentlich aus dem vorherigen Betriebspunkt übernommen wurde. Zeichne die Kennlinie mit Unsicherheitsangaben, identifiziere den verdächtigen Punkt und entscheide, welche Nachmessung das ohmsche Modell fair prüft.
  - Task demand (EN): A safe low-voltage data series for a resistor contains six paired voltage-current values and a seventh entry whose current was accidentally copied from the preceding operating point. Plot the characteristic with uncertainty information, identify the suspect point, and decide what repeat measurement would fairly test the ohmic model.
  - Expected performance (DE): Die lernende Person beschriftet Achsen und Einheiten, erkennt sechs annähernd lineare Ursprungspunkte, markiert den unpassenden Wertepaarpunkt, verlangt eine erneute simultane Ablesung dieses Betriebspunkts und entscheidet erst danach anhand von U/I und Unsicherheit über ohmsches Verhalten.
  - Expected performance (EN): The learner labels axes and units, recognizes six approximately linear points through the origin, marks the inconsistent paired point, calls for a fresh simultaneous reading at that operating point, and only then uses U/I and uncertainty to decide whether the behavior is ohmic.
  - Understanding focus (DE): Der gebrochene Wertepaarbezug prüft, ob Kennlinienpunkte als reale gemeinsame Betriebszustände verstanden werden.
  - Understanding focus (EN): The broken pairing tests whether characteristic points are understood as real shared operating states.
- `lamp-heating-up-and-down-sweep`
  - Task demand (DE): Für eine Kleinspannungs-Glühlampe liegen Messwerte einer langsam aufsteigenden und einer unmittelbar absteigenden Spannungsfolge vor. Erstelle beide Kennlinien, vergleiche U/I bei mehreren Punkten und entwickle eine Erklärung, in der die Temperatur des Glühfadens als kontrollierter beziehungsweise veränderter Zustand vorkommt.
  - Task demand (EN): For a low-voltage filament lamp, data are supplied for a slowly increasing voltage sweep and an immediately decreasing sweep. Construct both characteristics, compare U/I at several points, and develop an explanation that treats filament temperature as a controlled or changing state.
  - Expected performance (DE): Die lernende Person erkennt gekrümmte, gegebenenfalls leicht verschiedene Verläufe, zeigt den nicht konstanten Quotienten U/I, verbindet größeren Widerstand mit dem erwärmten Glühfaden und nennt Messfolge sowie Wartezeit als relevante Bedingungen statt die Kurve als bloßen Messfehler zu verwerfen.
  - Expected performance (EN): The learner recognizes curved and possibly slightly different traces, demonstrates that U/I is not constant, connects greater resistance with the heated filament, and identifies sweep order and waiting time as relevant conditions instead of dismissing the curve as mere measurement error.
  - Understanding focus (DE): Die Zustandsänderung trennt nichtohmsches Verhalten von einer formalen Gerade-durch-Ursprung-Prüfung ohne Physik.
  - Understanding focus (EN): The change of state separates non-ohmic behavior from a purely formal straight-line-through-origin test without physical interpretation.
- `polarity-dependent-component-supplied-data`
  - Task demand (DE): Eine Simulation eines polungsabhängigen Kleinspannungsbauteils liefert sichere U-I-Daten für beide Polaritäten und nennt eine zulässige Stromgrenze. Plane eine sinnvolle graphische Darstellung, klassifiziere den richtungsabhängigen Verlauf und sage innerhalb des untersuchten Bereichs einen Stromwert für eine neue Spannung voraus, ohne über die Grenze zu extrapolieren. Gib die Unsicherheit deiner Vorhersage an und benenne, falls nötig, zusätzliche Unsicherheit durch die Interpolation.
  - Task demand (EN): A simulation of a polarity-dependent low-voltage component supplies safe voltage-current data for both polarities and states an allowable current limit. Plan a suitable graph, classify the direction-dependent behavior, and predict a current for a new voltage within the investigated range without extrapolating beyond the limit. State the uncertainty of your prediction and, where needed, additional uncertainty from interpolation.
  - Expected performance (DE): Die lernende Person erhält Vorzeichen und Polarität in Tabelle und Diagramm, erkennt den asymmetrischen nichtohmschen Verlauf, interpoliert nur im belegten Bereich mit Unsicherheit und erklärt, weshalb weder ein konstanter Widerstand noch eine spiegelbildliche Fortsetzung in die andere Polarität gerechtfertigt ist.
  - Expected performance (EN): The learner preserves sign and polarity in the table and graph, recognizes the asymmetric non-ohmic behavior, interpolates only within the evidenced range with uncertainty, and explains why neither a constant resistance nor a mirror-image continuation into the other polarity is justified.
  - Understanding focus (DE): Polaritätswechsel und sichere Bereichsgrenze prüfen Modellwahl, Vorzeichenverständnis und begrenzten Transfer.
  - Understanding focus (EN): Changing polarity and imposing a safe range limit test model choice, sign understanding, and bounded transfer.
