// SPDX-License-Identifier: Apache-2.0
import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { compileCompositionView, collectCompositionProjectionRoleGoalIds } from '../src/utils/authoring/compositionViewAuthoring.ts'
const goalId='66256e22-44a3-5939-8862-821e29d6711d'
const load=(p:string)=>JSON.parse(readFileSync(p,'utf8'))
const hash=(p:string)=>'sha256:'+createHash('sha256').update(readFileSync(p)).digest('hex')
const manifestPath='app/scripts/config/goal-books/de-gym-physics-national-atlas.sources.json'
const manifest=load(manifestPath),physics=load('curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'),math=load('curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json')
const universe={...physics,goals:[...physics.goals,...math.goals]},map=new Map(universe.goals.map((g:any)=>[g.id,g])),sources=new Map([[physics.landscapeId,physics],[math.landscapeId,math]])
const rows=[]
for(const path of manifest.sourcePaths){const view=load(path),roles=collectCompositionProjectionRoleGoalIds(view.rootNodes,map),compiled=compileCompositionView(view,physics,universe,sources),paths:string[][]=[];const visit=(n:any,trail:string[])=>{const p=[...trail,n.label];if(n.sourceGoalId===goalId)paths.push(p);for(const c of n.children)visit(c,p)};compiled.compiledRootNodes.forEach(n=>visit(n,[]));rows.push({path,sha256:hash(path),scope:view.scope,target:roles.targetGoalIds.has(goalId),prerequisiteOnly:roles.prerequisiteOnlyGoalIds.has(goalId),visiblePaths:paths,findings:compiled.findings})}
const result={goalId,sourceManifest:{path:manifestPath,sha256:hash(manifestPath)},durationPolicy:{path:manifest.durationModelPolicyPath,sha256:hash(manifest.durationModelPolicyPath),policy:load(manifest.durationModelPolicyPath)},helper:{path:'app/src/utils/authoring/compositionViewAuthoring.ts',sha256:hash('app/src/utils/authoring/compositionViewAuthoring.ts')},sourcePathsCompiled:rows.length,allViewResults:rows,targetViews:rows.filter(r=>r.target),scopeLimit:'Exact authored matrix compiled using native helper; effective target placement is not official source approval, empirical experimentation or runtime acceptance.'}
writeFileSync('peer-inputs/native-current-projection-matrix.actual.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({sourcePathsCompiled:rows.length,targetViews:result.targetViews.length,byViews:result.targetViews.filter(r=>r.scope.jurisdiction==='DE-BY'),errors:rows.flatMap(r=>r.findings).filter((f:any)=>f.severity==='error').length}))
