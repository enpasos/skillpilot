# SPDX-License-Identifier: Apache-2.0
import json,pathlib,re
p=pathlib.Path(__file__).resolve().parent
fix={'Dieeigene':'Die eigene','Einenegative':'Eine negative','Einfreies':'Ein freies','Diegegebenen':'Die gegebenen','diegegebenen':'die gegebenen','Diebereitgestellte':'Die bereitgestellte','Einezyklische':'Eine zyklische','Eineeinmalige':'Eine einmalige','DieReservoir':'Die Reservoir','Eineverbotene':'Eine verbotene','Beidegegebenen':'Beide gegebenen','Dasvereinfachte':'Das vereinfachte','Dasselbebereitgestellte':'Dasselbe bereitgestellte','Nursimulatorberichtete':'Nur simulatorberichtete','EinOffset':'Ein Offset','Einbloßer':'Ein bloßer','Einideales':'Ein ideales','Ganzesc':'Ganzes c','Ganzesd':'Ganzes d','Ganzesf':'Ganzes f','Ganzesbe':'Ganzes be','Ganzes140':'Ganzes 140','Ganzes269':'Ganzes 269','Ganzes10':'Ganzes 10','Ganzes30':'Ganzes 30','Ganzes8':'Ganzes 8','Ganzes5':'Ganzes 5','Ganze078':'Ganze 078','Ganze79':'Ganze 79','Ganze531':'Ganze 531','Ganze37':'Ganze 37','Ganze891':'Ganze 891','Ganze904':'Ganze 904','beidemselben':'bei demselben','imgegebenen':'im gegebenen','dergegebenen':'der gegebenen','ausderexplizit':'aus der explizit','stattmitder':'statt mit der','beipassender':'bei passender','nachSonnenuntergang':'nach Sonnenuntergang','von0,':'von 0,','auf0,':'auf 0,','ohneeigene':'ohne eigene','wirdnicht':'wird nicht','wurde nicht':'wurde nicht','sindnicht':'sind nicht','istnicht':'ist nicht','darf nicht':'darf nicht','dürfennicht':'dürfen nicht','begründetnicht':'begründet nicht','keinall':'kein all','keinepersönliche':'keine persönliche','keinuniverseller':'kein universeller','keinegezählten':'keine gezählten','keinlaufender':'kein laufender','keinenStoß':'keinen Stoß','keinevollständige':'keine vollständige','nichtdemselben':'nicht demselben','nichtbegründet':'nicht begründet','nichtautomatisch':'nicht automatisch','nichtaus':'nicht aus','nichtzur':'nicht zur','nichtzwingend':'nicht zwingend','nichtmit':'nicht mit','bleibtunverändert':'bleibt unverändert','liegtim':'liegt im','giltaktuell':'gilt aktuell','gibtΣ':'gibt Σ','liefertf':'liefert f','liefertR':'liefert R','ergibtR':'ergibt R','ergibtL':'ergibt L','ergibtE':'ergibt E','ergibtd':'ergibt d','ergibtv':'ergibt v','ergebensich':'ergeben sich','erforderlichesf':'erforderliches f','hatΣ':'hat Σ','gibtV':'gibt V','bedarffes':'bedarf es','bedarfes':'bedarf es','mussvorder':'muss vor der','stehenbleiben':'stehen bleiben','erstbei':'erst bei','bleibtzuprüfen':'bleibt zu prüfen','wärenkein':'wären kein','in den':'in den','inde':'in de','vorderNormierung':'vor der Normierung','mitderEinfallsenergie':'mit der Einfallsenergie','nachdenselben':'nach denselben','ändertdie':'ändert die','istkein':'ist kein','derLinie':'der Linie','denpositiven':'den positiven','bleibendieselben':'bleiben dieselben','gleichenQ':'gleichen Q','gleichenTemperatur':'gleichen Temperatur','keinenZeit':'keinen Zeit','stattgleiche':'statt gleiche'}
def tidy(s):
 for a,b in sorted(fix.items(),key=lambda q:-len(q[0])):s=s.replace(a,b)
 s=re.sub(r'(?<=[a-zäöüß])(?=[A-ZÄÖÜ])',' ',s)
 s=re.sub(r'([.;:])(?=[A-ZÄÖÜ])',r'\1 ',s)
 s=re.sub(r'(-P)(?=[a-zäöüß])',r'\1 ',s)
 s=re.sub(r'(-P)(?=\d)',r'\1 ',s)
 return s
for name in ['twenty-individual-substantive-requires-peer-judgments.actual.json','forty-fresh-own-solved-countercases.actual.json']:
 q=p/name;d=json.loads(q.read_text())
 def walk(v):
  if isinstance(v,dict):
   for k,z in v.items():
    if k in ['rationaleDe','sourceAndScopeBoundaryDe','workedSolutionDe','necessityOrAlternativeImplicationDe']and isinstance(z,str):v[k]=tidy(z)
    else:walk(z)
  elif isinstance(v,list):
   for z in v:walk(z)
 walk(d);q.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print('Own prose spacing corrected; all structured decisions, IDs, numeric data unchanged.')
