// SPDX-License-Identifier: Apache-2.0
// Technical current-input proofs only; no review approval is created.
import {readFileSync, writeFileSync, existsSync} from 'node:fs';
import {resolve, dirname, relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {buildRequiresInventory, assertFreshRequiresInventory, stableJson} from '../../../app/scripts/lib/crossSubjectRequiresInventory.ts';
import {reviewPositiveGoalEvidenceConfig} from '../../../app/scripts/positiveGoalEvidenceReview.ts';
import {fingerprintGoalForPositiveEvidence, fingerprintPositiveGoalEvidenceProfile, fingerprintPositiveGoalEvidenceReviewInput} from '../../../app/scripts/positiveGoalEvidenceProfileModel.ts';
const root='/home/enpasos/projects/skillpilot';
const out=dirname(fileURLToPath(import.meta.url));
const reader='tmp/cross-subject-requires/gymnasium-unresolved97-informed-reader-20261013-v1';
const read=(path:string)=>JSON.parse(readFileSync(resolve(root,path),'utf8'));
const sha=(bytes:Buffer|string)=>'sha256:'+createHash('sha256').update(bytes).digest('hex');
const dossiers=read(relative(root,out)+'/twenty-complete-review-contexts.actual.json');
const configPath='curricula/quality/cross-subject-requires/math-physics.config.json';
const inventoryPath='curricula/quality/cross-subject-requires/math-physics.inventory.json';
const actualInventory=buildRequiresInventory(root,read(configPath));
const inventoryHash=assertFreshRequiresInventory(actualInventory,resolve(root,inventoryPath));
const selected=new Map(actualInventory.families.flatMap((f:any)=>f.goals.map((g:any)=>[g.goalId,g])));
const activePhysics=read('curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json');
const goals=new Map(activePhysics.goals.map((g:any)=>[g.id,g]));
const central=read('curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json');
const physicsConfig=central.subjects.find((s:any)=>s.subject==='physik');
const ownerRegistration=new Map<string,string[]>();
for(const p of physicsConfig.positiveEvidenceConfigPaths){for(const id of read(p).scope.goalIds){const old=ownerRegistration.get(id)??[];old.push(p);ownerRegistration.set(id,old);}}
const cache=new Map<string,ReturnType<typeof reviewPositiveGoalEvidenceConfig>>();
const proofs=[];const errors:string[]=[];
for(const dossier of dossiers){
 const id=dossier.goalId;const body=dossier.wholeCurrentGoalAndPositiveBody;
 const occurrence=(selected.get(id) as any)?.occurrences.find((o:any)=>o.selected&&o.path===body.currentSourceLandscape.path);
 const tripleMatches=stableJson(occurrence?.reviewInput)===stableJson(body.currentPerGoalReviewInput);
 const goal:any=goals.get(id);const wholeGoalMatches=stableJson(goal)===stableJson(body.wholeCurrentCanonicalGoal);
 const owner=body.positiveBodyOwner;const registration=ownerRegistration.get(id)??[];
 const uniqueCurrentOwner=registration.length===1&&registration[0]===owner.configPath;
 if(!cache.has(owner.configPath))cache.set(owner.configPath,reviewPositiveGoalEvidenceConfig(owner.configPath));
 const native=cache.get(owner.configPath)!;const record=native.records.find(r=>r.goalId===id)!;
 const raw=readFileSync(resolve(root,owner.recordPath));const lines=raw.toString('utf8').match(/[^\n]*\n|[^\n]+$/g)??[];
 const line=lines[owner.recordLine-1];const lineRecord=line?JSON.parse(line):null;
 const rawLineMatches=Boolean(line)&&sha(line)===owner.recordRawLineSha256&&lineRecord?.goalId===id;
 const ownerFilesMatch=sha(readFileSync(resolve(root,owner.configPath)))===owner.configSha256&&sha(raw)===owner.recordFileSha256;
 const profileBodyExact=stableJson(record?.profile)===stableJson(owner.wholePositiveProfile);
 const resourceDigests:Record<string,string>={};const resourcePaths:string[]=[];
 if(native.config.reviewedResourceTypes.includes('goal-visualization'))for(const link of goal.resourceLinks??[]){if(link.type==='goal-visualization'){const p='app/public'+link.url;if(existsSync(resolve(root,p))){resourceDigests[link.url]=sha(readFileSync(resolve(root,p)));resourcePaths.push(p);}}}
 const criteriaHash=sha(readFileSync(resolve(root,native.config.reviewCriteriaPath)));
 const calculated={goalFingerprint:fingerprintGoalForPositiveEvidence(goal,body.semanticKind),profileFingerprint:fingerprintPositiveGoalEvidenceProfile(record.profile),reviewInputFingerprint:fingerprintPositiveGoalEvidenceReviewInput(goal,criteriaHash,resourceDigests,body.semanticKind)};
 const fingerprintsMatch=calculated.goalFingerprint===owner.currentGoalFingerprint&&calculated.goalFingerprint===record.goalFingerprint&&calculated.profileFingerprint===owner.currentProfileFingerprint&&calculated.profileFingerprint===record.profileFingerprint&&calculated.reviewInputFingerprint===owner.currentReviewInputFingerprint&&calculated.reviewInputFingerprint===record.reviewInputFingerprint;
 const nativeErrors=native.errors;
 const passed=tripleMatches&&wholeGoalMatches&&uniqueCurrentOwner&&rawLineMatches&&ownerFilesMatch&&profileBodyExact&&fingerprintsMatch&&nativeErrors.length===0;
 if(!passed)errors.push(id+': technical binding proof failed');
 proofs.push({goalId:id,currentPerGoalReviewInput:occurrence?.reviewInput,dossierPerGoalReviewInput:body.currentPerGoalReviewInput,tripleMatches,wholeGoalMatches,semanticKind:body.semanticKind,ownerConfigPath:owner.configPath,ownerRecordPath:owner.recordPath,ownerRecordLine:owner.recordLine,registration,uniqueCurrentOwner,rawLineMatches,ownerFilesMatch,profileBodyExact,criteriaHash,criteriaPath:native.config.reviewCriteriaPath,reviewedResourceTypes:native.config.reviewedResourceTypes,resourcePaths,calculatedFingerprints:calculated,fingerprintsMatch,nativeConfigErrors:nativeErrors,technicalProofPassed:passed,approvalCreated:false});
}
const result={schemaVersion:1,checkedAt:new Date().toISOString(),scope:'Third20 positions21–40 of informed unresolved97 only; first20 frozen; other57 untouched',inventoryHash,inventoryFresh:true,validator:'Real buildRequiresInventory/assertFreshRequiresInventory and reviewPositiveGoalEvidenceConfig, with existing fingerprint helpers',uniqueOwnerConfigCount:cache.size,proofCount:proofs.length,allTechnicalProofsPass:proofs.length===20&&errors.length===0,errors,proofs,independentReviewApprovalCreated:false,sourceOrPQualityApprovalCreated:false,activeWrites:false};
writeFileSync(resolve(out,'native-current-owner-triples.actual.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({inventoryHash,inventoryFresh:true,proofCount:result.proofCount,uniqueOwnerConfigCount:cache.size,allTechnicalProofsPass:result.allTechnicalProofsPass,errors}));
process.exitCode=result.allTechnicalProofsPass?0:1;
