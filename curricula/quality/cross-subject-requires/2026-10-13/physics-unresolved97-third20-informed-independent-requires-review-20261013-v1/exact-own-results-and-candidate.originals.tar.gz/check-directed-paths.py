import pathlib,json,collections,hashlib
out=pathlib.Path(__file__).resolve().parent; root=pathlib.Path.cwd()
paths=['curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json','curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json']
g={};subject={}
for p in paths:
 x=json.loads(pathlib.Path(p).read_text())
 def walk(z):
  if isinstance(z,dict):
   if 'id'in z and 'requires'in z:g[z['id']]=z;subject[z['id']]='Math' if 'MATHEMATIK'in p else 'Physics'
   for v in z.values():walk(v)
  elif isinstance(z,list):
   for v in z:walk(v)
 walk(x)
ctx=json.loads((out/'twenty-complete-review-contexts.actual.json').read_text());c=json.loads((out/'all-claimed-whole-prerequisite-contexts.actual.json').read_text());print(type(c),list(c) if isinstance(c,dict) else len(c))
if isinstance(c,dict):c=c['records']
math=[z['goalId'] for z in c if subject.get(z['goalId'])=='Math']
reports=[]
for r in ctx:
 a=r['wholeGoal']['id'];q=collections.deque([(a,[a])]);seen={a};reach={}
 while q:
  z,path=q.popleft()
  for t in g[z].get('requires',[]):
   if t not in g:continue
   if t not in seen:seen.add(t);reach[t]=path+[t];q.append((t,path+[t]))
 reports.append({'index':r['index'],'goalId':a,'directRequires':g[a]['requires'],'reachableMathWholeGoals':[{ 'goalId':t,'title':g[t]['title'],'path':reach[t]} for t in math if t in reach],'absentRelevantMathGoals':[t for t in math if t not in reach],'scopeInterpretation':'Actual directional authored direct-requires paths only; no backward mastery, no automatic projection role, no inherited source authority.'})
(out/'actual-directed-requires-paths.json').write_text(json.dumps({'inputFiles':[{ 'path':p,'sha256':'sha256:'+hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()} for p in paths],'records':reports},ensure_ascii=False,indent=2)+'\n')
for r in reports:print(r['index'],r['goalId'][:8],[(v['title'],len(v['path'])-1) for v in r['reachableMathWholeGoals']]);
