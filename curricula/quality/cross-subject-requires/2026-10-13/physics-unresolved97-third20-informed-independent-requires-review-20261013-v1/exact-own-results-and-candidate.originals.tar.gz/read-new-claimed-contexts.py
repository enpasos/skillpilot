import pathlib,json,sys
p=pathlib.Path(__file__).resolve().parent
c=json.loads((p/'twenty-complete-review-contexts.actual.json').read_text());ids={r['goalId']for r in c}
ids.update(json.loads((p/'previously-read-exact-whole-context-reuse.json').read_text())['wholeCurrentGoalAndPExactlyIdentical']);ids.add('f2e42af5-67a6-477e-82ea-e65b09cc6cb3')
r=[z for z in json.loads((p/'all-claimed-whole-prerequisite-contexts.actual.json').read_text())if z['goalId']not in ids]
seen={}
def comp(v,path='$'):
 if isinstance(v,str)and len(v)>120:
  if v in seen:return{'sameCompleteValueAt':seen[v]}
  seen[v]=path;return v
 if isinstance(v,dict):return{k:comp(z,path+'.'+k)for k,z in v.items()}
 if isinstance(v,list):return[comp(z,path+'['+str(i)+']')for i,z in enumerate(v)]
 return v
start=int(sys.argv[1]);out=[];sz=0
for i,z in enumerate(r[start:],start):
 z={**z,'wholeGoal':{k:v for k,v in z['wholeGoal'].items()if k!='resourceLinks'},'newExtraIndex':i};s=json.dumps(z,ensure_ascii=False)
 if out and sz+len(s)>26000:break
 out.append(z);sz+=len(s)
print(json.dumps(comp({'nextIndex':start+len(out),'count':len(r),'records':out}),ensure_ascii=False))
