// SPDX-License-Identifier: Apache-2.0
import {readFileSync,writeFileSync,existsSync} from 'node:fs';import {resolve,dirname} from 'node:path';import {fileURLToPath} from 'node:url';import {createHash} from 'node:crypto';
import {reviewPositiveGoalEvidenceConfig} from '../../../app/scripts/positiveGoalEvidenceReview.ts';
import {fingerprintGoalForPositiveEvidence,fingerprintPositiveGoalEvidenceProfile,fingerprintPositiveGoalEvidenceReviewInput} from '../../../app/scripts/positiveGoalEvidenceProfileModel.ts';
import {stableJson} from '../../../app/scripts/lib/crossSubjectRequiresInventory.ts';
const out=dirname(fileURLToPath(import.meta.url)),root=process.cwd();const rd=(p:string)=>JSON.parse(readFileSync(resolve(root,p),'utf8'));
const sh=(p:string)=>'sha256:'+createHash('sha256').update(readFileSync(resolve(root,p))).digest('hex');
const records=rd(resolve(out,'all-claimed-whole-prerequisite-contexts.actual.json'));const cache=new Map();const proofs=[];
for(const context of records){
 if(!context.owner){proofs.push({goalId:context.goalId,kind:context.wholeGoal.semanticKind??(context.wholeGoal.contains?.length?'cluster':null),PExpected:false,arithmeticEvidence:false,exactWholeGoalBound:true});continue;}
 const cp=context.owner.config;if(!cache.has(cp))cache.set(cp,reviewPositiveGoalEvidenceConfig(cp));const native=cache.get(cp);
 const rec=native.records.find((z:any)=>z.goalId===context.goalId);const config=native.config;
 const goal=rd(config.landscapePath).goals.find((z:any)=>z.id===context.goalId);
 const kind=rd(config.semanticKindLedgerPath).decisions.find((z:any)=>z.goalId===context.goalId)?.semanticKind;
 const dg:Record<string,string>={};const resourceInputs=[];
 if(config.reviewedResourceTypes.includes('goal-visualization'))for(const link of goal.resourceLinks??[])if(link.type==='goal-visualization'){
  const rp='app/public'+link.url;if(existsSync(resolve(root,rp))){dg[link.url]=sh(rp);resourceInputs.push({path:rp,sha256:dg[link.url]});}}
 const criteria=sh(config.reviewCriteriaPath),gf=fingerprintGoalForPositiveEvidence(goal,kind),pf=fingerprintPositiveGoalEvidenceProfile(rec.profile),fp=fingerprintPositiveGoalEvidenceReviewInput(goal,criteria,dg,kind);
 const exact=stableJson(goal)===stableJson(context.wholeGoal)&&stableJson(rec.profile)===stableJson(context.wholeP);
 const fps=rec.goalFingerprint===gf&&rec.profileFingerprint===pf&&rec.reviewInputFingerprint===fp;
 proofs.push({goalId:context.goalId,configPath:cp,configSha256:sh(cp),recordPath:context.owner.record,recordSha256:sh(context.owner.record),semanticKindFromExistingCurrentLedger:kind,exactGoalAndP:exact,actualFingerprints:{goal:gf,profile:pf,input:fp},fingerprintsFresh:fps,nativeConfigErrors:native.errors,criteriaPath:config.reviewCriteriaPath,criteriaSha256:criteria,resourceInputs,noQualityApprovalCreated:true});
}
const result={role:'Technical current byte/owner/profile/resource fingerprint binding only; content judgments are separate',count:proofs.length,profileCount:proofs.filter((r:any)=>r.exactGoalAndP!==undefined).length,configCount:cache.size,errors:proofs.filter((r:any)=>r.exactGoalAndP===false||r.fingerprintsFresh===false||r.nativeConfigErrors?.length).map((r:any)=>({goalId:r.goalId,exact:r.exactGoalAndP,fresh:r.fingerprintsFresh,nativeErrors:r.nativeConfigErrors})),proofs};
writeFileSync(resolve(out,'native-all-whole-claimed-P-contexts.actual.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,proofs:undefined}));process.exitCode=result.errors.length?1:0;
