import pathlib,json
root=pathlib.Path.cwd();out=pathlib.Path(__file__).resolve().parent
# Actual current central registrations, not reconstructed P profiles.
goals={};subject={}
for sub,p in [('Math','curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'),('Physics','curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json')]:
 for g in json.loads((root/p).read_text())['goals']:goals[g['id']]=g;subject[g['id']]=sub
cp='curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json';central=json.loads((root/cp).read_text());owners={}
for ss in central['subjects']:
 for p in ss.get('positiveEvidenceConfigPaths',[]):
  c=json.loads((root/p).read_text());rp=c['reviewPath'];records=[json.loads(line)for line in(root/rp).read_text().splitlines()if line.strip()]
  for gid in c['scope']['goalIds']:
   if gid in goals:
    rs=[r for r in records if r['goalId']==gid];assert len(rs)==1
    owners.setdefault(gid,[]).append({'config':p,'record':rp,'profile':rs[0]['profile']})

rs=json.loads((out/'all-claimed-whole-prerequisite-contexts.actual.json').read_text());by={r['goalId']for r in rs};added=[]
for prefix in ['a94cfe1c','31a2ef52','d03f1cb6']:
 gid=next(i for i in goals if i.startswith(prefix));o=owners[gid];assert len(o)==1
 if gid not in by:rs.append({'goalId':gid,'subject':subject[gid],'wholeGoal':goals[gid],'wholeP':o[0]['profile'],'owner':{k:v for k,v in o[0].items()if k!='profile'}});added.append(gid)
(out/'all-claimed-whole-prerequisite-contexts.actual.json').write_text(json.dumps(rs,ensure_ascii=False,indent=2)+'\n');print(added,len(rs))
