# SPDX-License-Identifier: Apache-2.0
import json,pathlib,math,datetime
p=pathlib.Path(__file__).resolve().parent
rows=[]
for name,g,f in [('fresh-in-range',270.,16.875),('near-limit-counter',90.,16.5),('changed-in-range',360.,360*18/(360+18))]:
 retina=18.;H=2.;rays=[]
 for y in [-.8,0.,.8]:
  angle=(y-H)/g;after=angle-y/f;rays.append({'lensHeight_mm':y,'incomingSlope':angle,'afterThinLensSlope':after,'heightAtRetina_mm':y+retina*after})
 a,b=rays[0],rays[2];intersection=(b['lensHeight_mm']-a['lensHeight_mm'])/(a['afterThinLensSlope']-b['afterThinLensSlope']);lensEq=1/(1/f-1/g);assert math.isclose(intersection,lensEq,rel_tol=1e-12)
 rows.append({'model':name,'g_mm':g,'f_mm':f,'fixedRetina_mm':retina,'availableF_mm':[16.5,18.],'requiredFocusF_mm':g*retina/(g+retina),'rays':rays,'actualTwoRayIntersection_mm':intersection,'lensEquationCheck_mm':lensEq,'raySpreadAtRetina_mm':max(z['heightAtRetina_mm']for z in rays)-min(z['heightAtRetina_mm']for z in rays),'focusOnRetina':math.isclose(intersection,retina,abs_tol=1e-10)})
result={'executedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Actual numerical paraxial propagation and thin-lens slope change; two independent rays intersected; three fresh parameter models','models':rows,'experimentOrClinicalEvidence':False,'interactiveUIAcceptance':False,'activeWrites':False}
(p/'three-fresh-own-ideal-ray-models.actual.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
