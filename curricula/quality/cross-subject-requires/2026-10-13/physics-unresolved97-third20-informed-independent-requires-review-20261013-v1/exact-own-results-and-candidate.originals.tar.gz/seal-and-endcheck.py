# SPDX-License-Identifier: Apache-2.0
import pathlib,json,hashlib,datetime,sys
out=pathlib.Path(__file__).resolve().parent;root=pathlib.Path.cwd()
def sha(b):return 'sha256:'+hashlib.sha256(b).hexdigest()
def stat(p):
 q=root/p
 if not q.is_file():return {'path':str(p),'exists':False,'bytes':None,'sha256':None}
 b=q.read_bytes();return {'path':str(p),'exists':True,'bytes':len(b),'sha256':sha(b)}
initial=json.loads((out/'input-snapshot.before.json').read_text())
universe=out/'input-snapshot.final-universe.json'
if not universe.exists():
 files={r['path']:r for r in initial['files']}
 for addition in ['input-snapshot.additional-role-and-reading-bindings.json','late-legacy-cluster-input-binding.actual.json']:
  data=json.loads((out/addition).read_text())
  def collect(v):
   if isinstance(v,dict):
    if isinstance(v.get('path'),str) and 'sha256'in v and 'bytes'in v and (root/v['path']).is_file():
     r={**v,'exists':True}
     if r['path'] in files:
      old=files[r['path']];assert old['bytes']==r['bytes']and old['sha256']==r['sha256'],'Conflicting input snapshot '+r['path']
     else:files[r['path']]=r
    for z in v.values():collect(z)
   elif isinstance(v,list):
    for z in v:collect(z)
  collect(data)
 extras=['backend/src/main/java/com/skillpilot/backend/service/LearnerService.java','app/src/components/RequiresFlowMap.tsx','tmp/cross-subject-requires/three-legacy-referenced-math-clusters-reader-20261014-v2/whole-three-cluster-edges-and-descendant-P.neutral.json','app/scripts/lib/crossSubjectRequiresReview.ts','app/scripts/lib/crossSubjectRequiresInventory.ts','app/scripts/positiveGoalEvidenceReview.ts','app/scripts/positiveGoalEvidenceProfileModel.ts','curricula/quality/cross-subject-requires/math-physics.config.json','curricula/quality/cross-subject-requires/math-physics.inventory.json','curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json']
 for r in json.loads((out/'native-all-whole-claimed-P-contexts.actual.json').read_text())['proofs']:
  for k in ['configPath','recordPath','criteriaPath']:
   if r.get(k):extras.append(r[k])
  for z in r.get('resourceInputs',[]):extras.append(z['path'])
  if r.get('configPath'):
   config=json.loads((root/r['configPath']).read_text());extras +=[config['landscapePath'],config['semanticKindLedgerPath']]
 late=[]
 for p in sorted(set(extras)):
  if p not in files:files[p]=stat(p);late.append(p)
 universe.write_text(json.dumps({'initialSnapshotPreserved':'input-snapshot.before.json','initialCount':len(initial['files']),'lateCaptureAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'lateAdditionalFiles':late,'files':list(files.values()),'scope':'Inputs of exactly Third20 + full claimed prerequisite/source context, not remaining37 author outputs.'},ensure_ascii=False,indent=2)+'\n')
inputs=json.loads(universe.read_text())['files'];fail=[]
for r in inputs:
 a=stat(r['path'])
 if any(a[k]!=r[k] for k in ['exists','bytes','sha256']):fail.append({'kind':'inputSnapshot','expected':r,'actual':a})
originals=json.loads((out/'original-seals-and-current-inputs.fresh.actual.json').read_text())['checks']
for r in originals:
 a=stat(r['actual']['path']);e=r['expected']
 if not a['exists'] or a['bytes']!=e['bytes'] or a['sha256']!=e['sha256']:fail.append({'kind':r['kind'],'expected':e,'actual':a})
exclude={'own-seal.original.json','endcheck.actual.json','endcheck-before-seal.actual.json'}
sealpath=out/'own-seal.original.json';ownchecks=0
if sealpath.exists():
 s=json.loads(sealpath.read_text())
 for r in s['files']:
  a=stat(str(out.relative_to(root)/r['path']));ownchecks+=1
  if not a['exists'] or a['bytes']!=r['bytes'] or a['sha256']!=r['sha256']:fail.append({'kind':'ownSealedOutput','expected':r,'actual':a})
 current={str(p.relative_to(out)) for p in out.rglob('*') if p.is_file() and p.name not in exclude}
 if current!={r['path'] for r in s['files']}:fail.append({'kind':'OwnOutputMembershipChanged','extra':sorted(current-{r['path'] for r in s['files']}),'missing':sorted({r['path'] for r in s['files']}-current)})
report={'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputFileCount':len(inputs),'originalLiteralChecks':len(originals),'ownSealedOutputChecks':ownchecks,'allBytesExact':not fail,'failures':fail,'noWholeInputQualityPASSFromByteEquality':True,'activeWrites':False,'whole97Approval':False}
mode=sys.argv[1] if len(sys.argv)>1 else 'recheck'
if mode=='seal':
 if sealpath.exists():raise RuntimeError('Original own seal exists; overwrite refused')
 if fail:raise RuntimeError('Input preservation failed; seal refused')
 (out/'endcheck-before-seal.actual.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 rows=[]
 for p in sorted(out.rglob('*')):
  if p.is_file() and p.name not in exclude:
   b=p.read_bytes();rows.append({'path':str(p.relative_to(out)),'bytes':len(b),'sha256':sha(b)})
 seal={'schemaVersion':1,'role':'Actual informed independent AI Requires peer Third20; originals preserved; inert only','createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'20 individual decisions,40 fresh solved countercases,10 Requires peer approvals,10 pending; author f870 adds48/49 are not peer-approved; no whole97/remaining37/source/P/kind/M7/human/adoption approval','files':rows,'inputSnapshot':'input-snapshot.final-universe.json','presealInputEndcheck':report}
 sealpath.write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'ownSealPath':str(sealpath.relative_to(root)),'ownSealSha256':sha(sealpath.read_bytes()),'ownOutputCount':len(rows),'inputCount':len(inputs),'literalOriginalChecks':len(originals),'allOriginalInputBytesExact':True}));sys.exit(0)
(out/'endcheck.actual.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False));sys.exit(0 if not fail else 1)
