import json,pathlib,sys
p=pathlib.Path(__file__).resolve().parent;r=json.loads((p/'all-provided-whole-source-passages.actual.json').read_text())['newWholePassages'];start=int(sys.argv[1]);out=[];sz=0
for i,z in enumerate(r[start:],start):
 s=json.dumps(z,ensure_ascii=False)
 if out and sz+len(s)>25000:break
 out.append({'newPassageIndex':i,**z});sz+=len(s)
print(json.dumps({'nextIndex':start+len(out),'count':len(r),'records':out},ensure_ascii=False))
