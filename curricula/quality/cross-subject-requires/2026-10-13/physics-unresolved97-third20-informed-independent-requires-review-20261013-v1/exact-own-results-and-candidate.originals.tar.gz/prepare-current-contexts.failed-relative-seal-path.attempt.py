# SPDX-License-Identifier: Apache-2.0
import json,pathlib,hashlib,datetime,re
root=pathlib.Path.cwd();out=pathlib.Path(__file__).resolve().parent
first=root/'tmp/cross-subject-requires/physics-unresolved97-second20-informed-independent-requires-review-20261013-v1'
b=root/'tmp/cross-subject-requires/physics-unresolved97-whole-body-successor-author-20261013-v1/batch-003-final-v1'
def st(path):
 p=pathlib.Path(path);p=p if p.is_absolute() else root/p
 return {'path':str(p.relative_to(root)),'exists':p.is_file(),'bytes':p.stat().st_size if p.is_file() else None,'sha256':'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None}
def wr(name,x):(out/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
seal=st(b/'own-seal.json');assert seal['sha256']=='sha256:650471983b3b4e4b37c9ec52fadc2d1b62505077c3ecf9d1c56947d40f71b083'
originals=json.loads((first/'original-seals-and-current-inputs.fresh.actual.json').read_text())['checks'];checks=[]
for r in originals:
 a=st(r['actual']['path']);e=r['expected'];checks.append({'kind':'first20PreservedOriginal:'+r['kind'],'actual':a,'expected':e,'matches':a['bytes']==e['bytes'] and a['sha256']==e['sha256']})
for r in json.loads((b/'own-seal.json').read_text())['files']:
 a=st(b/r['path']);checks.append({'kind':'thirdAuthor51','expected':r,'actual':a,'matches':a['bytes']==r['bytes'] and a['sha256']==r['sha256']})
fs=json.loads((first/'own-seal.original.json').read_text())
for r in fs['files']:
 a=st(first/r['path']);checks.append({'kind':'secondPeer38','expected':r,'actual':a,'matches':a['bytes']==r['bytes'] and a['sha256']==r['sha256']})
assert all(r['matches']for r in checks)
files={r['path']:r for r in json.loads((first/'input-snapshot.final-universe.json').read_text())['files']}
for r in checks:files[r['actual']['path']]=r['actual']
for p in [b/'own-seal.json',first/'own-seal.original.json']:files[st(p)['path']]=st(p)
index=json.loads((b/'dossier-index.json').read_text())['authorDossiers'];ds=[json.loads(pathlib.Path(r['path']).read_text()) for r in index]
wr('twenty-sealed-author-dossiers.complete.json',ds)
contexts=[]
for d in ds:
 inp=json.loads(pathlib.Path(d['wholeInputPath']).read_text())
 contexts.append({'index':d['goalIndexWithin97'],'goalId':d['wholeGoal']['id'],'title':d['wholeGoal']['title'],'wholeCurrentGoalAndPositiveBody':inp['wholeCurrentGoalAndPositiveBody'],'authorDecision':d['ownCandidate']['decision'],'wholeGoal':d['wholeGoal'],'wholeP':d['wholePositiveProfile'],'historyResolution':d['historyResolution'],'originalIndependentHistory':d['originalAuthorPeerHistories'],'necessity':d['wholeBodyNecessityAndAlternativeAssessment'],'boundary':d['counterexampleAndBoundaryAssessment'],'scope':d['sourceStageAndApplicabilityAssessment'],'ownCandidate':d['ownCandidate'],'unboundMathNominees':d['unboundSuggestedMathNominees'],'authorProbes':d['freshSolvedAuthorProbes'],'directPrereqs':d['directPrerequisiteGoalsReadAsWholeBodies'],'sourceSemanticsPath':d['sourceSemanticsPath']})
 for p in [d['wholeInputPath'],d['sourceSemanticsPath']]:files[st(p)['path']]=st(p)
wr('twenty-complete-review-contexts.actual.json',contexts)
# Actual current central registrations, not reconstructed P profiles.
goals={};subject={}
for sub,p in [('Math','curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'),('Physics','curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json')]:
 for g in json.loads((root/p).read_text())['goals']:goals[g['id']]=g;subject[g['id']]=sub
cp='curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json';central=json.loads((root/cp).read_text());owners={}
for ss in central['subjects']:
 for p in ss.get('positiveEvidenceConfigPaths',[]):
  c=json.loads((root/p).read_text());rp=c['reviewPath'];records=[json.loads(line)for line in(root/rp).read_text().splitlines()if line.strip()]
  for gid in c['scope']['goalIds']:
   if gid in goals:
    rs=[r for r in records if r['goalId']==gid];assert len(rs)==1
    owners.setdefault(gid,[]).append({'config':p,'record':rp,'profile':rs[0]['profile']})
needed={c['goalId']for c in contexts}
for c in contexts:
 needed.update(g['id'] for g in c['directPrereqs'])
 text=json.dumps({k:c[k]for k in ['historyResolution','originalIndependentHistory','necessity','boundary','ownCandidate','unboundMathNominees']})
 needed.update(z for z in re.findall(r'[0-9a-f]{8}-[0-9a-f-]{27}',text)if z in goals)
 for prefix in set(re.findall(r'(?<![0-9a-f])[0-9a-f]{6,8}(?![0-9a-f])',text)):
  matches=[gid for gid in goals if gid.startswith(prefix)]
  if len(matches)==1:needed.add(matches[0])
extra=[]
for gid in sorted(needed):
 own=owners.get(gid,[]);assert len(own)<=1
 extra.append({'goalId':gid,'subject':subject[gid],'wholeGoal':goals[gid],'wholeP':own[0]['profile']if own else None,'owner':{k:v for k,v in own[0].items()if k!='profile'}if own else None})
 if own:
  for k in ['config','record']:files[st(own[0][k])['path']]=st(own[0][k])
wr('all-claimed-whole-prerequisite-contexts.actual.json',extra)
# Every path-binding object supplied by assigned dossier content is captured when present.
def scan(v):
 if isinstance(v,dict):
  p=v.get('path')
  if isinstance(p,str):
   q=pathlib.Path(p);q=q if q.is_absolute()else root/q
   if q.is_file():files[st(q)['path']]=st(q)
  for z in v.values():scan(z)
 elif isinstance(v,list):
  for z in v:scan(z)
scan(ds)
wr('input-snapshot.before.json',{'capturedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':sorted(files.values(),key=lambda x:x['path']),'scope':'Exact third20 assigned originals/current bindings and second20 frozen evidence; no remaining37 author outputs.'})
wr('original-seals-and-current-inputs.fresh.actual.json',{'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'thirdAuthorSeal':seal,'firstPeerSeal':st(first/'own-seal.original.json'),'originalLiteralChecks':len(checks),'allOriginalBytesExact':True,'noScientificApprovalFromHashes':True,'checks':checks})
print(json.dumps({'thirdAuthorFiles':51,'literalChecks':len(checks),'inputSnapshotCount':len(files),'wholeCurrent20':len(contexts),'wholeClaimedContexts':len(extra),'extraContextCount':len(extra)-20}))
