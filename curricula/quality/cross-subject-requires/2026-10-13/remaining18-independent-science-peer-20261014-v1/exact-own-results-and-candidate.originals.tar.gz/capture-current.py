#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import json, hashlib, subprocess
from pathlib import Path
R=Path('/home/enpasos/projects/skillpilot')
B=Path(__file__).resolve().parent
A=R/'tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1'
def read(p): return json.loads((R/p).read_text())
def bind(p):
 p=Path(p);p=p if p.is_absolute() else R/p
 d=p.read_bytes();return {'path':str(p.relative_to(R)), 'bytes':len(d),'sha256':'sha256:'+hashlib.sha256(d).hexdigest()}
def dump(p,d):
 p=B/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
cfg=read('curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json')
goals={};profiles={};owners={};files={}
for s in cfg['subjects']:
 if s['subject'] not in ['mathematik','physik']:continue
 files[s['landscapePath']]=bind(s['landscapePath'])
 for g in read(s['landscapePath'])['goals']:goals[g['id']]=g
 for cp in s['positiveEvidenceConfigPaths']:
  pc=read(cp);rp=pc['reviewPath'];files[cp]=bind(cp);files[rp]=bind(rp)
  scope=set(pc['scope'].get('goalIds',[]))
  for n,line in enumerate((R/rp).read_text().splitlines(),1):
   rec=json.loads(line)
   if rec['goalId'] not in scope:continue
   gid=rec['goalId'];assert gid not in profiles
   profiles[gid]=rec['profile'];owners[gid]={'config':cp,'reviewPath':rp,'line':n,'lineSha256':'sha256:'+hashlib.sha256(line.encode()).hexdigest(),'status':rec['status'],'reviewAuthority':rec['reviewAuthority']}
invpath='curricula/quality/cross-subject-requires/math-physics.inventory.json'
inv=read(invpath);occ={g['goalId']:next(o for o in g['occurrences'] if o['selected']) for f in inv['families'] for g in f['goals'] if any(o['selected'] for o in g['occurrences'])}
proposal=json.loads((A/'native-proposal.bound.inert.json').read_text())
assert bind(A/'native-proposal.bound.inert.json')['sha256']=='sha256:b98560e18d8de84cc7adcbe5931693ba5915b0008eb7b444af1a6d01ce9b49d3'
nom=json.loads((A/'nominee-whole-reader.current.inert.json').read_text())
records=[];source_checks=[]
def has(v,needle):
 if isinstance(v,dict):return any(has(x,needle) for x in v.values())
 if isinstance(v,list):return any(has(x,needle) for x in v)
 return v==needle
def objects(v,out):
 if isinstance(v,dict):
  if isinstance(v.get('id'),str):out.setdefault(v['id'],[]).append(v)
  for x in v.values():objects(x,out)
 elif isinstance(v,list):
  for x in v:objects(x,out)
cache={}
def check_object(path,body):
 if path not in cache:
  cache[path]={};objects(read(path),cache[path]);files[path]=bind(path)
 exact=any(x==body for x in cache[path].get(body.get('id'),[]))
 # Some mappings have no id; actual complete object membership is checked recursively.
 if body.get('id') is None:
  def equal(v):
   if isinstance(v,dict):return v==body or any(equal(x) for x in v.values())
   if isinstance(v,list):return any(equal(x) for x in v)
   return False
  exact=equal(read(path))
 source_checks.append({'path':path,'id':body.get('id',body.get('sourceGoalId')),'exactCurrentObject':exact})
 assert exact,(path,body.get('id'))
for pos,d in enumerate(proposal['decisions'],1):
 gid=d['dependentGoalId'];reader=json.loads(next((A/'readings').glob(f'*-{gid}.current-whole.json')).read_text());dossier=json.loads(next((A/'dossiers').glob(f'*-{gid}.author-successor.json')).read_text());src=json.loads(next((A/'sources').glob(f'*-{gid}.current-source.json')).read_text())
 assert goals[gid]==reader['wholeCurrentGoal']==dossier['currentGoalWhole']
 assert profiles[gid]==reader['wholeCurrentPositiveProfile']==dossier['currentPositiveWhole']
 assert occ[gid]['reviewInput']==d['reviewInput'];assert goals[gid]['requires']==d['proposalBinding']['baselineRequires']
 for sr in src['refreshedSourceRecords']:check_object(sr['sourceFile']['path'],sr['wholeCurrentRecord'])
 for placement in src['mappingPlacements']:
  for row in placement['records']:check_object(placement['sourceFile']['path'],row['wholeCurrentRecord'])
 prereqs=[]
 for pid in d['prerequisiteGoalIds']:
  n=next(r for r in nom['records'] if r['goalId']==pid)
  assert goals[pid]==n['wholeGoal'];assert profiles[pid]==n['wholePositiveProfile']
  for selection in n['explicitCurrentSourceSelection']:
   for row in selection['wholeMappingRows']:check_object(selection['mappingFile']['path'],row)
   for row in selection['wholeSourceGoals']+selection['wholePassages']:check_object(selection['sourceFile']['path'],row)
  prereqs.append({'goalId':pid,'goal':goals[pid],'profile':profiles[pid],'owner':owners[pid],'occurrence':occ[pid],'sourceSelections':n['explicitCurrentSourceSelection']})
 records.append({'position':pos,'goalId':gid,'goal':goals[gid],'profile':profiles[gid],'owner':owners[gid],'occurrence':occ[gid],'authorProposal':d,'originalExposure':reader['selectedOriginalPeer'],'sources':src,'prospectiveWholePrerequisites':prereqs})
 for ref in d['sourceRefs']:files[ref['path']]=bind(ref['path'])
dump('actual-current-whole-reader.private.json',{'records':records,'allGoalAndPExactToMain':True,'sourceChecks':source_checks,'license':{'ownDidacticWork':'CC-BY-4.0; SkillPilot attribution','technical':'Apache-2.0','sourceBodies':'Original rights retained, private bounded review evidence; no relicensing'}})
adj={}
for gid,o in occ.items():
 effective=[k.split(':')[-1] for k in inv['effectivePrerequisiteSets'][o['effectiveRequiresRef']]]
 adj[gid]=[(k,'effective_requires') for k in effective]+[(k.split(':')[-1],'contains_of_required_cluster') for k in goals.get(gid,{}).get('contains',[])]
def paths(start):
 seen={start:[]};q=[start]
 for u in q:
  for v,kind in adj.get(u,[]):
   if v not in seen:seen[v]=seen[u]+[{'from':u,'to':v,'kind':kind}];q.append(v)
 return seen
dump('current-directed-closure.actual.json',{'semantics':'Only forward effective requires, and contains reached from required clusters; no reverse mastery inference','records':[{'goalId':r['goalId'],'paths':paths(r['goalId']),'wholeRequiredGoalAndP':[{'goal':goals[k],'profile':profiles.get(k)} for k in paths(r['goalId']) if k in goals and k!=r['goalId']]} for r in records]})
for p in ['curricula/quality/cross-subject-requires/math-physics.config.json',invpath,'curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json']:files[p]=bind(p)
dump('input-file-bindings.before.json',{'gitHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'authorProposal':bind(A/'native-proposal.bound.inert.json'),'files':list(files.values()),'sourceChecks':source_checks})
print(json.dumps({'currentWholeGoals':len(records),'prospectivePrerequisiteBodies':sum(len(r['prospectiveWholePrerequisites']) for r in records),'exactSourceObjectsChecked':len(source_checks),'inputFiles':len(files),'failures':0}))
