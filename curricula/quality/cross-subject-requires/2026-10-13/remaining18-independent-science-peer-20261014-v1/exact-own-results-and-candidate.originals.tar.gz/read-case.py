#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import json,sys
from pathlib import Path
B=Path(__file__).resolve().parent
data=json.loads((B/'actual-current-whole-reader.private.json').read_text())
positions=[int(n) for n in sys.argv[2:]]
def de(v):
 if isinstance(v,dict):return {k:de(w) for k,w in v.items() if not k.endswith('En') and k!='resourceLinks'}
 if isinstance(v,list):return [de(w) for w in v]
 return v
seen=set()
for pos in positions:
 r=data['records'][pos-1];print('\nCASE',pos,r['goalId'])
 if sys.argv[1]=='body':
  print(json.dumps(de({'goal':r['goal'],'profile':r['profile']}),ensure_ascii=False))
  for p in r['prospectiveWholePrerequisites']:
   print('WHOLE NOMINEE',json.dumps(de({'goal':p['goal'],'profile':p['profile']}),ensure_ascii=False))
 elif sys.argv[1]=='source':
  for sr in r['sources']['refreshedSourceRecords']:
   w=sr['wholeCurrentRecord'];text=w.get('text',w.get('sourceText',w.get('description','')))
   key=(sr['sourceFile']['path'],text)
   if key in seen:continue
   seen.add(key);print(json.dumps({'path':key[0],'id':w.get('id'),'scope':{k:w[k] for k in ['sourceSpan','topicCode','courseLevel','page','sourceUrl','sourceRef'] if k in w},'wholeText':text},ensure_ascii=False))
  for p in r['prospectiveWholePrerequisites']:
   print('NOMINEE SOURCE',p['goalId'])
   for ss in p['sourceSelections']:
    print('mapping',ss['mappingFile']['path'])
    for w in ss['wholeSourceGoals']+ss['wholePassages']:
     text=w.get('text',w.get('sourceText',w.get('description','')));key=(ss['sourceFile']['path'],text)
     if key in seen:continue
     seen.add(key);print(json.dumps({'path':key[0],'id':w.get('id'),'scope':{k:w[k] for k in ['sourceSpan','topicCode','courseLevel','page','sourceUrl','sourceRef'] if k in w},'wholeText':text},ensure_ascii=False))
 elif sys.argv[1]=='closure':
  c=json.loads((B/'current-directed-closure.actual.json').read_text())['records'][pos-1]
  print('PATHS',json.dumps({p['goalId']:c['paths'].get(p['goalId']) for p in r['prospectiveWholePrerequisites']}))
  for p in c['wholeRequiredGoalAndP']:
   if p['profile'] is not None and p['goal']['id'] in r['goal']['requires']:print(json.dumps(de(p),ensure_ascii=False))
 elif sys.argv[1]=='author':
  d=json.loads(next((B.parent/'remaining18-whole-science-author-20261014-v1/dossiers').glob(f'*-{r["goalId"]}.author-successor.json')).read_text())
  print(json.dumps({k:d[k] for k in ['wholeNecessaryMathematicalAssessment','literalCurrentPCase','freshDiscriminatingCounterexampleOrTransfer','sourceAndScopeJudgment']}|{'dissent':r['originalExposure']},ensure_ascii=False))
