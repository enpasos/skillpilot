// SPDX-License-Identifier: Apache-2.0
import {readFileSync,writeFileSync,existsSync} from 'node:fs'
import {resolve} from 'node:path'
import {bytesFingerprint,fingerprint,stableJson,readActiveLandscapes,buildRequiresInventory,assertFreshRequiresInventory} from '../../../app/scripts/lib/crossSubjectRequiresInventory.ts'
import {validateRequiresDecisions} from '../../../app/scripts/lib/crossSubjectRequiresReview.ts'
import {buildCrossLandscapeGraph,findCrossLandscapeCycles} from '../../../app/scripts/lib/crossLandscapeGraph.ts'
const repo=resolve(process.cwd(),'..')
const base='tmp/cross-subject-requires/remaining18-independent-science-peer-20261014-v1'
const author='tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/native-proposal.bound.inert.json'
const read=(p:string)=>JSON.parse(readFileSync(resolve(repo,p),'utf8'))
const write=(p:string,v:unknown)=>writeFileSync(resolve(repo,base,p),JSON.stringify(v,null,2)+'\n',{flag:'wx'})
const raw=readFileSync(resolve(repo,author));const packet=JSON.parse(raw.toString())
if(bytesFingerprint(raw)!=='sha256:b98560e18d8de84cc7adcbe5931693ba5915b0008eb7b444af1a6d01ce9b49d3')throw new Error('Original author packet changed')
const reprepared=readFileSync(resolve(repo,base,'reprepared-author-proposal.native.json'))
if(!raw.equals(reprepared))throw new Error('Native re-preparation did not reproduce exact original proposal bytes')
const config=read('curricula/quality/cross-subject-requires/math-physics.config.json')
const invpath='curricula/quality/cross-subject-requires/math-physics.inventory.json'
const inventory=read(invpath)
const rebuilt=buildRequiresInventory(repo,config)
const invsha=assertFreshRequiresInventory(rebuilt,resolve(repo,invpath))
const review=read(base+'/native-independent-review.unbound.inert.json')
review.decisions=review.decisions.map((r:any)=>{
 const d=packet.decisions.find((d:any)=>d.decisionId===r.decisionId)
 if(!d||stableJson(d.reviewInput)!==stableJson(r.reviewInput))throw new Error('Independent review input mismatch')
 return {...r,proposalBindingSha256:fingerprint(d.proposalBinding)}
})
write('native-independent-review.bound.inert.json',review)
const options={familyIds:['canonical-gymnasium'],sourcePathExists:(p:string)=>existsSync(resolve(repo,p)),independentReview:review,authorLedgerSha256:bytesFingerprint(raw),inventorySha256:invsha}
const report=validateRequiresDecisions(inventory,packet,options)
if(report.errors.length)throw new Error(report.errors.join('\n'))
if(report.reviewed!==17)throw new Error('Expected exactly17 native approved records')
const slice={...inventory,families:inventory.families.map((f:any)=>({...f,goals:f.goals.map((g:any)=>({...g,reviewRequired:packet.decisions.some((d:any)=>d.dependentGoalId===g.goalId)}))}))}
const selectedReport=validateRequiresDecisions(slice,packet,options)
if(selectedReport.errors.length||selectedReport.required!==18||selectedReport.reviewed!==17)throw new Error('Selected18 validation mismatch')
write('selected18-native-validation.actual.json',{reason:'Bounded selection changes reviewRequired only, retaining every actual goal/owner/foreign nominee. Full real inventory validation is separately preserved.',validation:selectedReport})
const all=readActiveLandscapes(repo,{...config,excludedDirectories:['quality']})
const overrides=new Map(packet.decisions.map((d:any)=>[d.dependentGoalId,d.proposalBinding.proposedRequires]))
const proposed=all.map(l=>({...l,goals:l.goals.map(g=>overrides.has(g.id)&&config.families[0].paths.includes(l.file)?{...g,requires:overrides.get(g.id) as string[]}:g)}))
const bg=buildCrossLandscapeGraph(all);const pg=buildCrossLandscapeGraph(proposed)
const refs=pg.diagnostics.filter(d=>['missing_reference','ambiguous_reference'].includes(d.code));const cycles=findCrossLandscapeCycles(pg)
if(refs.length||cycles.length)throw new Error('Invalid proposed graph')
function path(graph:any,from:string,to:string){
 const start=graph.owners.get(from)?.find((n:any)=>config.families[0].paths.includes(n.file))
 const end=graph.owners.get(to)?.find((n:any)=>config.families[0].paths.includes(n.file))
 if(!start||!end)return null
 const seen=new Map<string,any[]>([[start.key,[]]]);const queue=[start.key]
 for(const k of queue){
  if(k===end.key)return seen.get(k)
  const edges=[...(graph.effectiveRequires.get(k)??[]).map((v:string)=>({v,kind:'effective_requires'})),...(graph.contains.get(k)??[]).map((v:string)=>({v,kind:'contains_of_required_cluster'}))]
  for(const e of edges)if(!seen.has(e.v)){seen.set(e.v,[...seen.get(k)!,{from:k,to:e.v,kind:e.kind}]);queue.push(e.v)}
 }
 return null
}
const minimality=packet.decisions.map((d:any)=>({goalId:d.dependentGoalId,nomineeBaselinePaths:d.prerequisiteGoalIds.map((pid:string)=>({goalId:pid,path:path(bg,d.dependentGoalId,pid)})),amongProposedNomineePaths:d.prerequisiteGoalIds.flatMap((p:string)=>d.prerequisiteGoalIds.filter((q:string)=>p!==q).map((q:string)=>({from:p,to:q,path:path(pg,p,q)})))}))
const m17=minimality.find((d:any)=>d.goalId==='cd1903a5-d70a-5320-9124-b6b24917ba14')!
const redundant=m17.amongProposedNomineePaths.find((p:any)=>p.from==='57fbbf31-9b8c-5408-9af5-fbc73acd12bb'&&p.to==='54148506-c23f-41b8-959b-068dd194cf15')
if(!redundant?.path?.length)throw new Error('Own redundancy finding did not reproduce in native graph')
write('native-directed-minimality.actual.json',{semantics:'Forward effective requires and required-cluster contains expansion only. No inverse mastery inference.',records:minimality,exact17RedundantForwardPath:redundant})
const rejected=review.decisions.filter((d:any)=>d.decision==='rejected').map((d:any)=>d.decisionId)
write('native-independent-validation.actual.json',{authorPacketSha256:bytesFingerprint(raw),repreparedPacketSha256:bytesFingerprint(reprepared),byteExactNativeRepreparation:true,currentInventorySha256:invsha,inventoryRebuiltAndAssertedFresh:true,validation:report,selected18:{approved:17,rejected:1,pending:0,rejectedDecisionIds:rejected},proposalGraph:{missingReferences:refs.filter(d=>d.code==='missing_reference').length,ambiguousReferences:refs.filter(d=>d.code==='ambiguous_reference').length,globalCycles:cycles.length},nativeZeroErrorsDoesNotApproveScience:true,sourcePKindDHumanM7AdoptionNotApproved:true})
console.log(JSON.stringify({nativeErrors:report.errors.length,required:report.required,reviewed:report.reviewed,open:report.open,selected18:{approved:17,rejected:1,pending:0},repreparedByteExact:true,missingReferences:refs.length,globalCycles:cycles.length,redundancyPath:redundant.path.map((s:any)=>({from:s.from.split(':').at(-1),to:s.to.split(':').at(-1),kind:s.kind}))}))
