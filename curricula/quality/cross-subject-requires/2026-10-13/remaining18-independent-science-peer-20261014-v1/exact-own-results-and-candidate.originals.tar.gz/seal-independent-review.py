#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import json,hashlib,datetime,subprocess
from pathlib import Path
B=Path(__file__).resolve().parent
R=B.parents[2]
A=B.parent/'remaining18-whole-science-author-20261014-v1'
def load(p):return json.loads(p.read_text())
def bind(p):
 raw=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(raw),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()}
def dump(name,obj):
 p=B/name
 if p.exists():raise RuntimeError('Refuse overwrite sealed file')
 p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
before=load(B/'input-file-bindings.before.json');checks=[]
for prior in before['files']:
 actual=bind(R/prior['path']);checks.append({'path':prior['path'],'exactBytesUnchanged':actual==prior,'before':prior,'after':actual})
assert all(c['exactBytesUnchanged'] for c in checks)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head==before['gitHead']
aseal=load(A/'artifact-seal.final.json');author_checks=[]
for prior in aseal['files']:
 actual=bind(R/prior['path']);author_checks.append({'path':prior['path'],'exactBytesUnchanged':actual==prior})
assert all(c['exactBytesUnchanged'] for c in author_checks)
# Additive primary math sources were not assumed current from their reader.
supp=load(A/'two-bw-explicit-nominee-source-reader.additive.json');supp_checks=[]
def nested(v,body):
 if isinstance(v,dict):return v==body or any(nested(w,body) for w in v.values())
 if isinstance(v,list):return any(nested(w,body) for w in v)
 return False
for record in supp:
 for key in ['mappingFile','sourceFile']:assert bind(R/record[key]['path'])==record[key]
 source=load(R/record['sourceFile']['path']);mapping=load(R/record['mappingFile']['path'])
 for row in record['records']:
  vals={'mapping':nested(mapping,row['wholeMappingRow']),'sourceGoal':nested(source,row['wholeSourceGoal']),'wholePassage':nested(source,row['wholePassage'])}
  assert all(vals.values());supp_checks.append({'goalId':record['goalId'],'checks':vals})
dump('final-freshness-and-original-preservation.actual.json',{'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headBefore':before['gitHead'],'headAfter':head,'headUnchanged':True,'boundMainAndEvidenceFiles':len(checks),'allBoundInputsExactBytesUnchanged':True,'inputChecks':checks,'originalAuthorSealedFiles':len(author_checks),'originalAuthorAllExactBytesUnchanged':True,'authorChecks':author_checks,'additiveBWOriginalObjectsCurrent':supp_checks,'gitWorkingTreeWasPreexistingDirty':True,'noClaimOfCleanWorkingTree':True,'ownWritesRestrictedTo':str(B.relative_to(R))})
science=load(B/'individual18.independent-scientific-verdicts.json');native=load(B/'native-independent-validation.actual.json')
dump('actual-execution-receipts.json',{'commands':[{'cwd':'app','command':'./node_modules/.bin/tsx scripts/prepareCrossSubjectRequiresProposal.ts --ledger tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/native-author-ledger.unbound.inert.json --output tmp/cross-subject-requires/remaining18-independent-science-peer-20261014-v1/reprepared-author-proposal.native.json','exitCode':0,'observedStdout':'Prepared 18 unreviewed proposals with baseline/proposed bindings; 0 proposed global cycles.'},{'cwd':'app','command':'./node_modules/.bin/tsx ../tmp/cross-subject-requires/remaining18-independent-science-peer-20261014-v1/native-independent-validation.mts','exitCode':0,'observedNonemptyResult':{'nativeErrors':0,'required':1285,'reviewed':17,'open':1268,'selected18':{'approved':17,'rejected':1,'pending':0},'repreparedByteExact':True,'missingReferences':0,'globalCycles':0}}],'nonemptyNativeResultFile':bind(B/'native-independent-validation.actual.json'),'selected18NativeResultFile':bind(B/'selected18-native-validation.actual.json'),'technicalValidationIsNotScientificApproval':True})
summary=['Independent informed scientific review of the exact18 author proposals.','', '17 approved;1 exact proposal rejected. No Main/canonical/P/config/index/HEAD changes.','', 'The rejected ideal-gas proposal redundantly adds541485 alongside57fbb:57fbb→f2e42→541485 already supplies the complete prerequisite in the forward proposed closure. A separately authored and rebound single57fbb successor is indicated; it is not approved by this packet.','', 'Native proposal re-preparation reproduced all original bytes. Native review:0errors; full universe1285 required/17reviewed/1268open. Bounded selection18required/17reviewed/1open. Missing/ambiguous references0, cycles0.','', 'Color empirical graphic and actual historical AU inputs remain missing/unperformed. Case5 does not claim its task supplies Gauss law/single-sheet field; physical foundational proof/P readiness remains separate. Source/placement/P/Kind/D/Human/M7/adoption gates remain unapproved.','', '| # | Goal | Exact author decision | Independent verdict |','|---|---|---|---|']
for d in science['decisions']:summary.append(f"|{d['pos']}|{d['title']}|{d['authorDecision']}|{d['verdict']}|")
(B/'review-summary.md').write_text('\n'.join(summary)+'\n')
# Seal all pre-handoff artifacts; self and following handoff are excluded.
files=[bind(p) for p in sorted(B.rglob('*')) if p.is_file() and p.name not in ['artifact-seal.final.json','completion.handoff.json']]
dump('artifact-seal.final.json',{'schemaVersion':'private-independent-review-artifact-seal-v1','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'INFORMED_INDEPENDENT_SCIENTIFIC_REQUIRES_REVIEW','files':files,'count':len(files),'sealExcludesItselfAndFollowingHandoff':True})
handoff={'schemaVersion':'remaining18-independent-review-handoff-v1','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'identity':science['identity'],'scope':science['scope'],'authorProposal':bind(A/'native-proposal.bound.inert.json'),'counts':science['counts'],'individual18':[{'position':d['pos'],'goalId':d['goalId'],'title':d['title'],'authorDecision':d['authorDecision'],'authorForeignIds':d['authorPrerequisiteGoalIds'],'independentExactProposalVerdict':d['verdict'],'scientificallyNecessaryNewForeignIds':d['necessary']} for d in science['decisions']],'nativeResults':native,'scientificVerdicts':bind(B/'individual18.independent-scientific-verdicts.json'),'nativeIndependentReview':bind(B/'native-independent-review.bound.inert.json'),'ownWholeMathematicalSolvedWork':bind(B/'own-whole-mathematical-prerequisite-solutions.json'),'ownPhysicalLiteralAndFreshWorkLocation':'individual18.independent-scientific-verdicts.json, literal and fresh fields for each case','nativeDirectedMinimality':bind(B/'native-directed-minimality.actual.json'),'freshnessAndOriginalPreservation':bind(B/'final-freshness-and-original-preservation.actual.json'),'sealedArtifactIndex':bind(B/'artifact-seal.final.json'),'unresolvedScientificCorrection':'Exact ideal-gas pair of direct edges is redundant; add only57fbb in a new independently bound successor. No successor is silently authored/adopted here.','separateOpenGates':['Color empirical required source graphic missing; synthetic triplets do not substitute.','Actual historical AU texts and observations absent; symbolic/synthetic work is not historical task completion.','Single-sheet foundational physical premise/proof in case5 is not provided by the literal task; the no-new-Math verdict uses inherited capacitor relations and does not close P readiness.','Curated-only physics direct locators and differing official scopes do not establish national source/placement.','P, Kind, D, Human, M7 and adoption require their actual independent evidence; none approved here.'],'boundaries':{'allWritesWithinOwnTmpFolder':True,'mainCanonicalProfilesQualityConfigIndexHeadWrites':False,'originalAuthorBytesUnchanged':True,'originalDissentAndFailureRecordsPreserved':True,'humanApprovalInvented':False,'protectedFloorsReduced':False,'committedPushedDeployed':False,'absoluteBlindFirstPassClaim':False,'modelDiversityClaim':False}}
dump('completion.handoff.json',handoff)
print(json.dumps({'approved':17,'rejected':1,'nativeErrors':0,'currentInputsUnchanged':len(checks),'originalAuthorSealedFilesUnchanged':len(author_checks),'sealedOwnArtifacts':len(files),'handoff':str((B/'completion.handoff.json').relative_to(R)),'handoffSha256':bind(B/'completion.handoff.json')['sha256']}))
