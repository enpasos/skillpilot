// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import {readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {compileCompositionView as candidate} from './private-alias/app/src/utils/authoring/compositionViewAuthoring.ts';
import {compileCompositionView as main} from '../../../app/src/utils/authoring/compositionViewAuthoring.ts';
const repo=process.cwd(),base=resolve(repo,'tmp/cross-subject-requires/whole-physics-native-stage-course-route-audit-20261014-v2'),bindings:any[]=[];
const hash=(v:Buffer|string)=>'sha256:'+createHash('sha256').update(v).digest('hex');
const read=(p:string)=>{const b=readFileSync(p);bindings.push({path:p,bytes:b.length,sha256:hash(b)});return JSON.parse(b.toString('utf8'));};
const docs=read(resolve(base,'native-matches.v5-visible-overlap-guard.actual.json'));
const canonDir=resolve(base,'regular-candidate-inputs/curricula/DE/Gymnasium/canonical'),landscapes=new Map<string,any>();
for(const n of readdirSync(canonDir).filter(n=>n.endsWith('.json'))){const landscape=read(resolve(canonDir,n));assert(!landscapes.has(landscape.landscapeId));landscapes.set(landscape.landscapeId,landscape);}
const universe={landscapeId:'own-recheck-exact-universe',title:'Own exact native-returned context',goals:[...landscapes.values()].flatMap(l=>l.goals)};
const rows:any[]=[];
for(const doc of docs){
 assert.equal(doc.actualProductionMatcherInvoked,true);assert(doc.matchedView);const originalInput=JSON.stringify(doc);const landscape=landscapes.get(doc.landscapeId);assert(landscape);
 const fresh=candidate(doc.matchedView,landscape,universe,landscapes),old=main(doc.matchedView,landscape,universe,landscapes);
 assert.deepEqual(fresh.compiledRootNodes,old.compiledRootNodes,doc.key+' exact tree');assert.equal(JSON.stringify(doc),originalInput);
 assert.deepEqual(fresh.findings.filter(f=>f.severity==='error'),[],doc.key+' no new blocking findings');
 // Only CPV-004 can legitimately differ in this source patch.
 assert.deepEqual(fresh.findings.filter(f=>f.code!=='CPV-004'),old.findings.filter(f=>f.code!=='CPV-004'),doc.key+' all other diagnostics stable');
 rows.push({key:doc.key,subject:doc.subject,viewId:doc.matchedView.viewId,requestedScope:doc.requestedScope,compiledTreeSha256:hash(JSON.stringify(fresh.compiledRootNodes)),compiledTreesExactlyEqual:true,inputUnchanged:true,mainErrors:old.findings.filter(f=>f.severity==='error'),candidateErrors:fresh.findings.filter(f=>f.severity==='error'),nonCPV004DiagnosticsExactlyEqual:true});
}
for(const b of bindings)assert.equal(hash(readFileSync(b.path)),b.sha256,b.path+' unchanged');
writeFileSync(new URL('./actual-native-scope-doc-recheck.actual.json',import.meta.url),JSON.stringify({role:'Fresh independent informed AI compiler recheck of exact already-produced Java native-v5 scope documents; no fresh Java/provider invocation claimed',executedAtUTC:new Date().toISOString(),bindings,scopeDocuments:rows.length,canonicalLandscapes:landscapes.size,allCompiledTreesExactlyUnchanged:true,totalCandidateErrors:0,totalMainErrors:rows.reduce((n,r)=>n+r.mainErrors.length,0),allNonCPV004DiagnosticsUnchanged:true,rows,noSourcePDScIM7HumanApproval:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({scopeDocuments:rows.length,canonicalLandscapes:landscapes.size,allExactTreesUnchanged:true,candidateErrors:0,allNonCPV004DiagnosticsUnchanged:true}));
