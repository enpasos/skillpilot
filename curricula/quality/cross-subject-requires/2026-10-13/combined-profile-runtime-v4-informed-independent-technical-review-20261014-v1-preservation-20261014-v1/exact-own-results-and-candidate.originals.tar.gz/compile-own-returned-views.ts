// SPDX-License-Identifier: Apache-2.0
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {compileCompositionView} from '../../../app/src/utils/authoring/compositionViewAuthoring.ts';
const out=dirname(fileURLToPath(import.meta.url));
const results:any[]=[];
for(const version of ['baseline','v4']){
 const raw=JSON.parse(readFileSync(resolve(out,version+'-own-cases.actual.json'),'utf8'));
 for(const row of raw.cases){
  if(!row.returnedRoots)continue;
  const graph=row.canonicalGraph;
  const landscape={landscapeId:'review',title:'Reviewer canonical fixture',goals:Object.entries(graph).map(([id,children])=>({id,title:id+' competency',description:'Reviewer fixture only',contains:children,requires:[],type:(children as any[]).length?'cluster':'atomic',weight:1,tags:[]}))};
  const view={viewId:'own-'+row.caseId,landscapeId:'review',scope:{schoolForm:'Gymnasium',stage:'SekII',courseProfile:'GK+LK'},rootNodes:row.returnedRoots};
  const compiled=compileCompositionView(view as any,landscape as any);
  results.push({version,caseId:row.caseId,backendTargetsCorrect:row.passedDeclaredExpectation??null,singleGKUnchanged:row.singleGKUnchanged??null,singleLKUnchanged:row.singleLKUnchanged??null,findings:compiled.findings,compilerErrors:compiled.findings.filter(f=>f.severity==='error'),compiledRootNodes:compiled.compiledRootNodes});
 }
}
const target=resolve(out,'own-native-frontend-compiler-results.actual.json');if(existsSync(target))throw new Error('Additive result exists');
writeFileSync(target,JSON.stringify({role:'Actual production frontend composition compiler run on fresh own Java-returned views; backend target-union equality is not tree validity',results},null,2)+'\n');
console.log(JSON.stringify(results.map(r=>({version:r.version,caseId:r.caseId,backendTargetsCorrect:r.backendTargetsCorrect,compilerErrors:r.compilerErrors.map((f:any)=>({code:f.code,goalId:f.goalId,message:f.message})),singleGKUnchanged:r.singleGKUnchanged,singleLKUnchanged:r.singleLKUnchanged}))));
