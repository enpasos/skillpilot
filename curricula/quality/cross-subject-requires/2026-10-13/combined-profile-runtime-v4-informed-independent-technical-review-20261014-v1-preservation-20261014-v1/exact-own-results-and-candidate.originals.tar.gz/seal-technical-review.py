# SPDX-License-Identifier: Apache-2.0
import pathlib,json,hashlib,datetime,subprocess,xml.etree.ElementTree as ET
root=pathlib.Path.cwd();out=pathlib.Path(__file__).resolve().parent;candidate=root/'tmp/cross-subject-requires/combined-profile-subtree-dedup-runtime-candidate-20261014-v4'
def read(p):return json.loads(p.read_text())
def stat(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':'sha256:'+hashlib.sha256(b).hexdigest()}
def write(name,data):
 p=out/name
 if p.exists():raise RuntimeError('Additive artifact exists; overwrite refused '+name)
 p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
initial=read(out/'original-inputs.before.actual.json');inputs=initial['files']+initial['classpathFiles'];checks=[];fail=[]
for r in inputs:
 a=stat(pathlib.Path(r['path']));same=all(a[k]==r[k]for k in ['bytes','sha256']);checks.append({'expected':r,'actual':a,'exact':same})
 if not same:fail.append(checks[-1])
extra=[]
for p in (root/'app/src/utils/authoring').glob('*.ts'):extra.append(stat(p))
xmls=[]
for p in (candidate/'backend-build-candidate/test-results/test').glob('TEST-*.xml'):
 d=ET.parse(p).getroot();xmls.append({'file':stat(p),'tests':int(d.attrib['tests']),'failures':int(d.attrib['failures']),'errors':int(d.attrib['errors'])});extra.append(stat(p))
fixture=[]
for version in ['baseline','v4']:
 row=next(r for r in read(out/(version+'-own-cases.actual.json'))['cases']if r['caseId']=='own-service-production-combined-and-single-views')
 for index,name in enumerate(['gk','lk']):
  p=out/version/'service-fixture/DE/Gymnasium/composition-views/mathematik'/(name+'.view.json');value=read(p);assert value['rootNodes']==row['inputSourceRoots'][index];fixture.append({'file':stat(p),'actualAuthoredSourceRootsExactAfterProductionServiceReads':True})
diffs=[]
for main,private in [('backend/src/main/java/com/skillpilot/backend/service/CompositionViewService.java','source/com/skillpilot/backend/service/CompositionViewService.java'),('backend/src/main/java/com/skillpilot/backend/composition/CourseProfileCompositionViewMerger.java','source/com/skillpilot/backend/composition/CourseProfileCompositionViewMerger.java')]:
 p=subprocess.run(['diff','-u',str(root/main),str(candidate/private)],capture_output=True,text=True);assert p.returncode==1;diffs.append(p.stdout)
p=out/'exact-v4-versus-main-source-diffs.actual.patch';assert not p.exists();p.write_text('\n'.join(diffs))
compiler=read(out/'own-native-frontend-compiler-results.actual.json')['results'];bad=[r for r in compiler if r['version']=='v4'and r['compilerErrors']];assert len(bad)==2
findings=[]
for row in bad:
 native=next(r for r in read(out/'v4-own-cases.actual.json')['cases']if r['caseId']==row['caseId']);findings.append({'caseId':row['caseId'],'sourcesIndividuallyRepresentable':True,'backendReturnedWithoutException':True,'backendTargetUnionExact':native['actualTargets']==sorted(native['expectedTargets'])if False else set(native['actualTargets'])==set(native['expectedTargets']),'productionCompilerErrors':row['compilerErrors'],'returnedRoots':native['returnedRoots'],'existingBaselineHasSameGap':any(r['version']=='baseline'and r['caseId']==row['caseId']and r['compilerErrors']for r in compiler)})
sources={'mainService':stat(root/'backend/src/main/java/com/skillpilot/backend/service/CompositionViewService.java'),'mainMerger':stat(root/'backend/src/main/java/com/skillpilot/backend/composition/CourseProfileCompositionViewMerger.java'),'v4Service':stat(candidate/'source/com/skillpilot/backend/service/CompositionViewService.java'),'v4Merger':stat(candidate/'source/com/skillpilot/backend/composition/CourseProfileCompositionViewMerger.java')}
review={'role':'Actual INFORMED independent AI technical review of exact private v4 production Java sources; not author, blind or human','reviewer':'/root/unresolved97_final17_completion','completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'reject_current_v4_for_unqualified_combined_tree_safety','exactSources':sources,'ownActualProductionJavaCases':14,'satisfactoryContractCases':12,'actualResidualTreeFailures':findings,'actualBaselineAndV4SeparateRecompileAndExecution':True,'actualProductionFrontendCompilerUsed':True,'ownFixturesAfterServiceReads':fixture,
 'conclusion':'Global equality-based strict-subset dedup repairs cross-branch subtree and direct-leaf duplication. It leaves cross-branch presentation conflicts and partial overlaps untouched; the final set equality accepts these compiler-invalid trees. The unchanged sibling-only overlap checker does not see those cross-branch references. Existing Main also has this residual gap, so this is not alleged to be a newly introduced regression. Current v4 is rejected as an unqualified fail-closed combined-tree fix.',
 'requiredBoundedFollowup':'After safe global strict-subset dedup, reject any remaining unrepresentable visible target overlap across the whole view, considering actual expected-target projection and source-local exclusions; prerequisiteOnly-only coverage must not be mistaken for a visible duplicate. Retain exact target union before/after and strict generic contract. New source version needs a separate fresh review; do not overwrite this v4 result.',
 'satisfactoryEvidence':['Global same-role/same-presentation strict canonical subtree containment dedups once and prunes empty wrappers.','Global direct-leaf strict redundancy dedups once.','Common direct exclusions remain unmastered and prerequisiteOnly.','One profile direct exclusion cannot suppress another source inherited target.','Nearest subtree common prerequisiteOnly role is retained.','Target dominates only at equal specificity.','Removing a direct override that would alter the target union rejects.','Sibling presentation conflict, unknown canonical ID and contains cycle reject.','Generic subtree+direct-leaf overlap remains strict.','Production service keeps individual GK/LK roots unchanged while safe combined view compiles.','Sources and canonical graph remain unchanged and returned structures are frozen.'],
 'authorRegressionEvidenceObserved':{'targetedTests':sum(x['tests']for x in xmls),'failures':sum(x['failures']for x in xmls),'errors':sum(x['errors']for x in xmls),'records':xmls,'notMyOwnCountercaseProof':True},
 'exposureDisclosure':['Parent reported v1/v2/v3 defects and v4 HashSet correction,84 passing author-targeted tests and whole-production matrix work.','I read exact Main/v4 source diffs and relevant full merger/service paths plus author3-case regression source.','Own14 cases and actual source recompilation/frontend compilation were independently designed and executed; no author cases or test counts were substituted for them.','Root-owned whole-production route audit was not mutated or granted a whole-matrix acceptance by this review.'],
 'scope':'Java course-profile composition/runtime technical behavior only; no curriculum content, Source/P/D/SCI/M7, human acceptance, active adoption or production approval','mainOrCandidateSourceWrites':False,'MainDataDocInventoryCheckpointWrites':False,'commitStagePublishDeploy':False,'hashEqualityIsPreservationOnly':True}
write('technical-review.actual.json',review)
write('original-inputs-fresh-endcheck.actual.json',{'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'allInitialInputsExact':not fail,'failures':fail,'additionalReadonlyInputs':extra,'scope':'Exact input preservation only, not technical quality approval'})
assert not fail
write('handoff.json',{'role':review['role'],'decision':review['decision'],'currentV4Sources':sources,'review':stat(out/'technical-review.actual.json'),'ownJavaResults':stat(out/'v4-own-cases.actual.json'),'baselineJavaResults':stat(out/'baseline-own-cases.actual.json'),'actualCompilerResults':stat(out/'own-native-frontend-compiler-results.actual.json'),'actualExecutions':stat(out/'own-production-java-executions.actual.json'),'ownCountercases':14,'satisfactory':12,'remainingCompilerInvalidReturnedViews':2,'compilerErrors':['CPV-004','CPV-005','CPV-006'],'defectsAlsoPresentInMain':True,'newRegressionClaim':False,'recheckNewV5Required':True,'noSourcePDScIM7HumanOrAdoptionApproval':True,'mainOrCandidateWrites':False,'ownSeal':'own-seal.json','ownEndcheck':'own-endcheck.actual.json'})
files=[stat(p)for p in sorted(out.rglob('*'))if p.is_file()and p.name not in ['own-seal.json','own-endcheck.actual.json']]
write('own-seal.json',{'sealedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'Exact independent v4 technical reject artifacts preserved','files':files,'selfExcluded':'own-seal.json','postsealCheckExcluded':'own-endcheck.actual.json'})
post=[]
for r in inputs+extra+files:
 a=stat(pathlib.Path(r['path']))
 if any(a[k]!=r[k]for k in ['bytes','sha256']):post.append({'expected':r,'actual':a})
write('own-endcheck.actual.json',{'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allOriginalAndOwnArtifactsExact':not post,'inputChecks':len(inputs)+len(extra),'ownArtifactChecks':len(files),'failures':post,'mainOrCandidateWrites':False,'technicalDecision':'reject_v4'})
print(json.dumps({'handoff':stat(out/'handoff.json'),'ownSeal':stat(out/'own-seal.json'),'endcheck':stat(out/'own-endcheck.actual.json'),'v4Sources':sources,'allOriginalAndOwnArtifactsExact':not post},ensure_ascii=False));raise SystemExit(1 if post else 0)
