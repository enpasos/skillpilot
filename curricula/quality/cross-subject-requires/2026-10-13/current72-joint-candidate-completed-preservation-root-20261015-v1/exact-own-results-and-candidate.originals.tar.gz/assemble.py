"""Compose exact bounded candidates without touching authoritative source.

SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime, timezone
import copy
import errno
import hashlib
import json
import os

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
T = R / 'tmp/cross-subject-requires'
W = O / 'candidate'
PHYS = 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'
MATH = 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
KIND = 'curricula/DE/Gymnasium/quality/release-model/physik.semantic-kinds.json'
REG = 'curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
hash_bytes = lambda b: hashlib.sha256(b).hexdigest()
sha = lambda p: hash_bytes(p.read_bytes())
load = lambda p: json.loads(p.read_text())
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
def binding(p):
    return {'path': str(p.relative_to(R)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
def write_json(p, x):
    assert p.is_relative_to(O)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(dump(x))
    json.loads(p.read_text())

assert Path.cwd().resolve() == O
assert not W.exists(), 'Never overwrite a prior candidate or failed attempt'
# Test the actual mount boundary before any fixture creation.
canaries = []
for p, mode in [(R / '.git/index', os.O_WRONLY),
                (R / 'tmp/cross-subject-requires/joint-candidate-outside-new-canary-20261015-v1',
                 os.O_WRONLY | os.O_CREAT | os.O_EXCL)]:
    try:
        fd = os.open(p, mode, 0o600)
    except OSError as e:
        assert e.errno == errno.EROFS, (str(p), e.errno)
        canaries.append({'path': str(p.relative_to(R)), 'errno': e.errno})
    else:
        os.close(fd)
        raise AssertionError('Root unexpectedly writable: ' + str(p))
(O / 'private-positive-write.actual').write_text('private only\n')
write_json(O / 'root-readonly-selfcheck.actual.json', {'outside': canaries, 'privateWrite': True})
assert sha(R / '.git/index') == '6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8'
assert sha(R / MATH) == '893a43d06900708643a33bf490820db6444078ec8284a1aa7086a8ecc30ce2ae'
assert sha(R / PHYS) == '38dcc3a7e4f910e6d7c8129d14d88cc198534f2bf7d449fc05ef5d5d7f97e637'
assert sha(R / KIND) == 'f49169289bd6dac3916e620dd6d8b697444ca1b230e3bf4d9afa94233a6fb2a7'

lanes = {
    'code': T / 'merge-current-p-guard-and-native-transport-author-20261015-v1',
    'volume': T / 'he-g9-volume-first-actual-preparation-author-20261015-v1',
    'eighteen': T / 'gymnasium-i02-i05-eighteen-current-integration-author-20261015-v1',
    'two': T / 'oscillator-induction-bounded-successors-author-20261015-v1',
    'freefall': T / 'free-fall-current-p-planning-gap-informed-author-20261015-v1',
}
expected_handoffs = {
    'code': '8089d9d6dfa39bae537d054842cc5624dc97e6435c8836098fd340c9840aade7',
    'volume': '70d3b35a13bbeb869f2ce34e28868c024caa22b859ae648e4eebd0d4215d9218',
    'eighteen': 'f90791403716434317481b7b962c00278235c25bc5c7efde42be242629304ca0',
    'two': '43c7cce0652694be13e9451feb2cb739da3ec9810d291a8c46830d35ba150ffe',
    'freefall': '92a78c154e7694834dc40a66ce852fbed32e4ea33a22b1b8ec911f09aebab189',
}
for name, lane in lanes.items():
    assert sha(lane / 'HANDOFF.actual.json') == expected_handoffs[name], name

versions, reads = {}, []
def add(name, target, source, expected=None):
    assert not Path(target).is_absolute() and '..' not in Path(target).parts
    assert source.is_file() and not source.is_symlink()
    raw = source.read_bytes()
    if expected:
        assert hash_bytes(raw) == expected.removeprefix('sha256:'), str(source)
    versions.setdefault(target, []).append((name, raw))
    reads.append({'candidate': name, 'target': target, **binding(source)})

code = load(lanes['code'] / 'CANDIDATE.actual.json')
assert len(code['files']) == 65
for row in code['files']:
    p = R / row['path']
    assert (sha(p) if p.exists() else None) == row['preimageSha256'], row['path']
    add('code', row['path'], lanes['code'] / row['candidatePath'], row['afterSha256'])
for row in load(lanes['volume'] / 'candidate-changed-files.actual.json'):
    add('volume', row['targetPath'], R / row['candidatePath'], row['sha256'])
for row in load(lanes['eighteen'] / 'candidate-landing-manifest.actual.json'):
    p = R / row['destination']
    original = row['original']
    assert (sha(p) if p.exists() else None) == (original['sha256'] if original else None)
    add('eighteen', row['destination'], R / row['candidate']['path'], row['candidate']['sha256'])
two = load(lanes['two'] / 'AUTHORING-OUTPUT-PATHS.actual.json')
for target in [PHYS, KIND]:
    add('two', target, lanes['two'] / 'workspace' / target)
for p in sorted((lanes['two'] / 'workspace' / two['packageBase']).rglob('*')):
    if p.is_file():
        add('two', str(p.relative_to(lanes['two'] / 'workspace')), p)
for row in load(lanes['freefall'] / 'CANDIDATE-FILES.actual.json')['files']:
    add('freefall', row['path'], lanes['freefall'] / row['source'], row['sha256'])

MISSING = object()
merge_log = []
def identity_list(value):
    if not isinstance(value, list):
        return None
    keys = []
    for x in value:
        if not isinstance(x, dict):
            return None
        if 'kind' in x:
            key = (x['kind'], x.get('goalId', x.get('id')))
        elif 'goalId' in x:
            key = ('goal', x['goalId'])
        elif 'id' in x:
            key = ('id', x['id'])
        else:
            return None
        if key[1] is None:
            return None
        keys.append(key)
    return keys if len(keys) == len(set(keys)) else None

def merge(base, current, proposed, path):
    if current == base:
        return copy.deepcopy(proposed)
    if proposed == base or proposed == current:
        return copy.deepcopy(current)
    if all(isinstance(x, dict) for x in [base, current, proposed]):
        out = {}
        for k in dict.fromkeys([*base, *current, *proposed]):
            b, c, p = (x.get(k, MISSING) for x in [base, current, proposed])
            if p is MISSING and c == b:
                continue
            if c is MISSING and p == b:
                continue
            if b is MISSING:
                assert c is MISSING or p is MISSING or c == p, (path, k, 'new-key conflict')
                out[k] = copy.deepcopy(p if c is MISSING else c)
            else:
                assert c is not MISSING and p is not MISSING, (path, k, 'delete/edit conflict')
                out[k] = merge(b, c, p, path + '/' + str(k))
        return out
    if all(isinstance(x, list) for x in [base, current, proposed]):
        keys = [identity_list(x) for x in [base, current, proposed]]
        if all(k is not None for k in keys):
            maps = [dict(zip(k, v)) for k, v in zip(keys, [base, current, proposed])]
            b, c, p = maps
            out = copy.deepcopy(c)
            for key in keys[0]:
                if key not in p:
                    assert key not in c or c[key] == b[key], (path, key, 'delete/edit conflict')
                    out.pop(key, None)
                elif key not in c:
                    assert p[key] == b[key], (path, key, 'edit/delete conflict')
                else:
                    out[key] = merge(b[key], c[key], p[key], path + '/' + repr(key))
            for key in keys[2]:
                if key not in b:
                    assert key not in c or c[key] == p[key], (path, key, 'new-item conflict')
                    out[key] = copy.deepcopy(p[key])
            order = [k for k in keys[1] if k in out] + [k for k in keys[2] if k not in c and k in out]
            assert len(order) == len(out)
            return [out[k] for k in order]
    raise AssertionError(('unresolved semantic merge conflict', path))

W.mkdir()
for target, variants in versions.items():
    original = R / target
    if len(variants) == 1:
        result = variants[0][1]
    else:
        assert original.exists(), ('multiple new-file owners', target)
        base = load(original)
        value = copy.deepcopy(base)
        for name, raw in variants:
            value = merge(base, value, json.loads(raw), target)
        result = dump(value)
        merge_log.append({'path': target, 'boundedInputNames': [v[0] for v in variants]})
    dest = W / target
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(result)

# Build the complete actual owner registry, preserving all other subjects.
registry = load(W / REG)
phys = next(s for s in registry['subjects'] if s['subject'] == 'physik')
paths = phys['positiveEvidenceConfigPaths']
owner_swaps = []
def replace_owner(old, new):
    assert paths.count(old) == 1, ('old owner must be unique', old, paths.count(old))
    i = paths.index(old)
    paths[i:i + 1] = new
    owner_swaps.append({'old': old, 'new': new})

vmap = load(lanes['volume'] / 'candidate-owner-registry-patch.actual.json')
vp = str((lanes['volume'] / 'candidate').relative_to(R)) + '/'
replace_owner(vmap['oldConfigPath'], [p.removeprefix(vp) for p in vmap['newConfigPaths']])
fmap = load(lanes['freefall'] / 'CANDIDATE-FILES.actual.json')
replace_owner(fmap['sourceCurrentOwnerConfig'], [fmap['files'][0]['path']])
tmap = load(lanes['two'] / 'workspace' / two['packageBase'] / 'P/ACTUAL-UNIQUE-OWNER-REPLACEMENTS.actual.json')
for owner in tmap['owners']:
    replace_owner(owner['actualPreviousOwnerConfig'], [owner['successorOwnerConfig']])
write_json(W / REG, registry)

# Read unchanged references from actual Root, never copied stale snapshots.
def actual_path(path):
    p = W / path
    return p if p.exists() else R / path
owners = {}
for config_path in paths:
    config = load(actual_path(config_path))
    records = [json.loads(line) for line in actual_path(config['reviewPath']).read_text().splitlines() if line.strip()]
    for goal_id in config['scope']['goalIds']:
        matching = [record for record in records if record['goalId'] == goal_id and record['reviewId'] == config['reviewId']]
        assert len(matching) == 1, (config_path, goal_id, len(matching))
        owners.setdefault(goal_id, []).append({'config': config_path, 'record': matching[0]})
assert len(owners) == 478 and all(len(v) == 1 for v in owners.values()), 'full unique478 owner scope'
baseline_registry = load(R / REG)
assert [s for s in registry['subjects'] if s['subject'] != 'physik'] == [s for s in baseline_registry['subjects'] if s['subject'] != 'physik']
before_goals = {g['id']: g for g in load(R / PHYS)['goals']}
after_goals = {g['id']: g for g in load(W / PHYS)['goals']}
assert len(before_goals) == len(after_goals) == 764 and before_goals.keys() == after_goals.keys()
math_ids = {g['id'] for g in load(R / MATH)['goals']}
pairs = [(gid, pre) for gid, g in after_goals.items() for pre in g.get('requires', []) if pre in math_ids]
assert len(pairs) == 72, len(pairs)
changed_goals = [gid for gid in before_goals if before_goals[gid] != after_goals[gid]]
assert len(changed_goals) == 20, changed_goals
assert after_goals['f827b00f-af7f-52de-84aa-2a2bbaa035bd']['requires'] == ['5c44b9ba-9b05-4774-95d5-073230d3fc4f', '7c978529-ce62-5adc-897f-24ea80babbc8']

rows = []
for dest in sorted(p for p in W.rglob('*') if p.is_file()):
    target = str(dest.relative_to(W))
    orig = R / target
    if orig.exists() and orig.read_bytes() == dest.read_bytes():
        continue
    rows.append({'target': target, 'preimage': binding(orig) if orig.exists() else None, 'candidate': binding(dest)})
write_json(O / 'CANDIDATE.actual.json', {
    'contract': 'private-current-physics-next-joint-composition-v1',
    'status': 'PRIVATE_COMPOSITION_ONLY_INDEPENDENT_PEERS_AND_FRESH_NATIVE_D_AND_AGGREGATE_GATES_PENDING',
    'createdUTC': datetime.now(timezone.utc).isoformat(),
    'scope': 'canonical Gymnasium Math807 Physics478 only',
    'changedPhysicsGoals': changed_goals,
    'candidateForeignPairs': len(pairs), 'activeRootForeignPairs': 45,
    'actualPhysicsPOwners': 478, 'ownerSwaps': owner_swaps,
    'MathChanges': 0, 'activeSupplements': 0, 'rootAdopted': False,
    'wholeSourceOrTargetOrRuntimeOrM7OrHumanAcceptance': False,
    'nativeDChangedContextsRequireFreshEvidence': True,
    'mergedPaths': merge_log, 'files': rows,
})
write_json(O / 'input-read-bindings.actual.json', reads)
assert sha(R / '.git/index') == '6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8'
assert sha(R / PHYS) == '38dcc3a7e4f910e6d7c8129d14d88cc198534f2bf7d449fc05ef5d5d7f97e637'
print(json.dumps({'candidateFiles': len(rows), 'changedPhysicsGoals': len(changed_goals), 'candidatePairs': len(pairs), 'actualPhysicsOwners': len(owners), 'rootAdopted': False}))
