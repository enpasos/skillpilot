// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict'
import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { resolve } from 'node:path'
import { loadRegisteredCurrentPositiveEvidenceOwners } from './execution-root/app/scripts/currentPositiveEvidenceOwners.ts'
import { normalizeCanonicalLandscape } from '../../../app/src/utils/authoring/canonicalAuthoring.ts'
import { normalizeCompositionView, collectCompositionProjectionRoleGoalIds, compileCompositionView } from '../../../app/src/utils/authoring/compositionViewAuthoring.ts'
import { buildCrossLandscapeGraph } from '../../../app/scripts/lib/crossLandscapeGraph.ts'

const R = '/home/enpasos/projects/skillpilot'
const O = resolve(import.meta.dirname)
const E = resolve(O, 'execution-root')
const V = resolve(O, 'candidate-v2')
const json = (p: string) => JSON.parse(readFileSync(p, 'utf8'))
const hash = (p: string) => createHash('sha256').update(readFileSync(p)).digest('hex')
const read = (rel: string) => json(existsSync(`${V}/${rel}`) ? `${V}/${rel}` : `${R}/${rel}`)
const reg = read('curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json')
const summaries: unknown[] = []
const landscapes = []
for (const subject of reg.subjects.filter((s: any) => ['mathematik', 'physik'].includes(s.subject))) {
  const landscape = json(`${E}/${subject.landscapePath}`)
  const kinds = json(`${E}/${subject.semanticKindLedgerPath}`)
  const atomicGoalIds = new Set<string>(kinds.decisions.filter((d: any) => d.semanticKind === 'curricularAtomic' && d.decisionStatus === 'authoritative').map((d: any) => d.goalId))
  const expected = subject.subject === 'mathematik' ? 807 : 478
  assert.equal(atomicGoalIds.size, expected)
  const actual = loadRegisteredCurrentPositiveEvidenceOwners({
    landscapeId: landscape.landscapeId, landscapePath: subject.landscapePath,
    semanticKindLedgerPath: subject.semanticKindLedgerPath, atomicGoalIds,
  })
  summaries.push({ subject: subject.subject, expectedGoals: expected,
    normalValidCurrentOwners: actual.owners.size, normalReady: actual.ready.size,
    issues: actual.issues })
  // Persist the actual full normal errors before failing; scope counts alone are insufficient.
  writeFileSync(`${O}/normal-current-owners.actual.json`, JSON.stringify(summaries, null, 2) + '\n')
  assert.deepEqual(actual.issues, [])
  assert.equal(actual.owners.size, expected)
  assert.deepEqual([...actual.ready].sort(), [...atomicGoalIds].sort())
  for (const [id, owner] of actual.owners) {
    assert(!owner.configPath.startsWith('tmp/'))
    assert(!owner.config.landscapePath.startsWith('tmp/'))
    assert(!owner.config.semanticKindLedgerPath.startsWith('tmp/'))
    assert(!owner.config.reviewPath.startsWith('tmp/'))
    assert.equal(owner.record.goalId, id)
  }
  landscapes.push(landscape)
}
const [math, phys] = landscapes
const mn = normalizeCanonicalLandscape(math), pn = normalizeCanonicalLandscape(phys)
const allBy = new Map([...mn.goals, ...pn.goals].map(g => [g.id, g]))
const roots = new Map([mn, pn].map(l => [l.landscapeId, l.goals.find(g => g.tags?.includes('root'))!.id]))
const ls = new Map([mn, pn].map(l => [l.landscapeId, l]))
const union = { landscapeId: 'joint', title: 'joint', goals: [...mn.goals, ...pn.goals] }
const priorMn = normalizeCanonicalLandscape(json(`${R}/curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json`))
const priorPn = normalizeCanonicalLandscape(json(`${R}/curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json`))
const priorAll = new Map([...priorMn.goals, ...priorPn.goals].map(g => [g.id, g]))
const views = []
const missingSupports: unknown[] = []
for (const filename of readdirSync(`${R}/curricula/DE/Gymnasium/composition-views/physik`).filter(f => f.endsWith('.view.json')).sort()) {
  const rel = `curricula/DE/Gymnasium/composition-views/physik/${filename}`
  const before = normalizeCompositionView(json(`${R}/${rel}`))
  const after = normalizeCompositionView(read(rel))
  assert.deepEqual(after.scope, before.scope)
  const prior = collectCompositionProjectionRoleGoalIds(before.rootNodes, priorAll, roots)
  const current = collectCompositionProjectionRoleGoalIds(after.rootNodes, allBy, roots)
  assert.deepEqual([...current.targetGoalIds].sort(), [...prior.targetGoalIds].sort(), after.viewId)
  const compiled = compileCompositionView(after, pn, union, ls)
  const errors = compiled.findings.filter((f: any) => f.severity === 'error')
  assert.deepEqual(errors, [], after.viewId)
  for (const id of current.targetGoalIds) {
    const goal = allBy.get(id)
    for (const required of goal?.requires ?? []) {
      if (mn.goals.some(g => g.id === required) && !current.prerequisiteOnlyGoalIds.has(required) && !current.targetGoalIds.has(required)) {
        missingSupports.push({ viewId: after.viewId, goalId: id, required })
      }
    }
  }
  views.push({ viewId: after.viewId, targetGoals: current.targetGoalIds.size,
    prerequisiteOnly: current.prerequisiteOnlyGoalIds.size, compilerErrors: errors })
}
writeFileSync(`${O}/joint-view-compiler.actual.json`, JSON.stringify({ views, missingSupports }, null, 2) + '\n')
assert.equal(views.length, 69)
assert.deepEqual(missingSupports, [])
const graph = buildCrossLandscapeGraph(landscapes.map(l => ({ landscapeId: l.landscapeId, file: l.title, goals: l.goals })))
assert.deepEqual(graph.diagnostics, [])
assert.equal(graph.nodes.size, 2018)
const code = json(`${R}/tmp/cross-subject-requires/merge-current-p-guard-and-native-transport-author-20261015-v1/CANDIDATE.actual.json`)
for (const row of code.files) assert.equal(hash(`${E}/${row.path}`), row.afterSha256, row.path)
assert.equal(hash(`${R}/.git/index`), '6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8')
writeFileSync(`${O}/joint-bounded-validation.actual.json`, JSON.stringify({
  status: 'NORMAL_CURRENT_OWNER_AND_JOINT_COMPOSITION_CHECKS_PASS',
  completedUTC: new Date().toISOString(), normalCurrentOwners: summaries,
  completePhysicsViews: views.length, targetSetsAndScopesUnchanged: true,
  missingDirectMathSupports: missingSupports.length, mergedCodeFilesExact: code.files.length,
  globalNodes: graph.nodes.size, graphDiagnostics: graph.diagnostics,
  currentMathOrdinaryGoals: 807, currentPhysicsOrdinaryGoals: 478,
  candidateForeignPairs: 72, RootAdopted: false,
  descriptionResolutionsOrFullM7OrRuntimeOrSourceOrHumanAcceptance: false,
}, null, 2) + '\n')
console.log(JSON.stringify({ validCurrentMathOwners: 807, validCurrentPhysicsOwners: 478,
  views: views.length, unchangedTargets: true, missingDirectMathSupports: 0,
  nodes: graph.nodes.size, mergedCodeFilesExact: code.files.length, RootAdopted: false }))
