"""Seal actual joint data/code evidence without claiming adoption or D completion.

SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
T = R / 'tmp/cross-subject-requires'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def bind(p):
    return {'path': str(p.relative_to(R)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
def save(p, data):
    assert p.is_relative_to(O) and not p.exists(), str(p)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    json.loads(p.read_text())
assert sha(O / 'CANDIDATE.v2.actual.json') == 'a840b2a1fec3027f74c1bcd9487b3d40b79f0a7437e187da33beb3bfc1b6a014'
result = json.loads((O / 'joint-bounded-validation.actual.json').read_text())
assert result['completePhysicsViews'] == 69 and result['missingDirectMathSupports'] == 0
assert [x['normalValidCurrentOwners'] for x in result['normalCurrentOwners']] == [807, 478]
assert result['globalNodes'] == 2018 and result['graphDiagnostics'] == []
checks = {
    'codeAndVolumePeer': ('merged-guard-transport-and-volume-independent-peer-20261015-v1', '270b82c3826b521428c1dbe5fee1f8e5cd8b8577ea2ff4b8a4a263a37c509853'),
    'eighteenPeer': ('gymnasium-i02-i05-eighteen-current-independent-peer-20261015-v1', '3550a4f7a05ad945a37226afa9e3fffe230fe7714634e3a67c9bada5851cd2fa'),
    'oscillatorInductionPeer': ('oscillator-induction-successors-independent-peer-20261015-v1', 'a8e36db7c3a023922697d66407f9a923f280e038df3f33328c60d615fed5df49'),
}
prior = json.loads((R / 'curricula/quality/cross-subject-requires/2026-10-13/work-checkpoint.json').read_text())
old_peer = prior['currentBoundedFollowups20261015']['freeFallPlanning']['peer']
checks['freeFallPeer'] = ('free-fall-current-p-planning-gap-independent-peer-20261015-v1', old_peer['sha256'].removeprefix('sha256:'))
peers = {}
for name, (lane, expected) in checks.items():
    p = T / lane / 'HANDOFF.actual.json'
    assert sha(p) == expected, (name, sha(p), expected)
    peers[name] = {'handoff': bind(p), 'seal': bind(p.with_name('SEAL.actual.json'))}
science = json.loads((T / 'canonical-gymnasium-effective-review-index-20261015-v21/actual-read-bindings.json').read_text())
assert len(science) == 737
for row in science:
    p = R / row['path']
    assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256'].removeprefix('sha256:'), str(p)
assert sha(R / '.git/index') == '6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8'
save(O / 'REVIEW-INPUTS.actual.json', {
    'contract': 'private-joint-22-actual-P-owner-integration-review-inputs-v1',
    'scope': 'canonical Gymnasium Math807 Physics478 only',
    'actualCandidate': bind(O / 'CANDIDATE.v2.actual.json'),
    'normalRegisteredOwnerAndCompilerChecks': bind(O / 'joint-bounded-validation.actual.json'),
    'ordinaryCommandReceipt': bind(O / 'joint-validation.execution.actual.json'),
    'ownOriginalUnportableCandidate': bind(O / 'CANDIDATE.actual.json'),
    'pathOnlyRepair': bind(O / 'portable-v2-four-path-field-repair.actual.json'),
    'independentPeerEvidence': peers,
    'currentRootScienceBindingsAll737Reverified': True,
    'pending': ['Fresh native D A/B and synthesis for21 changed contexts through regular20+1 groups',
        'Register bounded d18 A/M and genuinely new Science contexts without rewriting historical conditions',
        'Final joint D/P/A/M/V, protected floors and necessary integration tests',
        'Current candidate72 native route census and remaining source/selected-teaching-route or authorized supplement coverage'],
    'RootAdopted': False, 'newMathGoals': 0, 'newActiveSupplements': 0,
    'HumanSourceTargetLearnerOrM7AcceptanceClaimed': False,
})
save(O / 'HANDOFF.actual.json', {
    'status': 'SEALED_PRIVATE_JOINT_CODE_AND_22_OWNER_DATA_CANDIDATE_NORMAL_CURRENT_P_AND_COMPOSITION_PASS',
    'completedUTC': datetime.now(timezone.utc).isoformat(),
    'candidate': bind(O / 'CANDIDATE.v2.actual.json'),
    'candidateFiles': 228, 'acceptedMergedCodeFiles': 65,
    'changedWholePhysicsGoals': 20, 'changedActualPhysicsPOwners': 22,
    'candidateForeignPairs': 72, 'activeRootForeignPairs': 45,
    'normalValidMathPOwners': 807, 'normalValidPhysicsPOwners': 478,
    'physicsViewCompilers': 69, 'allTargetsAndScopesUnchanged': True,
    'missingDirectMathSupports': 0, 'jointGraphNodes': 2018, 'graphDiagnostics': 0,
    'sourceBindings737Unchanged': True,
    'portableRepair': 'Exact2 f827 configs/4 path metadata fields; actual whole P raw bytes, reviewId, reason and opinions unchanged. Original bad private paths remain as historical failed integration.',
    'independentPeers': peers, 'reviewInputs': bind(O / 'REVIEW-INPUTS.actual.json'),
    'freshNativeD': '21 changed contexts, owning native limit20 requires two normal20+1 groups, each real A/B; input author is active and results not yet supplied.',
    'f827NativeD': 'Exact existing genuine per-goal context reused; current Root807 check already passes. No new D or import of13 Math helpers claimed.',
    'pending': 'Final native D, actual A/M/Science-context ledger integration, full current quality/floors and runtime/source/teaching routes; Goal remains incomplete.',
    'rootAdopted': False, 'rootIndexChanged': False, 'MathGoalsAdded': 0,
    'activeSupplementsAdded': 0, 'humanApprovalOrFormalWholeSourceOrHostAcceptance': False,
})
owned, retained = [], []
for p in sorted(O.rglob('*')):
    if not p.is_file() or p.is_symlink():
        continue
    rel = p.relative_to(O)
    row = {'path': str(rel), 'bytes': p.stat().st_size, 'sha256': sha(p)}
    if rel.parts[0] in ['candidate', 'execution-root']:
        retained.append(row)
    else:
        owned.append(row)
save(O / 'RETAINED-EXECUTION-AND-FIRST-ATTEMPT.actual.json', {
    'status': 'PRIVATE_EXECUTION_CACHE_AND_SUPERSEDED_ATTEMPT_ONLY_NOT_CURRICULUM_ADOPTION', 'files': retained})
p = O / 'RETAINED-EXECUTION-AND-FIRST-ATTEMPT.actual.json'
owned.append({'path': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p)})
save(O / 'SEAL.actual.json', {'status': 'FROZEN_OWN_CANDIDATE_AND_REVIEW_EVIDENCE_ONLY',
    'files': owned, 'fileCount': len(owned), 'retainedPrivateFiles': len(retained),
    'candidateV2Sha256': sha(O / 'CANDIDATE.v2.actual.json'),
    'noRootAdoption': True})
print(json.dumps({'handoff': bind(O / 'HANDOFF.actual.json'), 'seal': bind(O / 'SEAL.actual.json'),
                  'ownFiles': len(owned), 'retainedFiles': len(retained)}))
