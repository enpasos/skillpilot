"""Run the real private-candidate owner and composition checks once.

SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess

O = Path(__file__).resolve().parent
R = Path('/home/enpasos/projects/skillpilot')
args = [str(R / 'tmp/ci-tools/node-v20.20.2-linux-x64/bin/node'),
        str(R / 'app/node_modules/tsx/dist/cli.mjs'), 'validate-joint.mts']
out, err, receipt = (O / n for n in ['joint-validation.stdout.txt', 'joint-validation.stderr.txt', 'joint-validation.execution.actual.json'])
assert not any(p.exists() for p in [out, err, receipt])
started = datetime.now(timezone.utc).isoformat()
with out.open('wb') as stdout, err.open('wb') as stderr:
    result = subprocess.run(args, cwd=O, stdout=stdout, stderr=stderr)
receipt.write_text(json.dumps({'argv': args, 'cwd': str(O), 'startedUTC': started,
    'completedUTC': datetime.now(timezone.utc).isoformat(), 'exitCode': result.returncode,
    'OSRootRO': True, 'normalRegisteredCurrentOwnerFunctionUnmodified': True,
    'scope': 'full807 Math and478 Physics P ownership; all69 Physics view compilers and2018-node graph; not D/fullM7'}, indent=2) + '\n')
print(out.read_text())
print(err.read_text())
raise SystemExit(result.returncode)
