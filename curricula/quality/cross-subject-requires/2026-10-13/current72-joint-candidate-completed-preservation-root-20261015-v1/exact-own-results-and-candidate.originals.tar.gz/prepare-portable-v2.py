"""Repair only publication paths, then materialize real current-owner inputs.

SPDX-License-Identifier: Apache-2.0
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil

R = Path('/home/enpasos/projects/skillpilot')
O = Path(__file__).resolve().parent
A, V, E = (O / name for name in ['candidate', 'candidate-v2', 'execution-root'])
REG = 'curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def bind(p):
    return {'path': str(p.relative_to(R)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
def save(p, d):
    assert p.is_relative_to(O)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n')
    load(p)
assert Path.cwd().resolve() == O and not V.exists() and not E.exists()
assert (O / 'root-readonly-selfcheck.actual.json').is_file()
shutil.copytree(A, V)
prefix = 'tmp/cross-subject-requires/he-g9-volume-first-actual-preparation-author-20261015-v1/candidate/'
pkg = 'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/f827-existing-volume-current-context-v1/P'
changes = []
for path in sorted((V / pkg).glob('*.config.json')):
    before = load(path)
    after = dict(before)
    fields = []
    for key in ['landscapePath', 'semanticKindLedgerPath', 'reviewPath']:
        if after[key].startswith(prefix):
            after[key] = after[key].removeprefix(prefix)
            fields.append(key)
    assert fields
    save(path, after)
    changes.append({'path': str(path.relative_to(V)), 'fields': fields,
                    'before': bind(A / path.relative_to(V)), 'after': bind(path)})
assert [(Path(c['path']).name, c['fields']) for c in changes] == [
    ('f827.current.config.json', ['landscapePath', 'semanticKindLedgerPath', 'reviewPath']),
    ('retained-owner-082-without-f827.config.json', ['reviewPath'])]
for path in A.rglob('*'):
    if path.is_file() and not path.name.endswith('.config.json'):
        assert path.read_bytes() == (V / path.relative_to(A)).read_bytes()
save(O / 'portable-v2-four-path-field-repair.actual.json', {
    'status': 'BOUNDED_PATH_ONLY_REPAIR_INDEPENDENT_PEER_PENDING',
    'createdUTC': datetime.now(timezone.utc).isoformat(),
    'exactOriginalCandidatePreserved': True,
    'PReviewRecordBodyReviewIdReasonAndAllOpinionsChanged': False,
    'rootRegistryChanged': False, 'changes': changes})

# This is a private execution capsule, never a proposed curriculum archive.
shutil.copytree(V, E)
source_scripts = R / 'tmp/cross-subject-requires/merge-current-p-guard-and-native-transport-author-20261015-v1/workspace/app/scripts'
shutil.copytree(source_scripts, E / 'app/scripts', dirs_exist_ok=True, symlinks=True)
for rel in ['app/src', 'app/node_modules']:
    dest = E / rel
    assert not dest.exists()
    dest.symlink_to(R / rel, target_is_directory=True)
(E / 'app/public/assets').mkdir(parents=True, exist_ok=True)
(E / 'app/public/assets/goal-visualizations').symlink_to(R / 'app/public/assets/goal-visualizations', target_is_directory=True)
for rel in ['app/tsconfig.json', 'app/tsconfig.node.json']:
    source = R / rel
    if source.exists():
        shutil.copyfile(source, E / rel)
shutil.copytree(R / 'contracts/goal-evidence', E / 'contracts/goal-evidence', dirs_exist_ok=True)
copied = []
def materialize(rel):
    assert not Path(rel).is_absolute() and '..' not in Path(rel).parts, rel
    target = E / rel
    if not target.exists():
        source = V / rel if (V / rel).exists() else R / rel
        assert source.is_file(), rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        copied.append(bind(source))
    return target

materialize('curricula/DE/Gymnasium/quality/deep-understanding-rollout/deep-understanding-rollout.schema.json')
registry = load(E / REG)
subjects = [s for s in registry['subjects'] if s['subject'] in ['mathematik', 'physik']]
for subject in subjects:
    landscape = load(materialize(subject['landscapePath']))
    materialize(subject['semanticKindLedgerPath'])
    for config_path in subject['positiveEvidenceConfigPaths']:
        cfg = load(materialize(config_path))
        for key in ['landscapePath', 'semanticKindLedgerPath', 'reviewCriteriaPath', 'reviewPath']:
            materialize(cfg[key])
        for manifest in cfg.get('reviewRunManifestPaths', []):
            materialize(manifest)
    for goal in landscape['goals']:
        for link in goal.get('resourceLinks', []):
            if link.get('type') == 'task-material':
                materialize('app/public' + link['url'])
                tail = link['url'].removeprefix('/assets/task-material/')
                materialize('curricula/DE/Gymnasium/task-material/' + tail)
for row in load(O / 'CANDIDATE.actual.json')['files']:
    rel = row['target']
    if rel in [c['path'] for c in changes]:
        continue
    assert sha(E / rel) == sha(V / rel), rel
save(O / 'execution-root-dependencies.actual.json', {
    'status': 'PRIVATE_CAPSULE_ONLY_NOT_ADOPTION_INPUTS', 'copiedSourceBindings': copied,
    'scriptsReadFromAcceptedExactMergedCode': str(source_scripts.relative_to(R)),
    'readOnlyDependencyLinks': ['app/src', 'app/node_modules', 'app/public/assets/goal-visualizations'],
    'ownPhysicalTaskSourceAndPublicFiles': True,
    'mathNewGoals': 0, 'RootWritten': False})
rows = []
for path in sorted(p for p in V.rglob('*') if p.is_file()):
    rel = str(path.relative_to(V)); original = R / rel
    if original.exists() and sha(original) == sha(path):
        continue
    rows.append({'target': rel, 'preimage': bind(original) if original.exists() else None, 'candidate': bind(path)})
save(O / 'CANDIDATE.v2.actual.json', {
    'contract': 'private-current-physics-next-joint-composition-v2',
    'status': 'PRIVATE_PORTABLE_PATH_REPAIR_CURRENT_OWNER_VALIDATION_AND_PEERS_AND_FRESH_D_PENDING',
    'createdUTC': datetime.now(timezone.utc).isoformat(),
    'scope': 'canonical Gymnasium only; full Math807 Physics478 preserved',
    'candidateForeignPairs': 72, 'activeRootForeignPairs': 45,
    'rootAdopted': False, 'portablePathChanges': changes, 'files': rows})
assert sha(R / '.git/index') == '6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8'
print(json.dumps({'candidateFiles': len(rows), 'configFilesChanged': len(changes), 'pathFieldsChanged': 4, 'capsuleDependencies': len(copied), 'rootAdopted': False}))
