# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,os,sys,shutil
R=Path('/home/enpasos/projects/skillpilot');O=Path(__file__).resolve().parent;B=R/'tmp/cross-subject-requires/caf-documented-image-correction-candidate-20261013-v1/attempt-02';N=O/'isolated-native-root'
def sha(p):return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def rel(p):return str(p.relative_to(R))
def bind(p):return {'path':rel(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def load(p):return json.loads(p.read_bytes())
def write(name,obj):p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=True,indent=2)+'\n')
if len(sys.argv)>1 and sys.argv[1]=='recheck':
 snap=load(O/'input-snapshot.before.json');seal=load(O/'own-seal.original.json');checks=[{'path':e['path'],'matches':bind(R/e['path'])==e}for e in snap['files']];own=[{'path':e['path'],'matches':bind(R/e['path'])==e}for e in seal['files']];report={'checkedAt':datetime.now(timezone.utc).isoformat(),'allInputsUnchanged':all(x['matches']for x in checks),'allOriginalOutputsUnchanged':all(x['matches']for x in own),'ownSealSha256':sha(O/'own-seal.original.json'),'newPNGe787VKeptAsAICandidate':True,'humanApproval':False,'checks':checks,'ownChecks':own};write('end-recheck.actual.json',report);print(json.dumps({k:v for k,v in report.items()if k not in ['checks','ownChecks']}));sys.exit(0 if report['allInputsUnchanged']and report['allOriginalOutputsUnchanged']else 1)
receipt=load(B/'generation-and-isolated-import.actual.json');sources=set()
for e in [receipt['prompt'],receipt['editTarget'],receipt['originalActiveAssetRetained'],receipt['generatedArtifact'],receipt['isolatedCandidateLandscape']]:
 p=R/e['path'];assert bind(p)==e;sources.add(p)
assert receipt['generatedArtifact']['sha256']=='sha256:e787f8afc98297599d0924851d7a255aa4081dbc1b0955ac98ca8c4fd835075b'
S=B/'isolated-import-root';modules=['app/scripts/positiveGoalEvidenceReview.ts','app/scripts/positiveGoalEvidenceProfileModel.ts','app/scripts/goalEvidenceProfileModel.ts'];schemas=['contracts/goal-evidence/v1/goal-evidence-ai-run-manifest.schema.json','contracts/goal-evidence/v2/goal-evidence-profile.schema.json','contracts/goal-evidence/v2/goal-evidence-review-config.schema.json'];criteria='curricula/DE/Gymnasium/quality/goal-evidence/prompts/mathematik-positive-understanding-evidence-profile-criteria-v2.md';land='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json';png='/assets/goal-visualizations/mathematik/cafd6520-c4af-4109-9863-cc49ba6fad4d/cafd6520-c4af-4109-9863-cc49ba6fad4d.png'
copied=[]
for name in [*modules,*schemas,criteria,land,'app/public'+png,'curricula/DE/Gymnasium/visualizations/mathematik/cafd6520-c4af-4109-9863-cc49ba6fad4d/cafd6520-c4af-4109-9863-cc49ba6fad4d.png']:
 src=S/name;dest=N/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);assert sha(src)==sha(dest);sources.add(src);copied.append({'source':bind(src),'exactCopy':bind(dest)})
(N/'app/node_modules').symlink_to(os.path.relpath(R/'app/node_modules',N/'app'),target_is_directory=True)
sources.add(B/'generation-and-isolated-import.actual.json');sources.add(B/'edit-prompt.actual.txt');sources.add(R/'tmp/cross-subject-requires/caf-documented-image-correction-candidate-20261013-v1/native-P-validator.isolated-toolkit.bindings.json')
prior=R/'tmp/cross-subject-requires/caf-documented-image-correction-informed-quality-review-20261013-v1'
sources.add(prior/'own-seal.original.json')
for e in load(prior/'own-seal.original.json')['files']:sources.add(R/e['path'])
five=R/'tmp/cross-subject-requires/five-successor-native-quality-informed-review-20261013-v1'
for p in [five/'own-seal.original.json',five/'content-review.actual.json',five/'native/mathematik/P.review.jsonl',five/'native/mathematik/semantic-kinds.reviewed-current.json',five/'additive-native-cli-acceptance-v1/own-seal.json']:
 sources.add(p)
for e in load(five/'own-seal.original.json')['files']:sources.add(R/e['path'])
sources.add(R/'tmp/cross-subject-requires/five-successor-native-quality-reader-20261013-v1/whole-five-goals-P-kind-A-M-V.inputs.json')
for name in ['app/scripts/semanticAtomicityReview.ts','app/scripts/memoryCardReview.ts','app/scripts/goalEvidenceProfileModel.ts','app/scripts/positiveGoalEvidenceProfileModel.ts','app/scripts/goalBookModel.ts','app/scripts/checkGoalVisualizationQaApprovalCoverage.ts','app/scripts/lib/crossSubjectRequiresInventory.ts','contracts/curriculum-package/v1/profiles/de-gymnasium-mathematik-v1.profile.json']:sources.add(R/name)
write('input-snapshot.before.json',{'schemaVersion':1,'capturedAt':datetime.now(timezone.utc).isoformat(),'files':[bind(p)for p in sorted(sources)],'allThreeToolkitModulesAndThreeSchemasCopiedByteExact':True,'copyBindings':copied,'technicalDependencySymlink':{'path':rel(N/'app/node_modules'),'relativeTarget':os.readlink(N/'app/node_modules'),'purpose':'Technical execution aid only, no validator modification or artifact-publication claim'}})
node=R/'tmp/toolchains/node-v22.22.0-linux-x64/bin/node';tsx=R/'app/node_modules/tsx/dist/cli.mjs';commands=[]
def run(label,args):
 started=datetime.now(timezone.utc).isoformat();p=subprocess.run(args,cwd=R,capture_output=True,text=True);(O/'commands').mkdir(exist_ok=True);(O/'commands'/f'{label}.stdout.txt').write_text(p.stdout);(O/'commands'/f'{label}.stderr.txt').write_text(p.stderr);e={'argv':args,'startedAt':started,'completedAt':datetime.now(timezone.utc).isoformat(),'exitCode':p.returncode,'stdoutPath':rel(O/'commands'/f'{label}.stdout.txt'),'stderrPath':rel(O/'commands'/f'{label}.stderr.txt')};write(f'commands/{label}.execution.json',e);commands.append(e);returnp=p.returncode;return returnp
assert run('01-fresh-native-context',[str(node),str(tsx),str(O/'native-new-CAF-review.ts')])==0
assert run('02-native-A',[str(node),str(tsx),str(R/'app/scripts/semanticAtomicityReview.ts'),'--config='+rel(O/'native-A.config.json'),'--mode=check'])==0
assert run('03-native-M',[str(node),str(tsx),str(R/'app/scripts/memoryCardReview.ts'),'--config='+rel(O/'native-M.config.json'),'--mode=check'])==0
ctx=load(O/'native-new-CAF-resource-context.actual.json');assert ctx['resourceContextChanged']and not ctx['nativePErrors']and ctx['nativeVApproval']
preservation=[{'path':e['path'],'matches':bind(R/e['path'])==e}for e in load(O/'input-snapshot.before.json')['files']];assert all(x['matches']for x in preservation)
write('review-completion.actual.json',{'schemaVersion':1,'completedAt':datetime.now(timezone.utc).isoformat(),'freshInformedCAFReviewCompleted':True,'realPResourceFingerprintChanged':True,'newPNGResourceDigest':ctx['newActualResourceDigest'],'newPInputFingerprint':ctx['newPInputFingerprint'],'nativePAMChecksPass':all(x['exitCode']==0 for x in commands),'VnewPNGKeptAsAICandidate':True,'actualOriginalImageDimensions':[1678,937],'nativeKindCurrentSingleGoalClassification':True,'originalFiveAndOldJPGUnchanged':True,'humanApprovalCreated':False,'newDOrGlobalM7Granted':False,'boundedCAFGoalQualityPass':True,'sourceRouteCIM7Accepted':False,'commands':commands,'inputPreservation':preservation})
owned=[p for p in sorted(O.rglob('*'))if p.is_file()and p.name not in ['own-seal.original.json','end-recheck.actual.json']];write('own-seal.original.json',{'schemaVersion':1,'sealedAt':datetime.now(timezone.utc).isoformat(),'files':[bind(p)for p in owned],'selfExcluded':True,'singleGoalFreshInformedReview':True,'newPNGe787VKeptAsAICandidate':True,'humanApproval':False});print(json.dumps({'nativePAMChecksPass':True,'newPInputFingerprint':ctx['newPInputFingerprint'],'VnewPNGKeptAsAICandidate':True,'ownSealSha256':sha(O/'own-seal.original.json'),'originalFiveAndOldJPGUnchanged':True}))
