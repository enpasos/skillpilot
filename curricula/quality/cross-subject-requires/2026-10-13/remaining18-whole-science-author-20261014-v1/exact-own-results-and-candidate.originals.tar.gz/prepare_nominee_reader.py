#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import json
from refresh_inputs import B,R,bind,dump
def collect_ids(v,out):
 if isinstance(v,dict):
  if isinstance(v.get('id'),str):out.setdefault(v['id'],[]).append(v)
  for x in v.values():collect_ids(x,out)
 elif isinstance(v,list):
  for x in v:collect_ids(x,out)
def contains(v,gid):
 if isinstance(v,dict):return any(contains(x,gid) for x in v.values())
 if isinstance(v,list):return any(contains(x,gid) for x in v)
 return v==gid
pool=json.loads((B/'currentGoalPositivePool.private.json').read_text())
inv=json.loads((R/'curricula/quality/cross-subject-requires/math-physics.inventory.json').read_text())
ledger=json.loads((B/'native-proposal.bound.inert.json').read_text())
ids=sorted({i for d in ledger['decisions'] for i in d['prerequisiteGoalIds']} | {i for i in pool['goals'] if i.startswith(('f870','346efb','715655','80c232'))})
records=[]
for gid in ids:
 o=pool['occurrences'][gid];files=inv['sourceBindingFileSets'][o['scope']['sourceBindingFilesRef']]
 choices=[p for p in files if 'source_extraction' in p and ('DE-BY' in p or 'DE-HE' in p or ('DE-BW' in p and gid.startswith('c63')))]
 # Read the current exact mapping rows and substantive source paragraphs from
 # explicit direct source owners. Broader locator inventory is not approval.
 selected=[]
 for p in choices[:2]:
  doc=json.loads((R/p).read_text());rows=[x for x in doc.get('decisions',[]) if contains(x,gid)]
  ep=doc.get('sourceExtractionPath');byid={}
  if ep:collect_ids(json.loads((R/ep).read_text()),byid)
  goalrows=[]; passages={}
  for row in rows:
   sid=row.get('sourceGoalId');matches=byid.get(sid,[])
   if matches:
    sg=matches[0];goalrows.append(sg)
    if sg.get('passageId') in byid:passages[sg['passageId']]=byid[sg['passageId']][0]
  selected.append({'mappingFile':bind(p),'wholeMappingRows':rows,'sourceFile':bind(ep) if ep else None,'wholeSourceGoals':goalrows,'wholePassages':list(passages.values()),'wholeSourceReadApprovalCreated':False})
 records.append({'goalId':gid,'wholeGoal':pool['goals'][gid],'wholePositiveProfile':pool['profiles'][gid],'positiveOwner':pool['owners'][gid],'nativeOccurrence':o,'explicitCurrentSourceSelection':selected,'allLocatorFiles':files,'sourceCoverageNotApproved':True})
dump('nominee-whole-reader.current.inert.json',{'records':records,'count':len(records),'noIndependentOrNativeApproval':True})
print('Whole nominee and relevant inherited bodies',len(records))
