#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Private refresh: reads current sources; writes only this new dossier."""
import datetime, hashlib, json
from pathlib import Path
B=Path(__file__).resolve().parent
R=Path('/home/enpasos/projects/skillpilot')
OLD=R/'tmp/cross-subject-requires/physics-unresolved97-whole-body-successor-author-20261013-v1'
INDEX='tmp/cross-subject-requires/canonical-gymnasium-effective-review-index-20261014-v3/effective-goal-index.json'
CONFIG='curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
INV='curricula/quality/cross-subject-requires/math-physics.inventory.json'
def read(p):return json.loads((R/p).read_text())
def bind(p):
 p=Path(p);p=p if p.is_absolute() else R/p
 raw=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(raw),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()}
def dump(p,d):
 p=B/p;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():raise RuntimeError('Refuse overwrite '+str(p))
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def main():
 index=read(INDEX); selected=[r for r in index['records'] if r['selectedRecord']['requiresDecision'] in ['review_required','scope_gap']]
 assert len(selected)==18
 assert sum(r['selectedRecord']['requiresDecision']=='review_required' for r in selected)==11
 assert sum(r['selectedRecord']['requiresDecision']=='scope_gap' for r in selected)==7
 cfg=read(CONFIG); profiles={};goals={}; owners={};sourcebinds={}
 for s in cfg['subjects']:
  if s['subject'] not in ['mathematik','physik']:continue
  landscape=read(s['landscapePath'])
  for g in landscape['goals']:goals[g['id']]=g
  for cp in s['positiveEvidenceConfigPaths']:
   pc=read(cp);rp=pc['reviewPath'];lines=(R/rp).read_text().splitlines()
   for n,l in enumerate(lines,1):
    r=json.loads(l);gid=r['goalId']
    if gid not in pc['scope'].get('goalIds',[]):continue
    if gid in profiles:raise RuntimeError('Duplicate active owner '+gid)
    profiles[gid]=r['profile'];owners[gid]={'config':bind(cp),'recordFile':bind(rp),'recordLine':n,'recordLineSha256':'sha256:'+hashlib.sha256(l.encode()).hexdigest(),'profileFingerprint':r['profileFingerprint'],'goalFingerprint':r['goalFingerprint'],'reviewInputFingerprint':r['reviewInputFingerprint'],'profileStatus':r['status'],'reviewAuthority':r['reviewAuthority']}
 inventory=read(INV);occ={g['goalId']:next(o for o in g['occurrences'] if o['selected']) for f in inventory['families'] for g in f['goals'] if any(o['selected'] for o in g['occurrences'])}
 allreadings=[p for dr in [OLD/'readings']+[OLD/f'batch-{i:03d}'/'readings' for i in range(2,6)] for p in dr.glob('*.whole-original-inert.json')]
 manifest=[]
 for idx,r in enumerate(selected,1):
  gid=r['goalId'];oldpath=next(p for p in allreadings if gid in p.name); old=json.loads(oldpath.read_text()); n=int(oldpath.name.split('-')[0])
  exactpath=oldpath.parent/f'{n}.complete-source-semantics.json'
  if not exactpath.exists():
   for p in (OLD/'batch-001'/'dossiers').glob('*.json'):
    dd=json.loads(p.read_text())
    if dd.get('goalId')==gid or dd.get('wholeGoal',{}).get('id')==gid:exactpath=p;break
  review=read(r['selectedRecord']['reviewPath']);peer=next(x for x in review['decisions'] if x['decisionId']==r['selectedRecord']['decisionId'])
  o=occ[gid];eff=inventory['effectivePrerequisiteSets'][o['effectiveRequiresRef']]
  sources=old['sourceBindingFilesToReadSubstantively']
  for p in sources:sourcebinds[p]=bind(p)
  d={'role':'INFORMED_SUCCESSOR_AUTHOR_READER','goalId':gid,'wholeCurrentGoal':goals[gid],'wholeCurrentPositiveProfile':profiles[gid],'positiveOwner':owners[gid],'originalWholeInput':bind(oldpath),'originalGoalUnchanged':goals[gid]==old['wholeCurrentGoalAndPositiveBody']['wholeCurrentCanonicalGoal'],'originalPUnchanged':profiles[gid]==old['wholeCurrentGoalAndPositiveBody']['positiveBodyOwner']['wholePositiveProfile'],'currentOccurrence':o,'currentEffectiveDirectOrContainsInheritedPrerequisites':eff,'wholeCurrentEffectivePrerequisiteGoals':[goals[k.split(':')[-1]] for k in eff if k.split(':')[-1] in goals],'selectedOriginalRecord':r,'selectedOriginalPeer':peer,'sourceBindingFilesToReadSubstantively':sources,'oldExactSourceLocator':str(exactpath.relative_to(R)) if exactpath.exists() else None,'noIndependentOrNativeApproval':True}
  dump(f'readings/{idx:02d}-{gid}.current-whole.json',d);manifest.append({'position':idx,'goalId':gid,'title':r['title'],'decision':r['selectedRecord']['requiresDecision'],'reader':f'readings/{idx:02d}-{gid}.current-whole.json'})
 dump('selected18.current-exact.json',{'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'index':bind(INDEX),'inventory':bind(INV),'rolloutConfig':bind(CONFIG),'counts':{'review_required':11,'scope_gap':7,'total':18},'records':manifest})
 dump('currentGoalPositivePool.private.json',{'goals':goals,'profiles':profiles,'owners':owners,'occurrences':occ})
 dump('input-file-bindings.before.json',{'files':[bind(INDEX),bind(INV),bind(CONFIG)]+[bind(s['landscapePath']) for s in cfg['subjects'] if s['subject'] in ['mathematik','physik']]+list(sourcebinds.values())+[v for owner in owners.values() for v in [owner['config'],owner['recordFile']]]})
 print('Refreshed exact 18 current whole Goal/P; old whole inputs inert; '+str(len(sourcebinds))+' source locators bound.')
if __name__=='__main__':main()
