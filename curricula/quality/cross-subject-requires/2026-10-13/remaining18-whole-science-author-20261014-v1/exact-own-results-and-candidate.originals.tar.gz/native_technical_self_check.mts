// SPDX-License-Identifier: Apache-2.0
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { resolve } from 'node:path'
import { fingerprint, bytesFingerprint } from '../../../app/scripts/lib/crossSubjectRequiresInventory.ts'
import { validateRequiresDecisions } from '../../../app/scripts/lib/crossSubjectRequiresReview.ts'
const repo = resolve(process.cwd(), '..')
const base = 'tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1'
const raw = readFileSync(resolve(repo, base, 'native-proposal.bound.inert.json'))
const packet = JSON.parse(raw.toString('utf8'))
const inventory = JSON.parse(readFileSync(resolve(repo, 'curricula/quality/cross-subject-requires/math-physics.inventory.json'), 'utf8'))
const report = validateRequiresDecisions(inventory, packet, { familyIds: ['canonical-gymnasium'], sourcePathExists: path => existsSync(resolve(repo, path)) })
const bindings = packet.decisions.map(d => ({goalId: d.dependentGoalId, decision: d.decision, prerequisiteGoalIds: d.prerequisiteGoalIds, reviewInput: d.reviewInput, proposalBindingSha256: fingerprint(d.proposalBinding)}))
if (report.errors.length) throw new Error(report.errors.join('\n'))
if (report.reviewed !== 0) throw new Error('Unexpected independent approval in author-only packet')
writeFileSync(resolve(repo, base, 'native-technical-self-check.actual.json'), `${JSON.stringify({role:'AUTHOR_TECHNICAL_SELF_CHECK_ONLY', packetSha256:bytesFingerprint(raw), validation:report, exactBindings:bindings, noIndependentReviewSupplied:true, approvalsCreated:0},null,2)}\n`, {flag:'wx'})
console.log(JSON.stringify({errors:report.errors.length,required:report.required,reviewed:report.reviewed,open:report.open,authorDecisions:packet.decisions.length}))
