#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import json,hashlib
from pathlib import Path
from refresh_inputs import B,R,bind,dump
def collect_ids(v,out):
 if isinstance(v,dict):
  if isinstance(v.get('id'),str):out.setdefault(v['id'],[]).append(v)
  for x in v.values():collect_ids(x,out)
 elif isinstance(v,list):
  for x in v:collect_ids(x,out)
def contains(v,gid):
 if isinstance(v,dict):return any(contains(x,gid) for x in v.values())
 if isinstance(v,list):return any(contains(x,gid) for x in v)
 return v==gid
unique={};manifest=[]
for rp in sorted((B/'readings').glob('*.json')):
 d=json.loads(rp.read_text());gid=d['goalId'];ep=Path(d['oldExactSourceLocator']);ep=ep if ep.is_absolute() else R/ep
 s=json.loads(ep.read_text())
 if 'sourceSemanticsPath' in s:
  ep=Path(s['sourceSemanticsPath']);ep=ep if ep.is_absolute() else R/ep;s=json.loads(ep.read_text())
 fresh={'goalId':gid,'locatorInput':bind(ep),'refreshedSourceRecords':[],'mappingPlacements':[],'noSourceApproval':True}
 for k,sk in [('completeSourceGoals','wholeSourceGoal'),('completePassages','wholePassage'),('additionalLegacyCuratedSnapshotGoals','wholeSourceGoal')]:
  for old in s.get(k,[]):
   if sk not in old:
    sk=next(x for x in old if x.startswith('whole'))
   path=old['sourceFile']['path'];index={};doc=json.loads((R/path).read_text());collect_ids(doc,index)
   prior=old[sk];matches=index.get(prior['id'],[])
   exact=[x for x in matches if x==prior]
   if not exact:raise RuntimeError('Changed/missing substantive source '+path+' '+prior['id'])
   rec={'recordKind':k,'sourceFile':bind(path),'wholeCurrentRecord':exact[0],'currentEqualsOldLocatedBody':True,'sourceDocument':doc.get('sourceDocument'),'sourceDocuments':doc.get('sourceDocuments')}
   fresh['refreshedSourceRecords'].append(rec);unique[(path,prior['id'])]=rec
 for path in d['sourceBindingFilesToReadSubstantively']:
  doc=json.loads((R/path).read_text());rows=[]
  for key in ['mappings','decisions','placements','goalPlacements']:
   rows += [{'collection':key,'wholeCurrentRecord':x} for x in doc.get(key,[]) if contains(x,gid)]
  fresh['mappingPlacements'].append({'sourceFile':bind(path),'sourceExtractionPath':doc.get('sourceExtractionPath'),'records':rows,'mappingApprovalDoesNotApproveMathRequires':True})
 dump('sources/'+rp.name.replace('.current-whole.json','.current-source.json'),fresh)
 manifest.append({'goalId':gid,'sourceRecordCount':len(fresh['refreshedSourceRecords']),'mappingRowCount':sum(len(x['records']) for x in fresh['mappingPlacements'])})
dump('source-read-refresh.manifest.json',{'records':manifest,'uniqueWholeSourceRecords':len(unique),'allWholeSourceRecordsRefreshedFromActualFiles':True,'sourceScopeApprovalCreated':False,'requiresApprovalCreated':False})
dump('source-whole-unique.private.json',list(unique.values()))
print('Refreshed',len(unique),'unique whole source records; no acceptance inference.')
