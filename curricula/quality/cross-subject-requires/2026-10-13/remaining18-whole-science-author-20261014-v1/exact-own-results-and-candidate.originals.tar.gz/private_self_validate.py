#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import json,math,hashlib,datetime
from pathlib import Path
from fractions import Fraction as F
from refresh_inputs import B,R,bind,dump
checks=[]
def chk(name,value,expected,tol=1e-9):
 passed=(value==expected) if not isinstance(value,float) else math.isclose(value,expected,rel_tol=tol,abs_tol=tol)
 checks.append({'check':name,'actual':value,'expected':expected,'passed':passed})
 assert passed,name
chk('01 Hooke-D',-.4/-.02,20.)
chk('01 cubic-F at 1cm',-50*.01-1000*.01**3,-.501)
chk('02 damping-delta',math.log(2)/2,.34657359027997264)
chk('02 fresh-decay-rate',math.log(1.5)/3,.1351550360360548)
chk('03 group velocity',2+2*.5*2,4.)
chk('03 fresh group velocity',4+2*(-.25)*2,3.)
chk('04 optical-Msum',2**3/2**2,2.)
chk('04 corrected-Msum',2.5**3/4,3.90625)
chk('05 sheet-superposition factor',(2+1)/2,1.5)
chk('06 reduced-answer-equality',[1,4]==[1,4],True)
chk('06 retained-M-discrimination',[1,3]!=[1,1],True)
chk('07 through-origin-slope',(10*695+20*1410+30*2095)/(10**2+20**2+30**2),70.)
chk('07 Hubble-time-Gyr',3.085677581e19/70/31557600/1e9,13.968460307501203)
chk('08 vector-sum-x',511-511,0)
chk('08 vector-sum-y',3+3,6)
chk('08 moving-pair-photon-energy',math.hypot(511,3),511.00880618635136)
chk('09 null-touch-versus-crossing',(0-1)**2>0 and (2-1)**2>0 and (0-1)<0<(2-1),True)
chk('10 axial-B',math.sqrt(1.6e-5/40000),20e-6)
chk('10 equatorial-B',math.sqrt(1.8e-5/20000),30e-6)
chk('10 axial-m',math.sqrt(1.6e-5*40000),.8)
chk('11 radar-au',3e8*500/(2*.5),1.5e11)
chk('12 L',10*.001,.01)
chk('12 nonzero-initial-current',1-.6*math.exp(-1),.7792723352971347)
chk('13 length-constant-factor',math.sqrt(4),2.)
chk('13 rounded-A-length',-2/math.log(.61),4.046155942769545)
chk('14 background-corrected-next',25/2+10,22.5)
chk('14 fractional-time-activity',800*2**(-9/6),282.842712474619)
chk('15 rational-resistance',3/.29,10.344827586206897)
chk('15 pendulum-mean',(15/10+15.2/10+14.8/10)/3,1.5)
chk('16 speed',24.6/3.7,6.648648648648649)
chk('16 correct-guard-digit-energy',.5*.842*(24.6/3.7)**2,18.61010664718773)
chk('16 premature-energy',.5*.842*6.6**2,18.33876)
chk('16 explicit-uncertainty-lower',11.9/.84,14.166666666666668)
chk('16 explicit-uncertainty-upper',12.1/.82,14.75609756097561)
chk('17 gas-n',250000*.01/(8.314*350),.859136052785319)
chk('17 fresh-gauge-pressure',200*2-100,300)
chk('18 first-echo-depth',1540*26e-6/2,.02002)
chk('18 second-echo-depth',1540*65e-6/2,.05005)
chk('18 axial-resolution-low',1540*1e-6/2*1e3,.77)
chk('18 axial-resolution-high',1540*.2e-6/2*1e3,.154)

# More precise recomputation corrects two non-decision-affecting decimal strings.
# The original authored dossiers remain byte-exact; the additive erratum is the
# final arithmetic interpretation, not a replacement of scientific inputs.
errata=[{'goalId':'b615830a-e8b0-5754-81e0-99da98343a8d','originalLiteralDecimal':'18,6102914536… J','correctLiteralDecimal':'18,61010664718773… J','resultAfterRequiredRounding':'19 J','changesNecessityDecision':False}, {'goalId':'cd1903a5-d70a-5320-9124-b6b24917ba14','originalLiteralDecimal':'0,859135 mol','correctLiteralDecimal':'0,859136052785319 mol','resultAfterRequiredRounding':'0,86 mol','changesNecessityDecision':False}]
dump('own-arithmetic.additive-corrections.json',{'role':'AUTHOR_SELF_CORRECTION','originalDossiersPreserved':True,'corrections':errata,'noNewApproval':True})

prior=json.loads((B/'input-file-bindings.before.json').read_text());drift=[]
for rec in prior['files']:
 if bind(rec['path'])!=rec:drift.append(rec['path'])
assert not drift,drift
selection=json.loads((B/'selected18.current-exact.json').read_text());bound=json.loads((B/'native-proposal.bound.inert.json').read_text()); author=json.loads((B/'native-author-ledger.unbound.inert.json').read_text())
assert len(bound['decisions'])==18
assert {d['dependentGoalId'] for d in bound['decisions']}=={r['goalId'] for r in selection['records']}
assert bound['sourceAuthorSha256']==bind('tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/native-author-ledger.unbound.inert.json')['sha256']
assert not bound['proposedGraphCycles']
assert all(d['proposalBinding']['baseline']==d['reviewInput'] for d in bound['decisions'])
assert all(len(d['proposalBinding']['prerequisiteInputs'])==len(d['prerequisiteGoalIds']) for d in bound['decisions'])
dump('private-self-validation.actual.json',{'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'AUTHOR_PRIVATE_TECHNICAL_AND_ARITHMETIC_SELF_CHECK','independentReviewer':False,'arithmeticChecks':checks,'activeInputDrift':drift,'exactSelectedCount':18,'exactSetPreserved':True,'nativeHelperCommand':'node --import tsx scripts/prepareCrossSubjectRequiresProposal.ts --ledger tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/native-author-ledger.unbound.inert.json --output tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/native-proposal.bound.inert.json','nativeHelperWorkingDirectory':'app','nativeHelperObservedExitCode':0,'nativeHelperObservedStdout':'Prepared 18 unreviewed proposals with baseline/proposed bindings; 0 proposed global cycles. Wrote /home/enpasos/projects/skillpilot/tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/native-proposal.bound.inert.json','globalMissingAndAmbiguousReferenceChecks':'passed by actual existing native helper before output; not inferred from local subset','globalCycleCount':0,'requiresApprovalCreated':False,'M7GateStatusChanged':False,'currentPOrGoalChanged':False,'nativeProposalBinding':bind('tmp/cross-subject-requires/remaining18-whole-science-author-20261014-v1/native-proposal.bound.inert.json'),'remainingBoundary':'Independent requires peer, substantive official source/stage/placement decisions and any eventual native adoption gates remain separate; empirical color graphic and AU historical inputs are not completed here.'})
print('Private self-validation passed',len(checks),'arithmetic/logical checks; 18 exact records; no active-input drift; two additive precision corrections.')
