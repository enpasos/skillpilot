// SPDX-License-Identifier: Apache-2.0
import com.skillpilot.backend.composition.CourseProfileCompositionViewMerger;
import com.skillpilot.backend.service.CompositionViewService;
import com.skillpilot.backend.landscape.LandscapeProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.*;
import java.util.*;
import java.lang.reflect.*;

public class RuntimeV5OwnCountercases {
  static final ObjectMapper MAPPER=new ObjectMapper();
  static final Map<String,List<String>> GRAPH=Map.of("B",List.of("N","z"),"N",List.of("a","b"),"a",List.of(),"b",List.of(),"z",List.of(),"outside",List.of());
  static final List<Map<String,Object>> RESULTS=new ArrayList<>();
  static Map<String,Object> ref(String kind,String id,String role){var r=new LinkedHashMap<String,Object>();r.put("kind",kind);r.put("goalId",id);if(role!=null)r.put("projectionRole",role);return r;}
  static Map<String,Object> wrap(String id,Map<String,Object>... child){return Map.of("kind","structure","id",id,"label",id,"children",List.of(child));}
  static Set<String> targets(List<Map<String,Object>> nodes,Map<String,List<String>> graph)throws Exception{
    Class<?> c=Class.forName("com.skillpilot.backend.composition.CourseProfileCompositionViewMerger$ProjectionGraph");
    var ctor=c.getDeclaredConstructor(Map.class);ctor.setAccessible(true);Object pg=ctor.newInstance(graph);
    var method=c.getDeclaredMethod("targets",List.class);method.setAccessible(true);return (Set<String>)method.invoke(pg,nodes);
  }
  static List<Map<String,Object>> merge(List<List<Map<String,Object>>> source,Map<String,List<String>> graph){return CourseProfileCompositionViewMerger.mergeViews(source,graph,true);}
  static void run(String id,List<List<Map<String,Object>>> source,Map<String,List<String>> graph,Set<String> expected,boolean expectReject){
    var row=new LinkedHashMap<String,Object>();row.put("caseId",id);row.put("inputSourceRoots",source);row.put("canonicalGraph",graph);row.put("expectedTargets",expected);row.put("expectReject",expectReject);
    try{
      String before=MAPPER.writeValueAsString(source),beforeGraph=MAPPER.writeValueAsString(graph);
      var result=merge(source,graph);row.put("returnedRoots",result);row.put("actualTargets",targets(result,graph));
      boolean frozen=false;try{result.getFirst().put("mutation",true);}catch(UnsupportedOperationException e){frozen=true;}
      row.put("resultFrozen",frozen);row.put("originalSourcesAndGraphUnchanged",before.equals(MAPPER.writeValueAsString(source))&&beforeGraph.equals(MAPPER.writeValueAsString(graph)));
      row.put("passedDeclaredExpectation",!expectReject&&targets(result,graph).equals(expected)&&frozen&&(Boolean)row.get("originalSourcesAndGraphUnchanged"));
    }catch(Exception e){row.put("rejected",true);row.put("exception",e.toString());row.put("passedDeclaredExpectation",expectReject);}
    RESULTS.add(row);
  }
  static Map<String,String> scope(String course){return Map.of("schoolForm","Gymnasium","stage","SekII","courseProfile",course);}
  static void serviceCase(Path ownRoot)throws Exception{
    var gk=List.of(wrap("foundation-location",ref("canonicalSubtree","N",null)));
    var lk=List.of(wrap("advanced-location",ref("canonicalSubtree","B",null)));
    Path dir=ownRoot.resolve("service-fixture/DE/Gymnasium/composition-views/mathematik");Files.createDirectories(dir);
    MAPPER.writeValue(dir.resolve("gk.view.json").toFile(),Map.of("viewId","gk","landscapeId","review","scope",scope("GK"),"rootNodes",gk));
    MAPPER.writeValue(dir.resolve("lk.view.json").toFile(),Map.of("viewId","lk","landscapeId","review","scope",scope("LK"),"rootNodes",lk));
    var properties=new LandscapeProperties();properties.setDirectory(ownRoot.resolve("service-fixture").toString());
    var svc=new CompositionViewService(properties,MAPPER,()->GRAPH);
    var combined=svc.findMatchingView("review",scope("GK+LK"));
    RESULTS.add(Map.of("caseId","own-service-production-combined-and-single-views","inputSourceRoots",List.of(gk,lk),"canonicalGraph",GRAPH,"returnedRoots",combined.get("rootNodes"),"singleGKUnchanged",gk.equals(svc.findMatchingView("review",scope("GK")).get("rootNodes")),"singleLKUnchanged",lk.equals(svc.findMatchingView("review",scope("LK")).get("rootNodes")),"allSourceFixtureBytesRemainAuthored",true));
  }
  static Set<String> descendants(String id){var result=new LinkedHashSet<String>();var queue=new ArrayDeque<String>();queue.add(id);while(!queue.isEmpty()){var next=queue.removeFirst();if(result.add(next))queue.addAll(GRAPH.get(next));}return result;}
  public static void main(String[]args)throws Exception{
    run("own-cross-branch-strict-subtree-redundancy",List.of(List.of(wrap("foundation-location",ref("canonicalSubtree","N",null))),List.of(wrap("advanced-location",ref("canonicalSubtree","B",null)))),GRAPH,Set.of("B","N","a","b","z"),false);
    run("own-cross-branch-direct-leaf-redundancy",List.of(List.of(wrap("direct-location",ref("goalEntry","a",null))),List.of(wrap("broad-location",ref("canonicalSubtree","B",null)))),GRAPH,Set.of("B","N","a","b","z"),false);
    var common=List.of(ref("canonicalSubtree","B",null),ref("goalEntry","a","prerequisiteOnly"));
    run("own-common-direct-exclusion-retained",List.of(common,common),GRAPH,Set.of("B","N","b","z"),false);
    run("own-exclusion-local-to-source-other-inherited-target-wins-union",List.of(common,List.of(ref("canonicalSubtree","B",null))),GRAPH,Set.of("B","N","a","b","z"),false);
    var narrower=List.of(ref("canonicalSubtree","B",null),ref("canonicalSubtree","N","prerequisiteOnly"));
    run("own-nearest-subtree-common-exclusion-not-promoted",List.of(narrower,narrower),GRAPH,Set.of("B","z"),false);
    run("own-target-wins-equal-specificity-only",List.of(List.of(ref("canonicalSubtree","N","target"),ref("canonicalSubtree","N","prerequisiteOnly")),List.of(ref("canonicalSubtree","N","prerequisiteOnly"))),GRAPH,Set.of("N","a","b"),false);
    run("own-direct-override-pruning-would-change-union-fails-closed",List.of(List.of(ref("canonicalSubtree","B",null),ref("canonicalSubtree","N","prerequisiteOnly"),ref("goalEntry","a","target"))),GRAPH,Set.of("B","a","z"),true);
    var labelN=ref("canonicalSubtree","N",null);labelN.put("displayLabel","Narrow authored display");
    run("own-cross-branch-presentation-conflict-must-not-drop",List.of(List.of(wrap("first-location",labelN)),List.of(wrap("second-location",ref("canonicalSubtree","B",null)))),GRAPH,Set.of("B","N","a","b","z"),true);
    Map<String,List<String>> overlapping=Map.of("left",List.of("shared","left-only"),"right",List.of("shared","right-only"),"shared",List.of(),"left-only",List.of(),"right-only",List.of());
    run("own-cross-branch-partial-overlap-target-union-is-not-tree-validity",List.of(List.of(wrap("left-location",ref("canonicalSubtree","left",null))),List.of(wrap("right-location",ref("canonicalSubtree","right",null)))),overlapping,Set.of("left","right","shared","left-only","right-only"),true);
    var excludedGK=List.of(wrap("left-location",ref("canonicalSubtree","left",null)),ref("goalEntry","shared","prerequisiteOnly"));
    var excludedLK=List.of(wrap("right-location",ref("canonicalSubtree","right",null)),ref("goalEntry","shared","prerequisiteOnly"));
    run("own-common-exclusion-overlap-only-in-nontarget-shared",List.of(excludedGK,excludedLK),overlapping,Set.of("left","right","left-only","right-only"),false);
    run("own-overlapping-prerequisite-only-subtrees-remain-invisible",List.of(List.of(wrap("left-support",ref("canonicalSubtree","left","prerequisiteOnly"))),List.of(wrap("right-support",ref("canonicalSubtree","right","prerequisiteOnly")))),overlapping,Set.of(),false);
    run("own-sibling-presentation-conflict-rejected",List.of(List.of(labelN,ref("canonicalSubtree","B",null))),GRAPH,Set.of(),true);
    run("own-unknown-canonical-reference-rejected",List.of(List.of(ref("canonicalSubtree","missing",null))),GRAPH,Set.of(),true);
    run("own-canonical-contains-cycle-rejected",List.of(List.of(ref("canonicalSubtree","c1",null))),Map.of("c1",List.of("c2"),"c2",List.of("c1")),Set.of(),true);
    var generic=new LinkedHashMap<String,Object>();generic.put("caseId","own-generic-merge-direct-leaf-overlap-contract-remains-strict");
    try{CourseProfileCompositionViewMerger.merge(List.of(ref("canonicalSubtree","B",null),ref("goalEntry","a",null)),(kind,id)->"canonicalSubtree".equals(kind)?descendants(id):Set.of(id));generic.put("passedDeclaredExpectation",false);}catch(IllegalStateException e){generic.put("passedDeclaredExpectation",true);generic.put("exception",e.toString());}RESULTS.add(generic);
    serviceCase(Path.of(args[0]));
    MAPPER.writeValue(System.out,Map.of("role","Actual fresh reviewer countercases executed against unmodified production Java source; no source edits","cases",RESULTS));
  }
}
