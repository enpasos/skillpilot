# SPDX-License-Identifier: Apache-2.0
import pathlib,json,hashlib,datetime,subprocess,collections
root=pathlib.Path.cwd();out=pathlib.Path(__file__).resolve().parent;candidate=root/'tmp/cross-subject-requires/combined-profile-subtree-dedup-runtime-candidate-20261014-v5';prior=root/'tmp/cross-subject-requires/combined-profile-runtime-v4-informed-independent-technical-review-20261014-v1'
def read(p):return json.loads(p.read_text())
def stat(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':'sha256:'+hashlib.sha256(b).hexdigest()}
def write(name,data):
 p=out/name
 if p.exists():raise RuntimeError('Additive artifact exists; overwrite refused '+name)
 p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
snapshot=read(out/'original-inputs.before.actual.json');inputs=snapshot['files']+snapshot['classpathFiles'];checks=[];fail=[]
for row in inputs+read(prior/'own-seal.json')['files']:
 actual=stat(pathlib.Path(row['path']));same=all(actual[k]==row[k]for k in ['bytes','sha256']);checks.append({'expected':row,'actual':actual,'exact':same})
 if not same:fail.append(checks[-1])
extra=[stat(p)for p in (root/'app/src/utils/authoring').glob('*.ts')]
native=read(out/'v5-own-cases.actual.json')['cases'];compiled=read(out/'own-native-frontend-compiler-results.actual.json')['results'];current=[r for r in compiled if r['version']=='v5'];runtimeFailures=[r['caseId']for r in native if r.get('passedDeclaredExpectation')is False]
assert not runtimeFailures and len(native)==16
fixed=[]
for name in ['own-cross-branch-presentation-conflict-must-not-drop','own-cross-branch-partial-overlap-target-union-is-not-tree-validity']:
 row=next(r for r in native if r['caseId']==name);assert row['rejected']and row['passedDeclaredExpectation'];fixed.append({'caseId':name,'v5RejectedBeforeReturningInvalidView':True,'exception':row['exception']})
commonName='own-common-exclusion-overlap-only-in-nontarget-shared'
common=next(r for r in current if r['caseId']==commonName);commonNative=next(r for r in native if r['caseId']==commonName)
ids=[]
def flatten(nodes):
 for n in nodes:
  if n.get('sourceGoalId'):ids.append(n['sourceGoalId'])
  flatten(n.get('children',[]))
flatten(common['compiledRootNodes']);counts=collections.Counter(ids)
assert set(ids)==set(commonNative['expectedTargets'])and all(n==1 for n in counts.values())and 'shared'not in counts
assert len(common['compilerErrors'])==1 and common['compilerErrors'][0]['code']=='CPV-004'
support=next(r for r in current if r['caseId']=='own-overlapping-prerequisite-only-subtrees-remain-invisible');assert not support['compilerErrors']and not support['compiledRootNodes']
service=next(r for r in native if r['caseId']=='own-service-production-combined-and-single-views');assert service['singleGKUnchanged']and service['singleLKUnchanged']
fixture=[]
for version in ['baseline','v5']:
 row=next(r for r in read(out/(version+'-own-cases.actual.json'))['cases']if r['caseId']=='own-service-production-combined-and-single-views')
 for index,name in enumerate(['gk','lk']):
  p=out/version/'service-fixture/DE/Gymnasium/composition-views/mathematik'/(name+'.view.json');assert read(p)['rootNodes']==row['inputSourceRoots'][index];fixture.append({'file':stat(p),'actualAuthoredRootNodesRemainExactAfterServiceReads':True})
diffs=[]
for rel in ['com/skillpilot/backend/service/CompositionViewService.java','com/skillpilot/backend/composition/CourseProfileCompositionViewMerger.java']:
 p=subprocess.run(['diff','-u',str(root/'tmp/cross-subject-requires/combined-profile-subtree-dedup-runtime-candidate-20261014-v4/source'/rel),str(candidate/'source'/rel)],capture_output=True,text=True);assert p.returncode in [0,1];diffs.append(p.stdout)
p=out/'exact-v5-versus-v4-source-diffs.actual.patch';assert not p.exists();p.write_text('\n'.join(diffs))
sources={'mainService':stat(root/'backend/src/main/java/com/skillpilot/backend/service/CompositionViewService.java'),'mainMerger':stat(root/'backend/src/main/java/com/skillpilot/backend/composition/CourseProfileCompositionViewMerger.java'),'v5Service':stat(candidate/'source/com/skillpilot/backend/service/CompositionViewService.java'),'v5Merger':stat(candidate/'source/com/skillpilot/backend/composition/CourseProfileCompositionViewMerger.java')}
report={'role':'Actual INFORMED independent AI technical v5 recheck; original v4 rejection remains exact','reviewer':'/root/unresolved97_final17_completion','completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'bounded_approve_exact_v5_java_runtime_change','exactSources':sources,'freshActualProductionJavaProbes':16,'javaContractFailures':runtimeFailures,'separateBaselineAndV5RecompileAndExecution':True,'actualProductionFrontendCompilerRecheck':True,'correctedV4Countercases':fixed,
 'negativeCommonExclusionCase':{'caseId':commonName,'newBackendGuardCorrectlyAllowsOverlapOnlyOutsideExpectedTargets':True,'expectedTargets':commonNative['expectedTargets'],'actualTargets':commonNative['actualTargets'],'actualCompiledVisibleOccurrenceCounts':dict(counts),'sharedVisibleOccurrences':0,'remainingCompilerErrors':common['compilerErrors'],'preexistingBaselineSameRawCoverageDiagnostic':next(r for r in compiled if r['version']=='baseline'and r['caseId']==commonName)['compilerErrors']},
 'allPrerequisiteOnlyOverlapCase':{'caseId':support['caseId'],'backendReturnedWithoutUnfoundedPromotionOrRejection':True,'actualCompiledVisibleTree':support['compiledRootNodes'],'compilerErrors':support['compilerErrors']},
 'compilerLimit':'Current frontend CPV-004 uses raw subtree overlap and diagnoses shared even when direct common prerequisiteOnly excludes it. The compiled tree contains only left,left-only,right,right-only once each and has no CPV-005/006. This same diagnostic occurs in Main baseline. It is a separate current authoring/compiler limitation; this approval does not grant a successful whole-source/whole-scope validation or authorize deployment.',
 'mechanismReview':'Only the explicit full-view branch receives expectedTargets. Safe same-role/same-presentation strict-subset pruning remains first. The new full-view guard compares only two remaining target references and rejects their coverage intersection only where expectedTargets makes it intended. It does not mutate expectedTargets or source inputs. Exact target union is still checked before and after; generic merge remains unchanged. The observed metadata/partial-overlap failures now fail closed, while common non-target and wholly prerequisiteOnly overlap remains unpromoted and unblocked.',
 'otherEvidence':['Source-local exclusions and inherited targets preserve the independently resolved union.','Nearest subtree common exclusions and equal-specificity target dominance remain correct.','Unknown IDs, canonical contains cycle, sibling metadata conflict and pruning that would alter target union still reject.','Safe global subtree/direct-leaf pruning keeps current visible goals unique and removes empty wrappers.','Generic direct-leaf overlap remains strict.','Individual production-service GK/LK views, original fixture bytes and source canonical graph remain unchanged; result maps frozen.'],
 'original14CasesActuallyReexecuted':True,'twoNewReviewerNegativeCasesActuallyExecuted':True,'oldV4JudgmentNotReboundOrOverwritten':True,'oldV4Seal':stat(prior/'own-seal.json'),'authorRootOwned86TestProcessRestartedOrMutated':False,'authorRootOwnedWholeProductionAuditClaimedComplete':False,'serviceFixtureEvidence':fixture,
 'exposureDisclosure':['Parent author supplied v5 mechanism and two new regression tests after accepting my sealed v4 countercases.','Reviewer read exact v4→v5 diffs and current test source, then independently recompiled actual Main and v5 Java into new own output directories.','Original14 informed reviewer probes were actually rerun; two new negative cases were independently authored and run.','No author test status or byte equality substitutes for actual runtime/compiler evidence.'],
 'scope':'Bounded Java runtime/course-profile technical change only; current frontend raw-overlap diagnostic remains open','SourcePDScIM7HumanOrActiveAdoptionApproval':False,'mainOrCandidateSourceWrites':False,'MainDataDocInventoryCheckpointWrites':False,'commitStagePublishDeploy':False,'hashEqualityIsPreservationOnly':True}
write('technical-recheck.actual.json',report)
write('original-inputs-and-v4-reject-fresh-endcheck.actual.json',{'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allOriginalAndV4SealedBytesExact':not fail,'checks':checks,'failures':fail,'additionalReadonlyFrontendInputs':extra,'preservationOnly':True});assert not fail
write('handoff.json',{'role':report['role'],'decision':report['decision'],'scope':report['scope'],'v5Sources':sources,'review':stat(out/'technical-recheck.actual.json'),'ownV5Cases':stat(out/'v5-own-cases.actual.json'),'baselineCases':stat(out/'baseline-own-cases.actual.json'),'actualProductionCompilerResults':stat(out/'own-native-frontend-compiler-results.actual.json'),'actualJavaExecutions':stat(out/'own-production-java-executions.actual.json'),'ownFreshReexecutedProbes':16,'runtimeContractFailures':0,'v4CountercasesNowFailClosed':2,'commonNontargetOverlapRetainedWithoutPromotion':True,'whollyPrerequisiteOnlyOverlapCompilesInvisible':True,'remainingFrontendDiagnostic':{'code':'CPV-004','caseId':commonName,'rawOverlapOnly':True,'actualVisibleOccurrencesUnique':True,'sameInMainBaseline':True},'priorV4RejectPreservedExact':True,'authorTestsOrAuditProcessTouched':False,'noSourcePDScIM7HumanOrAdoptionApproval':True,'mainOrCandidateWrites':False,'ownSeal':'own-seal.json','ownEndcheck':'own-endcheck.actual.json'})
files=[stat(p)for p in sorted(out.rglob('*'))if p.is_file()and p.name not in ['own-seal.json','own-endcheck.actual.json']]
write('own-seal.json',{'sealedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'Exact separate independent v5 technical recheck artifacts; prior v4 rejection preserved','files':files,'selfExcluded':'own-seal.json','postsealCheckExcluded':'own-endcheck.actual.json'})
post=[]
for row in inputs+read(prior/'own-seal.json')['files']+extra+files:
 actual=stat(pathlib.Path(row['path']))
 if any(actual[k]!=row[k]for k in ['bytes','sha256']):post.append({'expected':row,'actual':actual})
write('own-endcheck.actual.json',{'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allOriginalV4AndOwnArtifactBytesExact':not post,'ownArtifactChecks':len(files),'failures':post,'mainOrCandidateWrites':False,'scope':'Bounded approve v5 Java; frontend raw CPV-004 limitation separate'})
print(json.dumps({'handoff':stat(out/'handoff.json'),'ownSeal':stat(out/'own-seal.json'),'endcheck':stat(out/'own-endcheck.actual.json'),'exactV5Merger':sources['v5Merger'],'allOriginalV4AndOwnArtifactBytesExact':not post},ensure_ascii=False));raise SystemExit(1 if post else 0)
