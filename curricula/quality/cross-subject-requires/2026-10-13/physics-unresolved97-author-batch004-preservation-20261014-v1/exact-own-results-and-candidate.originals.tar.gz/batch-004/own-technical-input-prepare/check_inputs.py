# SPDX-License-Identifier: Apache-2.0
"""Technical byte preservation only. Never writes outside its own directory."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, sys

ROOT = Path('/home/enpasos/projects/skillpilot')
OUT = Path(__file__).resolve().parent
READER = ROOT / 'tmp/cross-subject-requires/gymnasium-unresolved97-informed-reader-20261013-v1'


def sha(raw):
    return 'sha256:' + hashlib.sha256(raw).hexdigest()


def rel(path):
    return str(path.relative_to(ROOT))


def load(path):
    return json.loads(path.read_bytes())


def bind(path):
    if not path.is_file():
        return {'path': rel(path), 'exists': False}
    raw = path.read_bytes()
    return {'path': rel(path), 'exists': True, 'bytes': len(raw), 'sha256': sha(raw)}


def write(name, obj):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    # Preserve even isolated escaped UTF-16 surrogates found in original sources.
    path.write_text(json.dumps(obj, ensure_ascii=True, indent=2) + '\n')


if len(sys.argv) > 1 and sys.argv[1] == 'recheck':
    snapshot = load(OUT / 'input-snapshot.before.json')
    checks = [{'path': e['path'], 'byteUnchanged': bind(ROOT / e['path']) == e,
               'before': e, 'after': bind(ROOT / e['path'])} for e in snapshot['files']]
    guard_path = OUT / 'own-technical-report.sealed-index.json'
    guard = load(guard_path)
    own_checks = [{'path': e['path'], 'byteUnchanged': bind(ROOT / e['path']) == e} for e in guard['files']]
    result = {'schemaVersion': 1, 'checkedAt': datetime.now(timezone.utc).isoformat(),
              'snapshotSha256': sha((OUT / 'input-snapshot.before.json').read_bytes()),
              'ownTechnicalSealSha256': sha(guard_path.read_bytes()),
              'inputCount': len(checks), 'allInputBytesUnchanged': all(e['byteUnchanged'] for e in checks),
              'allOwnTechnicalReportBytesUnchanged': all(e['byteUnchanged'] for e in own_checks),
              'approvalCreated': False, 'scope97ResolvedClaimed': False,
              'checks': checks, 'ownChecks': own_checks}
    write('input-snapshot.end-recheck.json', result)
    print(json.dumps({k: v for k, v in result.items() if k not in ['checks', 'ownChecks']}))
    sys.exit(0 if result['allInputBytesUnchanged'] and result['allOwnTechnicalReportBytesUnchanged'] else 1)

files = set()
errors = []


def remember(path):
    files.add(path)
    return bind(path)


def check(expected):
    path = ROOT / expected['path']
    actual = remember(path)
    matches = actual.get('exists') and actual.get('bytes') == expected.get('bytes') and actual.get('sha256') == expected.get('sha256')
    row = {'path': expected['path'], 'expected': expected, 'actual': actual, 'matches': bool(matches)}
    if not matches:
        errors.append(row)
    return row


bindings_path = READER / 'actual-input-bindings.json'
index_path = READER / 'reader.sealed-index.json'
root_bindings = load(bindings_path)
index = load(index_path)
root_checks = [check(e) for e in root_bindings]
own_index_checks = [check(e) for e in index['files']]
for path in READER.iterdir():
    if path.is_file():
        remember(path)
summary = load(READER / 'summary.json')
batch = load(READER / 'informed-batch-004.json')
goal_ids = [r['goalId'] for r in batch['records']]
assert len(root_checks) == 627 and len(own_index_checks) == 9
assert len(goal_ids) == 20 and goal_ids == summary['allGoalIds'][60:80]
pins = {
    'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json': 'sha256:76047cec422c555aacd1e04bff597c4f8a70d8ffed5f214ed7412c828bc34898',
    'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json': 'sha256:4704c85973997b0bc822c360a9802fa55ce897a98936ec2c8782ed7c8f47076e',
    'curricula/quality/cross-subject-requires/math-physics.inventory.json': 'sha256:05fee31821ab14ab716f161eb48a3a63121539e2ca3e583da72388b582fc0dc3',
}
pin_checks = []
for name, expected in pins.items():
    actual = remember(ROOT / name)
    row = {'path': name, 'expectedSha256': expected, 'actual': actual, 'matches': actual.get('sha256') == expected}
    pin_checks.append(row)
    if not row['matches']:
        errors.append(row)

# Snapshot real validator internals and recursive local imports, without editing them.
tool_seeds = ['app/scripts/lib/crossSubjectRequiresInventory.ts', 'app/scripts/lib/crossSubjectRequiresReview.ts',
              'app/scripts/positiveGoalEvidenceReview.ts', 'app/scripts/positiveGoalEvidenceProfileModel.ts',
              'app/scripts/goalEvidenceProfileModel.ts', 'app/scripts/goalBookEvidenceReviewLoader.ts']
queue = [ROOT / p for p in tool_seeds]
tool_paths = set()
while queue:
    path = queue.pop()
    if path in tool_paths or not path.is_file():
        continue
    tool_paths.add(path)
    remember(path)
    for spec in re.findall(r"(?:from\s*|import\s*)['\"]([^'\"]+)['\"]", path.read_text()):
        if not spec.startswith('.'):
            continue
        target = (path.parent / spec).resolve()
        for candidate in [target, Path(str(target) + '.ts'), target / 'index.ts']:
            if candidate.is_file():
                queue.append(candidate)
                break
for name in ['contracts/goal-evidence/v1/goal-evidence-ai-run-manifest.schema.json',
             'contracts/goal-evidence/v2/goal-evidence-profile.schema.json',
             'contracts/goal-evidence/v2/goal-evidence-review-config.schema.json',
             'contracts/goal-evidence/v1/goal-evidence-profile.schema.json',
             'curricula/quality/cross-subject-requires/math-physics.config.json',
             'curricula/curriculum_manifest.json', 'AGENTS.md', 'LICENSING.md']:
    remember(ROOT / name)

# The genuine inventory builder reads all non-quality curriculum JSON files.
# Snapshot that read universe and index only factual source IDs for exact lookups.
documents = {}
source_documents_by_id = {}
for folder, dirs, names in os.walk(ROOT / 'curricula'):
    dirs[:] = [d for d in dirs if d != 'quality']
    for name in names:
        if not name.endswith('.json'):
            continue
        path = Path(folder) / name
        remember(path)
        doc = load(path)
        if not isinstance(doc, dict):
            continue
        documents[rel(path)] = doc
        source_id = doc.get('sourceLandscapeId') if 'sourceGoals' in doc else doc.get('landscapeId', doc.get('id'))
        if source_id and ('goals' in doc or 'sourceGoals' in doc):
            source_documents_by_id.setdefault(source_id, []).append((path, doc))


def remember_refs(value):
    if isinstance(value, dict):
        for key, nested in value.items():
            if isinstance(nested, str) and nested.startswith(('curricula/', 'app/', 'docs/', 'contracts/', 'tmp/')) and (key.endswith('Path') or key in ['path', 'source']):
                remember(ROOT / nested)
            elif isinstance(nested, str) and nested.startswith('/assets/'):
                remember(ROOT / 'app/public' / nested.lstrip('/'))
            remember_refs(nested)
    elif isinstance(value, list):
        for nested in value:
            remember_refs(nested)


source_files = set()
source_association_index = []
for dossier in batch['records']:
    id_ = dossier['goalId']
    body = dossier['wholeCurrentGoalAndPositiveBody']
    remember_refs(body)
    owner = body['positiveBodyOwner']
    owner_config = load(ROOT / owner['configPath'])
    remember_refs(owner_config)
    mappings = []
    for name in dossier['sourceBindingFilesToReadSubstantively']:
        path = ROOT / name
        source_files.add(path)
        remember(path)
        if not path.is_file():
            mappings.append({'mappingPath': name, 'exists': False})
            continue
        doc = load(path)
        remember_refs(doc)
        direct_mappings = [m for m in doc.get('mappings', []) if m.get('canonicalGoalId') == id_]
        direct_ids = {m.get('reviewDecisionId') for m in direct_mappings}
        direct_decisions = [d for d in doc.get('decisions', []) if d.get('canonicalGoalId') == id_ or d.get('decisionId', d.get('id')) in direct_ids]
        rows = []
        source_path = doc.get('sourceExtractionPath')
        candidates = source_documents_by_id.get(doc.get('sourceLandscapeId'), [])
        if source_path and source_path in documents:
            candidates = [(ROOT / source_path, documents[source_path])] + [pair for pair in candidates if rel(pair[0]) != source_path]
        for mapping in direct_mappings:
            legacy_id = mapping.get('legacyGoalId')
            source_goal_matches = []
            for source_path_actual, source in candidates:
                exact_goals = [g for g in source.get('sourceGoals', source.get('goals', [])) if g.get('id') == legacy_id]
                if not exact_goals:
                    continue
                remember(source_path_actual)
                remember_refs(source)
                passage_ids = {g.get('passageId') or g.get('sourceRef', {}).get('passageId') for g in exact_goals}
                exact_passages = [p for p in source.get('passages', []) if p.get('id') in passage_ids or legacy_id in p.get('sourceGoalIds', [])]
                source_goal_matches.append({'sourceFile': bind(source_path_actual), 'sourceLandscapeId': doc.get('sourceLandscapeId'),
                                            'wholeSourceGoals': exact_goals, 'wholePassages': exact_passages,
                                            'sourceDocument': source.get('sourceDocument'), 'sourceDocuments': source.get('sourceDocuments')})
            rows.append({'exactMapping': mapping, 'legacyGoalId': legacy_id, 'exactIdSourceMatches': source_goal_matches,
                         'noDirectIdMatch': not source_goal_matches})
        mappings.append({'mappingFile': bind(path), 'sourceLandscapeId': doc.get('sourceLandscapeId'),
                         'targetLandscapeId': doc.get('targetLandscapeId'), 'sourceExtractionPath': doc.get('sourceExtractionPath'),
                         'wholeDirectMappingDecisions': direct_decisions, 'directGoalMappings': rows,
                         'directGoalMappingCount': len(direct_mappings)})
    relative_output = 'source-readings/' + id_ + '.exact-source-associations.json'
    write(relative_output, {'schemaVersion': 1, 'goalId': id_, 'literalSuppliedSourcePaths': dossier['sourceBindingFilesToReadSubstantively'],
                            'associations': mappings, 'kind': 'literal-exact-id-file-extraction-only',
                            'sourceQualityCoverageApplicabilityOrAcceptanceClaimed': False,
                            'allWholePassagesCopiedFromBoundOrFreshlySnapshottedExistingFiles': True})
    source_association_index.append({'goalId': id_, 'path': rel(OUT / relative_output),
                                     'suppliedMappingPathCount': len(mappings),
                                     'directGoalMappingCount': sum(m.get('directGoalMappingCount', 0) for m in mappings)})

native_script = OUT / 'native-current-owner-triples.ts'
toolchain = ROOT / 'tmp/toolchains/node-v22.22.0-linux-x64/bin/node'
tsx = ROOT / 'app/node_modules/tsx/dist/cli.mjs'
remember(toolchain)
remember(tsx)
for path in (ROOT / 'app/node_modules/tsx/dist').rglob('*'):
    if path.is_file():
        remember(path)
for package in ['ajv', 'ajv-formats']:
    for path in (ROOT / 'app/node_modules' / package / 'dist').rglob('*'):
        if path.is_file():
            remember(path)
    remember(ROOT / 'app/node_modules' / package / 'package.json')

snapshot = {'schemaVersion': 1, 'capturedAt': datetime.now(timezone.utc).isoformat(),
            'scope': 'Own informed AUTHOR technical input adapter positions61–80; first60sealed,37includingthisbatch not yet authored',
            'root627FileBindingsPreserved': all(e['matches'] for e in root_checks),
            'root9IndexEntriesPreserved': all(e['matches'] for e in own_index_checks),
            'files': [bind(p) for p in sorted(files)], 'approvalCreated': False}
write('input-snapshot.before.json', snapshot)
command = [str(toolchain), str(tsx), str(native_script)]
started = datetime.now(timezone.utc).isoformat()
run = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
(OUT / 'native-proof.stdout.txt').write_text(run.stdout)
(OUT / 'native-proof.stderr.txt').write_text(run.stderr)
write('native-proof.command.json', {'argv': command, 'startedAt': started,
                                    'completedAt': datetime.now(timezone.utc).isoformat(), 'exitCode': run.returncode,
                                    'stdoutPath': rel(OUT / 'native-proof.stdout.txt'), 'stderrPath': rel(OUT / 'native-proof.stderr.txt')})
native_result = load(OUT / 'native-current-owner-triples.actual.json') if (OUT / 'native-current-owner-triples.actual.json').is_file() else None
after_checks = [{'path': e['path'], 'byteUnchanged': bind(ROOT / e['path']) == e} for e in snapshot['files']]
all_preserved = all(e['byteUnchanged'] for e in after_checks)
report = {'schemaVersion': 1, 'checkedAt': datetime.now(timezone.utc).isoformat(),
          'kind': 'OWN informed AUTHOR technical input integrity only', 'assignedGoalCount': 20, 'remainingNotYetAuthored': 37, 'all97ApprovalAdoptionScopeStillOpen': True,
          'informedAuthorContext': True, 'rootInputBindingCount': len(root_checks), 'rootOwnIndexEntryCount': len(own_index_checks),
          'allRoot627BytesMatch': all(e['matches'] for e in root_checks), 'allRoot9IndexBytesMatch': all(e['matches'] for e in own_index_checks),
          'rootReaderIndexBinding': bind(index_path), 'rootActualBindingsBinding': bind(bindings_path),
          'baselinePinChecks': pin_checks, 'selectedBatchGoalIds': goal_ids, 'selectedBatchIdsMatchExactRootSlice': goal_ids == summary['allGoalIds'][60:80],
          'validatorInternals': [bind(p) for p in sorted(tool_paths)], 'validatorInternalsWritten': False,
          'sourceMappingFileCount': len(source_files), 'sourceAssociationIndex': source_association_index,
          'nativeProofExitCode': run.returncode, 'nativeProofSummary': {k: v for k, v in native_result.items() if k != 'proofs'} if native_result else None,
          'snapshotFileCount': len(snapshot['files']), 'allInputsUnchangedDuringNativeCheck': all_preserved,
          'rootByteErrors': errors, 'rootChecks': root_checks, 'rootOwnIndexChecks': own_index_checks,
          'independentReviewNativePKindSourceOrM7ApprovalCreated': False, 'activeWritesOrReconstructedOriginals': False,
          'scope97ResolvedClaimed': False, 'bytePreservationDoesNotEstablishContentOrSourceAcceptance': True}
write('independent-input-integrity.actual.json', report)
write('source-readings/index.json', {'records': source_association_index, 'goalCount': 20, 'noSourceAcceptanceCreated': True})
owned = [p for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['own-technical-report.sealed-index.json', 'input-snapshot.end-recheck.json']]
write('own-technical-report.sealed-index.json', {'schemaVersion': 1, 'createdAt': report['checkedAt'],
                                              'files': [bind(p) for p in owned], 'selfExcluded': True,
                                              'technicalReceiptOnly': True, 'approvalCreated': False})
print(json.dumps({k: report[k] for k in ['allRoot627BytesMatch', 'allRoot9IndexBytesMatch', 'sourceMappingFileCount', 'nativeProofExitCode', 'snapshotFileCount', 'allInputsUnchangedDuringNativeCheck', 'scope97ResolvedClaimed']}))
sys.exit(0 if not errors and run.returncode == 0 and all_preserved else 1)
