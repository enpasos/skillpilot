#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Own informed author judgments for positions 61–80; no review authority."""
import datetime, hashlib, json, math
from pathlib import Path

INPUT=Path(__file__).parent.parent/'batch-004'
B=Path(__file__).parent
R=Path.cwd()
AUTHOR='/root/gym_math_two_zero_product_native_d_informed_synthesis'
MATH='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
PHY='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'
AXES='80c232f1-8f72-5829-9dbe-5a610ccab3be'
UNITS='f2e42af5-67a6-477e-82ea-e65b09cc6cb3'
LINEAR='af3d6bff-c5fb-4ec6-a9f0-c0be09fc9186'
SINE='bbef7cf2-90fa-59fa-a115-8b651aab9231'


import sys
sys.path.insert(0,str(INPUT))
from own_substantive_cases import CASES
allcontexts={r['goalId']:r for sub in ['mathematik','physik'] for r in json.loads(Path('tmp/cross-subject-requires/gymnasium-whole-positive-body-review-inputs-20261013-v1',sub,'whole-goals-and-positive-profiles.current.json').read_text())['records']}

def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():raise RuntimeError('Refuse overwrite '+str(p))
    p.write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
def bind(path):
    p=R/path;raw=p.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()}
def main():
    index=[];ledger=[]
    paths=json.loads((INPUT/'full-current-prerequisite-paths-for-nominees.actual.json').read_text())
    for n,case in enumerate(CASES,61):
        state,foreign,reason,counter,source,probes,history=case
        s=json.loads((INPUT/f'readings/{n}.semantic-reading.json').read_text())
        raw=next((INPUT/'readings').glob(f'{n}-*.whole-original-inert.json'))
        orig=json.loads(raw.read_text());whole=orig['wholeCurrentGoalAndPositiveBody'];g=whole['wholeCurrentCanonicalGoal'];p=s['completePositiveProfile'];gid=g['id']
        exact=json.loads((INPUT/f'readings/{n}.complete-source-semantics.json').read_text())
        sourcepaths={v['sourceFile']['path'] for v in exact['completeSourceGoals']+exact['completePassages']+exact['additionalLegacyCuratedSnapshotGoals']}
        refs=[{'path':PHY,'recordId':gid,'locator':f'goals[id={gid}]','supports':'goalSemantics'}, {'path':PHY,'recordId':gid,'locator':f'goals[id={gid}].applicability','supports':'scope'}, {'path':str(raw),'recordId':gid,'locator':'wholeCurrentGoalAndPositiveBody;originalIndependentHistory','supports':'goalSemantics'}]
        refs += [{'path':v,'recordId':gid,'locator':'exact source IDs and whole passages in dossier; no blanket SourceCoverage','supports':'goalSemantics'} for v in sorted(sourcepaths)]
        refs += [{'path':MATH,'recordId':v,'locator':f'goals[id={v}]','supports':'prerequisite'} for v in foreign]
        proposal={'decisionId':f'informed97-author-004-{gid}','familyId':'canonical-gymnasium','dependentGoalId':gid,'dependentTitle':g['title'],'dependentDescription':g['description'],'prerequisiteGoalIds':foreign,'decision':state,'rationale':reason,'evidenceKind':'didacticSequencing','sourceRefs':refs,'applicability':{'universality':'allDependentScopes' if state in ['add','no_cross_subject_required'] else 'unresolved','scopes':[g.get('applicability',{})],'alternatives':[counter,source]},'author':AUTHOR,'status':'candidate'}
        ledger.append(proposal)
        d={'schemaVersion':1,'role':'INFORMED_AUTHOR','author':AUTHOR,'actualAuthoringTimeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'goalIndexWithin97':n,'subjectScope':'Gymnasium Math↔Physics only','modelConfigurationBasis':'Root-confirmed fork=none/gpt-6.1-sol/ultra; no API-build or model-diversity claim','exposure':'Knows Math2 synthesis, First60 authoring, original histories and child source/quality/Requires reports; not blind, no independent authority over own candidates','wholeInputPath':str(raw),'wholeInputFileBinding':bind(str(raw)),'wholeGoal':g,'wholePositiveProfile':p,'currentPerGoalReviewInput':s['currentPerGoalReviewInput'],'positiveOwner':whole['positiveBodyOwner'],'originalAuthorPeerHistories':s['history'],'unresolvedDistinctFourthBatchDissent':s['unresolvedDistinctFourthBatchDissent'],'historyResolution':history,'wholeBodyNecessityAndAlternativeAssessment':reason,'counterexampleAndBoundaryAssessment':counter,'sourceStageAndApplicabilityAssessment':source,'sourceFileBindings':[bind(v) for v in sorted(sourcepaths)],'sourceSemanticsPath':str(INPUT/f'readings/{n}.complete-source-semantics.json'),'currentDirectedPrerequisitePaths':paths[n-61],'ownCandidate':proposal,'unboundSuggestedMathNominees':([next(i for i in allcontexts if i.startswith('f4df'))] if n==80 else []),'freshSolvedAuthorProbes':[{'id':f'{n}-own-{j+1}','workedAnswer':v,'physicalExperimentPerformed':False} for j,v in enumerate(probes)],'wholePWitness':{'requiredExpectationIds':p['coverageExpectations']['requiredExpectationIds'],'allApplicationCaseIdsRead':[c['id'] for c in p['applicationCaseBriefs']],'coverageExplanation':reason+' '+counter+' '+' '.join(probes),'minimumIndependentDemonstrationsPreserved':p['coverageExpectations']['minimumIndependentDemonstrations'],'bothLanguagesAndAllCasesRead':True,'allCurrentQuantitativeDutiesRemainBinding':True,'knownMaterialLimit':'Synthetic supplied datasets/models, no physical experiment or P/source material approval','noAssessmentQuotaApprovalCreated':True},'directPrerequisiteGoalsReadAsWholeBodies':s['directPrerequisiteGoals'],'noFakePositiveOwnerForClustersOrOrientation':True,'noPKindAMVHumanM7OrSourceApprovalCreated':True,'newIndependentRequiresReview':False,'activeWritesOrAdoption':False,'remainingGates':['independent informed whole-body Requires review','P/Kind/A/M/V quality','SourceContent/SourcePlacement and entire scope','routes and mathematical floors','strict CI/M7','adoption'],'ownContentLicense':'CC-BY-4.0; third-party sources retain rights'}
        dest=B/f'dossiers/{n}-{gid}.author-dossier.json';dump(dest,d);index.append({'index':n,'goalId':gid,'decision':state,'path':str(dest),'sha256':bind(str(dest))['sha256']})
    dump(B/'author-ledger.inert.json',{'schemaVersion':1,'role':'INFORMED_AUTHOR','author':AUTHOR,'decisions':ledger})
    dump(B/'dossier-index.json',{'authorDossiers':index,'authoredThisBatch':20,'authoredWithin97':80,'notYetAuthored':17,'all97IndependentApprovalAndAdoptionStillOpen':True})
    dump(B/'source-content-reading.boundaries.json',{'newSemanticDisplayFilesActuallyRead':[bind(str(v)) for v in sorted((INPUT/'novel-source-content-display').glob('*.txt'))],'novelWholeSemanticObjectsActuallyRead':390,'wholeObjectsExactlyEqualToPreviouslySubstantivelyReadObjects':110,'reuseEvidence':bind(str(INPUT/'source-semantic-reuse.preparation.json')),'all20WholeGoalPAndCaseBodiesRead':True,'noGeneralFullPDFClaim':True,'limits':['Generic ST documentation rows only partially match topic-specific Physics','Malformed extracted formula text is extraction uncertainty, not an official-source error claim','HE resonance source qualitative versus active target quantitative remains a P/Source scope issue','Current all16 applicability preserved, old nominees may exclude BY/HB','Actual referenced quadratic cluster context separated from pure requires traversal and mastery']})
    print(json.dumps({'authoredThisBatch':20,'authoredWithin97':80,'remainingAuthoring':17,'states':[c[0] for c in CASES],'approvalsCreated':0}))

if __name__=='__main__':main()
