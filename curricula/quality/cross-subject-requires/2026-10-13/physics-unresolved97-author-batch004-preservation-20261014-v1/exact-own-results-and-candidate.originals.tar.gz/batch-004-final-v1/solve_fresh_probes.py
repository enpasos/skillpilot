# SPDX-License-Identifier: Apache-2.0
"""Actual own synthetic model calculations; no experiment or P approval."""
import datetime,json,math
from pathlib import Path
B=Path(__file__).parent
def near(a,b):return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-10)
def response(r,z):return 1/math.sqrt((1-r*r)**2+(2*z*r)**2)
centres=[(-4*k,3*k) for k in range(-2,3)]
r=1.6*.375;normal=(.6,.8)
tangencies=[(x+r*normal[0],y+r*normal[1]) for x,y in centres]
probes={
61:[{'centres':centres,'radius':r,'tangencies':tangencies,'frontEquation':'3x+4y=3','perpendicularSeparation':3/5}, {'circularRadius':1.2+r,'slowerMediumRadius':.8*.375}],
62:[{'midpoint_us':(31+59)/2,'halfDuration_us':(59-31)/2}, {'midpoint_us':(5+17)/2,'halfDuration_us':(17-5)/2}],
63:[{'halfLifeActivities_Bq':[960*2**(-n) for n in [1,2,3,.5]]}, {'netCountsPerMin':[88-8,48-8,28-8],'nextGrossPerMin':(28-8)/2+8}],
64:[{'T_K':(320/5.67e-8)**.25,'balancedFlux_W_m2':5.67e-8*(320/5.67e-8)}, {'T_K':(250/5.67e-8)**.25}],
65:[{'omega_s_inv':1/math.sqrt(.2*20e-6),'period_s':2*math.pi/500,'Ecapacitor_J':(30e-6)**2/(2*20e-6),'Einductor_J':.2*.015**2/2}, {'capacitance_F':1/(.5*200**2),'period_s':2*math.pi/200,'E_J':.5*.04**2/2}],
66:[{'periods_s':[12.3/10,12.5/10,12.1/10],'mean_s':sum([12.3,12.5,12.1])/30,'span_s':(12.5-12.1)/10}, {'R_Ohm':[u/i for u,i in zip([.5,1,1.5],[.025,.049,.072])]}],
67:[{'energies_kWh':[75*800/1000,12*800/1000],'saving_kWh':(75-12)*800/1000,'fractionSaved':(75-12)/75}, {'Q_kJ':.8*4.18*60,'input_kJ':[.080*3600,.100*3600],'eta':[.8*4.18*60/(e*3600) for e in [.080,.100]]}],
68:[{'netPerMin':(20-6)/1,'secondNetPerMin':(40-12)/2}, {'netPerMin':(42-9)/(90/60)}],
69:[{'eachLobePercent':88/2,'outsidePercent':100-88,'localEqualVolumeRatio':3}, {'probabilityA':2/(2+3),'probabilityB':3/(2+3)}],
70:[{'x0_m':.06,'v0_m_s':4*.06,'amplitude_m':math.hypot(.06,.06),'phase':-math.pi/4,'period_s':2*math.pi/4,'residuals':[(-16*(.06*math.cos(4*t)+.06*math.sin(4*t))+16*(.06*math.cos(4*t)+.06*math.sin(4*t))) for t in [0,.2,.7]]}, {'x0_m':0,'v0_m_s':.08*5,'period_s':2*math.pi/5}],
71:[{'energies_Wh':[8*5,13*5],'saved_Wh':(13-8)*5,'ratio':8/13}, {'dailySurplus_Wh':55-45,'nightRequiredStoreInput_Wh':20/.75}],
72:[{'R_Ohm':9.6/.71,'twoSigOhm':14}, {'E_J':.5*.842*(24.6/3.7)**2,'Eearly_J':.5*.842*6.6**2,'reported_J':19,'earlyReported_J':18}],
73:[{'reservoirChanges_J_K':[-100/500,100/250],'total_J_K':-100/500+100/250}, {'totals_J_K':[-.3+.3,-.3+.5,-.5+.3]}],
74:[{'valuesAtOne':[response(1,z) for z in [.1,.3]],'rpeak':[math.sqrt(1-2*z*z) for z in [.1,.3]],'peaks':[response(math.sqrt(1-2*z*z),z) for z in [.1,.3]]}, {'samplePeakRatio':5/1.747,'upperHalfCrossing_Hz':11+(3.288-2.5)/(3.288-1.995),'lowerCrossingOutsideSample':2.538>2.5}],
75:[{'positiveTriangle_J':.5*2*6,'negativeTriangle_J':-.5*2*4,'net_J':.5*2*(6-4),'oblique_J':5*3*math.cos(math.pi/3)}, {'springEnergy_J':.5*80*.15**2,'springWork_J':-.5*80*.15**2,'componentWork_J':4*.5}],
76:[{'enclosedMasses_Msun':[200**2*x/4.3e-6 for x in [5,10]],'excessMasses_Msun':[200**2*x/4.3e-6-v for x,v in zip([5,10],[3e10,4e10])]}, {'speeds':[150/.75,150/.6],'massRatio':(250/200)**2,'revisedMass_Msun':250**2*10/4.3e-6}],
77:[{'frequencies':[[v/n for v in row] for n,row in [(20,[2,7,2,7,2]),(500,[55,169,45,177,54]),(20000,[1980,7010,2005,6995,2010])]],'countSums':[sum(row) for row in [[2,7,2,7,2],[55,169,45,177,54],[1980,7010,2005,6995,2010]]]}, {'frequencies':[v/500 for v in [40,115,190,115,40]],'countSum':sum([40,115,190,115,40])}],
78:[{'force_N':.3*2*.12*math.sin(math.pi/6),'perpendicular_N':.3*2*.12}, {'slope_N_A':(.020-.008)/(1.5-.5),'B_T':(.020-.008)/(1.5-.5)/.1,'offset_N':.008-(.020-.008)/(1.5-.5)*.5,'badSingle_T':.008/(.5*.1)}],
79:[{'signedEnergy_eV':[2.1-2.4,3.7-2.4],'emissionPossible':[2.1>=2.4,3.7>=2.4]}, {'signedEnergy_eV':[3.7-4,4.8-4,4.8-2.4]}],
80:[{'p2_Pa':100000*450/300}, {'pV_J':250000*.010,'n_mol':250000*.010/(8.314*350),'badCelsius_mol':250000*.010/(8.314*77)}]
}
checks={
'fiveActualTangencies':len(centres)==5 and all(near(3*x+4*y,3) for x,y in tangencies),
'circleRadiusBackcheck':all(near((x-a)**2+(y-b)**2,r*r) for (x,y),(a,b) in zip(tangencies,centres)),
'syncSymmetry':near(45-31,59-45),
'backgroundNetHalves':probes[63][1]['netCountsPerMin']==[80,40,20],
'radiationBalance':near(5.67e-8*probes[64][0]['T_K']**4,320),
'LCEnergyBudget':near(probes[65][0]['Ecapacitor_J'],probes[65][0]['Einductor_J']),
'pendulumMean':near(probes[66][0]['mean_s'],1.23),
'savingService':near(probes[67][0]['fractionSaved'],.84),
'pulseDurationNormalization':near(probes[68][0]['netPerMin'],probes[68][0]['secondNetPerMin']),
'probabilityNormalization':near(sum(probes[69][1].values()),1),
'twoInitialValues':near(probes[70][0]['v0_m_s'],.24) and near(probes[70][1]['v0_m_s'],.4),
'guardDigitCounterexample':probes[72][1]['E_J']>18.5>probes[72][1]['Eearly_J'],
'entropyOppositeSigns':probes[73][1]['totals_J_K'][1]>0>probes[73][1]['totals_J_K'][2],
'resonancePeakShift':all(x<1 for x in probes[74][0]['rpeak']) and probes[74][0]['rpeak'][1]<probes[74][0]['rpeak'][0],
'signedWorkNotMagnitude':near(probes[75][0]['net_J'],2),
'projectionMassScaling':near(probes[76][1]['massRatio'],1.5625),
'photonAllBatchesNormalized':all(near(sum(row),1) for row in probes[77][0]['frequencies']) and near(sum(probes[77][1]['frequencies']),1),
'forceSlopeAllPoints':all(near(.012*i+.002,f) for i,f in zip([.5,1,1.5],[.008,.014,.020])),
'thresholdNoNegativeKE':not probes[79][0]['emissionPossible'][0] and probes[79][0]['signedEnergy_eV'][0]<0,
'gasBackSubstitution':near(probes[80][1]['n_mol']*8.314*350,2500)
}
errors=[k for k,v in checks.items() if not v]
report={'role':'OWN INFORMED AUTHOR','checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'positions61to80':probes,'probeCount':40,'meaningfulConsistencyChecks':checks,'errors':errors,'noPhysicalExperimentOrIndependentApproval':True}
dest=B/'forty-fresh-author-probe-calculations-and-construction.actual-v2.json'
if dest.exists():raise RuntimeError('Refuse overwrite')
dest.write_text(json.dumps(report,indent=2)+'\n')
# Narrow exact construction witness, not a generated goal visualization or approved asset.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
fig,ax=plt.subplots(figsize=(7,7))
for (a,b),(x,y) in zip(centres,tangencies):
 ax.add_patch(Circle((a,b),r,fill=False,color='royalblue'));ax.plot(a,b,'ko');ax.plot(x,y,'ro')
xx=[-10,10];ax.plot(xx,[-3*x/4 for x in xx],color='black',label='old: 3x+4y=0');ax.plot(xx,[(3-3*x)/4 for x in xx],color='red',label='new: 3x+4y=3')
ax.arrow(0,0,.6*r,.8*r,width=.025,color='green',length_includes_head=True)
ax.set(xlim=(-10,10),ylim=(-9,9),xlabel='x / m',ylabel='y / m',title='Five secondary circles, r=0.6 m; forward tangent envelope')
ax.set_aspect('equal');ax.grid();ax.legend();fig.savefig(B/'huygens-five-circle-construction.actual.png',dpi=180);plt.close(fig)
print(json.dumps({'freshSolvedProbes':40,'actualCirclesConstructed':5,'consistencyChecks':len(checks),'errors':errors}))
raise SystemExit(bool(errors))
