// SPDX-License-Identifier: Apache-2.0
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {buildRequiresInventory,assertFreshRequiresInventory,fingerprint,stableJson} from '../../../app/scripts/lib/crossSubjectRequiresInventory.ts';
import {validateRequiresDecisions} from '../../../app/scripts/lib/crossSubjectRequiresReview.ts';
const root=process.cwd();const out=dirname(fileURLToPath(import.meta.url));
const author='tmp/cross-subject-requires/physics-unresolved97-whole-body-successor-author-20261013-v1/batch-004-final-v1/native-proposal';
const read=(p:string)=>JSON.parse(readFileSync(resolve(root,p),'utf8'));
const sha=(p:string)=>'sha256:'+createHash('sha256').update(readFileSync(resolve(root,p))).digest('hex');
const ledger=read(author);const judgments=read(resolve(out,'twenty-individual-substantive-requires-peer-judgments.actual.json'));
const actual=buildRequiresInventory(root,read('curricula/quality/cross-subject-requires/math-physics.config.json'));
const actualHash=assertFreshRequiresInventory(actual,resolve(root,'curricula/quality/cross-subject-requires/math-physics.inventory.json'));
const reviews=ledger.decisions.map((d:any)=>{
 const own=judgments.records.find((r:any)=>r.goalId===d.dependentGoalId);
 if(!own)throw new Error('Missing individual own peer judgment '+d.dependentGoalId);
 if(stableJson(own.reviewInput)!==stableJson(d.reviewInput))throw new Error('Individual baseline mismatch');
 const bindingHash=fingerprint(d.proposalBinding);
 if(bindingHash!==own.proposalBindingSha256)throw new Error('Python/native proposal FP mismatch');
 return {decisionId:d.decisionId,decision:own.peerDecision,reviewer:judgments.reviewer,
 rationale:own.rationaleDe+' Quellen-/Geltungsgrenze: '+own.sourceAndScopeBoundaryDe,
 reviewInput:d.reviewInput,proposalBindingSha256:bindingHash};
});
const review={schemaVersion:1,role:'Actual informed separate AI Requires peer review; inert and limited to exactly Fourth20 positions61–80',
 authorLedgerSha256:sha(author),inventorySha256:actualHash,decisions:reviews,
 exposureDisclosure:judgments.exposureDisclosure,individualJudgments:'twenty-individual-substantive-requires-peer-judgments.actual.json',
 ownFreshSolvedCountercases:'forty-fresh-own-solved-countercases.actual.json',
 authorSourceLedgerSha256:sha('tmp/cross-subject-requires/physics-unresolved97-whole-body-successor-author-20261013-v1/batch-004-final-v1/author-ledger.inert.json'),
 humanReviewer:false,blind:false,PKindSourceGateM7Approval:false,activeAdoption:false};
writeFileSync(resolve(out,'native-independent-requires-review.inert.json'),JSON.stringify(review,null,2)+'\n');
const result=validateRequiresDecisions(actual,ledger,{familyIds:['canonical-gymnasium'],requireComplete:false,
 independentReview:review,authorLedgerSha256:sha(author),inventorySha256:actualHash,
 sourcePathExists:(p:string)=>existsSync(resolve(root,p))});
const checked={role:'Native technical schema/binding validation after actual20 substantive peer decisions; not scientific proof by hash',
 commandModule:'app/scripts/lib/crossSubjectRequiresReview.ts::validateRequiresDecisions',
 authorProposalPath:author,authorProposalHash:sha(author),inventoryHash:actualHash,
 individualPeerCounts:judgments.nativeReviewDecisionCounts,result,fourth20Examined:20,remaining17PeerReviewed:false,
 activeWrites:false,PKindSourcePlacementM7HumanApproval:false,createdAtUTC:new Date().toISOString()};
writeFileSync(resolve(out,'native-independent-requires-validation.actual.json'),JSON.stringify(checked,null,2)+'\n');
console.log(JSON.stringify(checked));
process.exitCode=result.errors.length===0&&result.reviewed===12?0:1;
