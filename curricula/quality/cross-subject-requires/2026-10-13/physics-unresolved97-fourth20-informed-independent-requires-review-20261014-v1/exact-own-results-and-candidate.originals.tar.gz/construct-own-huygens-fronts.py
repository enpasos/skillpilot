# SPDX-License-Identifier: Apache-2.0
import json,pathlib,math,datetime
from PIL import Image,ImageDraw,ImageFont
p=pathlib.Path(__file__).resolve().parent;v=1.8;dt=.25;r=v*dt;n=(5/13,-12/13);t=(12/13,5/13);ss=[-1.2,-.6,0,.6,1.2];centres=[(s*t[0],s*t[1])for s in ss];touches=[(x+r*n[0],y+r*n[1])for x,y in centres]
assert all(math.isclose(5*x-12*y,13*r,abs_tol=1e-12)for x,y in touches)
R=1.1;angles=[math.pi*k/3 for k in range(6)];cc=[(R*math.cos(a),R*math.sin(a))for a in angles];ct=[((R+r)*math.cos(a),(R+r)*math.sin(a))for a in angles]
assert all(math.isclose(math.hypot(x,y),R+r,abs_tol=1e-12)for x,y in ct)
im=Image.new('RGB',(1600,880),'white');draw=ImageDraw.Draw(im);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',22);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
def xy(z,origin,scale=150):return(origin[0]+scale*z[0],origin[1]-scale*z[1])
def circle(z,rr,origin,color,width=2):
 x,y=xy(z,origin);a=150*rr;draw.ellipse((x-a,y-a,x+a,y+a),outline=color,width=width)
left=(390,420);right=(1190,420)
draw.text((40,35),'Own fresh Huygens construction: v = 1.8 m/s, dt = 0.25 s, r = 0.45 m',fill='black',font=font)
draw.text((80,110),'Plane front: 5x - 12y = 0',fill='black',font=font)
for c,h in zip(centres,touches):circle(c,r,left,'#888888');draw.ellipse(tuple([xy(c,left)[0]-4,xy(c,left)[1]-4,xy(c,left)[0]+4,xy(c,left)[1]+4]),fill='black');draw.ellipse(tuple([xy(h,left)[0]-5,xy(h,left)[1]-5,xy(h,left)[0]+5,xy(h,left)[1]+5]),fill='#006fbd')
for offset,color,w in [(0,'black',3),(r,'#006fbd',4)]:
 ends=[(s*t[0]+offset*n[0],s*t[1]+offset*n[1])for s in [-1.8,1.8]];draw.line([xy(z,left)for z in ends],fill=color,width=w)
a=xy((0,0),left);b=xy((r*n[0],r*n[1]),left);draw.line([a,b],fill='#a33',width=3);draw.text((left[0]+30,left[1]+85),'normal distance = 0.45 m',fill='#a33',font=small)
draw.text((80,680),'Five independently chosen centres and forward tangencies.',fill='black',font=small);draw.text((80,720),'Envelope: 5x - 12y = 5.85; joining centres keeps old front.',fill='black',font=small)
draw.text((900,110),'Circular front: R = 1.1 m to R + r = 1.55 m',fill='black',font=font)
circle((0,0),R,right,'black',3)
for c,h in zip(cc,ct):circle(c,r,right,'#aaaaaa');x,y=xy(h,right);draw.ellipse((x-5,y-5,x+5,y+5),fill='#006fbd')
circle((0,0),R+r,right,'#006fbd',4);draw.text((900,680),'Outward envelope is tangent to all six secondary circles.',fill='black',font=small);draw.text((900,720),'Unequal local speeds require unequal radii; no matter transport.',fill='black',font=small)
path=p/'own-huygens-plane-and-circular-construction.actual.png';im.save(path)
report={'executedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'v_m_s':v,'dt_s':dt,'r_m':r,'plane':{'lineCoefficients':[5,-12,0],'unitNormal':n,'unitTangent':t,'chosenCentres':centres,'forwardTangencies':touches,'newLineConstant':13*r,'perpendicularDistance_m':r,'actualDrawnElementarCircles':5},'circular':{'initialR_m':R,'outwardR_m':R+r,'chosenCentres':cc,'forwardTangencies':ct,'actualDrawnElementarCircles':6},'mediumAssumptions':['homogeneous','isotropic','forward propagation branch selected'],'inhomogeneityCounterexample':{'localSpeed_m_s':[1.8,.9],'sameInterval_radii_m':[.45,.225],'equalRadiusUniversalFrontInvalid':True},'image':str(path),'physicalExperimentOrLearnerMastery':False,'noOriginalGoalImageCopied':True}
(p/'own-huygens-plane-and-circular-construction.actual.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'fivePlaneCirclesActuallyConstructed':True,'sixCircularFrontSecondaryCircles':True,'planeNewLine':13*r,'circularNewR':R+r,'image':str(path)}))
