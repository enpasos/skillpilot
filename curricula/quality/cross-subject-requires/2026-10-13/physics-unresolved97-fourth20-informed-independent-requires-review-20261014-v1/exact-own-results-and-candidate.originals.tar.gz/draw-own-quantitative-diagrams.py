# SPDX-License-Identifier: Apache-2.0
import pathlib,os,json,math,hashlib
p=pathlib.Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(p/'plot-tool-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
records=[]
def save(fig,name,content):
 target=p/name;fig.savefig(target,dpi=160);plt.close(fig);b=target.read_bytes();records.append({'path':name,'bytes':len(b),'sha256':'sha256:'+hashlib.sha256(b).hexdigest(),'scientificContent':content,'data':'Reviewer synthetic model, no physical experiment'})
t=[i*1.4/1000 for i in range(1001)]
x=[.04*math.cos(5*s)-.03*math.sin(5*s) for s in t];v=[-.2*math.sin(5*s)-.15*math.cos(5*s) for s in t]
fig,ax=plt.subplots(2,1,figsize=(10,7),sharex=True)
ax[0].plot(t,x,label='x = 0.04 cos(5t) - 0.03 sin(5t)');ax[0].scatter([0],[.04]);ax[0].set_ylabel('x / m');ax[0].legend();ax[0].set_title('Own ideal oscillator: x(0)=0.04 m, v(0)=-0.15 m/s')
ax[1].plot(t,v,color='darkorange',label='v = -0.2 sin(5t) - 0.15 cos(5t)');ax[1].scatter([0],[-.15]);ax[1].set_ylabel('v / (m/s)');ax[1].set_xlabel('t / s');ax[1].legend()
for a in ax:a.grid();a.axhline(0,color='gray',lw=.5)
fig.tight_layout();save(fig,'own-70-oscillator-function-and-derivative.actual.png','1001 analytic samples; two initial conditions; frequency5rad/s; derivative slope and zero crossings separated')
fig,ax=plt.subplots(figsize=(10,6));ax.scatter([.8,1.6,2.4],[.04,.079,.118],s=55,label='Supplied paired raw points');ax.set(xlabel='U / V',ylabel='I / A',title='Own documentation case: actual paired points; no exact fit or uncertainty invented');ax.grid();ax.legend();fig.tight_layout();save(fig,'own-66-paired-electrical-documentation.actual.png','Raw paired observations plotted; quotients20/20.253/20.339ohm; no unsupported exact origin-line inference')
fig,ax=plt.subplots(figsize=(10,6));ax.plot([6,7,8,9,10],[1.4,3.1,4.6,2.2,1.1],'-o',label='A sampled amplitude');ax.plot([6,7,8,9,10],[1.2,1.5,1.7,1.6,1.3],'-o',label='B sampled amplitude');ax.axhline(2.3,ls='--',label='half sampled A maximum');ax.axhline(.85,ls='--',label='half sampled B maximum');ax.set(xlabel='f / Hz',ylabel='amplitude / mm',title='Own synthetic sparse response: connecting lines are guides; true peaks not determined');ax.grid();ax.legend();fig.tight_layout();save(fig,'own-74-sparse-quantitative-curves.actual.png','Fresh five-frequency curves, each normalized only against own sample maximum; B half-height boundaries absent')
(p/'own-quantitative-diagram-bindings.actual.json').write_text(json.dumps({'diagrams':records,'physicalExperimentsPerformed':False,'noPOrVOrHumanApproval':True},indent=2)+'\n');print(json.dumps({'actualDiagrams':len(records),'files':[r['path'] for r in records]}))
