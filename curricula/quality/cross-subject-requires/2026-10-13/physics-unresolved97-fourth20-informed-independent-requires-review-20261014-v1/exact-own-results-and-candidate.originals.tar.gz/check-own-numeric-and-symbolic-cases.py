# SPDX-License-Identifier: Apache-2.0
import json,pathlib,math,datetime
from fractions import Fraction as F
p=pathlib.Path(__file__).resolve().parent
data=json.loads((p/'forty-fresh-own-solved-countercases.actual.json').read_text());checks=[]
def eq(a,b):
 if isinstance(b,list):return len(a)==len(b) and all(eq(x,y) for x,y in zip(a,b))
 if isinstance(b,bool):return a is b
 return math.isclose(float(a),float(b),rel_tol=1e-10,abs_tol=1e-12)
def check(i,expected,why):
 row=data['probes'][i];r=row['calculatedResults'];ok=all(eq(r[k],v) for k,v in expected.items());checks.append({'probeId':row['probeId'],'check':why,'passed':ok,'independentExpectedResults':expected});assert ok,row['probeId']
check(0,{'r_m':1.8/4,'newLineConstant':13*1.8/4,'circleCount':5},'vΔt and normal length13; actual five circle/tangent construction checked separately')
check(1,{'outerRadius_m':1.1+1.8/4,'slowLocalRadius_m':.9/4,'circularCentres':6},'Outward circular Minkowski radius and two local speeds')
check(2,{'reflection_us':(18.5+43.5)/2,'oneWay_us':(43.5-18.5)/2},'Equal round-trip legs')
check(3,{'reflection_us':(4.2+10.6)/2,'oneWay_us':(10.6-4.2)/2},'Fresh time midpoint')
check(4,{'rates':[720*2**(-t/5) for t in [5,10,15,2.5]]},'Continuous exponential model including noninteger t/T')
check(5,{'netRates':[x-15 for x in [95,55,35]],'nextGrossRate':20/2+15,'normalizedFirstGross':190/2},'Rate normalization before background subtraction')
check(6,{'T_K':(.7*1400/(4*.7*5.67e-8))**.25},'Radiative incident disk versus emitting sphere residual')
check(7,{'Tnew_K':(.7*1400/(4*.35*5.67e-8))**.25,'temperatureRatio':2**.25},'Emissivity transfer inverse fourth root')
check(8,{'omega':1/math.sqrt(.125*50e-6),'currentAmplitude_A':45e-6*400,'energy_J':.5*.125*.018**2},'LC coefficient, derivative amplitude and independent magnetic energy balance')
check(9,{'C_F':1/(.8*300**2),'qAmplitude_C':.027/300,'energy_J':.5*(90e-6)**2/(1/(.8*300**2))},'Inverse LC and independent capacitor energy')
check(10,{'periods_s':[float(F(str(x))/8) for x in [14.4,14.8,14.6]],'mean_s':float(sum(F(str(x)) for x in [14.4,14.8,14.6])/24),'range_s':float((F('14.8')-F('14.4'))/8)},'Exact rational timing mean and spread')
check(11,{'R_ohm':[float(F(str(u))/F(str(i))) for u,i in zip([.8,1.6,2.4],[.04,.079,.118])]},'Exact paired electrical quotients')
check(12,{'energies_kWh':[80*600/1000,16*600/1000],'savingFraction':1-16/80},'Equal-service power/time comparison')
check(13,{'useful_kJ':.6*4.18*75,'input_kJ':[.08*3600,.11*3600],'efficiencies':[.6*4.18*75/(.08*3600),.6*4.18*75/(.11*3600)]},'Heat/input unit conversion and efficiency')
check(14,{'gross_s_inv':33/75,'background_s_inv':8/50,'net_s_inv':33/75-8/50,'net_min_inv':(33/75-8/50)*60},'Unequal-duration rates')
check(15,{'GMenergyDistinguishable':False,'secondEventInsideDeadTime':50<250},'Equal pulse height and second event inside detector dead time')
check(16,{'lobeProbabilities':[.84/2,.84/2],'outside':1-.84,'localRatio':2.4},'Symmetric regional probability and equal-volume density ratio')
check(17,{'conditionalProbabilities':[2.5/(2.5+4),4/(2.5+4)]},'Probability density times region volume')
check(18,{'A_m':math.hypot(.04,-.15/5),'phase_rad':math.atan2(.15/5,.04),'T_s':2*math.pi/5},'Two initial conditions converted to independent amplitude/phase form')
check(19,{'A_m':.35/7,'T_s':2*math.pi/7,'shiftedCosPhase':-math.pi/2+2*math.pi/8,'decliningPeaksFitUndamped':False},'Time-origin phase plus constant-envelope boundary')
check(20,{'energies_Wh':[11*3.5,17*3.5],'difference_Wh':(17-11)*3.5},'Lighting energy comparison')
check(21,{'dailySurplus_Wh':48-36,'nightGuaranteed':False},'Total balance does not create storage')
check(22,{'unrounded_ohm':float(F('11.5')/F('.74')),'reported_ohm':16},'Independent exact quotient and two significant digits')
check(23,{'unroundedSpeed':float(F('23.2')/F('3.5')),'guardedEnergy_J':float(F('.757')*(F('23.2')/F('3.5'))**2/2),'earlyEnergy_J':float(F('.757')*F('6.6')**2/2),'reportedGuarded_J':17,'reportedEarly_J':16},'Exact rational guard-digit counterexample with correctly rounded intermediate')
check(24,{'changes_J_K':[-180/600,180/300],'total_J_K':180*(1/300-1/600),'reverseTotal':-180*(1/300-1/600)},'Signed heat-reservoir entropy sum')
check(25,{'totals_J_K':[float(sum(F(str(x)) for x in row)) for row in [[-.25,.25],[-.25,.4],[-.4,.25]]]},'Exact signed complete budgets')
check(26,{'M_at_one':[1/(2*z) for z in [.15,.35]],'peakLocations':[math.sqrt(1-2*z*z) for z in [.15,.35]],'peakAmplitudes':[1/math.sqrt((1-r*r)**2+(2*z*r)**2) for z in [.15,.35] for r in [math.sqrt(1-2*z*z)]]},'Response formula substituted independently at supplied peak roots')
check(27,{'samplePeak_Hz':[8,8],'peakRatio':max([1.4,3.1,4.6,2.2,1.1])/max([1.2,1.5,1.7,1.6,1.3]),'halfAmplitudeThresholds':[4.6/2,1.7/2],'fullWidthKnown':False},'Sample maxima and unbracketed B boundaries')
check(28,{'ropeWork_J':7*2.4*math.cos(math.pi/3),'frictionWork_J':-2.5*2.4,'deltaK_J':7*2.4*math.cos(math.pi/3)-2.5*2.4},'Actual projection and signed net work')
check(29,{'signedAreas_J':[.5*1.5*8,-2*1.2],'net_J':.5*1.5*8-2*1.2,'springRelease_J':.5*120*.12**2},'Signed triangle/rectangle and spring-energy boundary')
check(30,{'masses_solar':[180**2*r/4.3e-6 for r in [6,12]],'excesses_solar':[180**2*6/4.3e-6-3e10,180**2*12/4.3e-6-5e10]},'Newtonian model enclosed mass')
check(31,{'velocities':[108/.6,108/.45],'massRatio':(.6/.45)**2,'revisedMass_solar':(108/.45)**2*12/4.3e-6},'Deprojection and squared sensitivity')
check(32,{'frequencies':[[x/sum(row) for x in row] for row in [[3,6,2,6,3],[42,136,38,143,41],[2004,7008,1990,6988,2010]]]},'Every fresh supplied batch normalized using actual sum')
check(33,{'frequencies':[x/400 for x in [32,96,144,96,32]],'retrospectivePathKnown':False},'New apparatus count normalization')
check(34,{'obliqueF_N':.25*1.6*.15*math.sin(math.pi/6),'maxF_N':.25*1.6*.15,'parallelF_N':0},'Angle-consistent force magnitude, independent vector check below')
check(35,{'slope_N_A':(.029-.009)/(1.4-.4),'B_T':(.029-.009)/(1.4-.4)/.08,'offset_N':.009-.02*.4,'wrongSingleB_T':.009/(.4*.08)},'Two-point slope removes offset, third point satisfies model')
check(36,{'emission':[2.3>=2.7,4.1>=2.7],'maxKinetic_eV':4.1-2.7},'Single-photon threshold and difference')
check(37,{'newEmissionAtOldPhoton':4.1>=4.4,'newKinetic_eV':5.2-4.4,'oldMaterialAtNewPhoton_eV':5.2-2.7},'Fresh material threshold transfer')
check(38,{'p2_kPa':120*400/320,'ratio':400/320},'Rigid sealed vessel absolute-pressure ratio')
check(39,{'pV_J':180*1000*7.5/1000,'n_mol':float(F('180000')*F('.0075')/(F('8.314')*360)),'wrongLitreFactor':1000,'celsiusErrorFactor':360/(360-273.15)},'Independent exact units and gas-law inversion')
symbolic=[]
for omega,B,C in [(5,.04,-.03),(7,0,.05),(400,45e-6,0),(300,0,90e-6)]:
 residual=max(abs((-omega**2*B*math.cos(omega*t)-omega**2*C*math.sin(omega*t))+omega**2*(B*math.cos(omega*t)+C*math.sin(omega*t))) for t in [0,.001,.019,.11,.34,.77]);symbolic.append({'omega':omega,'B':B,'C':C,'derivativeRule':'xprime=-omega B sin(omega t)+omega C cos(omega t); xdd=-omega^2 x','maxAnalyticResidual':residual,'passed':residual<1e-9})
u=data['probes'][34]['given']['obliqueCurrentUnitVector'];assert eq(sum(x*x for x in u),1) and eq(u[1],math.cos(math.pi/6));assert u[0]>0
report={'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownCasesChecked':40,'arithmeticChecks':checks,'additionalAnalyticDGLChecks':symbolic,'obliqueWireGeometryAngleConsistent':True,'allPassed':all(x['passed'] for x in checks+symbolic),'scope':'Own model arithmetic QA only, not automatic scientific Requires/P/source/human approval'}
(p/'own-numeric-and-symbolic-case-checks.actual.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'ownCasesChecked':40,'analyticDGLChecks':4,'allPassed':report['allPassed']}))
