from pathlib import Path
import json,hashlib,subprocess,datetime,shutil
n=Path(__file__).resolve().parent;r=n.parents[2];out=n/'java-execution';old=n.parent/'exact-tuple-target-authority-and-shared-root-repair-author-20261015-v1/backend-repair'
receipt=json.loads((old/'compile.actual.json').read_text());javac=receipt['javaCompiler'];java=str(Path(javac).with_name('java'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prodJars=[]
for row in receipt['dependencies']:
 p=Path(row['copied']);assert sha(p)==row['sha256'];prodJars.append(p)
sources=sorted((r/'backend/src/main/java').rglob('*.java'));(out/'production-classes').mkdir(exist_ok=True)
cmd=[javac,'-encoding','UTF-8','-cp',':'.join(map(str,prodJars)),'-d',str(out/'production-classes')]+list(map(str,sources))
p=subprocess.run(cmd,capture_output=True,text=True);(out/'compile-production.stdout.txt').write_text(p.stdout);(out/'compile-production.stderr.txt').write_text(p.stderr)
(out/'fresh451-compile.actual.json').write_text(json.dumps({'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'sourceCount':len(sources),'sources':[{'path':str(p.relative_to(r)),'sha256':sha(p)} for p in sources],'dependencies':receipt['dependencies'],'javaCompiler':javac,'mutableMainBuildClassesUsed':False,'MainGradleInvoked':False},indent=2)+'\n');assert p.returncode==0,p.stderr
patterns=['org.junit.jupiter/junit-jupiter-api','org.junit.jupiter/junit-jupiter-engine','org.junit.platform/junit-platform-engine','org.junit.platform/junit-platform-commons','org.junit.platform/junit-platform-launcher','org.assertj/assertj-core','org.apiguardian/apiguardian-api','org.opentest4j/opentest4j','org.mockito/mockito-core','net.bytebuddy/byte-buddy-agent','org.objenesis/objenesis','org.springframework/spring-test']
cache=Path('/home/enpasos/.gradle/caches/modules-2/files-2.1');testJars=[];bindings=[];(out/'dependencies').mkdir(exist_ok=True)
for group in patterns:
 paths=sorted((cache/group).rglob('*.jar'));assert len(paths)==1,(group,paths);src=paths[0];dest=out/'dependencies'/src.name
 if not dest.exists():shutil.copy2(src,dest)
 assert sha(dest)==sha(src);testJars.append(dest);bindings.append({'source':str(src),'copy':str(dest.relative_to(n)),'sha256':sha(dest)})
(out/'test-dependencies.actual.json').write_text(json.dumps(bindings,indent=2)+'\n')
cp=':'.join(map(str,[out/'production-classes']+prodJars+testJars));(out/'test-classes').mkdir(exist_ok=True)
test=n/'candidate/backend/src/test/java/com/skillpilot/backend/service/ProjectionRoleLearnerServiceTest.java'
cmd=[javac,'-cp',cp,'-d',str(out/'test-classes'),str(test),str(out/'RunScope25JUnit.java')]
p=subprocess.run(cmd,capture_output=True,text=True);(out/'compile-test.stdout.txt').write_text(p.stdout);(out/'compile-test.stderr.txt').write_text(p.stderr);assert p.returncode==0,p.stderr
methods=['exactEligibilityWithoutAuthoredTargetStaysSupportUntilPrimaryPlacementAuthorizesIt','selectedLandscapeAndNamespacedSubtreeReferencesAuthorizeTheirExactTargets','selectedTargetCannotConvertMissingDurationIntoAnExplicitNoneContext']
agent=next(p for p in testJars if p.name.startswith('mockito-core'))
cmd=[java,'-javaagent:'+str(agent),'-cp',str(out/'test-classes')+':'+cp,'RunScope25JUnit']+methods
p=subprocess.run(cmd,capture_output=True,text=True);(out/'tests-current.stdout.txt').write_text(p.stdout);(out/'tests-current.stderr.txt').write_text(p.stderr);print(p.stdout);print(p.stderr[-1500:]);print('exit',p.returncode)
(out/'tests-current.actual.json').write_text(json.dumps({'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'testClass':str(test.relative_to(n)),'testSHA256':sha(test),'methods':methods,'command':cmd,'actualJUnitPlatform':True,'freshProductionSources':len(sources),'onlyOneTestClassCompiled':True,'MainGradleOrDBWrites':False},indent=2)+'\n')
raise SystemExit(p.returncode)
