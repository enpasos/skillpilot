from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
n=Path(__file__).resolve().parent;r=n.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();node=Path(os.environ.get('SCOPE25_NODE','/home/enpasos/.npm/_npx/f8fe74dae8f28233/node_modules/node/bin/node'));assert node.exists();env=dict(os.environ,PATH=str(node.parent)+os.pathsep+os.environ['PATH']);old=n.parent/'exact-tuple-production-consumer-repair-author-20261015-v1'
for row in json.loads((n/'inputs/frontend-production-source-bindings.actual.json').read_text()):assert sha(r/row['path'])==row['sha256']
for row in json.loads((n/'CANDIDATE-FILES.actual.json').read_text())['files']:
 assert sha(n/'candidate'/row['path'])==row['candidateSHA256']
 if row['baselineSHA256']:assert sha(r/row['path'])==row['baselineSHA256']
receipts=[]
def setup(destination,predecessor=False):
 app=n/destination/'app';shutil.copytree(r/'app/src',app/'src',dirs_exist_ok=True)
 for rel in ['package.json','tsconfig.json','tsconfig.app.json','tsconfig.node.json','eslint.config.js','scripts/viteTestServer.ts','scripts/fixtures/learnerCoreStartupUi.html','scripts/fixtures/learnerCoreStartupUi.tsx','scripts/fixtures/learnerViewStartupUi.html','scripts/fixtures/learnerViewStartupUi.tsx']:
  dest=app/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/'app'/rel,dest)
 for src in (n/'candidate/app').rglob('*'):
  if src.is_file():dest=app/src.relative_to(n/'candidate/app');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
 if not (app/'node_modules').exists():(app/'node_modules').symlink_to(r/'app/node_modules',target_is_directory=True)
 if predecessor:
  for rel in ['src/hooks/useAppCore.ts','src/utils/treeProjectionRuntime.ts','src/views/LearnerView.tsx']:shutil.copy2(old/'candidate/app'/rel,app/rel)
  (app/'scripts/runExactScopeTargetsOnly.ts').write_text("import { chromium } from 'playwright'\nimport { assertExactScopeTargetTrees } from './assertExactScopeTargetsUi'\nconst browser = await chromium.launch({headless:true})\ntry { await assertExactScopeTargetTrees(browser) } finally { await browser.close() }\n")
 else:
  (app/'tsconfig.scope-test.json').write_text(json.dumps({'extends':'./tsconfig.app.json','compilerOptions':{'incremental':False,'types':['vite/client','node']},'include':['scripts/assertExactScopeTargetsUi.ts','scripts/fixtures/exactScopeTargetsUi.tsx','scripts/viteTestServer.ts','src/vite-env.d.ts']},indent=2)+'\n')
 return app

def run(label,cmd,cwd,expected):
 result=subprocess.run(list(map(str,cmd)),cwd=cwd,env=env,capture_output=True,text=True);(n/'logs'/f'{label}.stdout.log').write_text(result.stdout);(n/'logs'/f'{label}.stderr.log').write_text(result.stderr);receipts.append({'label':label,'command':list(map(str,cmd)),'cwd':str(cwd),'exitCode':result.returncode,'expectedExitCode':expected,'stdout':f'logs/{label}.stdout.log','stderr':f'logs/{label}.stderr.log'});assert result.returncode==expected,result.stdout+result.stderr;return result
current=setup('execution');run('browser-ci-chain-current',['npm','run','test:learner-cockpit-startup'],current,0)
run('eslint',[node,'node_modules/eslint/bin/eslint.js','scripts/assertExactScopeTargetsUi.ts','scripts/testLearnerCoreStartupUi.ts','scripts/testLearnerViewStartupUi.ts','scripts/fixtures/exactScopeTargetsUi.tsx'],current,0)
run('typecheck',[node,'node_modules/typescript/bin/tsc','--project','tsconfig.scope-test.json'],current,0)
prior=setup('execution-predecessor',True);result=run('browser-predecessor',[node,'node_modules/tsx/dist/cli.mjs','scripts/runExactScopeTargetsOnly.ts'],prior,1)
assert 'Exact scope target tree passed: missing-duration' in result.stdout
for name in ['combined: combined: source-authorized Math goal','supplement-only: supplement-only: source-authorized Math goal']:assert name in result.stderr
assert '0 !== 1' in result.stderr and 'page errors:' not in result.stderr
(n/'FRONTEND-TESTS.actual.json').write_text(json.dumps({'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'currentCIChainPassed':True,'newMountedCases':['combined','supplement-only','missing-duration'],'productionPath':'useAppCore -> actual LearnerView -> CompetenceTree -> buildVisibleChildrenMap','predecessorExpectedFails':['combined source-authorized Math goal hidden','supplement-only source-authorized Math goal hidden'],'predecessorControlPass':'missing-duration','sourceCopyCount':303,'productionFilesModified':0,'APIIsolation':'All new fixture /api requests intercepted locally; non-GET returns405; no live backend or learner writes.','noNewDependencyOrWorkflow':True,'node':str(node),'nodeVersion':subprocess.check_output([node,'--version'],text=True).strip(),'checks':receipts,'candidateFiles':json.loads((n/'CANDIDATE-FILES.actual.json').read_text())['files']},indent=2)+'\n')
print('Current full CI cockpit chain, new-file TSC and changed-file ESLint pass; predecessor fails both original mounted tree counterexamples.')
