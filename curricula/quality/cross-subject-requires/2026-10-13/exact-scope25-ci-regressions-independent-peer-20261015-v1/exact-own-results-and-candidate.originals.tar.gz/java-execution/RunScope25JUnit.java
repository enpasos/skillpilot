import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import java.io.PrintWriter;

public class RunScope25JUnit {
    public static void main(String[] args) {
        var request = LauncherDiscoveryRequestBuilder.request();
        String type = "com.skillpilot.backend.service.ProjectionRoleLearnerServiceTest";
        for (String method : args) request.selectors(DiscoverySelectors.selectMethod(type, method));
        var listener = new SummaryGeneratingListener();
        LauncherFactory.create().execute(request.build(), listener);
        var summary = listener.getSummary();
        summary.printTo(new PrintWriter(System.out, true));
        summary.printFailuresTo(new PrintWriter(System.out, true));
        if (summary.getTestsFoundCount() != args.length || summary.getTestsSucceededCount() != args.length) System.exit(1);
    }
}
