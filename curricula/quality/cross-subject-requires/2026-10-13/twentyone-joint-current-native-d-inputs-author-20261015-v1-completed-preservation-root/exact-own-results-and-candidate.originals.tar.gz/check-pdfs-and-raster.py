# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,struct,subprocess
L=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
def bind(p):return {'path':str(p.relative_to(L)),'bytes':p.stat().st_size,'sha256':'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()}
commands=[];groups=[]
for group in ['twenty','one']:
    native=L/'native-artifacts'/group;pdf=native/'bundle/book.pdf';manifest=load(native/'bundle/book.pdf.render-manifest.json');model=load(native/'bundle/book-model.json');out=L/'pdf-pages'/group;out.mkdir(parents=True)
    for tag,argv in [('info',['pdfinfo',str(pdf)]),('text',['pdftotext','-layout',str(pdf),str(out/'book.txt')]),('raster',['pdftoppm','-r','100','-png',str(pdf),str(out/'page')])]:
        started=datetime.now(timezone.utc).isoformat();r=subprocess.run(argv,capture_output=True)
        stdout=L/'raw'/f'pdf-{group}-{tag}.stdout.txt';stderr=L/'raw'/f'pdf-{group}-{tag}.stderr.txt';stdout.write_bytes(r.stdout);stderr.write_bytes(r.stderr)
        commands.append({'argv':argv,'startedUTC':started,'completedUTC':datetime.now(timezone.utc).isoformat(),'actualExitCode':r.returncode,'stdout':bind(stdout),'stderr':bind(stderr)});assert r.returncode==0, r.stderr
    info=(L/'raw'/f'pdf-{group}-info.stdout.txt').read_text();physical=manifest['physicalPageCount'];assert f'Pages:           {physical}' in info
    pages=(out/'book.txt').read_text().split('\f');assert len(pages)==physical+1 and not pages[-1].strip()
    rasters=sorted(out.glob('page-*.png'));assert len(rasters)==physical
    rows=[]
    for i,p in enumerate(rasters):
        raw=p.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n';width,height=struct.unpack('>II',raw[16:24]);assert width>700 and height>1000
        rows.append({'physicalPageNumber':i+1,'raster':bind(p),'width':width,'height':height})
    for page in model['pages']:
        index=manifest['frontMatterPageCount']+page['pageNumber']-1
        assert page['goalId'] in pages[index],(group,page['goalId'],index)
        rows[index]['goalId']=page['goalId'];rows[index]['nativeGoalPageNumber']=page['pageNumber'];rows[index]['fullGoalIdPresentInOwnPhysicalPDFPage']=True
    groups.append({'group':group,'PDF':bind(pdf),'extractedPDFText':bind(out/'book.txt'),'physicalPageCount':physical,'frontMatterPageCount':manifest['frontMatterPageCount'],'goalPageCount':manifest['goalPageCount'],'pages':rows,'samePDFUsedForBothCampaignRounds':True})
result={'contract':'twentyone-actual-native-PDF-page-and-raster-binding-v1','checkedUTC':datetime.now(timezone.utc).isoformat(),'groups':groups,'commands':commands,'nativeGoalPageTotal':sum(g['goalPageCount'] for g in groups),'physicalPageTotal':sum(g['physicalPageCount'] for g in groups),'newDJudgments':0}
(L/'PDF-PAGES-AND-RASTERS.actual.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'actualGoalPages':result['nativeGoalPageTotal'],'physicalPDFPagesAndRasters':result['physicalPageTotal'],'bothGroupsExactFullGoalIDOnEachOwnPage':True,'newDJudgments':0}))
