// SPDX-License-Identifier: Apache-2.0
// Audit only. Preserves native pipeline input and output semantics.
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto'),url=require('node:url');
const sync=fs.readFileSync,promise=fsp.readFile,callback=fs.readFile;
const root=process.env.TWENTYONE_AUDIT_ROOT,out=process.env.TWENTYONE_AUDIT_OUTPUT,reads=new Map();
function capture(value){try{
 const input=value instanceof URL?url.fileURLToPath(value):Buffer.isBuffer(value)?value.toString():value;
 if(typeof input!=='string')return;
 const p=path.resolve(input),rel=path.relative(root,p);
 if(rel.startsWith('..')||path.isAbsolute(rel)||!rel||rel.includes('node_modules')||rel.includes('/native-D/')||rel.includes('/.goal-description-')||!fs.statSync(p).isFile())return;
 const bytes=sync(p),row={path:rel,realPath:fs.realpathSync(p),bytes:bytes.length,sha256:'sha256:'+crypto.createHash('sha256').update(bytes).digest('hex')};
 const prior=reads.get(rel);if(prior&&prior.sha256!==row.sha256)throw Error('Native input drift '+rel);reads.set(rel,row);
}catch(e){if(e.message?.startsWith('Native input drift'))throw e;}}
fs.readFileSync=function(p,...args){const value=sync.call(this,p,...args);capture(p);return value;};
fsp.readFile=async function(p,...args){const value=await promise.call(this,p,...args);capture(p);return value;};
fs.readFile=function(p,...args){const cb=args.pop();return callback.call(this,p,...args,(error,value)=>{if(!error)capture(p);cb(error,value);});};
require('node:module').syncBuiltinESMExports();
process.on('exit',()=>{if(!root||!out)return;fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'reads-'+process.pid+'.json'),JSON.stringify({pid:process.pid,argv:process.argv,workspace:root,reads:[...reads.values()]},null,2)+'\n');});
