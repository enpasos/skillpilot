# SPDX-License-Identifier: Apache-2.0
"""Small exact native-artifact schema/parsing and portability checks only."""
from pathlib import Path
import json,hashlib
from datetime import datetime,timezone
from jsonschema import Draft202012Validator,FormatChecker
from referencing import Registry,Resource
LANE=Path(__file__).resolve().parent;WORK=LANE/'workspace';NATIVE=LANE/'native-artifacts'
def load(p):return json.loads(p.read_text())
def bind(p):return {'path':str(p.relative_to(LANE)),'bytes':p.stat().st_size,'sha256':'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()}
schemas={}
for family in ['goal-description-review','goal-book','goal-evidence']:
 for p in (WORK/'contracts'/family).rglob('*.schema.json'):
  d=load(p)
  if '$id' in d:schemas[d['$id']]=d
registry=Registry().with_resources((k,Resource.from_contents(v)) for k,v in schemas.items())
validated=[];parsed_json=[];parsed_jsonl=[]
for p in NATIVE.rglob('*'):
 if not p.is_file():continue
 if p.suffix=='.json':
  d=load(p);parsed_json.append(bind(p));schema_id=d.get('$schema')
  if schema_id in schemas:
   errors=list(Draft202012Validator(schemas[schema_id],registry=registry,format_checker=FormatChecker()).iter_errors(d));assert not errors,(str(p),[e.message for e in errors]);validated.append({'artifact':bind(p),'schemaId':schema_id})
 elif p.suffix=='.jsonl':
  count=0
  for line in p.read_text().splitlines():
   if line.strip():json.loads(line);count+=1
  parsed_jsonl.append({'artifact':bind(p),'records':count})
assert len(validated)>=8
curriculum_links=[str(p.relative_to(WORK)) for p in (WORK/'curricula').rglob('*') if p.is_symlink()];assert curriculum_links==[]
for group in ['twenty','one']:
 for r in ['round-a','round-b']:assert list((NATIVE/group/r/'results').iterdir())==[]
result={'contract':'bounded-twentyone-native-artifact-schema-parse-check-v1','checkedUTC':datetime.now(timezone.utc).isoformat(),'schemaValidatedArtifacts':validated,'parsedJSONFiles':len(parsed_json),'parsedJSONLArtifacts':parsed_jsonl,'workspaceCurriculumSymlinks':curriculum_links,'resultDirectoriesEmpty':True,'fullLandscapeSchemaOrQAEngineRun':False,'newDReviewClaims':0}
(LANE/'checks/native-artifact-schema-check.actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'schemaValidatedArtifacts':len(validated),'parsedJSONFiles':len(parsed_json),'parsedJSONLFiles':len(parsed_jsonl),'curriculumSymlinks':0,'emptyResultDirectories':4}))
