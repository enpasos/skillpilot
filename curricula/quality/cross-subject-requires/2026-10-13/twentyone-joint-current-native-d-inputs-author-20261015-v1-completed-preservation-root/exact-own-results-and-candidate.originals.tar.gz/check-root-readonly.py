# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from datetime import datetime, timezone
import errno, hashlib, json, os
R = Path('/home/enpasos/projects/skillpilot')
L = Path(__file__).resolve().parent
existing = R/'tmp/cross-subject-requires/guard-readonly-namespace-selfcheck-root-20261015-v1/outside-private-lane.canary'
new = R/'tmp/cross-subject-requires/twentyone-native-d-outside-negative-20261015-v1.must-not-exist'
assert existing.is_file() and not new.exists()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
paths = [existing, R/'.git/index', R/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json', R/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json', R/'curricula/DE/Gymnasium/quality/release-model/physik.semantic-kinds.json']
before = {str(p.relative_to(R)):sha(p) for p in paths}
denials = []
for p, flags in [(existing,os.O_WRONLY|os.O_APPEND), (new,os.O_WRONLY|os.O_CREAT|os.O_EXCL)]:
    try:
        fd=os.open(p,flags,0o600); os.close(fd)
        raise AssertionError('External write unexpectedly allowed')
    except OSError as e:
        assert e.errno==errno.EROFS, e
        denials.append({'path':str(p.relative_to(R)), 'errno':e.errno, 'code':errno.errorcode[e.errno]})
positive=L/'positive-private-write.canary'; positive.write_text('owned lane write succeeds\n')
assert positive.read_text()=='owned lane write succeeds\n'
assert before=={str(p.relative_to(R)):sha(p) for p in paths} and not new.exists()
template=R/'tmp/cross-subject-requires/run-guard-regressions-with-root-readonly-20261015-v1.py'
assert sha(template)=='73d3d4f1e0630f38990370aec7012fba8ab9fef4a6a95c33c4c30a3f76f1990e'
result={'contract':'twentyone-native-inputs-os-root-readonly-canary-v1','checkedUTC':datetime.now(timezone.utc).isoformat(),'externalExistingAndNewWritesDenied':denials,'ownPrivateWriteSucceeded':True,'beforeAfterBindings':before,'allBeforeAfterExact':True,'wrapperTemplate':{'path':str(template.relative_to(R)),'sha256':sha(template)},'onlyWritableRepositoryPath':str(L),'wrapperSha256':sha(L/'run-root-readonly.py')}
(L/'ROOT-READONLY-NAMESPACE-CANARY.actual.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
