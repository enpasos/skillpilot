// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict'
import { readFileSync,writeFileSync,mkdirSync } from 'node:fs'
import { resolve,dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { loadGoalBookBuildInputs,fingerprintSemanticKindSourceGoal } from './workspace/app/scripts/goalBookModel'
import { loadRegisteredCurrentPositiveEvidenceOwners } from './workspace/app/scripts/currentPositiveEvidenceOwners'
const lane=dirname(fileURLToPath(import.meta.url)),work=resolve(lane,'workspace'),pack='curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/twentyone-joint-current-native-d-inputs-v1'
const load=(p:string)=>JSON.parse(readFileSync(p,'utf8')),save=(p:string,v:any)=>{mkdirSync(dirname(p),{recursive:true});writeFileSync(p,JSON.stringify(v,null,2)+'\n')}
assert(load(resolve(lane,'FINAL-18-PEER.observed.actual.json')).observedBeforeNativePrepare)
const frozen=load(resolve(lane,'ACTUAL-KIND-AND-P-OWNERS.before-Book.actual.json')),rollout=load(resolve(work,frozen.rootConfig)),summaries:any[]=[]
for(const subject of rollout.subjects.filter((s:any)=>['mathematik','physik'].includes(s.subject))){
 const landscape=load(resolve(work,subject.landscapePath)),kind=load(resolve(work,subject.semanticKindLedgerPath)),atomic=new Set<string>(kind.decisions.filter((k:any)=>k.semanticKind==='curricularAtomic').map((k:any)=>k.goalId))
 assert.equal(atomic.size,subject.subject==='physik'?478:807)
 const result=loadRegisteredCurrentPositiveEvidenceOwners({landscapePath:subject.landscapePath,landscapeId:landscape.landscapeId,semanticKindLedgerPath:subject.semanticKindLedgerPath,atomicGoalIds:atomic})
 assert.deepEqual(result.issues,[]);assert.equal(result.owners.size,atomic.size)
 if(subject.subject==='physik')for(const row of frozen.actualOwners){
   const owner=result.owners.get(row.goalId);assert(owner);assert.equal(owner.configPath,row.PConfigPath);assert.deepEqual(owner.record,row.PRecord)
   assert.deepEqual(landscape.goals.find((g:any)=>g.id===row.goalId),row.canonicalGoal);assert.equal(row.kindDecision.sourceFingerprint,fingerprintSemanticKindSourceGoal(row.canonicalGoal))
   if(['09029573-864f-40ca-bf8a-cee7bf6dcb73','d18d4190-ddc1-5181-b1b6-e79947b737c2'].includes(row.goalId))assert.deepEqual(owner.config.reviewedResourceTypes,[])
 }
 summaries.push({subject:subject.subject,fullAtomicCount:atomic.size,normalValidatedUniqueCurrentOwners:result.owners.size,issues:result.issues})
}
const base=await loadGoalBookBuildInputs(pack+'/base-goal-book.config.json');assert.equal(base.model.pages.length,478)
const ids=new Set<string>(frozen.actualOwners.map((r:any)=>r.goalId)),ordered=base.model.pages.map((p:any)=>p.goalId).filter((id:string)=>ids.has(id));assert.equal(ordered.length,21)
const original=load(resolve(work,pack,'batch.config.json')),groups=[]
for(const [index,goalIds] of [ordered.slice(0,20),ordered.slice(20)].entries()){
 const label=index===0?'twenty':'one',config={...original,batchId:`physik-joint-current-${label}-contexts-20261015-v1`,bookId:`physik-joint-current-${label}-contexts-20261015-v1`,title:`Physik – aktuelle gemeinsame P-Kontexte (${index+1}/2)`,goalIds,outputDirectory:pack+`/native-D-${label}`}
 const path=pack+`/batch-${label}.config.json`;save(resolve(work,path),config);groups.push({group:label,goalIds,configPath:path,outputDirectory:config.outputDirectory})
}
save(resolve(lane,'SUPPORTED-20-PLUS-1-GROUPS.actual.json'),{contract:'twentyone-unchanged-native-20-plus-1-split-v1',createdUTC:new Date().toISOString(),failed21AttemptRetained:true,closedMax20Unchanged:true,fullBasisAtomicCount:478,normalFullBasisBookDigest:base.model.digest,ordered21GoalIds:ordered,groups,newDJudgments:0})
save(resolve(lane,'checks/current-whole-goal-kind-P-input-checks.actual.json'),{contract:'twentyone-current-native-normal-owner-check-v1',checkedUTC:new Date().toISOString(),fullRegisteredSources:summaries,selectedWholeOwnersExact:21,selectedKindFingerprintsCurrent:21,optionalResourcePolicyPreservedFor090AndD18:true,requiredTaskMaterialBoundByNormalFullPValidation:true,newPAuthorRecords:0,newDJudgments:0})
console.log(JSON.stringify({fullRegisteredSources:summaries,fullBasisBookPages:base.model.pages.length,supportedGroups:groups.map(g=>({group:g.group,goals:g.goalIds.length})),selectedWholeOwnersExact:21,newDJudgments:0}))
