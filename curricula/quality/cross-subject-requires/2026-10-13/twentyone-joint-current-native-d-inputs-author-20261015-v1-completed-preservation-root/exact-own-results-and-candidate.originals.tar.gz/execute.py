# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,subprocess,sys
R=Path('/home/enpasos/projects/skillpilot');L=Path(__file__).resolve().parent
name=sys.argv[1];assert '/' not in name
args=sys.argv[2:];cwd=L
if args[0]=='--cwd':cwd=Path(args[1]);args=args[2:]
env=os.environ.copy();pop=R/'tmp/ci-tools/poppler-root/usr'
env['PATH']=str(R/'tmp/ci-tools/node-v20.20.2-linux-x64/bin')+os.pathsep+str(pop/'bin')+os.pathsep+env['PATH']
env['LD_LIBRARY_PATH']=str(pop/'lib/x86_64-linux-gnu')+os.pathsep+env.get('LD_LIBRARY_PATH','');env['XDG_DATA_HOME']=str(R/'tmp/ci-tools/xdg');env['TMPDIR']='/tmp'
if name.startswith(('native-prepare','native-check')):
    assert (L/'FINAL-18-PEER.observed.actual.json').is_file()
    env['TWENTYONE_AUDIT_ROOT']=str(L/'workspace');env['TWENTYONE_AUDIT_OUTPUT']=str(L/'native-read-traces'/name);env['NODE_OPTIONS']='--require='+str(L/'trace_reads.cjs')
start=datetime.now(timezone.utc).isoformat();(L/'raw').mkdir(exist_ok=True);o=L/'raw'/f'{name}.stdout.txt';e=L/'raw'/f'{name}.stderr.txt'
with o.open('wb') as out,e.open('wb') as err:result=subprocess.run(args,cwd=cwd,env=env,stdout=out,stderr=err)
def bind(p):return {'path':str(p.relative_to(L)),'bytes':p.stat().st_size,'sha256':'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()}
receipt={'argv':args,'cwd':str(cwd),'startedUTC':start,'completedUTC':datetime.now(timezone.utc).isoformat(),'actualExitCode':result.returncode,'stdout':bind(o),'stderr':bind(e),'OSRootReadonly':True,'onlyWritableRepositoryPath':str(L),'environmentOverrides':{k:v for k,v in env.items() if k in ['PATH','LD_LIBRARY_PATH','XDG_DATA_HOME','TMPDIR','TWENTYONE_AUDIT_ROOT','TWENTYONE_AUDIT_OUTPUT','NODE_OPTIONS']}}
(L/f'{name}.execution.actual.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(o.read_text());print(e.read_text());sys.exit(result.returncode)
