# SPDX-License-Identifier: Apache-2.0
"""Create a physically confined current capsule and freeze whole input owners."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil
R=Path('/home/enpasos/projects/skillpilot');L=Path(__file__).resolve().parent;W=L/'workspace'
J=R/'tmp/cross-subject-requires/current-physics-next-joint-candidate-root-20261015-v1'
E=J/'execution-root';V=J/'candidate-v2'
F='curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
P='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'
M='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
PACK='curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/twentyone-joint-current-native-d-inputs-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def bind(p):return {'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)}
assert load(L/'ROOT-READONLY-NAMESPACE-CANARY.actual.json')['ownPrivateWriteSucceeded']
assert sha(J/'CANDIDATE.v2.actual.json')=='a840b2a1fec3027f74c1bcd9487b3d40b79f0a7437e187da33beb3bfc1b6a014'
candidate=load(J/'CANDIDATE.v2.actual.json');assert len(candidate['files'])==228
assert not W.exists()
records=[]
for row in candidate['files']:
    rel=row['target'];assert sha(E/rel)==sha(V/rel)==row['candidate']['sha256'],rel
shutil.copytree(E,W,symlinks=True)
for p in sorted(E.rglob('*')):
    if p.is_file():records.append({**bind(p),'snapshot':'workspace/'+str(p.relative_to(E)),'mode':'readonly-dependency-link' if p.is_symlink() else 'exact-joint-execution-source-copy'})
def copy_missing(p, dest=None):
    dest=dest or W/p.relative_to(R)
    if dest.exists():return
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
    records.append({**bind(p),'snapshot':str(dest.relative_to(L)),'mode':'exact-root-required-input-copy'})
for directory in ['contracts/goal-description-review','contracts/semantic-kind','contracts/curriculum-package']:
    for p in (R/directory).rglob('*'):
        if p.is_file():copy_missing(p)
for rel in ['AGENTS.md','LICENSING.md','LICENSE','LICENSES/CC-BY-4.0.txt','app/package-lock.json','app/tsconfig.json','curricula/DE/Gymnasium/quality/goal-visualization-qa/physik.qa.json','curricula/DE/Gymnasium/quality/goal-evidence/prompts/goal-description-understanding-evidence-review-v2.md','curricula/DE/Gymnasium/quality/goal-evidence/prompts/physics-goal-description-understanding-evidence-review-criteria-v1.md']:
    copy_missing(R/rel)
manifest=load(W/'app/scripts/config/goal-books/de-gym-physics-national-atlas.sources.json')
for rel in manifest['sourcePaths']+[manifest['durationModelPolicyPath'],manifest['navigationViewPath']]:copy_missing(R/rel)
for rel in ['app/node_modules','app/src','app/public/assets/goal-visualizations']:
    assert (W/rel).is_symlink() and (W/rel).resolve()==(R/rel).resolve()
assert not any(p.is_symlink() for p in (W/'curricula').rglob('*'))
(L/'node_modules').symlink_to(R/'app/node_modules',target_is_directory=True)
config=load(W/F);phys=next(s for s in config['subjects'] if s['subject']=='physik')
author=R/'tmp/cross-subject-requires/gymnasium-i02-i05-eighteen-current-integration-author-20261015-v1/HANDOFF.actual.json'
ids=sorted(load(author)['goalIds']+['09029573-864f-40ca-bf8a-cee7bf6dcb73','b2fb9a25-4d26-5cf2-a917-823909dcb6bd','d18d4190-ddc1-5181-b1b6-e79947b737c2'])
assert len(ids)==len(set(ids))==21 and 'f82784b3-26e7-5dc3-9a02-814f17b5e03b' not in ids
goals=load(W/P)['goals'];byid={g['id']:g for g in goals};kind=load(W/phys['semanticKindLedgerPath']);kd={k['goalId']:k for k in kind['decisions']}
allowners={}; configs={}
for cp in phys['positiveEvidenceConfigPaths']:
    pc=load(W/cp);configs[cp]=pc
    for gid in pc['scope']['goalIds']:allowners.setdefault(gid,[]).append(cp)
assert len(allowners)==478 and all(len(x)==1 for x in allowners.values())
actual=[]
for gid in ids:
    cp=allowners[gid][0];pc=configs[cp];rp=pc['reviewPath'];owners=[json.loads(line) for line in (W/rp).read_text().splitlines() if line.strip()];matches=[v for v in owners if v['goalId']==gid];assert len(matches)==1
    record=matches[0];assert kd[gid]['semanticKind']=='curricularAtomic'
    deps=[]
    for dep in byid[gid].get('requires',[]):
        found=[{'landscapePath':rel,'goal':g} for rel in [P,M] for g in load(W/rel)['goals'] if g['id']==dep];assert len(found)==1;deps.extend(found)
    row={'goalId':gid,'canonicalGoal':byid[gid],'kindDecision':kd[gid],'PConfigPath':cp,'PReviewPath':rp,'PRecord':record}
    actual.append(row)
    write(L/'content'/f'{gid}.neutral-current-context.json',{'contract':'neutral-current-whole-goal-kind-P-review-source-v1','goalId':gid,'currentCanonicalGoal':byid[gid],'currentKindDecision':kd[gid],'currentRegisteredPConfig':pc,'currentWholePRecord':record,'directPrerequisiteWholeGoals':deps,'reviewInstruction':'Use the exact assigned native round as authoritative. Read the entire bilingual goal, Kind, whole P, relations and supplied resources. No new D keep/revise opinion is supplied.'})
base=load(W/'app/scripts/config/goal-books/de-gym-physics-national-atlas.json')
base['evidenceReviewPaths']=list(dict.fromkeys(r['PReviewPath'] for r in actual));base['evidenceReviewConfigPaths']=list(dict.fromkeys(r['PConfigPath'] for r in actual));base['outputPath']=PACK+'/full-478-basis.book-model.json'
write(W/PACK/'base-goal-book.config.json',base)
batch={'$schema':'https://skillpilot.com/schemas/goal-description-review/v1/goal-description-rollout-batch-config.schema.json','schemaVersion':1,'batchId':'physik-twentyone-joint-current-whole-p-contexts-20261015-v1','subject':'physik','subjectLabel':'Physik','bookId':'physik-twentyone-joint-current-whole-p-contexts-20261015-v1','title':'Physik – 21 aktuelle gemeinsame P-Kontexte','baseGoalBookConfigPath':PACK+'/base-goal-book.config.json','goalIds':ids,'outputDirectory':PACK+'/native-D','feedbackBaseUrl':'https://skillpilot.com/api/goal-feedback','promptPath':'curricula/DE/Gymnasium/quality/goal-evidence/prompts/goal-description-understanding-evidence-review-v2.md','criteriaPath':'curricula/DE/Gymnasium/quality/goal-evidence/prompts/physics-goal-description-understanding-evidence-review-criteria-v1.md','publicRoot':'app/public','printDerivativeProfile':'bounded-atlas'}
write(W/PACK/'batch.config.json',batch)
write(L/'ACTUAL-KIND-AND-P-OWNERS.before-Book.actual.json',{'contract':'twentyone-actual-current-whole-goal-kind-P-owners-before-book-v1','createdUTC':datetime.now(timezone.utc).isoformat(),'rootConfig':F,'jointCandidate':bind(J/'CANDIDATE.v2.actual.json'),'candidatePhysics':bind(W/P),'candidateMathematics':bind(W/M),'fullPhysicsAtomicBasis':478,'actualOwners':actual,'newPAuthorRecords':0,'newDKeepClaims':0})
plan=R/'tmp/cross-subject-requires/astra-current-p-native-d-freshness-guard-plan-20261015-v1/preservation.before.actual.json'
before=load(plan)
assert len(before['scienceBindings'])==737 and len(before['viewBindings'])==348
for row in before['scienceBindings']+before['viewBindings']:assert sha(R/row['path'])==row['sha256'],row['path']
assert sha(R/'.git/index')==before['indexSha256']=='6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8'
write(L/'ROOT-PRESERVATION.before.actual.json',before)
for p in [J/'CANDIDATE.v2.actual.json',J/'joint-bounded-validation.actual.json',J/'joint-validation.execution.actual.json',author]:copy_missing(p,L/'inputs'/p.relative_to(R))
for p in [R/'docs/concept/skill-graph/learning-goal-book-and-evidence-review-pipeline.md',R/'tmp/cross-subject-requires/merged-guard-transport-and-volume-independent-peer-20261015-v1/CODE-REVIEW.actual.json']:copy_missing(p,L/'inputs'/p.relative_to(R))
for rel in ['curricula/DE/Gymnasium/task-material/physik/cuboid-rulers-1ffdd7f06dd21af0222d3ce1bd6b1f6408bd04ae05b1651e4a703a980ab5e289.svg','app/public/assets/task-material/physik/cuboid-rulers-1ffdd7f06dd21af0222d3ce1bd6b1f6408bd04ae05b1651e4a703a980ab5e289.svg']:
    assert (W/rel).is_file() and not (W/rel).is_symlink() and sha(W/rel)=='1ffdd7f06dd21af0222d3ce1bd6b1f6408bd04ae05b1651e4a703a980ab5e289'
write(L/'INPUT-BINDINGS.actual.json',{'contract':'twentyone-exact-copied-input-bindings-v1','createdUTC':datetime.now(timezone.utc).isoformat(),'records':records,'candidateFilesVerified':228,'immutableDependencyLinks':['workspace/app/node_modules','workspace/app/src','workspace/app/public/assets/goal-visualizations','node_modules'],'allRootAndOtherLanesOSReadonly':True})
print(json.dumps({'exactInputBindings':len(records),'selectedWholeGoalKindPOwners':len(actual),'fullPhysicsCurrentOwners':len(allowners),'nativePrepareExecuted':False,'newDJudgments':0}))
