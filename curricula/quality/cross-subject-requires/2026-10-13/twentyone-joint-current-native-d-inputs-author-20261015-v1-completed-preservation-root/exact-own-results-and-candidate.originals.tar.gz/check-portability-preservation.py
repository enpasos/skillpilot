# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json
R=Path('/home/enpasos/projects/skillpilot');L=Path(__file__).resolve().parent;W=L/'workspace'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
spec=importlib.util.spec_from_file_location('normal_skillpilot_schema_validator',R/'scripts/validate_schemas.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
normal=mod.curriculum_symlink_errors(R);assert normal==[],normal
links=[str(p.relative_to(W)) for p in (W/'curricula').rglob('*') if p.is_symlink()];assert links==[]
artifacts=[p for p in (L/'native-artifacts').rglob('*') if p.is_file()];assert not any(p.is_symlink() for p in artifacts)
before=load(L/'ROOT-PRESERVATION.before.actual.json')
for row in before['scienceBindings']+before['viewBindings']:assert sha(R/row['path'])==row['sha256'],row['path']
assert sha(R/'.git/index')==before['indexSha256']=='6590754da8fa7a96703a630fd004fcb28978e5e1e18af447dcf24a7b77c6d9e8'
candidate=load(L/'inputs/tmp/cross-subject-requires/current-physics-next-joint-candidate-root-20261015-v1/CANDIDATE.v2.actual.json')
for row in candidate['files']:assert sha(W/row['target'])==row['candidate']['sha256'],row['target']
for group in ['twenty','one']:
 for round in ['round-a','round-b']:
  assert list((L/'native-artifacts'/group/round/'results').iterdir())==[]
  output=W/'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/twentyone-joint-current-native-d-inputs-v1'/f'native-D-{group}'/round/'results';assert list(output.iterdir())==[]
for p in (L/'native-artifacts').rglob('*'):
 if p.suffix=='.json' and p.is_file():load(p)
 if p.suffix=='.jsonl' and p.is_file():
  for line in p.read_text().splitlines():
   if line.strip():json.loads(line)
result={'contract':'twentyone-native-final-portability-and-source-preservation-v1','checkedUTC':datetime.now(timezone.utc).isoformat(),'normalRootCurriculumSymlinkErrors':normal,'normalValidatorPath':'scripts/validate_schemas.py','normalValidatorSha256':sha(R/'scripts/validate_schemas.py'),'workspaceCurriculumSymlinks':links,'nativeArtifactsAllPhysicalRegularFiles':True,'all737RootScienceBindingsExact':True,'all348RootViewBindingsExact':True,'rootIndexSha256':sha(R/'.git/index'),'all228CurrentJointCandidateSourceFilesExact':True,'allFourNativeResultDirectoriesEmptyInSourceAndReviewCopy':True,'allWrittenNativeJSONAndJSONLParse':True,'noRootAdoption':True,'noNewDJudgments':True}
(L/'ROOT-AND-INPUT-PRESERVATION.after.actual.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
