// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict'
import { readFileSync,writeFileSync,mkdirSync,cpSync,readdirSync,statSync } from 'node:fs'
import { resolve,dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { buildGoalDescriptionCanonicalContext } from './workspace/app/scripts/validateGoalDescriptionReviewCampaign'
import { fingerprintSemanticKindSourceGoal } from './workspace/app/scripts/goalBookModel'
import { stableGoalEvidenceJson } from './workspace/app/scripts/goalEvidenceProfileModel'
import { fingerprintGoalDescriptionReviewContext } from './workspace/app/scripts/validateGoalDescriptionDualRoundResolution'
import { assertGoalDescriptionRolloutCurrentPositiveEvidence } from './workspace/app/scripts/materializeGoalDescriptionRolloutBatch'
const lane=dirname(fileURLToPath(import.meta.url)),work=resolve(lane,'workspace')
const load=(p:string)=>JSON.parse(readFileSync(p,'utf8')),sha=(v:string|Buffer)=>'sha256:'+createHash('sha256').update(v).digest('hex')
const save=(p:string,v:any)=>{mkdirSync(dirname(p),{recursive:true});writeFileSync(p,JSON.stringify(v,null,2)+'\n')},binding=(p:string)=>({path:p.slice(lane.length+1),bytes:statSync(p).size,sha256:sha(readFileSync(p))})
const frozen=load(resolve(lane,'ACTUAL-KIND-AND-P-OWNERS.before-Book.actual.json')),split=load(resolve(lane,'SUPPORTED-20-PLUS-1-GROUPS.actual.json')),actualRows:any[]=[],groups:any[]=[],reads=new Map<string,any>()
const rollout=load(resolve(work,frozen.rootConfig)),physics=rollout.subjects.find((s:any)=>s.subject==='physik'),base=load(resolve(work,'curricula/DE/Gymnasium/quality/cross-subject-requires/2026-10-15/twentyone-joint-current-native-d-inputs-v1/base-goal-book.config.json'))
for(const group of split.groups){
 const native=resolve(work,group.outputDirectory),model=load(resolve(native,'bundle/book-model.json')),bundleInput=load(resolve(native,'bundle/review-input.json')),a=load(resolve(native,'round-a/description-review-input.json')),b=load(resolve(native,'round-b/description-review-input.json')),manifest=load(resolve(native,'batch-manifest.json'))
 assert.deepEqual(a,b);assert.equal(a.goalCount,group.goalIds.length);assert.equal(model.pages.length,group.goalIds.length);assert.equal(manifest.curriculumAtomicDenominatorAtPreparation,478);assert.deepEqual(a.goals.map((g:any)=>g.goalId),group.goalIds)
 for(const round of ['round-a','round-b'])assert.deepEqual(readdirSync(resolve(native,round,'results')),[])
 for(const g of a.goals){
   const owner=frozen.actualOwners.find((r:any)=>r.goalId===g.goalId);assert(owner)
   const page=model.pages.find((p:any)=>p.goalId===g.goalId),bundlePage=bundleInput.pages.find((p:any)=>p.page.goalId===g.goalId)
   assert.deepEqual(g.canonicalContext,buildGoalDescriptionCanonicalContext(owner.canonicalGoal));assert.equal(owner.kindDecision.sourceFingerprint,fingerprintSemanticKindSourceGoal(owner.canonicalGoal))
   assert.deepEqual(g.reviewContext.evidenceProfile,owner.PRecord);assert.deepEqual(bundlePage.evidenceProfile,owner.PRecord);assert.deepEqual(g.reviewContext.page,page);assert.deepEqual(bundlePage.page,page)
   const matches=physics.positiveEvidenceConfigPaths.filter((p:string)=>load(resolve(work,p)).scope.goalIds.includes(g.goalId));assert.deepEqual(matches,[owner.PConfigPath]);assert(base.evidenceReviewPaths.includes(owner.PReviewPath));assert(base.evidenceReviewConfigPaths.includes(owner.PConfigPath))
   const records=readFileSync(resolve(work,owner.PReviewPath),'utf8').trim().split('\n').map(JSON.parse);assert.deepEqual(records.filter((r:any)=>r.goalId===g.goalId),[owner.PRecord])
   assert.deepEqual(page.evidenceReview,Object.fromEntries(['reviewId','status','reviewInputFingerprint','profileFingerprint','evidenceLevel','maximumClaimScope'].map(k=>[k,owner.PRecord[k]])))
   actualRows.push({goalId:g.goalId,group:group.group,wholeCanonicalGoalKindAndActualRegisteredPExact:true,bookBundleAndBothNativeInputsFullPExact:true,sourcePConfig:owner.PConfigPath,sourcePReviewPath:owner.PReviewPath,wholePRecordDigest:sha(stableGoalEvidenceJson(owner.PRecord)),wholePProfileDigest:sha(stableGoalEvidenceJson(owner.PRecord.profile)),pageEvidenceReviewExact:true,goalFingerprint:g.goalFingerprint,pageFingerprint:g.pageFingerprint,goalReviewContextFingerprint:fingerprintGoalDescriptionReviewContext(g),nativePageNumber:page.pageNumber})
 }
 const pdf=load(resolve(native,'bundle/book.pdf.render-manifest.json'));assert.equal(pdf.goalPageCount,group.goalIds.length);assert.equal(pdf.physicalPageCount,pdf.goalPageCount+pdf.frontMatterPageCount)
 const dest=resolve(lane,'native-artifacts',group.group);cpSync(native,dest,{recursive:true,errorOnExist:true,force:false})
 const ref=(p:string)=>binding(resolve(dest,p)),campaignA=load(resolve(native,'round-a/description-review-campaign.json')),campaignB=load(resolve(native,'round-b/description-review-campaign.json'))
 assert.notEqual(campaignA.campaignId,campaignB.campaignId);assert.notEqual(campaignA.independenceGroupId,campaignB.independenceGroupId)
 groups.push({group:group.group,goalIds:group.goalIds,fullBasisAtomicGoals:478,renderedGoalPages:group.goalIds.length,physicalPDFPages:pdf.physicalPageCount,frontMatterPages:pdf.frontMatterPageCount,batchManifest:ref('batch-manifest.json'),bookModel:ref('bundle/book-model.json'),bundleManifest:ref('bundle/manifest.json'),PDF:ref('bundle/book.pdf'),HTML:ref('bundle/book.html'),bundleWholePInput:ref('bundle/review-input.json'),normalBookDigest:a.bookDigest,normalReviewInputFingerprint:a.reviewInputFingerprint,normalBundleFingerprint:a.bundleFingerprint,rounds:[['a',campaignA],['b',campaignB]].map(([label,campaign]:any)=>({round:label,campaignId:campaign.campaignId,roundId:campaign.roundId,independenceGroupId:campaign.independenceGroupId,input:ref(`round-${label}/description-review-input.json`),campaign:ref(`round-${label}/description-review-campaign.json`),recordSchema:ref(`round-${label}/contracts/goal-description-review-record.schema.json`),batches:campaign.batches.map((batch:any)=>({...batch,input:ref(`round-${label}/batches/${batch.batchId}.input.jsonl`)})),resultsDirectory:`native-artifacts/${group.group}/round-${label}/results`,resultsEmpty:true}))})
 for(const name of [`native-prepare-${group.group}-confined-retry`,`native-check-${group.group}`])for(const file of readdirSync(resolve(lane,'native-read-traces',name)).filter(f=>f.endsWith('.json'))){
   for(const row of load(resolve(lane,'native-read-traces',name,file)).reads){
     if(row.path.includes('/native-D-'))continue
     assert.equal(sha(readFileSync(resolve(work,row.path))),row.sha256,row.path);if(reads.has(row.path))assert.equal(reads.get(row.path).sha256,row.sha256);reads.set(row.path,row)
   }
 }
}
assert.equal(actualRows.length,21);assert.equal(new Set(actualRows.map(r=>r.goalId)).size,21)
assert.deepEqual([...actualRows.map(r=>r.goalId)].sort(),[...frozen.actualOwners.map((r:any)=>r.goalId)].sort())
// Exercise the actual native boundary on a privately altered whole-P payload.
const first=split.groups[0],native=resolve(work,first.outputDirectory),model=load(resolve(native,'bundle/book-model.json')),input=load(resolve(native,'round-a/description-review-input.json'))
const altered=structuredClone(input.goals[0]);altered.reviewContext.evidenceProfile.dissent.push('private-negative-control-only')
let negativeError='';try{await assertGoalDescriptionRolloutCurrentPositiveEvidence({subject:'physik',model,baseConfig:base,preparedInputGoals:[altered]})}catch(error){negativeError=String(error)}
assert(negativeError.includes('stale full P record')&&negativeError.includes('/dissent'))
save(resolve(lane,'checks/wrong-whole-P-native-boundary-negative.actual.json'),{contract:'twentyone-current-P-native-assertion-negative-v1',checkedUTC:new Date().toISOString(),normalOwningAssertion:'assertGoalDescriptionRolloutCurrentPositiveEvidence',goalId:altered.goalId,privateMutation:'append one dissent field only in an in-memory copy',nativeRejection:negativeError,expectedRejectionObserved:true,actualSourceAndNativeInputsUnchanged:true})
save(resolve(lane,'ACTUAL-GOAL-KIND-P-NATIVE-INPUT-EQUALITY.actual.json'),{contract:'twentyone-current-normal-native-whole-input-parity-v1',checkedUTC:new Date().toISOString(),normalPreparation:true,supportedGroups:[20,1],fullSourceBasisForEachGroup:478,selectedActualGoals:21,newNativeDKeepDecisions:0,rows:actualRows})
save(resolve(lane,'native-actual-read-bindings.actual.json'),{contract:'twentyone-actual-native-read-bindings-v1',workspace:'workspace',bindings:[...reads.values()],generatedNativeArtifactsBoundSeparately:true,normalRendererAndHashContractsUnchanged:true})
save(resolve(lane,'REVIEW-INPUTS.actual.json'),{contract:'twentyone-joint-current-whole-P-native-D-review-inputs-v1',status:'GENUINE_CURRENT_NATIVE_20_PLUS_1_INPUTS_READY_FOR_TWO_INDEPENDENT_ROUNDS_AND_SYNTHESIS',selectedGoalIds:actualRows.map(r=>r.goalId),grouping:'Two unchanged normal native Prepare/Check groups (20+1), with shared PDF per group for A/B; each of21 goals appears once per round.',groups,wholeCurrentOwnersFixedBeforeBook:binding(resolve(lane,'ACTUAL-KIND-AND-P-OWNERS.before-Book.actual.json')),actualInputEquality:binding(resolve(lane,'ACTUAL-GOAL-KIND-P-NATIVE-INPUT-EQUALITY.actual.json')),currentInputChecks:binding(resolve(lane,'checks/current-whole-goal-kind-P-input-checks.actual.json')),wrongPNegative:binding(resolve(lane,'checks/wrong-whole-P-native-boundary-negative.actual.json')),nativeReadBindings:binding(resolve(lane,'native-actual-read-bindings.actual.json')),fullBasisAtomicGoals:478,totalRenderedGoalPages:21,campaigns:4,totalIndependentRoundResultDirectoriesEmpty:4,newPAuthorRecords:0,authorDKeepOrStrictCompletionClaims:0,neutralPerGoalDossiers:actualRows.map(r=>({goalId:r.goalId,group:r.group,path:`content/${r.goalId}.neutral-current-context.json`,nativePageNumber:r.nativePageNumber})),reviewInstruction:'Read the entire current bilingual goal and full whole-P profile, current Kind, prerequisites and supplied resources in the exact assigned native round. Form your own judgment; no keep/revise verdict is supplied. Historical judgments remain unchanged and are separate synthesis material.',authorityBoundary:'Native D input preparation only. No D judgments, model-diversity or human claim, host/runtime/source/selected-route/full-M7/aggregate acceptance, Root adoption, learner writes or publication.'})
console.log(JSON.stringify({actualWholeGoalKindPExactInBothRounds:actualRows.length,normalPreparedGroups:[20,1],campaigns:4,emptyResultsDirectories:4,nativeReadBindings:reads.size,wrongWholePNativeRejectionObserved:true,newDJudgments:0}))
