# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import subprocess,json,datetime,os,sys,hashlib
L=Path(__file__).resolve().parent;R=Path('/home/enpasos/projects/skillpilot');name=sys.argv[1];args=sys.argv[2:];D=L/'checks';D.mkdir(exist_ok=True);f=D/(name+'.execution.actual.json');assert not f.exists();start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(args,cwd=R/'app',env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','TSX_DISABLE_CACHE':'1'},capture_output=True);out={}
for k,v in [('stdout',p.stdout),('stderr',p.stderr)]:q=D/(name+'.'+k+'.txt');q.write_bytes(v);out[k]={'path':str(q.relative_to(L)),'bytes':len(v),'sha256':'sha256:'+hashlib.sha256(v).hexdigest()}
f.write_text(json.dumps({'argv':args,'cwd':str(R/'app'),'startedUTC':start,'completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'RootOSReadOnlyEnforcedByCaller':True,'normalActualRootSourcesAndScripts':True,**out},indent=2)+'\n');print(p.stdout.decode()[:3500]);print(p.stderr.decode()[:2000]);raise SystemExit(p.returncode)
