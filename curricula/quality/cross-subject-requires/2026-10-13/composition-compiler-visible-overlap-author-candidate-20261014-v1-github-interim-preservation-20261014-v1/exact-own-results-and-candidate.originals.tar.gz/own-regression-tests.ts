// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {compileCompositionView as mainCompile} from '../../../app/src/utils/authoring/compositionViewAuthoring.ts';
import {compileCompositionView as candidateCompile} from './source/app/src/utils/authoring/compositionViewAuthoring.ts';
const out=dirname(fileURLToPath(import.meta.url));
const observed=JSON.parse(readFileSync(resolve(out,'../combined-profile-runtime-v5-informed-independent-technical-recheck-20261014-v1/v5-own-cases.actual.json'),'utf8'));
const witness=observed.cases.find((r:any)=>r.caseId==='own-common-exclusion-overlap-only-in-nontarget-shared');
const graph=witness.canonicalGraph;
const landscape={landscapeId:'review',title:'Compiler author regression fixture',goals:Object.entries(graph).map(([id,children])=>({id,title:id+' competency',description:'Technical fixture only',contains:children,requires:[],type:(children as any[]).length?'cluster':'atomic',weight:1,tags:[]}))};
const ref=(goalId:string,role?:string,kind='canonicalSubtree')=>({kind,goalId,...(role?{projectionRole:role}:{})});
const wrap=(id:string,children:any[])=>({kind:'structure',id,label:id,children});
const partial=[wrap('left-location',[ref('left')]),wrap('right-location',[ref('right')])];
const records:any[]=[];
const flatten=(nodes:any[],result:string[]=[]):string[]=>{for(const n of nodes){if(n.sourceGoalId)result.push(n.sourceGoalId);flatten(n.children??[],result);}return result;};
function test(caseId:string,roots:any[],expectedCodes:string[],expectedVisible:string[],mainFalsePositive=false){
 const view={viewId:caseId,landscapeId:'review',scope:{schoolForm:'Gymnasium',stage:'SekII',courseProfile:'GK+LK'},rootNodes:roots};
 const before=JSON.stringify({view,landscape}),old=mainCompile(view as any,landscape as any),fresh=candidateCompile(view as any,landscape as any);
 const codes=new Set(fresh.findings.filter(f=>f.severity==='error').map(f=>f.code));
 assert.deepEqual([...codes].sort(),[...expectedCodes].sort(),caseId);
 assert.deepEqual(flatten(fresh.compiledRootNodes).sort(),[...expectedVisible].sort(),caseId);
 assert.deepEqual(fresh.compiledRootNodes,old.compiledRootNodes,caseId+' projection unchanged');
 assert.equal(JSON.stringify({view,landscape}),before,caseId+' inputs unchanged');
 if(mainFalsePositive){assert(old.findings.some(f=>f.code==='CPV-004'&&f.severity==='error'));assert(!fresh.findings.some(f=>f.code==='CPV-004'));}
 records.push({caseId,candidateErrorCodes:[...codes],candidateFindings:fresh.findings,mainFindings:old.findings,actualCompiledVisibleGoalIds:flatten(fresh.compiledRootNodes),compiledProjectionUnchanged:true,inputsUnchanged:true,passed:true});
}
test('actual-v5-two-target-roots-with-common-direct-shared-exclusion',witness.returnedRoots,[],['left','left-only','right','right-only'],true);
test('real-visible-partial-overlap-remains-blocked',partial,['CPV-004','CPV-005','CPV-006'],['left','left-only','shared','right','right-only','shared']);
test('equal-specificity-direct-target-keeps-shared-visible',[...partial,ref('shared','prerequisiteOnly','goalEntry'),ref('shared','target','goalEntry')],['CPV-004','CPV-005','CPV-006'],['left','left-only','shared','right','right-only','shared','shared']);
test('wholly-prerequisite-only-overlap-is-invisible',[wrap('left-support',[ref('left','prerequisiteOnly')]),wrap('right-support',[ref('right','prerequisiteOnly')])],[],[]);
test('true-duplicate-canonical-root-remains-blocked',[wrap('one-location',[ref('left')]),wrap('two-location',[ref('left')])],['CPV-004','CPV-005','CPV-006'],['left','left-only','shared','left','left-only','shared']);
test('missing-reference-still-blocked',[wrap('missing-location',[ref('absent')])],['CPV-002'],[]);
test('invalid-role-still-blocked',[wrap('invalid-role',[ref('left','visible')])],['CPV-008'],[]);
test('shared-visible-direct-entries-still-blocked',[wrap('one-location',[ref('shared','target','goalEntry')]),wrap('two-location',[ref('shared','target','goalEntry')])],['CPV-005','CPV-006'],['shared','shared']);
writeFileSync(resolve(out,'own-meaningful-regressions.actual.json'),JSON.stringify({role:'Actual AUTHOR regression validation of private compiler correction; independent review pending',cases:records,passed:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({actualMeaningfulCases:records.length,allAssertionsPassed:true,oldCommonExclusionFalsePositiveConfirmed:true,projectionAndSourceRolesUnchanged:true}));
