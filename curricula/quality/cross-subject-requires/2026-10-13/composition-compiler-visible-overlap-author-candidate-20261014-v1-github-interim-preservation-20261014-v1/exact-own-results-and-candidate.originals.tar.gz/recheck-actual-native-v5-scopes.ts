// SPDX-License-Identifier: Apache-2.0
import {readFileSync,writeFileSync,existsSync,readdirSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {compileCompositionView as originalCompile} from '../../../app/src/utils/authoring/compositionViewAuthoring.ts';
import {compileCompositionView as candidateCompile} from './source/app/src/utils/authoring/compositionViewAuthoring.ts';
const out=dirname(fileURLToPath(import.meta.url)),root=process.cwd();
const matrix='tmp/cross-subject-requires/whole-physics-native-stage-course-route-audit-20261014-v2/native-matches.v5-visible-overlap-guard.actual.json';
const canonicalRoot=resolve(root,'tmp/cross-subject-requires/whole-physics-native-stage-course-route-audit-20261014-v2/regular-candidate-inputs/curricula/DE/Gymnasium/canonical');
const sha=(bytes:Buffer|string)=>'sha256:'+createHash('sha256').update(bytes).digest('hex');
const bindings:any[]=[];
const read=(path:string)=>{const b=readFileSync(path);bindings.push({path,bytes:b.length,sha256:sha(b)});return JSON.parse(b.toString());};
const documents=read(resolve(root,matrix)),landscapes=new Map<string,any>();
for(const name of readdirSync(canonicalRoot).filter(n=>n.endsWith('.json'))){const landscape=read(resolve(canonicalRoot,name));landscapes.set(landscape.landscapeId,landscape);}
const universe={landscapeId:'own-native-v5-universe',title:'Exact two-subject parent native scope graph',goals:[...landscapes.values()].flatMap(l=>l.goals)};
const rows:any[]=[];
for(const doc of documents){
 if(!doc.actualProductionMatcherInvoked||!doc.matchedView)throw new Error('Missing actual source document');
 const landscape=landscapes.get(doc.landscapeId);if(!landscape)throw new Error('Missing exact graph '+doc.landscapeId);
 const before=JSON.stringify(doc),original=originalCompile(doc.matchedView,landscape,universe,landscapes),candidate=candidateCompile(doc.matchedView,landscape,universe,landscapes);
 const oldTree=JSON.stringify(original.compiledRootNodes),newTree=JSON.stringify(candidate.compiledRootNodes);
 if(oldTree!==newTree||before!==JSON.stringify(doc))throw new Error('Projection/source mutation '+doc.key);
 rows.push({key:doc.key,viewId:doc.matchedView.viewId,subject:doc.subject,requestedScope:doc.requestedScope,compiledProjectionUnchanged:true,compiledTreeSha256:sha(newTree),originalErrors:original.findings.filter(f=>f.severity==='error'),candidateErrors:candidate.findings.filter(f=>f.severity==='error'),originalWarnings:original.findings.filter(f=>f.severity==='warning').length,candidateWarnings:candidate.findings.filter(f=>f.severity==='warning').length});
}
for(const b of bindings){if(sha(readFileSync(b.path))!==b.sha256)throw new Error('Input changed during scope checks '+b.path);}
const errors=rows.filter(r=>r.candidateErrors.length);const report={role:'Actual AUTHOR recheck using parent production Java v5 returned167scope documents and their exact original two-subject graph; no new provider/runtime invocation or source acceptance claim',checkedAtUTC:new Date().toISOString(),bindings,actualScopeDocuments:rows.length,allCompiledProjectionsUnchanged:true,viewsWithCandidateErrors:errors.length,totalCandidateErrors:rows.reduce((n,r)=>n+r.candidateErrors.length,0),totalOriginalErrors:rows.reduce((n,r)=>n+r.originalErrors.length,0),rows,SourcePDScIM7HumanOrAdoptionApproval:false};
const target=resolve(out,'actual-parent-native-v5-scopes-compiler-recheck.actual.json');if(existsSync(target))throw new Error('Additive output exists');writeFileSync(target,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({actualScopeDocuments:rows.length,allCompiledProjectionsUnchanged:true,viewsWithCandidateErrors:errors.length,totalOriginalErrors:report.totalOriginalErrors,totalCandidateErrors:report.totalCandidateErrors}));process.exitCode=errors.length?1:0;
