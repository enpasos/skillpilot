import datetime
import gzip
import hashlib
import json
from pathlib import Path

B = Path('tmp/physics-cqr104-consistent-stage-projection-20261115')
epochs = {'ee9829': B / 'final841-api-ui', '721585': B / 'after-cache841-api-ui', 'b391f6': B / 'boundary-b391-api-ui'}
digests = {'ee9829': 'ee9829cba17fe1cb8414a7c003fa9ed538278ab49ca1fce911a0ed710541923e',
           '721585': '721585772259388d11c4b6f1e6539099c375e6527828d62369acd6df6539e52c',
           'b391f6': 'b391f6a72d6fee14cc5836cd42ad9a46f30ff9dbc07b23a5dd7e0f47c7467173'}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
records = {epoch: {row['id']: row for row in json.loads(gzip.decompress((directory / 'api-ui-maps.actual.json.gz').read_bytes()))['reports']} for epoch, directory in epochs.items()}
assert all(len(rows) == 72 and rows.keys() == records['b391f6'].keys() for rows in records.values())
goal_by_id = {goal['id']: goal for path in Path('curricula/DE/Gymnasium/canonical').glob('*.json') for goal in json.loads(path.read_text())['goals']}


def metrics(row):
    first, deep = row['maps'][0], row['maps'][-1]
    top = [edge for board in first['backward'] if board['boardId'] == '__learner_goal_map_root__' for edge in board['backward']]
    inner = [edge for board in deep['backward'] if board['boardId'] != '__learner_goal_map_root__' for edge in board['backward']]
    causes = lambda edges: {(cause['dependentGoalId'], cause['requiredGoalId']) for edge in edges for cause in edge['provenance']}
    return {'S': len(row['seedAtomicGoalIds']), 'L': len(row['learningAtomicGoalIds']),
            'topArrows': first['topBackward'], 'topAtomicCauses': causes(top),
            'innerArrows': deep['nestedBackward'], 'innerAtomicCauses': causes(inner),
            'outside': set(first['outsideUnitAtomicGoalIds'])}


comparisons = {}
for baseline in ['ee9829', '721585']:
    rows = []
    for context_id, before in records[baseline].items():
        after = records['b391f6'][context_id]
        a, z = metrics(before), metrics(after)
        delta = {'id': context_id, 'authorization': after['authorization'], 'scope': after['scope']}
        for field in ['S', 'L', 'topArrows', 'innerArrows']:
            delta[field + 'Before'], delta[field + 'After'] = a[field], z[field]
        for prefix, field in [('seed', 'seedAtomicGoalIds'), ('learning', 'learningAtomicGoalIds')]:
            added, removed = sorted(set(after[field]) - set(before[field])), sorted(set(before[field]) - set(after[field]))
            delta[prefix + 'Added'], delta[prefix + 'Removed'] = added, removed
            delta[prefix + 'OrdinaryAdded'] = [goal_id for goal_id in added if not goal_by_id[goal_id].get('examData')]
            delta[prefix + 'OrdinaryRemoved'] = [goal_id for goal_id in removed if not goal_by_id[goal_id].get('examData')]
        for field in ['topAtomicCauses', 'innerAtomicCauses', 'outside']:
            delta[field + 'Added'], delta[field + 'Removed'] = sorted(z[field] - a[field]), sorted(a[field] - z[field])
        delta['progressBefore'], delta['progressAfter'] = before['progressDenominators'], after['progressDenominators']
        delta['completeMapFieldsEqual'] = before['maps'] == after['maps']
        delta['visibleRootsEqual'] = before['actualVisibleRootIds'] == after['actualVisibleRootIds']
        delta['exactScopeProgressAndMapInvariant'] = all(not delta[key] for key in ['seedAdded', 'seedRemoved', 'learningAdded', 'learningRemoved']) and delta['progressBefore'] == delta['progressAfter'] and delta['completeMapFieldsEqual'] and delta['visibleRootsEqual']
        rows.append(delta)
    comparisons[baseline + ' -> b391f6'] = rows

current = []
for row in records['b391f6'].values():
    values = metrics(row)
    current.append({'id': row['id'], 'authorization': row['authorization'], 'scope': row['scope'], 'S': values['S'], 'L': values['L'],
                    'topArrows': values['topArrows'], 'topDistinctAtomicCauses': len(values['topAtomicCauses']),
                    'innerArrows': values['innerArrows'], 'innerDistinctAtomicCausesAcrossBoards': len(values['innerAtomicCauses']),
                    'outside': len(values['outside']), 'progressDenominators': row['progressDenominators']})
national = [row for row in current if row['id'].startswith('canonical:')]
assert len(national) == 3 and all(row['topArrows'] == 0 and row['outside'] == 0 for row in national)
pins = json.loads((epochs['b391f6'] / 'source-pins.actual.json').read_text())
assert pins['allPinsUnchangedAtEnd']
for path, digest in pins['pins'].items():
    assert sha(Path(path)) == digest, path
result = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'FRESH_NATIVE72_API_UI_MAPPING_BOUNDARY_FINAL_CHECKPOINT',
          'canonicalEpochs': digests, 'nativeReadOnlyExports': 72, 'inputPinsUnchangedDuringExportAndAtFinalCheck': 190,
          'sourceSeal': {'path': str(B / 'boundary-b391-source-seal.actual.json'), 'sha256': sha(B / 'boundary-b391-source-seal.actual.json')},
          'comparisons': comparisons, 'currentRows': current, 'nationalCurrent': national,
          'policyConflictingContexts': [row['id'] for row in current if row['authorization'] == 'unsupported-subject-duration-policy-disagreement'],
          'interpretation': 'Same actual native API and corrected UI runner. S/L and numerical progress changes are measured, not inferred from cache labels. Top and inner atomic causes are separate counts. Existing inner/regional findings remain open. No source, view, code or learner-result writes.',
          'artifacts': [{'path': str(epochs['b391f6'] / filename), 'sha256': sha(epochs['b391f6'] / filename)} for filename in ['api-inputs.json.gz', 'api-ui-maps.actual.json.gz', 'summary.actual.json', 'source-pins.actual.json']]}
output = B / 'boundary-b391-final72-receipt.actual.json'
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('SHA', sha(output))
for baseline, rows in comparisons.items():
    print(baseline, 'invariant', sum(row['exactScopeProgressAndMapInvariant'] for row in rows),
          'scopeChanged', sum(bool(row['seedAdded'] or row['seedRemoved'] or row['learningAdded'] or row['learningRemoved']) for row in rows),
          'newBackflowOrOutside', sum(bool(row['topAtomicCausesAdded'] or row['innerAtomicCausesAdded'] or row['outsideAdded']) for row in rows))
print('NATIONAL', national)
