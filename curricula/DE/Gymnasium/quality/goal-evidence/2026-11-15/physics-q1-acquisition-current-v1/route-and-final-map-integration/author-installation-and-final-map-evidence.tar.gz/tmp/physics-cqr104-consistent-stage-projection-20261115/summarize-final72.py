import datetime
import gzip
import hashlib
import json
from pathlib import Path

B = Path('tmp/physics-cqr104-consistent-stage-projection-20261115')
O = Path('tmp/physics-by-g9-current840-preparation-placement-20261115')
epochs = {
    'main647-current-ui': O / 'main647-api-ui',
    'main647-historical-ui': O / 'main647-with-main-ui',
    'before809-current-ui': O / 'before809-final-api-ui',
    'before-last-route-fix6a77': O / 'after6a77-neutral-final-api-ui',
    'final841': B / 'final841-api-ui',
}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
reports = {key: json.loads(gzip.decompress((path / 'api-ui-maps.actual.json.gz').read_bytes()))['reports'] for key, path in epochs.items()}


def causes(edges):
    return sorted({(cause['dependentGoalId'], cause['requiredGoalId']) for edge in edges for cause in edge.get('provenance', [])})


def row(source):
    maps = source.get('maps', [])
    if not maps:
        return {'id': source['id'], 'status': source.get('status'), 'error': source.get('error')}
    top = min(maps, key=lambda item: item['step'])
    deep = max(maps, key=lambda item: item['step'])
    top_board = next((board for board in top['backward'] if board['boardId'] == '__learner_goal_map_root__'), {'backward': []})
    inner = [{'boardId': board['boardId'], 'title': board['title'], 'arrows': len(board['backward']),
              'distinctAtomicCauses': len(causes(board['backward'])), 'atomicCauses': causes(board['backward'])}
             for board in deep['backward'] if board['boardId'] != '__learner_goal_map_root__' and board['backward']]
    inner_causes = causes([edge for board in deep['backward'] if board['boardId'] != '__learner_goal_map_root__' for edge in board['backward']])
    top_causes = causes(top_board['backward'])
    return {'id': source['id'], 'authorization': source['authorization'], 'scope': source['scope'],
            'S': len(source['seedAtomicGoalIds']), 'L': len(source['learningAtomicGoalIds']), 'maxStep': deep['maxStep'],
            'topArrows': top['topBackward'], 'topDistinctAtomicCauses': len(top_causes), 'topAtomicCauses': top_causes,
            'innerArrows': deep['nestedBackward'], 'innerBoardsWithBackflows': len(inner),
            'innerDistinctAtomicCausesAcrossBoards': len(inner_causes), 'innerAtomicCauses': inner_causes, 'innerBoards': inner,
            'outside': len(top['outsideUnitAtomicGoalIds']), 'outsideGoalIds': top['outsideUnitAtomicGoalIds'],
            'progressDenominators': source['progressDenominators']}


rows = {key: [row(source) for source in sources] for key, sources in reports.items()}
indexed = {key: {source['id']: source for source in sources} for key, sources in rows.items()}
raw = {key: {source['id']: source for source in sources} for key, sources in reports.items()}
comparisons = {}
for baseline in ['main647-current-ui', 'before809-current-ui', 'before-last-route-fix6a77']:
    deltas = []
    for context_id, before in indexed[baseline].items():
        if context_id not in indexed['final841']:
            continue
        after = indexed['final841'][context_id]
        before_raw, after_raw = raw[baseline][context_id], raw['final841'][context_id]
        delta = {'id': context_id, 'authorization': after['authorization'], 'SDelta': after['S'] - before['S'], 'LDelta': after['L'] - before['L']}
        for name, field in [('seed', 'seedAtomicGoalIds'), ('learning', 'learningAtomicGoalIds')]:
            delta[name + 'Added'] = sorted(set(after_raw[field]) - set(before_raw[field]))
            delta[name + 'Removed'] = sorted(set(before_raw[field]) - set(after_raw[field]))
        for name, field in [('topArrows', 'topArrows'), ('topCauses', 'topDistinctAtomicCauses'), ('innerArrows', 'innerArrows'), ('innerDistinctCauses', 'innerDistinctAtomicCausesAcrossBoards'), ('outside', 'outside')]:
            delta[name + 'Before'], delta[name + 'After'] = before[field], after[field]
        for name, field in [('topCauses', 'topAtomicCauses'), ('innerCauses', 'innerAtomicCauses')]:
            a, z = set(map(tuple, before[field])), set(map(tuple, after[field]))
            delta[name + 'Added'], delta[name + 'Removed'] = sorted(z - a), sorted(a - z)
        a, z = set(before['outsideGoalIds']), set(after['outsideGoalIds'])
        delta['outsideAdded'], delta['outsideRemoved'] = sorted(z - a), sorted(a - z)
        deltas.append(delta)
    comparisons[baseline + ' -> final841'] = deltas

national = [source for source in rows['final841'] if source['authorization'] == 'national-canonical-no-Land-plan-or-duration-claim']
unsupported = [source for source in rows['final841'] if source['authorization'] == 'unsupported-subject-duration-policy-disagreement']
supported = [source for source in rows['final841'] if source not in unsupported]
assert len(national) == 3 and all(source['topArrows'] == 0 and source['outside'] == 0 for source in national)
assert len(rows['final841']) == 72 and len(unsupported) == 12
last = comparisons['before-last-route-fix6a77 -> final841']
result = {
    'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'FINAL_CURRENT72_ACTUAL_API_UI_MEASURED',
    'canonicalPhysicsSha256': json.loads((B / 'final-source-seal.actual.json').read_text())['canonicalPhysicsSha256'],
    'sourceSeal': {'path': str(B / 'final-source-seal.actual.json'), 'sha256': sha(B / 'final-source-seal.actual.json')},
    'method': 'Identical current actual native API/UI reader and helpers across curriculum comparisons. Same actual Overview-root and visible-child selection; read-only synthetic learner repository. National/[Land] CQR compatibility materialization is not claimed as an actual hybrid UI path.',
    'counting': 'Top summary arrows, atomic dependent/required cause pairs and inner boards are separate measures. Inner cause union is deduplicated across boards; do not sum it with top causes. Nested compatibility sections are not accepted new authored Land/year plans.',
    'baselineBoundary': 'Main647-current-ui compares Main647 curriculum with current API/current corrected UI, not deployed-main. Main647-historical-ui uses historical helper bytes with current API; maxStep0 means no comparable temporal board, not a clean map. Prior41/512 diagnostics used wrong all-catalog/fake-root inputs and remain retracted.',
    'rows': rows, 'comparisons': comparisons, 'nationalCurrent': national, 'supportedContextCount': len(supported),
    'unsupportedDiagnosticContextCount': len(unsupported), 'unsupportedDiagnosticContexts': unsupported,
    'supportedCurrentRegionalBackflowContexts': [source['id'] for source in supported if source['topArrows']],
    'supportedCurrentOutsideContexts': [source['id'] for source in supported if source['outside']],
    'lastFixRegressions': [delta for delta in last if delta['topCausesAdded'] or delta['innerCausesAdded'] or delta['outsideAdded']],
    'artifacts': [{'epoch': key, 'path': str(path / name), 'sha256': sha(path / name)} for key, path in epochs.items() for name in ['api-ui-maps.actual.json.gz', 'summary.actual.json']],
}
output = B / 'final72-api-ui-comparison.actual.json'
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('SHA', sha(output))
print('NATIONAL', [(source['id'], source['S'], source['L'], source['topArrows'], source['topDistinctAtomicCauses'], source['innerArrows'], source['innerDistinctAtomicCausesAcrossBoards'], source['outside']) for source in national])
print('REGRESSIONS', len(result['lastFixRegressions']), 'SUPPORTED', len(supported), 'regionalTop', len(result['supportedCurrentRegionalBackflowContexts']), 'outside', len(result['supportedCurrentOutsideContexts']))
print('LASTFIX', [{key: delta[key] for key in ['id', 'SDelta', 'LDelta', 'topArrowsBefore', 'topArrowsAfter', 'innerArrowsBefore', 'innerArrowsAfter', 'outsideBefore', 'outsideAfter']} for delta in last if delta['id'].startswith('canonical:')])
