import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

repository = Path.cwd()
directory = Path(sys.argv[1])
seal_path = Path(sys.argv[2])
directory.mkdir(exist_ok=True)
seal = json.loads(seal_path.read_text())
pins = {pin['path']: pin['sha256'] for pin in seal['pins']}
pin_file = directory / 'source-pins.actual.json'
pin_file.write_text(json.dumps({'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pins': pins, 'sourceSealPath': str(seal_path)}, indent=2) + '\n')
classpath = (repository / 'tmp/physics-by-g9-current840-preparation-placement-20261115/native-source-probe.classpath.txt').read_text().strip()
args = ['java', '-Xmx2400m', '-cp', classpath, 'ExportApiInputs', str(repository), str(repository / 'tmp/stage-map-f6-current-20261115/after840-crossstage/contexts.actual.json'), str(directory / 'api-inputs.json.gz')]
(directory / 'api-export-command.actual.json').write_text(json.dumps({'args': args, 'cwd': str(repository), 'readOnlyRepositoryContract': 'findById only; any persistence method throws'}, indent=2) + '\n')
with (directory / 'api-export.log').open('w') as log:
    result = subprocess.run(args, cwd=repository, stdout=log, stderr=subprocess.STDOUT)
assert result.returncode == 0, result.returncode
for path, digest in pins.items():
    assert hashlib.sha256((repository / path).read_bytes()).hexdigest() == digest, path
record = json.loads(pin_file.read_text())
record['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record['allPinsUnchangedAtEnd'] = True
pin_file.write_text(json.dumps(record, indent=2) + '\n')
print('72 native API exports passed; all source pins unchanged')
