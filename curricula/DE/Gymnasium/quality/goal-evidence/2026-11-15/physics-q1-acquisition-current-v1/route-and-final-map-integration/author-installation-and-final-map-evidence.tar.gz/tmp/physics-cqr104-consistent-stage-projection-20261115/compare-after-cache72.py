import datetime
import gzip
import hashlib
import json
from pathlib import Path

B = Path('tmp/physics-cqr104-consistent-stage-projection-20261115')
before_dir, after_dir = B / 'final841-api-ui', B / 'after-cache841-api-ui'
read = lambda path: json.loads(gzip.decompress(path.read_bytes()))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
before = {row['id']: row for row in read(before_dir / 'api-ui-maps.actual.json.gz')['reports']}
after = {row['id']: row for row in read(after_dir / 'api-ui-maps.actual.json.gz')['reports']}
assert len(before) == len(after) == 72 and before.keys() == after.keys()
rows = []
for context_id, old in before.items():
    new = after[context_id]
    row = {'id': context_id, 'authorization': new['authorization'], 'scope': new['scope']}
    for prefix, field in [('seed', 'seedAtomicGoalIds'), ('learning', 'learningAtomicGoalIds')]:
        a, z = set(old[field]), set(new[field])
        row[prefix + 'Before'], row[prefix + 'After'] = len(a), len(z)
        row[prefix + 'Added'], row[prefix + 'Removed'] = sorted(z - a), sorted(a - z)
    row['progressBefore'], row['progressAfter'] = old['progressDenominators'], new['progressDenominators']
    row['allMapDataExactlyEqual'] = old['maps'] == new['maps']
    row['visibleRootsExactlyEqual'] = old['actualVisibleRootIds'] == new['actualVisibleRootIds']
    row['stageNumbers'] = [{key: item[key] for key in ['step', 'maxStep', 'topBackward', 'nestedBackward']} | {'outside': len(item['outsideUnitAtomicGoalIds'])} for item in new['maps']]
    rows.append(row)
invariant = [row for row in rows if not row['seedAdded'] and not row['seedRemoved'] and not row['learningAdded'] and not row['learningRemoved'] and row['progressBefore'] == row['progressAfter'] and row['allMapDataExactlyEqual'] and row['visibleRootsExactlyEqual']]
source_pins = json.loads((after_dir / 'source-pins.actual.json').read_text())
assert source_pins['allPinsUnchangedAtEnd']
for path, digest in source_pins['pins'].items():
    assert sha(Path(path)) == digest, path
result = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'FRESH_NATIVE_API_UI_AFTER_SEVEN_CACHE_CORRECTIONS',
          'beforeCanonicalSha256': 'ee9829cba17fe1cb8414a7c003fa9ed538278ab49ca1fce911a0ed710541923e',
          'afterCanonicalSha256': '721585772259388d11c4b6f1e6539099c375e6527828d62369acd6df6539e52c',
          'nativeReadOnlyExports': 72, 'exactScopeProgressAndMapInvariantContexts': len(invariant),
          'changedContexts': [row for row in rows if row not in invariant], 'rows': rows,
          'sourcePinsUnchangedDuringExportAndAtFinalCheck': True,
          'beforeFullComparison': {'path': str(B / 'final72-api-ui-comparison.actual.json'), 'sha256': sha(B / 'final72-api-ui-comparison.actual.json')},
          'afterSourceSeal': {'path': str(B / 'after-cache-source-seal.actual.json'), 'sha256': sha(B / 'after-cache-source-seal.actual.json')},
          'interpretation': 'The after-cache epoch uses fresh actual native API exports and the same corrected UI runner. Only contexts whose actual S/L, numerical progress totals, visible roots and complete map fields compare exactly are declared invariant. No learner state was written.',
          'artifacts': [{'path': str(after_dir / name), 'sha256': sha(after_dir / name)} for name in ['api-inputs.json.gz', 'api-ui-maps.actual.json.gz', 'summary.actual.json', 'source-pins.actual.json']]}
out = B / 'after-cache72-invariance.actual.json'
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('SHA', sha(out), 'EXACTLY_INVARIANT', len(invariant), 'CHANGED', len(result['changedContexts']))
print('NATIONAL', [(row['id'], row['seedAfter'], row['learningAfter'], row['stageNumbers']) for row in rows if row['id'].startswith('canonical:')])
