import os,json,shutil,subprocess,hashlib,pathlib
root=pathlib.Path.cwd(); out=root/'tmp/pr157-phase-guard-ci-repair-20261115/author'; fixture=out/'fixture'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='161acc0d483780c6bece1be316b51fd0054c2e2f'
if fixture.exists(): raise SystemExit('fixture already exists')
fixture.mkdir()
for p in root.iterdir():
 if p.name not in ('tmp','app','curricula'): (fixture/p.name).symlink_to(p,target_is_directory=p.is_dir())
(fixture/'app').mkdir()
for p in (root/'app').iterdir():
 if p.name in ('scripts','src'): shutil.copytree(p,fixture/'app'/p.name)
 else: (fixture/'app'/p.name).symlink_to(p,target_is_directory=p.is_dir())
def mirror(src,dst):
 dst.mkdir(parents=True,exist_ok=True)
 for p in src.iterdir():
  q=dst/p.name
  if p.is_dir():
   if p.name in ('quality','input','provenance','completion-profiles','completion-scopes'):
    q.symlink_to(p,target_is_directory=True)
   else: mirror(p,q)
  elif p.suffix=='.json': shutil.copy2(p,q)
  else: q.symlink_to(p)
mirror(root/'curricula',fixture/'curricula')
# Copy only the semantic ledger that must reflect the two changed authored objects.
q=fixture/'curricula/DE/Gymnasium/quality';q.unlink();q.mkdir()
for p in (root/'curricula/DE/Gymnasium/quality').iterdir():
 if p.name!='release-model': (q/p.name).symlink_to(p,target_is_directory=p.is_dir())
r=q/'release-model';r.mkdir()
for p in (root/'curricula/DE/Gymnasium/quality/release-model').iterdir():
 if p.name=='mathematik.semantic-kinds.json': shutil.copy2(p,r/p.name)
 else: (r/p.name).symlink_to(p,target_is_directory=p.is_dir())
p=pathlib.Path('curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json')
d=json.loads((root/p).read_text()); before=json.loads((root/p).read_text()); gid='f39c49c7-003b-471a-a33e-6cfea1d7b7b1';tid='54ce7136-5bdd-5d36-b0a5-f9a781bff82a';orientation='65365dce-f33f-49d8-9516-42f75883aa86';numeric='f6b13b8e-1ecd-5420-905d-21290aa996a6'
for g in d['goals']:
 if g['id']==gid:g['requires']=[orientation]
 if g['id']==tid:g['requires']=[gid,numeric]
(fixture/p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
edits=[{'goalId':g['id'],'before':b,'after':g} for b,g in zip(before['goals'],d['goals']) if b!=g]
assert len(edits)==2
for e in edits:
 b=dict(e['before']);a=dict(e['after']);b.pop('requires');a.pop('requires');assert a==b
payload={'status':'inactive-author-candidate-no-content-approval','baseCommit':'161acc0d483780c6bece1be316b51fd0054c2e2f','canonicalPath':str(p),'canonicalBeforeSha256':'sha256:'+hashlib.sha256((root/p).read_bytes()).hexdigest(),'edits':edits,'proposedSourceChange':None,'proposedPlacementChange':None,'proposedLearnerResultChange':None,'preserved':['all ordinary descriptions','all full current P content','all task/solution/scoring/coverage content','all goal IDs','all phases and placements','all sources','all V9 evidence','all quality floors','all learner results']}
(out/'candidate-payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
shutil.copy2(root/p,out/'before.canonical.json');shutil.copy2(fixture/p,out/'proposed.canonical.json')
(out/'canonical.patch').write_text(subprocess.run(['diff','-u',str(out/'before.canonical.json'),str(out/'proposed.canonical.json')],capture_output=True,text=True).stdout)
print(json.dumps({'fixture':str(fixture),'edits':[{'id':e['goalId'],'requiresBefore':e['before']['requires'],'requiresAfter':e['after']['requires']} for e in edits]},indent=2))
