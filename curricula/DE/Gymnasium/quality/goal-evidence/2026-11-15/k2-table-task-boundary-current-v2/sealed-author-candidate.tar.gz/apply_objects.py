#!/usr/bin/env python3
"""Object-scoped candidate application. Default dry-run; no quality activation."""
import argparse,json,pathlib
p=argparse.ArgumentParser();p.add_argument('--target-root',required=True);p.add_argument('--apply',action='store_true');a=p.parse_args()
out=pathlib.Path(__file__).resolve().parent;payload=json.loads((out/'candidate-payload.json').read_text());root=pathlib.Path(a.target_root).resolve();path=root/payload['canonicalPath'];d=json.loads(path.read_text());by={g['id']:g for g in d['goals']};todo=[]
for e in payload['edits']:
 g=by[e['goalId']]
 if g==e['after']:continue
 if g!=e['before']:raise SystemExit('Current object differs from reviewed before: '+e['goalId'])
 b=dict(e['before']);n=dict(e['after']);b.pop('requires');n.pop('requires')
 if b!=n:raise SystemExit('Candidate changes more than requires: '+e['goalId'])
 todo.append((g,e['after']))
if a.apply:
 for current,after in todo:current.clear();current.update(after)
 path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'mode':'applied' if a.apply else 'dry-run','target':str(path),'changedObjects':[g['id'] for g,_ in todo],'scope':'Canonical requires only. Does not update ledgers, reviews, projections, learner results or branches.'},ensure_ascii=False,indent=2))
