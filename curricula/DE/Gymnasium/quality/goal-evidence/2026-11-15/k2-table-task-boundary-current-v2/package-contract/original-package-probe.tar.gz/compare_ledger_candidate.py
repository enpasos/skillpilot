"""Prove the pending staging-ledger refresh does not alter any decision."""
from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PROBE = Path(__file__).resolve().parent
LEDGER = Path("curricula/DE/Gymnasium/quality/package-redistribution/de-gymnasium-mathematik-v1.review.json")
SHELL = Path("scripts/run_curriculum_release_model_conformance.sh")


def main() -> None:
    old_bytes = (PROBE / "original.review.json").read_bytes()
    old = json.loads(old_bytes)
    candidate_bytes = (PROBE / "candidate.review.json").read_bytes()
    candidate = json.loads(candidate_bytes)
    changed = [key for key in sorted(set(old) | set(candidate)) if old.get(key) != candidate.get(key)]
    assert changed == ["contentDigest", "sourceReleaseModel"], changed
    assert old["assetDecisions"] == candidate["assetDecisions"]
    assert old["classDecisions"] == candidate["classDecisions"]
    assert old["summary"] == candidate["summary"]
    assert old["assetSetSha256"] == candidate["assetSetSha256"]
    assert not candidate["summary"]["publicationReady"]
    release_changed = [key for key in sorted(set(old["sourceReleaseModel"]) | set(candidate["sourceReleaseModel"]))
                       if old["sourceReleaseModel"].get(key) != candidate["sourceReleaseModel"].get(key)]
    assert release_changed == ["buildInputsSha256"], release_changed
    for row in candidate["assetDecisions"]:
        assert row["decisionStatus"] == "pending-human-review"
        assert row["redistributionStatus"] == "review-required"
        assert row["licenseExpression"] is None
        assert row["reviewer"] is None and row["reviewedAt"] is None
        assert row["reviewEvidence"] == []

    # Keep the assertion reproducible after root applies the active candidate.
    original_shell = (PROBE / "original.run_curriculum_release_model_conformance.sh").read_text()
    old_digest = old["contentDigest"]
    assert original_shell.count(old_digest) == 1
    candidate_shell = original_shell.replace(old_digest, candidate["contentDigest"])
    (PROBE / "candidate.run_curriculum_release_model_conformance.sh").write_text(candidate_shell)
    diff = "".join(difflib.unified_diff(old_bytes.decode().splitlines(True), candidate_bytes.decode().splitlines(True),
                                       fromfile=f"a/{LEDGER}", tofile=f"b/{LEDGER}"))
    diff += "".join(difflib.unified_diff(original_shell.splitlines(True), candidate_shell.splitlines(True),
                                        fromfile=f"a/{SHELL}", tofile=f"b/{SHELL}"))
    (PROBE / "pending-ledger-current-binding.candidate.patch").write_text(diff)
    receipt = {
        "originalLedgerSha256": hashlib.sha256(old_bytes).hexdigest(),
        "candidateLedgerSha256": hashlib.sha256(candidate_bytes).hexdigest(),
        "changedTopLevelFields": changed,
        "changedSourceReleaseModelFields": release_changed,
        "originalContentDigest": old_digest,
        "candidateContentDigest": candidate["contentDigest"],
        "originalBuildInputsSha256": old["sourceReleaseModel"]["buildInputsSha256"],
        "candidateBuildInputsSha256": candidate["sourceReleaseModel"]["buildInputsSha256"],
        "assetDecisionsByteEquivalentUnderJson": True,
        "classDecisionsByteEquivalentUnderJson": True,
        "summaryUnchanged": candidate["summary"],
        "resourceIndexUnchanged": old["sourceReleaseModel"]["resourceIndexSha256"],
        "historicalCompletedReviewRebound": False,
        "publicationApprovalCreated": False,
    }
    (PROBE / "candidate-delta.receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
