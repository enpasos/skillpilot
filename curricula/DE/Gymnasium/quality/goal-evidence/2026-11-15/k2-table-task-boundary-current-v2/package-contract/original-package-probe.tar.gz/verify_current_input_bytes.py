"""Check the compiler's recorded raw-input hashes against current files."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path

PROBE = Path(__file__).resolve().parent
ROOT = PROBE.parents[2]
MODEL = PROBE / "current-model"


def main() -> None:
    build = json.loads((MODEL / "metadata/build-inputs.json").read_text())
    conformance = json.loads((MODEL / "metadata/release-model-conformance.json").read_text())
    records = []

    def bind(role, path, expected_sha256, expected_bytes=None):
        source = ROOT / path
        raw = source.read_bytes()
        actual = hashlib.sha256(raw).hexdigest()
        expected_sha256 = expected_sha256.removeprefix("sha256:")
        assert actual == expected_sha256, (role, path, expected_sha256, actual)
        assert expected_bytes is None or len(raw) == expected_bytes, (role, path, expected_bytes, len(raw))
        records.append({"role": role, "path": path, "bytes": len(raw), "sha256": actual})

    canonical = conformance["prerequisiteReductionProof"]["canonicalSource"]
    bind("canonical-mathematik-raw", canonical["path"], canonical["sha256"])
    bind("release-model-profile", build["profilePath"], build["profileSha256"])
    bind("semantic-kind-current-ledger", build["semanticKindLedgerPath"], build["semanticKindLedgerSha256"])
    for role, binding in [("curriculum-ontology-profile", build["curriculumOntologyProfile"]),
                          ("publication-evidence-profile", build["publicationEvidence"]["profile"])]:
        bind(role, binding["path"], binding["sha256"])
    fwu = build["fwuCoreOntology"]
    bind("pinned-fwu-ontology", fwu["checkoutPath"] + "/" + fwu["sourcePath"], fwu["fileSha256"], fwu["bytes"])
    for item in build["assessmentSources"]:
        bind("assessment-source", item["sourcePath"], item["sha256"], item["bytes"])
    for item in build["publicationEvidence"]["inputFiles"]:
        bind("publication:" + item["inputRole"], item["sourcePath"], item["sha256"], item["bytes"])
    # The redistribution CLI also validates all these actual image bytes and
    # prompt hashes independently. Bind them here in one explicit source receipt.
    for item in build["binaryResources"]:
        bind("binary-resource", item["sourcePath"], item["sha256"], item["bytes"])
    registry = conformance["prerequisiteReductionProof"]
    bind("immutable-v9-registry", registry["registryPath"], registry["registryDigest"])
    receipt = {
        "currentModelContentDigest": conformance["contentDigest"],
        "currentBuildInputsSha256": hashlib.sha256((MODEL / "metadata/build-inputs.json").read_bytes()).hexdigest(),
        "allRecordedInputByteBindingsEqualCurrentFiles": True,
        "checkedBindingCount": len(records),
        "checkedRoleCounts": dict(sorted(Counter(row["role"] for row in records).items())),
        "sourcePins": records,
        "scope": "compiled raw-source bindings; model validator independently reconstructs transformed views/decks/contracts from current authoring inputs",
    }
    (PROBE / "current-source-pins.receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({key: value for key, value in receipt.items() if key != "sourcePins"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
