import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { fingerprintSemanticKindSourceGoal } from '/home/enpasos/projects/skillpilot/app/scripts/goalBookModel.ts'
import { sha256WithoutLearningUnitLayer } from '/home/enpasos/projects/skillpilot/app/scripts/learningUnitLayerProjection.ts'

const root = '/home/enpasos/projects/skillpilot'
const base = '161acc0d483780c6bece1be316b51fd0054c2e2f'
const mathPath = 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
const ledgerPath = 'curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json'
const deepPath = 'curricula/DE/Gymnasium/quality/deep-understanding-rollout/de-gymnasium-math-physics.config.json'
const policyPath = 'app/scripts/config/math-duration-split-spanning-tree-policy.json'
const evidence = 'curricula/DE/Gymnasium/quality/goal-evidence/2026-11-15/'
const v1 = evidence + 'k2-elementary-representations-current-v1/'
const v2 = evidence + 'k2-table-task-boundary-current-v2/'
const d2 = 'curricula/DE/Gymnasium/quality/goal-description-review/mathematik/rollout-v1/2026-11-15/k2-table-task-boundary-current-v2/'
const tableId = 'f39c49c7-003b-471a-a33e-6cfea1d7b7b1'
const taskId = '54ce7136-5bdd-5d36-b0a5-f9a781bff82a'
const rationalId = 'f6b13b8e-1ecd-5420-905d-21290aa996a6'
const orientationId = '65365dce-f33f-49d8-9516-42f75883aa86'
const bytes = (path: string) => readFileSync(root + '/' + path)
const read = (path: string) => JSON.parse(bytes(path).toString('utf8'))
const previous = (path: string) => JSON.parse(execFileSync('git', ['show', base + ':' + path], { cwd: root, maxBuffer: 128 * 1024 * 1024 }).toString('utf8'))
const hash = (value: Buffer) => createHash('sha256').update(value).digest('hex')
const results: Record<string, unknown> = {}

const before = previous(mathPath), after = read(mathPath)
const omit = (goal: any, field: string) => Object.fromEntries(Object.entries(goal).filter(([key]) => key !== field))
assert.deepEqual(omit(before, 'goals'), omit(after, 'goals'))
assert.deepEqual(before.goals.map((g: any) => g.id), after.goals.map((g: any) => g.id))
const oldById = new Map(before.goals.map((g: any) => [g.id, g]))
const byId = new Map(after.goals.map((g: any) => [g.id, g]))
const changed = after.goals.filter((g: any) => JSON.stringify(g) !== JSON.stringify(oldById.get(g.id)))
assert.deepEqual(changed.map((g: any) => g.id).sort(), [tableId, taskId].sort())
for (const goal of changed) assert.deepEqual(omit(goal, 'requires'), omit(oldById.get(goal.id), 'requires'))
assert.deepEqual(byId.get(tableId).requires, [orientationId])
assert.deepEqual(byId.get(taskId).requires, [tableId, rationalId])
results.canonical = { totalGoals: after.goals.length, onlyRequiresChangedOn: changed.map((g: any) => g.id), taskTextSolutionRubricCoverageAndApplicabilityUnchanged: true }

const oldLedger = previous(ledgerPath), ledger = read(ledgerPath)
assert.deepEqual(omit(oldLedger, 'decisions'), omit(ledger, 'decisions'))
const oldDecisions = new Map(oldLedger.decisions.map((d: any) => [d.goalId, d]))
const changedDecisions = ledger.decisions.filter((d: any) => JSON.stringify(d) !== JSON.stringify(oldDecisions.get(d.goalId)))
assert.deepEqual(changedDecisions.map((d: any) => d.goalId).sort(), [tableId, taskId].sort())
for (const decision of changedDecisions) {
  assert.deepEqual(omit(decision, 'sourceFingerprint'), omit(oldDecisions.get(decision.goalId), 'sourceFingerprint'))
  assert.equal(decision.sourceFingerprint, fingerprintSemanticKindSourceGoal(byId.get(decision.goalId)))
}
results.semanticPins = { changed: 2, bothNativeFingerprintsMatch: true, kindsStatusesAndBasesUnchanged: true }

const oldP = JSON.parse(bytes(v1 + 'current-f39c49c7.review.jsonl').toString('utf8').trim())
const p = JSON.parse(bytes(v2 + 'current-f39c49c7.review.jsonl').toString('utf8').trim())
assert.deepEqual(p.profile, oldP.profile)
for (const field of ['goalId', 'goalFingerprint', 'profileFingerprint', 'reviewAuthority', 'status', 'evidenceLevel', 'maximumClaimScope']) assert.equal(p[field], oldP[field])
assert.notEqual(p.reviewInputFingerprint, oldP.reviewInputFingerprint)
const resolution = read(d2 + 'resolutions/' + tableId + '.resolution.json')
const index = read(d2 + 'resolution-index.json'), summary = read(d2 + 'dual-summary.json')
const page = read(d2 + 'bundle/book-model.json').pages.find((page: any) => page.goalId === tableId)
assert.equal(resolution.goal.goalFingerprint, p.goalFingerprint)
assert.equal(resolution.goal.pageFingerprint, page.pageFingerprint)
assert.equal(resolution.decision, 'keep_current')
assert.equal(index.resolutions.length, 1)
assert.equal(index.resolutions[0].goalId, tableId)
assert.equal(index.resolutions[0].strictDescriptionComplete, true)
assert.equal(index.resolutions[0].resolutionDigest, 'sha256:' + hash(bytes(d2 + 'resolutions/' + tableId + '.resolution.json')))
assert.notEqual(resolution.rounds.first.independenceGroupId, resolution.rounds.second.independenceGroupId)
assert.equal(resolution.rounds.first.reviewInputFingerprint, resolution.rounds.second.reviewInputFingerprint)
assert.equal(resolution.rounds.first.goalReviewContextFingerprint, resolution.rounds.second.goalReviewContextFingerprint)
assert.equal(summary.goals[0].firstDecision, 'keep')
assert.equal(summary.goals[0].secondDecision, 'keep')
results.pAndD = { fullPProfileUnchanged: true, freshCurrentPInput: true, humanOrLearnerApprovalPromoted: false, oneFreshDResolutionMatchesActualBookPage: true, distinctIndependentGroups: true, bothRoundsKeep: true, modelDiversityNotIndependentlyAttested: true }

const oldDeep = previous(deepPath), deep = read(deepPath)
assert.deepEqual(omit(oldDeep, 'subjects'), omit(deep, 'subjects'))
assert.deepEqual(oldDeep.subjects.filter((s: any) => s.subject !== 'mathematik'), deep.subjects.filter((s: any) => s.subject !== 'mathematik'))
const oldMath = oldDeep.subjects.find((s: any) => s.subject === 'mathematik'), currentMath = deep.subjects.find((s: any) => s.subject === 'mathematik')
assert.deepEqual(currentMath.resolutionIndexPaths, [...oldMath.resolutionIndexPaths, d2 + 'resolution-index.json'])
assert.deepEqual(currentMath.positiveEvidenceConfigPaths, oldMath.positiveEvidenceConfigPaths.map((p: string) => p === v1 + 'current-f39c49c7.config.json' ? v2 + 'current-f39c49c7.config.json' : p))
assert.deepEqual(currentMath.resolutionSupersessions, [...oldMath.resolutionSupersessions, { goalId: tableId, supersededIndexPath: v1.replace('/goal-evidence/', '/goal-description-review/mathematik/rollout-v1/') + 'resolution-index.json', replacementIndexPath: d2 + 'resolution-index.json' }])
results.activeEvidenceChain = { otherFourSubjectsUnchanged: true, onlyF39PReplaced: true, oneDIndexAndOneGoalScopedSupersessionAdded: true }

const oldPolicy = previous(policyPath), policy = read(policyPath)
assert.equal(policy.inputs.canonical.sha256, sha256WithoutLearningUnitLayer(bytes(mathPath)))
const restored = structuredClone(policy)
restored.inputs.canonical.sha256 = oldPolicy.inputs.canonical.sha256
assert.deepEqual(restored, oldPolicy)
const duration = read(v2 + 'duration-view-byte-comparison.actual.json')
assert.equal(duration.views.length, 18)
for (const view of duration.views) {
  const baseline = execFileSync('git', ['show', base + ':' + view.path], { cwd: root, maxBuffer: 16 * 1024 * 1024 })
  assert(bytes(view.path).equals(baseline))
  assert.equal(view.baselineAndCurrentSha256, hash(baseline))
}
results.duration = { nativeCurrentInputPinMatches: true, allLayoutPolicyFieldsUnchanged: true, byteIdenticalViews: 18 }

for (const [subject, total, ordinary] of [['mathematik', 1262, 807], ['physik', 773, 481]] as const) {
  const report = read('curricula/DE/Gymnasium/quality/goal-visualization-review/' + subject + '-rollout-status.json')
  assert.equal(report.summary.totalGoals, total)
  assert.equal(report.summary.atomicGoalsInScope, ordinary)
  assert.equal(report.summary.coverageGatePassed, true)
  assert.equal(report.summary.releaseApprovedVisualizationCount, 0)
}
results.generatedVisualizationCounts = { mathTotal: 1262, mathOrdinary: 807, physicsTotal: 773, physicsOrdinary: 481, coverageGatesPass: true, publicationApprovalNotPromoted: true }

const redistributionPath = 'curricula/DE/Gymnasium/quality/package-redistribution/de-gymnasium-mathematik-v1.review.json'
const oldRedistribution = previous(redistributionPath), redistribution = read(redistributionPath)
const restoredRedistribution = structuredClone(redistribution)
restoredRedistribution.contentDigest = oldRedistribution.contentDigest
restoredRedistribution.sourceReleaseModel.buildInputsSha256 = oldRedistribution.sourceReleaseModel.buildInputsSha256
assert.deepEqual(restoredRedistribution, oldRedistribution)
const modelRoot = 'tmp/pr157-phase-guard-ci-repair-20261115/package-contract-probe/current-model/'
assert.equal(redistribution.sourceReleaseModel.buildInputsSha256, 'sha256:' + hash(bytes(modelRoot + 'metadata/build-inputs.json')))
assert.equal(redistribution.sourceReleaseModel.resourceIndexSha256, 'sha256:' + hash(bytes(modelRoot + 'data/resources/resource-index.json')))
const modelSummary = read('tmp/pr157-phase-guard-ci-repair-20261115/package-contract-probe/compile.stdout.json')
assert.equal(redistribution.contentDigest, modelSummary.contentDigest)
const shellPath = 'scripts/run_curriculum_release_model_conformance.sh'
const oldShell = execFileSync('git', ['show', base + ':' + shellPath], { cwd: root }).toString('utf8')
const shell = bytes(shellPath).toString('utf8')
assert.equal(shell.replace(redistribution.contentDigest, oldRedistribution.contentDigest), oldShell)
assert.equal(redistribution.assetDecisions.length, 836)
const pinReceipt = read('tmp/pr157-phase-guard-ci-repair-20261115/package-contract-probe/current-source-pins.stdout.json')
assert.equal(pinReceipt.checkedBindingCount, 1025)
results.packageBindings = { onlyTwoGeneratedReviewBindingsAndOneExpectedDigestChanged: true, currentCompiledModelBindingsMatch: true, all836AssetAndClassDecisionsUnchanged: true, allOtherReviewFieldsAndPendingStatesUnchanged: true, inspectedSourcePinReceiptCount: 1025, independentNativeValidatorNotClaimedByThisAudit: true }

const report = { observedAt: new Date().toISOString(), status: 'PASS-bounded-independent-technical-review', baseCommit: base, noLargeTestOrWriterStarted: true, results }
writeFileSync(root + '/tmp/pr157-phase-guard-ci-repair-20261115/completion-audit/technical-current-boundary-review.actual.json', JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report, null, 2))
