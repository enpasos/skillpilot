import { writeFileSync } from 'node:fs';
import {auditSemanticLearningRoutes} from '/home/enpasos/projects/skillpilot/app/scripts/auditSemanticLearningRoutes.ts';
const result=await auditSemanticLearningRoutes('/home/enpasos/projects/skillpilot/tmp/pr157-phase-guard-ci-repair-20261115/completion-audit/baseline-physics-route-fixture');
writeFileSync('/home/enpasos/projects/skillpilot/tmp/pr157-phase-guard-ci-repair-20261115/completion-audit/semantic-route-physics-baseline.actual.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result.summary));
