#!/usr/bin/env python3
"""Read-only graph comparison of recorded native seeds; not a native backend rerun."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = Path(__file__).resolve().parent
BASE = "161acc0d483780c6bece1be316b51fd0054c2e2f"
MATH = "curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json"
SEEDS = "curricula/DE/Gymnasium/quality/goal-model-review/backend-reviewed-seed-fixture-repair-20261115/current-api-seed-scopes-after.actual.json"


def digest(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()


def close(seeds, lookup):
    result = set(seeds)
    todo = list(seeds)
    while todo:
        goal = lookup[todo.pop()]
        for required in goal.get("requires", []):
            if required not in result:
                result.add(required)
                todo.append(required)
    return result


before_bytes = subprocess.check_output(["git", "show", BASE + ":" + MATH], cwd=ROOT)
seed_bytes = (ROOT / SEEDS).read_bytes()
goals = {}
bindings = []
for path in sorted((ROOT / "curricula/DE/Gymnasium/canonical").glob("*.json")):
    data = path.read_bytes()
    bindings.append({"path": str(path.relative_to(ROOT)), "sha256": digest(data)})
    for goal in json.loads(data).get("goals", []):
        assert goal["id"] not in goals, goal["id"]
        goals[goal["id"]] = goal
before_goals = dict(goals)
before_goals.update({goal["id"]: goal for goal in json.loads(before_bytes)["goals"]})
rows = []
for key, scope in sorted(json.loads(seed_bytes)["scopes"].items()):
    previous = close(scope["seedAtomicGoalIds"], before_goals)
    current = close(scope["seedAtomicGoalIds"], goals)
    rows.append({
        "scope": key,
        "seedCount": len(scope["seedAtomicGoalIds"]),
        "beforeClosureCount": len(previous),
        "currentClosureCount": len(current),
        "added": sorted(current - previous),
        "removed": sorted(previous - current),
    })
report = {
    "observedAt": datetime.now(timezone.utc).isoformat(),
    "comparedAgainstCommit": BASE,
    "semantics": "Read-only graph calculation of unpruned canonical direct requires closure of each recorded native seed set. This is not a fresh native backend projection or confirmation of post-generation seed identity.",
    "canonicalCatalogs": len(bindings),
    "recordedNativeScopes": len(rows),
    "currentMathRawSha256": digest((ROOT / MATH).read_bytes()),
    "baselineMathRawSha256": digest(before_bytes),
    "recordedNativeSeedInput": {"path": SEEDS, "sha256": digest(seed_bytes)},
    "currentCanonicalInputs": bindings,
    "changedClosureScopes": [row for row in rows if row["added"] or row["removed"]],
    "scopes": rows,
}
assert report["canonicalCatalogs"] == 21
assert report["recordedNativeScopes"] == 128
assert not report["changedClosureScopes"]
(OUTPUT / "recorded128-seed-closure-graph-comparison.actual.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: value for key, value in report.items() if key not in ["scopes", "currentCanonicalInputs"]}, indent=2))
