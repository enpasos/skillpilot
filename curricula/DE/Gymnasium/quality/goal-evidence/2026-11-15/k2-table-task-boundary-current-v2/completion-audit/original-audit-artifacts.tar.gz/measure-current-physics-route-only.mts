import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {validateHardDirectAtomicRoutes} from '/home/enpasos/projects/skillpilot/app/scripts/lib/hardLearningRouteValidation.ts';
import {deriveSemanticRouteProfiles} from '/home/enpasos/projects/skillpilot/app/scripts/lib/semanticRouteInventory.ts';
import {createRouteProfiles} from '/home/enpasos/projects/skillpilot/app/scripts/generateCurriculumQualityStatus.ts';
const root='/home/enpasos/projects/skillpilot';
const doc=JSON.parse(readFileSync(root+'/curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json','utf8'));
const ledger=JSON.parse(readFileSync(root+'/curricula/DE/Gymnasium/quality/release-model/physik.semantic-kinds.json','utf8'));
const paths=['quality/release-model/mathematik.semantic-kinds.json','quality/release-model/physik.semantic-kinds.json','quality/goal-book-publication/biologie.semantic-kinds.json','quality/goal-book-publication/chemie.semantic-kinds.json'];
const kinds=new Map(paths.flatMap(p=>JSON.parse(readFileSync(root+'/curricula/DE/Gymnasium/'+p,'utf8')).decisions.map((d:any)=>[d.goalId,d.semanticKind])));
const goals=readdirSync(root+'/curricula/DE/Gymnasium/canonical').filter(p=>p.endsWith('.json')).flatMap(p=>JSON.parse(readFileSync(root+'/curricula/DE/Gymnasium/canonical/'+p,'utf8')).goals);
const policy=JSON.parse(readFileSync(root+'/app/scripts/config/semantic-route-coverage.json','utf8'));
const owners=new Map(readdirSync(root+'/curricula/DE/Gymnasium/canonical').filter(p=>p.endsWith('.json')).flatMap(p=>{const d=JSON.parse(readFileSync(root+'/curricula/DE/Gymnasium/canonical/'+p,'utf8'));return d.goals.map((g:any)=>[g.id,d.landscapeId]);}));
const profile=deriveSemanticRouteProfiles(policy,kinds,owners,createRouteProfiles(root)).find((p:any)=>p.profileId==='canonical-physics-sek1')!;
const findings=validateHardDirectAtomicRoutes(goals,kinds,profile);
writeFileSync('/home/enpasos/projects/skillpilot/tmp/pr157-phase-guard-ci-repair-20261115/completion-audit/physics-route-only-current-diagnostic.actual.json',JSON.stringify({semantics:'Bounded diagnostic of exact baseline Physics goals, stage views and semantic kinds through native route function. Full baseline cross-subject historical review validation was not performed.',findings},null,2)+'\n');
const byId=new Map(goals.map((g:any)=>[g.id,g]));
const seen=new Set<string>();const todo=['1abfd5ef-1f42-5b71-8c9a-80c0a6b0322e'];
while(todo.length){const id=todo.pop()!;if(seen.has(id))continue;seen.add(id);todo.push(...(byId.get(id)?.requires??[]));}
console.log(JSON.stringify({findings,selectedOrdinaryPrerequisites:[...seen].filter(id=>profile.goalSelector(byId.get(id)!)&&kinds.get(id)==='curricularAtomic').map(id=>({id,title:byId.get(id)!.title}))},null,2));
