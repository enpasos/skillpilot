# AI review input: Physik – drei aktuelle Lernziele

- Book ID: `physics-three-atomic-boundary-successor-20261014-v1`
- Book edition: `curricular-atomic-v1`
- Publication mode: `review`
- BookModel digest: `sha256:9169de69309af61e05ca97ca0d0640b30a862e8309626df2f0e8802d3ca17fb6`
- Selected goals: 3

The PDF and this Markdown are parallel review surfaces. The normalized JSON is authoritative for exact IDs, relationships, fingerprints, and evidence-profile fields.

## Page 1: Ladungserhaltung erläutern

- Full learning-goal ID: `25998fed-ea4d-4c3e-b606-e965b5d7f290`
- Goal fingerprint: `sha256:7d4102629d3772ec4d015a7cbc0a2b5c0dc4ac0f5663e05cdfc9636f6f92c17e`
- Page fingerprint: `sha256:0a8e8a6700547422df616f27c17b847c78413a33d02462c5e2c59df95714f559`
- Topic path: Physik

### Canonical description

Die lernende Person kann elektrische Ladung als Erhaltungsgröße beschreiben und Ladungsumverteilungen in abgeschlossenen Systemen fachlich deuten.

### Visualization

/assets/goal-visualizations/physik/25998fed-ea4d-4c3e-b606-e965b5d7f290/25998fed-ea4d-4c3e-b606-e965b5d7f290.jpg

- original digest: `sha256:9cc7c92df54fdc88897b516935d601733a8e2d2b1f97f3e0b9af12a040a191fd`
- QA status: `review_candidate`
- approved for public publication: `false`

### Direct prerequisites

- None

### Direct reverse prerequisites

- None

### Prerequisites outside this book

- Ladungsphänomene und Reibungselektrizität — `a6e48b88-51ed-5942-bdb8-8d2192652e0d` (outside this book)
- Ganze Zahlen addieren — `4b67bed9-06da-40b2-a306-24e9e7dfd390` (outside this book)

### Direct reverse prerequisites outside this book

- Elektrostatik und Potenzial — `841edfdb-5e12-5a37-ab12-552a1d8e92ca` (outside this book)
- Influenz bei Leitern untersuchen — `9fb1dd85-11b7-4a5a-b124-27fea8d1788e` (outside this book)
- Q1-Klausuraufgaben Physik selbstständig lösen — `d441ee2f-9230-5751-832b-5b0b5cf14605` (outside this book)

### Evidence-profile candidate

Status: `needs_human_review`; profile fingerprint: `sha256:903a18de1a519a775a94ebd769503fc3e83b568f656633f572102924ee90d352`
Contract: `positive-understanding-evidence-v2`; authority: `ai_candidate`; evidence level: `E1`; maximum claim scope: `G1`
Archetype: `concept`

**Positive understanding expectations**

- `closed-system-algebraic-total-is-conserved`
  - Essential understanding (DE): In einem abgeschlossenen System bleibt die algebraische Gesamtladung erhalten: Die Summe aller positiven und negativen Ladungsbeiträge ist nach einer Wechselwirkung dieselbe wie vorher. Erhaltung bezieht sich auf das abgegrenzte Gesamtsystem, nicht darauf, dass jeder einzelne Körper seine Ladung behält.
  - Essential understanding (EN): In a closed system, total algebraic charge is conserved: the sum of all positive and negative charge contributions is the same after an interaction as before. Conservation applies to the bounded overall system, not to each individual body retaining its charge.
  - Observable performance (DE): Die lernende Person legt für einen unbekannten Umverteilungsfall die Systemgrenze fest, bildet die vorzeichenrichtige Gesamtladung vor und nach dem Vorgang und bestimmt oder kontrolliert eine fehlende Teilladung aus der Erhaltungsbilanz.
  - Observable performance (EN): For an unfamiliar redistribution case, the learner specifies the system boundary, forms the signed total charge before and after the process, and determines or checks a missing component charge from the conservation balance.
- `local-changes-are-transfers-across-subsystem-boundaries`
  - Essential understanding (DE): Wenn ein Teilkörper Ladung gewinnt oder verliert, wird Ladung über dessen Teilgrenze übertragen; im vollständig betrachteten abgeschlossenen System erscheint die entgegengesetzte Änderung an einem anderen Bestandteil. Eine scheinbare Verletzung der Erhaltung zeigt daher häufig, dass ein beteiligter Körper oder die Umgebung außerhalb der gewählten Grenze liegt.
  - Essential understanding (EN): When one component gains or loses charge, charge is transferred across that component's boundary; within the complete closed system, the opposite change appears on another component. An apparent violation of conservation therefore often shows that an involved body or the surroundings lie outside the chosen boundary.
  - Observable performance (DE): Die lernende Person vergleicht die Bilanz eines Teilsystems mit der eines erweiterten abgeschlossenen Systems, lokalisiert den Ladungstransfer und erklärt die Änderung einzelner Körper, ohne Ladung als neu entstanden oder verschwunden zu beschreiben.
  - Observable performance (EN): The learner compares the balance of a subsystem with that of an expanded closed system, locates the charge transfer, and explains changes of individual bodies without describing charge as newly created or destroyed.

**Coverage expectations**

- required expectations: `closed-system-algebraic-total-is-conserved`, `local-changes-are-transfers-across-subsystem-boundaries`
- alternative expectation groups: None
- minimum independent demonstrations: 2
- fresh variation required: true
- independent transfer required: true

**Variation axes**

- `system-boundary`: Ein vollständig abgeschlossenes Mehrkörpersystem oder ein zunächst zu eng gewähltes einzelnes Teilsystem / A complete closed multi-body system or an initially too narrowly chosen single subsystem
- `charge-information`: Vollständige Vorher-nachher-Werte oder eine aus der Erhaltungsbilanz zu bestimmende Teilladung / Complete before-and-after values or one component charge to be determined from conservation
- `sign-composition`: Nur gleichnamige Beiträge oder gemischte positive, negative und neutrale Anfangszustände / Only like-signed contributions or mixed positive, negative, and neutral initial states

**Application cases**

- `three-body-redistribution-balance`
  - Task demand (DE): Drei Körper befinden sich in einem Behälter und bilden selbst ein elektrisch abgeschlossenes System: Während der Umverteilung wird Ladung nur zwischen diesen drei Körpern übertragen, nicht zum Behälter oder zur übrigen Umgebung. Vorher tragen sie +4 nC, −1 nC und 0 nC. Danach werden an zwei Körpern +2 nC und +5 nC bestimmt. Ermittle die Ladung des dritten Körpers und beschreibe, was die Bilanz über Umverteilung und Gesamtladung aussagt.
  - Task demand (EN): Three bodies are inside an enclosure and themselves form a charge-isolated system: during redistribution, charge is transferred only among these three bodies, not to the enclosure or other surroundings. Beforehand they carry +4 nC, −1 nC, and 0 nC. Afterwards, +2 nC and +5 nC are determined on two bodies. Determine the charge of the third body and explain what the balance says about redistribution and total charge.
  - Expected performance (DE): Die lernende Person bildet vor dem Vorgang Q_ges = +3 nC. Damit die Nachher-Summe ebenfalls +3 nC beträgt, muss der dritte Körper −4 nC tragen, denn +2 nC + 5 nC − 4 nC = +3 nC. Sie erklärt, dass sich die Teilladungen stark geändert haben, die algebraische Gesamtladung des abgeschlossenen Dreikörpersystems aber erhalten blieb.
  - Expected performance (EN): The learner calculates Q_total = +3 nC before the process. For the final sum also to equal +3 nC, the third body must carry −4 nC because +2 nC + 5 nC − 4 nC = +3 nC. The learner explains that the component charges changed substantially while the algebraic total charge of the closed three-body system remained conserved.
  - Understanding focus (DE): Der Grundfall prüft vorzeichenrichtige Gesamtbilanz und die Trennung zwischen erhaltener Gesamtladung und veränderlichen Teilladungen.
  - Understanding focus (EN): The direct case tests a correctly signed total balance and the distinction between conserved total charge and changing component charges.
- `ground-contact-requires-expanded-boundary`
  - Task demand (DE): Eine leitende Kugel trägt zunächst +6 nC. Nach leitendem Kontakt mit einer geerdeten Verbindung wird an der Kugel näherungsweise 0 nC gemessen. Eine Aussage behauptet, in der Kugel sei Ladung vernichtet worden. Beurteile die Aussage zuerst für das Teilsystem Kugel und dann für ein erweitertes System aus Kugel, Leitung und Erde.
  - Task demand (EN): A conducting sphere initially carries +6 nC. After conducting contact with a grounded connection, approximately 0 nC is measured on the sphere. A statement claims that charge was destroyed in the sphere. Assess the statement first for the sphere as a subsystem and then for an expanded system consisting of sphere, connection, and Earth.
  - Expected performance (DE): Die lernende Person erkennt, dass die Kugel allein während des Kontakts kein abgeschlossenes System ist und Ladung über die Leitung übertragen wird. Sie erweitert die Grenze um Leitung und Erde und deutet die Änderung der Kugelladung als Umverteilung innerhalb dieses größeren Systems; die fehlenden +6 nC werden nicht als vernichtet bezeichnet.
  - Expected performance (EN): The learner recognizes that the sphere alone is not a closed system during contact and that charge is transferred through the connection. The learner expands the boundary to include the connection and Earth and interprets the sphere's change as redistribution within that larger system; the missing +6 nC is not described as destroyed.
  - Understanding focus (DE): Der Transfer prüft, ob eine scheinbare Nichterhaltung durch eine sachgerechte Systemgrenze und einen Ladungstransfer erklärt wird.
  - Understanding focus (EN): The transfer tests whether apparent non-conservation is explained through an appropriate system boundary and charge transfer.
## Page 2: Sinusfoermige Wechselgroessen mit Zeigerdiagrammen beschreiben

- Full learning-goal ID: `5f97952e-5ac9-5749-94d0-d1dc50dda358`
- Goal fingerprint: `sha256:bafbdd94a248a19d01b7f4d570c8378a321efe0337f65d38b16bdbcf63da8c85`
- Page fingerprint: `sha256:a599027044815f735b06d0bc6146bcff5fd3c0556808c7ecba249c43005077d9`
- Topic path: Physik

### Canonical description

Die lernende Person kann sinusförmige Spannung und Stromstärke in ohmschen Wechselstromkreisen mit Zeigerdiagrammen darstellen und Phasenbeziehungen fachlich deuten.

### Visualization

/assets/goal-visualizations/physik/5f97952e-5ac9-5749-94d0-d1dc50dda358/5f97952e-5ac9-5749-94d0-d1dc50dda358.jpg

- original digest: `sha256:32de0b0652e73ad4a1ecbd36f48ad3a0b615ae5d2cad56012607e920fa3caf6f`
- QA status: `review_candidate`
- approved for public publication: `false`

### Direct prerequisites

- None

### Direct reverse prerequisites

- None

### Prerequisites outside this book

- Zusammenhang von Spannung und Stromstärke qualitativ erläutern — `53196a71-9dbd-4835-b2f9-ff21b8a8962c` (outside this book)
- Elektromagnetischen Schwingkreis analysieren — `ac4ba260-6086-5fcc-bea2-c06f1425a1cc` (outside this book)
- Sinus- und Kosinusfunktionen verstehen — `bbef7cf2-90fa-59fa-a115-8b651aab9231` (outside this book)

### Direct reverse prerequisites outside this book

- Kondensator und Spule im Wechselstromkreis analysieren — `ef0f2391-fd8e-5ae3-ae86-7adcdd833c7a` (outside this book)

### Evidence-profile candidate

Status: `needs_human_review`; profile fingerprint: `sha256:d07495fd1617d93daa6d314d230546a74e76457d694b661aeb2dc6685f6138bc`
Contract: `positive-understanding-evidence-v2`; authority: `ai_candidate`; evidence level: `E1`; maximum claim scope: `G1`
Archetype: `representation`

**Positive understanding expectations**

- `phasor-projection`
  - Essential understanding (DE): Ein Zeiger stellt Amplitude und Phase einer sinusförmigen Größe bei festgelegter Projektion dar; Spannung und Strom eines ideal ohmschen Widerstands sind bei gleicher Bezugsrichtung in Phase.
  - Essential understanding (EN): A phasor represents amplitude and phase of a sinusoidal quantity using a specified projection; voltage and current in an ideal ohmic resistor are in phase under consistent reference directions.
  - Observable performance (DE): Konstruiert Zeiger aus Zeitfunktionen oder umgekehrt und kennzeichnet Projektion, Drehsinn, Einheiten und Amplitudenskalierung.
  - Observable performance (EN): Constructs phasors from time functions or vice versa and labels projection, rotation direction, units, and amplitude scales.
- `relative-phase`
  - Essential understanding (DE): Die relative Phase zwischen Spannung und Strom ist von der gemeinsamen Phase gegenüber dem Zeitursprung zu unterscheiden; Zeiger sind keine räumlichen Bewegungen von Ladungen.
  - Essential understanding (EN): Relative phase between voltage and current differs from their common phase relative to the time origin; phasors are not spatial charge trajectories.
  - Observable performance (DE): Deutet Gleichzeitigkeit von Nulldurchgängen und Extrema und überträgt die Darstellung auf einen geänderten Zeitursprung.
  - Observable performance (EN): Interprets simultaneous zero crossings and extrema and transfers the representation to a changed time origin.

**Coverage expectations**

- required expectations: `phasor-projection`, `relative-phase`
- alternative expectation groups: None
- minimum independent demonstrations: 2
- fresh variation required: true
- independent transfer required: true

**Variation axes**

- `time-to-phasor-and-back`: Zeitfunktion in ein Zeigerbild übersetzen und ein gegebenes gemeinsam gedrehtes Zeigerpaar zurück in Zeitfunktionen übertragen. / Translate a time function into phasors and convert a given commonly rotated phasor pair back into time functions.

**Application cases**

- `ohmic-sine`
  - Task demand (DE): Für einen ideal ohmschen Widerstand R=200 Ω in einem Kleinspannungsmodell gilt u(t)=4 sin(200πt) V, t in s, bei zueinander passenden Spannungs- und Strombezugsrichtungen. Bestimme i(t), zeichne beide Amplitudenzeiger und erkläre die Phasenbeziehung. Verwende Sinusprojektion auf die positive vertikale Achse; Winkel werden von der positiven horizontalen Achse gegen den Uhrzeigersinn gezählt, und die Zeiger rotieren mit positiver Kreisfrequenz gegen den Uhrzeigersinn.
  - Task demand (EN): For an ideal ohmic resistor R=200 Ω in a low-voltage model, u(t)=4 sin(200πt) V with t in s and mutually consistent voltage and current references. Determine i(t), draw both amplitude phasors, and explain their phase relationship. Use sine projection onto the positive vertical axis; angles are measured counterclockwise from the positive horizontal axis, and the phasors rotate counterclockwise with positive angular frequency.
  - Expected performance (DE): i(t)=0,020 sin(200πt) A. Ergänzend, nicht als zusätzliche Pflichtleistung: f=100 Hz und T=10 ms.  beide Zeiger sind gleichgerichtet und rotieren mit derselben Kreisfrequenz. Nulldurchgänge und Maxima sind gleichzeitig, Δφ=0. Zeigerlängen benötigen getrennte V- und A-Skalen; sie werden nicht als gleichartige räumliche Vektoren addiert.
  - Expected performance (EN): i(t)=0.020 sin(200πt) A. Supplementally, not as an additional required performance: f=100 Hz and T=10 ms.  the two phasors are aligned and rotate at the same angular frequency. Zero crossings and maxima coincide, Δφ=0. Lengths need separate V and A scales; the phasors are not added as like physical spatial vectors.
  - Understanding focus (DE): Ohmsches Verhalten als proportionale, phasengleiche Zeitverläufe darstellen.
  - Understanding focus (EN): Represent ohmic behaviour as proportional, in-phase time signals.
- `shifted-time-origin`
  - Task demand (DE): Bei Kosinusprojektion auf die positive horizontale Achse liegen die Amplitudenzeiger eines ideal ohmschen Kreises bei t=0 beide unter −60° zur Projektionsachse. Winkel werden gegen den Uhrzeigersinn gezählt; beide Zeiger rotieren gegen den Uhrzeigersinn mit derselben Kreisfrequenz ω>0. Bei zueinander passenden Spannungs- und Strombezugsrichtungen sind ihre Beträge 6 V und 30 mA. Gib Zeitfunktionen und Anfangswerte an. Eilt der Strom um 60° nach?
  - Task demand (EN): With cosine projection onto the positive horizontal axis, both amplitude phasors of an ideal ohmic circuit lie at −60° to the projection axis at t=0. Angles are measured counterclockwise; both phasors rotate counterclockwise at the same angular frequency ω>0. With mutually consistent voltage and current references, their magnitudes are 6 V and 30 mA. State time functions and initial values. Does the current lag by 60°?
  - Expected performance (DE): u=6 cos(ωt−π/3) V und i=0,030 cos(ωt−π/3) A; u(0)=3 V, i(0)=15 mA. Beide besitzen denselben Anfangswinkel, daher beträgt ihre relative Phase 0 und R=200 Ω. Der gemeinsame Winkel beschreibt den gewählten Zeitursprung, keinen Stromnachlauf.
  - Expected performance (EN): u=6 cos(ωt−π/3) V and i=0.030 cos(ωt−π/3) A; u(0)=3 V and i(0)=15 mA. Both share the same initial angle, so relative phase is 0 and R=200 Ω. The common angle describes the chosen time origin, not current lag.
  - Understanding focus (DE): Absolute Zeigerlage von einer physikalischen Phasendifferenz unterscheiden.
  - Understanding focus (EN): Distinguish absolute phasor orientation from physical phase difference.
## Page 3: Strom-Spannungs-Kennlinien einfacher Bauteile experimentell untersuchen und deuten

- Full learning-goal ID: `66256e22-44a3-5939-8862-821e29d6711d`
- Goal fingerprint: `sha256:726ad86f33f10e44be128ce796c0746610fac16ade219f5423617b912faf4b64`
- Page fingerprint: `sha256:8135cda54cd13d097e96dd8da52b20ec929e52c1a00de32c682d733ae3f9f872`
- Topic path: Physik

### Canonical description

Die lernende Person kann unter sicheren Kleinspannungsbedingungen Stromstärke und Spannung an einfachen Bauteilen systematisch messen, Kennlinien erstellen und den Zusammenhang von Spannung, Stromstärke und Widerstand deuten.

### Visualization

/assets/goal-visualizations/physik/66256e22-44a3-5939-8862-821e29d6711d/66256e22-44a3-5939-8862-821e29d6711d.jpg

- original digest: `sha256:ce7d822c6609a2ccecf73352d5cca2f30c7b4fe1b319e8089427a18bed84c419`
- QA status: `approved`
- approved for public publication: `true`

### Direct prerequisites

- None

### Direct reverse prerequisites

- None

### Prerequisites outside this book

- Zusammenhang von Spannung und Stromstärke qualitativ erläutern — `53196a71-9dbd-4835-b2f9-ff21b8a8962c` (outside this book)
- Proportionale Zusammenhänge mit Quotientengleichheit prüfen — `c1f50bcc-7848-4e49-b9de-0ec030cc6bca` (outside this book)

### Direct reverse prerequisites outside this book

- Sek-I-Abschlussaufgaben Physik selbstständig lösen — `3631c8f7-ff48-57ff-b7ee-8397ff1d166a` (outside this book)
- Prüfungsaufgabe: Kennlinien und Widerstandsnetze untersuchen — `5a530302-1303-517f-82cc-9cd457b792a8` (outside this book)
- Prüfungsaufgabe: Leitfähigkeit, Kennlinien und Widerstandsnetze untersuchen — `924e1187-a067-5eb6-8d8d-85525ee6c837` (outside this book)

### Evidence-profile candidate

Status: `needs_human_review`; profile fingerprint: `sha256:394b0e71fda1355701b924da3e5b5f47f90dca22fba4c6c235e63cc3ca9fbbd6`
Contract: `positive-understanding-evidence-v2`; authority: `ai_candidate`; evidence level: `E1`; maximum claim scope: `G1`
Archetype: `experiment`

**Positive understanding expectations**

- `measurement-circuit-binds-voltage-and-current`
  - Essential understanding (DE): Jeder Kennlinienpunkt besteht aus Spannung am Bauteil und Stromstärke durch dasselbe Bauteil im selben Betriebszustand. Das Strommessgerät liegt im betreffenden Zweig, das Spannungsmessgerät erfasst die Potenzialdifferenz über dem Bauteil; eine falsche Anordnung verändert oder gefährdet den Messaufbau und liefert keine gültige Wertepaarung.
  - Essential understanding (EN): Each point on a characteristic consists of the voltage across the component and the current through that same component in the same operating state. The ammeter is in the relevant branch and the voltmeter measures the potential difference across the component; an incorrect arrangement changes or endangers the setup and does not yield a valid pair of values.
  - Observable performance (DE): Die lernende Person konstruiert oder korrigiert für ein unbekanntes Bauteil eine sichere Kleinspannungs-Messschaltung, kennzeichnet die beiden gemessenen Größen am Bauteil und begründet, weshalb jedes protokollierte U-I-Paar denselben stabilen Betriebspunkt beschreiben muss.
  - Observable performance (EN): For an unfamiliar component, the learner constructs or corrects a safe low-voltage measuring circuit, labels the two measured quantities at the component, and explains why each recorded voltage-current pair must describe the same stable operating point.
- `controlled-sweep-produces-defensible-data`
  - Essential understanding (DE): Eine aussagekräftige Kennlinie entsteht durch systematische Änderung einer Größe bei kontrollierten Bedingungen, genügend Messpunkten und Einhaltung der bereitgestellten Bauteil- und Kleinspannungsgrenzen. Erwärmung, Polarität, Messbereich und Ableseunsicherheit können die Daten beeinflussen und müssen je nach Bauteil kontrolliert oder dokumentiert werden.
  - Essential understanding (EN): A defensible characteristic is produced by systematically varying one quantity under controlled conditions, taking enough data points, and respecting supplied component and safe-low-voltage limits. Heating, polarity, instrument range, and reading uncertainty can affect the data and must be controlled or documented as appropriate to the component.
  - Observable performance (DE): Die lernende Person plant für ein bereitgestelltes Kleinspannungsbauteil eine Messreihe mit sinnvoller Schrittfolge, Nullpunkt, Messbereichen, Wiederholungen oder Wartebedingungen, dokumentiert Einheiten und Unsicherheiten und begründet, welche Variable verändert und welche Bedingungen konstant gehalten werden.
  - Observable performance (EN): For a supplied low-voltage component, the learner plans a data series with a sensible sequence of steps, zero point, instrument ranges, repetitions or waiting conditions, records units and uncertainties, and justifies which variable is changed and which conditions are held constant.
- `graph-shape-distinguishes-ohmic-and-nonohmic-behavior`
  - Essential understanding (DE): Bei festgelegter Achsenwahl zeigt ein ohmsches Bauteil unter konstanten Bedingungen eine Gerade durch den Ursprung; dann bleibt U/I konstant. Bei einer gekrümmten oder richtungsabhängigen Kennlinie ändert sich U/I mit dem Betriebspunkt. Für I über U ist die Steigung der ohmschen Ursprungsgeraden der Leitwert G=I/U in S, nicht die Materialleitfähigkeit in S/m. Bei einer nichtlinearen Kennlinie beschreibt eine Sekantensteigung ΔI/ΔU die Änderung zwischen zwei Betriebspunkten; eine lokale Steigung beschreibt die Änderung in einer kleinen Umgebung. Beide dürfen nicht mit I/U oder dem Widerstandsquotienten U/I gleichgesetzt werden.
  - Essential understanding (EN): With a stated choice of axes, an ohmic component under constant conditions gives a straight line through the origin, so U/I remains constant. For a curved or direction-dependent characteristic, U/I changes with the operating point. For current plotted against voltage, the slope of the ohmic line through the origin is conductance G=I/U in S, not material conductivity in S/m. For a nonlinear characteristic, a secant slope ΔI/ΔU describes change between two operating points; a local slope describes change in a small neighborhood. Neither may be equated with I/U or the resistance ratio U/I.
  - Observable performance (DE): Die lernende Person erstellt aus frischen Messdaten ein beschriftetes Diagramm, prüft Linearität und Ursprung, bestimmt oder vergleicht U/I an mehreren nichtverschwindenden Punkten, deutet die Form physikalisch und korrigiert eine Steigungsinterpretation anhand der Achsen. Wird eine nichtlineare Steigung verwendet, unterscheidet sie qualitativ oder anhand benachbarter Messpunkte die Steigung vom Quotienten zum Ursprung; eine Ableitungsrechnung ist dafür nicht erforderlich.
  - Observable performance (EN): The learner constructs a labelled graph from fresh measurements, checks linearity and the origin, determines or compares U/I at several nonzero points, interprets the shape physically, and corrects a slope interpretation using the axes. If a nonlinear slope is used, the learner distinguishes it from the ratio to the origin qualitatively or using neighboring measurements; derivative calculation is not required.
- `characteristic-supports-bounded-prediction-and-model-check`
  - Essential understanding (DE): Eine Kennlinie erlaubt Ablesen oder Interpolation nur im untersuchten Zustands- und Messbereich. Abweichende Kurven bei geänderter Temperatur, Polarität oder Bauteilart sind physikalische Information und nicht automatisch Messfehler; weite Extrapolation oder die Annahme eines konstanten Widerstands benötigen zusätzliche Begründung.
  - Essential understanding (EN): A characteristic supports reading or interpolation only within the investigated state and measurement range. Different curves when temperature, polarity, or component type changes are physical information rather than automatically measurement error; wide extrapolation or assuming constant resistance requires additional justification.
  - Observable performance (DE): Die lernende Person nutzt eine unbekannte Kennlinie für eine Vorhersage innerhalb des Messbereichs, nennt eine angemessene Unsicherheit, vergleicht sie mit einem neuen Datenpunkt und entscheidet begründet, ob Messstreuung, Zustandsänderung oder ein ungeeignetes ohmsches Modell die Abweichung erklärt.
  - Observable performance (EN): The learner uses an unfamiliar characteristic to make a prediction within the measured range, states an appropriate uncertainty, compares it with a new data point, and decides with justification whether scatter, a change of state, or an unsuitable ohmic model explains the discrepancy.

**Coverage expectations**

- required expectations: `measurement-circuit-binds-voltage-and-current`, `controlled-sweep-produces-defensible-data`, `graph-shape-distinguishes-ohmic-and-nonohmic-behavior`, `characteristic-supports-bounded-prediction-and-model-check`
- alternative expectation groups: None
- minimum independent demonstrations: 3
- fresh variation required: true
- independent transfer required: true

**Variation axes**

- `component-behavior`: Ohmscher Widerstand, Glühlampe oder polungsabhängiges einfaches Bauteil innerhalb bereitgestellter sicherer Grenzwerte / Ohmic resistor, filament lamp, or polarity-dependent simple component within supplied safe limits
- `state-and-control`: Konstante Temperatur, merkliche Erwärmung, auf- und absteigende Messfolge oder vertauschte Polarität / Constant temperature, appreciable heating, increasing and decreasing sweep, or reversed polarity
- `data-quality`: Dichte oder grobe Messpunktfolge, Wiederholungen, Ausreißer und unterschiedliche Messunsicherheiten / Dense or coarse sequence of points, repeated readings, outliers, and different measurement uncertainties
- `representation-and-task`: Messschaltung, Tabelle, U-über-I- oder I-über-U-Diagramm sowie Vorhersage oder Fehlerdiagnose / Measuring circuit, table, voltage-versus-current or current-versus-voltage graph, and prediction or fault diagnosis

**Application cases**

- `independent-circuit-and-controlled-acquisition`
  - Task demand (DE): Untersuche in einer Kleinspannungssimulation ein unbekanntes einfaches Bauteil: Ist I bei unverändertem Zustand proportional zu U? Bereitgestellt sind eine regelbare Gleichspannungsquelle von 0 bis 3,0 V mit Strombegrenzung auf 4,0 mA, ein Spannungsmessbereich 0 bis 5 V mit Ableseunsicherheit ±0,02 V und Strommessbereiche 0 bis 2 mA (±0,01 mA) beziehungsweise 0 bis 20 mA (±0,10 mA). Für das Bauteil gelten höchstens 3,0 V und 4,0 mA; im Simulationsmodell belasten die Messgeräte die Schaltung nicht. Konstruiere ohne Vorlage die Messschaltung und kennzeichne die Messgrößen. Wähle und begründe selbst Messbereiche, Spannungsfolge, genügend Messpunkte und Kontrollen oder Wiederholungen; erhebe zusammengehörige Wertepaare mit Einheiten und Unsicherheiten. Erstelle daraus die Kennlinie, prüfe deine Frage und begründe eine Nachmessung oder eine begrenzte Vorhersage. Die Angaben liefern Grenzen und Geräte, keine fertige Messfolge oder Kennlinie.
  - Task demand (EN): Investigate an unfamiliar simple component in a low-voltage simulation: is I proportional to U when its state is unchanged? Available are an adjustable DC supply from 0 to 3.0 V with a 4.0 mA current limit, a voltage range of 0 to 5 V with reading uncertainty ±0.02 V, and current ranges of 0 to 2 mA (±0.01 mA) or 0 to 20 mA (±0.10 mA). The component limits are 3.0 V and 4.0 mA; in this simulation the meters do not load the circuit. Construct the measuring circuit without a template and label the measured quantities. Independently choose and justify the instrument ranges, voltage sequence, sufficient data points, and controls or repetitions; acquire paired readings with units and uncertainties. Plot the characteristic, test your question, and justify a repeat measurement or bounded prediction. The information supplies limits and instruments, not a completed sweep or characteristic.
  - Expected performance (DE): Die lernende Person platziert das Strommessgerät im Bauteilzweig und das Spannungsmessgerät parallel zum Bauteil und nennt die nichtbelastende Modellannahme. Sie begründet eine eigene sichere Bereichswahl und passt sie nach ersten Ablesungen an, ohne einen Messbereich zu überschreiten; sie berücksichtigt Nullpunkt, Paarung im gleichen Zustand, Temperatur beziehungsweise Wartezeit und geeignete Kontrollablesungen. Ihre selbst erhobenen Daten und ihr Diagramm tragen Einheiten und Unsicherheiten. Sie prüft Ursprungsverlauf und U/I außerhalb von U=I=0 und begründet die modell- und bereichsgebundene Schlussfolgerung. Andere nachvollziehbar sichere und aussagekräftige Messpläne sind gleichwertig; das Wiedergeben eines fertigen Plans genügt nicht. Organisatorische oder sicherheitsbezogene Anleitung zur Bedienung der Simulation ist zulässig; die zu bewertenden Schaltungs-, Mess- und Deutungsentscheidungen trifft und begründet die lernende Person selbst.
  - Expected performance (EN): The learner places the ammeter in the component branch and the voltmeter in parallel with the component and states the nonloading model assumption. The learner justifies an independently chosen safe range and adapts it after initial readings without exceeding a meter range, accounting for the zero point, pairing in the same state, temperature or waiting time, and suitable control readings. The learner-generated data and graph include units and uncertainties. The learner checks the origin and U/I outside U=I=0 and justifies a model- and range-limited conclusion. Other defensibly safe and informative plans are equivalent; reproducing a completed plan is insufficient. Organizational or safety guidance in operating the simulation is permitted; the learner independently makes and justifies the circuit, measurement, and interpretation decisions being assessed.
  - Understanding focus (DE): Eigenständige Schaltungs- und Messentscheidungen verbinden sichere Datenerhebung, Betriebspunktpaarung, Kennlinie und physikalische Deutung zu einer zusammenhängenden Untersuchung.
  - Understanding focus (EN): Independent circuit and measurement choices connect safe data acquisition, operating-point pairing, the characteristic, and physical interpretation in one coherent investigation.
- `resistor-data-with-one-mismatched-point`
  - Task demand (DE): Eine sichere Kleinspannungs-Messreihe an einem Widerstand enthält sechs zusammengehörige U-I-Paare und einen siebten Eintrag, dessen Stromwert versehentlich aus dem vorherigen Betriebspunkt übernommen wurde. Zeichne die Kennlinie mit Unsicherheitsangaben, identifiziere den verdächtigen Punkt und entscheide, welche Nachmessung das ohmsche Modell fair prüft.
  - Task demand (EN): A safe low-voltage data series for a resistor contains six paired voltage-current values and a seventh entry whose current was accidentally copied from the preceding operating point. Plot the characteristic with uncertainty information, identify the suspect point, and decide what repeat measurement would fairly test the ohmic model.
  - Expected performance (DE): Die lernende Person beschriftet Achsen und Einheiten, erkennt sechs annähernd lineare Ursprungspunkte, markiert den unpassenden Wertepaarpunkt, verlangt eine erneute simultane Ablesung dieses Betriebspunkts und entscheidet erst danach anhand von U/I und Unsicherheit über ohmsches Verhalten.
  - Expected performance (EN): The learner labels axes and units, recognizes six approximately linear points through the origin, marks the inconsistent paired point, calls for a fresh simultaneous reading at that operating point, and only then uses U/I and uncertainty to decide whether the behavior is ohmic.
  - Understanding focus (DE): Der gebrochene Wertepaarbezug prüft, ob Kennlinienpunkte als reale gemeinsame Betriebszustände verstanden werden.
  - Understanding focus (EN): The broken pairing tests whether characteristic points are understood as real shared operating states.
- `lamp-heating-up-and-down-sweep`
  - Task demand (DE): Für eine Kleinspannungs-Glühlampe liegen Messwerte einer langsam aufsteigenden und einer unmittelbar absteigenden Spannungsfolge vor. Erstelle beide Kennlinien, vergleiche U/I bei mehreren Punkten und entwickle eine Erklärung, in der die Temperatur des Glühfadens als kontrollierter beziehungsweise veränderter Zustand vorkommt.
  - Task demand (EN): For a low-voltage filament lamp, data are supplied for a slowly increasing voltage sweep and an immediately decreasing sweep. Construct both characteristics, compare U/I at several points, and develop an explanation that treats filament temperature as a controlled or changing state.
  - Expected performance (DE): Die lernende Person erkennt gekrümmte, gegebenenfalls leicht verschiedene Verläufe, zeigt den nicht konstanten Quotienten U/I, verbindet größeren Widerstand mit dem erwärmten Glühfaden und nennt Messfolge sowie Wartezeit als relevante Bedingungen statt die Kurve als bloßen Messfehler zu verwerfen.
  - Expected performance (EN): The learner recognizes curved and possibly slightly different traces, demonstrates that U/I is not constant, connects greater resistance with the heated filament, and identifies sweep order and waiting time as relevant conditions instead of dismissing the curve as mere measurement error.
  - Understanding focus (DE): Die Zustandsänderung trennt nichtohmsches Verhalten von einer formalen Gerade-durch-Ursprung-Prüfung ohne Physik.
  - Understanding focus (EN): The change of state separates non-ohmic behavior from a purely formal straight-line-through-origin test without physical interpretation.
- `polarity-dependent-component-supplied-data`
  - Task demand (DE): Eine Simulation eines polungsabhängigen Kleinspannungsbauteils liefert sichere U-I-Daten für beide Polaritäten und nennt eine zulässige Stromgrenze. Plane eine sinnvolle graphische Darstellung, klassifiziere den richtungsabhängigen Verlauf und sage innerhalb des untersuchten Bereichs einen Stromwert für eine neue Spannung voraus, ohne über die Grenze zu extrapolieren. Gib die Unsicherheit deiner Vorhersage an und benenne, falls nötig, zusätzliche Unsicherheit durch die Interpolation.
  - Task demand (EN): A simulation of a polarity-dependent low-voltage component supplies safe voltage-current data for both polarities and states an allowable current limit. Plan a suitable graph, classify the direction-dependent behavior, and predict a current for a new voltage within the investigated range without extrapolating beyond the limit. State the uncertainty of your prediction and, where needed, additional uncertainty from interpolation.
  - Expected performance (DE): Die lernende Person erhält Vorzeichen und Polarität in Tabelle und Diagramm, erkennt den asymmetrischen nichtohmschen Verlauf, interpoliert nur im belegten Bereich mit Unsicherheit und erklärt, weshalb weder ein konstanter Widerstand noch eine spiegelbildliche Fortsetzung in die andere Polarität gerechtfertigt ist.
  - Expected performance (EN): The learner preserves sign and polarity in the table and graph, recognizes the asymmetric non-ohmic behavior, interpolates only within the evidenced range with uncertainty, and explains why neither a constant resistance nor a mirror-image continuation into the other polarity is justified.
  - Understanding focus (DE): Polaritätswechsel und sichere Bereichsgrenze prüfen Modellwahl, Vorzeichenverständnis und begrenzten Transfer.
  - Understanding focus (EN): Changing polarity and imposing a safe range limit test model choice, sign understanding, and bounded transfer.
