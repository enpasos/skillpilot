import json,gzip,pathlib,collections,hashlib
root=pathlib.Path('/home/enpasos/projects/skillpilot'); d=json.load(gzip.open(root/'qa-artifacts/ci-contract-audit/2026-11-06/visualization-five-ledger-original-evidence-census-full/artifact-discovery.json.gz'))['files'];gs={};qs={}
for s in ['biologie']:
 gs[s]={g['id']:g for g in json.loads((root/f'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_{s.upper()}.de.json').read_bytes())['goals']};qs[s]={r['goalId']:r for r in json.loads((root/f'curricula/DE/Gymnasium/quality/goal-visualization-qa/{s}.qa.json').read_bytes())['records']}
rows=[];examined=[]
for f in d:
 p=f['path']
 if not p.endswith(('.md','.txt')) or not any(w in p.lower()for w in ['biolog']):continue
 data=(root/p).read_bytes();assert hashlib.sha256(data).hexdigest()==f['sha256'];t=data.decode('utf8');examined.append({'path':p,'sha256':f['sha256']})
 for s in gs:
  for gid,g in gs[s].items():
   if gid not in qs[s]or gid not in t:continue
   if g.get('description')in t and qs[s][gid]['assetSha256'].removeprefix('sha256:')in t:rows.append({'subject':s,'goalId':gid,'path':p,'sha256':f['sha256']})
o={'examined':examined,'candidateRows':rows};path=pathlib.Path('/dev/shm/skillpilot-v-biology-original-md-context-candidates.json');path.write_text(json.dumps(o,ensure_ascii=False,indent=2));print('examined',len(examined),'candidates',len(rows));print('\n'.join(f"{len(v)} {p}"for p,v in collections.defaultdict(list).items()))
for r in rows:print(r['subject'],r['goalId'],r['path'])
