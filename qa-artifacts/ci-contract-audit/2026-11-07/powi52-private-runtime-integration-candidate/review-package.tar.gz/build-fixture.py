from pathlib import Path
import json,gzip,hashlib,copy,os
R=Path('/home/enpasos/projects/skillpilot');W=Path('/dev/shm/powi52-runtime-alias-20261107');F=W/'fixture-root';I=R/'qa-artifacts/ci-contract-audit/2026-11-07/powi-id-correction-inventory';plan=json.loads((I/'first-batch-plan.json').read_text());source=R/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_POLITIKWIRTSCHAFT.de.json'
assert hashlib.sha256(source.read_bytes()).hexdigest()==plan['sourceSha256'];rename={r['sourceGoalId']:r['targetGoalId'] for r in plan['ids']};assert len(rename)==52 and len(set(rename.values()))==52
pointers=[r for r in json.loads(gzip.decompress((I/'active-reference-pointers.json.gz').read_bytes())) if r['before'] in rename]
assert len(pointers)==2152;byfile={}
for r in pointers:assert r['after']==rename[r['before']];byfile.setdefault(r['path'],[]).append(r)
assert len(byfile)==44
for p in (R/'curricula').rglob('*.json'):
 if p.is_file() and str(p.relative_to(R)) not in byfile:
  q=F/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True)
  if not q.exists():q.symlink_to(p)
rows=[]
def setptr(j,p,val,expected):
 parts=p.split('/')[1:];v=j
 for x in parts[:-1]:x=x.replace('~1','/').replace('~0','~');v=v[int(x)] if isinstance(v,list) else v[x]
 x=parts[-1].replace('~1','/').replace('~0','~');x=int(x) if isinstance(v,list) else x;assert v[x]==expected;v[x]=val
for path,rs in byfile.items():
 old=(R/path).read_bytes();j=json.loads(old);after=copy.deepcopy(j)
 for r in rs:setptr(after,r['pointer'],r['after'],r['before'])
 inv=copy.deepcopy(after)
 for r in reversed(rs):setptr(inv,r['pointer'],r['before'],r['after'])
 assert inv==j
 out=json.dumps(after,ensure_ascii=False,indent=2).encode()+b'\n';q=F/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(out)
 rows.append({'path':path,'beforeSha256':hashlib.sha256(old).hexdigest(),'afterSha256':hashlib.sha256(out).hexdigest(),'typedFields':len(rs),'inverseFullDocumentEquality':True})
(W/'private-data-pins.json').write_text(json.dumps({'status':'private-id-only-testframe-not-admissible-source-proof','finiteSubset':52,'typedFields':2152,'files':44,'cardOriginsChanged':0,'memoryGoalIdentitiesChanged':0,'pins':rows},indent=2)+'\n')
print('fixture',F,'44 exact typed docs projected, 2152 fields, inverse match')
