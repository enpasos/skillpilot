package com.skillpilot.backend.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skillpilot.backend.api.FrontierGoal;
import com.skillpilot.backend.api.LearnerLearningPlanApi;
import com.skillpilot.backend.api.LearnerPlanTodayStatus;
import com.skillpilot.backend.api.LearnerPlanningScopeResponse;
import com.skillpilot.backend.api.UnifiedLearnerStateResponse;
import com.skillpilot.backend.domain.Learner;
import com.skillpilot.backend.domain.LearnerLearningPlan;
import com.skillpilot.backend.events.LearnerStateChangedEvent;
import com.skillpilot.backend.landscape.LandscapeService;
import com.skillpilot.backend.landscape.SkillLandscape;
import com.skillpilot.backend.repository.LearnerLearningPlanRepository;
import com.skillpilot.backend.service.learningplan.PeriodBasis;
import com.skillpilot.backend.service.learningplan.PlanBalanceInputs;
import com.skillpilot.backend.service.learningplan.PlanBalanceResult;
import com.skillpilot.backend.service.learningplan.UnifiedLearningPlanStatusCalculator;
import com.skillpilot.backend.service.learningplan.UnifiedLearningPlanStatusFormatter;
import com.skillpilot.backend.service.learningplan.LearningPlanScopeResolver;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Clock;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.function.Function;
import org.springframework.http.HttpStatus;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/** Owns learner-side plan persistence and plan-to-learning transitions. */
@Service
public class LearnerLearningPlanService {

    static final double MASTERY_THRESHOLD = 0.9;
    private static final int MAX_BLOCKS = 500;
    private static final int MAX_ATOMIC_IDS = 10_000;
    private static final int MAX_ACTIVATION_PLANS = 50;
    private static final int PREVIEW_DAYS = 7;
    private static final int MAX_BLOCK_TITLE_LENGTH = 500;
    private static final long MAX_BLOCK_SPAN_DAYS = 36_600;
    private static final LocalDate MIN_PLAN_DATE = LocalDate.of(0, 1, 1);
    private static final LocalDate MAX_PLAN_DATE = LocalDate.of(9999, 12, 31);
    private static final ZoneId PLAN_ZONE = ZoneId.of("Europe/Berlin");
    private static final TypeReference<List<LearnerLearningPlanApi.Block>> BLOCK_LIST_TYPE =
            new TypeReference<>() { };

    private final LearnerLearningPlanRepository plans;
    private final LearnerService learners;
    private final ObjectMapper objectMapper;
    private final ApplicationEventPublisher eventPublisher;
    private final LandscapeService landscapeService;
    private final Clock clock;
    private final com.skillpilot.backend.completion.LearningPlanCompletionProjection completionProjection =
            new com.skillpilot.backend.completion.LearningPlanCompletionProjection();

    /** Operation-local result: no learner outcome is retained in a shared cache. */
    private record PlanFulfillment(Map<String, Set<String>> waivedByLandscape, Set<String> unavailable) {
        Set<String> waived(String landscapeId) {
            if (unavailable.contains(landscapeId)) {
                throw conflict("Learning-plan completion calculation is currently unavailable");
            }
            return waivedByLandscape.getOrDefault(landscapeId, Set.of());
        }
    }

    private PlanFulfillment planFulfillment(String learnerId, List<LearnerLearningPlan> planInputs,
            Map<String, Double> mastery) {
        Map<String, Set<String>> obligationsByLandscape = new LinkedHashMap<>();
        Set<String> invalidObligations = new HashSet<>();
        Set<String> invalid = new HashSet<>();
        Map<String, Set<String>> obligationsBySubject = new LinkedHashMap<>();
        for (var plan : planInputs) {
            try {
                List<LearnerLearningPlanApi.Block> blocks = readBlocks(plan);
                obligationsByLandscape.put(plan.getLandscapeId(), atomicIds(blocks));
                requireCurrentBlocks(learnerId, plan);
                Set<String> obligations = new LinkedHashSet<>(atomicIds(blocks));
                // Keep the authored obligation scope, including goals already mastered
                // before G was captured. A later revocation must still block a waiver.
                for (var block : blocks) {
                    if (!block.isActive() || block.focusGoalIds().isEmpty()
                            || !("learning".equals(block.kind()) || "milestone".equals(block.kind()))) continue;
                    try {
                        obligations.addAll(learners.resolveLearningPlanGoalIds(
                                learnerId, plan.getLandscapeId(), block.focusGoalIds()));
                    } catch (ResponseStatusException e) {
                        if (block.goalIds() != null || e.getStatusCode().is5xxServerError()) throw e;
                        // Historical single milestone labels were not authoritative scopes.
                    }
                }
                obligationsByLandscape.put(plan.getLandscapeId(), Set.copyOf(obligations));
                String subject = stableSubjectKey(plan.getLandscapeId());
                if (subject == null) throw conflict("Learning-plan subject cannot be resolved");
                obligationsBySubject.computeIfAbsent(subject, ignored -> new LinkedHashSet<>()).addAll(obligations);
            } catch (RuntimeException e) {
                invalidObligations.add(plan.getLandscapeId());
            }
        }
        Map<String, Set<String>> waived = new LinkedHashMap<>();
        Map<String, Set<String>> resolvedBySubject = new LinkedHashMap<>();
        Set<String> unavailableSubjects = new HashSet<>();
        com.skillpilot.backend.completion.LearningPlanCompletionContext automaticContext = null;
        Set<String> automaticTargets = null;
        Set<String> automaticWaived = null;
        RuntimeException automaticFailure = null;
        for (var entry : obligationsByLandscape.entrySet()) {
            String subject = stableSubjectKey(entry.getKey());
            if (unavailableSubjects.contains(subject)) { invalid.add(entry.getKey()); continue; }
            if (resolvedBySubject.containsKey(subject)) {
                waived.put(entry.getKey(), resolvedBySubject.get(subject));
                continue;
            }
            try {
                Set<String> allObligations = obligationsBySubject.getOrDefault(subject, entry.getValue());
                var context = automaticContext != null ? automaticContext
                        : learners.getLearningPlanCompletionContext(learnerId, allObligations);
                if (context == null) {
                    waived.put(entry.getKey(), Set.of());
                    resolvedBySubject.put(subject, Set.of());
                    continue;
                }
                if (subject == null || invalidObligations.stream()
                        .anyMatch(id -> Objects.equals(subject, stableSubjectKey(id)))) {
                    throw conflict("An active subject plan obligation scope cannot be resolved");
                }
                Set<String> resolved;
                if (context.semantics()
                        == com.skillpilot.backend.completion.LearningPlanCompletionContext.Semantics.AUTOMATIC) {
                    // All dated plans share one Personal Curriculum and one mastery
                    // snapshot within this operation. Compute its demand exactly once;
                    // subject quotas and individual schedules only select the result.
                    automaticContext = context;
                    if (automaticTargets == null) automaticTargets = context.level2TargetGoalIds().stream()
                            .filter(id -> {
                                var goal = context.canonicalGoals().get(id);
                                return goal == null || goal.getContains() == null || goal.getContains().isEmpty();
                            }).collect(java.util.stream.Collectors.toUnmodifiableSet());
                    if (!automaticTargets.containsAll(allObligations)) {
                        throw conflict("Plan obligations are outside the atomic Personal Curriculum targets");
                    }
                    if (automaticFailure != null) throw automaticFailure;
                    if (automaticWaived == null) {
                        try {
                            automaticWaived = completionProjection.waivedGoals(context, automaticTargets,
                                    ids -> learners.resolveLearningPlanCompletionMastery(learnerId, mastery, ids));
                        } catch (RuntimeException e) {
                            automaticFailure = e;
                            throw e;
                        }
                    }
                    Set<String> subjectWaived = new LinkedHashSet<>(automaticWaived);
                    subjectWaived.retainAll(allObligations);
                    resolved = Set.copyOf(subjectWaived);
                } else {
                    resolved = completionProjection.waivedGoals(context, allObligations,
                            ids -> learners.resolveLearningPlanCompletionMastery(learnerId, mastery, ids));
                }
                resolvedBySubject.put(subject, resolved);
                waived.put(entry.getKey(), resolved);
            } catch (RuntimeException e) {
                invalid.add(entry.getKey());
                unavailableSubjects.add(subject);
            }
        }
        return new PlanFulfillment(Map.copyOf(waived), Set.copyOf(invalid));
    }

    private PlanFulfillment planFulfillment(String learnerId, String landscapeId,
            List<LearnerLearningPlanApi.Block> blocks, Map<String, Double> mastery) {
        List<LearnerLearningPlan> allPlans = new ArrayList<>(
                plans.findByLearner_SkillpilotIdOrderByLandscapeIdAsc(learnerId));
        allPlans.removeIf(plan -> landscapeId.equals(plan.getLandscapeId()));
        LearnerLearningPlan supplied = new LearnerLearningPlan();
        supplied.setLandscapeId(landscapeId);
        supplied.setCurriculumId(learners.getLearner(learnerId).getSelectedCurriculum());
        supplied.setBlocksJson(writeBlocks(blocks));
        allPlans.add(supplied);
        return planFulfillment(learnerId, allPlans, mastery);
    }

    private static Set<String> countedWaivers(Learner learner, Set<String> waived) {
        return Boolean.TRUE.equals(learner.getLearningPlanCountOnlyExplicitGoals()) ? Set.of() : waived;
    }


    @Autowired
    public LearnerLearningPlanService(
            LearnerLearningPlanRepository plans,
            LearnerService learners,
            ObjectMapper objectMapper,
            ApplicationEventPublisher eventPublisher,
            LandscapeService landscapeService) {
        this(
                plans,
                learners,
                objectMapper,
                eventPublisher,
                landscapeService,
                Clock.system(PLAN_ZONE));
    }

    LearnerLearningPlanService(
            LearnerLearningPlanRepository plans,
            LearnerService learners,
            ObjectMapper objectMapper,
            ApplicationEventPublisher eventPublisher,
            LandscapeService landscapeService,
            Clock clock) {
        this.plans = plans;
        this.learners = learners;
        this.objectMapper = objectMapper;
        this.eventPublisher = eventPublisher;
        this.landscapeService = landscapeService;
        this.clock = clock;
    }

    /**
     * Returns one backend-formulated period balance per subject using its captured
     * plan goals, current mastery and real completion events. Invalid part plans
     * make their subject unavailable; authorized continuation remains independent.
     */
    @Transactional
    public LearnerPlanTodayStatus getTodayStatus(
            String skillpilotId,
            String communicationLocale) {
        // The same learner lock used by mastery, preference and plan writes gives this
        // read a coherent snapshot. Locking never changes learner state or activity.
        learners.acquireLearningPlanMutationLock(skillpilotId);
        Learner learner = learners.getLearner(skillpilotId);
        return calculateStatus(skillpilotId, learner,
                plans.findByLearner_SkillpilotIdOrderByLandscapeIdAsc(skillpilotId),
                LocalDate.now(clock.withZone(PLAN_ZONE)), communicationLocale, false);
    }

    private LearnerPlanTodayStatus calculateStatus(
            String skillpilotId, Learner learner, List<LearnerLearningPlan> subjectPlans,
            LocalDate asOf, String communicationLocale, boolean preview) {
        return calculateStatus(skillpilotId, learner, subjectPlans, asOf,
                communicationLocale, preview, null);
    }

    private LearnerPlanTodayStatus calculateStatus(
            String skillpilotId, Learner learner, List<LearnerLearningPlan> subjectPlans,
            LocalDate asOf, String communicationLocale, boolean preview,
            StatusReadSnapshot snapshot) {
        PeriodBasis periodBasis = learner.getLearningPlanPeriodBasis();
        LocalDate periodStart = periodStart(periodBasis, asOf);
        LocalDate periodEnd = periodEnd(periodBasis, asOf);
        // Hosts pass the language stored with their learning session; the WebGUI
        // passes its chosen language. There is no separate learner-language setting.
        String effectiveLocale = normalizeLocale(communicationLocale);

        boolean enabled = com.skillpilot.backend.completion.CompletionNavigationPolicy.followsPlans(learner);
        String activeGoalId = learner.getActiveGoalId();
        Map<String, Double> mastery = snapshot == null
                ? learners.getMastery(skillpilotId) : snapshot.mastery();
        boolean activeGoalInProgress = activeGoalId != null
                && !activeGoalId.isBlank()
                && mastery.getOrDefault(activeGoalId, 0.0) < MASTERY_THRESHOLD;

        PlanFulfillment fulfillment = snapshot != null && snapshot.fulfillment() != null
                ? snapshot.fulfillment() : planFulfillment(skillpilotId, subjectPlans, mastery);

        // One balance per subject: every plan of the same subject is merged before the
        // calculation, so a goal shared by two plans counts once and its earliest valid
        // scheduled date wins. The stable subject key orders the output identically in
        // every channel.
        Map<String, SubjectAggregate> bySubject = new TreeMap<>();
        int unavailablePlanCount = 0;
        int unidentifiedPlanCount = 0;
        for (LearnerLearningPlan plan : subjectPlans) {
            String subjectKey = stableSubjectKey(plan.getLandscapeId());
            Optional<String> label = localizedSubjectLabel(plan.getLandscapeId(), effectiveLocale);
            if (subjectKey == null || label.isEmpty()) {
                unavailablePlanCount++;
                unidentifiedPlanCount++;
                continue;
            }
            SubjectAggregate aggregate = bySubject.computeIfAbsent(
                    subjectKey, key -> new SubjectAggregate(key, label.get()));
            aggregate.addPlan(plan.getLandscapeId());
            Optional<PlanEvaluation> evaluation = evaluatePlan(
                    skillpilotId,
                    plan,
                    asOf,
                    periodBasis,
                    periodStart,
                    periodEnd,
                    enabled,
                    activeGoalInProgress ? activeGoalId : null,
                    effectiveLocale, mastery, fulfillment);
            if (evaluation.isEmpty()) {
                unavailablePlanCount++;
                aggregate.markUnevaluable();
                continue;
            }
            aggregate.merge(evaluation.get());
        }

        // Missing plans do not create invented subject balances. An explicitly requested
        // personal-curriculum continuation remains independently available.
        boolean personalContinuationAvailable = false;
        if (enabled && !hasExamScope(skillpilotId, subjectPlans, asOf)) {
            for (String landscapeId : learners.getPersonalCurriculumSubjectIds(skillpilotId)) {
                String subjectKey = stableSubjectKey(landscapeId);
                SubjectAggregate aggregate = subjectKey == null ? null : bySubject.get(subjectKey);
                if (aggregate != null && (aggregate.evaluable() || aggregate.canContinue())) continue;
                if (!fulfillment.unavailable().contains(landscapeId)
                        && firstPersonalCurriculumGoal(skillpilotId, landscapeId, fulfillment.waived(landscapeId)).isPresent()) {
                    personalContinuationAvailable = true;
                    if (aggregate != null) aggregate.allowContinuation();
                }
                if (aggregate != null && activeGoalInProgress
                        && landscapeId.equals(landscapeService.getLandscapeIdForGoal(activeGoalId))) {
                    aggregate.markCurrent();
                }
            }
        }

        Map<String, Instant> periodCompletions = periodBasis == PeriodBasis.WEEK
                ? learners.getGoalCompletionsBetween(skillpilotId, periodStart, periodEnd)
                : learners.getGoalCompletionsOnDate(skillpilotId, asOf);
        // The dated plan captures only goals still open when it was created. The Cockpit's
        // overall achievement count instead uses every current Level-2 target in the subject,
        // including goals mastered before that plan and goals outside its dated blocks.
        Map<String, SubjectAchievement> achievementBySubject = snapshot == null || snapshot.achievements() == null
                ? currentSubjectAchievements(skillpilotId, mastery, bySubject.keySet())
                : snapshot.achievements();

        List<LearnerPlanTodayStatus.SubjectStatus> subjects = new ArrayList<>();
        List<String> subjectLines = new ArrayList<>();
        List<String> unavailableSubjectLabels = new ArrayList<>();
        for (SubjectAggregate aggregate : bySubject.values()) {
            LearnerPlanTodayStatus.SubjectStatus subject = aggregate.toSubjectStatus(
                    periodBasis, periodStart, periodEnd, mastery, periodCompletions,
                    countedWaivers(learner, aggregate.waivedGoalIds),
                    achievementBySubject.get(aggregate.subjectKey), effectiveLocale);
            subjects.add(subject);
            if (subject.subjectLine() != null && !subject.subjectLine().isBlank()) {
                subjectLines.add(subject.subjectLine());
            }
            if (!subject.evaluable() && !unavailableSubjectLabels.contains(subject.subjectLabel())) {
                unavailableSubjectLabels.add(subject.subjectLabel());
            }
        }

        LearnerPlanTodayStatus.ActiveGoal activeGoal = null;
        if (activeGoalInProgress) {
            com.skillpilot.backend.landscape.LearningGoal goal =
                    landscapeService.getGoalDefinition(activeGoalId);
            String title = localizedGoalTitle(goal, effectiveLocale);
            if (title != null) {
                activeGoal = new LearnerPlanTodayStatus.ActiveGoal(
                        activeGoalId, title,
                        UnifiedLearningPlanStatusFormatter.formatActiveGoalAnnouncement(title, effectiveLocale));
            }
        }

        String noticeText = UnifiedLearningPlanStatusFormatter.formatUnavailableNotice(
                unavailableSubjectLabels, effectiveLocale);
        String unidentifiedNotice = UnifiedLearningPlanStatusFormatter.formatUnidentifiedPlansNotice(
                unidentifiedPlanCount, effectiveLocale);
        if (!unidentifiedNotice.isBlank()) {
            noticeText = noticeText.isBlank() ? unidentifiedNotice : noticeText + "\n" + unidentifiedNotice;
        }
        if (Boolean.TRUE.equals(learner.getLearningPlanCountOnlyExplicitGoals())
                && !fulfillment.unavailable().isEmpty()) {
            String coverageNotice = effectiveLocale.startsWith("en")
                    ? "The completion calculation is currently unavailable. Explicit plan counts remain visible; affected plan continuations are paused."
                    : "Die Abschlussberechnung ist derzeit nicht verfügbar. Explizite Planstände bleiben sichtbar; betroffene Planfortsetzungen sind pausiert.";
            noticeText = noticeText.isBlank() ? coverageNotice : noticeText + "\n" + coverageNotice;
        }
        if (subjectPlans.isEmpty()) {
            noticeText = UnifiedLearningPlanStatusFormatter.formatNoPlansNotice(effectiveLocale);
        }
        String statusText = String.join("\n", subjectLines);
        if (!noticeText.isBlank()) {
            statusText = statusText.isBlank() ? noticeText : statusText + "\n" + noticeText;
        }

        List<LearnerPlanTodayStatus.SubjectStatus> evaluated = subjects.stream()
                .filter(LearnerPlanTodayStatus.SubjectStatus::evaluable)
                .toList();
        boolean evaluable = !subjects.isEmpty() && unavailablePlanCount == 0
                && subjects.stream().allMatch(LearnerPlanTodayStatus.SubjectStatus::evaluable);
        boolean periodQuotaFulfilled = evaluated.stream()
                .allMatch(subject -> subject.balance().offenesPeriodenpensum() == 0);

        boolean automaticResume = !preview && enabled && !activeGoalInProgress && firstCandidateAcrossPlans(
                skillpilotId, subjectPlans, asOf, mastery, false, false, true, fulfillment).isPresent();
        boolean resumeAvailable = !activeGoalInProgress && enabled && (personalContinuationAvailable
                || firstCandidateAcrossPlans(skillpilotId, subjectPlans, asOf, mastery, false, true, true, fulfillment).isPresent());

        return new LearnerPlanTodayStatus(
                asOf,
                periodBasis,
                periodStart,
                periodEnd,
                PLAN_ZONE.getId(),
                effectiveLocale,
                evaluable,
                statusText,
                noticeText,
                periodQuotaFulfilled,
                activeGoal,
                enabled,
                resumeAvailable,
                List.copyOf(subjects),
                unavailablePlanCount,
                automaticResume);
    }

    /**
     * Counts current personal-curriculum targets once per stable subject. The goal IDs come
     * from the same Level-2 planning scope used for authoring; the mastery values come from
     * the status read's one effective snapshot (including the SRS overlay). A missing or
     * unreadable scope cannot be presented as zero progress.
     */
    private Map<String, SubjectAchievement> currentSubjectAchievements(
            String skillpilotId, Map<String, Double> mastery, Set<String> displayedSubjects) {
        if (displayedSubjects.isEmpty()) {
            return Map.of();
        }
        final Map<String, List<String>> targetIdsByLandscape;
        try {
            targetIdsByLandscape = learners.getPersonalCurriculumAtomicTargetsByLandscape(skillpilotId);
        } catch (ResponseStatusException | IllegalArgumentException
                | IllegalStateException | NullPointerException exception) {
            if (exception instanceof ResponseStatusException response
                    && response.getStatusCode().is5xxServerError()) {
                throw response;
            }
            return Map.of();
        }
        if (targetIdsByLandscape == null || targetIdsByLandscape.isEmpty()) {
            return Map.of();
        }

        Map<String, Set<String>> targetIdsBySubject = new LinkedHashMap<>();
        Set<String> unavailableSubjects = new HashSet<>();
        for (Map.Entry<String, List<String>> entry : targetIdsByLandscape.entrySet()) {
            String landscapeId = entry.getKey();
            String subjectKey = stableSubjectKey(landscapeId);
            if (subjectKey == null || !displayedSubjects.contains(subjectKey)) {
                continue;
            }
            if (entry.getValue() == null || entry.getValue().isEmpty()
                    || entry.getValue().stream().anyMatch(id -> id == null || id.isBlank())) {
                unavailableSubjects.add(subjectKey);
                continue;
            }
            targetIdsBySubject.computeIfAbsent(subjectKey, ignored -> new LinkedHashSet<>())
                    .addAll(entry.getValue());
        }

        Map<String, SubjectAchievement> result = new LinkedHashMap<>();
        targetIdsBySubject.forEach((subjectKey, targetIds) -> {
            if (!unavailableSubjects.contains(subjectKey)) {
                int achieved = (int) targetIds.stream()
                        .filter(goalId -> mastery.getOrDefault(goalId, 0.0) >= MASTERY_THRESHOLD)
                        .count();
                result.put(subjectKey, new SubjectAchievement(achieved, targetIds.size()));
            }
        });
        return result;
    }

    private record SubjectAchievement(int achievedGoalCount, int targetGoalCount) {
    }

    private record StatusReadSnapshot(
            Map<String, Double> mastery,
            Map<String, SubjectAchievement> achievements,
            PlanFulfillment fulfillment) {
        StatusReadSnapshot(Map<String, Double> mastery, Map<String, SubjectAchievement> achievements) {
            this(mastery, achievements, null);
        }
    }

    /**
     * Reads one plan's schedule and capabilities for the shared subject balance.
     *
     * <p>Returns empty when the plan cannot be evaluated reliably. Such a plan never
     * contributes a partial balance to its subject: a subject with an unevaluable part
     * plan must not appear to have a complete one.</p>
     */
    /** The goal title in the session language, as the localized landscape presents it. */
    private static String localizedGoalTitle(
            com.skillpilot.backend.landscape.LearningGoal goal, String locale) {
        if (goal == null) {
            return null;
        }
        boolean english = locale != null && locale.trim().toLowerCase(Locale.ROOT).startsWith("en");
        if (english && goal.getTitleEn() != null && !goal.getTitleEn().isBlank()) {
            return goal.getTitleEn().trim();
        }
        return goal.getTitle() != null && !goal.getTitle().isBlank() ? goal.getTitle().trim() : null;
    }

    private Optional<PlanEvaluation> evaluatePlan(
            String skillpilotId,
            LearnerLearningPlan plan,
            LocalDate asOf,
            PeriodBasis periodBasis,
            LocalDate periodStart,
            LocalDate periodEnd,
            boolean enabled,
            String activeGoalId,
            String locale, Map<String, Double> mastery, PlanFulfillment fulfillment) {
        final Evaluation evaluation;
        try {
            evaluation = summarize(
                    skillpilotId,
                    plan,
                    asOf,
                    periodBasis,
                    periodStart,
                    periodEnd,
                    enabled,
                    activeGoalId, mastery, fulfillment);
        } catch (ResponseStatusException exception) {
            if (exception.getStatusCode().is5xxServerError()) {
                throw exception;
            }
            return Optional.empty();
        } catch (IllegalStateException | NullPointerException exception) {
            return Optional.empty();
        }
        LearnerLearningPlanApi.PlanSummary summary = evaluation.summary();
        if (summary.stale()) {
            return Optional.empty();
        }

        final Map<String, LocalDate> dueDates;
        try {
            dueDates = scheduledAtomicGoalDueDatesForSchedule(evaluation.blocks());
        } catch (IllegalStateException | NullPointerException exception) {
            return Optional.empty();
        }
        Set<String> plannedGoalIds = atomicIds(evaluation.blocks());
        Set<String> waived = fulfillment.unavailable().contains(plan.getLandscapeId())
                ? Set.of() : fulfillment.waived(plan.getLandscapeId());

        return Optional.of(new PlanEvaluation(
                dueDates,
                plannedGoalIds,
                enabled && summary.nextEligibleGoal() != null,
                summary.canContinue(),
                activeGoalId != null && (plannedGoalIds.contains(activeGoalId)
                        || plan.getLandscapeId().equals(
                                landscapeService.getLandscapeIdForGoal(activeGoalId))),
                scopeWithBlockage(skillpilotId,
                        scopeProgress(learningScope(skillpilotId, plan.getLandscapeId(), evaluation.blocks(), asOf, true),
                                evaluation.blocks(), mastery,
                                countedWaivers(learners.getLearner(skillpilotId), waived), locale),
                        summary.nextEligibleGoal() == null && !fulfillment.unavailable().contains(plan.getLandscapeId()),
                        waived, mastery, locale), waived));
    }

    /** Stable subject identity: the landscape's canonical subject, never its translated label. */
    private String stableSubjectKey(String landscapeId) {
        return stableSubjectKey(landscapeService.getById(landscapeId));
    }

    static String stableSubjectKey(SkillLandscape landscape) {
        String subject = landscape == null ? null : optionalLabel(landscape.getSubject());
        return subject == null ? null : subject.toLowerCase(Locale.ROOT);
    }

    static LocalDate periodStart(PeriodBasis basis, LocalDate asOf) {
        return basis == PeriodBasis.WEEK
                ? asOf.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) : asOf;
    }

    static LocalDate periodEnd(PeriodBasis basis, LocalDate asOf) {
        return basis == PeriodBasis.WEEK
                ? asOf.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY)) : asOf;
    }

    private static String normalizeLocale(String locale) {
        if (locale == null || locale.isBlank()) return "de";
        String language = Locale.forLanguageTag(locale.trim()).getLanguage();
        if (!"de".equals(language) && !"en".equals(language)) {
            throw badRequest("language must be de or en");
        }
        return language;
    }

    private Optional<String> localizedSubjectLabel(
            String landscapeId,
            String communicationLocale) {
        SkillLandscape landscape = landscapeService.getById(landscapeId);
        if (landscape == null) {
            return Optional.empty();
        }
        String subject = optionalLabel(landscape.getSubject());
        if (subject == null) {
            return Optional.empty();
        }
        if (communicationLocale == null
                || !communicationLocale.trim().toLowerCase(Locale.ROOT).startsWith("en")) {
            return Optional.ofNullable(sanitizedSubjectLabel(subject));
        }
        return Optional.ofNullable(sanitizedSubjectLabel(switch (subject.toLowerCase(Locale.ROOT)) {
            case "mathematik" -> "Mathematics";
            case "physik" -> "Physics";
            case "chemie" -> "Chemistry";
            case "biologie" -> "Biology";
            case "informatik" -> "Computer Science";
            case "wirtschaftswissenschaften" -> "Economics";
            case "politik und wirtschaft" -> "Politics and Economics";
            case "deutsch" -> "German";
            case "englisch" -> "English";
            case "französisch" -> "French";
            case "latein" -> "Latin";
            case "geschichte" -> "History";
            default -> subject;
        }));
    }

    /**
     * Keeps control characters out of the binding status text.
     *
     * <p>The text itself is now the payload every channel quotes, so the label has to be
     * safe where it enters the text, not only where a projection copies it out again.</p>
     */
    private static String sanitizedSubjectLabel(String value) {
        if (value == null) {
            return null;
        }
        String cleaned = value.replaceAll("[\\p{Cc}\\p{Cf}]+", " ").replaceAll("\\s+", " ").trim();
        return cleaned.isEmpty() ? null : cleaned.substring(0, Math.min(cleaned.length(), 120));
    }

    private static String optionalLabel(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    @Transactional
    public LearnerLearningPlanApi.CollectionResponse getPlans(
            String skillpilotId, LocalDate requestedAsOf) {
        return getPlans(skillpilotId, requestedAsOf, null);
    }

    @Transactional
    public LearnerLearningPlanApi.CollectionResponse getPlans(
            String skillpilotId, LocalDate requestedAsOf, String communicationLocale) {
        learners.acquireLearningPlanMutationLock(skillpilotId);
        LocalDate asOf = asOf(requestedAsOf);
        Learner learner = learners.getLearner(skillpilotId);
        boolean enabled = com.skillpilot.backend.completion.CompletionNavigationPolicy.followsPlans(learner);
        List<LearnerLearningPlan> storedPlans = plans
                .findByLearner_SkillpilotIdOrderByLandscapeIdAsc(skillpilotId);
        Map<String, Double> mastery = learners.getMastery(skillpilotId);
        PlanFulfillment fulfillment = planFulfillment(skillpilotId, storedPlans, mastery);
        LearnerPlanTodayStatus status = calculateStatus(
                skillpilotId, learner, storedPlans, asOf, communicationLocale, false,
                new StatusReadSnapshot(mastery, null, fulfillment));
        List<LearnerLearningPlanApi.PlanSummary> summaries = storedPlans.stream()
                .map(plan -> safeSummary(skillpilotId, plan, asOf, enabled, learner.getActiveGoalId(), mastery, fulfillment))
                .filter(Objects::nonNull)
                .toList();
        return new LearnerLearningPlanApi.CollectionResponse(asOf, enabled, summaries, status);
    }

    private LearnerLearningPlanApi.PlanSummary safeSummary(
            String skillpilotId, LearnerLearningPlan plan, LocalDate asOf,
            boolean enabled, String activeGoalId, Map<String, Double> mastery, PlanFulfillment fulfillment) {
        try {
            PeriodBasis basis = learners.getLearner(skillpilotId).getLearningPlanPeriodBasis();
            return summarize(skillpilotId, plan, asOf, basis, periodStart(basis, asOf), periodEnd(basis, asOf),
                    enabled, activeGoalId, mastery, fulfillment).summary();
        } catch (ResponseStatusException exception) {
            if (exception.getStatusCode().is5xxServerError()) throw exception;
            return null;
        } catch (IllegalStateException | NullPointerException exception) {
            // The status retains this subject's unavailability. Corrupt details are
            // omitted instead of fabricating schedule dates or buffer values.
            return null;
        }
    }

    @Transactional
    public LearnerLearningPlanApi.PlanDetail getPlan(
            String skillpilotId,
            String landscapeId,
            LocalDate requestedAsOf) {
        String normalizedLandscapeId = requireText(landscapeId, "landscapeId", 255);
        learners.acquireLearningPlanMutationLock(skillpilotId);
        Learner learner = learners.getLearner(skillpilotId);
        LearnerLearningPlan plan = plans
                .findByLearner_SkillpilotIdAndLandscapeId(skillpilotId, normalizedLandscapeId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Learning plan not found"));
        try {
            Evaluation evaluation = summarize(
                    skillpilotId,
                    plan,
                    asOf(requestedAsOf),
                    com.skillpilot.backend.completion.CompletionNavigationPolicy.followsPlans(learner),
                    learner.getActiveGoalId());
            return detail(evaluation.summary(), evaluation.blocks());
        } catch (IllegalStateException | NullPointerException exception) {
            // Match today's unavailable-plan handling; a corrupt schedule must
            // not prevent a separately authorized personal-curriculum fallback.
            throw conflict("Stored learning plan cannot be evaluated");
        }
    }

    @Transactional
    public LearnerLearningPlanApi.PlanDetail upsert(
            String skillpilotId,
            String landscapeId,
            LearnerLearningPlanApi.UpsertRequest request,
            LocalDate requestedAsOf) {
        if (request == null) {
            throw badRequest("request is required");
        }
        String normalizedLandscapeId = requireText(landscapeId, "landscapeId", 255);

        learners.acquireLearningPlanMutationLock(skillpilotId);
        Learner learner = learners.getLearner(skillpilotId);
        PreparedPlan prepared = preparePlan(
                skillpilotId,
                learner,
                normalizedLandscapeId,
                request.expectedRevision(),
                request.planLabel(),
                request.blocks());
        LearnerLearningPlan saved = persistPreparedPlan(prepared);
        eventPublisher.publishEvent(new LearnerStateChangedEvent(
                this,
                skillpilotId,
                "LEARNING_PLAN_UPDATE"));

        Evaluation evaluation = summarize(
                skillpilotId,
                saved,
                asOf(requestedAsOf),
                com.skillpilot.backend.completion.CompletionNavigationPolicy.followsPlans(learner),
                learner.getActiveGoalId());
        return detail(evaluation.summary(), evaluation.blocks());
    }

    /** Drafts use the live calculation with today's known mastery, never predicted completions. */
    @Transactional
    public LearnerLearningPlanApi.PreviewResponse previewPlans(
            String skillpilotId, LearnerLearningPlanApi.ActivateRequest request) {
        return previewPlans(skillpilotId, request, null);
    }

    @Transactional
    public LearnerLearningPlanApi.PreviewResponse previewPlans(
            String skillpilotId, LearnerLearningPlanApi.ActivateRequest request,
            String communicationLocale) {
        if (request == null) throw badRequest("request is required");
        learners.acquireLearningPlanMutationLock(skillpilotId);
        LocalDate asOf = LocalDate.now(clock.withZone(PLAN_ZONE));
        if (request.asOf() != null && !asOf.equals(request.asOf())) {
            throw badRequest("asOf for preview must equal the current server date in Europe/Berlin");
        }
        LinkedHashMap<String, LearnerLearningPlanApi.ActivationPlan> requestedByLandscape =
                requestedActivationPlans(request);
        Learner learner = learners.getLearner(skillpilotId);
        assertNoCurrentStoredPlanIsHidden(skillpilotId, requestedByLandscape.keySet());
        List<LearnerLearningPlan> drafts = requestedByLandscape.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(entry -> preparePlan(skillpilotId, learner, entry.getKey(),
                        entry.getValue().expectedRevision(), entry.getValue().planLabel(),
                        entry.getValue().blocks(), false))
                .map(this::previewPlan)
                .toList();
        Map<String, Double> mastery = learners.getMastery(skillpilotId);
        Set<String> displayedSubjects = new HashSet<>();
        for (LearnerLearningPlan draft : drafts) {
            String subjectKey = stableSubjectKey(draft.getLandscapeId());
            if (subjectKey != null) {
                displayedSubjects.add(subjectKey);
            }
        }
        StatusReadSnapshot snapshot = new StatusReadSnapshot(mastery,
                currentSubjectAchievements(skillpilotId, mastery, displayedSubjects),
                planFulfillment(skillpilotId, drafts, mastery));
        List<LearnerLearningPlanApi.PreviewDay> days = new ArrayList<>();
        for (int offset = 0; offset < PREVIEW_DAYS; offset++) {
            LocalDate date = asOf.plusDays(offset);
            days.add(new LearnerLearningPlanApi.PreviewDay(date,
                    calculateStatus(skillpilotId, learner, drafts, date, communicationLocale, true, snapshot)));
        }
        return new LearnerLearningPlanApi.PreviewResponse(asOf, List.copyOf(days));
    }

    private LearnerLearningPlan previewPlan(PreparedPlan prepared) {
        LearnerLearningPlan draft = new LearnerLearningPlan();
        draft.setId(prepared.existing().map(LearnerLearningPlan::getId).orElse(null));
        draft.setLearner(prepared.learner());
        draft.setLandscapeId(prepared.landscapeId());
        draft.setCurriculumId(prepared.scope().curriculumId());
        draft.setScopeFingerprint(prepared.fingerprint());
        draft.setRevision(prepared.existing().map(LearnerLearningPlan::getRevision).orElse(0L));
        draft.setPlanLabel(prepared.planLabel());
        draft.setBlocksJson(writeBlocks(prepared.blocks()));
        draft.setCapturedAt(prepared.scope().capturedAt());
        return draft;
    }

    @Transactional
    public LearnerLearningPlanApi.ActivateResponse activatePlans(
            String skillpilotId,
            LearnerLearningPlanApi.ActivateRequest request) {
        if (request == null) {
            throw badRequest("request is required");
        }
        LocalDate asOf = requireCurrentMutationDate(request.asOf(), "activation");
        LinkedHashMap<String, LearnerLearningPlanApi.ActivationPlan> requestedByLandscape =
                requestedActivationPlans(request);

        learners.acquireLearningPlanMutationLock(skillpilotId);
        Learner learner = learners.getLearner(skillpilotId);
        assertNoCurrentStoredPlanIsHidden(skillpilotId, requestedByLandscape.keySet());
        List<PreparedPlan> preparedPlans = requestedByLandscape.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(entry -> preparePlan(
                        skillpilotId,
                        learner,
                        entry.getKey(),
                        entry.getValue().expectedRevision(),
                        entry.getValue().planLabel(),
                        entry.getValue().blocks()))
                .toList();

        List<LearnerLearningPlan> savedPlans = new ArrayList<>();
        for (PreparedPlan prepared : preparedPlans) {
            savedPlans.add(persistPreparedPlan(prepared));
        }

        Map<String, Double> mastery = learners.getMastery(skillpilotId);
        String previousActiveGoalId = learner.getActiveGoalId();
        boolean preserveInactiveActiveGoal = previousActiveGoalId != null
                && mastery.getOrDefault(previousActiveGoalId, 0.0) < MASTERY_THRESHOLD
                && savedPlans.stream().allMatch(plan -> learningScope(skillpilotId, plan.getLandscapeId(),
                        readBlocks(plan), asOf, false).goalIds().isEmpty())
                && savedPlans.stream().anyMatch(plan -> inactiveOnlyAtomicIds(readBlocks(plan))
                        .contains(previousActiveGoalId));
        Optional<PlanGoalCandidate> selected = findPreservedActiveCandidate(
                skillpilotId,
                savedPlans,
                previousActiveGoalId,
                mastery);
        if (selected.isEmpty() && !preserveInactiveActiveGoal) {
            selected = firstCandidateAcrossPlans(skillpilotId, savedPlans, asOf, mastery, true,
                    hasExamScope(skillpilotId, savedPlans, asOf), false);
        }

        LearnerLearningPlan scopePlan = selected.map(PlanGoalCandidate::plan).orElseGet(() -> savedPlans.stream()
                .filter(plan -> {
                    var scope = learningScope(skillpilotId, plan.getLandscapeId(), readBlocks(plan), asOf, false);
                    return "exam".equals(scope.kind()) && !scope.goalIds().isEmpty();
                })
                .findFirst().orElse(null));
        List<String> selectedScope = scopePlan == null ? List.of()
                : learningScope(skillpilotId, scopePlan.getLandscapeId(), readBlocks(scopePlan), asOf, false).goalIds();
        if (scopePlan != null && !"exam".equals(learningScope(skillpilotId, scopePlan.getLandscapeId(),
                readBlocks(scopePlan), asOf, false).kind())) {
            selectedScope = selected.map(candidate -> List.of(candidate.dueGoal().focusGoalId())).orElse(List.of());
        }

        LearnerService.LearningPlanTransitionResult transition;
        if (selected.isPresent()) {
            PlanGoalCandidate candidate = selected.get();
            transition = applyScopeTransition(
                    skillpilotId,
                    true,
                    true,
                    selectedScope,
                    candidate.dueGoal().atomicGoalId(),
                    false,
                    "LEARNING_PLAN_PACKAGE_ACTIVATED");
        } else {
            transition = applyScopeTransition(
                    skillpilotId,
                    true,
                    !preserveInactiveActiveGoal,
                    preserveInactiveActiveGoal ? null : selectedScope,
                    null,
                    false,
                    "LEARNING_PLAN_PACKAGE_ACTIVATED");
        }

        String effectiveActiveGoalId = selected
                .map(candidate -> candidate.dueGoal().atomicGoalId())
                .orElse(preserveInactiveActiveGoal ? previousActiveGoalId : null);
        List<LearnerLearningPlanApi.PlanDetail> details = savedPlans.stream()
                .map(plan -> {
                    Evaluation evaluation = summarize(
                            skillpilotId,
                            plan,
                            asOf,
                            true,
                            effectiveActiveGoalId);
                    return detail(evaluation.summary(), evaluation.blocks());
                })
                .toList();
        eventPublisher.publishEvent(new LearnerStateChangedEvent(
                this,
                skillpilotId,
                "LEARNING_PLAN_PACKAGE_ACTIVATED"));

        PlanGoalCandidate selectedCandidate = selected.orElse(null);
        return new LearnerLearningPlanApi.ActivateResponse(
                asOf,
                true,
                details,
                scopePlan == null ? null : scopePlan.getId(),
                scopePlan == null ? null : scopePlan.getLandscapeId(),
                selectedCandidate == null ? selectedScope.isEmpty() ? null : selectedScope.getFirst()
                        : selectedCandidate.dueGoal().focusGoalId(),
                selectedCandidate == null ? null : selectedCandidate.dueGoal().atomicGoalId(),
                transition.state());
    }

    private LinkedHashMap<String, LearnerLearningPlanApi.ActivationPlan> requestedActivationPlans(
            LearnerLearningPlanApi.ActivateRequest request) {
        if (request.plans() == null || request.plans().isEmpty()) {
            throw badRequest("plans must not be empty");
        }
        if (request.plans().size() > MAX_ACTIVATION_PLANS) {
            throw badRequest("plans exceeds the supported limit");
        }

        LinkedHashMap<String, LearnerLearningPlanApi.ActivationPlan> requestedByLandscape =
                new LinkedHashMap<>();
        for (LearnerLearningPlanApi.ActivationPlan requested : request.plans()) {
            if (requested == null) {
                throw badRequest("plans must not contain null entries");
            }
            String landscapeId = requireText(requested.landscapeId(), "landscapeId", 255);
            if (requestedByLandscape.putIfAbsent(landscapeId, requested) != null) {
                throw badRequest("landscapeId must be unique within an activation request");
            }
        }

        return requestedByLandscape;
    }

    private void assertNoCurrentStoredPlanIsHidden(
            String skillpilotId,
            Set<String> requestedLandscapeIds) {
        List<String> omittedCurrentPlans = new ArrayList<>();
        for (LearnerLearningPlan stored : plans
                .findByLearner_SkillpilotIdOrderByLandscapeIdAsc(skillpilotId)) {
            if (requestedLandscapeIds.contains(stored.getLandscapeId())) {
                continue;
            }
            try {
                List<LearnerLearningPlanApi.Block> blocks = readBlocks(stored);
                boolean current = learners.isLearningPlanCompatible(
                        skillpilotId, stored.getCurriculumId(), stored.getLandscapeId(), blocks);
                if (current) {
                    omittedCurrentPlans.add(stored.getLandscapeId());
                }
            } catch (ResponseStatusException exception) {
                if (exception.getStatusCode().is5xxServerError()) {
                    throw exception;
                }
                // A no-longer-projectable plan is stale and cannot become a
                // later automatic transition candidate.
            } catch (IllegalStateException exception) {
                // Malformed stored plans fail closed during reconciliation and
                // therefore do not need to block replacement of the live set.
            }
        }
        if (!omittedCurrentPlans.isEmpty()) {
            throw conflict("Activation must include every current stored learning plan: "
                    + String.join(", ", omittedCurrentPlans));
        }
    }

    /** Explicit subject switch; unlike the legacy continue action it may park another goal. */
    @Transactional
    public LearnerLearningPlanApi.TransitionResponse switchPlan(
            String skillpilotId,
            UUID planId,
            LearnerLearningPlanApi.ContinueRequest request) {
        if (request == null) {
            throw badRequest("request is required");
        }
        if (planId == null) {
            throw badRequest("planId is required");
        }
        long expectedRevision = requireExpectedRevision(request.expectedRevision());
        LocalDate asOf = requireCurrentMutationDate(request.asOf(), "switch");

        learners.acquireLearningPlanMutationLock(skillpilotId);
        Learner learner = learners.getLearner(skillpilotId);
        if (!com.skillpilot.backend.completion.CompletionNavigationPolicy.followsPlans(learner)) {
            throw conflict("Following learning plans is not enabled for this learner");
        }
        LearnerLearningPlan plan = requireCurrentPlan(skillpilotId, planId, expectedRevision);
        List<LearnerLearningPlanApi.Block> blocks = requireCurrentBlocks(skillpilotId, plan);
        Map<String, Double> mastery = learners.getMastery(skillpilotId);
        DueGoal dueGoal = firstScopeContinuationGoal(skillpilotId, plan.getLandscapeId(), blocks,
                asOf, mastery, false)
                .orElseThrow(() -> conflict("No open personal-curriculum goal is currently on the learner frontier"));
        PlanGoalCandidate candidate = new PlanGoalCandidate(plan, dueGoal);

        LearnerService.LearningPlanTransitionResult transition =
                applyScopeTransition(
                        skillpilotId,
                        false,
                        true,
                        transitionFocus(skillpilotId, plan, dueGoal, asOf, false),
                        dueGoal.atomicGoalId(),
                        true,
                        "LEARNING_PLAN_SUBJECT_SWITCH");
        return transition(candidate, dueGoal.atomicGoalId(), transition.changed(), transition.state());
    }

    /**
     * Idempotent explicit repair point used when plan mode is active but no
     * learning goal is selected. Reads remain side-effect free.
     */
    @Transactional
    public LearnerLearningPlanApi.TransitionResponse reconcile(
            String skillpilotId,
            LearnerLearningPlanApi.ReconcileRequest request) {
        return reconcileInternal(skillpilotId, request, false);
    }

    /** Explicitly requested continuation may select voluntary extra work. */
    @Transactional
    public LearnerLearningPlanApi.TransitionResponse resumeExplicitly(
            String skillpilotId,
            LearnerLearningPlanApi.ReconcileRequest request) {
        return reconcileInternal(skillpilotId, request, true);
    }

    /** Subject-name resolution has already been authorized by the coach facade. */
    @Transactional
    public LearnerLearningPlanApi.TransitionResponse switchPersonalCurriculumSubject(
            String skillpilotId, String landscapeId) {
        learners.acquireLearningPlanMutationLock(skillpilotId);
        if (!com.skillpilot.backend.completion.CompletionNavigationPolicy.followsPlans(learners.getLearner(skillpilotId))
                || !learners.getPersonalCurriculumSubjectIds(skillpilotId).contains(landscapeId)) {
            throw conflict("Subject is not in the current personal curriculum");
        }
        DueGoal goal = firstPersonalCurriculumGoal(skillpilotId, landscapeId)
                .orElseThrow(() -> conflict("No open personal-curriculum goal is currently on the learner frontier"));
        return applyPersonalCurriculumContinuation(skillpilotId, landscapeId, goal,
                "LEARNING_PLAN_SUBJECT_SWITCH");
    }

    private LearnerLearningPlanApi.TransitionResponse applyPersonalCurriculumContinuation(
            String skillpilotId, String landscapeId, DueGoal goal, String changeType) {
        var result = learners.applyLearningPlanTransition(skillpilotId, false, true,
                goal.focusGoalId(), goal.atomicGoalId(), true, changeType);
        return new LearnerLearningPlanApi.TransitionResponse(null, null, landscapeId,
                goal.focusGoalId(), goal.atomicGoalId(), result.changed(), result.state());
    }

    private LearnerLearningPlanApi.TransitionResponse reconcileInternal(
            String skillpilotId,
            LearnerLearningPlanApi.ReconcileRequest request,
            boolean allowExtra) {
        if (request == null) {
            throw badRequest("request is required");
        }
        LocalDate asOf = requireCurrentMutationDate(request.asOf(), "reconcile");
        learners.acquireLearningPlanMutationLock(skillpilotId);
        Learner learner = learners.getLearner(skillpilotId);
        String previousActiveGoalId = learner.getActiveGoalId();
        Map<String, Double> mastery = learners.getMastery(skillpilotId);

        if (!com.skillpilot.backend.completion.CompletionNavigationPolicy.followsPlans(learner)
                || (previousActiveGoalId != null
                        && !previousActiveGoalId.isBlank()
                        && mastery.getOrDefault(previousActiveGoalId, 0.0) < MASTERY_THRESHOLD)) {
            return new LearnerLearningPlanApi.TransitionResponse(
                    null,
                    null,
                    null,
                    null,
                    null,
                    false,
                    learners.getCoachLearnerState(skillpilotId));
        }

        List<LearnerLearningPlan> currentPlans = plans
                .findByLearner_SkillpilotIdOrderByLandscapeIdAsc(skillpilotId);
        Optional<PlanGoalCandidate> selected = firstCandidateAcrossPlans(
                skillpilotId,
                currentPlans,
                asOf,
                mastery,
                false,
                allowExtra);
        boolean parkedCompletedPointer = previousActiveGoalId != null && !previousActiveGoalId.isBlank();
        if (selected.isEmpty() && allowExtra && !hasExamScope(skillpilotId, currentPlans, asOf)) {
            for (String landscapeId : learners.getPersonalCurriculumSubjectIds(skillpilotId)) {
                Optional<DueGoal> goal = firstPersonalCurriculumGoalForPlanContinuation(
                        skillpilotId, landscapeId, currentPlans);
                if (goal.isPresent()) {
                    return applyPersonalCurriculumContinuation(skillpilotId, landscapeId, goal.get(),
                            "LEARNING_PLAN_RECONCILED");
                }
            }
        }
        if (selected.isEmpty()) {
            if (allowExtra) {
                for (LearnerLearningPlan plan : currentPlans) {
                    List<LearnerLearningPlanApi.Block> blocks;
                    try {
                        blocks = requireCurrentBlocks(skillpilotId, plan);
                    } catch (ResponseStatusException exception) {
                        if (exception.getStatusCode().is5xxServerError()) throw exception;
                        continue;
                    }
                    var scope = learningScope(skillpilotId, plan.getLandscapeId(), blocks, asOf, true);
                    if (!"exam".equals(scope.kind()) || scope.goalIds().isEmpty()) continue;
                    var repaired = applyScopeTransition(skillpilotId, false, true,
                            scope.goalIds(), null, true, "LEARNING_PLAN_RECONCILED");
                    return new LearnerLearningPlanApi.TransitionResponse(plan.getId(), plan.getRevision(),
                            plan.getLandscapeId(), scope.goalIds().getFirst(), null, repaired.changed(), repaired.state());
                }
            }
            LearnerService.LearningPlanTransitionResult transition = parkedCompletedPointer
                    ? learners.applyLearningPlanTransition(
                            skillpilotId,
                            false,
                            true,
                            null,
                            null,
                            true,
                            "LEARNING_PLAN_RECONCILED")
                    : new LearnerService.LearningPlanTransitionResult(
                            false,
                            learners.getCoachLearnerState(skillpilotId));
            return new LearnerLearningPlanApi.TransitionResponse(
                    null,
                    null,
                    null,
                    null,
                    null,
                    transition.changed(),
                    transition.state());
        }

        PlanGoalCandidate candidate = selected.get();
        LearnerService.LearningPlanTransitionResult transition = applyScopeTransition(
                skillpilotId,
                false,
                true,
                transitionFocus(skillpilotId, candidate.plan(), candidate.dueGoal(), asOf, true),
                candidate.dueGoal().atomicGoalId(),
                true,
                "LEARNING_PLAN_RECONCILED");
        return transition(
                candidate,
                candidate.dueGoal().atomicGoalId(),
                transition.changed(),
                transition.state());
    }

    @Transactional
    public LearnerLearningPlanApi.ContinueResponse continuePlan(
            String skillpilotId,
            UUID planId,
            LearnerLearningPlanApi.ContinueRequest request) {
        if (request == null) {
            throw badRequest("request is required");
        }
        long expectedRevision = requireExpectedRevision(request.expectedRevision());
        if (planId == null) {
            throw badRequest("planId is required");
        }
        learners.acquireLearningPlanMutationLock(skillpilotId);
        Learner learner = learners.getLearner(skillpilotId);
        if (!com.skillpilot.backend.completion.CompletionNavigationPolicy.followsPlans(learner)) {
            throw conflict("Following learning plans is not enabled for this learner");
        }

        LearnerLearningPlan plan = requireCurrentPlan(skillpilotId, planId, expectedRevision);
        List<LearnerLearningPlanApi.Block> blocks = requireCurrentBlocks(skillpilotId, plan);
        LocalDate asOf = requireCurrentMutationDate(request.asOf(), "continue");
        Map<String, Double> mastery = learners.getMastery(skillpilotId);
        DueGoal selected = firstScopeContinuationGoal(skillpilotId, plan.getLandscapeId(), blocks,
                asOf, mastery, true)
                .orElseThrow(() -> conflict("No open personal-curriculum goal is currently on the learner frontier"));

        learners.assertLearningPlanMayActivateGoal(skillpilotId, selected.atomicGoalId());
        learners.setPlannedGoalsAndGetState(skillpilotId, new LinkedHashSet<>(
                transitionFocus(skillpilotId, plan, selected, asOf, true)));
        learners.setActiveGoal(skillpilotId, selected.atomicGoalId());
        UnifiedLearnerStateResponse state = learners.getLearnerState(skillpilotId);
        return new LearnerLearningPlanApi.ContinueResponse(
                plan.getId(),
                plan.getRevision(),
                plan.getLandscapeId(),
                selected.focusGoalId(),
                selected.atomicGoalId(),
                state);
    }

    private PreparedPlan preparePlan(
            String skillpilotId,
            Learner learner,
            String landscapeId,
            Long requestedRevision,
            String requestedPlanLabel,
            List<LearnerLearningPlanApi.Block> requestedBlocks) {
        return preparePlan(skillpilotId, learner, landscapeId, requestedRevision,
                requestedPlanLabel, requestedBlocks, true);
    }

    private PreparedPlan preparePlan(
            String skillpilotId,
            Learner learner,
            String landscapeId,
            Long requestedRevision,
            String requestedPlanLabel,
            List<LearnerLearningPlanApi.Block> requestedBlocks,
            boolean forUpdate) {
        long expectedRevision = requireExpectedRevision(requestedRevision);
        String planLabel = optionalText(requestedPlanLabel, "planLabel", 160);
        LearnerPlanningScopeResponse scope = learners.getPlanningScope(skillpilotId, landscapeId);
        Optional<LearnerLearningPlan> existing = forUpdate
                ? plans.findForUpdate(skillpilotId, landscapeId)
                : plans.findByLearner_SkillpilotIdAndLandscapeId(skillpilotId, landscapeId);
        if (existing.isEmpty() && expectedRevision != 0) {
            throw conflict("expectedRevision must be 0 when creating a learning plan");
        }
        if (existing.isPresent() && existing.get().getRevision() != expectedRevision) {
            throw conflict("Learning plan revision conflict");
        }

        List<LearnerLearningPlanApi.Block> existingBlocks = existing
                .map(this::readBlocks)
                .orElseGet(List::of);
        var identity = landscapeService.identityProjection();
        List<LearnerLearningPlanApi.Block> normalizedBlocks = normalizeBlocks(
                identity == null ? requestedBlocks : identity.projectBlocks(requestedBlocks),
                scope,
                capturedAtomicIds(existingBlocks),
                false);
        learners.validateLearningPlanBlockFoci(skillpilotId, landscapeId, normalizedBlocks);
        normalizedBlocks = learners.orderLearningPlanBlocksByPrerequisites(
                skillpilotId,
                normalizedBlocks);
        String fingerprint = learners.learningPlanFingerprint(
                skillpilotId,
                landscapeId,
                normalizedBlocks);
        return new PreparedPlan(
                learner,
                landscapeId,
                planLabel,
                scope,
                existing,
                normalizedBlocks,
                fingerprint);
    }

    private LearnerLearningPlan persistPreparedPlan(PreparedPlan prepared) {
        LearnerLearningPlan plan = prepared.existing().orElseGet(LearnerLearningPlan::new);
        if (prepared.existing().isEmpty()) {
            plan.setLearner(prepared.learner());
            plan.setLandscapeId(prepared.landscapeId());
            plan.setRevision(1);
        } else {
            plan.setRevision(plan.getRevision() + 1);
        }
        plan.setCurriculumId(prepared.scope().curriculumId());
        plan.setScopeFingerprint(prepared.fingerprint());
        plan.setPlanLabel(prepared.planLabel());
        plan.setBlocksJson(writeBlocks(prepared.blocks()));
        plan.setCapturedAt(prepared.scope().capturedAt());
        try {
            return plans.saveAndFlush(plan);
        } catch (DataIntegrityViolationException exception) {
            if (prepared.existing().isEmpty()) {
                throw conflict("A learning plan for this landscape was created concurrently");
            }
            throw exception;
        }
    }

    private LearnerLearningPlan requireCurrentPlan(
            String skillpilotId,
            UUID planId,
            long expectedRevision) {
        LearnerLearningPlan plan = plans.findByIdForUpdate(skillpilotId, planId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Learning plan not found"));
        if (plan.getRevision() != expectedRevision) {
            throw conflict("Learning plan revision conflict");
        }
        return plan;
    }

    private List<LearnerLearningPlanApi.Block> requireCurrentBlocks(
            String skillpilotId,
            LearnerLearningPlan plan) {
        List<LearnerLearningPlanApi.Block> blocks = readBlocks(plan);
        if (!learners.isLearningPlanCompatible(
                skillpilotId, plan.getCurriculumId(), plan.getLandscapeId(), blocks)) {
            throw conflict("The personal curriculum changed after this learning plan was captured");
        }
        return blocks;
    }

    private Optional<PlanGoalCandidate> findPreservedActiveCandidate(
            String skillpilotId,
            List<LearnerLearningPlan> activatedPlans,
            String activeGoalId,
            Map<String, Double> mastery) {
        if (activeGoalId == null
                || activeGoalId.isBlank()
                || mastery.getOrDefault(activeGoalId, 0.0) >= MASTERY_THRESHOLD) {
            return Optional.empty();
        }
        List<PlanGoalCandidate> candidates = new ArrayList<>();
        for (LearnerLearningPlan plan : activatedPlans) {
            if (!learningScope(skillpilotId, plan.getLandscapeId(), readBlocks(plan),
                    LocalDate.now(clock.withZone(PLAN_ZONE)), false).goalIds().contains(activeGoalId)) continue;
            for (LearnerLearningPlanApi.Block block : readBlocks(plan)) {
                if (block.isActive() && "learning".equals(block.kind())
                        && block.atomicGoalIds() != null
                        && block.atomicGoalIds().contains(activeGoalId)) {
                    String focusGoalId = runtimeFocusGoalId(block, activeGoalId);
                    boolean remainsEligible = learners.getUncompactedRichFrontierForFocus(
                                    skillpilotId,
                                    block.focusGoalIds().isEmpty() ? List.of(activeGoalId) : block.focusGoalIds())
                            .stream()
                            .filter(goal -> "atomic".equals(goal.type()))
                            .anyMatch(goal -> activeGoalId.equals(goal.id()));
                    if (!remainsEligible) {
                        continue;
                    }
                    candidates.add(new PlanGoalCandidate(
                            plan,
                            new DueGoal(
                                    activeGoalId,
                                    focusGoalId,
                                    block.startDate(),
                                    block.endDate())));
                }
            }
        }
        return candidates.stream().min(planCandidateComparator());
    }

    private Optional<PlanGoalCandidate> firstCandidateAcrossPlans(
            String skillpilotId,
            List<LearnerLearningPlan> candidatePlans,
            LocalDate asOf,
            Map<String, Double> mastery,
            boolean failOnInvalidPlan) {
        return firstCandidateAcrossPlans(skillpilotId, candidatePlans, asOf, mastery, failOnInvalidPlan, false);
    }

    private Optional<PlanGoalCandidate> firstCandidateAcrossPlans(
            String skillpilotId,
            List<LearnerLearningPlan> candidatePlans,
            LocalDate asOf,
            Map<String, Double> mastery,
            boolean failOnInvalidPlan,
            boolean allowExtra) {
        return firstCandidateAcrossPlans(skillpilotId, candidatePlans, asOf, mastery,
                failOnInvalidPlan, allowExtra, true);
    }

    private Optional<PlanGoalCandidate> firstCandidateAcrossPlans(
            String skillpilotId, List<LearnerLearningPlan> candidatePlans, LocalDate asOf,
            Map<String, Double> mastery, boolean failOnInvalidPlan, boolean allowExtra, boolean keepBinding) {
        return firstCandidateAcrossPlans(skillpilotId, candidatePlans, asOf, mastery, failOnInvalidPlan,
                allowExtra, keepBinding, planFulfillment(skillpilotId, candidatePlans, mastery));
    }

    private Optional<PlanGoalCandidate> firstCandidateAcrossPlans(
            String skillpilotId, List<LearnerLearningPlan> candidatePlans, LocalDate asOf,
            Map<String, Double> mastery, boolean failOnInvalidPlan, boolean allowExtra, boolean keepBinding,
            PlanFulfillment fulfillment) {
        List<PlanGoalCandidate> candidates = new ArrayList<>();
        List<PlanGoalCandidate> furtherLearning = new ArrayList<>();
        Learner learner = learners.getLearner(skillpilotId);
        PeriodBasis periodBasis = learner.getLearningPlanPeriodBasis();
        LocalDate periodStart = periodStart(periodBasis, asOf);
        LocalDate periodEnd = periodEnd(periodBasis, asOf);
        Map<String, List<LearnerLearningPlanApi.Block>> validBlocks = new LinkedHashMap<>();
        Map<String, Set<String>> goalsBySubject = new LinkedHashMap<>();
        Map<String, Map<String, LocalDate>> datesBySubject = new LinkedHashMap<>();
        Set<String> unavailableSubjects = new HashSet<>();
        boolean examBound = hasExamScope(skillpilotId, candidatePlans, asOf);
        Map<String, Instant> completions = periodBasis == PeriodBasis.WEEK
                ? learners.getGoalCompletionsBetween(skillpilotId, periodStart, periodEnd)
                : learners.getGoalCompletionsOnDate(skillpilotId, asOf);
        for (LearnerLearningPlan plan : candidatePlans) {
            String subjectKey = stableSubjectKey(plan.getLandscapeId());
            if (subjectKey == null) continue;
            try {
                List<LearnerLearningPlanApi.Block> blocks = requireCurrentBlocks(skillpilotId, plan);
                Map<String, LocalDate> dueDates = scheduledAtomicGoalDueDatesForSchedule(blocks);
                validBlocks.put(plan.getLandscapeId(), blocks);
                goalsBySubject.computeIfAbsent(subjectKey, key -> new LinkedHashSet<>()).addAll(atomicIds(blocks));
                Map<String, LocalDate> merged = datesBySubject.computeIfAbsent(subjectKey, key -> new LinkedHashMap<>());
                dueDates.forEach((id, date) -> merged.merge(id, date,
                        (left, right) -> left.isBefore(right) ? left : right));
            } catch (ResponseStatusException exception) {
                if (failOnInvalidPlan || exception.getStatusCode().is5xxServerError()) throw exception;
                unavailableSubjects.add(subjectKey);
            } catch (IllegalStateException | NullPointerException exception) {
                if (failOnInvalidPlan) throw exception;
                unavailableSubjects.add(subjectKey);
            }
        }
        for (LearnerLearningPlan plan : candidatePlans) {
            List<LearnerLearningPlanApi.Block> blocks = validBlocks.get(plan.getLandscapeId());
            if (blocks == null) continue;
            String subjectKey = stableSubjectKey(plan.getLandscapeId());
            // An invalid part plan must not leave an apparently complete subject quota.
            // Explicit continuation remains independent of the unavailable balance.
            if (unavailableSubjects.contains(subjectKey) && !allowExtra) continue;
            if (fulfillment.unavailable().contains(plan.getLandscapeId())) {
                if (failOnInvalidPlan) throw conflict("Learning-plan assessment coverage is currently unavailable");
                continue;
            }
            Set<String> waived = fulfillment.waived(plan.getLandscapeId());
            PlanBalanceResult balance = calculateBalance(goalsBySubject.get(subjectKey),
                    datesBySubject.get(subjectKey), periodStart, periodEnd, mastery, completions,
                    countedWaivers(learner, waived));
            boolean quotaComplete = balance.offenesPeriodenpensum() == 0;
            if (quotaComplete && !allowExtra) continue;
            var scope = learningScope(skillpilotId, plan.getLandscapeId(), blocks, asOf, keepBinding);
            if (examBound && !"exam".equals(scope.kind())) continue;
            Set<String> scopeIds = Set.copyOf(scope.goalIds());
            Set<String> frontierIds = scopeIds.isEmpty() || !"exam".equals(scope.kind()) ? Set.of()
                    : learners.getUncompactedRichFrontierForFocus(skillpilotId, scope.goalIds()).stream()
                            .filter(goal -> "atomic".equals(goal.type()) && scopeIds.contains(goal.id()))
                            .map(FrontierGoal::id).collect(java.util.stream.Collectors.toSet());
            Optional<DueGoal> due = "exam".equals(scope.kind())
                    ? firstEligibleDueGoal(blocks, periodEnd, mastery, waived, ignored -> frontierIds)
                    : firstEligibleDueGoal(skillpilotId, blocks, periodEnd, mastery, waived);
            if (due.isPresent()) {
                // With explicit authorization, an earlier open goal keeps its priority
                // even when advance work has already covered this subject's quota.
                candidates.add(new PlanGoalCandidate(plan, due.get()));
            } else if (allowExtra) {
                firstScopeContinuationGoal(skillpilotId, plan.getLandscapeId(), blocks, asOf, mastery, keepBinding, waived)
                        .ifPresent(goal -> furtherLearning.add(new PlanGoalCandidate(plan, goal)));
            }
        }
        return (!candidates.isEmpty() ? candidates : furtherLearning)
                .stream().min(planCandidateComparator());
    }

    private static Comparator<PlanGoalCandidate> planCandidateComparator() {
        return Comparator
                .comparing(
                        (PlanGoalCandidate candidate) -> candidate.dueGoal().scheduledDate(),
                        Comparator.nullsLast(LocalDate::compareTo))
                .thenComparing(
                        candidate -> candidate.dueGoal().blockEndDate(),
                        Comparator.nullsLast(LocalDate::compareTo))
                .thenComparing(
                        candidate -> candidate.dueGoal().blockStartDate(),
                        Comparator.nullsLast(LocalDate::compareTo))
                .thenComparing(
                        candidate -> candidate.plan().getLandscapeId(),
                        Comparator.nullsLast(String::compareTo))
                .thenComparing(candidate -> candidate.dueGoal().atomicGoalId())
                .thenComparing(candidate -> candidate.plan().getId());
    }

    private static LearnerLearningPlanApi.TransitionResponse transition(
            PlanGoalCandidate candidate,
            String activeGoalId,
            boolean changed,
            UnifiedLearnerStateResponse state) {
        return new LearnerLearningPlanApi.TransitionResponse(
                candidate.plan().getId(),
                candidate.plan().getRevision(),
                candidate.plan().getLandscapeId(),
                candidate.dueGoal().focusGoalId(),
                activeGoalId,
                changed,
                state);
    }

    private Evaluation summarize(
            String skillpilotId,
            LearnerLearningPlan plan,
            LocalDate asOf,
            boolean enabled,
            String activeGoalId) {
        Learner learner = learners.getLearner(skillpilotId);
        PeriodBasis periodBasis = learner.getLearningPlanPeriodBasis();
        LocalDate periodStart = periodStart(periodBasis, asOf);
        LocalDate periodEnd = periodEnd(periodBasis, asOf);
        return summarize(
                skillpilotId,
                plan,
                asOf,
                periodBasis,
                periodStart,
                periodEnd,
                enabled,
                activeGoalId);
    }

    private Evaluation summarize(
            String skillpilotId,
            LearnerLearningPlan plan,
            LocalDate asOf,
            PeriodBasis periodBasis,
            LocalDate periodStart,
            LocalDate periodEnd,
            boolean enabled,
            String activeGoalId) {
        Map<String, Double> mastery = learners.getMastery(skillpilotId);
        List<LearnerLearningPlanApi.Block> blocks = readBlocks(plan);
        return summarize(skillpilotId, plan, asOf, periodBasis, periodStart, periodEnd, enabled, activeGoalId,
                mastery, planFulfillment(skillpilotId, plan.getLandscapeId(), blocks, mastery));
    }

    private Evaluation summarize(String skillpilotId, LearnerLearningPlan plan, LocalDate asOf,
            PeriodBasis periodBasis, LocalDate periodStart, LocalDate periodEnd, boolean enabled,
            String activeGoalId, Map<String, Double> mastery, PlanFulfillment fulfillment) {
        List<LearnerLearningPlanApi.Block> blocks = readBlocks(plan);
        boolean coverageUnavailable = fulfillment.unavailable().contains(plan.getLandscapeId());
        if (coverageUnavailable && !Boolean.TRUE.equals(
                learners.getLearner(skillpilotId).getLearningPlanCountOnlyExplicitGoals())) {
            throw conflict("Learning-plan assessment coverage is currently unavailable");
        }
        Set<String> waived = coverageUnavailable ? Set.of() : fulfillment.waived(plan.getLandscapeId());
        boolean stale = true;
        try {
            stale = !learners.isLearningPlanCompatible(
                    skillpilotId, plan.getCurriculumId(), plan.getLandscapeId(), blocks);
        } catch (ResponseStatusException exception) {
            if (exception.getStatusCode().is5xxServerError()) {
                throw exception;
            }
            stale = true;
        }

        Optional<DueGoal> eligible = !stale && !coverageUnavailable
                ? firstScopeContinuationGoal(skillpilotId, plan.getLandscapeId(), blocks, asOf, mastery, true, waived)
                : Optional.empty();
        boolean blockedByActiveGoal = eligible
                .map(next -> isBlockingActiveGoal(activeGoalId, next.atomicGoalId(), mastery))
                .orElse(false);
        boolean canContinue = enabled && !stale && eligible.isPresent() && !blockedByActiveGoal;
        String continueReason = canContinue
                ? null
                : !enabled
                        ? "learning-plan-following-disabled"
                        : stale
                                ? "personal-curriculum-changed"
                                : coverageUnavailable
                                        ? "assessment-coverage-unavailable"
                                : eligible.isEmpty()
                                        ? "no-open-due-frontier-goal"
                                        : "active-goal-in-progress";

        // Plan details describe the schedule only. The learning-plan status itself is
        // formulated once, per subject, in getTodayStatus; a second per-plan wording
        // here would compete with it as soon as a subject has more than one plan.
        LearnerLearningPlanApi.PlanSummary summary = new LearnerLearningPlanApi.PlanSummary(
                plan.getId(),
                plan.getRevision(),
                plan.getLandscapeId(),
                plan.getPlanLabel(),
                stale,
                period(blocks),
                currentBlock(blocks, asOf).orElse(null),
                nextMilestone(blocks, asOf).orElse(null),
                buffer(blocks, asOf),
                eligible
                        .map(next -> new LearnerLearningPlanApi.NextEligibleGoal(next.atomicGoalId()))
                        .orElse(null),
                continueReason,
                canContinue,
                stale ? null : scopeWithBlockage(skillpilotId,
                        scopeProgress(learningScope(skillpilotId, plan.getLandscapeId(), blocks, asOf, true),
                                blocks, mastery, countedWaivers(learners.getLearner(skillpilotId), waived), "de"),
                        eligible.isEmpty() && !coverageUnavailable, waived, mastery, "de"));
        return new Evaluation(summary, blocks);
    }

    private Optional<DueGoal> firstEligibleDueGoal(
            String skillpilotId,
            List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf,
            Map<String, Double> mastery, Set<String> waived) {
        return firstEligibleDueGoal(
                blocks,
                asOf,
                mastery,
                waived,
                focusGoalIds -> learners.getUncompactedRichFrontierForFocus(
                                skillpilotId,
                                focusGoalIds)
                        .stream()
                        .filter(goal -> "atomic".equals(goal.type()))
                        .map(FrontierGoal::id)
                        .collect(java.util.stream.Collectors.toSet()));
    }

    private Optional<DueGoal> firstPersonalCurriculumGoal(String skillpilotId, String landscapeId) {
        Map<String, Double> mastery = learners.getMastery(skillpilotId);
        PlanFulfillment fulfillment = planFulfillment(skillpilotId,
                plans.findByLearner_SkillpilotIdOrderByLandscapeIdAsc(skillpilotId), mastery);
        if (fulfillment.unavailable().contains(landscapeId)) return Optional.empty();
        return firstPersonalCurriculumGoal(skillpilotId, landscapeId, fulfillment.waived(landscapeId));
    }

    private Optional<DueGoal> firstPersonalCurriculumGoal(String skillpilotId, String landscapeId, Set<String> waived) {
        return learners.getPersonalCurriculumSubjectFrontier(skillpilotId, landscapeId).stream()
                .filter(goal -> "atomic".equals(goal.type()) && !waived.contains(goal.id()))
                .findFirst().map(goal -> new DueGoal(goal.id(), goal.id(), null, null));
    }

    private Optional<DueGoal> firstPersonalCurriculumGoalForPlanContinuation(
            String skillpilotId, String landscapeId, List<LearnerLearningPlan> currentPlans) {
        for (LearnerLearningPlan plan : currentPlans) {
            if (!landscapeId.equals(plan.getLandscapeId())) continue;
            final List<LearnerLearningPlanApi.Block> blocks;
            try {
                blocks = readBlocks(plan);
            } catch (ResponseStatusException exception) {
                if (exception.getStatusCode().is5xxServerError()) throw exception;
                // An unreadable old plan cannot define an inactivity choice.
                // Explicit personal-curriculum learning remains available.
                return firstPersonalCurriculumGoal(skillpilotId, landscapeId);
            }
            var scope = learningScope(skillpilotId, landscapeId, blocks,
                    LocalDate.now(clock.withZone(PLAN_ZONE)), true);
            if ("exam".equals(scope.kind())) return firstScopeContinuationGoal(skillpilotId, landscapeId, blocks,
                    LocalDate.now(clock.withZone(PLAN_ZONE)), learners.getMastery(skillpilotId), true);
            boolean hasInactiveLearning = blocks.stream().anyMatch(block -> block != null
                    && !block.isActive() && "learning".equals(block.kind()));
            if (!hasInactiveLearning) return firstPersonalCurriculumGoal(skillpilotId, landscapeId);
            if (blocks.stream().noneMatch(block -> block.isActive() && "learning".equals(block.kind()))) {
                return Optional.empty();
            }
            Set<String> inactiveOnly = inactiveOnlyAtomicIds(blocks);
            Set<String> waived = planFulfillment(skillpilotId, currentPlans, learners.getMastery(skillpilotId))
                    .waived(landscapeId);
            return learners.getPersonalCurriculumSubjectFrontier(skillpilotId, landscapeId).stream()
                    .filter(goal -> "atomic".equals(goal.type()) && !inactiveOnly.contains(goal.id()) && !waived.contains(goal.id()))
                    .findFirst().map(goal -> new DueGoal(goal.id(), goal.id(), null, null));
        }
        return firstPersonalCurriculumGoal(skillpilotId, landscapeId);
    }

    /** A schedule orders explicit further learning; dates never deny it. */
    private Optional<DueGoal> firstExplicitContinuationGoal(
            String skillpilotId, String landscapeId, List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf, Map<String, Double> mastery) {
        return firstScopeContinuationGoal(skillpilotId, landscapeId, blocks, asOf, mastery, true);
    }

    private LearningPlanScopeResolver.Scope learningScope(String skillpilotId, String landscapeId,
            List<LearnerLearningPlanApi.Block> blocks, LocalDate asOf, boolean keepBinding) {
        return LearningPlanScopeResolver.resolve(blocks, asOf,
                roots -> learners.resolveLearningPlanGoalIds(skillpilotId, landscapeId, roots),
                keepBinding ? learners.getStoredLearningPlanFocus(skillpilotId, landscapeId) : List.of());
    }

    private List<String> transitionFocus(String skillpilotId, LearnerLearningPlan plan, DueGoal selected,
            LocalDate asOf, boolean keepBinding) {
        var scope = learningScope(skillpilotId, plan.getLandscapeId(), readBlocks(plan), asOf, keepBinding);
        return "exam".equals(scope.kind()) ? scope.goalIds() : List.of(selected.focusGoalId());
    }

    private boolean hasExamScope(String skillpilotId, List<LearnerLearningPlan> candidatePlans, LocalDate asOf) {
        for (var plan : candidatePlans) {
            boolean explicitExam = false;
            try {
                List<LearnerLearningPlanApi.Block> blocks = readBlocks(plan);
                explicitExam = blocks.stream().anyMatch(block -> block.isActive() && "milestone".equals(block.kind())
                        && block.goalIds() != null && !block.goalIds().isEmpty());
                if ("exam".equals(learningScope(skillpilotId, plan.getLandscapeId(), blocks, asOf, true).kind())) {
                    return true;
                }
            } catch (ResponseStatusException exception) {
                if (exception.getStatusCode().is5xxServerError()) throw exception;
                if (explicitExam) return true;
            } catch (IllegalStateException exception) {
                if (explicitExam) return true;
                // An unreadable old schedule supplies no new exam selection.
            }
        }
        return false;
    }

    /** Retains the legacy single-focus boundary while supporting full exam selections. */
    private LearnerService.LearningPlanTransitionResult applyScopeTransition(String skillpilotId,
            boolean enableFollowing, boolean replaceActiveGoal, List<String> focusGoalIds,
            String activeGoalId, boolean publishEvent, String changeType) {
        if (focusGoalIds == null || focusGoalIds.size() <= 1) {
            return learners.applyLearningPlanTransition(skillpilotId, enableFollowing, replaceActiveGoal,
                    focusGoalIds == null || focusGoalIds.isEmpty() ? null : focusGoalIds.getFirst(),
                    activeGoalId, publishEvent, changeType);
        }
        return learners.applyLearningPlanScopeTransition(skillpilotId, enableFollowing, replaceActiveGoal,
                focusGoalIds, activeGoalId, publishEvent, changeType);
    }

    private static LearnerPlanTodayStatus.LearningScope scopeProgress(
            LearningPlanScopeResolver.Scope scope, List<LearnerLearningPlanApi.Block> blocks,
            Map<String, Double> mastery, Set<String> waived, String locale) {
        if (scope.goalIds().isEmpty()) return null;
        int achieved = (int) scope.goalIds().stream()
                .filter(id -> mastery.getOrDefault(id, 0.0) >= MASTERY_THRESHOLD || waived.contains(id)).count();
        // This names the existence of a real dated schedule, not full coverage of E.
        boolean scheduled = !atomicIds(blocks).isEmpty();
        boolean english = locale != null && locale.startsWith("en");
        String label = "exam".equals(scope.kind())
                ? (english ? "Exam preparation" : "Klausurvorbereitung")
                : (english ? "Learning plan" : "Lernplan");
        String progress = label + ": " + achieved + (english ? " of " : " von ") + scope.goalIds().size();
        return new LearnerPlanTodayStatus.LearningScope(scope.kind(), scope.sourceBlockId(),
                "plan".equals(scope.kind()) && english ? "Learning plan" : scope.title(), scope.goalIds(),
                achieved, scope.goalIds().size(), (double) achieved / scope.goalIds().size(),
                scheduled ? "scheduled" : "unscheduled", progress);
    }

    private LearnerPlanTodayStatus.LearningScope scopeWithBlockage(String skillpilotId,
            LearnerPlanTodayStatus.LearningScope scope, boolean noCandidate, Set<String> waived,
            Map<String, Double> mastery, String locale) {
        if (scope == null || !noCandidate) return scope;
        List<String> stillRequired = scope.goalIds().stream()
                .filter(id -> !waived.contains(id) && mastery.getOrDefault(id, 0.0) < MASTERY_THRESHOLD).toList();
        if (stillRequired.isEmpty()) return scope;
        String reason = learners.describeLearningPlanBlockage(skillpilotId, stillRequired, locale);
        if (reason == null || reason.isBlank()) return scope;
        return new LearnerPlanTodayStatus.LearningScope(scope.kind(), scope.sourceBlockId(), scope.title(),
                scope.goalIds(), scope.achievedGoalCount(), scope.targetGoalCount(), scope.needlePosition(),
                scope.schedulingState(), scope.progressText() + " · " + reason);
    }

    private Optional<DueGoal> firstScopeContinuationGoal(
            String skillpilotId, String landscapeId, List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf, Map<String, Double> mastery, boolean keepBinding) {
        return firstScopeContinuationGoal(skillpilotId, landscapeId, blocks, asOf, mastery, keepBinding,
                planFulfillment(skillpilotId, landscapeId, blocks, mastery).waived(landscapeId));
    }

    private Optional<DueGoal> firstScopeContinuationGoal(
            String skillpilotId, String landscapeId, List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf, Map<String, Double> mastery, boolean keepBinding, Set<String> waived) {
        var scope = learningScope(skillpilotId, landscapeId, blocks, asOf, keepBinding);
        if (!"exam".equals(scope.kind())) {
            if (blocks.stream().noneMatch(block -> block.isActive() && "learning".equals(block.kind()))) return Optional.empty();
            LocalDate cutoff = periodEnd(learners.getLearner(skillpilotId).getLearningPlanPeriodBasis(), asOf);
            var due = firstEligibleDueGoal(skillpilotId, blocks, cutoff, mastery, waived);
            if (due.isPresent()) return due;
            LocalDate scheduleEnd = blocks.stream().filter(LearnerLearningPlanApi.Block::isActive)
                    .filter(block -> "learning".equals(block.kind())).map(LearnerLearningPlanApi.Block::endDate)
                    .max(LocalDate::compareTo).orElse(asOf);
            var planned = firstEligibleDueGoal(skillpilotId, blocks, scheduleEnd, mastery, waived);
            if (planned.isPresent()) return planned;
            Set<String> inactive = inactiveOnlyAtomicIds(blocks);
            return learners.getPersonalCurriculumSubjectFrontier(skillpilotId, landscapeId).stream()
                    .filter(goal -> "atomic".equals(goal.type()) && !inactive.contains(goal.id()) && !waived.contains(goal.id()))
                    .findFirst().map(goal -> new DueGoal(goal.id(), goal.id(), null, null));
        }
        if (scope.goalIds().isEmpty()) return Optional.empty();
        Set<String> selectedIds = Set.copyOf(scope.goalIds());
        Set<String> frontierIds = learners.getUncompactedRichFrontierForFocus(skillpilotId, scope.goalIds()).stream()
                .filter(goal -> "atomic".equals(goal.type()) && selectedIds.contains(goal.id()))
                .map(FrontierGoal::id).collect(java.util.stream.Collectors.toSet());
        LocalDate dueCutoff = periodEnd(learners.getLearner(skillpilotId).getLearningPlanPeriodBasis(), asOf);
        Optional<DueGoal> due = firstEligibleDueGoal(blocks, dueCutoff, mastery, waived, ignored -> frontierIds);
        if (due.isPresent()) {
            return due;
        }
        return scope.goalIds().stream().filter(frontierIds::contains).filter(id -> !waived.contains(id))
                .filter(id -> mastery.getOrDefault(id, 0.0) < MASTERY_THRESHOLD)
                .findFirst().map(id -> new DueGoal(id, id, null, null));
    }

    private static String runtimeFocusGoalId(LearnerLearningPlanApi.Block block, String atomicGoalId) {
        List<String> roots = block.focusGoalIds();
        // A transition currently persists one focus root. An atomic focus is the
        // exact safe continuation when a section spans independent topic branches.
        return roots.size() == 1 ? roots.getFirst() : atomicGoalId;
    }

    private static Set<String> inactiveOnlyAtomicIds(List<LearnerLearningPlanApi.Block> blocks) {
        LinkedHashSet<String> inactive = new LinkedHashSet<>();
        for (LearnerLearningPlanApi.Block block : blocks) {
            if (!block.isActive() && "learning".equals(block.kind()) && block.atomicGoalIds() != null) {
                inactive.addAll(block.atomicGoalIds());
            }
        }
        inactive.removeAll(atomicIds(blocks));
        return Set.copyOf(inactive);
    }

    static Optional<DueGoal> firstEligibleDueGoal(
            List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf,
            Map<String, Double> mastery,
            Function<List<String>, Set<String>> frontierIdsForFocus) {
        return firstEligibleDueGoal(blocks, asOf, mastery, Set.of(), frontierIdsForFocus);
    }

    static Optional<DueGoal> firstEligibleDueGoal(List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf, Map<String, Double> mastery, Set<String> waived,
            Function<List<String>, Set<String>> frontierIdsForFocus) {
        Map<String, LocalDate> dueDates = scheduledAtomicGoalDueDatesForSchedule(blocks);
        LinkedHashSet<String> alreadyDue = new LinkedHashSet<>();
        List<DueGoal> candidates = new ArrayList<>();
        for (DueBlock dueBlock : dueLearningBlocks(blocks, asOf)) {
            LearnerLearningPlanApi.Block block = dueBlock.block();
            List<String> openDueInBlock = dueBlock.atomicGoalIds().stream()
                    .filter(alreadyDue::add)
                    .filter(goalId -> !waived.contains(goalId))
                    .filter(goalId -> mastery.getOrDefault(goalId, 0.0) < MASTERY_THRESHOLD)
                    .toList();
            if (openDueInBlock.isEmpty()) continue;
            if (!block.focusGoalIds().isEmpty()) {
                Set<String> frontierIds = frontierIdsForFocus.apply(block.focusGoalIds());
                for (String goalId : openDueInBlock) {
                    if (frontierIds.contains(goalId)) candidates.add(new DueGoal(
                            goalId, runtimeFocusGoalId(block, goalId), block.startDate(), block.endDate(), dueDates.get(goalId)));
                }
            } else {
                for (String goalId : openDueInBlock) {
                    if (frontierIdsForFocus.apply(List.of(goalId)).contains(goalId)) {
                        candidates.add(new DueGoal(goalId, goalId, block.startDate(), block.endDate(),
                                dueDates.get(goalId)));
                    }
                }
            }
        }
        return candidates.stream().min(Comparator.comparing(DueGoal::scheduledDate)
                .thenComparing(DueGoal::blockEndDate).thenComparing(DueGoal::blockStartDate));
    }

    static List<LearnerLearningPlanApi.Block> normalizeBlocks(
            List<LearnerLearningPlanApi.Block> requested,
            LearnerPlanningScopeResponse scope,
            Set<String> previouslyCaptured,
            boolean preserveAllScopeAtoms) {
        if (requested == null || requested.isEmpty()) {
            throw badRequest("blocks must not be empty");
        }
        if (requested.size() > MAX_BLOCKS) {
            throw badRequest("blocks exceeds the supported limit");
        }
        Set<String> scopeIds = Set.copyOf(scope.scopeAtomicGoalIds());
        Set<String> openIds = Set.copyOf(scope.openAtomicGoalIds());
        LinkedHashSet<String> unknownIds = new LinkedHashSet<>();
        HashSet<String> blockIds = new HashSet<>();
        List<IndexedBlock> indexed = new ArrayList<>();
        int submittedAtoms = 0;
        int submittedRoots = 0;

        for (int index = 0; index < requested.size(); index++) {
            LearnerLearningPlanApi.Block raw = requested.get(index);
            if (raw == null) {
                throw badRequest("blocks must not contain null entries");
            }
            String id = requireText(raw.id(), "block.id", 120);
            if (!blockIds.add(id)) {
                throw badRequest("block.id must be unique");
            }
            String kind = requireText(raw.kind(), "block.kind", 20).toLowerCase(Locale.ROOT);
            LearnerLearningPlanApi.Block normalized;
            LocalDate sortDate;
            LocalDate sortEndDate;
            switch (kind) {
                case "learning" -> {
                    LocalDate start = requireDate(raw.startDate(), "block.startDate");
                    LocalDate end = requireDate(raw.endDate(), "block.endDate");
                    requireDateOrder(start, end);
                    if (workdaysInclusive(start, end) == 0) {
                        throw badRequest("learning blocks must contain at least one workday");
                    }
                    if (raw.atomicGoalIds() == null) {
                        throw badRequest("learning block atomicGoalIds is required");
                    }
                    submittedAtoms += raw.atomicGoalIds().size();
                    if (submittedAtoms > MAX_ATOMIC_IDS) {
                        throw badRequest("atomicGoalIds exceeds the supported limit");
                    }
                    List<String> atoms = new ArrayList<>();
                    for (String rawGoalId : raw.atomicGoalIds()) {
                        String goalId = requireText(rawGoalId, "atomicGoalIds entry", 255);
                        if (!scopeIds.contains(goalId)) {
                            unknownIds.add(goalId);
                        } else if (!raw.isActive() || preserveAllScopeAtoms
                                || openIds.contains(goalId)
                                || previouslyCaptured.contains(goalId)) {
                            atoms.add(goalId);
                        }
                    }
                    submittedRoots += raw.goalIds() == null ? 0 : raw.goalIds().size();
                    List<String> goalIds = normalizeGoalRoots(raw.goalIds(), submittedRoots);
                    if (goalIds != null && goalIds.isEmpty()) {
                        throw badRequest("learning block goalIds must not be empty");
                    }
                    normalized = new LearnerLearningPlanApi.Block(
                            id,
                            kind,
                            goalIds == null ? optionalText(raw.goalId(), "block.goalId", 255) : goalIds.getFirst(),
                            optionalText(raw.title(), "block.title", MAX_BLOCK_TITLE_LENGTH),
                            start,
                            end,
                            null,
                            List.copyOf(new LinkedHashSet<>(atoms)),
                            goalIds,
                            raw.active());
                    sortDate = start;
                    sortEndDate = end;
                }
                case "buffer" -> {
                    LocalDate start = requireDate(raw.startDate(), "block.startDate");
                    LocalDate end = requireDate(raw.endDate(), "block.endDate");
                    requireDateOrder(start, end);
                    normalized = new LearnerLearningPlanApi.Block(
                            id,
                            kind,
                            null,
                            requireText(raw.title(), "block.title", MAX_BLOCK_TITLE_LENGTH),
                            start,
                            end,
                            null,
                            null,
                            null,
                            raw.active());
                    sortDate = start;
                    sortEndDate = end;
                }
                case "milestone" -> {
                    LocalDate date = requireDate(raw.date(), "block.date");
                    submittedRoots += raw.goalIds() == null ? 0 : raw.goalIds().size();
                    List<String> goalIds = normalizeGoalRoots(raw.goalIds(), submittedRoots);
                    normalized = new LearnerLearningPlanApi.Block(
                            id,
                            kind,
                            goalIds == null ? optionalText(raw.goalId(), "block.goalId", 255) : null,
                            requireText(raw.title(), "block.title", MAX_BLOCK_TITLE_LENGTH),
                            null,
                            null,
                            date,
                            null,
                            goalIds,
                            raw.active());
                    sortDate = date;
                    sortEndDate = date;
                }
                default -> throw badRequest("block.kind must be learning, buffer, or milestone");
            }
            indexed.add(new IndexedBlock(index, sortDate, sortEndDate, normalized));
        }
        if (!unknownIds.isEmpty()) {
            throw badRequest("Unknown atomicGoalIds: " + String.join(", ", unknownIds));
        }

        indexed.sort(Comparator
                .comparing(IndexedBlock::sortDate)
                .thenComparing(IndexedBlock::sortEndDate)
                .thenComparingInt(IndexedBlock::originalIndex)
                .thenComparing(entry -> entry.block().id()));
        LinkedHashSet<String> seenAtoms = new LinkedHashSet<>();
        List<LearnerLearningPlanApi.Block> normalized = new ArrayList<>();
        for (IndexedBlock entry : indexed) {
            LearnerLearningPlanApi.Block block = entry.block();
            if (!block.isActive() || !"learning".equals(block.kind())) {
                normalized.add(block);
                continue;
            }
            List<String> deduplicated = block.atomicGoalIds().stream()
                    .filter(seenAtoms::add)
                    .toList();
            normalized.add(new LearnerLearningPlanApi.Block(
                    block.id(),
                    block.kind(),
                    block.goalId(),
                    block.title(),
                    block.startDate(),
                    block.endDate(),
                    null,
                    deduplicated,
                    block.goalIds(),
                    block.active()));
        }
        boolean allLearningInactive = indexed.stream().anyMatch(entry -> "learning".equals(entry.block().kind()))
                && indexed.stream().noneMatch(entry -> "learning".equals(entry.block().kind()) && entry.block().isActive());
        if (seenAtoms.isEmpty() && !allLearningInactive) {
            throw conflict("The plan contains no currently open atomic goals");
        }
        return List.copyOf(normalized);
    }

    private static List<String> normalizeGoalRoots(List<String> rawRoots, int submittedRoots) {
        if (rawRoots == null) return null;
        if (submittedRoots > MAX_ATOMIC_IDS) throw badRequest("block goalIds exceeds the supported limit");
        LinkedHashSet<String> roots = new LinkedHashSet<>();
        for (String root : rawRoots) roots.add(requireText(root, "block.goalIds entry", 255));
        return List.copyOf(roots);
    }

    /**
     * Returns the exact cumulative due assignment used by learner-plan runtime
     * evaluation. Package visibility lets plan-order validation reuse the same
     * rounding semantics without exposing the internal due-block model.
     */
    static List<String> dueAtomicGoalIdsForSchedule(
            List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf) {
        LinkedHashSet<String> due = new LinkedHashSet<>();
        for (DueBlock dueBlock : dueLearningBlocks(blocks, asOf)) {
            due.addAll(dueBlock.atomicGoalIds());
        }
        return List.copyOf(due);
    }

    /**
     * Returns the immutable global due-slot assignment for one cutoff date.
     *
     * <p>The global rounded target count is monotone. Each newly available slot
     * is assigned to the earliest-ending started block and consumes exactly the
     * next atom of that block. Consequently, later evaluations only extend the
     * due prefixes; an atom that was due can never disappear again.</p>
     */
    private static List<DueBlock> dueLearningBlocks(
            List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf) {
        LearningDueSchedule schedule = learningDueSchedule(blocks);
        List<DueBlock> dueBlocks = new ArrayList<>();
        for (ScheduledDueBlock scheduledBlock : schedule.blocks()) {
            int dueCount = 0;
            while (dueCount < scheduledBlock.dueDates().size()
                    && !scheduledBlock.dueDates().get(dueCount).isAfter(asOf)) {
                dueCount++;
            }
            dueBlocks.add(new DueBlock(
                    scheduledBlock.block(),
                    scheduledBlock.block().atomicGoalIds().stream().limit(dueCount).toList()));
        }
        return List.copyOf(dueBlocks);
    }

    /**
     * Actual per-goal due dates used by runtime evaluation. Package visibility
     * keeps prerequisite validation on the same schedule instead of a separate
     * block-local approximation.
     */
    static Map<String, LocalDate> scheduledAtomicGoalDueDatesForSchedule(
            List<LearnerLearningPlanApi.Block> blocks) {
        LinkedHashMap<String, LocalDate> dueDates = new LinkedHashMap<>();
        for (ScheduledDueBlock scheduledBlock : learningDueSchedule(blocks).blocks()) {
            List<String> atomicGoalIds = scheduledBlock.block().atomicGoalIds();
            for (int index = 0; index < atomicGoalIds.size(); index++) {
                dueDates.merge(atomicGoalIds.get(index), scheduledBlock.dueDates().get(index),
                        (left, right) -> left.isBefore(right) ? left : right);
            }
        }
        return Map.copyOf(dueDates);
    }

    private static LearningDueSchedule learningDueSchedule(
            List<LearnerLearningPlanApi.Block> blocks) {
        List<IndexedBlock> indexedLearningBlocks = new ArrayList<>();
        for (int index = 0; index < blocks.size(); index++) {
            LearnerLearningPlanApi.Block block = blocks.get(index);
            if (block.isActive() && "learning".equals(block.kind()) && block.atomicGoalIds() != null) {
                indexedLearningBlocks.add(new IndexedBlock(
                        index,
                        block.startDate(),
                        block.endDate(),
                        block));
            }
        }
        indexedLearningBlocks.sort(Comparator
                .comparing(IndexedBlock::sortDate)
                .thenComparing(IndexedBlock::sortEndDate)
                .thenComparingInt(IndexedBlock::originalIndex)
                .thenComparing(entry -> entry.block().id()));

        List<ScheduledBlockState> states = new ArrayList<>();
        for (IndexedBlock indexedBlock : indexedLearningBlocks) {
            LearnerLearningPlanApi.Block block = indexedBlock.block();
            int size = block.atomicGoalIds().size();
            if (size == 0) {
                states.add(new ScheduledBlockState(
                        indexedBlock,
                        null,
                        null,
                        0));
                continue;
            }
            int totalWorkdays = workdaysInclusive(block.startDate(), block.endDate());
            if (totalWorkdays == 0) {
                throw new IllegalStateException("learning block must contain a workday");
            }
            LocalDate firstWorkday = firstPlanWorkday(block.startDate());
            LocalDate lastWorkday = lastPlanWorkday(block.endDate());
            if (firstWorkday.isAfter(lastWorkday)) {
                throw new IllegalStateException("learning block must contain a workday");
            }
            states.add(new ScheduledBlockState(
                    indexedBlock,
                    firstWorkday,
                    lastWorkday,
                    totalWorkdays));
        }

        List<ScheduledBlockState> nonEmptyStates = states.stream()
                .filter(state -> state.size() > 0)
                .toList();
        if (!nonEmptyStates.isEmpty()) {
            assignGlobalDueSlots(nonEmptyStates);
        }

        List<ScheduledDueBlock> scheduledBlocks = states.stream()
                .map(state -> new ScheduledDueBlock(
                        state.block(),
                        List.copyOf(state.dueDates())))
                .toList();
        return new LearningDueSchedule(scheduledBlocks);
    }

    private static void assignGlobalDueSlots(List<ScheduledBlockState> states) {
        LocalDate lastScheduleDate = states.stream()
                .map(ScheduledBlockState::lastWorkday)
                .max(LocalDate::compareTo)
                .orElseThrow();
        TreeMap<LocalDate, ScheduleBoundary> boundaries = new TreeMap<>();
        for (ScheduledBlockState state : states) {
            boundaries.computeIfAbsent(state.firstWorkday(), ignored -> new ScheduleBoundary())
                    .starts().add(state);
            if (state.lastWorkday().isBefore(lastScheduleDate)) {
                LocalDate stopDate = addPlanWorkdays(state.lastWorkday(), 1);
                boundaries.computeIfAbsent(stopDate, ignored -> new ScheduleBoundary())
                        .stops().add(state);
            }
        }

        Comparator<ScheduledBlockState> earliestDeadlineFirst = Comparator
                .comparing((ScheduledBlockState state) -> state.block().endDate())
                .thenComparing(state -> state.block().startDate())
                .thenComparingInt(ScheduledBlockState::originalIndex)
                .thenComparing(state -> state.block().id());
        PriorityQueue<ScheduledBlockState> eligible = new PriorityQueue<>(earliestDeadlineFirst);
        LinkedHashSet<ScheduledBlockState> active = new LinkedHashSet<>();
        List<LocalDate> boundaryDates = List.copyOf(boundaries.keySet());
        double cumulativeExpectedBefore = 0.0;
        long roundedBefore = 0L;

        for (int boundaryIndex = 0; boundaryIndex < boundaryDates.size(); boundaryIndex++) {
            LocalDate segmentStart = boundaryDates.get(boundaryIndex);
            ScheduleBoundary boundary = boundaries.get(segmentStart);
            for (ScheduledBlockState stopped : boundary.stops()) {
                active.remove(stopped);
                if (stopped.assignedCount() != stopped.size()) {
                    throw new IllegalStateException("global due-slot schedule missed a block deadline");
                }
            }
            for (ScheduledBlockState started : boundary.starts()) {
                active.add(started);
                eligible.add(started);
            }

            LocalDate segmentEnd = boundaryIndex + 1 < boundaryDates.size()
                    ? addPlanWorkdays(boundaryDates.get(boundaryIndex + 1), -1)
                    : lastScheduleDate;
            if (segmentEnd.isBefore(segmentStart)) {
                continue;
            }
            int segmentWorkdays = workdaysInclusive(segmentStart, segmentEnd);
            double dailyExpected = 0.0;
            for (ScheduledBlockState state : states) {
                if (active.contains(state)) {
                    dailyExpected += (double) state.size() / state.totalWorkdays();
                }
            }
            double cumulativeExpectedEnd = cumulativeExpectedBefore
                    + dailyExpected * segmentWorkdays;
            long roundedEnd = Math.round(cumulativeExpectedEnd + 1e-9);
            for (long slot = roundedBefore + 1L; slot <= roundedEnd; slot++) {
                int ordinal = earliestSegmentOrdinal(
                        slot,
                        cumulativeExpectedBefore,
                        dailyExpected,
                        segmentWorkdays);
                LocalDate dueDate = addPlanWorkdays(segmentStart, ordinal - 1L);
                ScheduledBlockState state = nextEligibleBlock(eligible);
                state.assign(dueDate);
                if (state.assignedCount() < state.size()) {
                    eligible.add(state);
                }
            }
            cumulativeExpectedBefore = cumulativeExpectedEnd;
            roundedBefore = roundedEnd;
        }

        int totalGoals = states.stream().mapToInt(ScheduledBlockState::size).sum();
        if (roundedBefore != totalGoals
                || states.stream().anyMatch(state -> state.assignedCount() != state.size())) {
            throw new IllegalStateException("global due-slot schedule is incomplete");
        }
    }

    private static int earliestSegmentOrdinal(
            long slot,
            double expectedBefore,
            double dailyExpected,
            int segmentWorkdays) {
        if (!(dailyExpected > 0.0)) {
            throw new IllegalStateException("global due-slot schedule has no eligible capacity");
        }
        double threshold = slot - 0.5 - 1e-9;
        int ordinal = (int) Math.ceil((threshold - expectedBefore) / dailyExpected);
        ordinal = Math.max(1, Math.min(segmentWorkdays, ordinal));
        while (ordinal > 1
                && Math.round(expectedBefore + dailyExpected * (ordinal - 1L) + 1e-9)
                        >= slot) {
            ordinal--;
        }
        while (ordinal <= segmentWorkdays
                && Math.round(expectedBefore + dailyExpected * ordinal + 1e-9) < slot) {
            ordinal++;
        }
        if (ordinal > segmentWorkdays) {
            throw new IllegalStateException("global due-slot date could not be resolved");
        }
        return ordinal;
    }

    private static ScheduledBlockState nextEligibleBlock(
            PriorityQueue<ScheduledBlockState> eligible) {
        ScheduledBlockState state = eligible.poll();
        while (state != null && state.assignedCount() >= state.size()) {
            state = eligible.poll();
        }
        if (state == null) {
            throw new IllegalStateException("global due-slot schedule has no started block");
        }
        return state;
    }

    private static LocalDate firstPlanWorkday(LocalDate date) {
        LocalDate result = date;
        while (result.getDayOfWeek() == DayOfWeek.SATURDAY
                || result.getDayOfWeek() == DayOfWeek.SUNDAY) {
            result = result.plusDays(1);
        }
        return result;
    }

    private static LocalDate lastPlanWorkday(LocalDate date) {
        LocalDate result = date;
        while (result.getDayOfWeek() == DayOfWeek.SATURDAY
                || result.getDayOfWeek() == DayOfWeek.SUNDAY) {
            result = result.minusDays(1);
        }
        return result;
    }

    private static LocalDate addPlanWorkdays(LocalDate date, long offset) {
        if (offset == 0L) {
            return date;
        }
        long direction = offset > 0L ? 1L : -1L;
        long remaining = Math.abs(offset);
        LocalDate result = date.plusWeeks(direction * (remaining / 5L));
        remaining %= 5L;
        while (remaining > 0L) {
            result = result.plusDays(direction);
            DayOfWeek day = result.getDayOfWeek();
            if (day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY) {
                remaining--;
            }
        }
        return result;
    }

    private LearnerLearningPlanApi.Period period(List<LearnerLearningPlanApi.Block> blocks) {
        List<LearnerLearningPlanApi.Block> activeBlocks = blocks.stream()
                .filter(LearnerLearningPlanApi.Block::isActive).toList();
        // A paused long-term section does not extend the current preparation.
        // A wholly paused plan retains its dates for display and later editing.
        List<LearnerLearningPlanApi.Block> datedBlocks = activeBlocks.isEmpty() ? blocks : activeBlocks;
        LocalDate start = datedBlocks.stream()
                .map(this::blockStart)
                .filter(Objects::nonNull)
                .min(LocalDate::compareTo)
                .orElseThrow(() -> conflict("Learning plan has no dated blocks"));
        LocalDate end = datedBlocks.stream()
                .map(this::blockEnd)
                .filter(Objects::nonNull)
                .max(LocalDate::compareTo)
                .orElseThrow(() -> conflict("Learning plan has no dated blocks"));
        return new LearnerLearningPlanApi.Period(start, end);
    }

    private Optional<LearnerLearningPlanApi.CurrentBlock> currentBlock(
            List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf) {
        return blocks.stream()
                .filter(LearnerLearningPlanApi.Block::isActive)
                .filter(block -> !"milestone".equals(block.kind()))
                .filter(block -> !asOf.isBefore(block.startDate()) && !asOf.isAfter(block.endDate()))
                .findFirst()
                .map(block -> new LearnerLearningPlanApi.CurrentBlock(
                        block.id(),
                        block.kind(),
                        displayTitle(block),
                        block.goalId(),
                        block.startDate(),
                        block.endDate()));
    }

    private Optional<LearnerLearningPlanApi.Milestone> nextMilestone(
            List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf) {
        return Optional.ofNullable(LearningPlanScopeResolver.nextMilestone(blocks, asOf))
                .map(block -> new LearnerLearningPlanApi.Milestone(
                        block.id(), block.title(), block.goalId(), block.date(), block.goalIds()));
    }

    private LearnerLearningPlanApi.Buffer buffer(
            List<LearnerLearningPlanApi.Block> blocks,
            LocalDate asOf) {
        int total = 0;
        int remaining = 0;
        for (LearnerLearningPlanApi.Block block : blocks) {
            if (!block.isActive() || !"buffer".equals(block.kind())) {
                continue;
            }
            total += workdaysInclusive(block.startDate(), block.endDate());
            if (asOf.isBefore(block.startDate())) {
                remaining += workdaysInclusive(block.startDate(), block.endDate());
            } else if (!asOf.isAfter(block.endDate())) {
                remaining += workdaysInclusive(asOf, block.endDate());
            }
        }
        return new LearnerLearningPlanApi.Buffer(total, remaining);
    }

    private static String displayTitle(LearnerLearningPlanApi.Block block) {
        if (block.title() != null && !block.title().isBlank()) {
            return block.title();
        }
        if (block.goalId() != null && !block.goalId().isBlank()) {
            return block.goalId();
        }
        return "Lernabschnitt";
    }

    private LocalDate blockStart(LearnerLearningPlanApi.Block block) {
        return "milestone".equals(block.kind()) ? block.date() : block.startDate();
    }

    private LocalDate blockEnd(LearnerLearningPlanApi.Block block) {
        return "milestone".equals(block.kind()) ? block.date() : block.endDate();
    }

    private static Set<String> atomicIds(List<LearnerLearningPlanApi.Block> blocks) {
        LinkedHashSet<String> ids = new LinkedHashSet<>();
        for (LearnerLearningPlanApi.Block block : blocks) {
            if (block.isActive() && block.atomicGoalIds() != null) {
                ids.addAll(block.atomicGoalIds());
            }
        }
        return Set.copyOf(ids);
    }

    private static Set<String> capturedAtomicIds(List<LearnerLearningPlanApi.Block> blocks) {
        LinkedHashSet<String> ids = new LinkedHashSet<>();
        for (LearnerLearningPlanApi.Block block : blocks) {
            if (block.atomicGoalIds() != null) ids.addAll(block.atomicGoalIds());
        }
        return Set.copyOf(ids);
    }

    static String scopeFingerprint(LearnerPlanningScopeResponse scope) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(scope.curriculumId().getBytes(StandardCharsets.UTF_8));
            digest.update((byte) '\n');
            digest.update(scope.landscapeId().getBytes(StandardCharsets.UTF_8));
            List<String> sorted = scope.scopeAtomicGoalIds().stream().sorted().toList();
            for (String goalId : sorted) {
                digest.update((byte) '\n');
                digest.update(goalId.getBytes(StandardCharsets.UTF_8));
            }
            return "sha256:" + HexFormat.of().formatHex(digest.digest());
        } catch (Exception exception) {
            throw new IllegalStateException("Could not fingerprint the personal curriculum scope", exception);
        }
    }

    private String writeBlocks(List<LearnerLearningPlanApi.Block> blocks) {
        try {
            return objectMapper.writeValueAsString(blocks);
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Could not persist learning-plan blocks", exception);
        }
    }

    private List<LearnerLearningPlanApi.Block> readBlocks(LearnerLearningPlan plan) {
        try {
            List<LearnerLearningPlanApi.Block> blocks = objectMapper.readValue(
                    plan.getBlocksJson(),
                    BLOCK_LIST_TYPE);
            var identity = landscapeService.identityProjection();
            return blocks == null ? List.of() : identity == null ? List.copyOf(blocks) : identity.projectBlocks(blocks);
        } catch (JsonProcessingException | NullPointerException exception) {
            throw conflict("Stored learning-plan blocks are invalid");
        }
    }

    private LocalDate asOf(LocalDate requested) {
        return requested == null ? LocalDate.now(clock.withZone(PLAN_ZONE)) : requested;
    }

    private LocalDate requireCurrentMutationDate(LocalDate requested, String action) {
        LocalDate current = LocalDate.now(clock.withZone(PLAN_ZONE));
        if (requested != null && !current.equals(requested)) {
            throw badRequest("asOf for " + action
                    + " must equal the current server date in Europe/Berlin");
        }
        return current;
    }

    private static long requireExpectedRevision(Long revision) {
        if (revision == null || revision < 0) {
            throw badRequest("expectedRevision must be zero or positive");
        }
        return revision;
    }

    private static String requireText(String value, String field, int maxLength) {
        String normalized = optionalText(value, field, maxLength);
        if (normalized == null) {
            throw badRequest(field + " is required");
        }
        return normalized;
    }

    private static String optionalText(String value, String field, int maxLength) {
        if (value == null || value.isBlank()) {
            return null;
        }
        String normalized = value.trim();
        if (normalized.length() > maxLength) {
            throw badRequest(field + " exceeds the supported length");
        }
        return normalized;
    }

    private static LocalDate requireDate(LocalDate value, String field) {
        if (value == null) {
            throw badRequest(field + " is required");
        }
        if (value.isBefore(MIN_PLAN_DATE) || value.isAfter(MAX_PLAN_DATE)) {
            throw badRequest(field + " must use a four-digit ISO year between 0000 and 9999");
        }
        return value;
    }

    private static void requireDateOrder(LocalDate start, LocalDate end) {
        if (end.isBefore(start)) {
            throw badRequest("block.endDate must not be before block.startDate");
        }
        if (ChronoUnit.DAYS.between(start, end) > MAX_BLOCK_SPAN_DAYS) {
            throw badRequest("a plan block must not span more than 100 years");
        }
    }

    private static int workdaysInclusive(LocalDate start, LocalDate end) {
        if (start == null || end == null || end.isBefore(start)) {
            return 0;
        }
        long inclusiveDays = ChronoUnit.DAYS.between(start, end) + 1;
        long count = (inclusiveDays / 7) * 5;
        int remainder = (int) (inclusiveDays % 7);
        for (int offset = 0; offset < remainder; offset++) {
            DayOfWeek day = start.plusDays(offset).getDayOfWeek();
            if (day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY) {
                count++;
            }
        }
        if (count > Integer.MAX_VALUE) {
            throw badRequest("plan block workday count exceeds the supported range");
        }
        return (int) count;
    }

    private static LearnerLearningPlanApi.PlanDetail detail(
            LearnerLearningPlanApi.PlanSummary summary,
            List<LearnerLearningPlanApi.Block> blocks) {
        return new LearnerLearningPlanApi.PlanDetail(
                summary.planId(),
                summary.revision(),
                summary.landscapeId(),
                summary.planLabel(),
                summary.stale(),
                summary.period(),
                summary.currentBlock(),
                summary.nextMilestone(),
                summary.buffer(),
                summary.nextEligibleGoal(),
                summary.continueReason(),
                summary.canContinue(),
                blocks,
                summary.learningScope());
    }

    /**
     * The one quantitative balance, over an already merged subject goal set.
     *
     * <p>S counts plan goals scheduled through the end of the period, P those newly due
     * within it, I mastered goals plus the selected plan-only waiver credit, and H the
     * distinct goals actually completed within the period that are still mastered.
     * Waivers never enter the mastery map or the real completion-event ledger.</p>
     */
    static PlanBalanceResult calculateBalance(
            Set<String> plannedGoalIds,
            Map<String, LocalDate> dueDates,
            LocalDate periodStart,
            LocalDate periodEnd,
            Map<String, Double> mastery,
            Map<String, Instant> periodCompletions) {
        return calculateBalance(plannedGoalIds, dueDates, periodStart, periodEnd, mastery, periodCompletions, Set.of());
    }

    static PlanBalanceResult calculateBalance(Set<String> plannedGoalIds, Map<String, LocalDate> dueDates,
            LocalDate periodStart, LocalDate periodEnd, Map<String, Double> mastery,
            Map<String, Instant> periodCompletions, Set<String> waived) {
        Objects.requireNonNull(plannedGoalIds, "plan goal set");
        Objects.requireNonNull(dueDates, "plan due dates");
        Objects.requireNonNull(mastery, "mastery snapshot");
        Objects.requireNonNull(periodCompletions, "completion snapshot");
        if (periodStart == null || periodEnd == null || periodEnd.isBefore(periodStart)
                || !plannedGoalIds.equals(dueDates.keySet()) || dueDates.values().stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("Plan goals, due dates and period must form one valid basis");
        }
        int s = 0;
        int p = 0;
        for (LocalDate dueDate : dueDates.values()) {
            if (dueDate.isAfter(periodEnd)) {
                continue;
            }
            s++;
            if (!dueDate.isBefore(periodStart)) {
                p++;
            }
        }
        int i = (int) plannedGoalIds.stream()
                .filter(id -> mastery.getOrDefault(id, 0.0) >= MASTERY_THRESHOLD || waived.contains(id))
                .count();
        int h = (int) periodCompletions.entrySet().stream()
                .filter(entry -> plannedGoalIds.contains(entry.getKey()))
                .filter(entry -> entry.getValue() != null)
                .filter(entry -> {
                    LocalDate completedOn = entry.getValue().atZone(PLAN_ZONE).toLocalDate();
                    return !completedOn.isBefore(periodStart) && !completedOn.isAfter(periodEnd);
                })
                .filter(entry -> mastery.getOrDefault(entry.getKey(), 0.0) >= MASTERY_THRESHOLD)
                .count();
        return UnifiedLearningPlanStatusCalculator.calculate(new PlanBalanceInputs(s, p, i, h));
    }

    /**
     * Projects the current period's existing balance into a dial. A zero target has no
     * meaningful needle position; it remains distinct from an unavailable plan status.
     */
    static LearnerPlanTodayStatus.PeriodGauge periodGauge(PlanBalanceResult balance) {
        Objects.requireNonNull(balance, "plan balance");
        int completed = balance.erfuelltesPeriodenziel();
        int target = completed + balance.offenesPeriodenpensum();
        return new LearnerPlanTodayStatus.PeriodGauge(
                completed, target, target == 0 ? null : (double) completed / target);
    }

    /**
     * Typical positive quota of the complete, merged subject schedule. Empty days or weeks
     * do not erase the scale. For an even number of scheduled periods, the mean of the two
     * central quotas is rounded up to a whole progress-effective goal.
     */
    static Integer typicalPeriodAmount(Map<String, LocalDate> dueDates, PeriodBasis periodBasis) {
        Objects.requireNonNull(dueDates, "plan due dates");
        Objects.requireNonNull(periodBasis, "period basis");
        Map<LocalDate, Integer> periodCounts = new LinkedHashMap<>();
        for (LocalDate dueDate : dueDates.values()) {
            Objects.requireNonNull(dueDate, "plan due date");
            LocalDate period = periodBasis == PeriodBasis.WEEK
                    ? dueDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                    : dueDate;
            periodCounts.merge(period, 1, Integer::sum);
        }
        if (periodCounts.isEmpty()) {
            return null;
        }
        List<Integer> positiveQuotas = periodCounts.values().stream().sorted().toList();
        int upperIndex = positiveQuotas.size() / 2;
        if (positiveQuotas.size() % 2 == 1) {
            return positiveQuotas.get(upperIndex);
        }
        int lower = positiveQuotas.get(upperIndex - 1);
        int upper = positiveQuotas.get(upperIndex);
        return lower + (upper - lower + 1) / 2;
    }

    /** The authoritative signed balance and bounded needle position for one subject. */
    static LearnerPlanTodayStatus.BalanceGauge balanceGauge(
            PlanBalanceResult balance,
            Map<String, LocalDate> dueDates,
            PeriodBasis periodBasis) {
        Objects.requireNonNull(balance, "plan balance");
        Integer typicalAmount = typicalPeriodAmount(dueDates, periodBasis);
        if (typicalAmount == null) {
            return null;
        }
        long scaleLimit = 2L * typicalAmount;
        int net = balance.vorsprung() - balance.rueckstand();
        // The red extreme is strict (> 2M behind), whereas dark green starts at >= 2M.
        // With integral goals, 2M+1 is the first point at the negative needle stop.
        double divisor = net < 0 ? scaleLimit + 1.0 : scaleLimit;
        double needlePosition = Math.max(-1.0, Math.min(1.0, net / divisor));
        return new LearnerPlanTodayStatus.BalanceGauge(
                net,
                typicalAmount,
                scaleLimit,
                needlePosition,
                net < -scaleLimit,
                net >= scaleLimit);
    }

    /** One plan's contribution to its subject: merged schedule and capabilities. */
    private record PlanEvaluation(
            Map<String, LocalDate> dueDates,
            Set<String> plannedGoalIds,
            boolean canContinue,
            boolean resumable,
            boolean current,
            LearnerPlanTodayStatus.LearningScope learningScope,
            Set<String> waivedGoalIds) {
    }

    /**
     * Collects every plan of one subject so a single balance can be calculated from the
     * merged goal set. A goal shared by several plans counts once, with its earliest date.
     */
    private static final class SubjectAggregate {

        private final String subjectKey;
        private final String subjectLabel;
        private final List<String> landscapeIds = new ArrayList<>();
        private final Map<String, LocalDate> dueDates = new LinkedHashMap<>();
        private final Set<String> plannedGoalIds = new LinkedHashSet<>();
        private final Set<String> waivedGoalIds = new LinkedHashSet<>();
        private boolean evaluable = true;
        private boolean canContinue;
        private boolean resumable;
        private boolean current;
        private LearnerPlanTodayStatus.LearningScope learningScope;

        SubjectAggregate(String subjectKey, String subjectLabel) {
            this.subjectKey = subjectKey;
            this.subjectLabel = subjectLabel;
        }

        void addPlan(String landscapeId) {
            landscapeIds.add(landscapeId);
        }

        void markUnevaluable() {
            evaluable = false;
        }

        void markCurrent() {
            current = true;
        }

        void allowContinuation() {
            canContinue = true;
            resumable = true;
        }

        boolean resumable() {
            return resumable;
        }

        boolean evaluable() {
            return evaluable;
        }

        boolean canContinue() {
            return canContinue;
        }

        void merge(PlanEvaluation evaluation) {
            evaluation.dueDates().forEach((goalId, dueDate) -> dueDates.merge(
                    goalId, dueDate, (left, right) -> left.isBefore(right) ? left : right));
            plannedGoalIds.addAll(evaluation.plannedGoalIds());
            waivedGoalIds.addAll(evaluation.waivedGoalIds());
            canContinue |= evaluation.canContinue();
            resumable |= evaluation.resumable();
            current |= evaluation.current();
            if (learningScope == null || (evaluation.learningScope() != null
                    && "exam".equals(evaluation.learningScope().kind()) && !"exam".equals(learningScope.kind()))) {
                learningScope = evaluation.learningScope();
            }
        }

        LearnerPlanTodayStatus.SubjectStatus toSubjectStatus(
                PeriodBasis periodBasis,
                LocalDate periodStart,
                LocalDate periodEnd,
                Map<String, Double> mastery,
                Map<String, Instant> periodCompletions,
                Set<String> waived,
                SubjectAchievement achievement,
                String locale) {
            // An ambiguous subject fails closed for switching: a switch must never guess
            // which plan of a subject the learner meant.
            boolean switchable = canContinue && landscapeIds.size() == 1;
            if (!evaluable) {
                return new LearnerPlanTodayStatus.SubjectStatus(
                        List.copyOf(landscapeIds), subjectKey, subjectLabel, false,
                        null, null, null, null, current, switchable, null, null,
                        achievement == null ? null : achievement.achievedGoalCount(),
                        achievement == null ? null : achievement.targetGoalCount(),
                        null, null);
            }
            PlanBalanceResult balance = calculateBalance(
                    plannedGoalIds, dueDates, periodStart, periodEnd, mastery, periodCompletions, waived);
            boolean hasScheduledGoals = !plannedGoalIds.isEmpty();
            LearnerPlanTodayStatus.LearningScope selectedScope = learningScope;
            boolean unscheduledScope = !hasScheduledGoals && selectedScope != null;
            String periodText = hasScheduledGoals
                    ? UnifiedLearningPlanStatusFormatter.formatPeriodText(periodBasis, balance, locale)
                    : unscheduledScope ? (locale.startsWith("en") ? "Scheduling pending" : "Zeitplanung offen")
                            : UnifiedLearningPlanStatusFormatter.formatNoScheduledGoalsText(locale);
            String planStatusText = hasScheduledGoals
                    ? UnifiedLearningPlanStatusFormatter.formatPlanStatusText(balance, locale)
                    : unscheduledScope ? selectedScope.progressText() : periodText;
            String subjectLine = hasScheduledGoals ? UnifiedLearningPlanStatusFormatter.formatSubjectLine(
                    subjectLabel, periodBasis, balance, locale) : subjectLabel + ": " + periodText;
            if (selectedScope != null && "exam".equals(selectedScope.kind())) {
                subjectLine = subjectLabel + ": " + selectedScope.progressText() + " · "
                        + (hasScheduledGoals ? UnifiedLearningPlanStatusFormatter.formatPeriodText(periodBasis, balance, locale)
                                : periodText);
            }
            return new LearnerPlanTodayStatus.SubjectStatus(
                    List.copyOf(landscapeIds),
                    subjectKey,
                    subjectLabel,
                    true,
                    periodText,
                    planStatusText,
                    subjectLine,
                    hasScheduledGoals ? balance.statusDirection() : null,
                    current,
                    switchable,
                    periodGauge(balance),
                    balanceGauge(balance, dueDates, periodBasis),
                    achievement == null ? null : achievement.achievedGoalCount(),
                    achievement == null ? null : achievement.targetGoalCount(),
                    hasScheduledGoals ? UnifiedLearningPlanStatusFormatter.formatBalanceDialText(balance, locale)
                            : planStatusText,
                    balance,
                    selectedScope,
                    planCreditText(plannedGoalIds, mastery, waived, locale));
        }
    }

    private static String planCreditText(Set<String> goals, Map<String, Double> mastery,
            Set<String> waived, String locale) {
        long implicit = goals.stream().filter(waived::contains)
                .filter(id -> mastery.getOrDefault(id, 0.0) < MASTERY_THRESHOLD).count();
        if (implicit == 0) return null;
        long total = goals.stream()
                .filter(id -> waived.contains(id) || mastery.getOrDefault(id, 0.0) >= MASTERY_THRESHOLD).count();
        return locale.startsWith("en")
                ? "Credited in this plan: " + total + (total == 1 ? " goal" : " goals")
                        + ", including " + implicit + " implicitly completed."
                : "Im Plan angerechnet: " + total + (total == 1 ? " Ziel" : " Ziele")
                        + ", davon " + implicit + " implizit erledigt.";
    }

    private static boolean isBlockingActiveGoal(
            String activeGoalId,
            String proposedGoalId,
            Map<String, Double> mastery) {
        return activeGoalId != null
                && !activeGoalId.isBlank()
                && !activeGoalId.equals(proposedGoalId)
                && mastery.getOrDefault(activeGoalId, 0.0) < MASTERY_THRESHOLD;
    }

    private static ResponseStatusException badRequest(String message) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, message);
    }

    private static ResponseStatusException conflict(String message) {
        return new ResponseStatusException(HttpStatus.CONFLICT, message);
    }

    private record IndexedBlock(
            int originalIndex,
            LocalDate sortDate,
            LocalDate sortEndDate,
            LearnerLearningPlanApi.Block block) {
    }

    private record Evaluation(
            LearnerLearningPlanApi.PlanSummary summary,
            List<LearnerLearningPlanApi.Block> blocks) {
    }

    private record PreparedPlan(
            Learner learner,
            String landscapeId,
            String planLabel,
            LearnerPlanningScopeResponse scope,
            Optional<LearnerLearningPlan> existing,
            List<LearnerLearningPlanApi.Block> blocks,
            String fingerprint) {
    }

    private record PlanGoalCandidate(
            LearnerLearningPlan plan,
            DueGoal dueGoal) {
    }

    record DueGoal(
            String atomicGoalId,
            String focusGoalId,
            LocalDate blockStartDate,
            LocalDate blockEndDate,
            LocalDate scheduledDate) {
        DueGoal(String atomicGoalId, String focusGoalId, LocalDate blockStartDate, LocalDate blockEndDate) {
            this(atomicGoalId, focusGoalId, blockStartDate, blockEndDate, null);
        }
    }

    private record DueBlock(LearnerLearningPlanApi.Block block, List<String> atomicGoalIds) {
    }

    private record LearningDueSchedule(List<ScheduledDueBlock> blocks) {
    }

    private record ScheduledDueBlock(
            LearnerLearningPlanApi.Block block,
            List<LocalDate> dueDates) {
    }

    private static final class ScheduledBlockState {
        private final IndexedBlock indexedBlock;
        private final LocalDate firstWorkday;
        private final LocalDate lastWorkday;
        private final int totalWorkdays;
        private final List<LocalDate> dueDates = new ArrayList<>();

        private ScheduledBlockState(
                IndexedBlock indexedBlock,
                LocalDate firstWorkday,
                LocalDate lastWorkday,
                int totalWorkdays) {
            this.indexedBlock = indexedBlock;
            this.firstWorkday = firstWorkday;
            this.lastWorkday = lastWorkday;
            this.totalWorkdays = totalWorkdays;
        }

        private int originalIndex() {
            return indexedBlock.originalIndex();
        }

        private LearnerLearningPlanApi.Block block() {
            return indexedBlock.block();
        }

        private int size() {
            return block().atomicGoalIds().size();
        }

        private LocalDate firstWorkday() {
            return firstWorkday;
        }

        private LocalDate lastWorkday() {
            return lastWorkday;
        }

        private int totalWorkdays() {
            return totalWorkdays;
        }

        private List<LocalDate> dueDates() {
            return dueDates;
        }

        private int assignedCount() {
            return dueDates.size();
        }

        private void assign(LocalDate dueDate) {
            dueDates.add(dueDate);
        }
    }

    private static final class ScheduleBoundary {
        private final List<ScheduledBlockState> starts = new ArrayList<>();
        private final List<ScheduledBlockState> stops = new ArrayList<>();

        private List<ScheduledBlockState> starts() {
            return starts;
        }

        private List<ScheduledBlockState> stops() {
            return stops;
        }
    }
}
