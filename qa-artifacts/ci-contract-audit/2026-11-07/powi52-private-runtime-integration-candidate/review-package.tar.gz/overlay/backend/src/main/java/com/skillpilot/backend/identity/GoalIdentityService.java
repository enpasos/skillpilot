package com.skillpilot.backend.identity;

/** Runtime identity projection: constructible only from a separately validated B capability. */
public final class GoalIdentityService {
    public enum Source { REPOSITORY, PACKAGE }
    public record SnapshotIdentity(Source source, String identity, String generationSha256) {
        public SnapshotIdentity {
            require(source != null && identity != null && !identity.isBlank(), "Missing snapshot identity");
            require(isSha(generationSha256), "Invalid snapshot generation");
        }
    }

    private final GoalIdentityMap identities;
    private final SnapshotIdentity snapshot;
    private final String sourceProofSha256;

    private GoalIdentityService(GoalIdentityProofLoader.ValidatedActivation activation, SnapshotIdentity active) {
        require(activation != null, "Missing validated activation receipt");
        require(activation.snapshot().equals(active), "Stale or foreign activation snapshot");
        identities = activation.identities(); snapshot = active; sourceProofSha256 = activation.sourceProofSha256();
    }

    public static GoalIdentityService fromValidatedActivation(
            GoalIdentityProofLoader.ValidatedActivation activation, SnapshotIdentity active) {
        return new GoalIdentityService(activation, active);
    }

    public String canonicalGoalId(String reference) { return identities.canonicalGoalId(reference); }
    public String storageGoalId(String reference) { return identities.storageGoalId(reference); }
    public boolean isAliasReference(String reference) { return identities.hasAlias(reference); }
    public SnapshotIdentity snapshot() { return snapshot; }
    public String sourceProofSha256() { return sourceProofSha256; }

    /** Only the finite alias set is translated; historical and unrelated keys remain byte-exact. */
    public String canonicalReference(String reference) {
        return identities.hasAlias(reference) ? canonicalGoalId(reference) : reference;
    }

    private GoalStateProjection stateProjection() {
        return new GoalStateProjection(identities, snapshot, new com.fasterxml.jackson.databind.ObjectMapper());
    }

    public java.util.Map<String, com.skillpilot.backend.api.MasteryEntryDTO> projectMastery(
            java.util.Map<String, com.skillpilot.backend.api.MasteryEntryDTO> original) {
        var result = new java.util.LinkedHashMap<String, com.skillpilot.backend.api.MasteryEntryDTO>();
        var aliases = new java.util.LinkedHashMap<String, com.skillpilot.backend.api.MasteryEntryDTO>();
        original.forEach((key, value) -> {
            if (identities.hasAlias(key)) aliases.put(key, value); else result.put(key, value);
        });
        result.putAll(stateProjection().mastery(aliases).canonical());
        return java.util.Collections.unmodifiableMap(result);
    }

    /** Validate every alias group before choosing an actual observed storage key. Never rekey a row. */
    public String masteryStorageKey(String reference, java.util.List<com.skillpilot.backend.domain.Mastery> rows) {
        if (!identities.hasAlias(reference)) return reference;
        var original = new java.util.LinkedHashMap<String, com.skillpilot.backend.api.MasteryEntryDTO>();
        rows.forEach(row -> original.put(row.getGoalKey(),
                new com.skillpilot.backend.api.MasteryEntryDTO(row.getValue(), row.getUpdatedAt())));
        projectMastery(original);
        String canonical = canonicalReference(reference);
        var matches = rows.stream().filter(row -> canonical.equals(canonicalReference(row.getGoalKey()))).toList();
        require(matches.size() <= 1, "Multiple alias persistkeys block writes pending explicit policy");
        return matches.isEmpty() ? storageGoalId(reference) : matches.getFirst().getGoalKey();
    }

    public java.util.List<String> projectFocus(java.util.List<com.skillpilot.backend.domain.PlannedGoal> rows) {
        var aliases = rows.stream().filter(row -> identities.hasAlias(row.getGoalId()))
                .map(row -> new GoalStateProjection.Focus(row.getGoalId(), row.getCreatedAt())).toList();
        stateProjection().focus(aliases); // Includes original capture times in duplicate/conflict validation.
        return rows.stream().map(row -> canonicalReference(row.getGoalId())).distinct().toList();
    }

    public java.util.List<com.skillpilot.backend.api.LearnerLearningPlanApi.Block> projectBlocks(
            java.util.List<com.skillpilot.backend.api.LearnerLearningPlanApi.Block> original) {
        return original == null ? null : GoalStateProjection.typedBlocks(original, this::canonicalReference);
    }

    public com.skillpilot.backend.completion.CompletionWorkflowState projectWorkflow(
            com.skillpilot.backend.completion.CompletionWorkflowState original) {
        return original == null ? null : GoalStateProjection.navigation(
                new GoalStateProjection.Navigation(null, null, 0, original), this::canonicalReference).workflow();
    }

    public record CompletionView(com.skillpilot.backend.domain.LearnerGoalCompletion original, String goalId) { }

    public java.util.List<CompletionView> projectCompletions(
            java.util.List<com.skillpilot.backend.domain.LearnerGoalCompletion> original) {
        var aliases = original.stream().filter(row -> identities.hasAlias(row.getGoalId())).map(row ->
                new GoalStateProjection.Completion(row.getId().toString(), row.getGoalId(), row.getCompletionDate(),
                        row.getOccurredAt(), row.getMasteryValue(), row.isObservedTransition(), row.getPracticeEvidence())).toList();
        var accepted = stateProjection().history(aliases).events().canonical().stream()
                .map(GoalStateProjection.Completion::eventId).collect(java.util.stream.Collectors.toSet());
        return original.stream().filter(row -> !identities.hasAlias(row.getGoalId()) || accepted.contains(row.getId().toString()))
                .map(row -> new CompletionView(row, canonicalReference(row.getGoalId()))).toList();
    }

    public String completionStorageKey(String reference,
            java.util.List<com.skillpilot.backend.domain.LearnerGoalCompletion> sameDayRows) {
        if (!identities.hasAlias(reference)) return reference;
        projectCompletions(sameDayRows);
        String canonical = canonicalReference(reference);
        var matches = sameDayRows.stream().filter(row -> canonical.equals(canonicalReference(row.getGoalId()))).toList();
        require(matches.size() <= 1, "Multiple alias completion rows block writes pending explicit policy");
        return matches.isEmpty() ? storageGoalId(reference) : matches.getFirst().getGoalId();
    }

    /** Invoked only after the caller has authenticated the original DTO. No SRS keys are renamed in PoWi-52. */
    public com.skillpilot.backend.api.LearnerDataDTO projectAuthenticatedImport(
            com.skillpilot.backend.api.LearnerDataDTO data, java.util.List<com.skillpilot.backend.domain.Mastery> existing) {
        java.util.Map<String, com.skillpilot.backend.api.MasteryEntryDTO> mastery = null;
        if (data.mastery() != null) {
            mastery = new java.util.LinkedHashMap<>();
            for (var entry : projectMastery(data.mastery()).entrySet())
                mastery.put(masteryStorageKey(entry.getKey(), existing), entry.getValue());
        }
        var plans = data.learningPlans() == null ? null : data.learningPlans().stream().map(plan ->
                new com.skillpilot.backend.api.LearnerLearningPlanApi.PortablePlan(
                        plan.landscapeId(), plan.planLabel(), projectBlocks(plan.blocks()))).toList();
        var focus = data.plannedGoals() == null ? null : data.plannedGoals().stream().map(this::canonicalReference).toList();
        return new com.skillpilot.backend.api.LearnerDataDTO(data.learner(), mastery, focus,
                data.copySources(), plans, data.srsData());
    }

    static boolean isUuid(String value) {
        return value != null && value.matches("(?i)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");
    }
    static boolean isSha(String value) { return value != null && value.matches("[0-9a-f]{64}"); }
    static void require(boolean condition, String message) {
        if (!condition) throw new GoalIdentityException(message);
    }
}
