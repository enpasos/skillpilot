package com.skillpilot.backend.identity;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.skillpilot.backend.api.*;
import com.skillpilot.backend.completion.CompletionWorkflowState;
import com.skillpilot.backend.domain.*;
import com.skillpilot.backend.landscape.*;
import com.skillpilot.backend.repository.*;
import com.skillpilot.backend.service.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.stream.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.junit.jupiter.api.*;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.web.server.ResponseStatusException;

/** Simulates a capability only inside tests; never invokes or opens the production loader. */
class Powi52RuntimeContinuityTest {
 static final Path ROOT=Path.of("/home/enpasos/projects/skillpilot");
 static final Path FRAME=Path.of("/dev/shm/powi52-runtime-alias-20261107/fixture-root");
 static final String OWNER="51b60137-46e8-5498-973e-ea38bb32f327", ID="private-synthetic-powi52", SECRET="test-only-signed-archive-secret";
 static final Instant TIME=Instant.parse("2026-10-01T10:00:00Z"), WRITE_TIME=TIME.plusSeconds(10);
 static final ObjectMapper OM=new ObjectMapper().registerModule(new JavaTimeModule()).disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS).disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
 static List<GoalIdentityMap.Rename> rules; static LandscapeService landscapes; static GoalMappingService mappings;
 static GoalIdentityService identity; static String OLD,CURRENT,CLUSTER,UNCHANGED; static CompositionViewService views;
 Learner learner; LearnerService service; MasteryRepository masteryRepo; LearnerRepository learnerRepo;
 PlannedGoalRepository focusRepo; LearnerClientStateRepository clientRepo; LearnerLearningPlanRepository planRepo;
 ApplicationEventPublisher publisher; Map<String,Mastery> rows; List<PlannedGoal> focus; List<LearnerGoalCompletion> events;
 @BeforeAll static void frame() throws Exception {
  var plan=OM.readTree(ROOT.resolve("qa-artifacts/ci-contract-audit/2026-11-07/powi-id-correction-inventory/first-batch-plan.json").toFile());
  assertThat(plan.path("firstActivatedSubsetCount").asInt()).isEqualTo(52);
  assertThat(plan.path("sourceSha256").asText()).isEqualTo(hex(java.security.MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(ROOT.resolve("curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_POLITIKWIRTSCHAFT.de.json")))));
  rules=new ArrayList<>(); plan.path("ids").forEach(n->rules.add(new GoalIdentityMap.Rename(OWNER,n.path("sourceGoalId").asText(),n.path("targetGoalId").asText())));
  assertThat(rules).hasSize(52);
  var props=new LandscapeProperties();props.setDirectory(FRAME.resolve("curricula").toString());
  mappings=new GoalMappingService(props,OM);mappings.pinRuntimeGeneration();landscapes=new LandscapeService(props,OM,mappings);landscapes.pinRuntimeGeneration();
  Map<String,Set<String>> owners=new LinkedHashMap<>();Set<String> original=new HashSet<>();
  landscapes.getAll().forEach(l->l.getGoals().forEach(g->{owners.computeIfAbsent(g.getId(),x->new HashSet<>()).add(l.getLandscapeId());original.add(g.getId().toLowerCase(Locale.ROOT));}));
  for(var r:rules){owners.put(r.sourceGoalId(),Set.of(OWNER)); original.remove(r.targetGoalId());original.add(r.sourceGoalId());}
  var map=new GoalIdentityMap(rules,owners,original);
  var snapshot=new GoalIdentityService.SnapshotIdentity(GoalIdentityService.Source.REPOSITORY,"private-fixture-only", "a".repeat(64));
  var ctor=GoalIdentityProofLoader.ValidatedActivation.class.getDeclaredConstructor(GoalIdentityMap.class,GoalIdentityService.SnapshotIdentity.class,String.class);
  ctor.setAccessible(true);identity=GoalIdentityService.fromValidatedActivation(ctor.newInstance(map,snapshot,"b".repeat(64)),snapshot);
  field(landscapes,"goalIdentityService",identity);
  OLD=rules.stream().filter(r->landscapes.getGoalDefinition(r.targetGoalId()).getContains().isEmpty()).findFirst().orElseThrow().sourceGoalId();CURRENT=identity.canonicalReference(OLD);CLUSTER=rules.getFirst().targetGoalId();
  UNCHANGED=landscapes.getById(OWNER).getGoals().stream().map(LearningGoal::getId).filter(id->!identity.isAliasReference(id)&&!id.contains("memory")).findFirst().orElseThrow();
  views=new CompositionViewService(props,OM,()->{Map<String,List<String>> g=new TreeMap<>();landscapes.getAll().forEach(l->l.getGoals().forEach(n->g.put(n.getId(),n.getContains())));return g;});
 }
 @BeforeEach void setup(){
  learner=new Learner();learner.setSkillpilotId(ID);learner.setLearningState(LearningState.FRONTIER);learner.setAutoPilot(false);learner.setFollowLearningPlans(false);
  rows=new LinkedHashMap<>();focus=new ArrayList<>();events=new ArrayList<>();
  learnerRepo=mock(LearnerRepository.class);masteryRepo=mock(MasteryRepository.class);focusRepo=mock(PlannedGoalRepository.class);clientRepo=mock(LearnerClientStateRepository.class);planRepo=mock(LearnerLearningPlanRepository.class);publisher=mock(ApplicationEventPublisher.class);
  when(learnerRepo.findById(ID)).thenReturn(Optional.of(learner));when(learnerRepo.findBySkillpilotIdForUpdate(ID)).thenReturn(Optional.of(learner));when(learnerRepo.existsById(ID)).thenReturn(true);when(learnerRepo.save(any())).thenAnswer(i->i.getArgument(0));
  when(masteryRepo.findByLearner_SkillpilotId(ID)).thenAnswer(i->new ArrayList<>(rows.values()));
  when(masteryRepo.findById(any())).thenAnswer(i->Optional.ofNullable(rows.get(((MasteryId)i.getArgument(0)).getGoalKey())));
  when(masteryRepo.save(any())).thenAnswer(i->{Mastery m=i.getArgument(0);m.setUpdatedAt(WRITE_TIME);rows.put(m.getGoalKey(),m);return m;});
  when(masteryRepo.saveAndFlush(any())).thenAnswer(i->{Mastery m=i.getArgument(0);m.setUpdatedAt(WRITE_TIME);rows.put(m.getGoalKey(),m);return m;});
  doAnswer(i->{rows.get(i.getArgument(1)).setUpdatedAt(i.getArgument(2));return null;}).when(masteryRepo).updateTimestamp(eq(ID),anyString(),any());
  when(focusRepo.findByLearner_SkillpilotId(ID)).thenAnswer(i->new ArrayList<>(focus));when(planRepo.findByLearner_SkillpilotIdOrderByLandscapeIdAsc(ID)).thenReturn(List.of());
  service=new LearnerService(learnerRepo,clientRepo,masteryRepo,focusRepo,landscapes,mappings,mock(DeckResourceService.class),OM,publisher);
  field(service,"learnerLearningPlanRepository",planRepo);field(service,"signingSecret",SECRET);
 }
 Mastery row(String key,double value,Instant time){Mastery m=new Mastery(learner,key,value);m.setUpdatedAt(time);rows.put(key,m);return m;}
 void active(){learner.setActiveGoalId(OLD);learner.setLearningState(LearningState.TEACHING);}
 SignedLearnerDataDTO signed(LearnerDataDTO data)throws Exception {Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(SECRET.getBytes(java.nio.charset.StandardCharsets.UTF_8),"HmacSHA256"));return new SignedLearnerDataDTO(data,hex(m.doFinal(OM.writeValueAsBytes(data))));}
 static void field(Object target,String name,Object value){try{Field f=target.getClass().getDeclaredField(name);f.setAccessible(true);f.set(target,value);}catch(Exception e){throw new RuntimeException(e);}}
 static String hex(byte[] b){return HexFormat.of().formatHex(b);}
 @Test void all52RowsRetainOriginalTimesAndNoReadWritesAcrossThreeRealMasteryConsumers(){
  for(var r:rules)row(r.sourceGoalId(),1,TIME);
  row("unknown_historical_powi_key",.7,TIME.minusSeconds(2));row(UNCHANGED,.4,TIME);
  assertThat(service.getMastery(ID)).hasSize(54).containsEntry(CURRENT,1.0).containsEntry("unknown_historical_powi_key",.7);
  for(var read:List.of(service.getMasteryWithTimestamps(ID),service.getMasteryProjectedToGoalIds(ID,Set.of(CURRENT))))
   for(var r:rules)assertThat(read).containsEntry(r.targetGoalId(),new MasteryEntryDTO(1,TIME)).doesNotContainKey(r.sourceGoalId());
  assertThat(rows).hasSize(54);assertThat(rows.get(OLD).getUpdatedAt()).isEqualTo(TIME);
  verify(masteryRepo,never()).save(any());verify(masteryRepo,never()).saveAndFlush(any());verify(learnerRepo,never()).save(any());
 }
 @Test void explicitCanonicalWriteUsesSameObservedOldPersistkey(){
  var before=row(OLD,0,TIME);active();service.setMastery(ID,new MasteryUpdateRequest(Map.of(CURRENT,1.0),CURRENT));
  assertThat(rows).containsOnlyKeys(OLD);assertThat(rows.get(OLD)).isSameAs(before);assertThat(before.getValue()).isEqualTo(1);
  verify(masteryRepo).save(before);verify(masteryRepo,never()).findById(new MasteryId(ID,CURRENT));
 }
 @Test void qualifiedObservedOldKeyRemainsTheWriteTarget(){
  var before=row(OWNER+":"+OLD,0,TIME);active();assertThat(service.getMasteryWithTimestamps(ID)).containsEntry(CURRENT,new MasteryEntryDTO(0,TIME));
  service.setMastery(ID,new MasteryUpdateRequest(Map.of(OWNER+":"+CURRENT,1.0),CURRENT));assertThat(rows).containsOnlyKeys(OWNER+":"+OLD);assertThat(rows.values()).containsExactly(before);
 }
 @Test void loneObservedCanonicalKeyIsPreservedInsteadOfRewrittenToOld(){
  var before=row(CURRENT,0,TIME);active();service.setMastery(ID,new MasteryUpdateRequest(Map.of(OLD,1.0),OLD));assertThat(rows).containsOnlyKeys(CURRENT);assertThat(rows.get(CURRENT)).isSameAs(before);
 }
 @Test void missingStorageRowUsesExplicitOriginalDefaultKey(){active();service.setMastery(ID,new MasteryUpdateRequest(Map.of(CURRENT,1.0),CURRENT));assertThat(rows).containsOnlyKeys(OLD);}
 @Test void identicalOldNewRowsDeduplicateReadsAndBlockWrites(){
  row(OLD,1,TIME);row(CURRENT,1,TIME);assertThat(service.getMasteryWithTimestamps(ID)).containsOnlyKeys(CURRENT);active();long rev=learner.getCoachStateRevision();
  assertThatThrownBy(()->service.setMastery(ID,new MasteryUpdateRequest(Map.of(CURRENT,0.0),CURRENT))).isInstanceOf(GoalIdentityException.class).hasMessageContaining("Multiple alias persistkeys");
  assertThat(rows).hasSize(2);assertThat(learner.getCoachStateRevision()).isEqualTo(rev);verify(masteryRepo,never()).save(any());
 }
 @Test void differingAliasValuesFailAllThreeReadsInsteadOfMax(){conflict(new MasteryEntryDTO(0,TIME));}
 @Test void differingAliasTimesFailAllThreeReadsInsteadOfLatest(){conflict(new MasteryEntryDTO(1,TIME.plusSeconds(1)));}
 void conflict(MasteryEntryDTO other){row(OLD,1,TIME);row(CURRENT,other.value(),other.updatedAt());
  assertThatThrownBy(()->service.getMastery(ID)).isInstanceOf(GoalIdentityException.class);assertThatThrownBy(()->service.getMasteryWithTimestamps(ID)).isInstanceOf(GoalIdentityException.class);assertThatThrownBy(()->service.getMasteryProjectedToGoalIds(ID,Set.of(CURRENT))).isInstanceOf(GoalIdentityException.class);active();
  assertThatThrownBy(()->service.setMastery(ID,new MasteryUpdateRequest(Map.of(CURRENT,1.0),CURRENT))).isInstanceOf(GoalIdentityException.class);verify(masteryRepo,never()).save(any());
 }
 @Test void lookupRejectsWrongOwnerAndUnknownCurrentUuid(){
  assertThat(landscapes.getGoalDefinition(OLD).getId()).isEqualTo(CURRENT);assertThat(landscapes.getGoalDefinition(OWNER+":"+OLD).getId()).isEqualTo(CURRENT);
  assertThatThrownBy(()->landscapes.getGoalDefinition("00000000-0000-4000-8000-000000000000:"+OLD)).isInstanceOf(GoalIdentityException.class);
  assertThat(landscapes.getGoalDefinition("00000000-0000-4000-8000-000000000000")).isNull();
 }
 @Test void clusterWriteDoesNotCreateChildrenOrAnotherRow(){learner.setActiveGoalId(CLUSTER);assertThatThrownBy(()->service.setMastery(ID,new MasteryUpdateRequest(Map.of(CLUSTER,1.0),CLUSTER))).isInstanceOf(ResponseStatusException.class).hasMessageContaining("cluster");assertThat(rows).isEmpty();}
 @Test void unknownHistoricalRowsExportWithoutGoalAuthorization(){row("opaque_history",1,TIME);assertThat(service.exportLearner(ID).data().mastery()).containsEntry("opaque_history",new MasteryEntryDTO(1,TIME));learner.setActiveGoalId("00000000-0000-4000-8000-000000000000");assertThatThrownBy(()->service.setMastery(ID,new MasteryUpdateRequest(Map.of(learner.getActiveGoalId(),1.0),learner.getActiveGoalId()))).hasMessageContaining("Unknown active goal");}
 @Test void oldFocusReadPreservesOriginalCreatedAtAndRow(){var f=new PlannedGoal(learner,OLD);field(f,"createdAt",TIME);focus.add(f);long rev=learner.getCoachStateRevision();assertThat(service.getPlannedGoals(ID)).containsExactly(CURRENT);assertThat(f.getGoalId()).isEqualTo(OLD);assertThat(f.getCreatedAt()).isEqualTo(TIME);assertThat(learner.getCoachStateRevision()).isEqualTo(rev);verify(focusRepo,never()).deleteAll(any());verify(focusRepo,never()).saveAll(any());}
 @Test void conflictingFocusTimesFailBeforeReadDefaultOrDeletion(){var a=new PlannedGoal(learner,OLD);var b=new PlannedGoal(learner,CURRENT);field(a,"createdAt",TIME);field(b,"createdAt",TIME.plusSeconds(1));focus.addAll(List.of(a,b));assertThatThrownBy(()->service.getPlannedGoals(ID)).isInstanceOf(GoalIdentityException.class);verify(focusRepo,never()).deleteAll(any());}
 @Test void oldPlanTypedWorkingCopyKeepsCaptureBytesNullsArraysAndNavigationBinding()throws Exception {
  var block=new LearnerLearningPlanApi.Block("block-original","learning",OLD,"original-title",LocalDate.of(2026,10,1),LocalDate.of(2026,10,2),null,List.of(OLD,CURRENT),List.of(),false);
  var plan=new LearnerLearningPlan();plan.setBlocksJson(OM.writeValueAsString(List.of(block)));plan.setRevision(17);plan.setScopeFingerprint("original-fingerprint");plan.setCapturedAt(TIME);String before=plan.getBlocksJson();
  var m=LearnerService.class.getDeclaredMethod("readPortableLearningPlanBlocks",LearnerLearningPlan.class);m.setAccessible(true);
  @SuppressWarnings("unchecked") var translated=(List<LearnerLearningPlanApi.Block>)m.invoke(service,plan);assertThat(translated.getFirst().goalId()).isEqualTo(CURRENT);assertThat(translated.getFirst().atomicGoalIds()).containsExactly(CURRENT,CURRENT);assertThat(translated.getFirst().goalIds()).isEmpty();assertThat(translated.getFirst().active()).isFalse();assertThat(plan.getBlocksJson()).isEqualTo(before);assertThat(plan.getRevision()).isEqualTo(17);assertThat(plan.getCapturedAt()).isEqualTo(TIME);assertThat(plan.getScopeFingerprint()).isEqualTo("original-fingerprint");
  var direct=new CompletionWorkflowState.DirectAssessmentContext("claude","original-session",OLD,TIME);
  var nav=new CompletionWorkflowState("profile","rev","generation",OWNER,"digest","required",OLD,direct);var actual=identity.projectWorkflow(nav);assertThat(actual.currentGoalId()).isEqualTo(CURRENT);assertThat(actual.directAssessment().goalId()).isEqualTo(CURRENT);assertThat(actual.directAssessment().sessionBinding()).isEqualTo("original-session");assertThat(actual.directAssessment().expiresAt()).isEqualTo(TIME);assertThat(actual.curriculumGeneration()).isEqualTo("generation");
 }
 @Test void actualHistoryAndBerlinMetricsAssociateOriginalEventsOnceWithoutNewCredit(){
  row(OLD,1,TIME);var event=new LearnerGoalCompletion(learner,OLD,LocalDate.of(2026,10,1),TIME,1);event.bindPracticeEvidence("coach_learning","unchanged-fingerprint",TIME);events.add(event);var completionRepo=mock(LearnerGoalCompletionRepository.class);when(completionRepo.findByLearner_SkillpilotIdOrderByOccurredAtDesc(ID)).thenReturn(events);when(completionRepo.findByLearner_SkillpilotIdAndCompletionDateOrderByOccurredAtAsc(eq(ID),any())).thenReturn(events);when(completionRepo.findByLearner_SkillpilotIdAndCompletionDateBetweenOrderByOccurredAtAsc(eq(ID),any(),any())).thenReturn(events);
  var completionService=new LearnerGoalCompletionService(completionRepo);field(service,"goalCompletionService",completionService);
  assertThat(service.getHistory(ID)).hasSize(1);assertThat(service.getHistory(ID).getFirst().goalId()).isEqualTo(CURRENT);assertThat(service.getHistory(ID).getFirst().timestamp()).isEqualTo(TIME);assertThat(service.getGoalCompletionsOnDate(ID,event.getCompletionDate())).containsExactlyEntriesOf(Map.of(CURRENT,TIME));assertThat(service.getGoalCompletionsBetween(ID,event.getCompletionDate(),event.getCompletionDate())).containsExactlyEntriesOf(Map.of(CURRENT,TIME));assertThat(event.getGoalId()).isEqualTo(OLD);assertThat(event.getPracticeEvidence()).containsExactly(new LearnerGoalCompletion.PracticeEvidence("coach_learning","unchanged-fingerprint",TIME));verify(completionRepo,never()).save(any());
 }
 @Test void signatureAuthenticatesOriginalBeforeCanonicalImportAndRestoresSamePersistkeyTime()throws Exception {
  var existing=row(OWNER+":"+OLD,0,TIME.minusSeconds(10));var data=new LearnerDataDTO(null,Map.of(OLD,new MasteryEntryDTO(1,TIME)),null,Set.of(),null,null);var signed=signed(data);byte[] before=OM.writeValueAsBytes(data);service.importLearner(ID,signed);assertThat(rows).containsOnlyKeys(OWNER+":"+OLD);assertThat(rows.values()).containsExactly(existing);assertThat(existing.getValue()).isEqualTo(1);assertThat(existing.getUpdatedAt()).isEqualTo(TIME);assertThat(OM.writeValueAsBytes(data)).containsExactly(before);verify(masteryRepo).updateTimestamp(ID,OWNER+":"+OLD,TIME);
 }
 @Test void invalidOriginalSignaturePrecedesAnyAliasReadOrWrite()throws Exception {
  var data=new LearnerDataDTO(null,Map.of(OLD,new MasteryEntryDTO(1,TIME)),null,Set.of(),null,null);var translated=new LearnerDataDTO(null,Map.of(CURRENT,new MasteryEntryDTO(1,TIME)),null,Set.of(),null,null);
  assertThatThrownBy(()->service.importLearner(ID,new SignedLearnerDataDTO(data,signed(translated).signature()))).isInstanceOf(ResponseStatusException.class).hasMessageContaining("Invalid data signature");verifyNoInteractions(masteryRepo);verify(learnerRepo,never()).findBySkillpilotIdForUpdate(any());
 }
 @Test void importedAliasConflictBlocksWholeArchiveBeforeMutation()throws Exception {
  var data=new LearnerDataDTO(null,Map.of(OLD,new MasteryEntryDTO(1,TIME),CURRENT,new MasteryEntryDTO(0,TIME)),List.of(OLD),Set.of(),null,null);assertThatThrownBy(()->service.importLearner(ID,signed(data))).isInstanceOf(GoalIdentityException.class);verify(masteryRepo,never()).saveAndFlush(any());verify(learnerRepo,never()).save(any());verifyNoInteractions(publisher);
 }
 @Test void loaderCannotBeOpenedByArbitraryApprovedJson(){assertThatThrownBy(()->new GoalIdentityProofLoader().load("{\"approved\":true}".getBytes(),identity.snapshot())).isInstanceOf(GoalIdentityException.class).hasMessageContaining("unavailable");}

 @Test void everyCurrentPoWiScopeKeepsExactlyItsOriginalTargetsAfterInverse52Projection()throws Exception {
  var props=new LandscapeProperties();props.setDirectory(ROOT.resolve("curricula").toString());
  var oldMappings=new GoalMappingService(props,OM);oldMappings.pinRuntimeGeneration();var oldLandscape=new LandscapeService(props,OM,oldMappings);oldLandscape.pinRuntimeGeneration();
  var oldViews=new CompositionViewService(props,OM,()->{Map<String,List<String>> g=new TreeMap<>();oldLandscape.getAll().forEach(l->l.getGoals().forEach(n->g.put(n.getId(),n.getContains())));return g;});
  var tx=new org.springframework.transaction.PlatformTransactionManager(){public org.springframework.transaction.TransactionStatus getTransaction(org.springframework.transaction.TransactionDefinition d){return new org.springframework.transaction.support.SimpleTransactionStatus();}public void commit(org.springframework.transaction.TransactionStatus t){}public void rollback(org.springframework.transaction.TransactionStatus t){}};
  var base=new LearnerService(learnerRepo,clientRepo,masteryRepo,focusRepo,oldLandscape,oldMappings,mock(DeckResourceService.class),oldViews,OM,publisher,tx);
  var candidate=new LearnerService(learnerRepo,clientRepo,masteryRepo,focusRepo,landscapes,mappings,mock(DeckResourceService.class),views,OM,publisher,tx);
  Method projection=LearnerService.class.getDeclaredMethod("getGoalProjection",String.class,String.class);projection.setAccessible(true);
  var requests=OM.readTree(Path.of("/dev/shm/powi-native-focus-verification-20261107/requests.json").toFile());int seen=0,progressCases=0;var evidence=new ArrayList<Map<String,Object>>();
  row(OLD,1,TIME);
  for(var request:requests){
   @SuppressWarnings("unchecked") Map<String,Object> syntheticConfig=OM.convertValue(request.path("personalCurriculum"),Map.class);
   Method mark=CurriculumPersonalizationPlanner.class.getDeclaredMethod("markMigrationCompleted",Map.class,String.class);mark.setAccessible(true);mark.invoke(null,syntheticConfig,"a0e13c56-c25f-4742-9272-3a1a603ee52e");
   String config=OM.writeValueAsString(syntheticConfig);Object before=projection.invoke(base,"a0e13c56-c25f-4742-9272-3a1a603ee52e",config),after=projection.invoke(candidate,"a0e13c56-c25f-4742-9272-3a1a603ee52e",config);
   for(String field:List.of("targetGoalIds","prerequisiteOnlyGoalIds")){Method get=before.getClass().getDeclaredMethod(field);get.setAccessible(true);
    @SuppressWarnings("unchecked") Set<String> original=(Set<String>)get.invoke(before);@SuppressWarnings("unchecked") Set<String> current=(Set<String>)get.invoke(after);
    assertThat(current).as(request.path("key").asText()+":"+field).containsExactlyInAnyOrderElementsOf(original.stream().map(identity::canonicalReference).toList());
    evidence.add(Map.of("scope",request.path("key").asText(),"field",field,"beforeCount",original.size(),"afterCount",current.size(),"exactInverse52Identity",true));
    if (field.equals("targetGoalIds") && current.contains(CURRENT)) {
     learner.setSelectedCurriculum("a0e13c56-c25f-4742-9272-3a1a603ee52e");learner.setPersonalCurriculum(config);
     var oldProgress=base.getPlanningScope(ID,OWNER);var newProgress=candidate.getPlanningScope(ID,OWNER);
     assertThat(newProgress.totalAtomicGoalCount()).isEqualTo(oldProgress.totalAtomicGoalCount());
     assertThat(newProgress.masteredAtomicGoalCount()).isEqualTo(oldProgress.masteredAtomicGoalCount()).isGreaterThanOrEqualTo(1);
     assertThat(newProgress.openAtomicGoalIds()).doesNotContain(CURRENT);progressCases++;
    }
   } seen++;
  }
  assertThat(seen).isEqualTo(38);assertThat(progressCases).isGreaterThan(0);
  OM.writerWithDefaultPrettyPrinter().writeValue(Path.of("/dev/shm/powi52-runtime-alias-20261107/scope-continuity.json").toFile(),Map.of("contexts",seen,"comparisons",evidence,"actualProgressContexts",progressCases));
  verify(masteryRepo,never()).save(any());verify(learnerRepo,never()).save(any());
 }
 @Test void lateInvalidPlanGroupRejectsSignedImportBeforeAnyMasteryOrFocusMutation()throws Exception {
  var invalid=new LearnerLearningPlanApi.PortablePlan(OWNER,"invalid-empty",List.of());
  var data=new LearnerDataDTO(null,Map.of(OLD,new MasteryEntryDTO(1,TIME)),List.of(OLD),Set.of(),List.of(invalid),null);
  assertThatThrownBy(()->service.importLearner(ID,signed(data))).isInstanceOf(ResponseStatusException.class);
  assertThat(rows).isEmpty();verify(masteryRepo,never()).saveAndFlush(any());verify(learnerRepo,never()).save(any());verify(focusRepo,never()).deleteAll(any());verifyNoInteractions(publisher);
 }
 @Test void invalidAliasWorkflowOwnerCannotDisappearIntoAnEmptyAssessmentContext()throws Exception {
  var direct=new CompletionWorkflowState.DirectAssessmentContext("claude","original-session","00000000-0000-4000-8000-000000000000:"+OLD,TIME);
  var nav=new CompletionWorkflowState("profile","revision","generation",OWNER,"digest","required",OLD,direct);
  learner.setCompletionWorkflow(OM.writeValueAsString(nav));
  Method parse=LearnerService.class.getDeclaredMethod("completionWorkflow",Learner.class);parse.setAccessible(true);
  assertThatThrownBy(()->parse.invoke(service,learner)).isInstanceOf(InvocationTargetException.class).hasCauseInstanceOf(GoalIdentityException.class);
 }
 @Test void completionExplicitWriteReusesActualOriginalDailyEventKey(){
  var event=new LearnerGoalCompletion(learner,OLD,LocalDate.of(2026,10,1),TIME,1);event.bindPracticeEvidence("coach_learning","same-fingerprint",TIME);var repo=mock(LearnerGoalCompletionRepository.class);
  when(repo.findByLearner_SkillpilotIdAndCompletionDateOrderByOccurredAtAsc(ID,event.getCompletionDate())).thenReturn(List.of(event));
  when(repo.findByLearner_SkillpilotIdAndGoalIdAndCompletionDate(ID,OLD,event.getCompletionDate())).thenReturn(Optional.of(event));
  var actual=new LearnerGoalCompletionService(repo);field(actual,"landscapeService",landscapes);actual.recordTransition(learner,CURRENT,0,1,TIME.plusSeconds(20),"coach_learning","same-fingerprint");
  verify(repo).save(event);assertThat(event.getGoalId()).isEqualTo(OLD);assertThat(event.getOccurredAt()).isEqualTo(TIME);assertThat(event.getPracticeEvidence()).hasSize(1);
 }
 @Test void originalDailyHistoryAliasesDeduplicateOnlyWhenAllOutcomeTimesAndPracticeMatch(){
  row(OLD,1,TIME);var before=new LearnerGoalCompletion(learner,OLD,LocalDate.of(2026,10,1),TIME,1);var alias=new LearnerGoalCompletion(learner,CURRENT,before.getCompletionDate(),TIME,1);
  assertThat(identity.projectCompletions(List.of(before,alias))).hasSize(1);assertThat(before.getGoalId()).isEqualTo(OLD);assertThat(alias.getGoalId()).isEqualTo(CURRENT);
  var changed=new LearnerGoalCompletion(learner,CURRENT,before.getCompletionDate(),TIME.plusSeconds(1),1);assertThatThrownBy(()->identity.projectCompletions(List.of(before,changed))).isInstanceOf(GoalIdentityException.class);
 }

 @Test void existingFocusAliasConflictRejectsEntireImportBeforeFirstMutation()throws Exception {
  var a=new PlannedGoal(learner,OLD);var b=new PlannedGoal(learner,CURRENT);field(a,"createdAt",TIME);field(b,"createdAt",TIME.plusSeconds(1));focus.addAll(List.of(a,b));
  var data=new LearnerDataDTO(null,Map.of(OLD,new MasteryEntryDTO(1,TIME)),null,Set.of(),null,null);
  assertThatThrownBy(()->service.importLearner(ID,signed(data))).isInstanceOf(GoalIdentityException.class);verify(masteryRepo,never()).saveAndFlush(any());verify(learnerRepo,never()).save(any());verifyNoInteractions(publisher);
 }
 @Test void ordinaryLegacyStageArchiveWithRealPlanStillMigratesBeforePlanPreflight()throws Exception {
  String root="a0e13c56-c25f-4742-9272-3a1a603ee52e",math="68a8ac50-f5f5-4e24-8aa9-5e408ca01ced",atom="4b67bed9-06da-40b2-a306-24e9e7dfd390";
  var oldConfig=new LinkedHashMap<String,Object>();oldConfig.put(root,Map.of("selected",true,"filterId","ALL"));oldConfig.put(math,Map.of("selected",true,"filterId","ALL"));oldConfig.put("__skillpilot_stage_scope_sek1__",Map.of("selected",true));oldConfig.put("__skillpilot_stage_scope_sek2__",Map.of("selected",true));
  var source=new Learner();source.setSkillpilotId("private-source-archive");source.setSelectedCurriculum(root);source.setPersonalCurriculum(OM.writeValueAsString(oldConfig));String originalConfig=source.getPersonalCurriculum();
  var block=new LearnerLearningPlanApi.Block("old-plan-block","learning",null,"Original",LocalDate.of(2026,10,1),LocalDate.of(2026,10,2),null,List.of(atom));
  var data=new LearnerDataDTO(source,Map.of("unaffected-global-history",new MasteryEntryDTO(.93,TIME)),null,Set.of(),List.of(new LearnerLearningPlanApi.PortablePlan(math,"Original plan",List.of(block))),null);
  service.importLearner(ID,signed(data));
  assertThat(source.getPersonalCurriculum()).isEqualTo(originalConfig);assertThat(OM.readTree(learner.getPersonalCurriculum()).path(root).path("stage").asText()).isEqualTo("CrossStage");assertThat(rows).containsEntry("unaffected-global-history",rows.get("unaffected-global-history"));assertThat(rows.get("unaffected-global-history").getUpdatedAt()).isEqualTo(TIME);verify(planRepo).saveAll(argThat(saved->{var list=StreamSupport.stream(saved.spliterator(),false).toList();return list.size()==1&&list.getFirst().getBlocksJson().contains(atom)&&list.getFirst().getLearner()==learner;}));
 }

 @Test void explicitSameSemanticFocusKeepsActualOldPersistkeyAndCreationTime()throws Exception {
  String root="a0e13c56-c25f-4742-9272-3a1a603ee52e";field(service,"compositionViewService",views);
  Method mark=CurriculumPersonalizationPlanner.class.getDeclaredMethod("markMigrationCompleted",Map.class,String.class);mark.setAccessible(true);
  Method project=LearnerService.class.getDeclaredMethod("getGoalProjection",String.class,String.class);project.setAccessible(true);String selectedConfig=null;
  for(var request:OM.readTree(Path.of("/dev/shm/powi-native-focus-verification-20261107/requests.json").toFile())) {
   @SuppressWarnings("unchecked") Map<String,Object> config=OM.convertValue(request.path("personalCurriculum"),Map.class);mark.invoke(null,config,root);String json=OM.writeValueAsString(config);Object projection=project.invoke(service,root,json);Method targets=projection.getClass().getDeclaredMethod("targetGoalIds");targets.setAccessible(true);
   if (((Set<?>)targets.invoke(projection)).contains(CURRENT)){selectedConfig=json;break;}
  }
  assertThat(selectedConfig).isNotNull();learner.setSelectedCurriculum(root);learner.setPersonalCurriculum(selectedConfig);var original=new PlannedGoal(learner,OLD);field(original,"createdAt",TIME);focus.add(original);
  assertThat(service.setPlannedGoals(ID,Set.of(CURRENT))).containsExactly(CURRENT);
  assertThat(original.getGoalId()).isEqualTo(OLD);assertThat(original.getCreatedAt()).isEqualTo(TIME);verify(focusRepo).deleteAll(argThat(deleted->!StreamSupport.stream(deleted.spliterator(),false).anyMatch(g->g==original)));verify(focusRepo).saveAll(argThat(added->!added.iterator().hasNext()));
 }
 @Test void omittedLearnerArchiveCannotPreparePlanAgainstAnUncommittedMigration()throws Exception {
  String root="a0e13c56-c25f-4742-9272-3a1a603ee52e",math="68a8ac50-f5f5-4e24-8aa9-5e408ca01ced",atom="4b67bed9-06da-40b2-a306-24e9e7dfd390";
  var config=Map.of(root,Map.of("selected",true,"filterId","ALL"),math,Map.of("selected",true,"filterId","ALL"),"__skillpilot_stage_scope_sek1__",Map.of("selected",true),"__skillpilot_stage_scope_sek2__",Map.of("selected",true));learner.setSelectedCurriculum(root);learner.setPersonalCurriculum(OM.writeValueAsString(config));String before=learner.getPersonalCurriculum();
  var block=new LearnerLearningPlanApi.Block("old-plan-block","learning",null,"Original",LocalDate.of(2026,10,1),LocalDate.of(2026,10,2),null,List.of(atom));
  var data=new LearnerDataDTO(null,Map.of("unaffected-global-history",new MasteryEntryDTO(.93,TIME)),null,Set.of(),List.of(new LearnerLearningPlanApi.PortablePlan(math,"Original plan",List.of(block))),null);
  assertThatThrownBy(()->service.importLearner(ID,signed(data))).isInstanceOf(ResponseStatusException.class).hasMessageContaining("incomplete");assertThat(learner.getPersonalCurriculum()).isEqualTo(before);verify(masteryRepo,never()).saveAndFlush(any());verify(planRepo,never()).saveAll(any());
 }
}
