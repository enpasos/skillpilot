import json,subprocess,datetime,hashlib
from pathlib import Path
W=Path('/dev/shm/powi52-runtime-alias-20261107');R=Path('/home/enpasos/projects/skillpilot');cp=(W/'regression-classpath.txt').read_text()
agent=next(Path('/tmp/skillpilot-plan-gradle-20261022/caches/modules-2/files-2.1/net.bytebuddy/byte-buddy-agent').rglob('*.jar'))
args=['bwrap','--ro-bind','/','/','--dev-bind','/dev','/dev','--proc','/proc','--bind','/dev/shm','/dev/shm','--',str(R/'tmp/amazon-corretto-25.0.2.10.1/bin/java'),'-Xmx1400m','-Djava.io.tmpdir='+str(W),'-javaagent:'+str(agent),'-cp',cp,'RunRegressionTests']+(W/'regression-classes.txt').read_text().splitlines()
rec={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':args,'cwd':str(W)}
with (W/'regression-junit.stdout').open('w') as o,(W/'regression-junit.stderr').open('w') as e:p=subprocess.run(args,cwd=R,stdout=o,stderr=e)
rec.update(exitCode=p.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=hashlib.sha256((W/'regression-junit.stdout').read_bytes()).hexdigest(),stderrSha256=hashlib.sha256((W/'regression-junit.stderr').read_bytes()).hexdigest());(W/'regression-junit-execution.json').write_text(json.dumps(rec,indent=2)+'\n');print('Junit exit',p.returncode);print((W/'regression-junit.stdout').read_text()[-10000:]);print((W/'regression-junit.stderr').read_text()[-2000:]);raise SystemExit(p.returncode)
