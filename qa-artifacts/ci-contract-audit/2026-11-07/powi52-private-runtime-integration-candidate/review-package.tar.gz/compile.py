from pathlib import Path
import json,hashlib,subprocess
R=Path('/home/enpasos/projects/skillpilot');W=Path('/dev/shm/powi52-runtime-alias-20261107'); C=W/'classes';C.mkdir(exist_ok=True)
old=json.loads(Path('/dev/shm/informatics-owner-entry-readiness-repair-s0nr8nmh/before-source-class-guards.json').read_text())
rootguard=json.loads(Path('/dev/shm/root-owner-entry-active-checks/active-source-guard.json').read_text()); expected={r['path']:r['sourceSha256'] for r in old['rows']}; expected.update({k:v for k,v in rootguard['activeFiles'].items() if '/main/java/' in k})
actual={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'backend/src/main/java').rglob('*.java')}
drift=[p for p in set(expected)|set(actual) if expected.get(p)!=actual.get(p)]
(W/'source-guard.json').write_text(json.dumps({'sources':len(actual),'unexpectedDrift':drift,'all484CurrentSourcePins':actual},indent=2)+'\n');assert not drift,drift
cp=':'.join([str(C),'/dev/shm/root-owner-entry-active-checks/classes',Path('/dev/shm/informatics-owner-entry-readiness-repair-s0nr8nmh/focused-test-classpath.txt').read_text().strip()]);(W/'classpath.txt').write_text(cp)
java=R/'tmp/amazon-corretto-25.0.2.10.1/bin/javac';args=[str(java),'-J-Xmx700m','-cp',cp,'-d',str(C)]+[str(p) for p in (W/'overlay').rglob('*.java')]+[str(p) for p in (W/'tests').rglob('*.java')]+[str(W/'RunAliasTests.java')]
p=subprocess.run(args,cwd=W,text=True,capture_output=True);(W/'compile.stdout').write_text(p.stdout);(W/'compile.stderr').write_text(p.stderr);print(p.stderr);print('compile exit',p.returncode);raise SystemExit(p.returncode)
