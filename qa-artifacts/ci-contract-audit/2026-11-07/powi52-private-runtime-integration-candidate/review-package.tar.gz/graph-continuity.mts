import {readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {checkSkillGraphIntegrity} from '/home/enpasos/projects/skillpilot/app/scripts/lib/skillGraphIntegrity.ts';
const root='/home/enpasos/projects/skillpilot',w='/dev/shm/powi52-runtime-alias-20261107',owner='51b60137-46e8-5498-973e-ea38bb32f327';
const plan=JSON.parse(readFileSync(root+'/qa-artifacts/ci-contract-audit/2026-11-07/powi-id-correction-inventory/first-batch-plan.json','utf8'));
const rev=new Map(plan.ids.map((r:any)=>[r.targetGoalId,r.sourceGoalId]));
const restore=(v:any):any=>typeof v==='string'?[...rev].reduce((s,[to,from]:any)=>s.replaceAll(to,from),v):Array.isArray(v)?v.map(restore):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,restore(x)])):v;
const paths=readdirSync(root+'/curricula/DE/Gymnasium/canonical').filter(f=>f.endsWith('.json')&&!/_deck/i.test(f)).sort().map(f=>'curricula/DE/Gymnasium/canonical/'+f);
const pins:any[]=[];
function catalog(r:string){return paths.map(sourceFile=>{const b=readFileSync(r+'/'+sourceFile);const j=JSON.parse(b.toString());if(r===root)pins.push({path:sourceFile,sha256:createHash('sha256').update(b).digest('hex')});return{landscapeId:j.landscapeId,sourceFile,goals:j.goals};});}
const before=checkSkillGraphIntegrity(catalog(root),[owner]);const after=checkSkillGraphIntegrity(catalog(w+'/fixture-root'),[owner]);
const count=(r:any,id:string)=>r.findings.filter((f:any)=>f.ruleId===id).length;
const sem=(r:any)=>JSON.stringify(r.findings.filter((f:any)=>f.ruleId!=='G01a').map(restore).sort((a:any,b:any)=>JSON.stringify(a).localeCompare(JSON.stringify(b))));
if(count(before,'G01a')!==477||count(after,'G01a')!==317||count(before,'G17')!==116||count(after,'G17')!==116||sem(before)!==sem(after))throw Error('PoWi52 graph semantics mismatch');
const result={scope:'normal-native-StrictGraphChecker-data-only',canonicalSources:paths.length,canonicalGoals:catalog(root).reduce((n:any,r:any)=>n+r.goals.length,0),before:{G01a:count(before,'G01a'),G17:count(before,'G17')},after:{G01a:count(after,'G01a'),G17:count(after,'G17')},nonG01aFindingsInverseExact:true,sourceAProbeExecuted:false,runtimeActivated:false,pins};
writeFileSync(w+'/graph-continuity.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,pins:undefined}));
