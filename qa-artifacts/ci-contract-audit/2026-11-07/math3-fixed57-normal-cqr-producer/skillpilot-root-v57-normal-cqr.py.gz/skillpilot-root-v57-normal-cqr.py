from pathlib import Path
import json,hashlib,tempfile,shutil,datetime,subprocess,time,os
repo=Path.cwd(); root=Path(tempfile.mkdtemp(prefix='skillpilot-v57-normal-cqr-',dir='/dev/shm')); (root/'npm-cache').mkdir()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,j):p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
old=json.loads((repo/'qa-artifacts/ci-contract-audit/2026-11-07/visualization-fixed54-normal-cqr-producer/metadata/preflight.json').read_text())
status=repo/'docs/qa-ci/status'; shutil.copytree(status,root/'status',copy_function=shutil.copyfile)
chem=repo/old['chemistryReportPath'];shutil.copyfile(chem,root/'chemistry-report.md')
paths=set(old['protectedInputHashes'])|{e['path'] for e in old['codePins']}
a=json.loads((repo/'qa-artifacts/ci-contract-audit/2026-11-07/math3-coherent-active-integration/receipt.json').read_text())
paths|={e['target'] for e in a['changes']}
paths|={'qa-artifacts/ci-contract-audit/2026-11-07/math3-coherent-private-binding-candidate-2026-11-07/atomicity.review.jsonl','qa-artifacts/ci-contract-audit/2026-11-07/math3-coherent-private-binding-candidate-2026-11-07/memory.review.jsonl','contracts/goal-visualization-context/v1/qualified-context-index-math3-2026-11-07.json','app/scripts/collectVisualizationContextMath3Originals.ts','qa-artifacts/ci-contract-audit/2026-11-07/visualization-qualified-context-index-math3-2026-11-07/capsule/capsule.json'}
pins={p:sha(repo/p) for p in sorted(paths)}
outputs={str(p.relative_to(repo)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(status.rglob('*')) if p.is_file()}
args=['bwrap','--ro-bind','/','/','--dev-bind','/dev','/dev','--proc','/proc','--bind','/dev/shm','/dev/shm','--bind',str(root/'status'),str(status),'--bind',str(root/'chemistry-report.md'),str(chem),'--chdir',str(repo/'app'),'--setenv','TMPDIR',str(root),'--setenv','npm_config_cache',str(root/'npm-cache'),'--','npm','run','quality:curriculum-status']
pre={'recordedAtActual':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(repo),'ramRoot':str(root),'protectedInputHashes':pins,'outputsBefore':outputs,'chemistryReportBefore':{'path':old['chemistryReportPath'],'sha256':sha(chem)},'activeMemoryConfigs':old['activeMemoryConfigs'],'command':args,'normalCommandUnchanged':True,'source':pins['curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'],'activeAuthority':pins['app/scripts/lib/qualifiedVisualizationContextAuthority.ts'],'rootFreeBytes':shutil.disk_usage(repo).free,'memoryPrehookSkipped':False}
save(root/'preflight.json',pre); save(repo/'tmp/root-v57-normal-cqr-location-2026-11-07.json',{'ramRoot':str(root),'preflight':str(root/'preflight.json')})
execution={'status':'running','startedAtActual':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':args,'pythonPid':os.getpid()};save(root/'execution.json',execution)
print(json.dumps({'ramRoot':str(root),'status':'starting actual normal producer including memory prehook','protectedInputs':len(pins)}),flush=True)
t=time.monotonic()
with (root/'stdout.log').open('wb') as stdout,(root/'stderr.log').open('wb') as stderr:
 child=subprocess.Popen(args,stdout=stdout,stderr=stderr);execution['childPid']=child.pid;save(root/'execution.json',execution);code=child.wait()
execution.update(status='terminal',exitCode=code,completedAtActual=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-t,stdoutSha256=sha(root/'stdout.log'),stderrSha256=sha(root/'stderr.log'));save(root/'execution.json',execution)
changed=[p for p,h in pins.items() if sha(repo/p)!=h];save(root/'postflight.json',{'allProtectedInputsUnchanged':not changed,'changedProtectedInputs':changed,'rootFreeBytes':shutil.disk_usage(repo).free,'outputChemistrySha256':sha(root/'chemistry-report.md'),'hostChemistryUnchanged':sha(chem)==pre['chemistryReportBefore']['sha256']})
print(json.dumps({'ramRoot':str(root),'execution':execution,'changedProtectedInputs':changed},indent=2),flush=True)
raise SystemExit(code if code else int(bool(changed)))
