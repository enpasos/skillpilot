from pathlib import Path
import os,json,time,hashlib,gzip,datetime,tempfile,subprocess,shutil,re
repo=Path.cwd();root=Path('/dev/shm/skillpilot-v57-normal-cqr-r32re925');out=repo/'qa-artifacts/ci-contract-audit/2026-11-07/math3-fixed57-normal-cqr-producer';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,j):p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
def fileinfo(p):
 b=p.read_bytes();return {'path':str(p.relative_to(repo)),'bytes':len(b),'sha256':sha(b)}
def carrier(name,p):
 b=p.read_bytes();q=out/(name+'.gz');q.write_bytes(gzip.compress(b,compresslevel=9,mtime=0));assert gzip.decompress(q.read_bytes())==b;return fileinfo(q)|{'rawBytes':len(b),'rawSha256':sha(b)}
# This is a dependency on the already confirmed live process, never a restart.
print('Waiting for original normal-producer PID536039 to terminate; no generator restarted.',flush=True)
while Path('/proc/536039').exists():
 try:args=Path('/proc/536039/cmdline').read_bytes()
 except FileNotFoundError:break
 assert b'skillpilot-root-v57-normal-cqr.py' in args,args
 time.sleep(0.5)
e=json.loads((root/'execution.json').read_text());assert e['status']=='terminal' and e['exitCode']==0,e
post=json.loads((root/'postflight.json').read_text());assert post['allProtectedInputsUnchanged'] and post['hostChemistryUnchanged'],post
pre=json.loads((root/'preflight.json').read_text())
for p,h in pre['protectedInputHashes'].items():assert sha((repo/p).read_bytes())==h,p
status=repo/'docs/qa-ci/status';mirror=root/'status'
oldset={str(p.relative_to(status)) for p in status.rglob('*') if p.is_file()};newset={str(p.relative_to(mirror)) for p in mirror.rglob('*') if p.is_file()};assert oldset==newset
allowed={'curriculum-quality-status.json','curriculum-quality-status.md'}|{str(Path(c['reportPath']).relative_to('docs/qa-ci/status')) for c in pre['activeMemoryConfigs'] if c['reportPath'].startswith('docs/qa-ci/status/')}
changes=[]
for rel in sorted(oldset):
 host=status/rel;new=mirror/rel;old=pre['outputsBefore'][str(host.relative_to(repo))];assert sha(host.read_bytes())==old['sha256'],rel
 b=new.read_bytes()
 if sha(b)!=old['sha256']:
  assert rel in allowed,rel;changes.append({'path':str(host.relative_to(repo)),'beforeSha256':old['sha256'],'beforeBytes':old['bytes'],'afterSha256':sha(b),'afterBytes':len(b)})
assert {'docs/qa-ci/status/curriculum-quality-status.json','docs/qa-ci/status/curriculum-quality-status.md'}<={c['path'] for c in changes}
j=json.loads((mirror/'curriculum-quality-status.json').read_text());before=json.loads((status/'curriculum-quality-status.json').read_text());assert j['generatedAt']!=before['generatedAt']
bm={c['landscapeId']:c for c in before['curricula']};assert len(bm)==len(j['curricula'])==21
for c in j['curricula']:
 old=bm[c['landscapeId']];assert c['maturity']==old['maturity'];assert c['goals']==old['goals'];assert c['atomicGoals']==old['atomicGoals']
math=next(c for c in j['curricula'] if c['subject']=='Mathematik');gr=next(r for r in math['rules'] if r['id']=='CQR-001');assert gr['metrics']['findings']==916 and gr['metrics']['transitiveRedundancies']==914
m7owners={f['landscapeId'] for f in json.loads((repo/'app/scripts/config/curriculum-maturity-floor-policy.json').read_text())['floors'] if f['minimumMaturity']=='M7'};assert len(m7owners)==5
v=[{'subject':c['subject'],'metrics':r['metrics']} for c in j['curricula'] if c['landscapeId'] in m7owners for r in c['rules'] if r['id']=='CQR-303'];assert len(v)==5
assert sum(x['metrics']['currentVisualizationQaRecords'] for x in v)==57
assert sum(x['metrics']['expectedGoals'] for x in v)==2483
assert sum(x['metrics']['blockingIssues'] for x in v)==2426
assert all(x['metrics']['requiredChecksPassed']==5 for x in v)
for x in v:
 for k in ['currentDescriptionResolutions','currentPositiveEvidenceProfiles','currentSemanticAtomicityDecisions','currentMemoryReviewDecisions']:assert x['metrics'][k]==x['metrics']['expectedGoals']
assert sha((root/'chemistry-report.md').read_bytes())==pre['chemistryReportBefore']['sha256']
save(out/'generated-output-deltas.json',changes)
# Every replacement has a private inode and a fresh guard; large old reports stay in HEAD0b.
for c in changes:
 p=repo/c['path'];b=(mirror/p.relative_to(status)).read_bytes();assert shutil.disk_usage(repo).free>len(b)+16*1024*1024
 fd,n=tempfile.mkstemp(prefix='.v57-generated-private-',dir=p.parent)
 with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 os.chmod(n,0o644);assert sha(p.read_bytes())==c['beforeSha256'];os.replace(n,p);assert sha(p.read_bytes())==c['afterSha256']
print(json.dumps({'normalProducerExit':0,'generatedAt':j['generatedAt'],'changedOutputs':changes,'V':57,'openV':2426,'mathGraph':916}),flush=True)
logs=[carrier('normal-producer.stdout.log',root/'stdout.log'),carrier('normal-producer.stderr.log',root/'stderr.log')]
for name in ['preflight.json','execution.json','postflight.json']:shutil.copyfile(root/name,out/name)
policy=repo/'app/scripts/config/curriculum-maturity-floor-policy.json';policyh=sha(policy.read_bytes());assert policyh=='35e711cea5d5709093bddd53fc1fca91e30bf3c7bec906ca178ed6d8ff364cd7'
args=['bwrap','--ro-bind','/','/','--dev-bind','/dev','/dev','--proc','/proc','--bind','/dev/shm','/dev/shm','--chdir',str(repo/'app'),'--setenv','TMPDIR',str(root),'--setenv','npm_config_cache',str(root/'npm-cache'),'--','npm','run','check:curriculum-maturity-floors']
floor={'status':'running','startedAtActual':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':args};save(root/'floor-execution.json',floor);t=time.monotonic()
with (root/'floor.stdout.log').open('wb') as stdout,(root/'floor.stderr.log').open('wb') as stderr:
 p=subprocess.Popen(args,stdout=stdout,stderr=stderr);floor['childPid']=p.pid;save(root/'floor-execution.json',floor);code=p.wait()
floor.update(status='terminal',exitCode=code,completedAtActual=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-t);save(root/'floor-execution.json',floor)
body=(root/'floor.stderr.log').read_text();failed=[{'subject':m[0],'landscapeId':m[1],'current':m[2],'floor':m[3]} for m in re.findall(r'^([^\n]+) \[([0-9a-f-]+)\]: current (M[0-7]) is below protected floor (M[0-7])',body,re.M)]
assert code==1 and len(failed)==7,(code,failed,body[-2000:])
for p,h in pre['protectedInputHashes'].items():assert sha((repo/p).read_bytes())==h,p
for c in changes:assert sha((repo/c['path']).read_bytes())==c['afterSha256']
assert sha(policy.read_bytes())==policyh
logs +=[carrier('floor.stdout.log',root/'floor.stdout.log'),carrier('floor.stderr.log',root/'floor.stderr.log')]
shutil.copyfile(root/'floor-execution.json',out/'floor-execution.json')
receipt={'schemaVersion':1,'status':'normal-producer-complete-floor-fails-seven-subjects','recordedAtActual':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer':e,'ordinaryMemoryPrehookReports':len(pre['activeMemoryConfigs']),'normalCommandUnchanged':True,'generatorRuns':1,'standaloneDeepReruns':0,'fullDenominator':2483,'actualVisualizationQualified':57,'actualVisualizationOpen':2426,'deepMetrics':v,'mathGraph':{'findings':916,'G17':914,'G01a':2,'newFindingsFromThreeReviewedRepairs':0},'transfer':changes,'all21MaturitiesAndGoalCountsUnchanged':True,'floor':floor,'failedProtectedSubjects':failed,'floorPolicySha256':policyh,'policyExceptionsOrThresholdsChanged':False,'protectedInputs':len(pre['protectedInputHashes']),'allProtectedInputsUnchangedDuringProducerAndFloor':True,'chemistryGeneratedOutputUnchanged':True,'logCarriers':logs,'independentComponentPassAndWholeM7StillDifferent':True,'remoteAcceptanceClaim':False,'normalRunStorageObservation':'Already running producer continued after a byte-identical durable Git index was restored from mounted E to native .git/index. No generator restart or semantic-input change.'}
q=repo/'docs/dev/ci-graph-repairs/math3-fixed57-normal-cqr-producer-2026-11-07.json';save(q,receipt);print(json.dumps({'receipt':fileinfo(q),'failedProtectedSubjects':failed,'floorExit':code,'normalProducerExit':e['exitCode']},indent=2),flush=True)
