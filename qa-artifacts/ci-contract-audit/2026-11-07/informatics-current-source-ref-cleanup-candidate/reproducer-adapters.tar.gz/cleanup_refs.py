from pathlib import Path
import json,hashlib,collections
W=Path(__file__).parent;R=Path('/home/enpasos/projects/skillpilot');V=Path('/dev/shm/informatics-q2-source-scope-v3-20261107/candidate');A=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-q2-source-scope-independent-review/current-informatics-cleanup-authority'
load=lambda p:json.loads(p.read_text());dump=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
closure=load(A/'all-current-reference-closure.json');inv=load(A/'eight-definition-inventory.json');forbidden={r['oldId'] for r in inv['exactlyEightRows']}|set(inv['additionalRemovalIds']);rows=[]
# Each row names the exact surviving basic obligation and the unproved stronger/different performance.
judgments=[
('Vorgegebene Modelle variieren und erweitern, ohne Festlegung auf Domänenmodelle.', 'Domänenverfeinerung mit Aggregaten/Bounded Contexts verlangt eine bestimmte zusätzliche Modellierungstechnik; das allgemeine Variieren/Erweitern ist damit nicht vollständig und niveaugleich gebunden.'),
('Anwendungsfälle und Auslöser eines Systems anhand gestellter Anforderungen identifizieren und in einem grundlegenden Modell verbinden.', 'Domänenaggregate/Bounded Contexts, UML-Klassenassoziationen/Aggregationen und nebenläufige Service-Sequenzen belegen diese grundlegende Anwendungsfall-/Auslöserleistung nicht vollständig.'),
('Die statische Struktur eines Systems mit Komponenten und Klassen grundlegend modellieren.', 'Das vorhandene Klassenziel verlangt Assoziationen/Aggregationen; Komponentenmodellierung ist darin nicht ausdrücklich enthalten. Domänenaggregate und nebenläufige Service-Sequenzen ersetzen die fehlende Grundzuordnung nicht.'),
('Dynamisches Systemverhalten mit Ereignissen und Aktionen grundlegend analysieren und modellieren.', 'Nebenläufige Service-Sequenzen sind eine spezielle weitergehende Leistung; ein allgemeines Ereignis-/Aktionsmodell ist damit nicht vollständig belegt.'),
('Geeignete grundlegende UML-Anwendungsfall-, Klassen-, Sequenz- und Zustandsdiagramme zur Darstellung des jeweiligen Systems verwenden.', 'Ein Klassendiagrammziel und ein spezielles Nebenläufigkeits-/Service-Sequenzziel liefern weder alle vier UML-Formate noch die geforderte grundlegende Auswahl-/Darstellungsleistung.'),
('Zu realen Automaten zugehörige Automatenmodelle entwerfen.', 'Das vorhandene Grundziel trifft reales Automatenmodellieren, verlangt zusätzlich Simulation. Eine vollständige quellen- und leistungsidentische Zuordnung dieser zusätzlichen Leistung wurde hier nicht bewiesen; keine automatische Vollabdeckung.'),
('Automatentafel und Zustandsdiagramm endlicher Automaten interpretieren und in beide Richtungen übertragen.', 'Das allgemeine Modellieren/Simulieren von Automaten nennt weder die Automatentafel noch die wechselseitige Darstellungsübertragung; diese konkrete Leistung bleibt offen.'),
('Prozesse mit Aktivitäts- oder Zustandsdiagrammen modellieren; die amtliche Alternative erhalten.', 'Klassendiagramme modellieren keine Prozessabläufe. Das vorhandene Automatenziel bildet die zugelassene Aktivitätsdiagramm-Alternative nicht vollständig ab und ist keine nachgewiesene niveaugleiche Ersatzzuordnung.'),
('Zustandsdiagramme beschreiben.', 'Allgemeines Automatenmodellieren/Simulieren benennt die geforderte Diagrammbeschreibung nicht ausdrücklich; eine direkte vollständige Leistungsbindung fehlt.'),
('Automaten analysieren und mithilfe von Zustandsdiagrammen modellieren.', 'Das Grundziel benennt Modellieren/Simulieren, aber die konkrete Analyse- und Diagrammleistung ist nicht vollständig gebunden.'),
('Im Wahlpflichtthema Technische Informatik Roboter analysieren und mithilfe von Zustandsdiagrammen modellieren.', 'Das vorhandene Grundziel ist allgemeines Modellieren/Simulieren; Roboteranalyse und explizite Zustandsdiagramme bleiben unbewiesen. Der Wahlpflichtstatus wird nicht zur allgemeinen Pflicht erweitert.'),
('Die Arbeitsweise deterministischer Automaten erläutern (hier LK).', 'Das allgemeine Modellieren/Simulieren von Automaten belegt die spezifische Erläuterung deterministischer Arbeitsweise nicht vollständig; der LK-Kontext bleibt erhalten.'),
('Deterministische Automaten entwerfen und implementieren (hier LK).', 'Simulation ist kein Nachweis einer eigenständigen Implementierung. Das Grundziel verspricht die konkrete Implementierungsleistung nicht; der LK-Kontext bleibt erhalten.')]
assert len(judgments)==len(closure['sourceDemandsStillToAccountFor'])==13
by_source={};by_review={}
for item,(demand,gap) in zip(closure['sourceDemandsStillToAccountFor'],judgments):
 rel=item['file'];sid=item['sourceGoal']['id'];p=W/'candidate'/rel;d=load(p);sg=d['sourceGoals'][item['index']];assert sg==item['sourceGoal'];original=dict(sg)
 candidates=[x for x in sg['canonicalTargetIds'] if x not in forbidden]
 # No inference from proximity: retain the official passage, expose exact gap, no substitute stronger target.
 sg['canonicalTargetIds']=[]
 sg['mappingGap']={'status':'needsCanonicalGoal','requiredPerformance':demand,'reason':gap,'authorProposal':True,'independentSourceReviewPending':True}
 by_source.setdefault(rel,[]).append(sid)
 # Pipeline M3 cannot continue claiming full content coverage after the active correction.
 step=next(x for x in d['pipelineStatus']['steps'] if x['id']=='MAPPING-3');step['status']='incomplete'
 for c in step['checks']:
  if 'content-covered' in c['id']:c['passed']=False;c['details']='Explizite fachliche Zuordnungslücken bleiben nach aktueller Quellenbereinigung offen; keine vollständige Inhaltsabdeckung.'
 cid='20261107-current-basic-source-gap'
 if not any(c['id']==cid for c in step['checks']):step['checks'].append({'id':cid,'label':'Grundlegende Source-Leistungen vollständig und niveaugleich zugeordnet','passed':False,'details':'Konkrete offene Mappinglücken; Originalpassagen und Kurs-/Wahlkontext bleiben erhalten. Unabhängiges Review steht aus.'})
 dump(p,d)
 # Locate the existing corresponding review by extraction path, no invented second mapping framework.
 review=None
 for fr in closure['filesWithExactReferences']:
  if '/mapping/' not in fr['path'] or not fr['path'].endswith('.review.json'):continue
  rp=W/'candidate'/fr['path'];rd=load(rp)
  if rd.get('sourceExtractionPath')==rel:review=(fr['path'],rp,rd);break
 assert review,rel
 rrel,rp,rd=review;decision=next(x for x in rd['decisions'] if x['sourceGoalId']==sid)
 old_decision=dict(decision);old_mappings=[x for x in rd['mappings'] if x.get('legacyGoalId')==sid]
 rd['mappings']=[x for x in rd['mappings'] if x.get('legacyGoalId')!=sid]
 decision.clear();decision.update({'sourceGoalId':sid,'sourceSpan':sg['sourceSpan'],'decision':'needsCanonicalGoal','canonicalGoalIds':[],'rationale':demand+' '+gap,'reviewStatus':'draft','reviewer':'Codex author proposal','reviewedAt':'2026-11-07'})
 # Recompute factual counters, preserve unrelated decisions; no stale all-covered sentence.
 summ=rd['summary'];mapped=[x for x in rd['decisions'] if x.get('decision')=='mapped'];gaps=[x for x in rd['decisions'] if x.get('decision')=='needsCanonicalGoal']
 for key in ['mappedSourceGoals','acceptedSourceGoals']:
  if key in summ:summ[key]=len(mapped)
 if 'needsCanonicalGoal'in summ:summ['needsCanonicalGoal']=len(gaps)
 if 'reviewedSourceGoals'in summ:summ['reviewedSourceGoals']=len(rd['decisions'])
 if 'exactMappings'in summ:summ['exactMappings']=sum(x.get('matchType',x.get('mappingStrength'))=='exact' for x in mapped)
 if 'partialMappings'in summ:
  if 'acceptedSourceGoals'in summ:summ['partialMappings']=sum(x.get('matchType',x.get('mappingStrength'))=='partial' for x in mapped)
  else:summ['partialMappings']=sum(x.get('matchType')=='partial' for x in rd['mappings'])
 if 'notes'in summ:summ['notes']=f"Aktueller Autorenstand: {len(mapped)} zugeordnete Source-Ziele, {len(gaps)} konkrete offene Canonical-Zuordnungslücken. Frühere Gesamtvollständigkeit ist keine Freigabe des geänderten Stands."
 rd['status']='author-draft-with-explicit-source-gaps'
 dump(rp,rd);by_review.setdefault(rrel,[]).append(sid)
 rows.append({'sourcePath':rel,'sourceGoalId':sid,'sourceGoal':{k:v for k,v in original.items() if k!='canonicalTargetIds'},'requiredPerformance':demand,'fullExistingCandidateGoals':candidates,'notAutomaticallyMapped':True,'remainingGap':gap,'status':'needsCanonicalGoal','oldMappings':old_mappings,'oldDecision':old_decision,'newDecision':decision})
# The3 HE snapshot links encode only authorship, not official demand for old bundles.
he='curricula/DE/Gymnasium/mapping/DE-HE/upper-secondary/hessen_informatics_upper_secondary_to_canonical_informatics.json';p=W/'candidate'/he;d=load(p);withdraw=[x for x in d['mappings'] if x.get('canonicalGoalId') in forbidden];assert len(withdraw)==3;d['mappings']=[x for x in d['mappings'] if x not in withdraw]
# Existing historicalWithdrawn* records remain audit. Retire stale current draft fields referencing deleted IDs to the private audit payload.
removed_draft=[]
for fr in closure['filesWithExactReferences']:
 p=W/'candidate'/fr['path'];x=load(p)
 if 'repairDraft'in x:
  for k,val in list(x['repairDraft'].items()):
   if isinstance(val,str) and val in forbidden:removed_draft.append({'path':fr['path'],'field':k,'value':val});del x['repairDraft'][k]
  dump(p,x)
dump(W/'candidate'/he,d)
# Full matched candidate texts are in the audit evidence, not active mapping/projection links.
source=load(W/'candidate/curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json');gm={g['id']:g for g in source['goals']}
for row in rows:row['fullExistingCandidateGoals']=[gm[x] for x in row['fullExistingCandidateGoals']]
dump(W/'source-demand-dispositions.json',{'kind':'13 exact basic-source obligations; author source-gap proposal, no false full-coverage claims','rows':rows,'heSnapshotMappingsRemoved':withdraw,'retiredDraftReferences':removed_draft,'sourcePassagesPreserved':True,'newCanonicalGoalsInvented':False,'newWhole875Replacement':False})
print(json.dumps({'sourceDemands':len(rows),'sourceFiles':len(by_source),'reviewFiles':len(by_review),'heLinksRemoved':len(withdraw)}))
