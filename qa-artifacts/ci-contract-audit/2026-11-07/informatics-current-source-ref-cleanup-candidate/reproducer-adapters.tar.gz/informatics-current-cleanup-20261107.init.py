from pathlib import Path
import json,hashlib,gzip,os,shutil
R=Path('/home/enpasos/projects/skillpilot');V=Path('/dev/shm/informatics-q2-source-scope-v3-20261107/candidate');W=Path('/dev/shm/informatics-current-cleanup-20261107');A=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-q2-source-scope-independent-review/current-informatics-cleanup-authority'
W.mkdir(exist_ok=True);(W/'candidate').mkdir(exist_ok=True);(W/'pins').mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
inv=json.loads((A/'eight-definition-inventory.json').read_text()); rows=inv['exactlyEightRows'];rename={r['oldId']:r['proposedNewId'] for r in rows if r.get('proposedNewId')};removed={r['oldId'] for r in rows if not r.get('proposedNewId')}|set(inv['additionalRemovalIds']);forbidden=removed|set(rename)
source='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json';assert h((R/source).read_bytes())=='85411185514af4b2ecf818807f3bd6fe5df17fb5011c5ebf8c4996de1a47817e';assert h((V/source).read_bytes())=='c824e0b360470ef67ae4deb560146c7e677ad9601446b26cd5a46097c426e53b'
changes=json.loads(Path('/dev/shm/informatics-q2-source-scope-v3-20261107/candidate-file-changes.json').read_text())['files']
for row in changes:
 rel=row['path']
 if not rel.startswith('curricula/'):continue
 out=W/'candidate'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((V/rel).read_bytes())
# The remaining canonical catalog frame is current. Never reuse V3's old PoWi source.
for p in sorted((R/'curricula/DE/Gymnasium/canonical').glob('*.de.json')):
 out=W/'candidate'/p.relative_to(R);out.parent.mkdir(parents=True,exist_ok=True)
 if not out.exists():out.write_bytes(p.read_bytes())
# Capture19 authored views, including unchanged SekI.
for p in sorted((V/'curricula/DE/Gymnasium/composition-views/informatik').glob('*.view.json')):
 out=W/'candidate'/p.relative_to(V);out.parent.mkdir(parents=True,exist_ok=True)
 if not out.exists():out.write_bytes(p.read_bytes())
closure=json.loads((A/'all-current-reference-closure.json').read_text())
for row in closure['filesWithExactReferences']:
 rel=row['path'];out=W/'candidate'/rel
 if not out.exists():out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((R/rel).read_bytes())
# Freeze current native source code; only private snapshots, no code changes.
code=[]
for root in ['app/scripts','app/src','backend/src/main/java']:
 for p in (R/root).rglob('*'):
  if p.is_file() and p.suffix in ['.ts','.mts','.tsx','.java','.json']:
   rel=p.relative_to(R);q=W/'native-code'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());code.append({'path':str(rel),'sha256':h(p.read_bytes())})
(W/'pins/code-frame.json').write_text(json.dumps({'files':code},indent=2)+'\n')
# Capture actual21 current source bytes for reliable postguards and graph comparison.
catalog=[]
for p in sorted((R/'curricula/DE/Gymnasium/canonical').glob('*.de.json')):catalog.append({'path':str(p.relative_to(R)),'activeSha256':h(p.read_bytes()),'effectiveSha256':h((W/'candidate'/p.relative_to(R)).read_bytes())})
assert len(catalog)==21
(W/'pins/catalog-before.json').write_text(json.dumps({'files':catalog},indent=2)+'\n')
# Goal definitions: remove unsupported3 +875 +emptied practice; five identities are genuinely new.
s=json.loads((W/'candidate'/source).read_text());s['goals']=[g for g in s['goals'] if g['id'] not in removed]
for g in s['goals']:
 g['id']=rename.get(g['id'],g['id'])
 for field in ['contains','requires']:
  if field in g:g[field]=[rename.get(x,x) for x in g[field] if x not in removed]
 if g.get('examData',{}).get('coveredGoalIds') is not None:
  assert not set(g['examData']['coveredGoalIds'])&removed
  g['examData']['coveredGoalIds']=[rename.get(x,x) for x in g['examData']['coveredGoalIds']]
assert len(s['goals'])==283
(W/'candidate'/source).write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
(W/'pins/disposition.json').write_text(json.dumps({'authority':str(A.relative_to(R)),'authoritySha256':h((A/'README.md').read_bytes()),'sourceBasisSha256':h((V/source).read_bytes()),'removedCurrentDefinitions':sorted(removed),'prospectiveNewIdentities':rename,'newIdsAreAliases':False,'resultTransfer':False,'dbDeletion':False,'notes':'No material integration: five definitions retain their invalid generic material for truthful native failure; all ordinary atom IDs/texts preserved.'},indent=2)+'\n')
print(json.dumps({'work':str(W),'sourceSha256':h((W/'candidate'/source).read_bytes()),'currentCatalogs':len(catalog),'codeFiles':len(code),'defs':len(s['goals']),'examCount':sum('examData' in g for g in s['goals'])}))
