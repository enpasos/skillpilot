from pathlib import Path
import json,gzip,hashlib,collections
W=Path(__file__).parent;R=Path('/home/enpasos/projects/skillpilot');A=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-q2-source-scope-independent-review/current-informatics-cleanup-authority';I=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-five-placeholder-exam-contract-inventory'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());gz=lambda p,d:p.write_bytes(gzip.compress((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));sourceRel='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json'
def effective(rel):
 p=W/'candidate'/rel
 return p if p.exists() else R/rel
info=load(effective(sourceRel));goals={g['id']:g for g in info['goals']};inv=load(W/'pins/disposition.json');rename=inv['prospectiveNewIdentities'];old=set(inv['removedCurrentDefinitions'])|set(rename);plans=json.load(gzip.open(I/'contracts-and-material-plans.json.gz','rt'));primary=load(I/'source-passages.json');native=json.load(gzip.open(W/'native-graph-scope.json.gz','rt'));runtime=json.load(gzip.open(W/'current-cleanup-global.runtime.json.gz','rt'))['nativeAuthoredGlobalCases'];complete=[r for r in runtime if 'targetIds'in r]
# Exact existing primary-source extraction rows for every fixed goal. These are supporting records, not a new substantive approval.
primary_by_atom=collections.defaultdict(list);inputpins=[]
for p in sorted((R/'curricula/DE/Gymnasium/input').rglob('*.source-extraction.json')):
 rel=str(p.relative_to(R));ep=effective(rel);d=load(ep)
 if d.get('subject')!='Informatik':continue
 inputpins.append({'path':rel,'sha256':h(ep),'activeSha256':h(p)})
 for sg in d.get('sourceGoals',[]):
  for atom in sg.get('canonicalTargetIds',[]):
   if atom in goals:primary_by_atom[atom].append({'sourcePath':rel,'sourceDocument':d.get('sourceDocument'),'sourceGoalId':sg['id'],'sourceSpan':sg.get('sourceSpan'),'sourceText':sg.get('sourceText'),'parentBulletText':sg.get('parentBulletText'),'sourceRef':sg.get('sourceRef'),'courseLevel':sg.get('courseLevel'),'stage':sg.get('stage'),'granularity':sg.get('granularity'),'evidenceStatus':'existing exact source-extraction association; not independent proof of whole canonical performance/compulsory scope'})
rows=[];total=0
for plan in plans['rows']:
 oldid=plan['uuid'];newid=rename[oldid];atoms=plan['competenceScope']['nativeV3AtomicIds'];assert len(atoms)==plan['competenceScope']['historicalDeclaredAtomicCount'];total+=len(atoms)
 allocations=plan['repairPlan']['editorialAtomAllocation'];atomrows=[]
 for atom in atoms:
  g=goals[atom];oldg=next(x for x in plan['competenceScope']['allFullAtomicDefinitions'] if x['id']==atom);assert g['title']==oldg['title'] and g['description']==oldg['description']
  groups=[x['materialWorkPackage'] for x in allocations if atom in x['atomicGoalIds']];assert groups,atom
  contexts=[{'jurisdiction':r['requestedJurisdiction'],'profile':r['requestedProfile'],'viewIds':r['viewIds'],'routeIsTarget':newid in r['targetIds']} for r in complete if atom in r['targetIds']]
  views=[v['viewId'] for v in native['views'] if atom in v['targetGoalIds']]
  atomrows.append({'goalId':atom,'fullUnchangedGoal':g,'authorityOrNamedDidacticGap':{'primaryAssociations':primary_by_atom[atom],'primaryFullPerformanceApprovedHere':False,'namedNecessaryDidacticGap':f"Für das bestehende gewöhnliche Ziel ‚{g['title']}‘ fehlt im generischen Phasenabschluss eine konkrete materialgestützte Leistungsaufgabe mit prüfbarer Lösung und Bestehensmerkmal. Die vollständige zu belegende Leistung lautet: {g['description']}",'scopeLimit':'Eine bestehende Zuordnung ist kein neuer Vollbeleg für eine Landespflicht. Wahl-/Niveau-/Themenfeldgrenzen und fehlende Belege bleiben offen; keine automatische fachliche Kürzung.'},'actuallyObservedTargetScope':{'nativeAuthoredViews':views,'nativeOfferedGlobalContexts':contexts,'approvedAsUniversalStateDuty':False,'perScopeWholeRouteAuthority':'UNRESOLVED: this atom is retained in finite inventory, not made compulsory outside an independently supported target context.'},'currentAssessmentRoute':{'prospectiveGoalId':newid,'phase':plan['phase'],'materialWorkPackages':groups,'status':'planned complete route; current generic material remains invalid','alternateCurrentApprovedRouteAssigned':False,'requiredRouteRemoved':False},'materialSpecification':{'necessaryObservablePerformance':g['description'],'taskMustAskForThisCompletePerformance':True,'completeInputRequirement':'Die unten angegebenen vollständigen Materialpakete müssen konkrete, eindeutig auswertbare Eingaben für genau diese Leistung enthalten; bloße Titel, Taskbankhints und vorausgesetzte nicht mitgelieferte Materialien zählen nicht.','materialWorkPackages':groups,'modelAnswerRequirement':'Datengestützte richtige Musterlösung mit allen im unveränderten Ziel verlangten Verben/Objekten; Verfahren, Ergebnis und notwendige Begründung explizit dem Teilauftrag zuordnen.','necessaryPassCriterionRequirement':'Das fachlich unverzichtbare Merkmal für genau diese Leistung ist vor Vergabe des neuen Ergebnisses festzulegen und unabhängig zu prüfen. Andere Aufgabenpunkte dürfen sein Fehlen nicht kompensieren. Keine neue Rechtschreib-/Nebenkriteriumspflicht.','counterexampleRequirement':'Mindestens eine konkrete fachlich falsche oder unvollständige Antwort, die gerade die notwendige Leistung verfehlt, und eine fachlich richtige Antwort mit nebensächlichem Schreibfehler. Die erste darf nicht bestehen, die zweite darf deswegen nicht scheitern.','currentExecutableTaskAuthored':False,'currentInputsAndCorrectSolutionAuthored':False,'independentMaterialReviewApproved':False}})
 # Existing author allocations enumerate concrete domain bundles and full atom texts. Preserve them as specifications, not dummy actual tasks.
 rows.append({'phase':plan['phase'],'prospectiveNewGoalId':newid,'newIdentityIsAlias':False,'resultTransfer':False,'inventoryAtomCount':len(atoms),'currentCoverageExactlyPreservedForPlanning':atoms,'fullRouteGoal':goals[newid],'needDecision':{'status':'finite ordinary-target inventory and named assessment gaps; final per-scope offer/material authority remains open','ownAuthoredPromise':plan['sourceContract']['exactOwnGoalPromise'],'primaryPartialAnchor':plan['sourceContract']['primaryPartialAnchor'],'statutoryWholeOfferingProved':False,'wholeOriginalInventoryPreserved':True,'silentTargetOrRouteReduction':False,'materialIntegrationAuthorizedByThisSpecification':False,'reasonNoBlanketCut':'No independently justified ordinary target reduction has been demonstrated. Keep all fixed atom obligations visible while classifying the exact lawful state/own scope; do not fabricate a compulsory union.'},'fourColumnAtomInventory':atomrows,'completeRequiredMaterialBundles':plan['repairPlan']['requiredFullMaterialBundles'],'fullMaterialPackageAtomAllocation':allocations,'passingMeaning':{'status':'UNRESOLVED; current20/12 threshold is not carried into the new result contract','necessaryAtomicPerformanceGuarantee':'Ein Bestehen darf nur die im finalen belegten aktuellen Scope zugesagten vollständigen Leistungen anerkennen. Vollständige Aufgaben, Musterlösungen und notwendige fachliche Kriterien sind atomweise zu binden; ein Gesamtpunktwert allein reicht nicht.','newScoreThresholdInvented':False,'oldResultsUpgraded':False},'scopeBoundary':plan['sourceContract']['primaryPartialAnchor']['limit'],'actualRouteTargetContexts':[{'jurisdiction':r['requestedJurisdiction'],'profile':r['requestedProfile'],'viewIds':r['viewIds']} for r in complete if newid in r['targetIds']],'currentMaterialGap':plan['actualMaterialGap']})
assert total==166
# Required full scope classification cannot be claimed from mapping associations alone.
spec={'kind':'Five new prospective current routes: complete finite166-atom need/material specification; NOT implemented material and NOT source/material approval','sourceSha256':h(effective(sourceRel)),'contractAuthority':str(A.relative_to(R)),'materialPlanInputSha256':h(I/'contracts-and-material-plans.json.gz'),'primaryDocument':primary['primaryDocument'],'primarySelectionRule':primary.get('generalSelectionRule'),'sourceEvidencePins':inputpins,'fourColumnRows':rows,'totalAtomObligations':total,'remainingHolds':['Final source-/scope-specific route coverage is not independently approved; existing broad canonical/default fallbacks cannot establish state duty.','Complete executable material, correct model answers, necessary pass features and countercases not authored for these5.','No result compatibility, aliases, historical runtime, DB deletion or deployment.','The own20 exam is independent; do not promote it to a universal replacement for deleted41.','All22 current definitions remain in native assessment checking; no draft/offer exception.']}
gz(W/'five-new-route-need-material-specifications.json.gz',spec)
# Same current reference domains as the authority, plus canonical sources. Keep explicitly historical withdrawn author/audit evidence distinguishable.
paths=set()
for relroot in ['curricula/DE/Gymnasium/canonical','curricula/DE/Gymnasium/mapping','curricula/DE/Gymnasium/provenance','curricula/DE/Gymnasium/composition-views']:
 paths.update(str(p.relative_to(R)) for p in (R/relroot).rglob('*.json'))
paths.update(str(p.relative_to(R)) for p in (R/'curricula/DE/Gymnasium/input').rglob('*.source-extraction.json'))
activehits=[];audithits=[];pins=[]
def scan(x,ptr,rel,historical=False):
 if isinstance(x,str):
  for ident in old:
   if x==ident or x.endswith(':'+ident):(audithits if historical else activehits).append({'path':rel,'pointer':ptr,'id':ident})
 elif isinstance(x,list):
  for i,v in enumerate(x):scan(v,ptr+'/'+str(i),rel,historical)
 elif isinstance(x,dict):
  for k,v in x.items():
   hist=historical or k in ['historicalWithdrawnMappings','historicalWithdrawnDecisions'] or ptr=='/repairDraft' and k=='withdrawnPrimaryClaim'
   scan(v,ptr+'/'+k,rel,hist)
for rel in sorted(paths):
 ep=effective(rel);pins.append({'path':rel,'sha256':h(ep),'activeSha256':h(R/rel)});scan(load(ep),'',rel)
assert not activehits,activehits
# No atom was removed from any of19 final native view targets, no undeclared coverage manufactured.
assert all(v['ordinaryTargetsExactlyEqual'] for v in native['views'])
assert native['examCounts']=={'current':22,'declared':12,'unknown':10}
gz(W/'current-reference-closure.json.gz',{'inspectedFiles':len(paths),'effectiveFilePins':pins,'activeOldIdentityReferences':activehits,'explicitHistoricalAuditReferences':audithits,'unknownContractsKeptUnknown':10,'ordinaryTargetSetsPreservedInAll19Views':True,'sourceGapRecords':13,'sourcePassagesPreserved':True,'limits':'Code identity-history pins/testfixtures are separate audit. One stale production QA practice-cluster reference is reported in current-scope-ref-followup; no second engine.'})
print(json.dumps({'fiveRoutes':len(rows),'atoms':total,'primaryExtractions':len(inputpins),'referenceFiles':len(paths),'activeOldRefs':len(activehits),'historicalAuditRefs':len(audithits)}))
