from pathlib import Path
import json,subprocess,time,os,hashlib,gzip
W=Path(__file__).parent;R=Path('/home/enpasos/projects/skillpilot');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=['bwrap','--die-with-parent','--unshare-net','--ro-bind','/','/','--proc','/proc','--dev','/dev','--tmpfs','/tmp','--ro-bind','/dev/shm','/dev/shm','--bind',str(W),str(W)]
# Every changed source/reference and all21 canonical inputs are read-only overlayed at their real paths.
for p in sorted((W/'candidate').rglob('*')):
 if p.is_file():base+=['--ro-bind',str(p),str(R/p.relative_to(W/'candidate'))]
base+=['--ro-bind',str(W/'native-code/app/scripts'),str(R/'app/scripts'),'--ro-bind',str(W/'native-code/app/src'),str(R/'app/src'),'--ro-bind',str(W/'native-code/contracts/curriculum-assessment-coverage'),str(R/'contracts/curriculum-assessment-coverage')]
base+=['--ro-bind','/tmp/skillpilot-plan-gradle-20261022','/tmp/skillpilot-plan-gradle-20261022']
base+=['--setenv','TSX_DISABLE_CACHE','1','--setenv','TMPDIR','/tmp','--chdir',str(R),'--']
commands=[('graph-scope',base+[str(R/'app/node_modules/.bin/tsx'),str(W/'native_graph_scope.mts')]),('backend-global',base+[str(R/'tmp/amazon-corretto-25.0.2.10.1/bin/java'),'-Xmx768m','-cp',(W/'backend-classpath.txt').read_text(),'CurrentInfoCleanupGlobalScopeProbe',str(R),str(W),'current-cleanup-global'])]
previous=json.loads((W/'combined-native.execution.json').read_text())['commands'];receipts=[r for r in previous if r['label']=='graph-scope' and r['exitCode']==0]
for label,cmd in commands:
 if label=='graph-scope' and receipts:continue
 start=time.time()
 with (W/(label+'.stdout')).open('w') as out,(W/(label+'.stderr')).open('w') as err:
  proc=subprocess.Popen(cmd,stdout=out,stderr=err);(W/(label+'.running.json')).write_text(json.dumps({'pid':proc.pid,'started':start}));rc=proc.wait()
 receipt={'label':label,'command':cmd,'started':start,'finished':time.time(),'exitCode':rc};receipts.append(receipt)
 (W/'combined-native.execution.json').write_text(json.dumps({'commands':receipts},indent=2)+'\n');print(label,rc,flush=True)
 if rc:print((W/(label+'.stderr')).read_text()[-5000:],flush=True);raise SystemExit(rc)
# Retain big raw output only compressed; stdout is not copied to durable package.
p=W/'current-cleanup-global.runtime.json';(W/'current-cleanup-global.runtime.json.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()
print('combined native terminal0',flush=True)
