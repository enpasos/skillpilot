import {readFileSync,readdirSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {gzipSync} from 'node:zlib';
import {captureCurriculumSource} from '/home/enpasos/projects/skillpilot/app/scripts/lib/retainedAssessmentCoverage.ts';
import {discoverCurriculumAssessmentScope,evaluateCurriculumExamReadiness} from '/home/enpasos/projects/skillpilot/app/scripts/generateCurriculumQualityStatus.ts';
const R='/home/enpasos/projects/skillpilot',W='/dev/shm/informatics-current-cleanup-20261107';
const catalog=readdirSync(R+'/curricula/DE/Gymnasium/canonical').filter(x=>x.endsWith('.de.json')).sort().map(x=>{const p='curricula/DE/Gymnasium/canonical/'+x;return captureCurriculumSource<any>(p,readFileSync(R+'/'+p));});
const info=catalog.find(x=>x.landscapeId==='7d51b38c-a149-5407-bddc-d2ce7878b020');
const discovery=discoverCurriculumAssessmentScope(info,undefined,catalog),readiness=evaluateCurriculumExamReadiness(info,undefined,catalog);
assert.equal(discovery.definitionGoalIds.length,22);assert.equal(discovery.requiredGoalIds.length,22);assert.deepEqual(discovery.discoveryIssues,[]);
for(const check of readiness){assert.equal(check.assessmentValidation.checkedGoalIds.length,22);assert.equal(check.status,'fail');assert(check.assessmentValidation.failingGoalIds.includes('309d4587-8080-5dd4-b329-785d9996a195'));}
writeFileSync(W+'/native-scope-ref-followup.json.gz',gzipSync(JSON.stringify({kind:'Focused native readout after exactly one deleted-cluster configuration reference was removed; no repeated graph/global flow and no Full-CQR',discovery,readiness},null,2)+'\n'));
console.log(JSON.stringify({currentDefinitions:discovery.definitionGoalIds.length,required:discovery.requiredGoalIds.length,discoveryIssues:discovery.discoveryIssues,checks:readiness.map(c=>({id:c.id,status:c.status,metrics:c.metrics}))}));
