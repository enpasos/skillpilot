from pathlib import Path
import json,hashlib,subprocess,shutil
W=Path(__file__).parent;R=Path('/home/enpasos/projects/skillpilot');V=W.parent/'informatics-q2-source-scope-v3-20261107'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
guards=json.loads((V/'backend-reuse-current-guards.json').read_text());changes=[]
for row in guards['checks']:
 p=W/'native-code'/row['path'];assert p.exists()
 if h(p)!=row['sourceSha256']:changes.append(row['path'])
assert set(changes)=={'backend/src/main/java/com/skillpilot/backend/service/LearnerService.java','backend/src/main/java/com/skillpilot/backend/ui/LearnerUiController.java'}
basecp=(V/'backend-classpath.txt').read_text();classes=W/'backend-classes';classes.mkdir(exist_ok=True)
java=R/'tmp/amazon-corretto-25.0.2.10.1/bin';cmd=[str(java/'javac'),'-cp',basecp,'-d',str(classes),*[str(W/'native-code'/rel) for rel in changes]]
p=subprocess.run(cmd,capture_output=True,text=True);(W/'compile-current.stdout').write_text(p.stdout);(W/'compile-current.stderr').write_text(p.stderr);assert p.returncode==0,p.stderr
s=(V/'V3AuthoredGlobalScopeProbe.java').read_text().replace('class V3AuthoredGlobalScopeProbe','class CurrentInfoCleanupGlobalScopeProbe')
a='for(JsonNode historical:om.readTree(dir.resolve("old-24-raw-definitions.json").toFile()).path("exams")){inputMastery.put(historical.path("goal").path("id").asText(),1.0);}inputMastery.put("875cb53c-b48d-5b2b-8cb0-e20f27534f16",1.0);'
assert s.count(a)==1;s=s.replace(a,'')
s=s.replace('row.put("newOwnExamMasteryUnset",!inputMastery.containsKey("6ebc2a67-ea20-5c4e-8a63-635f40438d6a"));','row.put("newOwnExamMasteryUnset",!inputMastery.containsKey("6ebc2a67-ea20-5c4e-8a63-635f40438d6a"));row.put("allNewAssessmentResultsUnset",List.of("309d4587-8080-5dd4-b329-785d9996a195","fa47a714-07c3-589b-a4e2-385a33e84c79","7aec2086-2cfa-50d3-8503-b40e96ca3430","3277867f-ede2-5dc4-bd76-1b03d992e9d5","357fde7c-d334-50aa-be11-068ae8d832b3").stream().noneMatch(inputMastery::containsKey));')
p=W/'CurrentInfoCleanupGlobalScopeProbe.java';p.write_text(s);cp=str(classes)+':'+basecp;cmd=[str(java/'javac'),'-cp',cp,'-d',str(classes),str(p)];p2=subprocess.run(cmd,capture_output=True,text=True);(W/'compile-probe.stdout').write_text(p2.stdout);(W/'compile-probe.stderr').write_text(p2.stderr);assert p2.returncode==0,p2.stderr
(W/'backend-classpath.txt').write_text(cp)
(W/'pins/backend-frame.json').write_text(json.dumps({'all484SourceInputsChecked':True,'reusedIdenticalSourceClasses':482,'currentRecompiledSources':changes,'currentCompiledClassFiles':[{'path':str(p.relative_to(W)),'sha256':h(p)} for p in sorted(classes.rglob('*.class'))],'priorClassInputGuardSha256':h(V/'backend-reuse-current-guards.json'),'nativeHarnessSha256':h(W/'CurrentInfoCleanupGlobalScopeProbe.java'),'sourceSnapshotCodePins':'code-frame.json'},indent=2)+'\n')
# Current contracts only; do not install the V3 retained/prospective overlay.
shutil.copytree(R/'contracts/curriculum-assessment-coverage',W/'native-code/contracts/curriculum-assessment-coverage',dirs_exist_ok=True)
print(json.dumps({'nativeCurrentRecompiled':changes,'harness':'CurrentInfoCleanupGlobalScopeProbe','status':'ready; no run yet'}))
