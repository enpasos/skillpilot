from pathlib import Path
import json,gzip,hashlib,tarfile,io,difflib,shutil,time,collections
W=Path(__file__).parent;R=Path('/home/enpasos/projects/skillpilot');V=W.parent/'informatics-q2-source-scope-v3-20261107/candidate';out=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-current-source-ref-cleanup-candidate';out.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());gz=lambda p,d:p.write_bytes(gzip.compress((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));source='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json'
# Detect any unrelated live change, rather than silently rebinding it to this completed run.
cpins=load(W/'pins/catalog-before.json')['files'];cd=[r['path'] for r in cpins if h(R/r['path'])!=r['activeSha256']];assert not cd,cd
codepins=load(W/'pins/code-frame.json')['files'];codedrift=[r['path']for r in codepins if h(R/r['path'])!=r['sha256']]
# Snapshot remains explicit if another authorized worker made later code changes.
changed=[]
for p in sorted((W/'candidate').rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(W/'candidate'));before=R/rel
 if before.exists() and h(before)==h(p):continue
 changed.append({'path':rel,'beforeSha256':h(before)if before.exists()else None,'afterSha256':h(p),'bytes':p.stat().st_size})
assert len(changed)==37,len(changed)
# Store only37 changed files, never copies of all current curricula/code/official primary assets.
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT)as tar:
 for row in changed:
  p=W/'candidate'/row['path'];data=p.read_bytes();ti=tarfile.TarInfo(row['path']);ti.size=len(data);ti.mode=0o644;ti.mtime=0;ti.uid=0;ti.gid=0;ti.uname='';ti.gname='';tar.addfile(ti,io.BytesIO(data))
(out/'candidate-overlay.tar.gz').write_bytes(gzip.compress(buf.getvalue(),mtime=0))
# Full semantic source changes, using stable goal IDs rather than array-index churn.
def goal_diff(before,after):
 bm={g['id']:g for g in before['goals']};am={g['id']:g for g in after['goals']};rows=[]
 for gid in sorted(set(bm)|set(am)):
  b=bm.get(gid);a=am.get(gid)
  if b==a:continue
  if b is None:rows.append({'goalId':gid,'change':'added','after':a})
  elif a is None:rows.append({'goalId':gid,'change':'removed','before':b})
  else:rows.append({'goalId':gid,'change':'field-edits','fields':{k:{'before':b.get(k),'after':a.get(k)} for k in sorted(set(b)|set(a))if b.get(k)!=a.get(k)}})
 return rows
b=load(R/source);v=load(V/source);a=load(W/'candidate'/source)
gz(out/'full-source-changes.json.gz',{'active854ToCandidate':goal_diff(b,a),'reviewedV3ToCandidate':goal_diff(v,a),'changedFileInventory':changed,'oneLineCurrentScopeReferenceCorrection':load(W/'pins/current-scope-ref-followup.json')})
# Keep author draft decisions and all exact raw successful native outputs. No M6/M7 claim.
for name in ['five-new-route-need-material-specifications.json.gz','current-reference-closure.json.gz','native-graph-scope.json.gz','native-scope-ref-followup.json.gz','current-cleanup-global.runtime.json.gz']:
 shutil.copyfile(W/name,out/name)
gz(out/'source-demand-dispositions.json.gz',load(W/'source-demand-dispositions.json'))
shutil.copyfile(W/'current-scope-ref-followup.patch',out/'current-scope-ref-followup.patch')
gz(out/'input-frame-and-postguards.json.gz',{'current21CanonicalInputs':cpins,'catalogPostguardDrift':cd,'currentNativeCodeInputFiles':codepins,'currentCodePostguardDrift':codedrift,'exactPrivateOneLineConfigDelta':load(W/'pins/current-scope-ref-followup.json'),'backend':load(W/'pins/backend-frame.json'),'authority':load(W/'pins/disposition.json'),'nativeGraphHarnessSha256':h(W/'native_graph_scope.mts'),'nativeGlobalHarnessSha256':h(W/'CurrentInfoCleanupGlobalScopeProbe.java'),'focusedScopeHarnessSha256':h(W/'native_scope_ref_followup.mts')})
gz(out/'native-execution-receipts.json.gz',{'combinedNative':load(W/'combined-native.execution.json'),'focusedConfigRefFollowup':load(W/'scope-ref-followup.execution.json'),'initialAdapterMountFailure':load(W/'bootstrap-mount-correction.json'),'initialAdapterClasspathFailure':load(W/'bootstrap-classpath-correction.json'),'initialFailedMountReceipt':load(W/'bootstrap-mount-failure.combined-native.execution.json'),'initialFailedClasspathReceipt':load(W/'bootstrap-classpath-failure.combined-native.execution.json'),'initialFailureOutputs':{'mount':(W/'bootstrap-mount-failure.graph-scope.stderr').read_text(),'classpath':(W/'bootstrap-classpath-failure.backend-global.stderr').read_text()},'finalSuccessfulStdout':{'graph':(W/'graph-scope.stdout').read_text(),'scopeRef':(W/'scope-ref-followup.stdout').read_text()},'successfulStderr':{'graph':(W/'graph-scope.stderr').read_text(),'backend':(W/'backend-global.stderr').read_text(),'scopeRef':(W/'scope-ref-followup.stderr').read_text()}})
# Reproducers are tiny adapters calling the existing native engines. Capture exact scripts without duplicating engine sources.
repro=io.BytesIO()
with tarfile.open(fileobj=repro,mode='w',format=tarfile.PAX_FORMAT)as tar:
 scripts=[W.parent/'informatics-current-cleanup-20261107.init.py',*[W/x for x in ['cleanup_refs.py','prepare_native.py','native_graph_scope.mts','run_combined_native.py','CurrentInfoCleanupGlobalScopeProbe.java','native_scope_ref_followup.mts','build_specs_and_closure.py','package_cleanup.py']]]
 for p in scripts:
  data=p.read_bytes();ti=tarfile.TarInfo(p.name);ti.size=len(data);ti.mode=0o644;ti.mtime=0;tar.addfile(ti,io.BytesIO(data))
(out/'reproducer-adapters.tar.gz').write_bytes(gzip.compress(repro.getvalue(),mtime=0))
ng=json.load(gzip.open(W/'native-graph-scope.json.gz','rt'));ns=json.load(gzip.open(W/'native-scope-ref-followup.json.gz','rt'));rt=json.load(gzip.open(W/'current-cleanup-global.runtime.json.gz','rt'));old=set(load(W/'pins/disposition.json')['removedCurrentDefinitions'])|set(load(W/'pins/disposition.json')['prospectiveNewIdentities']);currentrows=rt['nativeAuthoredGlobalCases'];successful=[r for r in currentrows if 'targetIds'in r]
assert all(not set(r['targetIds'])&old for r in successful)
result={'status':'PRIVATE_CURRENT_SOURCE_REF_CLEANUP_AND_FINITE_MATERIAL_SPECIFICATION; NOT APPROVED FOR INTEGRATION','sourceBasisSha256':h(V/source),'activeSourceUnchangedSha256':h(R/source),'candidateSourceSha256':h(W/'candidate'/source),'changedFiles':len(changed),'sourceDefinitions':283,'currentExams':{'total':22,'declared':12,'unknown':10},'nativeViews':{'compiled':19,'compileErrors':0,'ordinaryTargetsExactlyPreservedAgainstV3':True},'nativeGraph':ng['graph']['checks'],'nativeOfferedGlobalScopes':{'complete':len(successful),'selection':len(currentrows)-len(successful),'completeTargetsNonempty':all(r['targetIds']for r in successful),'oldIdsInCompleteTargets':0,'newResultIdsUnset':all(r['allNewAssessmentResultsUnset']for r in currentrows),'syntheticMasteryUnchanged':all(r['masteryUnchanged']for r in currentrows),'repositoryCalls':rt['repositoryCalls']},'currentAssessmentDiscovery':{'definitions':len(ns['discovery']['definitionGoalIds']),'required':len(ns['discovery']['requiredGoalIds']),'issues':ns['discovery']['discoveryIssues']},'nativeReadinessChecks':[{'id':x['id'],'status':x['status'],'metrics':x['metrics']}for x in ns['readiness']],'materialSpecifications':{'prospectiveNewIds':load(W/'pins/disposition.json')['prospectiveNewIdentities'],'atomObligations':166,'scopeFullyIndependentlyQualified':False,'materialsAuthored':False,'materialPassClaim':False},'activeReferenceClosure':{'files':1206,'oldActiveSourceMappingReferences':0,'explicitHistoricalAuditReferencesKept':5,'sourceDemandGapsExplicit':13,'sourcePassagesLost':0,'oneDeletedClusterQaConfigReferenceCorrected':True},'ordinaryPreparationAndCoverageOfAll22UnchangedAgainstV3':True,'activeWrites':False,'dbChanges':False,'resultImportAliasesHistoryRuntime':False,'gitWriteOrDeploy':False,'fullCqrRun':False,'remainingHolds':['All5 complete material implementations/solutions/pass criteria/countercases and independent final scope/source/material review remain.','CQR204 current identity-history transition needs the expressly authorized exact one-time Source/Context/Manifest binding. Current checks remain red.','Own20 cb82 requires a new exact frame-bound first-definition review; not a general replacement for deleted41.','HE cohort, BYmodel, SH DB4 and4 DB-task missing-input holds remain.','G17 retains27 findings. Final50-scope CQR/Maturity/Floor must run only after the fully reviewed material/CI/source frame is ready.']}
(out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
readme=f'''# Aktuelle Informatik: privater Source-/Referenzbereinigungskandidat

Die Ownerentscheidung erfordert keine Übernahme alter Informatikergebnisse. Dieser Kandidat entfernt drei unbegründete alte Q2-Prüfungen sowie das Hierarchie-/Parallelitätsziel und den leeren Praxisast aus dem aktuellen Source. Die fünf anderen Routen bekommen neue prospektive IDs; alle166 gewöhnlichen Atomzusagen bleiben vollständig im Bedarf-/Materialinventar. Keine Aliase, Ergebnisübernahme, Historienruntime, DB-Löschung, aktive Änderung, Gitoperation oder Veröffentlichung.

**Stand:** Source-/Referenzbereinigung und vollständige endliche Bedarf-/Materialspezifikation; **keine integrierbaren Vollmaterialien und keine fachliche Freigabe**. Die fünf neuen IDs tragen im privaten Planungssource weiterhin das ungültige generische Material. Das hält die bestehenden harten Checks rot. Unveränderte Prüfungen und UNKNOWN-Verträge bleiben vollständig enthalten.

## Exakte Basis und Inhalt

- Aktive Infoquelle unverändert: `{h(R/source)}`.
- Unterstützte V3-Basis: `{h(V/source)}`.
- Privater aktueller Source: `{h(W/'candidate'/source)}`.
- Aktueller21-Katalog-Frame: PoWi `dc148f0be7b3156c2014ca1b23137273ce62b9bd44b34ffb28ff43957c224896`, Math `e4de3c3e3a294a1751d7ebcd70fa4e63a457a63e51016996055c0e78f4510a06`. Alle übrigen Eingaben vollständig gepinnt.
- `candidate-overlay.tar.gz`: genau37 neue/geänderte Dateien an ihren Repositorypfaden; unterstützte V3-Source-/View-/Placement-/Kantenkorrekturen plus aktuelle Referenzbereinigung. Keine V3-CI-Sonderbindungen oder alten Material82/46 unter alten IDs. Der eigene20er-Vertrag bleibt unabhängig erhalten, seine neue Framebindung offen.
- `full-source-changes.json.gz`: volle Goal-/Feldwerte für854→Kandidat undc824→Kandidat samt genauen Vorher-/Nachherhashes aller37 Dateien.
- `source-demand-dispositions.json.gz`:13 exakte amtliche Grundanforderungen ausMV/SH/ST/TH, volle unveränderte Sourcepassagen und vollständige Vergleichsgoaltexte. Die alten875- und überstarken pauschalen Restzuordnungen werden aus aktiven Mapping-/Decision-/Extractionreferenzen entfernt. Für jede Passage steht eine eng benannte `needsCanonicalGoal`-Lücke. Kein pauschaler7ad8-Ersatz, kein erfundenes neues875 und keine falsche Vollabdeckung. Alle gewöhnlichen kanonischen Ziele und ihre19 Viewtargetmengen bleiben erhalten; die13 Lücken bedeuten keine Inhaltslöschung.
- `five-new-route-need-material-specifications.json.gz`: pro29/25/58/35/19 Atom voller unveränderter Goaltext; genaue bestehende Primärassoziationen oder konkret benannte didaktische Abschlusslücke; tatsächliche native Targetkontexte/Views; prospektive aktuelle Route. Dazu vollständige fachliche Materialpaket-Spezifikationen, notwendige atomweise Aufgaben-/Eingabe-/Lösungs-/Bestehens-/Gegenfallanforderungen. Bestehende Primärzuordnungen sind ausdrücklich kein frisch bewiesener amtlicher Vollpflichtvertrag. Finaler tatsächlicher Angebotszuschnitt und vollständige Materialien benötigen unabhängige Prüfung. Keine automatische Kürzung und keine20/12-Übernahme.

## Tatsächlich ausgeführte native Gegenprobe

Ein gebündelter Lauf verwendet den heutigen eingefrorenen Code, die bestehenden Scope-/Composition-/Graphengine und alle21 Kataloge. Die484 früheren Backend-Quell-/Klassenpins wurden nachgeprüft; genau die zwei inzwischen geänderten Klassen wurden aus dem heutigen Quellsnapshot neu kompiliert. Die anfänglichen zwei isolierten Adapter-Mount-/Classpathfehler entstanden vor dem jeweiligen fachlichen Lauf und sind samt Korrektur protokolliert; keine Gate- oder Sourceänderung repariert sie.

| Check | Ergebnis |
|---|---|
| Aktueller Source |283 Definitionen,22 Prüfungen:12 DECLARED/10 ABSENT-UNKNOWN |
| Alle19 vorhandenen Views |0 Compilefehler; gewöhnliche Targetmengen exaktV3-gleich, nur5 reservierte Exam-IDwechsel |
| Coverage/Vorbereitung aller22 Prüfungen |ExaktV3-gleich; keine[]-Erfindung ausUNKNOWN |
| Native Graphregeln |G17 unverändert27; alle übrigen geprüften Regeln0 |
| Tatsächlich angebotener globaler Auswahlfluss |39 COMPLETE mit nichtleeren Targets;12 SELECTION, keine erfundene Union |
| Ergebniszustand |Alle5 neuen Prüfungs-IDs ungesetzt; alle synthetischen Masterys leer/unverändert; nur360 Repository-Leseaufrufe `findById` |
| Aktive aktuelle Referenzen |1206 Dateien geprüft;0 alte aktive Source-/Mapping-/Viewreferenzen;5 ausdrücklich historische HE-Auditreferenzen erhalten |
| Vollständiger Definitions-/Readinesscheck |22 Definitionen,22Required,22Checked; CQR204/CQR202 weiterhin rot |

Die bestehende QA-Konfiguration hatte zusätzlich die gelöschte leere Praxiscluster-ID fest eingetragen. `current-scope-ref-followup.patch` entfernt genau diese eine Zeile aus `CANONICAL_GYM_INFORMATICS_PRACTICE_CLUSTER_IDS`, ändert keine Engine und keine materielle Readinesspflicht. Der danach fokussiert ausgeführte native Reader findet0DiscoveryIssues bei unverändert22Definitionen/Required/Checked. Der Graph und der globale Backendfluss wurden deshalb nicht wiederholt. Die genaue alte/neue Codebindung steht in den Framepins.

CQR204 zeigt weiterhin14 fehlschlagende Identitäten aus der unveränderten alten24er-Historiennorm einschließlich aktueller neuer Identitäten/Own20. Dies sind keine14 vermeintlich aktuellen Sourceprüfungen: alle22 tatsächlichen aktuellen Definitionen sind gesondert vollständig aufgeführt. CQR202 hat6 schwache aktuelle Prüfungen: fünf generische Materialien und die offene Own20-Erstbindung. Dieses Paket umgeht keinen Fehler und verändert die historische Identitätsnorm nicht. Der konkrete autorisierte einmalige Anschluss bleibt separate Folgearbeit im bestehenden CapturedSource/ExpectedContext/Manifest-Pfad.

## Grenzen und nächster endlicher Schritt

Finale Quellen-/Niveau-/Auswahlqualifikation der fünf Routen, vollständige konkrete Materialien und deren unabhängige Prüfung bleiben offen. Die atomweisen Spezifikationen beschreiben diese Arbeit vollständig, ersetzen sie aber nicht. Die13 engen Quellenlücken bleiben reale rote Mappingarbeit. HE-Kohorte, BY-Modell, SHDB4 und vier DB-Materiallücken bleiben ungelöst. Der eigene20er-Abschluss ist keine allgemeine Ersatzroute für die alte41.

Erst auf dem tatsächlich geprüften Source-/Material-/CI-Stand folgt ein einziger vollständiger50-Scope-CQR-/Maturity-/Floorlauf. Dieser Kandidat enthält keinen Full-CQR und behauptet wederM6/M7 noch Host-/Produktabnahme. Die alten Quellen und QA-Seals bleiben Git-/Auditgeschichte; sie werden nicht zu einer Runtime-Historienlösung.

Die Rawbelege sind verlustfrei komprimiert. Die kleinen Reproduceradapter referenzieren den gebundenen privaten RAMframe `{W}` und die unveränderten lokalen Originalquellen; sie sind kein portabler Releasecontainer. Keine großen amtlichen PDFs, QA-Bäume oder vollständigen Codekopien wurden dem dauerhaften Paket beigefügt.
'''
(out/'README.md').write_text(readme)
# Package integrity: exact archive bytes, file set and no missing/duplicate payload names.
with tarfile.open(out/'candidate-overlay.tar.gz','r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(changed);assert len({m.name for m in members})==len(members)
 for row in changed:assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['afterSha256']
files=[{'path':str(p.relative_to(out)),'sha256':h(p),'bytes':p.stat().st_size}for p in sorted(out.iterdir())if p.is_file()and p.name not in ['inventory.json','seal.json']]
(out/'inventory.json').write_text(json.dumps({'status':result['status'],'payloads':files},indent=2)+'\n');(out/'seal.json').write_text(json.dumps({'inventorySha256':h(out/'inventory.json'),'payloadCount':len(files),'notAnApproval':True},indent=2)+'\n')
print(json.dumps({'package':str(out),'source':result['candidateSourceSha256'],'files':len(changed),'payloads':len(files),'bytes':sum(p.stat().st_size for p in out.iterdir()if p.is_file()),'codePostguardDrift':codedrift}))
