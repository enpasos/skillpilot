import assert from'node:assert/strict'
import{readFileSync,writeFileSync}from'node:fs'
import{createHash}from'node:crypto'
import{readEconomicsQ2MonetarySocialContext as read}from'/home/enpasos/projects/skillpilot/app/scripts/lib/goalVisualizationEconomicsQ2MonetarySocialContexts.ts'
import{parseVisualizationReviewJson}from'/home/enpasos/projects/skillpilot/app/scripts/goalVisualizationReviewedContext.ts'
import type{VisualizationContextQualification,VisualizationReviewArtifact}from'/home/enpasos/projects/skillpilot/app/scripts/goalVisualizationReviewedContext.ts'
const R='/home/enpasos/projects/skillpilot',W='/dev/shm/economics-q2-context-lint-typed-successor-20261107',label=process.argv[2],hash=(b:Buffer)=>createHash('sha256').update(b).digest('hex')
const pins=JSON.parse(readFileSync(R+'/contracts/goal-visualization-context/v1/economics-q2-monetary-social-original-pins-2026-11-07.json','utf8')) as {originalReferences:Array<VisualizationReviewArtifact&{currentCopyRequired:boolean}>,goalIds:string[]},fixed=new Map(pins.originalReferences.map(r=>[r.path,r]))
const index=JSON.parse(readFileSync(R+'/qa-artifacts/ci-contract-audit/2026-11-07/economics-additional-existing-reviewed-context-candidate/candidate-index.json','utf8'))as{candidateReceipts:Array<{path:string,sha256:string,goalId:string}>}
const rows=[];let negatives=0;const calls=new Set<string>()
const artifact=(ref:VisualizationReviewArtifact)=>{const expected=fixed.get(ref.path);assert.ok(expected);assert.equal(ref.sha256,expected.sha256);assert.equal(ref.gitCommit,expected.gitCommit);const b=readFileSync(R+'/'+ref.path);assert.equal(hash(b),ref.sha256);calls.add(ref.path);return b}
for(const row of index.candidateReceipts){
 const receiptBytes=readFileSync(R+'/'+row.path);assert.equal(hash(receiptBytes),row.sha256);const receipt=parseVisualizationReviewJson(receiptBytes)as VisualizationContextQualification;assert.equal(receipt.context.goalId,row.goalId);const review=parseVisualizationReviewJson(artifact(receipt.originalReview))as Record<string,unknown>,image=artifact(receipt.reviewedAsset)
 const result=read(receipt,review,image,artifact,parseVisualizationReviewJson);rows.push({goalId:row.goalId,result})
 for(const mutate of [(r:Record<string,unknown>)=>{r.decision='REJECT'},(r:Record<string,unknown>)=>{r.goalTitle='Not the native original goal'},(r:Record<string,unknown>)=>{r.actualInspection=null}]){
  const changed=structuredClone(review);mutate(changed);assert.throws(()=>read(receipt,changed,image,artifact,parseVisualizationReviewJson));negatives++
 }
 assert.throws(()=>read({...receipt,context:{...receipt.context,goalId:'wrong-goal'}},review,image,artifact,parseVisualizationReviewJson));negatives++
}
assert.equal(rows.length,17);assert.deepEqual(rows.map(r=>r.goalId),pins.goalIds)
writeFileSync(W+'/'+label+'.json',JSON.stringify({label,kind:'Direct native closed-family reader regression; local bytes checked against immutable external pins; not a new Git/authentication/source/image review',positiveRows:rows,negativeCases:negatives,readArtifactPaths:[...calls].sort(),noGitInvoked:true,noActiveWrites:true},null,2)+'\n');console.log(JSON.stringify({nativePositiveRows:rows.length,negativeCases:negatives,actualBoundArtifactPaths:calls.size,noGitInvoked:true,status:'pass'}))
