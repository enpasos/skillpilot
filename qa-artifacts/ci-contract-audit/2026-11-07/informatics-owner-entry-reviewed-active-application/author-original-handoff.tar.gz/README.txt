Private candidate only. Root owns application and fresh active verification.

Exactly nine implementation/test paths are listed in nine-paths-before-after.json.
The complete small patch is candidate.patch (also deterministic gzip), and
nine-candidate-files.tar.gz contains byte-exact complete files at normal paths.
The new service test is CanonicalSubjectScopeReadinessTest.java. The other eight
paths already exist. No package manifests, source graphs, QA authorities or
learning-unit runtime are changed.

Production behavior:
- UI curriculum selection delegates to existing setCurriculumFromPublicCatalog.
- Existing canonical-gymnasium subject/no-flow states require the already
  existing scope/view resolver to resolve them before they count as ready.
  Explicit compatibility-only resumes and noncanonical standalone/CEFR no-flow
  domains retain their contract. The global Gymnasium authored flow is unchanged.
  The existing explicit published-default package contract is preserved; no new
  GK/CrossStage default is invented or persisted.
- An unresolved subject returns existing INVALID diagnostic
  canonical-subject-scope-unresolved. Public state has PERSONALIZATION,
  setPersonalization, no teaching frontier and scope_completed=false. Structural
  projection and global mastery are retained; this is not an empty scope pass.
- First-party UI shows a concrete existing base-selection recovery link and
  gates the direct-owner cockpit on the server's setup requirement. Automatic
  plan reconciliation waits for that existing setup gate too.

Critical evidence is in test-receipt.json, bound to all nine after hashes.
The same actual Java service adapter and unchanged V3 sources were run against
original cached classes and the private candidate classes: Owner{} and LK with
no stage change from false configured completion to INVALID/not-complete.
The old mastered focus 875 demonstrates the baseline's actual scope_completed=true;
this is not inferred from the planner summary. Explicit owner GK/CrossStage and
the real global Info PC constructed from offered options remain COMPLETE.
Mastery 875=1 and old 41=1 remain unchanged; new 6eb remains unset. Explicit base
reselection returns to the authored SELECTION plan without changing mastery.
The adapter forbids writes/events during all read controls and permits only its
synthetic in-memory recovery mutation. No database or external event was reached.

22 focused ordinary JUnit tests pass: the UI delegation/rejection cases, six
service readiness/compatibility cases, plus the unchanged generic no-flow test.
Real Chromium recovery and the complete existing SessionSetup suite pass. The
complete cockpit startup/dedup/quiet/scope suite passes, including direct-owner
blocking and absence of automatic reconcile while setup is unresolved. Editor
labels, app TypeScript and targeted ESLint pass. No additional tests are needed
for this sealed private head unless root changes it or finds a new concern.

484 current production source/cache-class pairs were checked before candidate
binding changes; the probe is the 485th separately pinned source binding. Root
production sources still match that initial guard. Full exact execution commands,
stdout and relevant data are preserved as gzip support files. Namespace/package
acceptance, remote CI, SourceA native review, source QA/M6/M7 and deployment are
separate; none are claimed here.
