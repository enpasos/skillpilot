from pathlib import Path
import json,gzip,hashlib,shutil
R=Path('/home/enpasos/projects/skillpilot');W=Path(__file__).parent;P=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-current-definition-revision-plan';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inv=json.loads((P/'inventory.json').read_text());assert h(P/'inventory.json')=='c5b1b4bec076cbd1e346cc063c88348f9683e177a9098a947d4b016171146e14';assert h(P/'seal.json')=='08ef79d009d8ab9d4e308f2d3e10cde77368683739b85e0aeff308f4125d5ca1'
for row in inv['payloads']:assert h(P/row['path'])==row['sha256']
N=W/'native-code';rows=[]
for rel in ['app/scripts','app/src','contracts/curriculum-assessment-coverage']:
 shutil.copytree(R/rel,N/rel,dirs_exist_ok=True)
 for p in sorted((N/rel).rglob('*')):
  if p.is_file():rows.append({'path':str(p.relative_to(N)),'sha256':h(p)})
catalog=[]
for p in sorted((R/'curricula/DE/Gymnasium/canonical').glob('*.de.json')):
 rel=p.relative_to(R);q=W/'candidate'/rel
 if not q.exists():q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 catalog.append({'path':str(rel),'activeSha256':h(p),'candidateSha256':h(q)})
rev=W/'candidate/contracts/curriculum-assessment-coverage/v1/informatics/revisions/2026-11-07-current23';rev.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/'prospective-initial-source.json.gz',rev/'initial-source.json.gz');shutil.copyfile(P/'proposed-current-inventory.json',rev/'current-inventory.json')
(W/'pins/code-before.json.gz').write_bytes(gzip.compress((json.dumps(rows,indent=2)+'\n').encode(),mtime=0));(W/'pins/catalog-before.json').write_text(json.dumps(catalog,indent=2)+'\n');(W/'pins/revision-plan-before.json').write_text(json.dumps({'sealSha256':h(P/'seal.json'),'inventorySha256':h(P/'inventory.json'),'payloads':inv['payloads']},indent=2)+'\n')
print(json.dumps({'nativeCodeFiles':len(rows),'catalogInputs':len(catalog),'initialArchiveSha256':h(rev/'initial-source.json.gz'),'initialInventorySha256':h(rev/'current-inventory.json')}))
