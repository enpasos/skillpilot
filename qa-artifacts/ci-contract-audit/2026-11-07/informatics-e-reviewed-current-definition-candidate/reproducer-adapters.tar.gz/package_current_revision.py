from pathlib import Path
import json,gzip,hashlib,tarfile,io,difflib,shutil,re
R=Path('/home/enpasos/projects/skillpilot');W=Path(__file__).parent;O=W/'candidate';P=W/'pins';OUT=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-e-reviewed-current-definition-candidate';B=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-current-e-authoring-candidate';PLAN=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-current-definition-revision-plan';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());gl=lambda p:json.load(gzip.open(p,'rt'));dump=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');gz=lambda p,d:p.write_bytes(gzip.compress((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
source='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json';assert h(O/source)=='50a26163a1934216727ee178f8b0d2740c2476f62482ce32911fecbf890654e8';current=gl(W/'native-current-producer.json.gz');assert current['sourceSha256']==h(O/source);assert current['scope']['retainedCoverage']['manifest']['status']=='pass';assert len(current['scope']['retainedCoverage']['manifest']['rows'])==23;assert len(current['scope']['retainedCoverage']['manifest']['retirementChecks'])==9
assert {r['id']:r['metrics']['weakExamData']for r in current['readiness']}=={'CQR-204':8,'CQR-202':9};assert all(r['metrics']['checkedExams']==23 for r in current['readiness']);assert current['consumerAcceptsReadiness'] is False
matrix=gl(W/'db-body-guard-native-after.json.gz');assert len(matrix['cases'])==4 and all(not c['consumerAccepted'] for c in matrix['cases'])
for label in ['final-producer','db-guard-after-native','final-assessment-suite']:assert load(W/(label+'.execution.json'))['exitCode']==0,label
# All author/review seals and every captured active source/code input remain intact.
old=load(P/'before-current-frame.json');oldDrift=[r['path']for r in old['oldPackageFiles']if h(R/r['path'])!=r['sha256']];assert not oldDrift,oldDrift
plan=load(P/'revision-plan-before.json');assert h(PLAN/'seal.json')==plan['sealSha256'];assert h(PLAN/'inventory.json')==plan['inventorySha256']
for row in plan['payloads']:assert h(PLAN/row['path'])==row['sha256']
code=gl(P/'code-before.json.gz');codeDrift=[r['path']for r in code if not(R/r['path']).exists()or h(R/r['path'])!=r['sha256']];assert not codeDrift,codeDrift
catalog=load(P/'catalog-before.json');catalogDrift=[r['path']for r in catalog if h(R/r['path'])!=r['activeSha256']];assert not catalogDrift,catalogDrift
assert h(R/source)=='85411185514af4b2ecf818807f3bd6fe5df17fb5011c5ebf8c4996de1a47817e'
# Preserve the exact E-only intermediate alongside its original proof and patch.
f4=gzip.decompress((P/'f4-e-released-source.json.gz').read_bytes());assert hashlib.sha256(f4).hexdigest()=='f4a4575998460d819f34eec5bf906291b339a731740c64e35fa9a19ed5ae3e23';shutil.copyfile(P/'f4-e-released-source.json.gz',OUT/'f4-e-released-source.json.gz')
# Full Source85→Source50 semantic metadata-only proof; no material or coverage edits.
with tarfile.open(B/'candidate-overlay.tar.gz','r:gz')as t:base={m.name:t.extractfile(m).read()for m in t.getmembers()}
before=json.loads(base[source]);after=load(O/source);bm={g['id']:g for g in before['goals']};am={g['id']:g for g in after['goals']};changes=[]
for id in bm:
 if bm[id]!=am[id]:
  restored=json.loads(json.dumps(am[id]));e=restored['examData'];b=bm[id]['examData']
  if 'reviewStatus'in b:e['reviewStatus']=b['reviewStatus']
  else:del e['reviewStatus']
  if 'reviewNote'in b:e['reviewNote']=b['reviewNote']
  else:del e['reviewNote']
  assert restored==bm[id],id;changes.append({'goalId':id,'beforeReviewStatus':b.get('reviewStatus'),'afterReviewStatus':am[id]['examData'].get('reviewStatus'),'beforeReviewNote':b.get('reviewNote'),'afterReviewNote':am[id]['examData'].get('reviewNote')})
assert len(changes)==7;assert before.keys()==after.keys();assert {k:v for k,v in before.items()if k!='goals'}=={k:v for k,v in after.items()if k!='goals'};assert len(after['goals'])==284
coverageState={g['id']:'DECLARED'if'coveredGoalIds'in g['examData']else'ABSENT_UNKNOWN'for g in after['goals']if'examData'in g};assert list(coverageState.values()).count('DECLARED')==13 and list(coverageState.values()).count('ABSENT_UNKNOWN')==10
metadata={'source85Sha256':'85ed339482b57f9ea19661df76acce4403ca5b7b9b9727261c1fffb1796dd48b','eOnlyF4Sha256':hashlib.sha256(f4).hexdigest(),'source50Sha256':h(O/source),'completeGoalCount':284,'examCount':23,'exactSevenMetadataChanges':changes,'allMaterialsSolutionsRubricsPointsCoverageRequiresIdsViewsAndMappingDataUnchanged':True,'coverageStates':coverageState};gz(OUT/'source85-f4-source50-metadata-proof.json.gz',metadata)
# Package only repository changes; all20 unrelated canonical snapshots are omitted.
changed=[];patch=[]
for p in sorted(O.rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(O));active=R/rel
 if active.exists()and h(p)==h(active):continue
 row={'path':rel,'activeBeforeSha256':h(active)if active.exists()else None,'afterSha256':h(p),'bytes':p.stat().st_size,'source85OverlayBeforeSha256':hashlib.sha256(base[rel]).hexdigest()if rel in base else None};changed.append(row)
 if p.suffix!='.gz':
  prior=base.get(rel,active.read_bytes()if active.exists()else b'')
  patch.extend(difflib.unified_diff(prior.decode().splitlines(keepends=True),p.read_text().splitlines(keepends=True),fromfile='source85-frame/'+rel,tofile='candidate/'+rel))
assert len(changed)==46,len(changed)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT)as t:
 for row in changed:
  data=(O/row['path']).read_bytes();ti=tarfile.TarInfo(row['path']);ti.size=len(data);ti.mtime=0;ti.mode=0o644;t.addfile(ti,io.BytesIO(data))
(OUT/'candidate-overlay.tar.gz').write_bytes(gzip.compress(buf.getvalue(),mtime=0));(OUT/'code-and-source85-frame-diff.patch.gz').write_bytes(gzip.compress(''.join(patch).encode(),mtime=0));dump(OUT/'changed-files.json',{'sourceSha256':h(O/source),'files':changed})
# Actual native outputs are kept separately before and after the causal DB repair.
for name in ['native-current-producer.json.gz','initial-current-producer-before-db-body-guard.json.gz','db-status-only-before-body-guard.json.gz','db-body-guard-native-after.json.gz']:shutil.copyfile(W/name,OUT/name)
reasons={r['id']:{'status':r['status'],'metrics':r['metrics'],'details':r['details']}for r in current['readiness']};dump(OUT/'final-readiness-reasons.json',reasons)
# Parse exact emitted test records, retain all command outputs and the obsolete
# DB-positive assertion failure as a named earlier diagnostic, never erase it.
records=[]
for line in (W/'final-assessment-suite.stdout').read_text().splitlines():
 if line.startswith('{'):
  try:records.append(json.loads(line))
  except json.JSONDecodeError:pass
assert any(r.get('currentDefinitionRevisionGroups')==14 for r in records);assert any(r.get('retainedCoverageGroups')==20 for r in records);assert any(r.get('group')=='T21'and r.get('positiveMaturity')=='M6'and r.get('negativeMaturity')=='M3'for r in records)
fixture=W/'test-tmp/retained-assessment-chain-fixture';fixtures={n:load(fixture/n)for n in ['overlay-evidence.json','synthetic-binding-evidence.json']};gz(OUT/'focused-test-results-and-fixture-inputs.json.gz',{'emittedFinalRecords':records,'fixtureEvidence':fixtures,'normalAssessmentSuite':'final-assessment-suite','historicalAuditSourceAndInventoryPinsRetained':True,'initialWrongDbPositiveAssertionCorrected':{'label':'full-assessment-tests','actualLegacyExpectationWasPass':True,'correctedToFourIndividualKnownMissingInputControls':True,'independentlyFailingMutationCases':40,'alreadyBlockedDbMutationCases':16}})
receipts={p.stem:load(p)for p in W.glob('*.execution.json')};outputs={p.name:p.read_text()for p in W.iterdir()if p.is_file()and p.suffix in ['.stdout','.stderr']};gz(OUT/'native-execution-receipts-and-outputs.json.gz',{'receipts':receipts,'outputs':outputs,'sourceAProbesRun':False,'fullCqrRun':False,'gitDbDeployOrActiveWrites':False})
# Existing consumer/maturity/floor algorithms are byte-identical; only the
# configured producer/helper and its explicit material countercase are changed.
gen=(O/'app/scripts/generateCurriculumQualityStatus.ts').read_text();activeGen=(R/'app/scripts/generateCurriculumQualityStatus.ts').read_text();section=lambda s:s[s.index('export function deriveCurriculumMaturity('):s.index('function pushGeneratedMarkdownNotice(')];assert section(gen)==section(activeGen)
unchangedConsumers=[{'path':rel,'sha256':h(R/rel)}for rel in ['app/scripts/lib/curriculumAssessmentValidation.ts','app/scripts/checkCurriculumMaturityFloors.ts']];assert all(not(O/r['path']).exists()for r in unchangedConsumers)
frames={'activeCodeInputFiles':code,'activeCodePostguardDrift':codeDrift,'catalogInputs':catalog,'catalogPostguardDrift':catalogDrift,'oldSource85AndReviewPins':old['oldPackageFiles'],'oldPackagePostguardDrift':oldDrift,'revisionPlanSealSha256':h(PLAN/'seal.json'),'revisionPlanInventorySha256':h(PLAN/'inventory.json'),'revisionPlanPayloads':plan['payloads'],'unchangedConsumerFiles':unchangedConsumers,'maturityFunctionBodyExactlyUnchanged':True,'finalEffectiveChangedFilePins':changed,'actualCurrentSource50':h(O/source),'activeSourceUnchanged':h(R/source),'finalGuardIsFourKnownMaterialBodiesOnly':gl(W/'db-status-only-before-body-guard.json.gz')['rows'],'initialProducerHelperSha256':'64b7a672ed50c3bdea6c3a0c6b2cbabef5fa4cd5be32caeca5b44586899325da'};gz(OUT/'input-frame-code-pins-and-postguards.json.gz',frames)
repro=io.BytesIO()
with tarfile.open(fileobj=repro,mode='w',format=tarfile.PAX_FORMAT)as t:
 for p in [W/n for n in ['prepare_released_e.py','mark_four_db_drafts.py','prepare_native_revision.py','implement_revision.py','run_private_native.py','native_readout.mts','native_db_status_countercase.mts','native_db_guard_after.mts','package_current_revision.py']]:
  data=p.read_bytes();ti=tarfile.TarInfo(p.name);ti.size=len(data);ti.mtime=0;ti.mode=0o644;t.addfile(ti,io.BytesIO(data))
(OUT/'reproducer-adapters.tar.gz').write_bytes(gzip.compress(repro.getvalue(),mtime=0))
result={'status':'PRIVATE_REVIEWABLE_CURRENT_DEFINITION_IMPLEMENTATION; WHOLE_INFORMATICS_REMAINS_RED; NO_ACTIVE_APPLICATION','source50Sha256':h(O/source),'activeSourceUnchangedSha256':h(R/source),'changedRepositoryFiles':len(changed),'sourceMetadataOnlyVsSource85':7,'sourceStages':{'source85':'85ed339482b57f9ea19661df76acce4403ca5b7b9b9727261c1fffb1796dd48b','releasedEOnly':hashlib.sha256(f4).hexdigest(),'draftDb4OnF4':h(O/source)},'currentContract':{'status':'pass','currentRows':23,'separateRetirements':9,'survivingDeclared':5,'survivingUnknown':10,'firstDefinitions':8,'callerRegistryOrSourceHashWhitelist':False,'oldHistoryPinsUnchanged':True,'all23DefinitionsRequiredAndChecked':True},'actualReadiness':[{'id':r['id'],'status':r['status'],'metrics':r['metrics']}for r in current['readiness']],'dbKnownBadBodyRepair':{'firstActualStatusOnlyFalsePassFound':True,'fourBodyFingerprintsBound':True,'draftReleaseReviewNoteVariantsEachIndividuallyBlocked':4,'actualCases':[{k:c[k]for k in ['mode','sourceSha256','manifestStatus','consumerAccepted']}for c in matrix['cases']],'threeActualEPositiveControlsReady':True,'differentCompleteDbMaterialNotIdBanned':True,'newMaterialStillNeedsExistingMeaningEvidence':True},'focusedChecks':{'fullAssessmentSuiteExitCode':0,'historicalGroups':20,'heldViewCases':25,'currentRevisionGroups':14,'unknownTransitionNegatives':30,'staleInitialInventoryReviewPinNegatives':5,'duplicateOrOneSidedInitialPartitionNegatives':2,'nativeM6ControlM3SingleCoverageNegative':True,'independentFloorCliForgeryRejected':True,'currentActualConsumerAccepts':False},'unchangedConsumers':unchangedConsumers,'activeCodeAndCatalogDrift':[],'gitDbProductionWrites':False,'fullCqrOrSourceAProbes':False,'independentImplementationReviewPending':True,'remainingHolds':['8 actual CQR204 material errors:4 generic placeholders plus4 known missing ER/schema/SQL/algebra inputs.','9 actual CQR202 unready definitions:the same8 plus Own20draft.','Own20 compiled applicability/source/scope holds;10 ordinary E residual routes and other-state scope qualification.','Earlier source/cohort/DB/model questions and graph G17 remain; bounded native rule derivation is no full-CQR outcome.','Independent review of this exact code/source package before Root applies; no overall M6/M7 or host/human/production acceptance.']};dump(OUT/'RESULT.json',result)
readme=f'''# Privater aktueller Informatik-Definitionsanschluss

**Fokussierte Implementierung und Tests bestehen; der aktuelle Informatikstand bleibt hart rot.** Source `{h(O/source)}` hat23 aktuelle Definitionen, alle23 sind Required und Checked. Der technische Vertrag hat23 aktuelle Zeilen (5 unveraendert deklariert,10 unveraendert UNKNOWN,8 explizite Erstbindungen) und neun getrennte Retirementpruefungen. Die tatsächlichen Endbefunde sind **CQR204:8** und **CQR202:9**, nicht die vorherige Vertragsprognose4/9. Es gibt keine aktive Anwendung, Ergebnisuebernahme, Aliase oder Historienruntime.

## Zwei getrennte Metadatenstufen

Source85 `85ed3394…` bleibt unveraendert versiegelt. Sein unabhaengiger Review ist durch Resultat `71ec7653107de3c75b87b39369358911b3813baef7b1624e26d277fa407fc05d` und Seal `6106e2c3149252c3d7f5f2408549e2b8574b78ac11ef3cb2691d52582a18e439` belegt. Die erste Stufe `{hashlib.sha256(f4).hexdigest()}` setzt ausschliesslich die drei geprueften E-Aufgaben auf released und fuegt im bestehenden `examData.reviewNote` den exakten begrenzten Reviewbeleg hinzu. Diese Stufe bleibt als eigenes Overlay, Patch, Diff und komprimierter Source erhalten.

Die zweite ausdruecklich autorisierte Stufe setzt ausschliesslich die vier bisher statuslosen UNKNOWN-Datenbankaufgaben auf draft mit jeweils konkreter Notiz zu fehlenden ER-/Schema-/Tabellen-/SQL-/Algebra-Eingaben. Drei E-Aufgaben bleiben released; vier andere Platzhalter und Own20 bleiben draft. Alle Aufgabe-, Loesungs-, Rubrik-, Punkte-, Coverage-, Voraussetzungen-, ID-, View- und Mappingfelder bleiben gegen Source85 gleich. Alle zehn Coveragefelder bleiben tatsächlich abwesend. `source85-f4-source50-metadata-proof.json.gz` prueft den vollstaendigen Vergleich.

## Endliche bestehende Vertragsbindung

Der unveraenderte historische24er-Source und sein Inventory bleiben Audit. Der separat versiegelte Vertrag `informatics-current-definition-revision-plan/` (Inventory `{h(PLAN/'inventory.json')}`, Seal `{h(PLAN/'seal.json')}`) liefert die genaue15/9/8-Partition. Die Initialarchive5a0abd35 und das Inventory031ba948 werden bytegleich uebernommen und im bestehenden Helper neu aus ihren tatsaechlichen Quellinhalten verifiziert. Es gibt keinen vom Caller waehlbaren JSON-Register-/approved-/ignoreHistory-Einstieg und keine Whitelist heutiger Gesamtsourcehashes.

Die kanonische CapturedSourcepfadidentitaet konsumiert genau diese codeeigene Revision. Die 15 ueberlebenden Bedeutungen werden unveraendert gegen ihre alten Vertraege geprueft. Q3 bleibt tatsächlich21/18; keine Q3-Rekeys werden erfunden. Die acht neuen Definitionen verwenden die bereits vorhandenen `ExactMeaningEvidence`-Erstbindungen. Die neun alten Retirements werden separat auf aktuelle Abwesenheit geprueft, niemals als bestanden oder `Coverage=[]` bezeichnet. Wiedereinfuehrung, ungebundene neue Definition, fehlender Survivor/Birth und veraenderte Leistung bleiben harte Fehler; auch UUID-Schreibvarianten koennen eine gehaltene/retirierte Identitaet nicht verdecken.

CapturedSource, Freeze/WeakMap und die vollstaendige serialisierte Manifestbindung bleiben erhalten. Der Frame bindet zusaetzlich die exakten Initial-/Inventar-/Reviewpins sowie die Revisions-/Retirementteile. `curriculumAssessmentValidation.ts`, der Maturityfunktionskoerper und `checkCurriculumMaturityFloors.ts` sind unveraendert. Ein frischer Source mit unveraenderten Pruefungsvertraegen und anderer unbeteiligter Landscapeueberschrift besteht die technische Bindung; ein alter Context dazu nicht.

## Tatsaechlich gefundene und geschlossene DB-Readinessluecke

Der erste echte Source50-Producer lieferte den technischen Vertragspass, aber vier bekannte DB-Eingabeluecken waren nur durch draft blockiert. Der gezielte Gegenfall aenderte ausschliesslich diese vier Status zu released. Derselbe Source `b22f9a715d213bc47405f34a888b6473b558da83a49f7b1dfc15ea9208bf8205` erzeugte damals fuer jede der vier Aufgaben unberechtigt keinen individuellen CQR202- oder CQR204-Fehler; der Gesamtbestand war lediglich aus anderen Gruenden weiter rot. Dieser Rohbefund bleibt in `db-status-only-before-body-guard.json.gz` erhalten.

Der vorhandene `concreteExamReadinessIssues`-Pfad erkennt deshalb jetzt genau die vier unabhaengig belegten unveraenderten fehlenden Materialkoerper anhand stabiler Task-/Loesungs-/Scoringfingerprints. Reviewstatus und Reviewnotiz gehoeren bewusst nicht zu diesem Fingerprint. Das ist kein allgemeiner Textqualitaetspruefer, kein Fach- oder ID-Bann und keine neue approved-Eigenschaft. Ein anderer vollstaendiger DB-Materialkoerper ist nicht deshalb unready, weil die alte ID dazu genannt wird; fuer seine Anerkennung als gleicher Vertrag bleibt die normale explizite Bedeutungs-/Evidenzpruefung erforderlich.

Nach der Reparatur wurden die normale Discovery, der Producer und der aktuelle Consumer fuer draft, released, reine neue Reviewnotiz und released+neue Notiz tatsächlich erneut ausgefuehrt. In allen vier Faellen sind23 Definitionen vollstaendig Required/Checked, alle vier DB-Aufgaben einzeln in CQR202 **und** CQR204 fehlerhaft, der Consumer lehnt ab, und die drei echten geprueften E-Aufgaben bleiben ready. Die genaue Statusflipquelleb22 ist damit vor und nach der Codereparatur identisch. `db-body-guard-native-after.json.gz` enthaelt alle Einzelzeilen und Sourcepins.

Der finale aktuelle Producer zeigt CQR204: vier generische Platzhalter plus vier fehlende konkrete DB-Eingabematerialien. CQR202 enthaelt dieselben acht Aufgaben und Own20draft. Die genauen Befunde stehen getrennt in `final-readiness-reasons.json`. Ein Vertrags-/Erstbindungspass qualifiziert keine dieser Materialien, keinen allgemeinen Landespflichtscope und keinen Gesamtstand.

## Verifikation und Grenzen

Die fokussierte normale Assessmentsuite wurde auf dem privaten aktuellen Codeframe bis EXIT0 ausgefuehrt: bestehende Graph-/Maturityfaelle, sechs bekannte generische Negativpayloads,20 historische Coveragegruppen,25 Held-View-Faelle, die echte native M6-Kontrolle mit einzelnem CoveragefehlerM3 und unabhaengigem CLI-Floor-Forgerygegenfall sowie14 neue aktuelle Revisionsgruppen. Darunter sind30 UNKNOWN→leer/null/Liste-Gegenfaelle, alle neun Retirement-Reintroduktionen, native Q3-Wachstumsnegative, Material-/Loesungs-/Rubrik-/Schwellenveraenderungen, fuenf stale Initial-/Inventory-/Reviewpins, zwei doppelte/einseitige Initialpartitionen, Contextreplay und gefaelschte Nullfehler-/M6-/M7-Berichte bei einer tatsächlichen Vertragsverletzung.

Die alten Auditbytes/IDs und festen synthetischen Historienpins bleiben unveraendert. Die vorhandene synthetische aktuelle Quellcapture hat einen eigenen Dateinamen erhalten, damit sie nicht als produktive kanonische Revision gilt; das ist kein Readinessausweg. Ihr bereits vorhandener isolierter Loader ersetzt weiterhin nur seine expliziten Testbindings. Die alte falsche Positivassertion fuer die vier DB-Angebote wurde als konkreter frueherer Testfehler erhalten und anschliessend durch vier Negativkontrollen ersetzt: sechs bisher akzeptierte Info-Angebotskontrollen, vier bekannte Materialholds,40 unabhaengig fehlschlagende Payloadmutationen und16 Mutationen bereits blockierter DB-Koerper. Es wird kein frueherer Materialpass fortgeschrieben.

`native-execution-receipts-and-outputs.json.gz` enthaelt auch die frueheren fehlgeschlagenen bzw. vorlaeufigen Laeufe klar getrennt. Die Maturityangabe im begrenzten nativen Producer stammt nur aus Graph-/Assessmentregeln und ist kein vollstaendiger CQR-Lauf. Der Root uebernimmt nach unabhaengigem Review die konkrete Anwendung und einen einzigen normalen Gesamt-CQR. Keine SourceA-Probes, neuen Backend-/51-Scope-Laeufe oder erneuten Browsermaterialtests wurden ausgefuehrt.

Alle verwendeten aktiven Code-/Kataloginputs und alten Siegel wurden nachgeprueft und sind unveraendert. Die aktive Informatikquelle bleibt `{h(R/source)}`. Das46-Datei-Overlay, seine exakten Vorher-/Nachherpins und der lesbare gzip-Diff sind unabhaengig reviewbar. Grosse private Code- und Fixturebaeume bleiben ausschliesslich im RAMframe `{W}`.

Erforderliche Evidenzdateien der neuen Erstbindungen liegen im bereits versiegelten `informatics-current-definition-revision-plan/` sowie den bestehenden Cleanup-/E-Reviewpaketen. Sie muessen bei einer spaeteren Anwendung/Commitaufnahme mit ihren unveraenderten Bytes verfuegbar bleiben. Ihr Fehlen ist absichtlich ein harter Pinfehler. Dieses neue Paket selbst erteilt noch keine unabhaengige Implementierungsfreigabe, keine M6/M7-, Human-, Host- oder Produktionsabnahme.
''';(OUT/'README.md').write_text(readme)
with tarfile.open(OUT/'candidate-overlay.tar.gz','r:gz')as t:
 assert len(t.getmembers())==len(changed)
 for row in changed:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['afterSha256']
files=[{'path':p.name,'sha256':h(p),'bytes':p.stat().st_size}for p in sorted(OUT.iterdir())if p.is_file()and p.name not in ['inventory.json','seal.json']];dump(OUT/'inventory.json',{'status':result['status'],'payloads':files});dump(OUT/'seal.json',{'inventorySha256':h(OUT/'inventory.json'),'payloadCount':len(files),'sourceSha256':h(O/source),'independentImplementationReviewPending':True});print(json.dumps({'package':str(OUT),'sourceSha256':h(O/source),'overlayFiles':len(changed),'inventorySha256':h(OUT/'inventory.json'),'sealSha256':h(OUT/'seal.json'),'payloads':len(files),'bytes':sum(p.stat().st_size for p in OUT.iterdir()if p.is_file()),'helperSha256':h(O/'app/scripts/lib/retainedAssessmentCoverage.ts'),'producerSha256':h(O/'app/scripts/generateCurriculumQualityStatus.ts')}))
