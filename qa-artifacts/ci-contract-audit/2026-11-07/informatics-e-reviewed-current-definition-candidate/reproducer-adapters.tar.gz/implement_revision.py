from pathlib import Path
import json,hashlib,shutil
R=Path('/home/enpasos/projects/skillpilot');W=Path(__file__).parent;O=W/'candidate';P=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-current-definition-revision-plan';rel='app/scripts/lib/retainedAssessmentCoverage.ts';p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);s=(R/rel).read_text();revision=json.loads((P/'proposed-revision.json').read_text());bindings=json.loads((P/'proposed-first-bindings.json').read_text())['bindings'];canonical='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json'
s=s.replace("contractVersion: 'informatics-retained-assessment-coverage-v1'", "contractVersion: 'informatics-retained-assessment-coverage-v1' | 'informatics-current-assessment-coverage-2026-11-07-v1'",1)
s=s.replace('  historicalGoalIds: string[]\n', '''  historicalGoalIds: string[]
  revision?: { revisionId: string; definitionSourcePath: string; initialSourceReference: { path: string; sha256: string; gzip?: boolean };
    initialInventoryReference: { path: string; sha256: string }; dataSha256: string; reviewPins: Array<{ path: string; sha256: string }> }
  retirementChecks?: Array<{ goalId: string; decision: 'retired-current-definition' | 'fail'; issues: string[] }>
''',1)
start='// Append-only concrete bindings are added only after exact source integration.\n// Pending private candidates are deliberately not a passing baseline.\nconst CONCRETE_BINDINGS: readonly ExactMeaningEvidence[] = []'
assert start in s
insert="""// One reviewed authoring revision at the existing canonical source identity.
// Historical fixture captures keep the immutable24 audit; the actual producer
// and independent floor capture this exact repository path. No current SHA
// allowlist: the archived SHA binds only the fixed initial definitions.
const CURRENT_INFO_SOURCE_PATH = '"""+canonical+"""'
const CURRENT_INFO_REVISION = """+json.dumps(revision,ensure_ascii=False,indent=2)+""" as const

// Existing finite first-definition evidence, not a caller/runtime registry.
const CONCRETE_BINDINGS: readonly ExactMeaningEvidence[] = """+json.dumps(bindings,ensure_ascii=False,indent=2)+"""

function verifyCurrentInfoRevision(repoRoot: string, historical: SkillLandscape): { issues: string[]; pins: Array<{ path: string; sha256: string }> } {
  const revision = CURRENT_INFO_REVISION, issues: string[] = [], pins = [revision.initialSourceReference, revision.initialInventoryReference, ...revision.reviewPins]
  try {
    for (const pin of pins) if (coverageSha256(readFileSync(resolve(repoRoot, pin.path))) !== pin.sha256) issues.push(`revision-pin-invalid: ${pin.path}`)
    const archive = readFileSync(resolve(repoRoot, revision.initialSourceReference.path)), raw = gunzipSync(archive)
    if (coverageSha256(raw) !== revision.initialSourceSha256 || revision.owner !== RETAINED_INFO_OWNER
      || revision.priorActiveSourceSha256 !== RETAINED_INFO_SOURCE_SHA || revision.priorHistoryInventorySha256 !== RETAINED_INFO_INVENTORY_SHA) issues.push('revision-source-binding-invalid')
    const initial = JSON.parse(raw.toString('utf8')) as SkillLandscape
    const inventory = JSON.parse(readFileSync(resolve(repoRoot, revision.initialInventoryReference.path), 'utf8'))
    if (initial.landscapeId !== RETAINED_INFO_OWNER || new Set(initial.goals.map(goal => goal.id.toLowerCase())).size !== initial.goals.length) issues.push('revision-owner-or-duplicate-invalid')
    const exams = initial.goals.filter(goal => goal.examData).sort((a, b) => a.id.localeCompare(b.id))
    const definitions = exams.map(goal => {
      const declared = Object.hasOwn(goal.examData!, 'coveredGoalIds')
      const coverage = declared ? resolveRetainedCoverage(initial, goal.examData!.coveredGoalIds) : undefined
      if (coverage?.issues.length) issues.push(...coverage.issues.map(issue => `revision-initial-coverage: ${issue}`))
      return { goalId: goal.id, title: goal.title, protectedMeaningSha256: coverageSha256(stableCoverageJson(protectedAssessmentMeaning(goal, true))),
        fullGoalObjectSha256: coverageSha256(stableCoverageJson(goal)), examDataSha256: coverageSha256(stableCoverageJson(goal.examData)),
        reviewStatus: goal.examData!.reviewStatus ?? null, coverage: declared
          ? { state: 'declared', references: goal.examData!.coveredGoalIds, atomicGoalKeys: coverage!.atoms }
          : { state: 'undeclared', reason: 'coveredGoalIds is absent in the exact current definition; external competence coverage remains UNKNOWN.' } }
    })
    const actualInventory = { kind: 'PROPOSED exact initial current-definition inventory; no material quality or maturity grant', owner: initial.landscapeId,
      sourceSha256: coverageSha256(raw), definitionCount: definitions.length, declaredCount: definitions.filter(row => row.coverage.state === 'declared').length,
      undeclaredCount: definitions.filter(row => row.coverage.state === 'undeclared').length, definitions }
    if (!same(inventory, actualInventory) || actualInventory.definitionCount !== 23
      || actualInventory.declaredCount !== revision.currentDeclaredCount || actualInventory.undeclaredCount !== revision.currentUndeclaredCount) issues.push('revision-inventory-invalid')
    const historicalIds = sorted(historical.goals.filter(goal => goal.examData).map(goal => goal.id)), initialIds = exams.map(goal => goal.id)
    const surviving = historicalIds.filter(id => initialIds.includes(id)), retired = historicalIds.filter(id => !initialIds.includes(id)), births = initialIds.filter(id => !historicalIds.includes(id))
    if (!same(initialIds, revision.currentDefinitionGoalIds) || !same(surviving, revision.survivingHistoricalGoalIds)
      || !same(retired, revision.retiredHistoricalGoalIds) || !same(births, revision.introductionGoalIds)
      || surviving.length !== 15 || retired.length !== 9 || births.length !== 8) issues.push('revision-partition-invalid')
    const oldById = new Map(historical.goals.map(goal => [goal.id, goal])), initialById = new Map(initial.goals.map(goal => [goal.id, goal]))
    for (const id of surviving) {
      const old = oldById.get(id)!, current = initialById.get(id)!, declared = Object.hasOwn(old.examData!, 'coveredGoalIds')
      if (!same(protectedAssessmentMeaning(old, true), protectedAssessmentMeaning(current, true))
        || declared !== Object.hasOwn(current.examData!, 'coveredGoalIds')) issues.push(`revision-survivor-meaning-invalid: ${id}`)
      if (declared) {
        const oldCoverage = resolveRetainedCoverage(historical, old.examData!.coveredGoalIds), newCoverage = resolveRetainedCoverage(initial, current.examData!.coveredGoalIds)
        if (oldCoverage.issues.length || newCoverage.issues.length || !same(oldCoverage.atoms, newCoverage.atoms)) issues.push(`revision-survivor-coverage-invalid: ${id}`)
        for (const ref of oldCoverage.definitions) if (!initialById.has(ref)
          || !same(protectedAssessmentMeaning(oldById.get(ref)!), protectedAssessmentMeaning(initialById.get(ref)!))) issues.push(`revision-survivor-target-meaning-invalid: ${id}:${ref}`)
      }
    }
    const firsts = CONCRETE_BINDINGS.filter(binding => binding.kind === 'first-definition-binding' && binding.sourcePath === CURRENT_INFO_SOURCE_PATH)
    if (firsts.length !== 8 || !same(sorted(firsts.map(binding => binding.goalId)), births)
      || firsts.some(binding => binding.owner !== revision.owner || binding.sourceSha256 !== revision.initialSourceSha256
        || !same(binding.sourceReference, revision.initialSourceReference) || !verifiedInitialSource(binding, repoRoot))) issues.push('revision-first-bindings-invalid')
  } catch (error) { issues.push(`revision-binding-invalid: ${String(error)}`) }
  return { issues: sorted(issues), pins }
}
"""
s=s.replace(start,insert)
old='''  const registeredFirstGoalIds = CONCRETE_BINDINGS.filter(binding => binding.kind === 'first-definition-binding').map(binding => binding.goalId)'''
new='''  const revisionRequested = capture?.path === CURRENT_INFO_SOURCE_PATH
  const revisionCheck = revisionRequested ? verifyCurrentInfoRevision(repoRoot, historical) : undefined
  discoveryIssues.push(...(revisionCheck?.issues ?? []))
  const currentRevision = revisionRequested && revisionCheck?.issues.length === 0
  // Source-path ownership is already part of every first binding. Historical
  // audit captures and existing isolated fixture frames cannot import births
  // registered for a different source identity.
  const sourceBindings = CONCRETE_BINDINGS.filter(binding => binding.sourcePath === capture?.path)
  const registeredFirstGoalIds = sourceBindings.filter(binding => binding.kind === 'first-definition-binding').map(binding => binding.goalId)
  if (revisionRequested) {
    const actualDefinitions = sorted(landscape.goals.filter(goal => goal.examData !== undefined || goal.nodeKind === 'exam'
      || (!(goal.contains?.length) && (goal.tags ?? []).some(tag => tag === 'Exam' || tag === 'Assessment'))).map(goal => goal.id))
    if (!same(sorted(definitionGoalIds), CURRENT_INFO_REVISION.currentDefinitionGoalIds)
      || !same(actualDefinitions, CURRENT_INFO_REVISION.currentDefinitionGoalIds)) discoveryIssues.push('current-definition-set-invalid')
    if (byId.has(CURRENT_INFO_REVISION.privateDiscardedNeverActiveId)) discoveryIssues.push('discarded-introduction: active source')
  }
  const retirementChecks = revisionRequested ? CURRENT_INFO_REVISION.retiredHistoricalGoalIds.map(goalId => {
    const issues = [...(!currentRevision ? ['revision-binding-invalid'] : []), ...(byId.has(goalId) || definitionGoalIds.includes(goalId) ? ['retired-definition-reintroduced'] : [])]
    return { goalId, decision: issues.length ? 'fail' as const : 'retired-current-definition' as const, issues }
  }) : undefined'''
assert old in s;s=s.replace(old,new)
s=s.replace("if (CONCRETE_BINDINGS.some(binding => binding.kind === 'first-definition-binding'", "if (sourceBindings.some(binding => binding.kind === 'first-definition-binding'",1)
s=s.replace("  for (const goalId of [...historicalGoalIds, ...introductions]) {", "  const requiredHistoricalGoalIds = currentRevision ? [...CURRENT_INFO_REVISION.survivingHistoricalGoalIds] : historicalGoalIds\n  for (const goalId of [...requiredHistoricalGoalIds, ...introductions]) {",1)
# Every existing comparison stays in place; concrete rows are merely restricted to the current captured source identity.
s=s.replace('const binding = CONCRETE_BINDINGS.find(', 'const binding = sourceBindings.find(')
s=s.replace('const initial = CONCRETE_BINDINGS.find(', 'const initial = sourceBindings.find(')
s=s.replace('const first = CONCRETE_BINDINGS.find(', 'const first = sourceBindings.find(')
old="  const manifest: RetainedCoverageManifest = { contractVersion: 'informatics-retained-assessment-coverage-v1', owner: RETAINED_INFO_OWNER,"
new="""  const revision = revisionRequested ? { revisionId: CURRENT_INFO_REVISION.revisionId, definitionSourcePath: CURRENT_INFO_SOURCE_PATH,
    initialSourceReference: { ...CURRENT_INFO_REVISION.initialSourceReference }, initialInventoryReference: { ...CURRENT_INFO_REVISION.initialInventoryReference },
    dataSha256: coverageSha256(stableCoverageJson(CURRENT_INFO_REVISION)), reviewPins: CURRENT_INFO_REVISION.reviewPins.map(pin => ({ ...pin })) } : undefined
  const manifest: RetainedCoverageManifest = { contractVersion: revisionRequested ? 'informatics-current-assessment-coverage-2026-11-07-v1' : 'informatics-retained-assessment-coverage-v1', owner: RETAINED_INFO_OWNER,"""
assert old in s;s=s.replace(old,new)
s=s.replace('source: capture ?? null, views, consumedPins, definitionGoalIds, requiredGoalIds', 'source: capture ?? null, views, consumedPins, ...(revisionRequested ? { revision, revisionPins: revisionCheck?.pins, retirementChecks } : {}), definitionGoalIds, requiredGoalIds')
s=s.replace('    historicalGoalIds, currentDefinitionGoalIds:', '    historicalGoalIds, ...(revisionRequested ? { revision, retirementChecks } : {}), currentDefinitionGoalIds:')
s=s.replace("failingGoalIds: sorted(rows.filter(row => row.decision === 'fail').map(row => row.goalId)),", "failingGoalIds: sorted([...rows.filter(row => row.decision === 'fail').map(row => row.goalId), ...(retirementChecks?.filter(row => row.decision === 'fail').map(row => row.goalId) ?? [])]),")
s=s.replace("status: rows.every(row => row.decision !== 'fail') && !discoveryIssues.length && historicalGoalIds.length === 24 ? 'pass' : 'fail'", "status: rows.every(row => row.decision !== 'fail') && !retirementChecks?.some(row => row.decision === 'fail')\n      && !discoveryIssues.length && historicalGoalIds.length === 24 && (!revisionRequested || (currentRevision && rows.length === 23 && retirementChecks?.length === 9)) ? 'pass' : 'fail'")
p.write_text(s)
# The existing process-isolated fixture loader must replace the now-populated
# code-owned binding literal, preserving its real historical/synthetic cases.
tr='app/scripts/testRetainedAssessmentCoverageChain.ts';q=O/tr;q.parent.mkdir(parents=True,exist_ok=True);t=(R/tr).read_text();needle=".replace('const CONCRETE_BINDINGS: readonly ExactMeaningEvidence[] = []','const CONCRETE_BINDINGS: readonly ExactMeaningEvidence[] = '+JSON.stringify(config.bindings))";assert needle in t;t=t.replace(needle,".replace(/const CONCRETE_BINDINGS: readonly ExactMeaningEvidence\\\\[\\\\] = \\\\[[\\\\s\\\\S]*?^\\\\]/mu,'const CONCRETE_BINDINGS: readonly ExactMeaningEvidence[] = '+JSON.stringify(config.bindings))");q.write_text(t)
print(json.dumps({'helperSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'helperLines':len(s.splitlines()),'births':len(bindings),'sourceUnchanged':hashlib.sha256((O/canonical).read_bytes()).hexdigest(),'fixtureLoaderOnlyTestAdaptation':tr}))
