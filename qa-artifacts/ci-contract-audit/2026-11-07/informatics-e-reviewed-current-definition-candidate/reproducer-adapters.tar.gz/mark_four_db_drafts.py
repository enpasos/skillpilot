from pathlib import Path
import json,hashlib,copy,gzip,difflib,io,tarfile
R=Path('/home/enpasos/projects/skillpilot');W=Path(__file__).parent;O=W/'candidate';P=W/'pins';OUT=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-e-reviewed-current-definition-candidate';rel='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json';p=O/rel;h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();dump=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
assert h(p)=='f4a4575998460d819f34eec5bf906291b339a731740c64e35fa9a19ed5ae3e23';raw=p.read_bytes();(P/'f4-e-released-source.json.gz').write_bytes(gzip.compress(raw,mtime=0));before=json.loads(raw);after=copy.deepcopy(before);byid={g['id']:g for g in after['goals']}
materials={
'b86e8ab3-2c12-5b6b-b515-1e7d457c99c2':'Für den Fahrradverleih werden ER-Diagramm, Relationsschema und Beispieltabellen, eine SQL-Abfrage mit Join/Aggregation und ein Relationenalgebra-Ausdruck nur angekündigt; die konkreten Diagramm-, Schema-, Tabellen-, Abfrage- und Ausdrucksdaten fehlen.',
'd13e297f-505d-576a-9a86-11ab4d7896c9':'Für die klinischen Studiendaten werden ein ER-Diagramm mit schwachen/starken Entitäten, ein Relationsschema mit Schlüsseln, eine SQL-Unterabfrage mit Gruppierung und ein Relationenalgebra-Ausdruck nur angekündigt; die konkreten Aufgabenmaterialien fehlen.',
'd9892508-97b5-529e-9b9e-c4889fba2166':'Für das Konzertticketing werden ER-Diagramm, nicht vollständig normalisiertes Relationsschema, eine SQL-Abfrage mit mehreren Joins/Aggregationen und ein Relationenalgebra-Ausdruck nur angekündigt; die konkreten Modelle, Daten, Abfragen und Ausdrücke fehlen.',
'4e0668e3-edca-57f4-b258-df87f23d2b4e':'Für die Lieferkettenanalyse werden ER-Diagramm für Standorte/Lieferungen/Produkte, Relationsschema und Beispieltabellen, eine SQL-Abfrage mit Join/Gruppierung/Bedingung und ein Relationenalgebra-Ausdruck nur angekündigt; die konkreten Aufgabenmaterialien fehlen.'}
changes=[]
for id,reason in materials.items():
 e=byid[id]['examData'];assert 'coveredGoalIds'not in e and 'reviewStatus'not in e and 'reviewNote'not in e
 note='2026-11-07: Individueller Materialhold, deshalb draft. '+reason+' Die Lösung nennt allgemeine Erwartungen statt überprüfbarer Ergebnisse zu diesen fehlenden Eingaben. Keine Materialfreigabe. coveredGoalIds bleibt vollständig ABSENT/UNKNOWN; Vorbereitung begründet keine Coverage.'
 e['reviewStatus']='draft';e['reviewNote']=note;changes.append({'goalId':id,'title':byid[id]['title'],'fields':{'examData.reviewStatus':{'beforeAbsent':True,'after':'draft'},'examData.reviewNote':{'beforeAbsent':True,'after':note}},'coverageFieldRemainsAbsent':True})
changed=[]
for b,a in zip(before['goals'],after['goals']):
 if b!=a:
  x=copy.deepcopy(a);del x['examData']['reviewStatus'];del x['examData']['reviewNote'];assert x==b;changed.append(a['id'])
assert set(changed)==set(materials)
for id in ['ea2ce31f-a0c7-5102-9213-ee1db5b2d475','c24236b2-d783-53be-84d5-96b4f4ef8159','6aa77baf-a199-5c66-b07c-8dc23439acca']:assert byid[id]['examData']['reviewStatus']=='released'
for id in ['309d4587-8080-5dd4-b329-785d9996a195','7aec2086-2cfa-50d3-8503-b40e96ca3430','3277867f-ede2-5dc4-bd76-1b03d992e9d5','357fde7c-d334-50aa-be11-068ae8d832b3','6ebc2a67-ea20-5c4e-8a63-635f40438d6a']:assert byid[id]['examData']['reviewStatus']=='draft'
assert sum('examData'in g and 'coveredGoalIds'not in g['examData'] for g in after['goals'])==10;dump(p,after)
proof={'kind':'Explicit separate four-DB material-hold metadata delta on the unchanged f4 E-released intermediate','f4SourceBeforeSha256':hashlib.sha256(raw).hexdigest(),'sourceAfterDb4StatusSha256':h(p),'changes':changes,'allFourEntireTaskSolutionScoringCoverageRequiresAndIdsUnchanged':True,'allTenCoverageFieldsRemainExactlyAbsentUnknown':True,'eThreeReleasedObjectsExactlyUnchanged':True,'fourOtherPlaceholdersAndOwn20StillDraft':True,'ownerAuthorization':'Root instruction in current session: mark exactly the four individually confirmed missing-material DB exams draft; no coverage/task invention','technicalGateCodeChanged':False,'originalF4IntermediatePreservedIn':'pins/f4-e-released-source.json.gz','activeSourceUnchangedSha256':h(R/rel)};dump(W/'db4-draft-status-difference.json',proof);dump(OUT/'db4-draft-status-difference.json',proof)
patch=''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True),p.read_text().splitlines(keepends=True),fromfile='f4-e-released/'+rel,tofile='db4-draft-status-successor/'+rel,n=2));(OUT/'db4-draft-status-only.patch').write_text(patch)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT)as t:
 for q in sorted(O.rglob('*')):
  if q.is_file():
   data=q.read_bytes();ti=tarfile.TarInfo(str(q.relative_to(O)));ti.size=len(data);ti.mtime=0;ti.mode=0o644;t.addfile(ti,io.BytesIO(data))
(OUT/'db4-draft-status-overlay.tar.gz').write_bytes(gzip.compress(buf.getvalue(),mtime=0));(OUT/'README.md').write_text(f'Privater Nachfolger in Vorbereitung. Erste getrennte Stufe f4a45759: ausschließlich drei unabhängig geprüfte E-Aufgaben released mit Reviewnotiz. Zweite ausdrücklich autorisierte Metadatenstufe {h(p)}: genau vier bisher statuslose UNKNOWN-Datenbankprüfungen wegen fehlender konkreter Materialien draft mit individuellen Notizen. F4-Overlay/Patch und Source85-Seals unverändert erhalten. Inhalte, Rubriken, Coverage, Voraussetzungen, IDs, Views und Mappings unverändert. Technischer Revisionsvertrag steht noch aus; noch keine Gatecodeänderung oder aktive Anwendung.\n');print(json.dumps({'source':h(p),'beforeF4':proof['f4SourceBeforeSha256'],'changedDbGoals':changed,'metadataOnly':True,'unknownCoverage':10,'eReleased':3,'draftMaterialHolds':9,'technicalCodeWork':False}))
