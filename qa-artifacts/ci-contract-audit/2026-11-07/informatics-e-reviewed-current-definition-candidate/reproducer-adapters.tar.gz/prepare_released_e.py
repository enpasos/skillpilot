from pathlib import Path
import json,gzip,tarfile,hashlib,io,copy
R=Path('/home/enpasos/projects/skillpilot');W=Path(__file__).parent;B=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-current-e-authoring-candidate';V=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-e-independent-review';OUT=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-e-reviewed-current-definition-candidate';O=W/'candidate';P=W/'pins';OUT.mkdir(exist_ok=True);O.mkdir(exist_ok=True);P.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());dump=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
assert h(V/'seal.json')=='6106e2c3149252c3d7f5f2408549e2b8574b78ac11ef3cb2691d52582a18e439';assert h(V/'review-result.json')=='71ec7653107de3c75b87b39369358911b3813baef7b1624e26d277fa407fc05d'
oldpins=[]
for root in [B,V]:
 inv=load(root/'inventory.json');assert h(root/'inventory.json')==load(root/'seal.json')['inventorySha256']
 for row in inv['payloads']:assert h(root/row['path'])==row['sha256']
 oldpins.extend({'path':str(p.relative_to(R)),'sha256':h(p)}for p in sorted(root.iterdir())if p.is_file())
source='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json'
with tarfile.open(B/'candidate-overlay.tar.gz','r:gz')as t:
 assert len(t.getmembers())==37
 for m in t.getmembers():assert m.isfile() and not Path(m.name).is_absolute() and '..'not in Path(m.name).parts
 t.extractall(O,filter='data')
assert h(O/source)=='85ed339482b57f9ea19661df76acce4403ca5b7b9b9727261c1fffb1796dd48b';before=load(O/source);after=copy.deepcopy(before);ids=['ea2ce31f-a0c7-5102-9213-ee1db5b2d475','c24236b2-d783-53be-84d5-96b4f4ef8159','6aa77baf-a199-5c66-b07c-8dc23439acca'];byid={g['id']:g for g in after['goals']}
reviewPath=str((V/'review-result.json').relative_to(R));reviewSha=h(V/'review-result.json');reviewSeal=h(V/'seal.json');note=f'2026-11-07: Lokal fachlich freigegeben nach unabhängigem KI-Material- und Scopereview durch /root/informatics_e_independent_review. Beleg: {reviewPath} (SHA256 {reviewSha}; Review-Seal-SHA256 {reviewSeal}), geprüfter Source85ed339482b57f9ea19661df76acce4403ca5b7b9b9727261c1fffb1796dd48b. Gilt ausschließlich für diese vollständige lokale E-Aufgabe im geprüften HE-kompatiblen eigenen Angebot und dessen technischen Own-GK/LK-Views. Keine vollständige amtliche E-Abdeckung, Gesamtfreigabe des Informatikstands, Human-, Host- oder Produktionsabnahme.'
for id in ids:
 e=byid[id]['examData'];assert e['reviewStatus']=='draft' and 'reviewNote'not in e;e['reviewStatus']='released';e['reviewNote']=note
for id in ['309d4587-8080-5dd4-b329-785d9996a195','7aec2086-2cfa-50d3-8503-b40e96ca3430','3277867f-ede2-5dc4-bd76-1b03d992e9d5','357fde7c-d334-50aa-be11-068ae8d832b3','6ebc2a67-ea20-5c4e-8a63-635f40438d6a']:assert byid[id]['examData']['reviewStatus']=='draft'
changed=[]
for b,a in zip(before['goals'],after['goals']):
 assert b['id']==a['id']
 if b!=a:
  x=copy.deepcopy(a);x['examData']['reviewStatus']='draft';del x['examData']['reviewNote'];assert x==b;changed.append({'goalId':a['id'],'fields':{'examData.reviewStatus':{'before':'draft','after':'released'},'examData.reviewNote':{'beforeAbsent':True,'after':note}}})
assert len(changed)==3;dump(O/source,after)
# All37 overlay members retain exact bytes except this single canonical source.
baselinefiles=[]
with tarfile.open(B/'candidate-overlay.tar.gz','r:gz')as t:
 for m in t.getmembers():
  old=t.extractfile(m).read();same=(O/m.name).read_bytes()==old;assert same or m.name==source;baselinefiles.append({'path':m.name,'source85Sha256':hashlib.sha256(old).hexdigest(),'afterSha256':h(O/m.name),'unchanged':same})
proof={'kind':'Exactly three independently reviewed current E definitions released; existing reviewNote field only, no technical definition policy changed yet','source85BeforeSha256':'85ed339482b57f9ea19661df76acce4403ca5b7b9b9727261c1fffb1796dd48b','releasedSourceSha256':h(O/source),'reviewResultPath':reviewPath,'reviewResultSha256':reviewSha,'reviewSealSha256':reviewSeal,'changes':changed,'overlayFiles':baselinefiles,'materialsRubricsPointsCoveragePrerequisitesIdsViewsAndMappingFieldsExactlyUnchanged':True,'ordinaryDefinitionsUnchanged':True,'allTenUnknownContractsRemainAbsentUnknown':True,'fourOtherPlaceholdersAndOwn20RemainDraft':True,'technicalDefinitionsContract':'WAITING_FOR_INDEPENDENT_ASTRA_CONTRACT; no dependent implementation yet','activeSourceUnchangedSha256':h(R/source),'oldPackageFilePins':oldpins,'dbGitDeploymentOrActiveWrites':False}
assert proof['activeSourceUnchangedSha256']=='85411185514af4b2ecf818807f3bd6fe5df17fb5011c5ebf8c4996de1a47817e';dump(W/'released-source-difference.json',proof);dump(OUT/'released-source-difference.json',proof);dump(P/'before-current-frame.json',{'oldPackageFiles':oldpins,'activeSourceSha256':h(R/source)})
for name in ['review-result.json','seal.json','inventory.json']:(P/('independent-'+name)).write_bytes((V/name).read_bytes())
# Reviewable exact status-only source overlay; no code mutation beyond inherited Source85 private profile bytes.
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT)as t:
 for row in baselinefiles:
  data=(O/row['path']).read_bytes();ti=tarfile.TarInfo(row['path']);ti.size=len(data);ti.mtime=0;ti.mode=0o644;t.addfile(ti,io.BytesIO(data))
(OUT/'released-status-only-overlay.tar.gz').write_bytes(gzip.compress(buf.getvalue(),mtime=0));(OUT/'README.md').write_text(f'Privater Nachfolger in Vorbereitung. Ausschließlich drei unabhängig geprüfte E-Aufgaben sind gegenüber Source85 released und erhalten die konkrete Reviewnotiz. Statussource {h(O/source)}. Material-/Coverage-/Voraussetzungs-/View-/Mappingbytes bleiben unverändert; vier Platzhalter und Own20 bleiben draft. Der konkrete technische Definitionsvertrag steht noch aus. Keine aktive Anwendung und keine Integrationsfreigabe.\n')
print(json.dumps({'package':str(OUT),'source85':proof['source85BeforeSha256'],'releasedSource':h(O/source),'changedGoals':len(changed),'exactFields':['examData.reviewStatus','examData.reviewNote'],'allOther37OverlayBytesUnchanged':True,'releaseNote':note,'waitingForTechnicalContract':True}))
