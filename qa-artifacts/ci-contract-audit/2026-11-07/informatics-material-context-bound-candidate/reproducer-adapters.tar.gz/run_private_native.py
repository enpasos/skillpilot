from pathlib import Path
import json,subprocess,sys,time,shutil
W=Path(__file__).parent;R=Path('/home/enpasos/projects/skillpilot');label=sys.argv[1];entry=sys.argv[2];N=W/'native-code';O=W/'candidate';(W/'test-tmp').mkdir(exist_ok=True)
for rel in ['app/scripts','contracts/curriculum-assessment-coverage']:
 if (O/rel).exists():shutil.copytree(O/rel,N/rel,dirs_exist_ok=True)
cmd=['bwrap','--die-with-parent','--unshare-net','--ro-bind','/','/','--proc','/proc','--dev','/dev','--tmpfs','/tmp','--ro-bind','/dev/shm','/dev/shm','--bind',str(W),str(W),'--bind',str(W/'test-tmp'),str(R/'tmp')]
for rel in ['app/scripts','app/src','contracts/curriculum-assessment-coverage']:cmd+=['--ro-bind',str(N/rel),str(R/rel)]
for p in sorted(O.rglob('*')):
 if p.is_file()and not str(p.relative_to(O)).startswith(('app/scripts/','contracts/curriculum-assessment-coverage/')):cmd+=['--ro-bind',str(p),str(R/p.relative_to(O))]
cmd+=['--setenv','TSX_DISABLE_CACHE','1','--setenv','TMPDIR','/tmp','--chdir',str(R),'--',str(R/'app/node_modules/.bin/tsx'),entry if entry.startswith('/')else str(W/entry)]
start=time.time();r=subprocess.run(cmd,capture_output=True,text=True);(W/(label+'.stdout')).write_text(r.stdout);(W/(label+'.stderr')).write_text(r.stderr);(W/(label+'.execution.json')).write_text(json.dumps({'label':label,'command':cmd,'start':start,'finished':time.time(),'exitCode':r.returncode},indent=2)+'\n');print(r.stdout[-12000:]);print(r.stderr[-6000:]);raise SystemExit(r.returncode)
