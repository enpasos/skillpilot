import {readFileSync,readdirSync,writeFileSync,mkdirSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {captureCurriculumSource,coverageSha256} from '/home/enpasos/projects/skillpilot/app/scripts/lib/retainedAssessmentCoverage.ts'
import {discoverCurriculumAssessmentScope,evaluateCurriculumExamReadiness,deriveCurriculumMaturity} from '/home/enpasos/projects/skillpilot/app/scripts/generateCurriculumQualityStatus.ts'
import {hasCompletePassingCurriculumExamReadiness} from '/home/enpasos/projects/skillpilot/app/scripts/lib/curriculumAssessmentValidation.ts'
import assert from 'node:assert/strict'
const R='/home/enpasos/projects/skillpilot',W='/dev/shm/curriculum-material-context-20261107',D=W+'/german-cases',path='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_DEUTSCH.de.json',id='2fb368b0-7b9d-5df0-99b6-6d719fd47f95';mkdirSync(D,{recursive:true})
const raw=readFileSync(R+'/'+path),original=JSON.parse(raw.toString()),catalog=readdirSync(R+'/curricula/DE/Gymnasium/canonical').filter(f=>f.endsWith('.json')&&!f.includes('_deck')).map(f=>captureCurriculumSource<any>('curricula/DE/Gymnasium/canonical/'+f,readFileSync(R+'/curricula/DE/Gymnasium/canonical/'+f))),prior=JSON.parse(readFileSync(W+'/prior-german-countercase/status.json','utf8')),policy=JSON.parse(readFileSync(W+'/prior-german-countercase/policy.json','utf8'))
const results=[];let freshBaseline:any
for(const mode of ['baseline','draft','missing-task','missing-solution','missing-scoring']){
 const s=structuredClone(original),e=s.goals.find((g:any)=>g.id===id).examData
 if(mode==='draft')e.reviewStatus='draft';if(mode==='missing-task')e.taskContent='';if(mode==='missing-solution')e.solutionContent='';if(mode==='missing-scoring')e.scoring.steps=[]
 const bytes=mode==='baseline'?raw:Buffer.from(JSON.stringify(s,null,2)+'\n'),source=captureCurriculumSource<any>(path,bytes),all=[source,...catalog.filter(c=>c.landscapeId!==source.landscapeId)],scope=discoverCurriculumAssessmentScope(source,undefined,all),readiness=evaluateCurriculumExamReadiness(source,undefined,all,scope),artifact=structuredClone(prior),row=artifact.curricula.find((r:any)=>r.landscapeId===source.landscapeId)
 row.rules=row.rules.map((r:any)=>readiness.find(x=>x.id===r.id)??r)
 assert.equal(scope.definitionGoalIds.length,17);assert.equal(scope.requiredGoalIds.length,17);assert.equal(scope.discoveryIssues.length,0);assert.equal(scope.retainedCoverage,undefined)
 const failures=readiness.map(r=>r.metrics!.weakExamData);assert.deepEqual(failures,mode==='baseline'?[0,0]:mode==='draft'?[0,1]:[1,1]);assert.equal(hasCompletePassingCurriculumExamReadiness(row.rules,source.landscapeId,scope),mode==='baseline')
 const derived=deriveCurriculumMaturity(row.rules,row.scopes,source.landscapeId,scope);assert.equal(derived,mode==='baseline'?'M6':'M3')
 writeFileSync(D+'/'+mode+'-source.json',bytes);writeFileSync(D+'/'+mode+'-native-artifact.json',JSON.stringify(artifact,null,2)+'\n')
 if(mode==='baseline')freshBaseline=structuredClone(artifact)
 const output={mode,sourceSha256:coverageSha256(bytes),scope,readiness,maturity:derived,consumerAccepted:mode==='baseline',rulesDerivedFromRealM6ReportWithoutGraphEdits:true};writeFileSync(D+'/'+mode+'-native.json.gz',gzipSync(JSON.stringify(output,null,2)+'\n'));results.push({mode,sourceSha256:output.sourceSha256,definitions:17,required:17,failures,maturity:derived,consumerAccepted:output.consumerAccepted})
}
writeFileSync(D+'/baseline-fresh-m6-artifact.json',JSON.stringify(freshBaseline,null,2)+'\n');writeFileSync(D+'/policy.json',JSON.stringify(policy,null,2)+'\n');writeFileSync(D+'/native-results.json',JSON.stringify({results,sourcePath:path,goalId:id,activeWrites:false,fullCqr:false},null,2)+'\n');console.log(JSON.stringify({results,actualGraphUnchanged:true,wholeCqrRun:false}))
