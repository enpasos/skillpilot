from pathlib import Path
O=Path(__file__).parent/'candidate'
p=O/'app/scripts/testCurriculumGraphMaturity.ts';s=p.read_text();s=s.replace("import type { SkillLandscape }", "import { captureCurriculumSource } from './lib/retainedAssessmentCoverage'\nimport type { SkillLandscape }",1);a=s.index('export const strictGraphFixtureAssessmentRules =');b=s.index('const expectedScopes =',a);s=s[:a]+'''const strictAssessmentSource = captureCurriculumSource<SkillLandscape>('fixtures/strict-maturity-fixture.json',
  JSON.stringify(landscape([goal(A, [B]), goal(B)])))
export const strictGraphFixtureAssessmentScope = discoverCurriculumAssessmentScope(strictAssessmentSource, [])
export const strictGraphFixtureAssessmentRules = evaluateCurriculumExamReadiness(
  strictAssessmentSource, [], [strictAssessmentSource], strictGraphFixtureAssessmentScope,
)
'''+s[b:];p.write_text(s)
p=O/'app/scripts/testCurriculumExamReadiness.ts';s=p.read_text();s=s.replace("import type { LearningGoal, SkillLandscape }", "import { captureCurriculumSource } from './lib/retainedAssessmentCoverage'\nimport type { LearningGoal, SkillLandscape }",1);s=s.replace("const load = (file: string): SkillLandscape => JSON.parse(readFileSync(resolve(canonical, file), 'utf8'))", "const load = (file: string): SkillLandscape => captureCurriculumSource('curricula/DE/Gymnasium/canonical/'+file, readFileSync(resolve(canonical, file)))\nconst capturedFixture = (source: SkillLandscape) => captureCurriculumSource<SkillLandscape>('fixtures/assessment/'+source.landscapeId+'.json', JSON.stringify(source))",1)
s=s.replace("Partial<NonNullable<LearningGoal['examData']>>) => ({", "Partial<NonNullable<LearningGoal['examData']>>) => capturedFixture({",1)
s=s.replace("const fullCore = (landscape: SkillLandscape, viewFiles: string[] = [], catalog = [landscape]) => {\n", "const fullCore = (landscape: SkillLandscape, viewFiles: string[] = [], catalog = [landscape]) => {\n  landscape = capturedFixture(landscape)\n",1)
s=s.replace('evaluateCurriculumExamReadiness(ownedCaseFixture, [])','evaluateCurriculumExamReadiness(capturedFixture(ownedCaseFixture), [])',1);p.write_text(s)
p=O/'app/scripts/testVisualizationContextMaturity.ts';s=p.read_text();s=s.replace("import type { LearningGoal, SkillLandscape }", "import { captureCurriculumSource } from './lib/retainedAssessmentCoverage'\nimport type { LearningGoal, SkillLandscape }",1);s=s.replace('const fixture: SkillLandscape = { ...source, goals:',"const fixture: SkillLandscape = captureCurriculumSource('fixtures/visualization-material.json', JSON.stringify({ ...source, goals:",1);s=s.replace('...routeClusters] }','...routeClusters] }))',1);p.write_text(s)
print('Connected shared graph/maturity, assessment and visualization fixtures to actual immutable source factory.')
