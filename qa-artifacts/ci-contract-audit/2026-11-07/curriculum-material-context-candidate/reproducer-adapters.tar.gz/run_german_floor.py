from pathlib import Path
import json,copy,hashlib,time,subprocess
R=Path('/home/enpasos/projects/skillpilot');W=Path(__file__).parent;D=W/'german-cases';P=W/'prior-german-countercase';F=W/'floor-cases';F.mkdir(exist_ok=True);path='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_DEUTSCH.de.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();fresh=json.loads((D/'baseline-fresh-m6-artifact.json').read_bytes());missing204=copy.deepcopy(fresh);missing202=copy.deepcopy(fresh);forged=copy.deepcopy(fresh)
for artifact,rid in [(missing204,'CQR-204'),(missing202,'CQR-202')]:
 for r in artifact['curricula'][0]['rules']:
  if r['id']==rid:del r['assessmentValidation']['sourceMaterialManifest']
for r in forged['curricula'][0]['rules']:
 if r['id']=='CQR-202':r['assessmentValidation']['sourceMaterialManifest']['frameDigest']='0'*64
for label,artifact in [('missing-204-manifest',missing204),('missing-202-manifest',missing202),('forged-frame-digest',forged)]: (F/(label+'.json')).write_text(json.dumps(artifact,indent=2)+'\n')
cases=[('fresh-native-german-M6-positive',D/'baseline-source.json',D/'baseline-fresh-m6-artifact.json',0),('old-german-report-missing-mandatory-binding',D/'baseline-source.json',P/'status.json',1),('exact-previous-draft-source-and-old-M6-falsepass',P/'draft-source.json',P/'status.json',1)]
for mode in ['draft','missing-task','missing-solution','missing-scoring']:cases.append((mode+'-source-with-fresh-baseline-M6',D/(mode+'-source.json'),D/'baseline-fresh-m6-artifact.json',1))
cases.append(('draft-source-with-honest-current-material-report',D/'draft-source.json',D/'draft-native-artifact.json',1))
for label in ['missing-204-manifest','missing-202-manifest','forged-frame-digest']:cases.append((label,D/'baseline-source.json',F/(label+'.json'),1))
cmd=['bwrap','--die-with-parent','--unshare-net','--ro-bind','/','/','--proc','/proc','--dev','/dev','--tmpfs','/tmp']
for rel in ['app/scripts','app/src','contracts/curriculum-assessment-coverage']:cmd+=['--ro-bind',str(W/'native-code'/rel),str(R/rel)]
for p in sorted((W/'candidate/curricula').rglob('*.json')):cmd+=['--ro-bind',str(p),str(R/p.relative_to(W/'candidate'))]
cmd+=['--ro-bind',str(D/'policy.json'),str(R/'app/scripts/config/curriculum-maturity-floor-policy.json')];records=[]
for label,source,artifact,expectedExit in cases:
 full=cmd+['--ro-bind',str(source),str(R/path),'--ro-bind',str(artifact),str(R/'docs/qa-ci/status/curriculum-quality-status.json'),'--setenv','TSX_DISABLE_CACHE','1','--setenv','TMPDIR','/tmp','--chdir',str(R),'--',str(R/'app/node_modules/.bin/tsx'),str(R/'app/scripts/checkCurriculumMaturityFloors.ts')]
 t=time.time();p=subprocess.run(full,capture_output=True,text=True);(F/(label+'.stdout')).write_text(p.stdout);(F/(label+'.stderr')).write_text(p.stderr);receipt={'label':label,'sourceFile':str(source.relative_to(W)),'sourceSha256':sha(source),'artifactFile':str(artifact.relative_to(W)),'artifactSha256':sha(artifact),'command':full,'startUnix':t,'endUnix':time.time(),'exitCode':p.returncode,'expectedExitCode':expectedExit,'assessmentFailurePresent':'no complete passing assessment reports'in p.stderr,'graphFailurePresent':'no complete passing strict graph-integrity report'in p.stderr,'noGraphReportEdits':True};(F/(label+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');records.append({k:v for k,v in receipt.items()if k!='command'});print(json.dumps(records[-1]),flush=True);assert p.returncode==expectedExit,p.stderr;assert not receipt['graphFailurePresent'],p.stderr
 if expectedExit:assert receipt['assessmentFailurePresent'],p.stderr
(F/'results.json').write_text(json.dumps({'status':'GERMAN_FRESH_M6_POSITIVE_AND_ALL_REQUIRED_MATERIAL_NEGATIVES_PASS','cases':records,'floorProgramUnmodified':True,'onlySourceMaterialViolationNeeded':True,'mainCiRegeneratesItsReports':True,'fullCqr':False,'activeWrites':False},indent=2)+'\n')
