from pathlib import Path
import json,hashlib,shutil,gzip
R=Path('/home/enpasos/projects/skillpilot');W=Path('/dev/shm/curriculum-material-context-20261107');W.mkdir(exist_ok=False);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-material-context-bound-candidate';V=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-material-context-independent-review'
assert h(P/'seal.json')=='157269c7eec4805477c50e9fdd92f67488742b7a0ae11344489baa9c1886b6e2';assert h(V/'seal.json')=='069ff6ca36b6a1c3f22ada543ea384d5d572506a1163e576b0f9b40ce23a3777'
parents={}
for d in [P,V]:
 inv=json.loads((d/'inventory.json').read_bytes());assert h(d/'inventory.json')==json.loads((d/'seal.json').read_bytes())['inventorySha256']
 for row in inv['payloads']:assert h(d/row['path'])==row['sha256']
 for p in d.rglob('*'):
  if p.is_file():parents[str(p.relative_to(R))]=h(p)
code={str(p.relative_to(R)):h(p)for folder in ['app/scripts','app/src','contracts/curriculum-assessment-coverage']for p in (R/folder).rglob('*')if p.is_file()};catalog={str(p.relative_to(R)):h(p)for p in(R/'curricula/DE/Gymnasium/canonical').glob('*.json')}
for folder in ['app/scripts','app/src','contracts/curriculum-assessment-coverage']:shutil.copytree(R/folder,W/'native-code'/folder)
(W/'candidate').mkdir();(W/'pins').mkdir();(W/'pins/parents.json').write_text(json.dumps(parents,indent=2)+'\n');(W/'pins/code-before.json.gz').write_bytes(gzip.compress(json.dumps(code).encode(),mtime=0));(W/'pins/catalog-before.json').write_text(json.dumps(catalog,indent=2)+'\n')
D=Path('/dev/shm/root-german-material-scope-countercase-20261107');shutil.copytree(D,W/'prior-german-countercase',ignore=shutil.ignore_patterns('tmp'))
for folder in ['app/scripts','contracts/curriculum-assessment-coverage']:shutil.copytree(W/'native-code'/folder,W/'candidate'/folder)
for rel in catalog:
 p=W/'candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,p)
shutil.copyfile('/dev/shm/informatics-material-context-20261107/run_private_native.py',W/'run_private_native.py')
print(json.dumps({'work':str(W),'codeInputs':len(code),'catalogInputs':len(catalog),'parentFiles':len(parents)}))
