from pathlib import Path
import json,gzip,hashlib,subprocess,time,copy
R=Path('/home/enpasos/projects/skillpilot');W=Path(__file__).parent;V=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-current-code-independent-review';D=W/'info-h1-floor-cases';D.mkdir(exist_ok=True);h=lambda b:hashlib.sha256(b).hexdigest();owner='7d51b38c-a149-5407-bddc-d2ce7878b020'
policy=json.loads((V/'bounded-real-info-floor-policy.json').read_bytes());assert len(policy['floors'])==1 and policy['floors'][0]['landscapeId']==owner and policy['floors'][0]['minimumMaturity']=='M6';(D/'policy.json').write_bytes((V/'bounded-real-info-floor-policy.json').read_bytes())
native=json.loads(gzip.decompress((W/'native-current-producer.json.gz').read_bytes()));assert native['sourceSha256']=='50a26163a1934216727ee178f8b0d2740c2476f62482ce32911fecbf890654e8';assert [r['metrics']['weakExamData']for r in native['readiness']]==[8,9];m=native['scope']['retainedCoverage']['manifest'];assert [len(m['sourceMaterialFailures'][k])for k in ['structureGoalIds','readinessGoalIds']]==[8,9]
row=policy['floors'][0];base={'curricula':[{'landscapeId':owner,'frameworkId':row['frameworkId'],'subject':row['subject'],'maturity':'M6','rules':[native['graph'],*native['readiness']]}]}
def graph(a):
 r=a['curricula'][0]['rules'][0];r['status']='pass';r['details']=[];g=r['graphIntegrity'];g['ok']=True;g['findings']=[]
 for c in g['checks']:c['findingCount']=0;c['status']='pass'
 for k in ['findings','localRedundancies','transitiveRedundancies']:g['metrics'][k]=0
 return a
def material(a,clear=False,remove=False):
 for r in a['curricula'][0]['rules'][1:]:
  r['status']='pass';r['details']=[];r['metrics']['weakExamData']=0;r['metrics']['discoveryIssues']=0;r['assessmentValidation']['failingGoalIds']=[];r['assessmentValidation']['discoveryIssues']=[]
  if clear:r['assessmentValidation']['retainedCoverageManifest']['sourceMaterialFailures']={'structureGoalIds':[],'readinessGoalIds':[]}
  if remove:del r['assessmentValidation']['retainedCoverageManifest']['sourceMaterialFailures']
 return a
labels=['graph-shaped-pass-with-honest-material','honest-graph-with-forged-material','passing-shaped-graph-with-forged-material']
cases=[('exact-prior-'+label,json.loads((V/(label+'.json')).read_bytes()))for label in labels]
cases.extend([('fresh-honest-material-pass-shaped-graph',graph(copy.deepcopy(base))),('fresh-forged-material-honest-graph',material(copy.deepcopy(base))),('fresh-forged-material-pass-shaped-graph',material(graph(copy.deepcopy(base)))),('fresh-forged-material-and-manifest-zeroes',material(graph(copy.deepcopy(base)),clear=True)),('fresh-forged-material-and-missing-manifest',material(graph(copy.deepcopy(base)),remove=True))])
cmd=['bwrap','--die-with-parent','--unshare-net','--ro-bind','/','/','--proc','/proc','--dev','/dev','--tmpfs','/tmp']
for rel in ['app/scripts','app/src','contracts/curriculum-assessment-coverage']:cmd+=['--ro-bind',str(W/'native-code'/rel),str(R/rel)]
for p in sorted((W/'candidate').rglob('*')):
 if p.is_file() and not str(p.relative_to(W/'candidate')).startswith(('app/scripts/','contracts/curriculum-assessment-coverage/')):cmd+=['--ro-bind',str(p),str(R/p.relative_to(W/'candidate'))]
cmd+=['--ro-bind',str(D/'policy.json'),str(R/'app/scripts/config/curriculum-maturity-floor-policy.json')];records=[]
for label,artifact in cases:
 file=D/(label+'.json');file.write_text(json.dumps(artifact,indent=2)+'\n');full=cmd+['--ro-bind',str(file),str(R/'docs/qa-ci/status/curriculum-quality-status.json'),'--setenv','TSX_DISABLE_CACHE','1','--setenv','TMPDIR','/tmp','--chdir',str(R),'--',str(R/'app/node_modules/.bin/tsx'),str(R/'app/scripts/checkCurriculumMaturityFloors.ts')]
 t=time.time();p=subprocess.run(full,capture_output=True,text=True);(D/(label+'.stdout')).write_text(p.stdout);(D/(label+'.stderr')).write_text(p.stderr);receipt={'label':label,'command':full,'startUnix':t,'endUnix':time.time(),'exitCode':p.returncode,'accepted':p.returncode==0,'artifactSha256':h(file.read_bytes()),'stdoutSha256':h(p.stdout.encode()),'stderrSha256':h(p.stderr.encode()),'actualFreshCapturedSource':native['sourceSha256'],'unchangedFloorProgram':True,'assessmentFailurePresent':'no complete passing assessment reports'in p.stderr,'graphFailurePresent':'no complete passing strict graph-integrity report'in p.stderr};(D/(label+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');records.append({k:v for k,v in receipt.items()if k!='command'});print(json.dumps(records[-1]),flush=True);assert p.returncode==1 and receipt['assessmentFailurePresent'],p.stderr
(D/'results.json').write_text(json.dumps({'status':'ALL_PRIOR_AND_FRESH_READINESS_FORGERIES_REJECTED','cases':records,'sourceSha256':native['sourceSha256'],'sourceMaterialFailures':m['sourceMaterialFailures'],'fullCqr':False,'sourceAProbes':False},indent=2)+'\n')
