from pathlib import Path
W=Path(__file__).parent;O=W/'candidate';hp=O/'app/scripts/lib/retainedAssessmentCoverage.ts';gp=O/'app/scripts/generateCurriculumQualityStatus.ts';cp=O/'app/scripts/lib/curriculumAssessmentValidation.ts';h=hp.read_text();g=gp.read_text();c=cp.read_text()
h=h.replace("export interface RetainedCoverageContext { readonly manifest: RetainedCoverageManifest }", """export interface RetainedCoverageContext { readonly manifest: RetainedCoverageManifest }
export interface CurriculumSourceMaterialManifest {
  contractVersion: 'curriculum-source-assessment-material-v1'
  owner: string
  source?: CapturedSource
  frameDigest: string
  definitionGoalIds: string[]
  requiredGoalIds: string[]
  discoveryIssues: string[]
  sourceMaterialFailures: RetainedCoverageManifest['sourceMaterialFailures']
  views: Array<{ path: string; sha256: string }>
}
export interface CurriculumSourceMaterialContext { readonly manifest: CurriculumSourceMaterialManifest }""",1)
h=h.replace("const contexts = new WeakMap<object, { owner:","const contexts = new WeakMap<object, { kind: 'retained' | 'material'; discoveryIssues?: readonly string[]; owner:",1)
h=h.replace("if (parsed.landscapeId === RETAINED_INFO_OWNER) freeze(parsed)","if (typeof parsed.landscapeId === 'string' && Array.isArray(parsed.goals)) freeze(parsed)",1)
h=h.replace("&& typeof value === 'object' && contexts.has(value)","&& typeof value === 'object' && contexts.get(value)?.kind === 'retained'",1)
anchor='/** Only these exact fields are nonsemantic'
insert="""/** Ordinary curriculum material authority uses the same capture, immutable
 * context store and readiness engine, without any Informatics history policy.
 * Its scope inputs are the results of native discovery; failures are never an
 * input. A noncaptured mutable object cannot establish a passing authority. */
export function createCurriculumSourceMaterialContext(landscape: SkillLandscape,
  definitionGoalIds: readonly string[], requiredGoalIds: readonly string[], discoveryIssues: readonly string[],
  viewFiles: readonly string[], viewFrame?: ReadonlyMap<string, Buffer>): CurriculumSourceMaterialContext | undefined {
  if (landscape.landscapeId === RETAINED_INFO_OWNER) return
  const source = captures.get(landscape)
  const issues = [...discoveryIssues]
  if (!source || source.owner !== landscape.landscapeId || !Object.isFrozen(landscape)) issues.push('expected-context-missing: current source was not immutably captured')
  const byId = new Map(landscape.goals.map(goal => [goal.id, goal]))
  const failures = (ids: readonly string[], ready: boolean) => sorted(ids.filter(id => {
    const goal = byId.get(id)
    return !goal || concreteExamReadinessIssues(goal, ready).length > 0
  }))
  const sourceMaterialFailures = { structureGoalIds: failures(definitionGoalIds, false), readinessGoalIds: failures(requiredGoalIds, true) }
  const views = viewFiles.map(path => {
    try { return { path, sha256: coverageSha256(viewFrame?.get(path) ?? readFileSync(path)) } }
    catch { issues.push(`current-frame-invalid: ${path}`); return { path, sha256: '' } }
  })
  const manifest: CurriculumSourceMaterialManifest = { contractVersion: 'curriculum-source-assessment-material-v1', owner: landscape.landscapeId,
    ...(source ? { source } : {}), frameDigest: coverageSha256(stableCoverageJson({ source: source ?? null, views, definitionGoalIds, requiredGoalIds,
      discoveryIssues: sorted(issues), sourceMaterialFailures })), definitionGoalIds: [...definitionGoalIds], requiredGoalIds: [...requiredGoalIds],
    discoveryIssues: sorted(issues), sourceMaterialFailures, views }
  const context = freeze({ manifest })
  contexts.set(context, { kind: 'material', owner: landscape.landscapeId, source, definitions: [...definitionGoalIds], required: [...requiredGoalIds],
    discoveryIssues: [...discoveryIssues], materialFailures: sourceMaterialFailures })
  return context
}
export const isTrustedCurriculumSourceMaterialContext = (value: unknown): value is CurriculumSourceMaterialContext =>
  value !== null && typeof value === 'object' && contexts.get(value)?.kind === 'material'
export function sourceMaterialContextMatchesSource(context: unknown, source: SkillLandscape): boolean {
  if (!isTrustedCurriculumSourceMaterialContext(context)) return false
  const expected = contexts.get(context)!.source, actual = captures.get(source)
  return !!expected && !!actual && same(expected, actual)
}
export function sourceMaterialContextMatchesScope(context: unknown, owner: string, definitions: readonly string[], required: readonly string[], issues: readonly string[]): boolean {
  if (!isTrustedCurriculumSourceMaterialContext(context)) return false
  const frame = contexts.get(context)!
  return !!frame.source && frame.owner === owner && same(frame.definitions, definitions) && same(frame.required, required)
    && same(frame.discoveryIssues, issues) && same(frame.materialFailures, context.manifest.sourceMaterialFailures)
}

"""
assert h.count(anchor)==1;h=h.replace(anchor,insert+anchor,1);h=h.replace("contexts.set(context, { owner: landscape.landscapeId","contexts.set(context, { kind: 'retained', owner: landscape.landscapeId",1)
g=g.replace('retainedContextMatchesSource, concreteExamReadinessIssues','retainedContextMatchesSource, concreteExamReadinessIssues, createCurriculumSourceMaterialContext, isTrustedCurriculumSourceMaterialContext, sourceMaterialContextMatchesSource',1)
g=g.replace('  return Object.freeze({ landscapeId: landscape.landscapeId, ...(retainedCoverage ? { retainedCoverage } : {}),',"  const sourceMaterialContext = createCurriculumSourceMaterialContext(landscape, definitionGoalIds, requiredGoalIds, issues, files, assessmentInputFrame)\n  return Object.freeze({ landscapeId: landscape.landscapeId, ...(retainedCoverage ? { retainedCoverage } : {}), ...(sourceMaterialContext ? { sourceMaterialContext } : {}),",1)
g=g.replace('    const allIssues = [...issues, ...retainedIssues]',"""    const material = expectedScope.sourceMaterialContext
    const materialIssues = landscape.landscapeId === RETAINED_INFO_OWNER ? []
      : isTrustedCurriculumSourceMaterialContext(material) ? [...material.manifest.discoveryIssues,
        ...(sourceMaterialContextMatchesSource(material, landscape) ? [] : ['current-frame-invalid: producer source differs from captured material context'])]
        : ['expected-context-missing: source material context']
    const allIssues = [...new Set([...issues, ...retainedIssues, ...materialIssues])]""",1)
g=g.replace("...(retained ? { retainedCoverageManifest: structuredClone(retained.manifest) } : {}) }","...(retained ? { retainedCoverageManifest: structuredClone(retained.manifest) } : {}),\n      ...(material ? { sourceMaterialManifest: structuredClone(material.manifest) } : {}) }",1)
c=c.replace('type RetainedCoverageContext, type RetainedCoverageManifest','isTrustedCurriculumSourceMaterialContext, sourceMaterialContextMatchesScope, type CurriculumSourceMaterialContext, type CurriculumSourceMaterialManifest,\n  type RetainedCoverageContext, type RetainedCoverageManifest',1)
c=c.replace('  readonly retainedCoverage?: RetainedCoverageContext','  readonly sourceMaterialContext?: CurriculumSourceMaterialContext\n  readonly retainedCoverage?: RetainedCoverageContext',1)
c=c.replace('  retainedCoverageManifest?: RetainedCoverageManifest','  sourceMaterialManifest?: CurriculumSourceMaterialManifest\n  retainedCoverageManifest?: RetainedCoverageManifest',1)
anchor='  const definitions = expected.definitionGoalIds'
insert="""  const material = expected.sourceMaterialContext
  if (landscapeId !== RETAINED_INFO_OWNER && (!isTrustedCurriculumSourceMaterialContext(material)
    || !sourceMaterialContextMatchesScope(material, landscapeId, expected.definitionGoalIds, expected.requiredGoalIds, expected.discoveryIssues)
    || material.manifest.discoveryIssues.length !== 0
    || material.manifest.sourceMaterialFailures.structureGoalIds.length !== 0
    || material.manifest.sourceMaterialFailures.readinessGoalIds.length !== 0)) return false
"""
assert c.count(anchor)==1;c=c.replace(anchor,insert+anchor,1)
anchor="    const checked = kind === 'structure' ? definitions : required"
insert="""    if (landscapeId !== RETAINED_INFO_OWNER
      && (!isTrustedCurriculumSourceMaterialContext(material)
        || stableCoverageJson(manifest?.sourceMaterialManifest) !== stableCoverageJson(material.manifest))) return false
"""
assert c.count(anchor)==1;c=c.replace(anchor,insert+anchor,1)
hp.write_text(h);gp.write_text(g);cp.write_text(c)
print('Ordinary curricula receive mandatory authenticated source-material binding; Info history/revision remains separate.')
