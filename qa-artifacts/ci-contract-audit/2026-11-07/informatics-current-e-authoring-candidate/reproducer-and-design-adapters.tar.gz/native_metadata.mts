import {readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {captureCurriculumSource} from '/home/enpasos/projects/skillpilot/app/scripts/lib/retainedAssessmentCoverage.ts';
import {discoverCurriculumAssessmentScope,evaluateCurriculumExamReadiness,routeProfiles} from '/home/enpasos/projects/skillpilot/app/scripts/generateCurriculumQualityStatus.ts';
const R='/home/enpasos/projects/skillpilot',W='/dev/shm/informatics-current-e-authoring-20261107';
const catalog=readdirSync(R+'/curricula/DE/Gymnasium/canonical').filter(x=>x.endsWith('.de.json')).sort().map(x=>{const p='curricula/DE/Gymnasium/canonical/'+x;return captureCurriculumSource<any>(p,readFileSync(R+'/'+p));});
const info=catalog.find(x=>x.landscapeId==='7d51b38c-a149-5407-bddc-d2ce7878b020')!,goals=new Map(info.goals.map((g:any)=>[g.id,g])),pins=JSON.parse(readFileSync(W+'/pins/bootstrap.json','utf8'));
const discovery=discoverCurriculumAssessmentScope(info,undefined,catalog),readiness=evaluateCurriculumExamReadiness(info,undefined,catalog);
assert.equal(discovery.definitionGoalIds.length,22);assert.equal(discovery.requiredGoalIds.length,22);assert.deepEqual(discovery.discoveryIssues,[]);
for(const check of readiness){assert.equal(check.assessmentValidation.checkedGoalIds.length,22);assert.equal(check.status,'fail');for(const id of pins.draftIds)assert(check.assessmentValidation.checkedGoalIds.includes(id));}
for(const id of pins.draftIds)assert.equal((goals.get(id) as any).examData.reviewStatus,'draft');
const profile=routeProfiles.find(p=>p.profileId==='canonical-informatics-crossstage')!;
assert(profile.terminalAutonomyClusterIds.includes(pins.q2Root));assert(!profile.terminalAutonomyClusterIds.includes('010651ba-ddd0-510b-8ed1-e3610031f6e1'));
// Exact selection expression used by existing evaluateRouteProfile, no new route engine.
const selectedTerminals=profile.terminalAutonomyClusterIds.flatMap(id=>(goals.get(id) as any)?.contains??[]).map(id=>goals.get(id)).filter((g:any)=>!!g).filter((g:any)=>(g.contains?.length??0)===0&&!g.tags?.includes('Memory'));
assert(selectedTerminals.some((g:any)=>g.id===pins.own20Id));
const own=goals.get(pins.own20Id) as any;assert.equal(own.extendedData.offeringAuthority.officialStateDuty,false);
const assessments=info.goals.filter((g:any)=>g.examData).map((g:any)=>({id:g.id,reviewStatus:g.examData.reviewStatus,coverageState:Object.hasOwn(g.examData,'coveredGoalIds')?'DECLARED':'ABSENT_UNKNOWN'}));
assert.equal(assessments.filter((x:any)=>x.coverageState==='DECLARED').length,12);assert.equal(assessments.filter((x:any)=>x.coverageState==='ABSENT_UNKNOWN').length,10);
const out={kind:'Focused actual native metadata successor reader; all current definitions remain hard-checked despite draft status',sourceSha256:createHash('sha256').update(readFileSync(R+'/curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json')).digest('hex'),assessments,discovery,readiness,profile:{id:profile.profileId,terminalAutonomyClusterIds:profile.terminalAutonomyClusterIds,selectedTerminalIds:selectedTerminals.map((g:any)=>g.id),own20Selected:true,officialStateDuty:false},noFullCqr:true};
writeFileSync(W+'/native-metadata.json.gz',gzipSync(JSON.stringify(out,null,2)+'\n'));
console.log(JSON.stringify({source:out.sourceSha256,definitions:22,required:22,checked:readiness.map(x=>({id:x.id,count:x.assessmentValidation.checkedGoalIds.length,status:x.status,metrics:x.metrics})),discoveryIssues:discovery.discoveryIssues,own20ProfileSelected:true}));
