from pathlib import Path
import json,gzip,tarfile,hashlib,shutil,difflib
R=Path('/home/enpasos/projects/skillpilot');W=Path(__file__).parent;B=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-current-source-ref-cleanup-candidate';O=W/'candidate';P=W/'pins';P.mkdir(exist_ok=True);O.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());gz=lambda p,d:p.write_bytes(gzip.compress((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
inv=load(B/'inventory.json');assert h(B/'inventory.json')==load(B/'seal.json')['inventorySha256']
for row in inv['payloads']:assert h(B/row['path'])==row['sha256']
with tarfile.open(B/'candidate-overlay.tar.gz','r:gz') as t:
 assert len(t.getmembers())==37
 for m in t.getmembers():assert m.isfile() and '..' not in Path(m.name).parts and not Path(m.name).is_absolute()
 t.extractall(O,filter='data')
source='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json';assert h(O/source)=='d163550987320c6c8667fde4782a40ed4308525b8b9f025fcfc7fd6d70591d9c'
basePins=[{'path':str(p.relative_to(O)),'sha256':h(p)} for p in sorted(O.rglob('*')) if p.is_file()]
# Snapshot all native catalogue inputs. Keep only changed files in the durable overlay later.
catalog=[]
for p in sorted((R/'curricula/DE/Gymnasium/canonical').glob('*.de.json')):
 rel=p.relative_to(R);q=O/rel
 if not q.exists():q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 catalog.append({'path':str(rel),'activeSha256':h(p),'effectiveBeforeMetadataSha256':h(q)})
assert len(catalog)==21
info=load(O/source);goals={g['id']:g for g in info['goals']};ids=['309d4587-8080-5dd4-b329-785d9996a195','fa47a714-07c3-589b-a4e2-385a33e84c79','7aec2086-2cfa-50d3-8503-b40e96ca3430','3277867f-ede2-5dc4-bd76-1b03d992e9d5','357fde7c-d334-50aa-be11-068ae8d832b3']
for i in ids:assert goals[i]['examData']['reviewStatus']=='released';goals[i]['examData']['reviewStatus']='draft'
(O/source).write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')
codeRel='app/scripts/generateCurriculumQualityStatus.ts';code=(O/codeRel).read_text();anchor="  '6982b63a-c6c8-5a6f-b5cb-51568301ac1c',\n";assert code.count(anchor)==1 and '010651ba-ddd0-510b-8ed1-e3610031f6e1' not in code
q2='66630624-08b1-5d02-8544-877d0ffb12c9';own='6ebc2a67-ea20-5c4e-8a63-635f40438d6a';assert goals[q2]['contains']==[own];assert goals[own]['extendedData']['offeringAuthority']['officialStateDuty'] is False
code=code.replace(anchor,anchor+"  '"+q2+"',\n");(O/codeRel).write_text(code)
spec=json.load(gzip.open(B/'five-new-route-need-material-specifications.json.gz','rt'));ep='curricula/DE/Gymnasium/input/SL/lower-secondary/source-extraction/DE_SL_INFORMATIK_SEKI_GYM9_2023_2026.source-extraction.json';ex=load(R/ep);doc=next(d for d in ex['sourceDocuments'] if d['key']=='SL-INF-GYM9-10-2026');passage=next(p for p in ex['passages'] if p['id']=='de-sl-informatik:sl-inf-10-llm');actual=next(p for p in ex['sourceGoals'] if p['sourceSpan']=='SL-INF-SEKI-10-LLM.1');corrections=[]
for route in spec['fourColumnRows']:
 for atom in route['fourColumnAtomInventory']:
  for association in atom['authorityOrNamedDidacticGap']['primaryAssociations']:
   if association['sourcePath']==ep and association['sourceSpan']=='SL-INF-SEKI-10-LLM.1':
    assert association['sourceGoalId']==actual['id'];assert association['sourceDocument']['key']=='SL-INF-GYM9-7-2023';before=association['sourceDocument'];association['sourceDocument']=doc.copy();association['evidenceStatus']='Existing passage-specific Klasse10 association, corrected from actual registered extraction document; local earlier web-extract only, no fresh original whole-PDF verification or universal HE/DE duty.';corrections.append({'goalId':atom['goalId'],'sourceGoalId':actual['id'],'before':before,'after':doc})
assert corrections
# Inventory remains an unapproved need/material inventory, not a released task bank.
spec['sourceSha256']=h(O/source)
for row in spec['fourColumnRows']:row['fullRouteGoal']=goals[row['prospectiveNewGoalId']]
spec['metadataSuccessor']={'baselineInventorySha256':h(B/'five-new-route-need-material-specifications.json.gz'),'corrections':corrections,'class10Evidence':{'extractionPath':ep,'extractionSha256':h(R/ep),'registeredDocument':doc,'localPassageTextSha256':h(R/doc['path']),'actualSourceGoal':actual,'actualPassage':passage,'freshWholeOriginalPdfVerification':False,'generalHeOrDeDuty':False},'fiveProspectiveExamReviewStatus':'draft','draftDoesNotSkipHardChecks':True}
gz(W/'five-route-need-material-inventory.json.gz',spec)
(P/'bootstrap.json').write_text(json.dumps({'baselinePackage':str(B.relative_to(R)),'baselineSealSha256':h(B/'seal.json'),'baselineInventorySha256':h(B/'inventory.json'),'baselineSourceSha256':'d163550987320c6c8667fde4782a40ed4308525b8b9f025fcfc7fd6d70591d9c','baseline37Files':basePins,'current21CatalogInputs':catalog,'metadataSourceSha256':h(O/source),'metadataCodeSha256':h(O/codeRel),'draftIds':ids,'q2Root':q2,'own20Id':own,'sourceDocumentCorrections':corrections,'activeSourceSha256':h(R/source)},ensure_ascii=False,indent=2)+'\n')
(P/'metadata-source.json').write_bytes((O/source).read_bytes());(P/'metadata-profile.ts').write_bytes((O/codeRel).read_bytes())
print(json.dumps({'source':h(O/source),'code':h(O/codeRel),'correctedInventoryAssociations':len(corrections),'catalog':len(catalog),'definitions':len(info['goals']),'exams':sum('examData'in g for g in info['goals'])}))
