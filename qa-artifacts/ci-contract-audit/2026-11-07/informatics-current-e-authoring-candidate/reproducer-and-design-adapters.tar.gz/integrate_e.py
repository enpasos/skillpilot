from pathlib import Path
import json,gzip,hashlib,copy,shutil
R=Path('/home/enpasos/projects/skillpilot');W=Path(__file__).parent;O=W/'candidate';D=R/'qa-artifacts/ci-contract-audit/2026-11-07/informatics-e-minimal-material-design';P=W/'pins';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());dump=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');gz=lambda p,d:p.write_bytes(gzip.compress((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
assert h(D/'design-receipt.json')=='bb752c90759b2c7dd56b243e97ff895e5f450896ecd058cd09d4be8fa50ebca8';receipt=load(D/'design-receipt.json');assert h(D/'inventory.json')==receipt['inventorySha256']=='da0abc2ff42044b23e6757aafe9dc4fe2948800f2fe591501febf699d2e34c19';di=load(D/'inventory.json')
for row in di['files']:assert h(D/row['path'])==row['sha256'],row['path']
for name in ['draft-goals.json','integration-contract.json','coverage-matrix.json','residual-ten.json','design-receipt.json','inventory.json','material-check-results.json','scope-check-results.json']:
 shutil.copyfile(D/name,P/('design-'+name))
contract=load(D/'integration-contract.json');drafts=load(D/'draft-goals.json');source='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_INFORMATIK.de.json';info=load(O/source);goals={g['id']:g for g in info['goals']};retired=set(contract['supersededCurrentAssessmentIds']);parent=goals[contract['parentPatch']['id']];patch=contract['parentPatch'];assert parent['contains']==patch['beforeContains'] and parent['requires']==patch['beforeRequires'] and parent['weight']==patch['beforeWeight']
info['goals']=[g for g in info['goals'] if g['id'] not in retired]+copy.deepcopy(drafts)
parent['contains']=patch['afterContains'];parent['requires']=patch['afterRequires'];parent['weight']=patch['afterWeight'];parent['applicability']=patch['afterApplicability'];parent['description']=patch['afterDescription'];parent['descriptionEn']=patch['afterDescriptionEn'];dump(O/source,info)
# Only this explicitly unqualified exam subtree leaves foreign views; ordinary targets are checked natively afterward.
viewchanges=[]
def remove_subtree(nodes,gid):
 result=[];count=0
 for node in nodes:
  if node.get('kind')=='canonicalSubtree' and node.get('goalId')==gid:count+=1;continue
  for key in ['children','rootNodes']:
   if isinstance(node.get(key),list):node[key],n=remove_subtree(node[key],gid);count+=n
  result.append(node)
 return result,count
for row in contract['viewDecisions']:
 p=O/row['path'];assert h(p)==row['sha256']
 if row['decision'].startswith('WITHHOLD'):
  d=load(p);d['rootNodes'],count=remove_subtree(d['rootNodes'],parent['id']);assert count==1,(row['path'],count);dump(p,d);viewchanges.append({'path':row['path'],'beforeSha256':row['sha256'],'afterSha256':h(p),'removedExactlyOneCanonicalSubtree':parent['id']})
assert len(viewchanges)==15
# A legacy snapshot author-assessment match is withdrawn, never rebound to new identities.
he='curricula/DE/Gymnasium/mapping/DE-HE/upper-secondary/hessen_informatics_upper_secondary_to_canonical_informatics.json';mp=O/he;m=load(mp);withdrawn=[row for row in m['mappings'] if row.get('canonicalGoalId') in retired];assert len(withdrawn)==1 and withdrawn[0]['canonicalGoalId']=='bb651ed7-2674-580c-8916-ac5aa88d93f8';m['mappings']=[row for row in m['mappings'] if row not in withdrawn];m.setdefault('historicalWithdrawnMappings',[]).extend(withdrawn);dump(mp,m)
# Keep all166 explicit ordinary inventory promises. Replace only the unqualified E route claim, leaving10 genuine open local routes visible.
spec=json.load(gzip.open(W/'five-route-need-material-inventory.json.gz','rt'));spec['sourceSha256']=h(O/source);coverage={g['id']:set(g['examData']['coveredGoalIds']) for g in drafts};allcovered=set.union(*coverage.values());assert len(allcovered)==15
for row in spec['fourColumnRows']:
 if row['phase']!='E':continue
 row['historicalPlanningRouteGoal']=row.pop('fullRouteGoal');row['supersededPlanningRouteId']=row.pop('prospectiveNewGoalId');row.pop('currentCoverageExactlyPreservedForPlanning',None);row['currentRouteGoalIds']=[g['id']for g in drafts];row['currentDraftRouteGoals']=drafts;row['currentMaterialGap']='Three concrete task/solution/rubric drafts now authored for15 ordinary goals;10 ordinary targets retain open local task/scope decisions. No whole E completion or independent approval.'
 row['needDecision']={'status':'Concrete own HE-compatible local materials for15/25 ordinary inventory goals;10 openly residual','all25OrdinaryDefinitionsUnchanged':True,'finalFullHeCurriculumProved':False,'universalStateDuty':False,'noBroad25AtomExamRequired':True,'independentMaterialReviewApproved':False}
 row['passingMeaning']={'status':'Each new task uses its own noncompensable binary criteria:12/12,10/10,12/12; no carried20/12 threshold','currentScoring':{g['id']:g['examData']['scoring']for g in drafts},'independentApproval':False,'oldResultsUpgraded':False}
 for atom in row['fourColumnAtomInventory']:
  ids=[i for i,c in coverage.items() if atom['goalId']in c];atom['currentAssessmentRoute']={'currentDraftGoalIds':ids,'status':'concrete local task authored; independent scope/material review pending'if ids else'OPEN_RESIDUAL_ORDINARY_TARGET_ROUTE','ordinaryGoalRetained':True,'supersededUnqualifiedBroadRoute':row['supersededPlanningRouteId'],'resultTransfer':False,'officialWholeStateDutyProved':False};atom['materialSpecification']['currentExecutableTaskAuthored']=bool(ids);atom['materialSpecification']['currentInputsAndCorrectSolutionAuthored']=bool(ids);atom['materialSpecification']['independentMaterialReviewApproved']=False
 row['currentResidualGoalIds']=[a['goalId']for a in row['fourColumnAtomInventory'] if a['goalId']not in allcovered]
 row['materialIntegrationAuthorizedByThisSpecification']=False
spec['kind']='Finite166 ordinary-target need/material inventory with current metadata correction and explicit E15 concrete authoring/10 residual split; not independent approval';spec['remainingHolds']=[s for s in spec['remainingHolds'] if not s.startswith('Complete executable material')];spec['remainingHolds']+=['Four other placeholders still lack actual complete materials; E three-task materials still need independent current-scope/material review.','All23 current definitions remain hard-checked, including drafts and nonoffered definitions.'];gz(W/'five-route-need-material-inventory.json.gz',spec)
# Exact delta ledger from the successfully checked metadata intermediate.
meta=load(P/'metadata-source.json');after={g['id']:g for g in info['goals']};before={g['id']:g for g in meta['goals']};changes=[]
for gid in sorted(set(before)|set(after)):
 b=before.get(gid);a=after.get(gid)
 if b!=a:changes.append({'goalId':gid,'before':b,'after':a})
assert len(changes)==6
proof={'designReceiptSha256':h(D/'design-receipt.json'),'designInventorySha256':h(D/'inventory.json'),'designAll25PayloadsVerified':len(di['files']),'metadataIntermediateSourceSha256':h(P/'metadata-source.json'),'finalSourceSha256':h(O/source),'examCountTransition':[22,23],'definitionCountTransition':[283,284],'retiredAssessmentDefinitions':sorted(retired),'newAssessmentDefinitions':[g['id']for g in drafts],'fullMetadataToEChanges':changes,'foreignViewWithdrawals':viewchanges,'heLegacyAuthorMappingWithdrawn':withdrawn,'parentLegacyMappingIsOnlyStructuralProvenance':True,'independentMaterialApproval':False}
gz(W/'e-authoring-changes.json.gz',proof)
print(json.dumps({'source':h(O/source),'sourceDefinitions':len(info['goals']),'exams':sum('examData'in g for g in info['goals']),'declared':sum('examData'in g and 'coveredGoalIds'in g['examData']for g in info['goals']),'foreignViewWithdrawals':len(viewchanges),'newExamIds':[g['id']for g in drafts]}))
