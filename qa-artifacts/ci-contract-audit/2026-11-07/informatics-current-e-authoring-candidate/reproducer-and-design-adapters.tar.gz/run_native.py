from pathlib import Path
import json,subprocess,time,sys
R=Path('/home/enpasos/projects/skillpilot');W=Path(__file__).parent;B=W;label=sys.argv[1];script=sys.argv[2]
cmd=['bwrap','--die-with-parent','--unshare-net','--ro-bind','/','/','--proc','/proc','--dev','/dev','--tmpfs','/tmp','--ro-bind','/dev/shm','/dev/shm','--bind',str(W),str(W)]
# Freeze the existing proven reader implementation, then apply exactly the private current route-profile delta.
for path in ['app/scripts','app/src','contracts/curriculum-assessment-coverage']:cmd+=['--ro-bind',str(B/'native-code'/path),str(R/path)]
for p in sorted((W/'candidate').rglob('*')):
 if p.is_file():cmd+=['--ro-bind',str(p),str(R/p.relative_to(W/'candidate'))]
cmd+=['--setenv','TSX_DISABLE_CACHE','1','--setenv','TMPDIR','/tmp','--chdir',str(R),'--',str(R/'app/node_modules/.bin/tsx'),str(W/script)]
start=time.time();p=subprocess.run(cmd,capture_output=True,text=True);(W/(label+'.stdout')).write_text(p.stdout);(W/(label+'.stderr')).write_text(p.stderr);(W/(label+'.execution.json')).write_text(json.dumps({'label':label,'command':cmd,'started':start,'finished':time.time(),'exitCode':p.returncode},indent=2)+'\n');print(p.stdout[-6500:]);print(p.stderr[-3000:]);raise SystemExit(p.returncode)
