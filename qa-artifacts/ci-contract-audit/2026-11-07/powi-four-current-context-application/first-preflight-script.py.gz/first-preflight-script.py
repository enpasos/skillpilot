from pathlib import Path
import json,hashlib,gzip,datetime,tempfile,os,shutil,sys
sys.dont_write_bytecode=True
repo=Path.cwd();base=repo/'qa-artifacts/ci-contract-audit/2026-11-07';technical=base/'powi-four-current-context-application-candidate';reviewdir=base/'powi-four-independent-application-review';out=base/'powi-four-current-context-application';out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def J(x):return (json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
rb=(reviewdir/'review.json').read_bytes();assert sha(rb)=='783abc4c36c4ceb66cc5bbaf4ff0f2a92d21bcecda689f494754a9ca257a9ac2';r=json.loads(rb);assert r['decision']=='support-exact-four-on-pinned-current-full-transitive-branch' and r['blockingFindingsForExactFour']==[]
inv=json.loads((technical/'inventory.json').read_text())
for e in inv['files']:assert sha((technical/e['path']).read_bytes())==e['sha256'] and (technical/e['path']).stat().st_size==e['bytes'],e['path']
m=json.loads((technical/'technical-proposal.json').read_text());pre=json.loads((technical/'preflight.json').read_text());comparison=json.loads((technical/'native-comparison.json').read_text());assert comparison['noNewFindingIdentityInAnyOf21Reports'];assert comparison['foreignGraphReportsUnchanged']==19
assert r['source']==m['source'];assert len(r['approvedOperations'])==len(m['operations'])==4
for ro,op in zip(r['approvedOperations'],m['operations']):
 for k,v in ro.items():assert op[k]==v,(k,op[k],v)
for p,h in pre['protectedInputHashes'].items():assert sha((repo/p).read_bytes())==h,p
safe=Path('/dev/shm/skillpilot-fixed74-argument-et0l77ka/sourcewrite-safe-point.json');assert safe.exists();sb=safe.read_bytes();sj=json.loads(sb)
# This explicit read-only snapshot was published by the active neighboring producer.
snapshot=Path('/dev/shm/skillpilot-fixed74-argument-et0l77ka/politikwirtschaft49.readonly.json');assert sha(snapshot.read_bytes())==m['source']['sha256'];assert snapshot.stat().st_mode&0o222==0
sys.path.insert(0,str(repo/'docs/dev/ci-graph-repairs'));import verify_german_minimality_review as core
source=repo/m['source']['path'];raw=source.read_bytes();assert sha(raw)==m['source']['sha256']=='49e68eedeac6a891a0327551bfbe7c9d31a44573d97b464b69b49d5023511c94';doc=json.loads(raw);after=json.loads(gzip.decompress((technical/'candidate.json.gz').read_bytes()));b=(json.dumps(after,ensure_ascii=False,indent=2)+'\n').encode();assert sha(b)==r['candidateSourceSha256']==m['candidateSourceSha256']=='29d02016b7e31b5683b1d51196e21c68ab4a310b8a88aa1a09bd5f30d1ee2eef'
expected=json.loads(raw)
for op in m['operations']:
 assert op['op']=='replace' and op['file']==m['source']['path'];parts=op['path'].split('/');assert parts[:2]==['','goals'] and parts[3]=='requires';g=expected['goals'][int(parts[2])];assert g['id']==op['guardGoalId'] and sha(core.stable(g))==op['guardGoalCanonicalSha256'] and g['requires']==op['guardRequiresBefore'];g['requires']=op['value']
assert expected==after;assert len(doc['goals'])==len(after['goals'])==512
held=m['heldCase']['goalId'];assert next(g for g in doc['goals'] if g['id']==held)==next(g for g in after['goals'] if g['id']==held)
policy=repo/'app/scripts/config/curriculum-maturity-floor-policy.json';ph=sha(policy.read_bytes());assert ph=='35e711cea5d5709093bddd53fc1fca91e30bf3c7bec906ca178ed6d8ff364cd7'
assert shutil.disk_usage(repo).free>len(b)+16*1024*1024
(out/'source.before.json.gz').write_bytes(gzip.compress(raw,mtime=0));(out/'neighbor-sourcewrite-safe-point.json').write_bytes(sb)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();fd,n=tempfile.mkstemp(prefix='.powi-four-private-',dir=source.parent)
with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
os.chmod(n,source.stat().st_mode&0o777);assert sha(source.read_bytes())==m['source']['sha256'];os.replace(n,source);fd=os.open(source.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
assert sha(source.read_bytes())==m['candidateSourceSha256']
for p,h in pre['protectedInputHashes'].items():
 if p!=m['source']['path']:assert sha((repo/p).read_bytes())==h,p
assert sha(policy.read_bytes())==ph;assert sha(snapshot.read_bytes())==m['source']['sha256']
receipt={'schemaVersion':1,'kind':'four-individually-reviewed-powi-redundant-intro-requirements-applied','startedAtActual':started,'completedAtActual':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourcePath':m['source']['path'],'beforeSha256':m['source']['sha256'],'afterSha256':m['candidateSourceSha256'],'independentReview':{'path':str((reviewdir/'review.json').relative_to(repo)),'sha256':sha(rb),'decision':r['decision']},'currentContextProof':{'path':str((technical/'native-comparison.json').relative_to(repo)),'sha256':sha((technical/'native-comparison.json').read_bytes())},'exactOperations':m['operations'],'onlyFourRequiresArraysChanged':True,'allOther508GoalObjectsAndAllNonRequiresFieldsUnchanged':True,'heldFifthWholeGoalUnchanged':True,'other20CanonicalSourcesAndRelevantCodeInputsUnchanged':True,'method':'full raw/WholeGoal/field/catalog checks, own private inode, fsync, atomic replace; old bytes archived','neighborProducerSnapshotAndSourcewriteBarrierHonored':True,'sourceQAReviewDatesAliasesMasteryCardsPolicyOrRuntimeChanges':False,'floorPolicySha256':ph,'normalProducerAndFloorStillRequired':True,'notAnM6M7OrRemoteAcceptanceClaim':True}
(out/'receipt.json').write_bytes(J(receipt));print(json.dumps({'receipt':str((out/'receipt.json').relative_to(repo)),'sha256':sha((out/'receipt.json').read_bytes()),'sourceAfter':sha(source.read_bytes()),'arraysChanged':4,'allOther508GoalsUnchanged':True,'normalGatesStillRequired':True},indent=2))
