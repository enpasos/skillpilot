import concurrent.futures
import datetime
import json
import os
from pathlib import Path
import subprocess
import yaml

root = Path.cwd()
out = root / 'tmp/pr157-third-ci-followup-20261115'
workflow = yaml.safe_load((root / '.github/workflows/ci.yml').read_text())
steps = next(j for j in workflow['jobs'].values() if j.get('name') == 'Curriculum CI')['steps']
commands = []
started = False
for step in steps:
    if step.get('name') == 'Check Goal Source Rationale Coverage Report':
        started = True
    if started and 'run' in step and step['name'] != 'Verify committed curriculum quality status':
        commands.append(step)

def run(index_step):
    index, step = index_step
    path = out / ('remaining-%02d.actual.log' % index)
    begin = datetime.datetime.now(datetime.timezone.utc).isoformat()
    env = dict(os.environ, SEMANTIC_ROUTE_POLICY_BASE='a7c7e9ceb26f06194e25f29e32941d4e4cb17c32')
    with path.open('wb') as stream:
        result = subprocess.run(['bash', '-c', step['run']], cwd=root/'app', env=env, stdout=stream, stderr=subprocess.STDOUT)
    row = {'name': step['name'], 'command': step['run'], 'startedAt': begin,
           'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'exitCode': result.returncode, 'log': str(path.relative_to(root))}
    (out / ('remaining-%02d.actual.json' % index)).write_text(json.dumps(row, indent=2)+'\n')
    print(json.dumps({'name':step['name'],'exitCode':result.returncode}), flush=True)
    return row

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    rows = list(pool.map(run, enumerate(commands, 1)))
(out/'remaining-curriculum-checks.actual.json').write_text(json.dumps({
    'scope': 'Actual commands after the failed report check, excluding full quality already proved at the identical canonical c9 inputs; F7 documentation is present locally and is not claimed as PR157 content.',
    'commands': rows,
}, indent=2)+'\n')
raise SystemExit(0 if all(row['exitCode']==0 for row in rows) else 1)
