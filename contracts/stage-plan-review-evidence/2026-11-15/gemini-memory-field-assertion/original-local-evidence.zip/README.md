# Gemini memory-practice security assertion repair

Recorded 2026-11-15T12:38:50+01:00. Local candidate only; no commit, push, remote workflow or deployment performed by this subtask.

## Original failure

- Workflow run: 43707177517; job: 132790655387; exact head: `c9a2d355ae68e2a9bd152fce78066b9fe8bf9fba`.
- Retained original tool response: `original-failed-job.actual.json`; focused original lines: `original-failure.excerpt.log`.
- `GeminiV1MemoryPracticeContractTest.startPublishesFrontsWithoutAnyAnswersOrReviewCapabilities`, original line 108, searched the whole map's `.toString()` for `back`. A legitimate opaque encrypted `answerCapability` beginning `ARjBT-back...` contained those four characters. The recorded assertion found only `back`; card fields were `id`, `front`, `answerCapability`, with no actual answer or review capability released. Original Gemini job: 168 tests, one failure.

## Candidate and preserved security

`candidate.diff` is bounded to that one test method (33 added, 6 removed lines). It checks the exact allowed top-level fields and progress fields, every card's exact fields, both expected card IDs and fronts, nonempty string capabilities, expected revision/status/progress/locale, and exactly one text content block. Identical checks execute independently on structured content and parsed text JSON. Answer and review field names are excluded structurally, so random opaque token substrings are irrelevant.

Both channels still reject actual answer text, private instructions, learner ID and learning-session ID anywhere in the payload; the privacy checks now cover text JSON as well. Empty metadata remains required. The actual answer-release, capability isolation, premature-rating and mastery/rating tests and all helpers are byte-identical to HEAD (`source-verification.json`). No capability producer, cryptography, source curriculum, retained artifact or learner-result behavior changed.

## Native evidence

Exact environment and command: `native-command.txt`. Both invocations used existing Amazon Corretto 25.0.2.10.1, Gradle 9.7.1, offline dependency cache `/tmp/skillpilot-plan-gradle-20261022`, two Gradle workers and a private project cache under this evidence directory. `compileJava`, `processResources`, and `processTestResources` were excluded to preserve already-built unchanged runtime inputs. Native Gradle compiled test sources and executed only the named actual Spring/JUnit class; no full backend suite or dependency installation ran.

1. Temporary native mutation run: exit 0, **9 tests, 0 failures, 0 errors, 0 skipped** (`temporary-native-mutation.log`, `.xml`). A single temporary evidence test calls the actual production-output contract test method, not a copied assertion helper. A forced last-card opaque token `opaque-back-token` passes both revised channels while the old lexical assertion deterministically fails. In each channel, extra `back` or `reviewCapability` fields at the top level, progress map and last card fail (12 cases), as do answer text, private instruction, learner ID and session ID in an existing string field (8 cases). All 20 negative cases are rejected. The synthetic token case concerns serialization assertions; the unchanged capability tests continue exercising real issued capabilities.
2. Final source restored exactly, then final native class: exit 0, **8 tests, 0 failures, 0 errors, 0 skipped** (`final-native-class.log`, `.xml`). No temporary evidence test remains in the candidate. `native-results.json` records terminal exit and XML totals.
3. `git diff --check -- backend/src/test/java/com/skillpilot/backend/connectors/gemini/v1/mcp/GeminiV1MemoryPracticeContractTest.java`: exit 0.

Reproducer source and runner are retained as `temporary-native-mutation.java` and `run-native-evidence.py`. The runner always restores `candidate.java` before the final-class run. These files are TMP evidence, not proposed repository tests. `deterministic-matrix-markers.log` records each case without learner identifiers.

## Delivery boundary

Candidate source SHA-256: `bfc281aa6c6dd62ac01121f3040b66f6d9905b307d9c4565249f963d63c06be2`. This local result does not claim remote/main CI acceptance. The parent may include the single test repair in its next coherent delivery, then obtain required fresh PR/main workflow evidence.
