from pathlib import Path
import json, os, shlex, shutil, subprocess

root = Path('/home/enpasos/projects/skillpilot')
evidence = root / 'tmp/gemini-memory-field-assertion-20261115'
source = root / 'backend/src/test/java/com/skillpilot/backend/connectors/gemini/v1/mcp/GeminiV1MemoryPracticeContractTest.java'
candidate = (evidence / 'candidate.java').read_text()
original_start = '''    private McpSchema.CallToolResult start() {
        return call(
                GeminiV1Contract.TOOL_START_MEMORY_PRACTICE,
                Map.of(
                        "goalId", GOAL_ID,
                        "expectedStateVersion", INITIAL_STATE_VERSION,
                        "language", "de"));
    }
'''
mutated_start = original_start.replace('return call(', 'return assertionMutationResult(call(').replace('"language", "de"));', '"language", "de")));')
assert candidate.count(original_start) == 1
addition = r'''
    // Temporary evidence only: invoke the actual contract test on real producer output.
    private String assertionMutation;

    @Test
    void deterministicOpaqueTokenAndLeakMutationEvidence() {
        try {
            assertionMutation = "opaque-back";
            McpSchema.CallToolResult collision = start();
            org.assertj.core.api.Assertions.assertThatThrownBy(() ->
                    assertThat(collision.structuredContent().toString()).doesNotContain("back"))
                    .isInstanceOf(AssertionError.class).hasMessageContaining("back");
            startPublishesFrontsWithoutAnyAnswersOrReviewCapabilities();
            System.out.println("SECURITY_ASSERTION_MATRIX opaque-back: old lexical assertion fails; actual revised assertion passes both channels");
            int rejected = 0;
            for (String channel : List.of("structured", "text")) {
                for (String location : List.of("top", "progress", "last-card")) {
                    for (String field : List.of("back", "reviewCapability")) {
                        assertionMutation = channel + ":" + location + ":" + field;
                        org.assertj.core.api.Assertions.assertThatThrownBy(
                                this::startPublishesFrontsWithoutAnyAnswersOrReviewCapabilities)
                                .as(assertionMutation).isInstanceOf(AssertionError.class)
                                .hasMessageContaining(field);
                        System.out.println("SECURITY_ASSERTION_MATRIX rejected " + assertionMutation);
                        rejected++;
                    }
                }
                for (String value : List.of("Rückseite 2", "private instruction", learningSessionId, learnerId)) {
                    assertionMutation = channel + ":instruction:" + value;
                    org.assertj.core.api.Assertions.assertThatThrownBy(
                            this::startPublishesFrontsWithoutAnyAnswersOrReviewCapabilities)
                            .as(channel + " private-value leak").isInstanceOf(AssertionError.class)
                            .hasMessageContaining(value);
                    System.out.println("SECURITY_ASSERTION_MATRIX rejected " + channel + ":instruction:private-value");
                    rejected++;
                }
            }
            assertThat(rejected).isEqualTo(20);
            System.out.println("SECURITY_ASSERTION_MATRIX total: 1 accepted opaque-token case; 20 rejected leak cases");
        } finally {
            assertionMutation = null;
        }
    }

    private McpSchema.CallToolResult assertionMutationResult(McpSchema.CallToolResult result) {
        if (assertionMutation == null) {
            return result;
        }
        try {
            var mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            Map<String, Object> structured = mapper.convertValue(result.structuredContent(),
                    new com.fasterxml.jackson.core.type.TypeReference<>() {});
            Map<String, Object> text = payload(result);
            if ("opaque-back".equals(assertionMutation)) {
                for (Map<String, Object> channel : List.of(structured, text)) {
                    map(((List<?>) channel.get("cards")).getLast()).put("answerCapability", "opaque-back-token");
                }
            } else {
                String[] mutation = assertionMutation.split(":", 3);
                Map<String, Object> channel = "structured".equals(mutation[0]) ? structured : text;
                if ("instruction".equals(mutation[1])) {
                    channel.put("instruction", mutation[2]);
                } else {
                    Map<String, Object> destination = switch (mutation[1]) {
                        case "top" -> channel;
                        case "progress" -> map(channel.get("progress"));
                        case "last-card" -> map(((List<?>) channel.get("cards")).getLast());
                        default -> throw new AssertionError(assertionMutation);
                    };
                    destination.put(mutation[2], "actual leaked secret");
                }
            }
            return McpSchema.CallToolResult.builder().isError(false)
                    .structuredContent(structured)
                    .addTextContent(mapper.writeValueAsString(text)).build();
        } catch (Exception e) {
            throw new AssertionError(e);
        }
    }
'''
mutated = candidate.replace(original_start, mutated_start).rstrip()[:-1] + addition + '\n}\n'
(evidence / 'temporary-native-mutation.java').write_text(mutated)

env = dict(os.environ)
env.update(JAVA_HOME='/tmp/skillpilot-backend-ci-corretto-25.0.2.10.1',
           GRADLE_USER_HOME='/tmp/skillpilot-plan-gradle-20261022')
env['PATH'] = env['JAVA_HOME'] + '/bin:' + env.get('PATH', '')
command = ['./gradlew', '--no-daemon', '--offline', '--max-workers=2',
           '--project-cache-dir', str(evidence / 'gradle-project-cache'),
           '-Dorg.gradle.java.installations.paths=' + env['JAVA_HOME'],
           '-Dorg.gradle.java.installations.auto-detect=false',
           'test', '--tests', 'com.skillpilot.backend.connectors.gemini.v1.mcp.GeminiV1MemoryPracticeContractTest',
           '-x', 'compileJava', '-x', 'processResources', '-x', 'processTestResources']
(evidence / 'native-command.txt').write_text(
    'cd ' + shlex.quote(str(root / 'backend')) + '\n' +
    'JAVA_HOME="' + env['JAVA_HOME'] + '" GRADLE_USER_HOME="' + env['GRADLE_USER_HOME'] + '" ' +
    shlex.join(command) + '\n')
report = root / 'backend/build/test-results/test/TEST-com.skillpilot.backend.connectors.gemini.v1.mcp.GeminiV1MemoryPracticeContractTest.xml'
results = {}
def run(label):
    print('RUNNING ' + label, flush=True)
    with (evidence / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root / 'backend', env=env, stdout=log, stderr=subprocess.STDOUT)
    results[label] = {'exitCode': result.returncode}
    if report.is_file():
        shutil.copy2(report, evidence / (label + '.xml'))
        import xml.etree.ElementTree as ET
        suite = ET.parse(report).getroot()
        results[label]['suite'] = {k:suite.get(k) for k in ['name','tests','failures','errors','skipped','time']}
    (evidence / 'native-results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(label + ' ' + json.dumps(results[label]), flush=True)
    return result.returncode

try:
    source.write_text(mutated)
    matrix_code = run('temporary-native-mutation')
finally:
    source.write_text(candidate)
final_code = run('final-native-class')
print('Restored final candidate source; no production source changed.', flush=True)
raise SystemExit(max(matrix_code, final_code))
