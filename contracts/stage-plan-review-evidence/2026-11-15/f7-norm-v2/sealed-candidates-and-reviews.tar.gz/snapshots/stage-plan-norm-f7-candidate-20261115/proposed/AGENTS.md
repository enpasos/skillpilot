# AGENTS.md – Skill Graph Memory & Design Guide

## Current execution mandate: stage plans and pedagogical repairs

On **15 November 2026**, the Product Owner delegated the resolution and
implementation of the model, stage-plan and pedagogical findings recorded in
`docs/dev/stage-plan-units-handover-2026-11-15.md` to the implementing agents.
The owner reviews concrete results and intervenes when needed; do not return
ordinary modelling, subject-review, goal-splitting, assessment-authoring or
necessary implementation decisions to the owner as unresolved assignments.
Research educational practice and primary sources, explain the chosen
solution, and implement the corresponding atomic goals, prerequisites,
assessments and projections with current evidence. Evidence-based new wording
and bridge goals are permitted; invented official source claims are not.

This mandate supersedes the handover's earlier owner-approval reservations
for this work. It does not waive source fidelity, genuine independent reviews,
immutable evidence, learner-result contracts or existing quality floors. A
missing assessment must be repaired with an appropriate task and coverage,
never with a fictitious prerequisite or a relaxed gate. Curriculum edits do
not themselves write or transfer learner mastery.

The delivery target is **integrated `main` with a fresh fully successful CI
run**, not a collection of open PRs. The owner explicitly authorized completing
and integrating #153 and #156 after successful CI, and bringing the subsequent
deliveries to `main`; use PRs as intermediate reviewable deliveries and keep
their number small. Delegate suitable work to **GPT 6.1 Sol Ultra**. This
development mandate does not authorize unrelated production deployments,
provider publication, credential changes or changes to the retained sources.

Maintain `docs/dev/stage-plan-management-summary.md` after every implementation
delivery, as explicitly requested by the Product Owner on 15 November 2026.
Write a short German entry with date, time and timezone, overall progress
against K1–K13/F1–F7, the concrete result, implementation decisions, two or
three owner inspection points, linked quality evidence, integration status
and next step. Distinguish learner assessment tasks, automated checks and
independent content reviews. Count completed work, activated real plans and
measured backflow effects explicitly; do not turn partial work into completion
percentages. Update the timestamp when revising an open entry.

Mark a delivery complete only after merge and a fresh successful main CI run.
Open entries link the PR; completed entries additionally bind the implementation
commit and terminal main workflow run. Count jobs of that specific run, not
the changing aggregate of checks attached to a commit. Retain completed
entries as history, with explicit corrections where needed. The owner's
follow-up feedback permits a small documentation-only completion commit or
short-lived PR after successful main CI, so the record need not wait for the
next implementation delivery. Check the applicable workflow paths and run
the documentation checks; never claim that the implementation CI ran on the
later documentation commit. Otherwise keep updates in the coherent delivery
stream and avoid interrupting a running full PR CI merely to update status.

## 0. OpenAI review retired — successor development is authorized

The submitted `skillpilot-coach-v1` **1.0.0** was **REJECTED**. On
**9 September 2026**, the Product Owner explicitly lifted **all ChatGPT/OpenAI
review development freezes** and authorized updating the current plugin,
submission preparation and tests. The initial successor target was **1.1.0**;
the published Git beta patch is now **1.1.2**, with the delayed-image correction
ported from Claude prepared for a separate backend rollout. OpenAI portal
submission remains unpublished.

Do not require new review-time hash exceptions for current OpenAI package,
MCP, UI, instructions, shared first-party WebGUI, tests or documentation.
The former runtime/supplemental hash chains are historical audit data, not
constraints on current development. The earlier presentation-island restriction
was a review-time boundary, not a perpetual development stop.

Keep the rejected `1.0.0-SNAPSHOT`, its old archive/manifest/contract and
content-addressed review video intact as history. The complete former freeze
record is archived under
`contracts/openai/skillpilot-coach-v1/review-history/1.0.0-rejected/`.
The active `review-freeze.json` now records the rejection and explicit
retirement; the checker verifies this decision and historical evidence without
hash-pinning live source files:

```bash
node scripts/check_openai_plugin_review_freeze.mjs
```

Local successor `candidate`, `prepare` and `verify` work is permitted.
Do not overwrite rejected 1.0.0 or any actually published release. Published
Claude artifacts and their independent evidence/acceptance gates remain intact;
the OpenAI unfreeze does not rebind a Claude release or claim client acceptance.
Previously advertised content-addressed UI resources retain their exact bytes.

This authorization does **not** publish, deploy or resubmit anything and does
not authorize portal writes, credential changes or `record-published`.
Security, OAuth/session separation, authorization, privacy, state integrity,
artifact reproducibility and truthful acceptance tests remain required.
`DRAFT` still means unpublished; local tests are not real-host acceptance.
See [review retirement and history](docs/deploy/openai-plugin-v1-review-freeze.md)
and the [release runbook](docs/deploy/openai-plugin-v1-release.md).

### 0.1 Claude-first beta and subsequent ChatGPT publication

On **12 September 2026**, the Product Owner set this binding work order:
**Claude beta → stable candidate → focused ChatGPT integration acceptance →
official submission**. The detailed [beta and publication strategy](docs/deploy/claude-beta-chatgpt-release-strategy.md)
supersedes earlier plans for a parallel external ChatGPT beta.

- Continue the real Claude beta and stabilize complete learning flows,
  including session continuation, persisted learning progress and reliable tools.
- The original pause on additional ChatGPT distribution work is superseded
  only for the explicitly authorized desktop archive/Git beta described below.
  Do not develop speculative ChatGPT-specific extensions.
- Once Claude is stable, identify the proven source/build as the release
  candidate. Test that shared functional baseline through the actual ChatGPT
  adapter; do not duplicate the core or treat the provider packages as identical.
- ChatGPT acceptance is a focused host-integration check, not a second full
  beta: connection/authentication and token renewal, loaded coach instructions,
  actual tool calls, and a representative learning flow with session continuation.
  Fix observed host-specific faults and record a demo of the tested candidate.
- Existing security, privacy, domain checks and submission evidence gates remain
  unchanged. Claude results do not prove ChatGPT host behavior.
- An external ChatGPT beta is not a submission prerequisite. Handle provider
  inquiries separately; only a demonstrated submission or operation obstacle,
  not silence on a general support question, can block the next step.
- This work order does not itself submit, publish or change production settings.

Claude lane status in the repository on **11 November 2026** (recorded state,
not a new decision): plugin **1.1.13** is published in the repository-backed
personal marketplace with independently verified source, package and
repository. Full real-client acceptance remains pending, and this is not an
Anthropic-curated or Anthropic-verified listing. See
`docs/deploy/claude-personal-marketplace-release.md`.

On **24 September 2026**, the Product Owner explicitly authorized trying the
documented ChatGPT archive upload and adapting the server to native desktop
CIMD with S256 PKCE. Use the existing V1 MCP endpoint and OAuth issuer; do not
introduce a second OpenAI endpoint for this integration. The native client is
a separate, exactly pinned public OAuth profile, never a fallback from failed
confidential authentication. The Product Owner permits mTLS `observe` for the
initial working integration; mandatory client certificates are later transport
hardening, not a prerequisite for this test. OAuth, learner-session isolation,
and truthful host acceptance remain required. See the
[native CIMD integration runbook](docs/deploy/openai-native-cimd.md).

On **5 October 2026**, after a successful Windows desktop archive installation
and an observed wrong-provider start message, the Product Owner explicitly
requested the **existing Git marketplace deployment** for rapid fixes and
**ChatGPT in the WebGUI**. This authorizes publishing the verified **1.1.1 Git
beta** to `enpasos/skillpilot-chatgpt-marketplace` and implementing an explicit
**ChatGPT Desktop (Beta)** provider choice with a separate OpenAI learning
session. It supersedes the distribution pause for this concrete route. Preserve
published `v1.1.0`, rejected review history, provider isolation and all privacy
and authentication checks. Installation and local CLI update evidence do not
prove desktop OAuth, tools, complete learning flows or automatic updates.
OpenAI directory submission, portal writes, `record-published`, production
settings and GUI/server production deployment remain separate operations.
See the [Git beta runbook](docs/deploy/openai-personal-marketplace-release.md).

In the same **5 October 2026** session, the Product Owner confirmed that the
Git/Windows Desktop route **works** and requested it through the ordinary
**Lernen starten** GUI and current ChatGPT notices. Record this as owner-reported
installation/start evidence; do not present it as detailed OAuth traces,
full mastery/continuation/renewal acceptance, another account or web/mobile
support. Ordinary GUI and Cockpit entry offer the provider choice without
`chatgptTest`. Preserve all published plugin bytes and immutable review/media
records when reconciling current user-facing documentation.

The subsequent Windows **Work/Voice** test reports working learning and apparent
success saving, but only the first learning image displayed; the later image
is visible in the Cockpit. The **1.1.2** candidate ports Claude's existing
delayed-image correction. After local checks passed, the Product Owner
explicitly requested immediate Git marketplace rollout: **1.1.2** is published
at commit `cf5e23a7908412f3f28a1a66485d0e106c346154`, with a byte-exact fresh-clone
check and successful GitHub validation. The Product Owner still handles the
matching backend rollout; actual Desktop/Voice image-sequence acceptance stays
pending. Local SDK/browser and backend checks are not host acceptance.
Preserve published **1.1.1**, **1.1.2**, historical UI bytes and the old drafts;
this Git publication does not submit or publish in the OpenAI portal.

In the subsequent **5 October 2026** Windows Desktop retest, the Product Owner
reported no observed automatic update when moving to **1.1.2**, while the manual
marketplace update works. This does not establish that automatic updates never
occur. The repeated **Work/Voice** test still lacked new learning-goal images,
while the Cockpit showed saved goals and successor images. The timeout
correction therefore has no successful host acceptance. A fresh installation,
fresh chat, the MCP resource hash actually used and correlated tool/display
traces have not been confirmed for this retest. Public GUI version evidence
does not identify the MCP resource loaded by the desktop chat.
The owner subsequently reports that the image flow works without Voice. Treat
this as owner-reported Text-mode evidence, not acceptance of the local follow-up
correction or proof that Voice invoked the successor renderer. The supplied
commit description is not a runtime tool trace.

The subsequently supplied production MCP trace on **5 October 2026** records
successful mastery persistence at **15:42:39 UTC** (`stateVersion=133`), a fresh
context offering an image, and a successful renderer completion at
**15:43:32 UTC** for the same pseudonymized session and state. Resource reads
served `12762009bd8e` as active under backend build `0af05906c8...`; the local
`08030bd956b6` correction is not present in this trace. The owner subsequently
confirmed that this last renderer call belonged to **Voice**. The expanded
trace also records a successful initial renderer at **15:32:00 UTC**, state
132. Thus the missing Voice successor image is not explained by an absent
renderer call: it remains a failure after successful server invocation,
without proof of client receipt, component execution or image display. The
renderer's `goalVisualizationOffered=false` is expected for its presentation
receipt, not a missing-image error. Earlier MCP `401` and
`notifications/initialized` warnings do not establish a cause for this
successful renderer's missing display. Roll out the already-tested local
backend/widget correction before attributing the symptom to another defect.

The follow-up local investigation reproduced two additional renderer faults:
documented ChatGPT `toolResponseMetadata`/MCP result envelopes were ignored,
and a delayed persisted `widgetState` could restore the first image over a newer
native result. The backend widget correction accepts bounded known result
envelopes and treats persisted state only as a bootstrap fallback. Its new
resource is `08030bd956b68b816523f4971b6d18ab154eef01381882b01d7f1991cc643391`;
the advertised `12762009...` bytes remain retained unchanged. This is a local
backend/resource correction with actual Desktop/Voice acceptance pending.
The seven published Git install files and package version **1.1.2** are unchanged.

The **19 October 2026** production trace now confirms deployment and serving of
the corrected active image resource `08030bd956b6` under backend build
`fd1f419769c9…`. Mastery succeeds at **11:50:26.927 UTC**, advances state to 142,
and triggers the learning-plan handoff. A fresh context still offers an image;
the successor renderer succeeds at **11:51:35.894 UTC** for the same session
and state. The owner still reports no successor image in Voice. This newer
incident is therefore not explained by an absent renderer call or the old
backend resource. Resource reads do not prove component execution or display;
the actual client event/image-loading failure remains unobserved. Preserve
the older trace as history and use the current incident record in
`docs/deploy/openai-personal-marketplace-release.md` for further diagnosis.

On **19 October 2026**, the Product Owner requested modernization of the
deployment workflow, including mobile and web wherever supported, and an
assessment of one durable plugin across package major versions. The current
local **1.1.3** candidate adds the deterministic directory-submission ZIP and
explicit package OAuth/CIMD preference. A separately reproduced pending-image
handshake race is corrected with new resource `9c09821e96ab…`; deployed
`08030…` remains retained unchanged. Git-imported direct-MCP plugins remain
Desktop only; Web and mobile are targets of the hosted directory route and
require actual host acceptance. Local Chromium viewport checks are not client
acceptance.

In the same **19 October 2026** session, the Product Owner explicitly chose a
fresh permanent plugin **SkillPilot Coach**, technical name **`skillpilot-coach`**,
with the neutral endpoint **`https://mcp-openai.skillpilot.com/mcp`** before the
new submission. This supersedes both the initial recommendation to retain the
old public identity/endpoint and the former one-plugin-per-major plan. Package
SemVer may change across majors while this identity and exact endpoint remain
stable. The existing OAuth issuer **`https://skillpilot.com/api/openai/v1`**,
internal V1 adapter, scopes and session isolation remain; public Resource/Audience,
widget origin, discovery and edge pins move together to the neutral origin.
Native CIMD uses the exact new resource-specific `7yTcOAOqrumX` client/callback.
Do not introduce dual audiences or multiple public runtime origins for this cutover.

The owner expressly excluded old chats: no chat continuation, session migration
or continued old MCP runtime is required. Reconnection and a fresh learning start
are acceptable; preserve durable learner progress. Published Git-beta bytes,
historical archives and previously advertised UI artifact bytes remain immutable.
The owner handles deletion of the unpublished portal draft. Local preparation is
authorized; this decision does not itself deploy, submit or publish anything.
The resource change activates a new OAuth profile fingerprint and retires the old
one; a rollback needs a new explicit policy revision and fresh authorization.
Future tool changes must respect the host's separately reviewed live definitions;
one stable plugin does not make arbitrary incompatible schema changes safe or
require every old tool forever. See the binding current decision in
`docs/concept/runtime-workflows/openai-plugin-versioning-and-lifecycle.md`.

Repository state on **11 November 2026** (recorded state, not a new decision):
current source implements the preparation for this cutover.
`ai/openai plugin/skillpilot-coach/` is the canonical package and
`ai/openai plugin/skillpilot-coach-v1/` is inactive historical source. Backend
defaults and protected-resource metadata bind
`https://mcp-openai.skillpilot.com/mcp`. The neutral **1.1.3** candidate remains
local and unpublished. Endpoint rollout, marketplace publication, directory
submission and host acceptance are still separate operations that each need
their own explicit instruction; see `ai/openai plugin/README.md` and
`docs/deploy/openai-stable-origin.md`.

This document is the **long-term memory** for SkillPilot, including the skill-graph explorer.  
It captures the *concepts and design decisions* that are **not obvious from the code alone**, so humans and LLMs can extend the project consistently across different learning domains.

### Project licensing

The binding Product Owner decision of 21 September 2026 is **Apache-2.0 for
our software; CC-BY-4.0 for our knowledge-landscape content**. Follow the fixed
allocation and boundaries in `LICENSING.md`: code, technical schemas,
developer documentation and functional coach instructions are Apache-2.0;
own graphs, goal texts, mappings, tasks, cards, didactic media and Whitepapers
are CC-BY-4.0. Use function, not file extension, to classify material. Full
texts are `LICENSE` and `LICENSES/CC-BY-4.0.txt`. No general dual licensing or
additional per-goal license approval is required for clearly own material.
Do not relicense third-party sources, linked provider content, dependencies,
marks or private learner data. Provenance labels such as `AI-generated,
SkillPilot-curated` are not licenses or proof of ownership. License grants,
source/third-party rights checks and quality approvals remain separate.
New exports carry applicable licenses and attribution; preserve prior grants,
immutable published archives and historical review records.

---

## 1. Purpose of this project

SkillPilot is a **general open-source learning platform** that models domains as skill graphs.
Every landscape should:

1. Represent learning goals as a **DAG of competencies** (cluster + atomic goals).
2. Enable **smooth learning paths** via the `requires` frontier: no goal is suggested unless prerequisites are mastered.
3. Provide a **transparent mastery/progress view** that can later drive grading or certification models.
4. Be usable both by **human teachers/learners** and **LLM-based agents** (task generation, coaching, analytics).

The project started from the Hessian KC 2024 upper-secondary landscapes; that source tree is retired (§10.5). The repository now ships the roots listed in `curricula/curriculum_manifest.json`:

- **Gymnasium (DE)**: one canonical landscape per subject under `curricula/DE/Gymnasium/canonical/` (20 subjects plus the overview root), viewed through Bundesland- and duration-specific composition views. Retained state sources live under `curricula/DE/Gymnasium/input/<STATE>/` for all sixteen Länder plus `KMK`. Maturity differs widely per subject; the generated `docs/qa-ci/status/curriculum-quality-status.json` is authoritative.
- **Hessian roots**: the manifest still lists `Gymnasiale Mittelstufe` and `Gymnasiale Oberstufe` (DE, HE, G9). Retired Hessen upper-secondary compatibility views are described only by frozen metadata under `curricula/DE/Gymnasium/archive/`.
- **Other school forms and programmes**: Bavarian school forms, university programmes (TU München, TU Darmstadt, Uni Mannheim, Uni Heidelberg) and MIT OpenCourseWare foundations.
- **Sprachen CEFR (für Deutschsprachige)**: Englisch und Französisch als A1–C2 CEFR-Landschaften under `curricula/EU/CEFR/`.

All conventions described below are general enough to support other curricula, subjects, or languages; the mathematics graph remains the reference implementation.

> Foreign languages (Englisch/Französisch) follow a TF × Skill × GER schema: Themenfelder aus dem KC + sprachliche Skills (reading, listening, speaking, writing, mediation, intercultural) mit `tags` wie `skill:*` und `cefr:B1/B2/C1` (E ~ B1, Q GK ~ B2, LK ~ C1).  
> German Ziele wurden KC-konform operationalisiert (prüfbare Beschreibungen, z. B. Analyse, Vergleich, Deutung, Urteilsbildung) und mit einfachen `skill:*`-Tags (lesen, schreiben, sprechen, medien, sprachreflexion) versehen.  
> Geschichte ist komplett angelegt (E + Q1–Q4), je Themenfeld GK-/LK-Ziele: Überblick, Quellenanalyse, Strukturen/Ursachen, Vergleich, historisches Urteil, Erinnerung/Deutung.

---

## 2. Mental model of the skill graph

### 2.1 Nodes = learning goals

Each node is a **learning goal** (“Lernziel”). There are two “flavours”:

- **Atomic goals**  
  Small, assessable skills (e.g. _“mittlere Änderungsrate berechnen und deuten”_).
- **Cluster goals**  
  Aggregations that group atomic goals (e.g. all goals in one Themenfeld, or all E1-Analysis basics).

Atomic goals are what the student actually “masters”.  
Cluster goals are for navigation, progress summaries, and intermediate hierarchy layers.

### 2.2 Edges = relationships between goals

We use exactly **two connection types**:

1. `requires` – **prerequisite**  
   - `A.requires = [B, C]` means: A should only be approached if B und C sitzen.  
   - Current compatibility model: existing prerequisites on clusters are still read through `contains` inheritance and atomic expansion for runtime/frontier purposes. This is transition semantics, not the canonical target state.
   - Binding target state (Product Owner, 8 November 2026): **all** authored `requires` have atomic source and prerequisite goals, $R\subseteq A\times A$. There is no permanent exception for universal cluster claims.
   - Product Owner decision of **12 November 2026** supersedes the earlier prerequisite-migration order and preservation obligation: acceptance depends on comprehensive deterministic validation of the current target state within the milestone examination. No comparison with a historical prerequisite closure, scope or frontier is required for `G17` or `GD-C17`.
   - Product Owner decision of **13 November 2026**: the grading domain of the Graph Definition `GD-*` register is the complete canonical Gymnasium catalog (21 roots). A rule is hard only when every obligation is fail-closed within that domain, applying milestone-bound obligations at their stated threshold. The complete policy pins 21 curricula and twelve route scopes (ten M6/M7 subjects, five of them M7). Landscapes outside Gymnasium alone do not justify `PARTIAL`; real runtime or subject-matter gaps remain explicit. Retained source inputs must remain byte-identical; their live consumers and any inventory exclusion need explicit validation. This programme neither repairs nor retires non-Gymnasium landscapes and does not promote the eleven M0 curricula. Every upgraded register row names its gate, covered count, and negative test. The immutable V9 proof and all learner-result contracts remain unchanged.
   - Before any `M1`–`M7` pass, check the complete declared canonical subject inventory, including necessary foreign prerequisites and inheriting ancestors, for resolved identities/references, acyclicity, atomic `requires` endpoints, consistent explicit types and transitive minimality. A violation or incomplete check caps the subject and its scopes at `M0`; an incomplete catalog aborts the status run. Current `CQR-001` coverage is the canonical Gymnasium catalog, not every curriculum in the repository.
   - Historical reduction proofs remain evidence for the review bindings that actually reuse them; they neither define the current validation inventory nor replace current-state checks. A missing or invalid proof disables that reuse and leaves strict current-input QA checks in force; it never grants stale reviews. Existing source fidelity, review freshness and learner-result contracts remain in force. Graph edits never automatically write learner results.
   - Product Owner decision of **12 November 2026 (frozen proof, registry contract V9)**: the reduction proof is frozen at its end state and review reuse is decided goal by goal. Contracts V1 to V8 bind complete documents and store no historical document, so their chain can be replayed only while the catalog still is its end state; any goal change, even a new exam, disabled the whole reuse. The chain was verified completely for the last time at the freeze. The active registry `curricula/DE/Gymnasium/provenance/prerequisite-reduction-proof-registry.json` (`frozen-goal-scoped-prerequisite-reduction-v9`) binds the complete V8 proof as its parent by raw digest and records, for each of the 1,361 goals whose reviews saw another value than the frozen goal, that reviewed value and the digest of the frozen goal. While a goal still has its frozen digest, its reviews are compared with the reviewed value. A changed or removed goal has no transfer and faces the strict current-input checks, so only that goal needs a new review. Every other catalog change (new goals, new documents, other goals, learning units) leaves all transfers untouched. Witness paths belong to the frozen proof and are not re-checked against later catalogs; ordinary reviews do not depend on edges of other goals either. The V9 registry and its parent are immutable evidence: never edit or rebind them. No process replays the history after the freeze; a later bulk normalization needs a new proof epoch. Record: `docs/dev/prerequisite-reduction-proof-freeze-2026-11-12.md`.
   - Intention: modelling **didactic dependencies** (prevents jumping into topics without foundation).

2. `contains` – **is composed of / includes**  
   - `A.contains = [B, C]` means: A is a **higher-level bundle** of B and C.  
   - Cluster progress and satisfaction are derived from the atomic descendants. Completing a cluster never writes mastery back to its children.

The overall structure is a **DAG (Directed Acyclic Graph)**:
- `requires` should never form cycles.
- `contains` also should not create cycles (think of it as a hierarchy of clusters).

### 2.3 Separate goals from structure and taxonomy

The long-term target model should distinguish four semantic concepts plus one learner-facing composition layer that are currently still partly mixed in some landscapes:

- **Goal layer**: actual assessable learning goals and fachliche clusters
- **Program layer**: structural units such as year, semester, module, phase, track, or exam
- **Placement layer**: links from goals into program units
- **Competency-axis layer**: taxonomy entries such as process competencies (`K1`-`K6`)
- **Composition-view layer**: explicit scope-specific learner-facing tree definitions that reference reviewed canonical subtrees

Interpretation rules:

- year/semester/module/phase nodes are **not** the durable semantic backbone of the skill graph
- broad capability families such as `K1`-`K6` are **not** program units
- only concrete, assessable process skills become actual goals
- current `phase` values should increasingly be treated as compatibility/view metadata rather than as the canonical semantic anchor
- user-facing initial narrowing by school form, stage, jurisdiction, duration model, course profile, and current year/phase should be treated as **entry scope** over program units, placements, and applicability, not as duplicated goal semantics
- catalog navigation (for example Schule / Hochschule / Sprachen) precedes the
  selected base curriculum and is not learner scope; the committed Personal
  Curriculum is backend-owned Level 2 state, edited through the authored flow
  in first-party WebGUI surfaces. The OpenAI V1 coach neither presents nor
  mutates that configuration
- Level 2 contains jurisdiction or canonical view, applicable duration model,
  explicit stage, selected subjects, and course profile per subject; an absent
  stage stays unresolved, and LK is a subject attribute that never implies
  Sekundarstufe II
- For the current Bavarian Mathematics rollout, `GK` and `LK` are **technical
  SkillPilot projection labels**, not the names of Bavarian courses. `GK`
  targets the complete compulsory four-hour Mathematics curriculum at elevated
  level; `LK` targets those goals **plus all five modules** of the separate
  Mathematics Vertiefungskurs. A teacher may use Level 3 focus to work on the
  three modules actually taught, but this does not remove the other two from
  the Level 2 target, total progress, or completion. The later elective-course
  and module-selection UX is tracked in GitHub issue #59. This interim mapping
  never relaxes goal quality, source fidelity, independent reviews, or strict
  Mathematics M7 gates; it does not assert that Bavaria offers Mathematics as
  a selectable Leistungsfach.
- For the Chemistry rollout, the Product Owner decided on **16 October 2026**
  to include all authored topics in the applicable target scope first and defer
  the preceding topic-selection flow, following the Bavarian Mathematics
  approach. This includes Schleswig-Holstein's optional medication theme in
  the interim GK/LK Chemistry target. Preserve its official optional status:
  inclusion in SkillPilot's broader target does not make it a universal official
  curriculum requirement or prove that a learner selected it. No persisted
  theme choice or new runtime selector is implied. Source fidelity, independent
  reviews, full target progress and strict Chemistry M7 gates remain required.
- current focus roots and the one active atomic goal are mutable Level 3 state;
  changing Level 2 revalidates them against the new learner-facing `target`
  projection without rewriting stable goal IDs or global Level 4 mastery
- Under the **10 November 2026 Product Owner decision**, the Personal Curriculum
  learning basis is $L=S\cup\{p\mid\exists t\in S:(t,p)\in R_{at}^+\}$,
  where $S$ is the union of canonical atomic seed targets from the selected
  reviewed subject scopes. First resolve valid seeds with their reviewed
  course/jurisdiction filters; then close on the unpruned canonical graph.
  Retain the additional necessary atoms even when those seed filters would
  exclude them; unrelated course or jurisdiction content is not included. Every necessary atom belongs to learning, progress and
  completion; an open prerequisite needs an actual acquisition target in the
  full Personal Curriculum. Deduplicate stable canonical IDs across subjects.
- $L$ is fixed by personal configuration and curriculum/projection revision,
  independently of mastery. Already mastered prerequisites stay in the progress
  denominator as satisfied and need no automatic repetition. Do not stop closure
  at a mastered intermediate. An assumed entry basis is not mastery evidence.
  Official curricular assignment and source applicability remain separate from
  inclusion as necessary preparation; no goal, edge, source claim or learner
  result is authored by this policy.
- all targets in this closed Personal Curriculum remain intended learning goals;
  Level 3 focus only narrows current work. Adding necessary targets does not
  widen focus automatically or change normal/strict prerequisite checks. Overall
  progress and completion still include necessary targets outside that focus.
- A Level 3 focus is the union of its selected roots and their `contains`
  descendants, restricted to Personal Curriculum targets. Normal mode checks
  only the effective prerequisite relation inside this focus, including
  scope-relative atomic satisfaction of prerequisite clusters. Requirements
  outside the focus, including `prerequisiteOnly` goals, do not block entry or
  become mastered. Explicit strict mode retains global prerequisite checks.
  This applies equally to a single root and to multiple exam/topic roots;
  invalid authored Level 2 references remain configuration errors.
- Level 3 focus widening follows the single learner-facing `contains` path
  toward the root. The backend publishes strict supersets that add at least one
  unmastered target, nearest suitable ancestor first. It proposes widening only
  after actual current-focus completion, never from an empty frontier alone,
  and persists the published option only after learner acceptance. With
  multiple focus roots, widening replaces only the covered branch and the
  option's complete ordered `goalIds` payload retains every independent root
- `requires` alone never writes prerequisite mastery. Under the 4 November
  2026 correction, independent application in valid local assessment contracts
  derives globally effective mastery of ordinary prerequisites. Required-work
  recommendations and ordinary prerequisite checks use that effective result;
  focus widening must not reopen a recognized goal. Voluntary repetition remains
  available. Transitive minimality is mandatory; a mastered intermediate goal
  alone must not hide an open local assessment's transitive demand.
- learner-facing default trees for resolved scopes should preferably be compiled from reviewed composition views early enough that validation can run before UI rendering
- composition views should reference canonical subtree roots and should not inline authored atomic goals
- composition-view references may explicitly use `projectionRole: "target"` or `projectionRole: "prerequisiteOnly"`; an omitted role means `target`
- authored subject-view roles are not inferred from phase, year or stage; the
  explicit personal learning-closure rule above additionally derives the global
  target basis from existing reviewed `requires`, without rewriting those roles
- Authored seed references and subject-local role assignments remain validated.
  At the Personal Curriculum compile boundary, each necessary atom receives a
  derived target role with a checked canonical prerequisite path and recorded
  provenance; this satisfies its role/exposure obligation without a manual view
  reference for each atom. The 10 November decision supersedes the 7 November
  blanket manual-role requirement at this boundary. Unknown references, cycles,
  missing canonical atoms or unexposed/unaccounted derived targets remain hard
  errors, regardless of mastery or focus. The learner runtime and first-party
  WebGUI implement this closed basis. Applicability validation and complete
  native/curriculum/remote acceptance remain separate current-state checks.
- Product Owner decision of 11 November 2026: these hard errors belong to
  validation, CQR and native acceptance, not to learner reads. When the
  canonical graph of a learning context is not strictly compilable, the runtime
  keeps the reviewed seed scope without the derived closure, claims no learning
  basis, offers no goal whose demand is broken, and logs the failure once per
  curriculum and error code. State, results and export stay readable.
  This covers the many non-canonical curricula whose root cluster contains and
  requires its own orientation goal; their data is not changed by this rule.
- `prerequisiteOnly` remains a subject-local support role. A required atom may
  keep that role in one view when the same canonical atom is a target elsewhere
  in the full Personal Curriculum; acquisition counts once. It must not remain
  outside global $L$ merely because every subject view labels it support. Only
  actual targets contribute to the respective learning/progress/completion set.
- when overlapping composition references assign different projection roles, specificity decides: a direct `goalEntry` overrides a role inherited from a `canonicalSubtree`, and the nearest/deepest matching `canonicalSubtree` overrides a broader subtree; only at equal specificity does `target` win
- within one resolved learner-facing scope, the default tree should show each goal at most once and under at most one visible parent
- Bundesland-specific canonical supplement branches under a broad shared root may use `extendedData.applicabilityMappingInheritance = "boundary"` on the supplement cluster. This prevents old broad ancestor-cluster source mappings from being treated as source evidence for the supplement's atomic descendants, while direct mappings/provenance inside the branch and child-union visibility upward still count.
- Practice or assessment terminal goals may use `extendedData.applicabilityFromRequires = true` when their visibility should be derived exactly from their prerequisite goals. This is for local autonomy/exam endpoints, not for ordinary content atoms, and the resulting `assessment-requires` evidence is applicability evidence only, not source-coverage evidence.
- The applicability compiler additionally supports an explicit
  `extendedData.assessmentApplicabilityBasis = { kind: "allOfGoalApplicability", goalRefs: [...] }`
  for those atomic endpoints. It evaluates the referenced goals freshly through
  the existing applicability rules, including cluster child unions. The basis
  does not add prerequisite edges, learning targets, source coverage or mastery.
  Current support requires a fully resolved local expression and rejects
  malformed, duplicate, cyclic, foreign or Memory-derived dependencies. This is a temporary
  compiler boundary, not a restriction on foreign prerequisites in the Personal
  Curriculum. The V8 proof contract introduced the existing Biology and
  Economics basis bindings; the frozen V9 registry carries their reviewed
  values per goal. Ordinary current
  description-review contexts still reject an unqualified basis; the
  current-state decision does not extend the review schema. Those evidence
  bindings remain intact; new graph acceptance follows the current-state
  decision above and does not require another prerequisite-migration
  preservation proof. The milestone producer uses the frozen proof only for
  review reuse (registry contract V9, §2.2). The complete-proof verifier stays
  as a tool with its fixture regressions. The replays of the real history ran
  for the last time at the freeze and are retired; the native gates on the
  current catalog, among them `APV-102`, live in
  `CanonicalRequiredLearningGateTest`.
- local authoring tools should mirror this split: one tool for canonical cluster authoring, one tool for composition-view authoring
- preferred design maxim: **as much semantics as necessary, as little ontology as possible**
- add semantic distinctions only when they solve a concrete authoring, migration, validation, projection, or runtime problem

Reference:

- `docs/concept/skill-graph/general-goal-system-and-migration.md`
- `docs/dev/skill-graph-minimal-schema-runtime-fallback-and-math-pilot.md`

### 2.4 Recursive learning units

The Product Owner confirmed **Lerneinheit** (English **learning unit**,
conceptual name `LearningUnit`) on **4 November 2026**. This replaces the former
curricular-level terminology. Personalization Levels 1–4, QA maturity and goal
`level` difficulty retain their meanings.

- A unit states what learners will be able to do and why it matters. A motivational
  introduction leads into goals and optional subunits. Calendar years, semesters
  and navigation headings are not automatically assessed learning units.
- Assign unit roles through authoritative placements or reviewed composition
  structure for a resolved scope/revision. Every acquisition target has one
  direct owner in that hierarchy. Ancestors aggregate child targets; general
  canonical multiple-parent containment is still permitted.
- Derive unit completion from all required child completions and its own
  goal-type results. No extra unit mastery is stored. A parent may add an
  integrative assessment; an aggregate needs no redundant extra examination.
- Local recognition applies only to directly owned ordinary targets under the
  reviewed assessment contract. Never turn a parent's descendant union into a
  second shortcut. Valid direct and implicit competence remains globally effective
  while a later or parent exam is open. Exams and cards always need their own
  explicit results; a parent pass never passes them implicitly.
- An explicitly authored whole-unit requirement belongs to the course. An atomic
  prerequisite does not automatically impose the entire foreign unit. Whether
  unit requirements guide recommendations or technically block starts, including
  direct assessment attempts, remains undecided; no new hard gate is authorized
  by this concept alone. Independent branches may proceed in parallel.
- Preserve effective atomic acyclicity and transitive minimality. When whole-unit
  sequencing is intended, additionally check the projected block graph at every
  relevant boundary: atomic acyclicity alone does not guarantee a unit order.
  Include inherited, indirect, cluster, hidden and cross-subject requirements.
- Optional workload claims need documented entry assumptions, supported effort
  estimates, reserve and overall/subject budgets. Count shared acquisition once;
  `weight` and raw goal counts are not time estimates. An assumed entry competency
  is not a learner mastery write.
- **Purpose (Product Owner, 11 November 2026).** A unit establishes solid,
  independent application of its promise before planned learning builds on it.
  Its assessments expose essential misconceptions; a gap leads to focused
  learning and a fresh equivalent assessment instead of a false completion. Unit
  boundaries follow meaningful conceptual transitions, not existing exams,
  target quotas, tidy headings or edge density; never add or remove edges to
  fit a cut. The ordinary grading contract applies: no hidden pass rule and no
  second stored outcome. This is a didactic requirement, not an access lock.
- **Unit validity rules (Product Owner, 11 November 2026).** Recognition (§4)
  is only sound if units hard-satisfy five rules, each with a fixed placement:
  - R1: every own ordinary content goal of a unit lies on a prerequisite path
    from at least one own assessment of that unit, directly or transitively; a
    path that leads only to a memory goal does not count. Validity condition of
    the unit definition, same class as acyclicity: hard from the first authored
    unit; a unit that violates it cannot be merged.
  - R2: for every own ordinary goal, at least one own assessment that requires
    it has reviewed evidence that its tasks and normal grading really test the
    goal. Milestone M5 (assessment approval and coverage metadata), with the
    current per-goal binding at M7; without it the curriculum does not reach
    the milestone.
  - R3: an assessment claims coverage only for goals it requires directly or
    transitively (coverage ⊆ Reach⁺ over the atomic prerequisite relation), so
    the assessment that actually tests a goal is among those the recognition
    rule waits for. Same placement as R1.
  - R4: every acquisition target has exactly one directly owning unit. Same
    placement as R1.
  - R5: a later re-cut of units or later edges never grant additional
    recognition to existing results; the contract is versioned. Runtime
    contract and precondition before implicit recognition is enabled in
    production.
  Implicit recognition exists only inside units whose contract satisfies R1–R4
  with reviewed coverage. Otherwise the unit's goals stay open, and the
  violation keeps the curriculum from reaching the milestone. A goal that no
  assessment covers therefore stays open *and* is a rule violation; it is never
  recognized for free (Graph Definition §13.3; `GD-U05`, `GD-U06`, `GD-U15`,
  `GD-A07`, `GD-A08`, `GD-A10`, `GD-A12`, `GD-A18`).
- **Resumption (Product Owner, 12 November 2026).** The learning-unit work is
  resumed; the working plan is
  `docs/dev/mathematics-physics-learning-units-plan.md` (Mathematics first, then
  Physics). The catalog of units is derived in-house, block by block, from the
  canonical graph and the design sheet; an external proposal is at most a
  recorded origin, never a contract. Whole-unit access locks stay undecided.
- **Unit contract (Product Owner, 12 November 2026).** Learning units are part
  of the landscape and live in the existing placement layer; the Product Owner
  rejected a separate catalog file beside the landscape as a bolt-on and asked
  for a stable long-term contract, with a new schema version wherever one is
  needed. A unit is a `programUnits` entry of kind `learningUnit` (`id`,
  `label`, `labelEn`, `promise`, `promiseEn`, `revision`, optional
  `parentUnitId` naming the unit that requires it as a child). It owns atomic
  goals of the same landscape through `goalPlacements` of relation `own`,
  which carry exactly `goalId`, `unitId` and `relation` (no `context`). Reviewed coverage (R2) is the unit's
  `coverageReviews`, one entry per own assessment, hash-bound to that
  assessment's task, solution and rubric; goal objects carry nothing of the
  unit contract, so a review never changes a goal's bytes. The
  optional landscape field `learningUnitCoverage` is `partial` or `complete`.
  The declaration is closed: whole-unit prerequisites, access locks and waiver
  lists cannot be expressed. Curriculum-package contract 1.2
  (`contracts/curriculum-package/v1.2`) carries the units; builds under 1.0 or
  1.1 project them out completely, and published files of earlier versions
  stay unchanged. The completion profiles and scopes of contract 1.1 implement
  the superseded waiver semantics and remain in operation only until the
  runtime switches.
- **Unit validator (12 November 2026).** `npm --prefix app run
  validate:learning-units` enforces R1, R3 and R4 plus the declaration rules
  fail-closed for every learning unit in the canonical landscapes and runs in
  the required curriculum CI; only `learningUnitCoverage: "complete"` requires
  an owner for every atomic goal. Missing R2 evidence is reported, not
  rejected; it is not yet a milestone gate. R5 and implicit recognition are
  not implemented: a learning unit has no runtime effect, and every goal is
  still completed by its own explicit result. Never add an edge, weaken a goal
  description or cut a unit to turn the validator green; a finding is a
  subject-review task.
- **Bindings ignore the learning-unit layer (12 November 2026).** Evidence
  about goals, edges and assessments binds the landscape with its
  learning-unit layer projected out: without `programUnits` of kind
  `learningUnit`, without `goalPlacements` of relation `own` or towards a
  learning unit, and without `learningUnitCoverage`. It is the projection the
  package build applies for contracts 1.0 and 1.1; for a landscape without
  units it is the identity. Contracts V1 to V8 of the prerequisite-reduction
  proof and the input pin of the Mathematics duration layout fingerprint that
  projection; a registry record keeps its full digest. Since the freeze of
  12 November 2026 the active V9 registry binds single goals (§2.2), so
  neither a unit edit nor an unrelated goal change stales review reuse; the
  duration-layout pin still goes stale on any goal change in Mathematics.
  Carriers that predate learning units follow the same rule: a 1.0 or
  1.1 build and the legacy subject export (with its MEM/FWU roundtrip) ship
  the landscape without the layer; only contract 1.2 carries units. This was
  the recommendation presented to the Product Owner on 12 November 2026 after
  the first placement attempt broke the proof chain; the Product Owner asked
  to proceed. Never rebind a proof by hand and never touch a floor to place a
  unit. Record: `docs/dev/canonical-math-learning-unit-pilot-binding-review-2026-11-12.md`.
- **Redistribution ledger (Product Owner, 12 November 2026).** The committed,
  CI-checked package-redistribution ledger is always the one of the contract
  under which packages are released: today 1.0. The 1.2 ledger binds the 1.2
  model, because a redistribution review must see everything that ships; it
  is generated per build and is committed, taking over the CI check, when the
  runtime switches to contract 1.2. Do not commit a ledger that no CI step
  checks.
- **First placed unit (12 November 2026), first reviewed coverage
  (13 November 2026).** Canonical Mathematics contains the pilot unit
  `math-dot-product-projection` (one ordinary goal, one assessment). Its first
  assessment did not satisfy R2
  (`curricula/DE/Gymnasium/quality/learning-units/math-dot-product-projection-2026-11-12.md`).
  Since 13 November the unit owns the assessment
  `be48054d-48f7-54c0-8248-d0a462ad6dc9`, written for it, and carries the
  first coverage review: two independent machine reviewers, the second without
  knowledge of the first, found R2 satisfied for the bound text
  (`curricula/DE/Gymnasium/quality/learning-units/math-dot-product-projection-2026-11-13.md`).
  The earlier assessment keeps its ID outside the unit; its passes are not
  upgraded. A coverage review is machine content review bound to the task and
  rubric revisions: any change to task, solution, grading note or rubric needs
  a new review. The earlier completion profile `math-dot-product-projection`
  still names the earlier assessment and stays unchanged until the runtime
  stage retires the profile path: production runs in automatic mode, which
  skips the completion-profile and completion-scope directories, so the
  profile only serves the historical profile-path tests and the 1.1 package
  profile.
- **Second unit and the assessment tool (13 November 2026).** Canonical
  Mathematics also contains `math-natural-numbers` (five grade 5 goals, two
  assessments written for it, `49507f95-d079-5113-8aac-1a08299473a3` and
  `de7e0bb2-262a-50e7-8398-f91ab1b365ca`), with reviewed coverage for all five
  goals
  (`curricula/DE/Gymnasium/quality/learning-units/math-natural-numbers-2026-11-13.md`).
  Unit assessments are authored in a source file under
  `curricula/DE/Gymnasium/assessments/` and placed by
  `app/scripts/applyLearningUnitAssessments.mjs`, which derives the assessment
  goal, its cluster membership, the semantic-kind decision, the unit and its
  coverage reviews; `npm --prefix app run check:learning-unit-assessments`
  fails in required CI when catalog and sources differ. Do not edit a unit
  assessment in the canonical file by hand. The pilot stays a unit of its own
  (decided 13 November): its goal is a learning target in few configurations,
  and in a shared unit its assessment would hold back the recognition of the
  three core dot-product goals everywhere. The assessment model has one task
  per assessment ID; fresh task variants for repeat attempts need a contract
  extension and backend selection and belong to the runtime stage.
- **First Physics unit (13 November 2026) and experimental goals (Product
  Owner, 14 November 2026).** Canonical Physics contains
  `physics-constant-acceleration` (two goals of the introductory phase, one
  assessment written for it, `c5807a37-129e-5df6-8989-482bc7f5683e`) with
  reviewed coverage for both goals
  (`curricula/DE/Gymnasium/quality/learning-units/physics-constant-acceleration-2026-11-13.md`).
  The goal "Freier Fall experimentell untersuchen" is outside the unit: two
  independent reviewers found R2 not satisfied for an assessment that
  evaluates given measurement data, and disagreed on whether own measurement
  data or planning plus evaluation would satisfy it. Experimental goals get
  no special treatment (Product Owner, 14 November 2026; this replaces the
  decision of the same day that they are never recognized). An experimental
  goal is a content goal like any other: it joins a unit once an own
  assessment of that unit requires it and a coverage review confirms that the
  assessment tests it, and it is then recognized like the unit's other goals.
  Until then it stays outside the unit. What an assessment must demand to
  test an experimental goal is not decided; it is settled once, for all such
  goals, when the first unit with one is cut. The contract needs no marker
  and no `ownExplicit` relation.
- **Knowledge context of a unit (13 November 2026).** Nothing is written by
  hand about the subject matter of a unit: its knowledge context is the union
  of the contexts of its own goals and assessments (§2.5). Tasks, memory
  cards, goal images and coach examples of a unit stay inside it; whether an
  assessment does becomes part of its R2 review, not a new validity rule.
- **Unit structure (Product Owner decision, 14 November 2026; not
  implemented).** `docs/concept/skill-graph/learning-unit-wiring-concept-2026-11-14.md`
  is the binding statement (decisions B1 to B16). Three concepts build on each
  other: a cluster structures goals; a unit is a cluster that is learned in
  one piece (begun, completed, and only then what lies after it) and thereby
  takes part in the order; a unit with assessments additionally proves the
  independent application of its own content goals. Being a unit is declared
  in the unit entry of the placement layer, which points to the cluster; own
  goals and sub-units follow from `contains`. Not every cluster is a unit,
  and subjects are not. A unit has assessments when its entry names coverage
  reviews for own assessments; these assessments lie in its cluster (they
  move there; view rule 5 rules out a second parent cluster) and cover each
  of its own content goals (R1 to R5 unchanged). A unit without assessments
  only orders its goals and may hold content goals directly; in the end every
  content goal lies in a unit with assessments. Only content goals need a
  unit. The children of a unit are its direct sub-units and its own goals;
  there are no uniform levels. Subject units live in the canonical landscape
  and hold in every Land; stages, school years and phases are plan units of a
  Land across the selected subjects, in a fixed order. Between two units that
  are children of the same unit the relation is `after` (the intended order:
  the other unit is completed before this one begins); between atomic goals
  it is `requires`, which is a special `after` that additionally states the
  need. An `after` holds for all goals of its two units, as an order and
  never as a need, and no cluster carries `requires`. Rules E1 to E4 keep the
  two consistent, each looking at the children of one unit (E1: units form a
  tree; E2: an order of all goals exists that keeps every need and every
  `after` with each unit in one piece; E3: the `requires` between goals of
  different units are a subset of the `after` inherited to the leaves, that
  is, where a need separates two child units of the smallest unit that
  contains both goals, the `after` between them is declared; E4: no redundant
  declaration among the children of a unit). An `after` never changes the
  frontier and locks nothing. In the learning mode "unit by unit" it decides
  which reachable goal comes next: first from a child that is due (everything
  it must come after is done), among those from a unit already begun. That a
  unit builds on the independent application of another is said only by its
  `after` and followed by the learning mode: no `requires` points to an
  assessment goal, and there is no unit lock, so the open access profile of
  Graph Definition §11.5 is dropped. The 170 existing edges from ordinary
  goals to assessments contradict this and go to the subject review. Every Land
  carries a subject unit without sub-units whole in one plan unit. The
  learner map shows units and atomic goals only: for display, the learner's
  graph is cleaned of the clusters that are not units, `contains` is kept
  across the removed clusters, and subjects act as filters. All clusters
  appear in the goal tree. Units are introduced top-down: plan units first
  (only the plans of the Länder change), subject units below them, their
  assessments last. There is no timeline and no stage-specific rule. Never
  author `requires` on a cluster of a canonical landscape: today's readers
  inherit it to every atomic goal and `CQR-001` rejects it; inheritance stays
  the reading of transition data outside the canonical Gymnasium catalog.
  Until the follow-up work in section 10 of the document is done, the tools
  enforce the unit contract of 12 November. Graph Definition §11 to §13
  distinguish the binding target model from that implemented compatibility
  contract; target wording does not assert completed migration.
  A first, surface-only step is implemented: the learner map
  (`app/src/components/learningUnitMap/learnerUnitMapProjection.ts` and
  `learnerUnitMapPreview.ts`) renders the learner's graph as units and atomic
  goals for Mathematics and Physics only, under a visible construction-site
  notice; other subjects appear in the goal tree only, and the tree view is
  unchanged. Units are not declared in the curriculum yet, so this preview
  takes the sections of the Land views as stand-ins, top-down by a step
  control, orders sibling sections as the view lists them, and merges the two
  stages across the subjects through a provisional table of view node ids
  (`PROVISIONAL_STAGE_PLAN_UNITS`), to be removed once plan units are
  declared. `buildLearnerMapProjection` is kept but no longer rendered.


- **Stage authority and normative precedence (15 November 2026).** The F7
  bilingual Graph Definition source states the binding target model and
  labels the previous 1.2 ownership representation as compatibility. One
  shared plan per Land and duration model governs all selected subjects;
  course profiles may select contributions but cannot contradict the stage
  of a stable goal. Its full root has only Sekundarstufe I and II, exactly
  II `after` I; orientation, practice and assessment goals belong inside
  these stages. A single-stage view is a derived excerpt; the nationwide
  canonical structure is no Land plan. `Geführt in` means source-evidenced
  curricular assignment; `steht in` means learning placement. A canonical
  phase may justify an explicitly provisional default, never official
  coverage. A support reference's authored position asserts no stage.
  Necessary atoms outside the carried seed targets receive one derived
  placement at their earliest actual need in the closed personal scope,
  independently of mastery. Already carried late targets are not silently
  moved; their backflows remain findings until explicitly repaired.
  E1 to E4 apply per declaration layer and to derived preparation. R4 is
  E1; R1 to R5 govern units with assessments. Assessment-free units only
  order and recognize nothing. `GD-U14`'s formerly open access profile is
  retired in the target model, without claiming historical code removal.
  The stage-plan foundation under `contracts/curriculum-package/v1.3/` is
  not a published package version. Zero real Land plans are activated;
  shared production-reader migration remains open. Subject-unit migration,
  B3/B13 acceptance, packages, recognition and learning-mode runtime require
  F8 to F13 and their own evidence. Existing atomic G17 across the complete
  21-root catalog, immutable V9 evidence, quality floors, focus rules,
  learner results and recognition semantics remain unchanged.

This is concept documentation plus a static authoring contract and validator,
not an implemented runtime or access policy. See `docs/concept/skill-graph/learning-units.md`,
`docs/concept/skill-graph/learning-unit-progression.md`,
`docs/concept/skill-graph/learning-unit-design-and-examples.md` (design criteria
and worked candidates) and Graph Definition §11 (learning units), §12 (optional
acquisition and time planning) and §13.3 (unit validity rules);
capacity details remain in `docs/concept/didactic/curriculum-time-axis-and-pacing.md`.

### 2.5 Knowledge context

Product Owner requirement of 13 November 2026: **the learner's knowledge
context must be respected.** For every learning goal it is derived
deterministically from data stored in the graph, compact enough to accompany
every step, and given to every AI step that generates or reviews content of
the skill landscape, as a constant cross-check, and to the coach together
with the respective goal.

- **Definition.** The secured goals `W(g)` of an atomic goal are the atomic
  goals it requires directly or transitively (inherit, expand to atoms, close
  transitively). The knowledge context is a projection, not stored data: the
  goal itself, what it builds on (the goals of `W(g)` that no other goal of
  `W(g)` requires), the secured goals, what leads on from it (its direct
  dependents), and what is "not yet" (the first goals of the same area
  outside `W(g)`; an area is a cluster directly below the subject root).
  Only ordinary goals are listed. An assessment or memory goal develops
  nothing and may use `W(q)`.
- **Rule of use.** What some goal of the catalog develops may be used only if
  that goal is secured. What no goal of the catalog develops is baseline
  knowledge and is judged by review. The rule is the same for generator,
  reviewer and coach.
- **Sufficiency.** The context is exactly as good as the edges. The existing
  gates establish that `requires` is acyclic, atomic and transitively minimal;
  none establishes that the prerequisites of a goal suffice to learn it. The
  derivation of 13 November 2026 shows, for example, that the Mathematics
  goal on differentiating polynomial functions secures no goal on linear,
  quadratic, power or polynomial functions; in English, History and Latin no
  ordinary goal has any prerequisite. Until a subject is reviewed for
  sufficiency, its derived context is a mirror for the graph and must not be
  used to restrict the coach.
- **Findings, never repairs.** A competence that is needed but not secured is
  a candidate `requires` edge (a pedagogical modelling decision with honest
  provenance, through subject review), a goal that reaches into later subject
  matter, or a gap in the catalog. Do not add an edge, narrow a goal text or
  invent a goal to make a context fit.
- **Monotone verdicts.** An added edge only enlarges `W(g)`; content that
  stayed inside the context still does. Only a goal whose `W(g)` loses a goal
  needs its content reviewed again.
- **Tool.** `npm --prefix app run knowledge-context -- <goalId> [--full]`
  prints the context of one goal, `-- --cluster <goalId>` of every atomic
  goal below a cluster, and `npm --prefix app run report:knowledge-context`
  the sizes per subject (`app/scripts/lib/knowledgeContext.ts`, built on the
  graph class of the learning-unit validator; `test:knowledge-context` runs
  in required CI and pins no catalog count). Derive the context with this
  tool before generating or reviewing content of a goal; do not re-derive it
  by hand.
- **Status.** Only the derivation exists. No gate, no generation pipeline
  and no coach uses the context yet. Order of introduction: derive (done),
  review sufficiency block by block (pilot done on 13 November 2026: 20 of 39
  goals insufficient by both independent reviewers,
  `docs/dev/knowledge-context-sufficiency-pilot-2026-11-13.md`; subject
  review of its 15 high-confidence findings on 14 November 2026: both
  reviewers recommend twelve edges and two narrower goal texts, which would
  change 14 goals, and disagree on one cross-subject Physics edge; nothing is
  applied yet, `docs/dev/knowledge-context-subject-review-2026-11-14.md`),
  check images, cards and tasks, serve the coach per subject once it is
  sufficient. Open: whether
  sufficiency becomes a milestone gate, and whether goals should name the
  terms they introduce. Do not call the context of a goal "context" alone;
  that word names the resolved curriculum context.

See `docs/concept/skill-graph/knowledge-context.md` and the working plan
`docs/dev/mathematics-physics-learning-units-plan.md`, sections 4, 6 and 7.

---

## 3. Semantics of the `Goal` fields

The `Goal` type in code currently uses a minimal set of fields.  
Semantics (the “meaning”) of those fields is:

- `id`  
  Short, stable identifier, used everywhere in the app.  
  Conventions (examples):
  - E-phase: `L_A1`, `L_AG4`, `TF_E2`, …
  - Q3 Stochastik: `TF_Q3_2_WAHRSCH_VERTEILUNGEN`, `Q3_2_03_BERNOULLI_KETTEN`, …

- `title`  
  Short phrase naming the competence. Shown prominently in the UI.

- `description`  
  Full-sentence learning goal, typically of the form:  
  _“Die lernende Person kann …”_  
  This should be understandable for teachers and learners, not only for machines.

- `phase`  
  Curriculum-specific grouping (semester, module, year).  
  *Example (Hessen math):* `E`, `Q1`, `Q2`, `Q3`, `Q4`.

- `area`  
  Domain area or strand (e.g. `Analysis`, `Geometry`, `Process Skills`). Adjust freely per landscape.

- `level`  
  Difficulty tier for the native curriculum.  
  *Example (Hessen math):* `1/2/3` map to Anforderungsbereiche I–III. In other landscapes, map to whatever taxonomy you need.

- `core`  
  - `true` = Kernziel (Pflichtstoff für alle Schüler:innen).
  - `false` = Erweiterung (typisch: LK-Inhalte oder Vertiefungen).

- `weight`  
  Relative importance of this goal for **progress and later grading**.  
  Used to compute weighted averages over sets of goals (e.g. all E1 core goals).
  - **Hessen Math (Gymnasiale Oberstufe, KC 2024):**  
    Atomic goals use `weight = 1`.  
    Cluster goals use `weight = (# of unique atomic descendants)` so progress is proportional to actual goal count.  
    If a goal appears under multiple parents, clusters count that atomic goal only once (set‑union) to avoid double counting.

- `requires`  
  List of IDs that are **didactic prerequisites** for this goal.  
  LLMs and UIs should:
  - use these to avoid suggesting goals whose prerequisites are clearly nicht gemeistert,
  - use them to compute “Frontiers” (see below).

- `contains`  
  List of IDs that are **subgoals** of this goal (cluster relationship).  
  Mainly used for navigation (“drill down”) and summaries.

- `examples`  
  List of **example task IDs** or labels that exercise this goal.  
  Actual tasks/exercises can be kept elsewhere; this field is just a cross-reference.

> **Important invariant for agents:**  
> When adding or modifying goals, keep the DAG property: do not introduce `requires` or `contains` cycles.

---

## 4. Mastery model

The **4 November 2026 Product Owner decision** supersedes the 31 October
preparation-discharge model. Transitive minimality remains mandatory. Direct
ordinary mastery establishes understanding; implicit mastery establishes the
competence through independent application in its relevant passed assessments.
Both mean completed globally: effective mastery satisfies later prerequisites
and counts toward total progress. Later consumers, focus changes and a different
Personal Curriculum do not withdraw a valid recognition.

Store only the existing binary result per atomic goal: `mastery[goalId] ∈ {0,1}`.
Here `0` means no explicit completion; a goal may nevertheless be effectively
mastered through derived recognition. Let M be explicit mastery and I the
recognition derived from fixed authoritative learning-unit contracts; use M_eff = M ∪ I
for competence, ordinary prerequisites and total progress. This is not a second
stored outcome, partial mastery, a higher numeric tier or a separate pass.
Assessment and memory goals themselves are never implicit: use their normal
binary grading or verified-recall results.

Recognition considers every transitive consumer within the authoritative
directly owning learning unit. Traverse full effective prerequisite paths through mastered
intermediate goals. In Q → B → A, ordinary B alone mastered does not discharge
A while the local exam Q is open. Once all relevant local assessment/card
obligations are met, A and B can be recognized and remain completed for later
units. A child unit can finish while a later or parent exam is open. A temporary
focus is not a learning unit. Uncovered ordinary endpoints are authoring
faults, never zero-work recognition; a failed structural calculation gives no
new implicit credit. Required card targets remain explicit independently.

**Confirmation of 11 November 2026 (Product Owner).** This recognition rule
stays: implicit mastery is derived per valid local contract of the owning
learning unit, and an own ordinary goal is recognized once it is no longer
required by any open own assessment or memory goal of that unit (`N_U`, `I_U`
in Graph Definition §13). Example: assessments Q1 and Q2 belong to the same
unit and both require A; when Q1 is passed, A stays open until Q2 is passed as
well. The alternative recorded on the archived branch of PR #83 as a
"6 November 2026 target decision" (immediate recognition from the qualified
coverage list `C(q)` of a single passed assessment, including proof by a parent
or foreign unit) was reviewed and is **not adopted**. Do not port its formulas,
its rewrite of `docs/concept/skill-graph/latex/check-assessment-model.py` or its
diagrams. The rule is only sound inside units that satisfy the validity rules
R1–R5 of §2.4.

The normal tasks and rubrics MUST require independent application of every
competence recognized by the relevant assessment set. A missing essential
competence must not be compensated by unrelated points while it is recognized.
Independent review tests whether passing without a claimed competence is
possible. A requires path supplies structure, not proof of task quality.
No extra runtime qualifying evidence, manually curated waiver list, second
per-part result or mastery backfill is permitted. Unreviewed legacy tasks do
not automatically satisfy this stronger authoring contract.

Keep recognition semantics stable for each assessment identity and retain the
authoritative authorship context needed to reconstruct it outside today's
selected plan. New graph edges or a broader new unit must not grant additional
competencies to old exam results (rule R5: the contract is versioned, and this
runtime contract is a precondition before implicit recognition is enabled in
production). Equivalent task forms preserve that contract;
a different recognition claim requires a distinct assessment identity or an
explicitly reviewed migration. Do not invent a learner qualification registry.

See `docs/concept/skill-graph/assessment-gated-completion.md` and the decision
record `docs/concept/skill-graph/completion-semantics-clarification-2026-11-04.md`.
This is the corrected concept, not a claim that current main implements it.
Implementation was replanned on 12 November 2026 after the concept
reconciliation (`docs/dev/mathematics-physics-learning-units-plan.md`, §2.4);
old PR work is reused selectively. Do not continue the old PR's
runtime/curriculum rollout.

Cluster progress aggregates effective mastery of unique atomic descendants;
no cluster or unit completion writes mastery to its children.

For goals authoritatively classified as `semanticKind: "orientation"`, this
numeric field is only a compatibility completion marker: `1` means that the
learner received the motivation/orientation, either explicitly wished to
continue or actively engaged in a tailored motivational follow-up, and then
accepted a separate coach offer to close after a positive summary. Merely
repeating or selecting one of the possibilities offered by the coach starts
that follow-up; it does not complete the orientation. The coach must connect
the selected interest to concrete things the learner can understand, explore,
shape, or do, and invite one low-pressure personal reaction, choice, or
question. This does **not** certify subject-matter mastery. Orientation must
show concrete possibilities and honest positive perspectives of the following
material; it must not test prior knowledge, terminology, calculations,
details, correctness, transfer, recall, or exam performance. Do not expose a
graded 0/50/100 mastery control for these nodes.

Goal types determine how this one outcome is reached. Orientation follows the
interaction contract above. SRS/memorization goals (`srs-deck:*` /
`memorization`) derive their goal outcome from card-level review data under the
memory workflow; a coach must not manually assign it. Card scheduling and
review data describe the learning process, not additional goal-result states.

**Implementation status (30 October 2026):** new general mastery writes enforce
`0` or `1`, and ordinary atomic goal controls offer binary choices. Historical
numeric rows remain readable through the shared legacy threshold `>= 0.9`;
this does not introduce partial outcomes or round existing database values.
The technical completion pilot, protected card synchronization and import
boundaries are documented in `docs/dev/assessment-gated-completion-pilot.md`.
Goal-type workflow details remain in
`docs/concept/runtime-workflows/learning-workflow.md`.

The intended use is:

1. **Learner, teacher or coach** records whether an ordinary atomic goal is mastered under its completion contract.
2. The backend computes aggregate progress from the binary atomic outcomes.
3. A grading rule (not yet implemented) maps these to familiar school grades (1–6).

When agents generate feedback or suggestions, they should:

- Use the authoritative mastered/not-mastered result; do not invent degrees of mastery.
- Suggest unmastered goals whose effective prerequisites are satisfied under
  the selected normal or strict scope mode.

For coach-led learning, finishing a task and mastering a goal are distinct.
The coach makes its evidence decision privately when sufficient learner work
is available. For an ordinary content goal this can happen during the chat;
for an `examData` assessment goal it happens after grading the complete
submission. A solved task alone does not imply mastery, and a learner's
agreement is not evidence. Genuine multi-step transfer within one task can
suffice; count the evidence, not the number of task labels. Once every aspect
is sufficiently shown, stop assessing; there is no extra-task quota. When the
goal is mastered, commit the success
immediately, before claiming it was saved or announcing a successor. Do not
condition this write on a separate learner agreement to close. If the write
fails, do not claim that the goal was saved. Guide ordinary learning toward
mastery with targeted checks of any missing aspect. After a confirmed save,
say that the goal is mastered and saved, offer the backend-selected next topic
if available, and wait for the learner's answer. A learner may instead remain
for questions or optional unassessed practice without reopening saved mastery.
If evidence is missing, never offer mastery or a mastered next topic as a
learner choice. An accepted, authorized offer cannot be reversed by reflection
on unchanged work; report an actual session, state or write failure as such.
A request for the next topic after declining another task never accepts that
task. If the goal remains open, use only authorized redirect options and never
infer mastery from that request. An unsuccessful exam attempt
produces feedback but no learner-state write: SkillPilot does not distinguish
"not passed" from "not attempted", and the learner may retry the same exam
without a limit. After grading, disclose the score, result, tasks and solution
and discuss them on request. This can reduce the evidential value of a later
retry of the same exam; it is a known current limitation without a special
countermeasure. A verdict on the submitted work stays fixed unless the learner
provides new substantive work or an actual grading error is corrected; a
plain "weiter" does not trigger reassessment. After feedback, invite questions
or continuation and wait for the learner's reply before showing the next task
or goal. Apply this with or without autopilot. Answer questions about the
current content and respect a pause. Begin new content and render its image
only after recognizable agreement to continue, such as “Alles klar, weiter”.
At the actual end, offer a fitting close without assuming a next task. Small
explanations and hints during an unfinished task do not need separate
confirmation. Orientation and Verified Recall retain their goal-type workflows
for reaching the same single binary goal outcome.

---

## 5. Frontier: “next sensible steps”

The **frontier** of a learner is the set of goals that are **good next candidates**:

- All checked `requires` are satisfied: within the
  selected focus in normal mode, globally in explicit strict mode.
- The atomic goal itself is not yet mastered.

For the set `M_A` of mastered atomic goals:

```text
Frontier F = {
  g ∈ targetAtomicGoals(focus) \ M_A |
    ∀ r ∈ checkedRequires(g, focus, strictMode):
      satisfied(r, M_A, focus, strictMode)
}
```

For atomic prerequisites, satisfaction means mastery. For prerequisite clusters,
it means mastery of all atomic descendants relevant to the selected mode. Normal
mode restricts requirements and cluster satisfaction to the focus; strict mode
checks them globally. See the complete definitions in
`docs/concept/skill-graph/graph-definition.md`, §4.2 (global frontier) and
§5.3 (normal and strict mode).

Agents that recommend tasks should:

* Use the **frontier** as the primary pool for “what next?”.
* Possibly sort frontier goals by:

  * phase,
  * area,
  * level,
  * or teacher preference.

The frontier is backend-owned (§12.1). The Cockpit and the coach adapters
consume the backend result instead of recomputing it.

---

## 6. Mapping curricula into the graph (example: Hessian KC)

Any curriculum or skill framework can be mapped by following the same blueprint.  
For the Hessian *Kerncurriculum Mathematik gymnasiale Oberstufe* this means:

1. **Process competencies (K1–K6)** – argumentieren, modellieren, Darstellungen verwenden, …
2. **Content competencies per topic field** – e.g. E.1–E.7, Q1.1–Q4.3.
3. **Cross-cutting dimensions** – Leitideen (L1–L5), digitale Werkzeuge, etc.

Whatever the framework, interpret it as a **universe of required goals** and encode it as a skill graph using the following strategy.

### 6.1 Structural layers

To stay organized, we think in **layers**:

* **Layer 0: Root (optional)** – one node that contains everything.
* **Layer 1: High-level clusters** – e.g. Kurshalbjahre, grade levels, or modules (`E_Analysis`, `Q1_Analysis`, … in the Hessian case).
* **Layer 2: Topic clusters** – one per table row / topic grouping (e.g. `TF_E2`, `TF_Q3_2_WAHRSCH_VERTEILUNGEN`). These `contains` the atomic goals derived from that unit.
* **Layer 3: Atomic goals** – each bullet (or small cluster of bullets) becomes 1–3 measurable goals.

Agents adding new content from the curriculum should:

* Prefer to add **atomic goals on Layer 3**.
* Link them to an appropriate **Themenfeld-cluster (Layer 2)** via `contains`.
* Optionally adjust the relevant **Kurshalbjahr-cluster (Layer 1)**.

### 6.2 Dependencies (`requires`) between Themenfeldern

Dependencies between Themenfeldern should be **simple and regular**, not over-engineered:

* Within a Themenfeld:

  * Order atomic goals in a reasonable sequence.
  * Let each goal require the 1–2 key predecessors.

* Between Themenfeldern (or modules):

  * Use the logical structure of the curriculum:
    * Example: `Q1` Analysis requires the E-phase basics; `TF_Q3_2` (binomial distributions) requires `TF_Q3_1` (foundations).
  * Express these dependencies through the relevant **atomic goals at both ends**, as required by §2.2. Cluster-level `requires` in existing data are transitional, including claims applying to all descendants; migrate them in the order defined there. Derive topic-level summaries from the atomic layer.

Agents should **avoid creating very long or tangled `requires` chains**
if they can be expressed via a small number of well-chosen prerequisites.

### 6.3 Phase-local autonomy branches vs. global final-exam branches

For phase-based school curricula, ordinary didactic routes should normally end in **phase-local terminal autonomy goals**, not only in distant global final-exam nodes.

Practical modeling rule:

* Create local autonomy clusters such as `Übungen E-Phase`, `Übungen Q1`, `Übungen Q2`, `Übungen Q3`, `Übungen Q4` where appropriate.
* Initial rollout scope: canonical Gymnasium Mathematik, Sekundarstufe I. In that scope, model local autonomy at the year level: each visible year or year-band scope must contain a `Prüfungen Jahrgangsstufe <n>` folder inside the respective year/year-band structure, and the actual assessment tasks live as individual exam nodes below that folder.
* Do not place ordinary Sek-I year practice for canonical Gymnasium Mathematik as one separate `Übungen Sekundarstufe I` learner-facing branch or as a separate `Sek-I-Abschlussaufgaben Mathematik` capstone. The learner-facing terminal endpoints for Sek I mathematics are the individual year-level exam tasks under the matching `Prüfungen Jahrgangsstufe <n>` folders.
* If an old aggregate Sek-I practice cluster is retained only for compatibility, keep it out of learner-facing composition views and mark it with `extendedData.applicabilityProjection = "excluded"` so child-union applicability does not project it as a visible branch.
* Sek-I mathematics exam tasks must use coherent, age-appropriate contexts that actually carry the mathematics. Avoid copied umbrella scenarios, artificial mega-contexts, and tasks that only wrap isolated procedures in decorative prose.
* For year-level exam tasks, prefer a low-floor/high-ceiling shape: an accessible entry from concrete data or representations, followed by at least one reasoning, checking, model-limit, or explanation prompt at a level appropriate to the year.
* Keep each exam node's `requires` and `examData.coveredGoalIds` aligned with the goals that the task actually assesses; do not bulk-copy the entire year coverage onto every individual task.
* Other Sek-I subjects or school forms may adopt the same pattern after their own learner-facing composition views and assessment semantics have been reviewed; do not force the Mathematik rollout rule onto them by default.
* If the curriculum has cross-phase process competencies, a separate branch such as `Übungen Prozesskompetenzen` can be appropriate.
* Keep global Abitur/final-exam branches **separate** from these local exercise branches.
* Do not use the global final-exam branch as the only terminal target for ordinary phase goals.

Interpretation:

* Local exercise branches model ordinary klausur-style self-sufficiency inside a phase.
* In canonical Gymnasium Mathematik Sek I, year exam folders make it possible to verify that each learning route ends in a task appropriate to the learner's current year, instead of only in a coarse stage-level practice bucket.
* Global final-exam branches model an additional assessment layer with different selection and assessment semantics.
* Mature learner-facing landscapes should aim for atomic route coverage from motivation anchors through ordinary atomic goals toward one or more local terminal autonomy goals.

---

## 7. Conventions for new learning goals

When adding new goals (especially atomic ones), follow these conventions:

1. **Descriptions are student-facing**

   * Use *“Die lernende Person kann …”* style wording.
   * Make them specific enough to be tested in 1–3 tasks.
   * Formulate competencies around motivation, understanding, reasoning, or
     purposeful application, problem solving, and construction. Merely looking
     up a formula and substituting values is not a learning goal.
   * Do not mention a *Formelsammlung* / *formula sheet* in canonical goal
     titles or descriptions unless the normative curriculum explicitly makes
     its use part of the competence. Such a rare exception must be documented
     with an exact source reference and quote in
     `scripts/config/competency-wording-exceptions.json`. Source-extraction
     artifacts may retain the original wording without becoming operative
     competence formulations.
   * Never convert `ae`, `oe`, or `ue` to umlauts indiscriminately in authored
     or displayed text. Review every proposed word and field in its actual
     context first; valid spellings such as `Fotoeffekt`, `photoelektrisch`,
     `Koeffizient`, names, URLs, IDs, and formulas must remain intact. Record
     corrections as explicit before/after cases and update only their affected
     evidence bindings. A spelling fix is not a new substantive QA approval.

2. **IDs reflect structure**

   * Pick a convention that mirrors the native curriculum (semester, module, etc.).
   * Example (Hessen math): `E2_01_...`, `Q3_2_03_BERNOULLI_KETTEN`, cluster IDs starting with `TF_`.

3. **Keep goals atomic**

   * Avoid “kann Analysis in der Oberstufe”.
   * Aim for granularity where one exam task can reasonably assess 1–3 goals.

4. **DAG sanity**

   * Check that `requires` and `contains` don’t produce cycles.
   * `requires` should generally **point “backwards” in time** (to earlier phases or earlier goals in the same Themenfeld).

5. **Core vs Extension**

   * Use `core: true` for what every student (GK) must be able to do.
   * Use `core: false` for:

     * LK-only extensions,
     * enrichment topics,
     * deeper applications.

6. **Separate local autonomy from global exam layers**

   * In phase-based school curricula, add explicit local terminal autonomy branches for ordinary learning routes.
   * Keep global Abitur/final-exam goals on their own branch instead of mixing them into the normal phase exercise structure.
   * Do not introduce coarse cluster-level `requires` just to connect ordinary curriculum goals to a global exam branch.

### 7.1 Semantic atomicity review

Technical content leaf nodes (`contains: []`) are not automatically semantically atomic.

Rule:

* A content leaf goal is semantically atomic only if it contains exactly one content learning goal.
* Broad titles/descriptions that combine independent routines such as “A, B und C bestimmen” should be split or sent to developer review.
* Some combinations such as “berechnen und deuten” may still be one semantic goal; this must be judged from the content, not from keywords alone.
* Non-content leaves such as motivation anchors, SRS/memorization decks, terminal practice nodes, and `examData` assessment nodes are out of scope for semantic content atomicity; they are covered by their own QA lanes.

Process:

* Semantic atomicity is tracked in external review ledgers under `curricula/DE/Gymnasium/quality/semantic-atomicity/`.
* Review records use `atomic`, `needs_developer_review`, or `non_atomic`.
* `atomic` means `semanticAtomic: true`; uncertain or too-broad goals stay visible in the review queue.
* Review records include a fingerprint of semantic fields, so later small graph edits make prior decisions stale until the goal is reviewed again.
* The local Workbench route `/semantic-atomicity-review` is only an algorithmic ledger editor. Semantic bulk review decisions are made from the Codex command line and then written back to the ledger.
* The pilot documentation is `docs/qa-ci/semantic-atomicity-review.md`.

### 7.2 Memory-card review

Memory/SRS cards are not a default learning strategy. They are justified only where a learner must reliably recall compact facts, formulas, vocabulary, notation, definitions, or similar hard memory items. Ordinary mathematical understanding should remain anchored in explanation, worked examples, problem solving, `requires`, and assessment nodes.

Rule:

* Normal SkillPilot learning goals must exist first.
* Then all relevant ordinary atomic goals in the configured scope are reviewed for memory-card suitability.
* The review is tracked under `curricula/DE/Gymnasium/quality/memory-card-review/`.
* Review records use `no_memory_needed`, `memory_required`, or `needs_developer_review`.
* `memory_required` records must reference concrete `memoryGoalIds` and `deckIds`.
* Every active primary card must also be reviewed in the matching `*.cards.review.jsonl` ledger.
* A kept card needs `kept`, `necessary: true`, and at least one concrete `originGoalId`.
* Each `originGoalId` of a kept card must be a current `memory_required` ordinary atomic goal and must reference the card's deck.
* Configured `visibilityScopes` must prove that when a `memory_required` goal is visible in a learner-facing composition view, at least one of its referenced memory goals is visible in that same view.
* Cards marked `remove` may stay in the card ledger as an audit trail, but they must be removed from active deck files.
* Every existing `nodeKind: "memory"` / `memorization` / `srs-deck:*` goal in the configured scope must be traced back through kept cards and at least one `memory_required` decision.
* Review records include a fingerprint of semantic goal fields, so goal text changes make the decision stale.
* Human-readable audit reports under `docs/qa-ci/status/memory-card-review-*.md` are generated from the ledgers; they must not be edited as a second source of truth.
* `CQR-302` is the M6 dashboard rule for memory-card decision tracing. `M5` stays the core curriculum QA level and does not depend on memory-card review configuration. Missing or open memory-card review configuration counts as open for `M6`. In the status generated on 10 November 2026 it passes for Biologie, Chemie, Deutsch, Geschichte, Informatik, Latein, Mathematik, Physik, Politik und Wirtschaft and Wirtschaftswissenschaften (all `Gymnasium, DE`); Biologie, Chemie, Mathematik, Physik and Wirtschaftswissenschaften additionally pass `CQR-303` (M7). This list is a snapshot: the generated `docs/qa-ci/status/curriculum-quality-status.json` and the protected floors in `app/scripts/config/curriculum-maturity-floor-policy.json` are authoritative.

Naming and ownership:

* Public memory decks for canonical German Gymnasium subjects are owned by the DE/Gymnasium canonical layer, not by a Bundesland source lane.
* Deck IDs, active card IDs, and public deck filenames must not encode source-state prefixes such as `he`, `hes`, or `DE-HE`; use canonical scope names such as `de_gymnasium_math_*`, `de_gymnasium_physics_*`, and `de_gymnasium_chemistry_*`.
* Canonical deck source files live under `curricula/DE/Gymnasium/memory-decks/` and are deployed to runtime `/data/...` files. They intentionally do not live below `curricula/DE/Gymnasium/canonical/`, because that directory is reserved for `SkillLandscape` JSON files scanned by validators.
* Bundesland-specific visibility is handled by composition views, applicability, provenance, and review ledgers. It must not be encoded by duplicating decks or by naming a canonical deck after one source state.
* Source-state information may remain in provenance and retained source assets, but not in learner-facing SRS deck identifiers.

Interpretation:

* `no_memory_needed` is the conservative default.
* A deck should stay narrow and should not become a second curriculum hidden inside flashcards.
* Passing `CQR-302` means the configured scope has current semantic goal-level decisions, current card-level origin traces, configured learner-facing visibility for required memory nodes, and no unresolved/removal debt in active decks. It upgrades a curriculum from core-ready `M5` to memory-layer-ready `M6`.
* Canonical description, assessment, route, mapping, or composition-view work is not complete until the curriculum-quality status has been regenerated and the protected maturity floors have been checked. A previously reached maturity such as `M6` must not silently fall to a lower level; the floor gate reports the concrete non-passing CQR rules and fails closed. Lowering a protected floor requires an explicit product-owner decision with the fachliche reason recorded in the floor policy.
* The CQR gate pins every canonical Gymnasium catalog entry and every registered
  QA scope. It checks the catalog independently, requires each applicable rule
  result exactly once with `pass`, and rejects unpinned maturity gains as well
  as losses. The Git base policy protects pins and existing endpoint-visibility
  coverage against removal or reduction. `CQR-001`, `CQR-002` and `CQR-501`
  apply even at `M0`; the complete-catalog G17 checker also fails CI directly.
  Endpoint visibility (`CQR-104`) is explicitly pinned for eight of twelve
  scopes. The four upper-secondary Mathematics, Physics, Chemistry and Biology
  gaps remain open; an unconfigured scope is not a visibility pass. Direct
  route coverage (`CQR-102`) applies to all twelve scopes, while the stronger
  semantic route rule (`GVR-012`) is required in four scopes (Mathematics
  Sek I/Sek II, Biology Sek II and Physics Sek II). Physics Sek I and Chemistry
  Sek II retain five/three route findings; six other scopes lack complete
  current ledgers. The shared factory adds reviewed explicit Physics
  `goalEntry` stage targets to the established QA lanes (96→101 and 306→316
  curricular atoms), without changing terminals, graphs, views or roles.
  Separately, 43 inherited Physics Sek II stage targets lie beyond that lane;
  42 lack a terminal route in the broader diagnostic. Four passing registered
  scopes do not prove complete stage-target coverage. The shared semantic
  scope inventory accounts for all twelve. These limits must
  remain visible in the rule register; no review or learner result is inferred.
* Product Owner decision of **13 November 2026**: `GVR-012` shall become
  mandatory from subject maturity `M7`, covering every registered QA scope of
  each subject obligated to meet M7. This binding target has not yet been
  activated across that domain: four of today's seven M7 scopes pass and are
  directly required.
  First close the remaining current M7 classification and route gaps with
  evidence, then enforce the complete M7 obligation, including future
  promotions. The inventory remains twelve scopes; the five M6 scopes join
  the mandatory domain when their subjects advance to M7. `GVR-012` stays
  `PARTIAL` until that complete domain is fail-closed; twelve passing scopes
  are not required merely because all twelve remain in the inventory. Keep
  the four existing required scopes and all maturity pins unchanged and
  protected even through later status changes. A later hard `GVR-012` gate
  does not automatically upgrade broader `GD-*` obligations. This
  decision neither lowers floors nor supplies missing pass evidence. The
  twelve-scope semantic audit remains diagnostic, with failure on missing
  M6 ledgers as well; it is not an M7 promotion check.
* Do not turn a review queue green by bulk-writing `no_memory_needed`; each decision must be made from the current goal semantics.
* The OpenAI V1 coach offers normal due-card practice through the dedicated
  `start_skillpilot_memory_practice` MCP Apps UI resource. The model-visible
  result contains only bounded status and progress; card front, back and the
  bounded due-card batch live only in result `_meta` for the component.
  `review_skillpilot_memory_practice_card` is app-only, accepts exactly the
  displayed card plus `not_known` or `known`, maps those choices to the internal
  spaced-repetition qualities `1` or `4`, and updates only that card's
  repetition schedule. It never changes mastery or the active goal. Turning a
  card and moving backward or forward inside the supplied batch are component-
  local operations and must not call a tool or write learner state. The model
  starts the component exactly once; after a bounded batch has been reviewed,
  only the component may call the start tool again with the newest state version
  to load the next due batch.
* Normal in-chat card practice and strict Verified Recall are separate modes.
  Only Verified Recall can supply the hard, no-help evidence used by the
  memory-goal mastery rule. Completing today's due cards must not be described
  as mastering or completing the learning goal. The cockpit remains the
  fallback when the component cannot be used.
* Verified Recall uses one server-sized complete batch, never a model-chosen
  subset. The backend owns the card IDs, exact count and order, completeness
  checks, answer-release boundary, atomic persistence, state/version checks,
  idempotency and the continuation after the batch. The model only presents
  every returned prompt, waits for the complete learner submission, compares
  its meaning with the complete answer set, gives feedback, invites questions
  or closure, waits for the learner's answer, and only after consent submits
  one assessment per returned card in one atomic batch write. It must not choose a `batchSize`,
  fetch or save cards in a technical per-card loop, shorten the returned batch,
  or begin the next batch during the feedback turn. After persistence, begin
  a new batch only when the learner agreed to continue. The V1
  operations are `start_skillpilot_verified_recall(learningSessionId)`,
  `get_skillpilot_verified_recall_answers(learningSessionId,
  batchCapability)` and `record_skillpilot_verified_recall_results(
  learningSessionId, gradingCapability, assessments)`. The start result carries
  `batchCapability` and the complete ordered cards; the answer result carries
  `gradingCapability` and the complete ordered answers. `assessments` contains
  exactly one ordered `{passed}` entry per returned card. Semantic grading and
  its explanation stay in the provider conversation; no feedback prose is sent
  to or persisted by the backend. This
  capability-bound write derives its expected state version and idempotency key
  server-side; the model supplies neither `expectedStateVersion` nor
  `clientRequestId`. When a terminal Recall write activates an ordinary atomic
  successor with an authorized image, its one imperative `continuation` uses
  `action: "renderGoalVisualizationThenTeachActiveGoal"` and contains one
  `toolCall` for `render_skillpilot_goal_visualization` whose image-specific
  fields are fully server-filled. That call supplies `goalId` and
  `expectedStateVersion`; the model copies them unchanged and adds only the
  already current unchanged `learningSessionId` required by the global session
  gate. The receipt never mirrors that session capability. The model invokes
  the renderer exactly once after the learner has agreed to continue beyond
  this batch and then begins the active goal. It must not reconstruct the
  image-specific arguments from the successor context or reload context in
  that turn. If the learner agreed only to close and pause, the renderer is
  deferred until a later explicit continuation with fresh context. If
  rendering fails or the host omits the component, it does not retry and
  continues with complete teaching text. Other Recall continuations contain no
  `toolCall`.
* Give every interactive memory-card view its own explicitly bound, reviewed,
  content-addressed MCP Apps UI resource. Do not attach generic MCP
  `ImageContent` to ordinary memory-card tools, expose private card answers in
  `structuredContent`, or reuse another tool's UI resource implicitly. Render
  card text, line breaks, Markdown and mathematics with bundled safe rendering;
  never inject untrusted card HTML.

### 7.3 Atomic goal visualizations

Atomic learning goals may optionally carry one or more didactic image references
for cockpit and provider use. The multilingual OpenAI V1 MCP coach may present
the current goal's visualization through its one explicitly bound MCP Apps UI
resource when the active goal is atomic, has a matching canonical
`goal-visualization` link, and the learner's default-on
`showGoalVisualizationsInChat` preference is not disabled.

Rule:

* Store visualization references directly on the goal in canonical `resourceLinks`, not in a separate learner-facing branch or custom top-level image field.
* Use `type: "goal-visualization"`, `resourceType: "image"`, and `skillpilotId` equal to the containing goal's `id`.
* Public URLs should be root-relative under `/assets/goal-visualizations/...`.
  The OpenAI V1 adapter resolves the matching active atomic goal's asset to an
  absolute public URL and exposes it only through the bounded
  `goalVisualization` projection used by the image renderer. Other resources
  and provider adapters continue to use a normal cockpit deep link such as
  `https://skillpilot.com/?l=<curriculumId>&goal=<goalId>`.
* `render_skillpilot_goal_visualization` is a read-only image renderer. It
  returns bounded `goalVisualization` data in `structuredContent` for the
  image-only widget. Its descriptor is the only goal-visualization descriptor that carries
  `ui.resourceUri` and the `openai/outputTemplate` compatibility alias, both
  pointing to the same active content-addressed resource. The widget displays
  only the approved image; goal title, description, ID, and cockpit URL may be
  retained for validation but are not rendered. A naked MCP `ImageContent`
  block is not the V1 display contract and must not be treated as a guaranteed
  inline presentation.
* V1 publishes exactly one active, hash-bound MCP Apps HTML resource for this
  renderer. Its URI contains the SHA-256 of the self-contained HTML bytes, and
  the renderer binds exactly that active resource. `resources/list` and
  `resources/read` also keep every previously advertised content-addressed
  resource byte-identically readable for provider metadata caches. Ordinary
  context, curriculum/mastery mutations, recall, and exam tools carry no UI
  binding and therefore do not create empty UI boxes. The independently bound
  memory-practice launcher is a separate UI contract and does not weaken this
  image-renderer invariant.
  This is the documented OpenAI component contract: a selected tool links a
  registered `text/html;profile=mcp-app` resource through
  `_meta.ui.resourceUri`, with `_meta["openai/outputTemplate"]` only as the
  ChatGPT compatibility alias. See
  `https://developers.openai.com/plugins/build/chatgpt-ui` and the explicit
  "Structured content only, no component" diagnostic at
  `https://developers.openai.com/plugins/deploy/troubleshooting#server-side-issues`.
  Never infer a visible ChatGPT component from generic MCP content alone.
* Offer the renderer only when the preference is enabled and a safe
  `goalVisualization` projection exists. The widget starts collapsed, becomes
  visible only after a valid image has loaded, and collapses and requests
  teardown when input is absent or malformed or the image fails. These failures
  must not affect the complete ordinary coaching response.
* Image authorization is surface-neutral. Do not inspect `openai/userAgent`,
  infer Desktop/Mobile/App/Browser, or apply any client-surface presentation
  gate. A conforming host may render or decline the UI resource; this optional
  presentation result must never change authentication, authorization, state,
  persistence, or the ordinary chat result.
* A full context or state-changing result qualifies only when the learner has
  agreed to begin or continue the associated goal, its full context contains
  `goalVisualization`, and it permits the renderer. During feedback or a
  pending task/goal closure, never render the next task's or successor goal's
  image. Every previously
  unseen pair of that context's `goalVisualization.goalId` and the authorizing
  result's top-level `stateVersion` creates its own one-shot render
  authorization. After the learner has agreed to continue, call the renderer
  once for that pair as the immediate next tool call, even if an earlier pair in the conversation
  was already rendered. A repeated pair creates no automatic call. Only an
  explicit learner request to show the current image again creates one new
  one-shot authorization after a fresh qualifying result. Copy the pair into
  `goalId` and `expectedStateVersion` unchanged. Never insert another tool call,
  reuse stale authorization, or retry otherwise. Commit positive ordinary or
  exam mastery as soon as the assessment is complete, then give feedback and
  invite questions or continuation; render only after agreement
  to continue and before coaching the associated active goal. The receipt does
  not replace the authoritative full result, and omitted
  host presentation does not weaken the text path.
  The terminal Verified-Recall cross-flow is the narrow exception to deriving
  this call from those generic facts: when its authoritative `continuation`
  has `action: "renderGoalVisualizationThenTeachActiveGoal"`, execute the
  continuation's server-filled image-specific `toolCall` fields unchanged. This remains the
  same single imperative channel; never add a sibling `presentationAction` or
  bind the Recall write itself to the image UI.
* A content-addressed UI URI becomes immutable as soon as it has been advertised
  to a real client, including during draft testing. Replacing widget HTML
  produces a new active hash-bound URI; older URIs remain registered with their
  exact bytes as passive retained resources because provider metadata and chat
  snapshots may request them later. Retention is transport continuity, not a
  second active UI contract: only the current URI may be bound by a tool.
* The renderer result and widget create no state, authorization, goal selection,
  or permanent learner identity. Alt text remains accessibility metadata; the
  visible widget contains exactly the image and no caption, description, goal
  title, technical ID, or cockpit link.
* Image filenames should be the same SkillPilot ID plus image extension, using `<skillpilotId>.<ext>`, so copied assets remain self-identifying without creating Windows path-length problems.
* Keep source image and prompt metadata under `curricula/DE/Gymnasium/visualizations/<subject>/<skillpilotId>/`.
* For Gemini API generated images, keep `image-reconstruction-prompt.de.md` beside the canonical source image. It is a standalone alternative prompt derived from the generated image and may be offered or generated on demand in `/goal-visualization-qa` as a correction base; it does not override human review or fachliche correctness.
* **Image-provider policy, Product Owner decision of 13 September 2026:** KEEP good existing Mathematik and Physik images regardless of provider. For necessary new images or corrections of documented weaknesses, prefer ChatGPT/Codex **image generation**, subject to actual subject-matter quality, suitable representation and fit with the existing approachable visual style. For new Mathematik and Physik raster illustrations, the default image language is friendly, abstract, clear and comic-like rather than photorealistic or sterile-technical; the concrete representation still follows the fachliche need. Nano Banana Pro remains an allowed alternative when it better meets those needs; prior failure of either provider is not required. Programmatically drawn diagrams/SVGs remain narrow, documented fachlich justified exceptions, not a default style replacement. This supersedes the former Nano-Banana-first and retroactive provider-conversion requirements; historical receipts and valid reviews stay intact. Follow the detailed [provider and quality policy](docs/concept/skill-graph/atomic-goal-visualizations.md#provider-priority-and-exception-policy).
* For Nano Banana Pro automation, prefer `npm --prefix app run visualization:generate:nano-banana -- <goal>` with `GEMINI_API_KEY` or `GOOGLE_API_KEY` set; this generates the image, writes trace files under `tmp/`, creates the image-reconstruction prompt, imports the asset, and updates the canonical JSON.
* For manual/tool-based image generation, use `npm --prefix app run visualization:prepare -- <goal>` before generation and `npm --prefix app run visualization:import -- <goal> <file>` after generation instead of hand-building paths, filenames, or JSON links. Pass the actual `--provider` explicitly to both commands and the actual generation prompt via `--prompt` on import; legacy helper defaults or filenames do not identify the provider actually used. For Physics, also pass its canonical `--landscape` and `--subject=physik` to both commands.
* Provider prompts must not include SkillPilot IDs; IDs belong in filenames, directories, JSON links, and prompt metadata only. In provider-facing constraints, prefer neutral phrases such as `technical IDs` instead of naming SkillPilot.
* Record reviewed production batches under `curricula/DE/Gymnasium/quality/goal-visualization-review/`, including rejected/regenerated attempts and visible mathematical risks.
* Generated images are never accepted automatically. Separately inspect the actual image against the current goal and suitable existing style references: calculations, notation, labels, geometry, age fit, text readability, visible artifacts and representation/style fit. Record actual provider/model or tool, prompt/reference strategy, asset hash and review decision. Recheck affected goal, page, context and evidence bindings after substantive image changes; a mechanical hash refresh is not a content review. Preserve the existing transparency and human/AI approval distinction.
* Reject or regenerate any visualization with a wrong or misleading value, marked digit, angle, coordinate, side property, unit conversion, sign rule, counterexample, or notation. Text that is correct does not rescue a misleading drawing.
* If targeted image-generation attempts remain fachlich wrong, use an allowed alternative or a justified precise diagram; record the attempted prompts/reference strategy and visible defects without inventing prerequisite failures. If no candidate meets the same correctness, legibility and style bar, keep rejected candidates inactive, archive the evidence, remove any demonstrably unsuitable active link/published copies, and record the appropriate unresolved or `deferred_provider_limitation` decision. Do not weaken the gates or replace a good existing image merely because a new candidate failed.
* When an atomic goal is split, retain a good existing aggregate image on the surviving parent cluster whenever it still correctly summarizes the combined child content. Add more specific child images separately instead of erasing the useful overview.
* A visualization supports orientation only. Whether shown in the cockpit or
  inline in ChatGPT, it is not source evidence, not an assessment task, not a
  solution or performance record, and not a substitute for explanation or
  practice.
* Before broad rollout, review every image for mathematical correctness, age fit, text readability, accessibility alt text, and licensing/copyright risk.
* Goal-visualization QA is tracked per subject under `curricula/DE/Gymnasium/quality/goal-visualization-qa/*.qa.json`. `CQR-303` now represents complete deep curriculum QA, as defined in `docs/concept/curriculum-quality-and-human-trial.md`: M6 plus the central strict D/P/A/M/V intersection for every current `curricularAtomic` goal, successful required validation checks and no relevant blockers. Images are gate V, not a separate highest maturity. Technical `deferred_provider_limitation` is unfinished work and never a completed exception. An explicit `Approved AI` decision remains AI evidence and requires an exact current asset hash; it never becomes human approval. Gate V and M7 are machine-only: neither `humanApproved` nor `humanIssueIdentified` satisfies or vetoes them. Existing human image approvals, findings, historical artifacts and mandatory human release gates remain intact and are evaluated separately. M7 grants no human approval or practical human-trial completion and does not weaken core M5 or memory M6 requirements.

Reference:

* `docs/concept/skill-graph/atomic-goal-visualizations.md`

### 7.4 Learning-goal books and evidence review

The first learning-goal book edition is a deterministic publication and review
surface for ordinary technical atomic goals in reviewed learner-facing
composition views. It is not a second curriculum source.

Rules:

* Build HTML and PDF from one shared, versioned BookModel.
* Commit the curriculum, publication configuration, reviewed source bindings,
  visualization sources and renderer, not the generated publications under
  `app/public/lernzielbuch/`. `npm --prefix app run build:goal-books` generates
  the registered PDFs (five subjects in
  `app/src/utils/goalBookPublicationRegistry.ts`), BookModels, source indexes, render manifests and
  publication index before application packaging. CI shares one verified
  publication artifact across jobs; neither missing output nor a stale cache
  may bypass the existing publication checks. See
  `docs/deploy/goal-book-build-and-history-cleanup.md`.
* Include each eligible `target` goal exactly once and on exactly one complete
  PDF page. Cluster and structure nodes provide chapter paths; memory,
  orientation, practice/assessment, exam, and runtime-support nodes require
  separate later edition contracts.
* Show the full public **Lernziel-ID** on every goal page. Never confuse this
  curriculum identifier with a learner's permanent SkillPilot ID.
* Use a stable topological order that respects direct in-scope `requires`.
  `contains` supplies chapter context and deterministic ordering preferences,
  but never overrides a prerequisite edge.
* Render direct `requires` and derived reverse-`requires` as checked links to
  stable goal destinations. Broken, ambiguous, or missing destinations fail the
  build.
* Never clip, truncate, silently shrink, or continue a goal onto a second page.
  A layout overflow names the affected goal and fails closed.
* Keep detailed didactic coverage in separate bilingual, fingerprint-bound goal
  evidence profiles. AI output can create review candidates only; current human
  approval is required before a profile may become authoritative.
* The fast multi-AI loop is the primary early improvement engine. The public
  teacher channel is installed as a slow, moderated signal and challenge path;
  silence is not evidence and one forceful report cannot create a global rule.
* Books, evidence profiles, review bundles, and feedback links contain public
  curriculum data only. They must never contain learner state, learner IDs,
  sessions, transcripts, credentials, or private provider traces.
* Keep temporary execution capsules and dependency caches outside `curricula`.
  Committable review inputs must use exact file copies or repository-relative
  links to committable targets, never absolute local paths or ignored scratch
  targets. Check this with `curriculum_symlink_errors` in
  `scripts/validate_schemas.py` before sealing a new review package; preserve
  original evidence bytes when repairing portability.
* Serialize JSON and JSONL with actual newline characters, then parse the
  complete written files before sealing. Store raw command output as `.txt`.
  Correct historical format errors with exact-byte raw archives and additive
  valid successors; preserve scientific judgments and use normal validation.
* Runtime and Mastery integration are separate later gates. A prompt-level
  profile cannot by itself prove that a learner understood a goal.

Reference:

* `docs/concept/skill-graph/learning-goal-book-and-evidence-review-pipeline.md`

---

### 7.5 Champion trial start and completion

Human trial status is independent of machine-only maturity M0–M7. Per the
Product Owner decision of 20 September 2026, an active Champion role with at
least one completed goal in its current assigned scope counts as an ongoing
human trial once M5 is reached, regardless of registration or progress dates.
An explicit start remains available before any progress exists. Respect pauses,
ended roles and explicit scope bindings; do not require re-registration or
manufacture historical start timestamps. This is a start signal only: existing
mastery never substitutes for current content-bound practical evidence or the
explicit final confirmation required by **Human-tested**. See the binding
[quality and human-trial concept](docs/concept/curriculum-quality-and-human-trial.md).

---

## 8. Ideas for future work (for agents and humans)

These are directions that were **intended** early on. Status in November 2026:
the frontier (1) and per-learner persistence (4) are implemented and
backend-owned (§5, §10.2, §11). Source references (part of 3) are carried by
provenance, mapping and source-rationale artifacts (§10.5) rather than by a
`sourceRef` goal field. Grade mapping (2) is still not implemented.

1. **Frontier view**

   * Visualize all frontier goals for the current learner.
   * Let agents propose exercises or explanations for them.

2. **Grade mapping**

   * Turn aggregated `mastery` over core/extension + weights into familiar grades (1–6).
   * Keep the mapping **simple & explainable**.

3. **Curriculum metadata**

   * Extend `Goal` with:

     * `themenfeld` (e.g. `"E.2"`),
     * `courseLevel` (`"GK" | "LK" | "both"`),
     * `leitideen` (subset of L1–L5),
     * `kompetenzen` (references like `"K1.2"`, `"K3.4"`),
     * `sourceRef` (text reference into the Kerncurriculum PDF).
   * Use these tags for filtering, reporting and to help agents align goals with the official text.

4. **Persistence**

   * Store mastery information per student (e.g. in backend or local storage).
   * Potentially support multiple learner profiles.

5. **Task / example integration**

   * Link `examples` to real tasks (in a separate database or file).
   * Let agents generate new example tasks for given goals and attach them.

---

## 9. How agents should behave

When an LLM/agent works on this repo, it should:

* **Respect the existing structure**:

  * keep the DAG invariant,
  * follow the conventions above.
* **Be explicit about curriculum intent**:

  * when adding goals, think “what bullet in the Kerncurriculum is this covering?”.
* **Avoid restating what code already says**:

  * AGENTS.md is for *concepts & policies*,
  * code files are for implementation details.

* **Keep the project root clean**:
  * Write temporary files, verification scripts, logs, or one-off migration scripts to the `tmp/` directory (or `docs/` if permanent).
  * Never write transient files directly to the project root.

* **Never edit generated artifacts by hand**:
  * Generated Markdown starts with a "Generated artifact" notice naming its script; change the source and regenerate (`docs/dev/documentation-guidelines.md`).
  * The bilingual Graph Definition compendium is single-sourced in `docs/concept/skill-graph/source/` and compiled by `docs/concept/skill-graph/build_spec.py`. Its Markdown pages, PDFs and generated diagrams are build outputs.

* **Keep `CLAUDE.md` consistent**: it is the short practical orientation derived from this file. This file wins on any conflict; update both.

* **Use the two CI tiers** (Product Owner decision of 11 November 2026):
  * Remote CI is the final quality control, not a step after every intermediate change.
    A draft pull request receives only the quick tier. Marking it ready for review starts
    the complete check, which also runs on every push to `main`.
  * The complete check contains every check on its own and runs as parallel jobs.
    Splitting a job must not drop or weaken a check. See `docs/qa-ci/ci.md`.

If you extend the project in a conceptually new way (new types of nodes, new semantics),
update this document so future agents don’t have to reverse-engineer intentions from code.

---

## 10. Layered architecture: A (Lernziellandschaft), B (Lernverläufe), C (LLM/MCP)

This project is intended as the *lower layer* of a larger architecture.  
We distinguish three levels that should stay conceptually separated:

- **Layer A – Lernziellandschaft (competence landscape)**  
- **Layer B – Individuelle Lernpfade & Mastery**  
- **Layer C – LLM-gestützte Navigation via MCP**

### 10.1 Layer A – Lernziellandschaft

Layer A contains the **static, curriculum-level description** of a domain:

- A directed acyclic skill graph with:
  - nodes = learning goals (atomic + cluster),
  - edges:
    - `contains` for structural hierarchy (Themenfelder, Halbjahres-Cluster, etc.),
    - `requires` for didactic prerequisites.
- All domain metadata lives here:
  - `phase`, `area`, `themenfeld`,
  - `level` (Anforderungsbereich I–III),
  - `leitideen` (L1–L5),
  - `kompetenzen` (K1–K6, ggf. mit Subcodes),
  - `courseLevel`, `sourceRef`, `examples`, …

**Representation strategy:**

- Conceptually, Layer A is **pure data**, ideally representable as JSON (or a similarly simple format) so that:
  - it can be reused by different frontends and tools,
  - other curricula or Themenwelten (z. B. Physik, Informatik, Brückenkurse) can be added as additional landscapes.
- In this repo, the JSON files under `curricula/` are the **concrete encodings** of each landscape:
  - canonical German Gymnasium subjects under `curricula/DE/Gymnasium/canonical/`,
  - other curricula under their own `curricula/**/json/` directories.

Agents working on Layer A should think in terms of:

- “Which bullet / table row in the curriculum does this goal correspond to?”
- “How does this new goal fit into `contains` and `requires` without breaking the DAG?”

Layer A is **shared across all learners**; it does not contain any individual performance data.

#### Curriculum release packages

The long-term publication target for Layer A is one fachlicher release in two equivalent package variants:

* a self-contained JSON runtime package that is the normative fachlicher input for SkillPilot;
* a Lehrplan-Ontologie package derived Core-first from that exact JSON artifact, with explicit application extensions only where the Core cannot express the required semantics.

The two variants are build artifacts of one normalized content state, not independently authored sources. A release is valid only if the ontology package can be transformed back, without a hidden copy of the original JSON, into the same normalized runtime content and byte-identical binary assets. An external release index binds both artifact hashes and the shared semantic content digest.

SkillPilot runtime code should consume versioned package manifests and artifact roles, not infer curriculum semantics from repository paths. The JSON package must include the transitive runtime closure, composition views, cards, resources, and visualizations needed for standalone operation. Embedded cross-package goals retain ownership metadata; jointly installed packages may provide the same stable goal ID only when their canonical definitions are identical. Authoring repositories, build tooling, and the SkillPilot runtime may be separated after this package contract and a package-only runtime path are stable.

The first public contract profile is `full-standalone-v1`. Compiled release goals carry an explicit `semanticKind`; ontology tooling must not derive Core semantics from titles or subject-specific ID patterns. Public stable releases are authenticated by a trusted signature over an external release index that binds both package variants and their equivalence evidence.

Package validity and publication permission stay separate. `review-required` records use `licenseExpression: null`, remain usable for technical staging tests, and must fail the redistribution-readiness gate. Never infer a license from provider, provenance, AI-generation, or curation labels. Human decisions for image quality, redistribution, or source verification are hash-bound; content drift makes them stale. Machine source-text matches reduce the manual queue but never count as human or legal approvals, and complete extracted official-PDF text must not be committed merely as verification evidence.

Reference:

* `docs/concept/skill-graph/dual-curriculum-package-releases.md`
* `docs/dev/dual-curriculum-package-implementation-status.md`

### 10.2 Layer B – Individuelle Lernpfade & Mastery

Course-plan sections have an optional `active` flag; omission means active for
legacy documents. Inactive sections remain persisted and editable but are
excluded before goal allocation/deduplication, scheduling, backlog and plan-led
continuation. This never excludes goals from free learning or changes mastery.
Learning sections may use `goalIds` for a union of canonical visible `contains`
subtrees; an explicit list supersedes the legacy single `goalId`. Milestones
record exam scope without scheduling additional work. Assessment coverage uses
explicit `examData.coveredGoalIds`, never prerequisite closure. Preparation
completion previews changes and separately discloses additional and out-of-scope
foundations; it never silently widens the Personal Curriculum or writes mastery.
Additional topics and foundations are optional and off by default. Declining
them must not prevent preparing the selected topics and usable assessments or
activating that plan. Unresolved assessment metadata and external prerequisites
remain advisory; invalid selected roots, actual scheduling errors and the normal
backend prerequisite/frontier checks remain enforced. Canonical cluster
references may resolve to already-visible target atoms, never add hidden atoms.
An active exam's explicitly selected visible atomic goals form a learnable
scope even without a dated preparation section. Keep this scope separate from
scheduled work: no invented quota, due date or balance. A shared backend
resolver supplies the exact scope to Cockpit, plan transitions and coach;
activation preserves its full goal set as Level-3 focus rather than narrowing
it to the active goal cursor. Multiple exam scopes are not unioned; the next
active exam is the initial selection. Automatic handoff and date changes must
not silently replace a running exam scope or add prerequisite goals.
The selected exam roots use the ordinary Level 3 focus rules above. In normal
mode an outside prerequisite must not turn this induced graph into an empty
frontier; internal prerequisites still determine the next eligible goal.
See `docs/concept/runtime-workflows/exam-preparation-planning.md`.

Optional external learning materials belong to a separate content layer:
packages reference canonical goal IDs; canonical goals must not acquire provider
or package dependencies. Learner package selection is persisted separately from
curriculum scope, plans, focus and mastery. No selection, unavailable material or
provider outage may block learning. Source evidence and existing QS-bound goal
visualizations remain distinct and unchanged. See
`docs/concept/skill-graph/content-integration.md` for the architecture and the
controlled Physik Libre link-only pilot. Material links are untrusted references,
not coach instructions, proof of reading, mastery or an AI-use license. Never send
learner identifiers, progress or chat content to a material provider. Material
selection is a normal Cockpit setting under the existing SkillPilot-ID access
model: the system intentionally does not distinguish the learner from another
holder of that ID. Do not add a separate content credential, per-profile grant,
operator approval or teacher identity system. Keep the ordinary active-profile
and writable-session checks, revision conflict protection and separate selection
state. Content support is available by default; the global operational switch
`SKILLPILOT_CONTENT_ENABLED=false` may disable it without blocking learning.
Package selection remains explicit and empty for a new profile. This Product
Owner clarification of 21 September 2026 supersedes the original PoC's additional
configuration-capability requirement; it does not publish or deploy an update.

Layer B describes, for a fixed Layer‑A graph, the **state of a concrete learner** (or group):

- For each learner ℓ and atomic goal g:
  - `mastery_ℓ[g] ∈ {0,1}` as in Section 4: mastered or not mastered.
- **SRS/memorization goals** use the same binary outcome, computed from
  card-level review data under the memory workflow and **not** manually set
  by a learning coach or LLM. The implementation boundary in Section 4 applies.
- Optional:
  - history of visited goals, tasks, timestamps,
  - teacher comments / annotations,
  - learner preferences (z. B. „mehr Stochastik“, „erst Analysis abschließen“).

Navigation support on Layer B should:

- Use the **Frontier** definition (Section 5) to propose “nächste sinnvolle Lernziele”:
  - only suggest unmastered atomic goals with satisfied effective prerequisites
    under the selected normal or strict scope mode,
  - use weight or learner preferences to prioritize those available goals.
- Allow both:
  - *guided* navigation (Lehrer:in wählt Ziele aus, Frontier dient als Check),
  - *self-directed* navigation (Lernende sehen Frontier + Kontext, wählen selbst).

Implementation-wise:

- Layer B is **per-learner data** and should be persisted separately (database, files, …).
- The backend persists learner goal results; a frontend `mastery` map is a
  projection of those results, not a separate source of truth.

**Persisted learner goal results are the sole source of achieved-goal progress
throughout the application**, including Cockpit, goal tree and teacher planning.
The former manual teaching-coverage/attestation model is retired: do not collect
or present a separate `Unterrichts-IST` as progress, require a teacher to confirm
already stored results, or use legacy coverage records as an achievement source.
Existing local records may remain for compatibility; this decision does not
authorize their deletion or any mastery, learner-plan or backend mutation.
Read-only learner/subject progress uses current authoritative personalized
target IDs and stored results. A plan baseline fixes scheduled work, not current
achievement. Plan-goal set **G** and the complete Personal Curriculum target set
may differ (for example through prior knowledge or selected scope); name the
scope and use the same result/atomicity rules, rather than forcing unequal
scopes to have equal counts. An orientation completion is counted consistently
where that goal is in scope, without calling it subject-matter mastery. Missing
or stale result data must be shown as unavailable, never as zero achievements.

Learning-plan status is backend-owned on the learner's persisted **DAY or WEEK**
basis (default WEEK; Europe/Berlin, Monday through Sunday). Each stable subject is
balanced independently over the same fixed, deduplicated plan-goal set; prior
knowledge is excluded and later mastery remains in that set. Current-period
completion events cover the period quota first, and advance work can cover it
as well. No cross-subject balance or overall direction is permitted. Cockpit
renders the backend's exact localized per-subject status parts; chat and learner
planning use the exact localized `status.text`; the active-goal announcement is
separate and appears once when teaching begins.
In Cockpit Plan mode, two subject-specific dials additionally use backend-owned
period completion, net balance, scale and needle positions; the client does not
recalculate them or replace the authoritative status text. The typical scale
amount is derived from positive quotas of the merged subject plan as specified
in the concept below. In the learner-facing dials, completed period work is
blue and open work gray; the cumulative scale is clearly red for strong
backlog, neutral gray near the plan and green for advance work. The needle and
status text also carry the meaning. This later product-owner design decision
supersedes the interim all-blue palette.
The learner-facing Today panel shows the active goal as information but has no
duplicate settings or "continue learning" button; settings remain in the goal
sidebar and the learning content is rendered separately below the panel.
Automatic plan reconciliation and handoff stop when the applicable period quota
is met; further work requires an explicit learner request. A valid active goal
remains available. **A plan guides and prioritizes learning; it must never prevent
learning.** An explicit continuation request prioritizes reachable due work, then
other reachable targets in the Personal Curriculum, even without a quota,
backlog or usable schedule. Preserve requested pauses, prerequisites and actual
mastery. Never infer completion dates from `mastery.updated_at`, imports or current
mastery snapshots. Unreliable plan or completion data must remain explicitly
unevaluable. The binding calculation, data and presentation contract is
`docs/concept/didactic/unified-learning-plan-status.md`; the former daily-quota
contract is superseded.

The **4 November 2026** completion correction also governs plan accounting:
first reconstruct global effective mastery M_eff from explicit results and
fixed valid recognition contracts, independent of today's plan/focus selection.
Then intersect with the fixed, subject-specific plan baseline G:
`I = |G ∩ M_eff|`. Each goal counts once. A later open exam does not remove an
already recognized prerequisite. Local learning-unit recognition and global effect are
separate from the plan's date mask; never calculate recognition just inside G.

The Cockpit preference “Nur explizit erreichte Lernziele zählen” defaults to off
and limits plan IST to `|G ∩ M|` when selected. It changes counting only, not
competence, prerequisite satisfaction or exam access. Daily/weekly fulfillment
H remains based exclusively on genuine dated explicit completion events in
both modes. Implicit recognition creates neither fake events nor mastery rows.
An explicit result later acquired for an already recognized goal cannot add a
second goal to total IST; any period event still follows its ordinary contract.
Missing recognition data must be reported, not interpreted as zero or restored
from the retired preparation-discharge rules. Existing implementation evidence
is historical and does not establish conformance to the new contract.

### 10.3 Layer C – LLM-/MCP-Integration

Layer C connects the skill graph and learner states to **LLM-based agents**.
The intended architecture:

- An MCP server (or a set of servers) exposes:
  - **read access** to Layer A:
    - list of goals, neighborhood of a goal, themenfeld/phase filters, frontier computation primitives,
  - **read/write access** to Layer B:
    - get/set mastery for learner ℓ and goal g,
    - log that a task was attempted / solved,
    - derive learner-specific frontiers or summaries.
- MCP clients (e.g. ChatGPT with MCP support) connect to this server.  
  The LLM (e.g. GPT‑5.1) acts as:
  - navigator on the skill graph (“Welche Ziele passen als nächstes?”),
  - didactic assistant (Erklärungen, Aufgaben, Reflexionsfragen),
  - broker between learners/teachers and the underlying data.

Key principles for Layer C:

- The LLM **does not own the ground truth** about goals or mastery:
  - it always reads/writes via MCP tools/resources,
  - it respects `requires`/`contains` constraints coming from Layer A.
- The same provider-neutral application behavior should be reusable by
  conversational UIs and other services. External MCP/Action contracts remain
  provider-specific because authentication, context recovery, tool schemas,
  widgets, and retry semantics differ. Do not force them into one universal
  `submit_turn` or one-size-fits-all schema.
- The strategic public OpenAI coach channel is one durable provider-hosted
  plugin (`skillpilot-coach`; 19 October 2026 decision in §0), not one plugin
  per language or package major. It combines one language-neutral English control-plane skill
  with the corresponding language-neutral MCP server submitted directly for
  review. A local or
  workspace pilot may map an already registered MCP connection through
  `.app.json`; that compatibility wiring is not the public MCP submission.
  Learners can use the model under the provider's free access or fixed-price
  consumer subscription without SkillPilot paying metered inference costs. The
  plugin packages and distributes the capability; the skill controls repeatable
  dialogue and tool orchestration; the MCP server exposes live data,
  authentication and controlled actions; SkillPilot owns all fachliche state,
  authorizes every domain mutation, and exposes only passgenaue
  provider adapters. The backend-selected learning session language controls
  every learner-facing payload and response. A first-party SkillPilot model orchestrator is not
  the target while this direct-provider-billing requirement remains hard.
- The multilingual OpenAI MCP App separates two server-owned bindings:
  - OAuth 2.1 authenticates the registered confidential App connection.
  - An independent, absolute 24-hour learning session addresses one learner for
    fachliche tool use. It is created anew only by `Lernen starten` in the
    first-party SkillPilot UI after permanent-ID, provider-notice, curriculum,
    stage, subject, course-profile and personalization configuration there. It
    is never extended by OAuth refreshes or MCP calls, enters the provider flow
    only in the short prepared start message, and is passed unchanged as
    `learningSessionId` to every fachlicher MCP call. OAuth alone never chooses
    the learner, and the permanent SkillPilot ID never becomes an MCP argument.
  OpenAI attaches the OAuth bearer token to MCP requests automatically. The
  backend requires both proofs and resolves the learner only through the
  learning-session mapping. Because ChatGPT exposes no stable conversation
  identifier for this contract, `learningSessionId` is explicit application
  state, not a provider-conversation or MCP-transport session.
- Guided curriculum personalization is an explicitly authored entry protocol,
  not a projection of the skill graph:
  - a curriculum root may declare a versioned top-level `personalizationFlow`;
  - stages, groups, order, cardinalities, landscapes, and filter sources come
    only from that flow and the referenced landscape metadata;
  - `contains`, `requires`, frontier, applicability, composition views, tags,
    labels, subject names, jurisdictions, and hard-coded IDs must never invent
    a personalization decision;
  - an absent flow means no mandatory guided personalization; a malformed
    authored flow fails closed;
  - first-party authored-flow hosts submit the currently published opaque
    `optionId` unchanged. Labels are presentation only and are never mutation
    keys; the OpenAI V1 coach does not mutate this Level 2 configuration;
  - if a group has met its minimum but not its maximum, the plan publishes an
    opaque `COMPLETE_GROUP` action; only this action, or reaching the maximum,
    closes that concrete group instance. Optional groups use the same action
    to close with zero selected values;
  - provider projections expose the current decision label plus
    `minSelections`, `maxSelections`, and `selectedCount`; adapters must not
    infer cardinality or completion from labels or transcript wording;
  - mutations re-resolve the active flow under the learner row lock and persist
    only the selected landscape plus its exact authored filter;
  - a selected landscape outside the old graph closure is usable only when a
    valid active flow explicitly offered it. Arbitrary persisted configuration
    must never expand the runtime landscape set.
  Neutral, synthetic multi-stage contract tests are required so a concrete
  Hessen, Mathematik, or course-profile example cannot become runtime logic.
- Every normal model-facing learner state must pass through the shared safe
  projection: no permanent SkillPilot ID or copy-source IDs, and no exam solution,
  passing threshold, source-artifact path, or scoring rubric.
- Released exam evaluation material is a separate, explicitly authorized backend
  use case. Legacy provider-hosted chats enforce answer-before-evaluation only by
  instruction. Target MCP Apps must use a widget-backed
  `start -> submit -> receipt -> evaluate -> record` attempt so the backend can
  prove submission before releasing protected evaluation material.
- Exam grading is criterion-based, not an exact match against the released
  solution. The solution is a non-exclusive reference; subject-correct equivalent
  results, representations, permitted rounding, explanations, and alternative
  methods receive equal credit unless the task or rubric explicitly requires a
  particular answer form; explicit requirements remain binding. Exam submissions
  are graded conclusively without follow-up questions. Providers identify
  illegible work as such and score only reliably visible evidence; they must never
  invent a specific subject error from unreadable handwriting or image content.

In the long run, multiple landscapes (different Fächer, Curricula, Sprachräume) can live in Layer A,  
while Layer B maintains separate mastery maps per learner and landscape,  
and Layer C provides a **unified, sprachbasiertes Interface** auf diese Strukturen.

### 10.4 File formats & persistence (PoC conventions)

To keep the architecture transparent and repo-friendly, we use simple JSON files during the PoC:

- **Layer A (landscapes)**
  - Stored under `curricula/` (e.g. `curricula/<...>/json/<file>.json`; canonical German Gymnasium subjects under `curricula/DE/Gymnasium/canonical/`).
  - Root curricula are explicitly listed in `curricula/curriculum_manifest.json` and validated in CI.
  - In the current repo they are maintained directly as committed JSON files; there is no `export:landscape` pipeline at the moment.
  - Fields follow `SkillLandscape` / `LearningGoal` in `app/src/landscapeTypes.ts`; the backend mirrors these structures in its landscape loader types.
  - `shortKey` is an optional ASCII identifier for cross-layer references. Current committed landscapes may still omit it, so runtime code must tolerate deterministic fallback derivation from `id`.

- **Layer B (learner state)**
  - Conceptually this can be represented as `learners/<learnerId>.json` in a file-based PoC.
  - Current implementation in this repo persists learner state in the backend and also uses browser-local prototype state for some UI flows; there is no committed `learners/` directory in the repository today.
  - Schema draft (if file-based snapshots are used):
    ```json
    {
      "learnerId": "alice",
      "landscapeId": "hessen-math-upper-secondary",
      "mastery": {
        "math_go": 0.0,
        "e_rate_avg": 1.0
      },
      "meta": {
        "lastUpdated": "2025-03-01T12:00:00Z"
      }
    }
    ```
  - Runtime/API calls currently use goal IDs / goal keys as returned by the backend.
  - If `shortKey` is available in a landscape, it is a good human-readable external reference, but consumers must handle missing `shortKey`.
  - During the PoC we can load/save these JSON files directly. Later they can move into a database or service, but the schema should remain stable so MCP tools/users can rely on it.

- **Layer C (MCP resources/tools)**
  - MCP resources should point to specific landscape or learner files (e.g. `resource:skillpilot/landscape?hessen-math-upper-secondary`).
  - MCP tools (`get_frontier`, `set_mastery`, etc.) should internally operate on the JSON schemas above. They should never assume a particular curriculum language; all metadata fields use US-English so other landscapes can be added with different locales (German, English, …).

These JSON conventions let us run the full SkillPilot proof-of-concept without additional infrastructure, and they keep the project open to future landscapes, languages and persistence layers.

### 10.5 Canonical Gymnasium convergence (transition strategy)

For German Gymnasium curricula, the long-term target is a **canonical competence layer per subject** that spans Sekundarstufe I and Sekundarstufe II and can be viewed through state-specific curriculum filters.

Practical rollout rules:

- Do **not** duplicate canonical goals per Bundesland.
- Keep existing state-specific landscapes alive during transition as **legacy views**.
- The convergence started from the Hessen upper-secondary source tree. That tree is retired and must stay absent from the active repo; its retained evidence lives under `curricula/DE/Gymnasium/input/HE/`, and the canonical layer under `curricula/DE/Gymnasium/canonical/`.
- For Sekundarstufe I, use **G9 year levels 5-10 as the first canonical reference grid**. If source materials come from tracks with different total duration such as G8 vs G9, normalize them initially onto the matching year-level buckets instead of creating separate canonical G8 and G9 goal sets.
- When legacy source material must survive the migration outside the canonical graph, keep it **bundeslandspezifisch** in DE-level retained-asset lanes. This applies not only to `abi/`, but also to source snapshots, curriculum-owned input bundles, exam blueprints, release notes, and similar state-owned materials.
- Treat retained state-owned source JSON under paths such as `curricula/DE/Gymnasium/input/HE/upper-secondary/source-json/` as frozen source evidence; do not rewrite those snapshots just to host canonical convergence.
- Use a **small mapping layer** from legacy goal IDs to canonical goal IDs instead of introducing a large new abstraction stack too early.
- When a Bundesland must be represented explicitly in metadata, filters, overlays, or APIs, use ISO 3166-2 codes such as `DE-HE` and `DE-BY`.
- Place canonical Gymnasium subject landscapes on a Germany-level path, not under a single Bundesland subtree; source ownership and canonical ownership should stay visibly separate in the repository layout.
- When different Bundeslaender or duration models (`G8`/`G9`) need different learner-facing upper tree shapes for the same canonical subject graph, prefer separate scope-specific composition-view files over runtime reparenting or duplicated atomic goals. Use `scope.durationModel` only as a projection discriminator; do not create separate canonical G8/G9 goal sets.
- Use a didactically closed **subtree** as the primary migration unit; operational states are `legacy_frozen`, `subtree_adopted`, `cutover_ready`, and `legacy_view_retained`.
- The existing repository directory layout such as `curricula/DE/HE/...` may remain unchanged during transition; path segments are not the canonical public identifier contract.
- Keep Custom GPT / MCP / API contracts as stable as possible; translation between legacy and canonical layers should happen in backend/runtime logic, not in prompt logic.
- Preserve **multi-subject navigation** and allow selected cross-subject `requires` edges where didactically justified, e.g. Mathematik -> Physik.
- Prefer one DE-level school root such as `Gymnasium (DE)` in learner-facing curriculum selection, with subject landscapes as child modules.
- Keep course-level filters such as `GK` / `LK` on the child subject landscapes.
- Put Bundesland filters such as `DE-HE`, `DE-BY`, and `ALL` on the shared DE-level root and propagate them runtime-side into the selected canonical child landscapes.
- Target runtime filtering for canonical Gymnasium should converge toward compiled node-level `applicability` metadata derived from mappings, provenance, and validated filtered-graph rules, rather than depending permanently on recursive runtime inference.
- For a resolved Gymnasium learner-facing scope, the preferred steady-state artifact is a compiled single-occurrence tree projection derived from a reviewed composition view plus canonical subtree expansion.

Operational consequence for Sek I:

- Preserve the original source labels such as `G8`, `G9`, or state-specific year naming in provenance, mapping files, and archived input material.
- But keep the first canonical authoring and migration target aligned to year levels `5`, `6`, `7`, `8`, `9`, `10`.
- Where G8/G9 matters for a learner-facing Bundesland view, carry it as `durationModel`/`durationModels` in source-extraction metadata and source registries, and as `durationModel` in goal placement contexts and composition-view scopes.

Operational consequence for retained assets:

- If a file or directory is kept because it remains relevant after canonical cutover, archive it under a DE-level state lane such as `curricula/DE/Gymnasium/input/HE/...` or `curricula/DE/Gymnasium/input/BY/...`.
- Treat the retained Hessen `abi/` assets under `curricula/DE/Gymnasium/input/HE/abi` as the model example for this rule, not as a special one-off exception.
- For official curriculum sources, commit the structured reference and extraction state, not necessarily the original PDF/HTML working copy. `sourceDocument`/`sourceDocuments` entries with official HTTP(S) URLs, titles, and roles are the durable source-of-truth in Git; local PDFs/HTML files are cache/work artifacts for extraction and may remain ignored by `.gitignore`.
- A green source-readiness state means the source situation is explicitly decided for every claimed scope dimension (Bundesland, subject, Sek I/Sek II, and G8/G9 where relevant), the official reference is usable, and any local working copy needed by the current pipeline can be reproduced or is present locally. It must not mean "the PDF is committed to Git."

Operational consequence for human-readable source rationales:

- A generated source rationale is a view over existing provenance evidence, not a new source of truth.
- Long-term explainability covers every learning goal and every direct `requires` / `contains` relation in a knowledge landscape.
- Relation rationales may explain a direct source statement, a reviewed mapping decision, a derived graph-modeling rule, or a didactic sequencing decision; do not pretend every edge is a direct curriculum quote.
- Prefer the classic reviewed source route first: canonical goal -> mapping review decision -> source extraction -> official source document.
- MEM/FWU SPARQL evidence may be added as a secondary or future primary route only with explicit route status such as consistent, review-needed, unavailable, or source-version-gap.
- Public source-rationale text should explain how to reach the original source and why the mapping supports the SkillPilot goal, while avoiding long copied source passages.
- GPT/MCP integrations must retrieve and summarize structured rationale evidence instead of inventing provenance.
- Reference: `docs/concept/skill-graph/human-readable-source-rationales.md`.

Detailed rollout plan:

- `docs/concept/skill-graph/canonical-gymnasium-rollout.md`

---

## 11. SkillPilot ID and privacy model

SkillPilot is designed to work in school contexts but should also scale to **any subject, level and region**.  
To keep the architecture simple and privacy-friendly, we separate:

- **Curriculum data (Layer A)** – public, static landscapes,
- **Learner state (Layer B)** – per‑learner mastery and history,
- **Language models / tools (Layer C)** – stateless compute that only see what they need.

### 11.1 SkillPilot ID – pseudonymous learner key

The SkillPilot server should treat every learner as a **pseudonymous profile** identified only by a server-generated key:

- `skillpilotId` – random, opaque token (e.g. 128‑bit, URL‑safe string).
- The server stores for each `skillpilotId`:
  - the learner’s mastery map per landscape,
  - optional history and technical metadata (`createdAt`, `lastUpdated`),
  - but **no personally identifying information** (no real name, no e‑mail, no school IDs).

Guiding principle:

- The skill graph knows only **“learner X with skillpilotId …”**, not who that person is in the real world.

### 11.2 What lives where?

**Server-side (SkillPilot backend)**

- Stores:
  - landscapes (JSON files under `curricula/`) – public curriculum-level descriptions,
  - learner state per `skillpilotId` – pseudonymous mastery and history.
- Does **not** store:
  - names, nicknames, e‑mails, or other PII.

**Language model / SkillPilot Learning Coach**

- May ask for a *nickname* to address the learner in the conversation, but must
  never ask for, display, or receive the permanent `skillpilotId` through an
  external AI adapter.
- The current OpenAI MCP App never receives the permanent
  `skillpilotId`. `Lernen starten` inserts a newly created
  `learningSessionId` automatically into the prepared start message, and
  ChatGPT passes it unchanged as a required argument to every fachlicher tool
  call. OAuth authorizes the registered App connection; the backend resolves
  the learner only through the independent learning-session mapping, never
  through an OAuth subject alone. The coach must not ask the learner to copy,
  re-enter, or repeat the session value.
- The Claude Connector v1 follows the same separation with its own
  provider-isolated sessions: connector OAuth is transport-only, and the
  learner is resolved solely through the current first-party `spc_` learning
  session passed unchanged as `learningSessionId`. The Gemini controlled
  integration likewise addresses the learner only through its own `spg_`
  learning sessions (§12.2). A session of one provider lane is never accepted
  by another.
- The dormant legacy Claude beta adapter (`/api/claude/mcp`, disabled by
  default) resolved an authenticated opaque OAuth subject internally and had
  neither `skillpilotId` nor OAuth credentials as model tool parameters. It is
  not the active Claude lane.
- German, English and later supported interaction languages use the same App
  registration; there is no per-language registration. Widget-only selection references may be returned
  in tool-result `_meta`, but must never appear in user-visible content or
  model-visible `structuredContent`.
- Provider-neutral backend services may use the SkillPilot ID internally after
  the provider-specific trusted temporary context has been resolved. For the
  current OpenAI MCP App, this resolution happens only through the
  explicit learning-session mapping under a valid OAuth-authorized App request,
  not through the OAuth subject. That internal implementation detail must not
  leak into the external model context.

**User-local (browser / ChatGPT UI)**

- The learner is responsible for:
  - keeping their `skillpilotId` somewhere safe (e.g. in the browser, a notes file),
  - deciding which nickname they share with the learning coach or teacher.
- The current MCP-App transcript may contain the automatically inserted
  `learningSessionId` in the prepared start message. It must not contain the
  permanent `skillpilotId` or any additional access or technical selection
  credential, and the coach must not repeat the learning-session value.
  Human-readable learning-goal IDs may still be shown when they are
  intentionally part of the learning product rather than access credentials.
- The interim Custom GPT keeps its temporary token inside Action context after
  start-code redemption. Only its explicitly started emergency fallback places
  the token in response footers; neither convention may be copied into MCP-App
  workflows.
- Local frontends (web GUI, notebooks, etc.) may:
  - store the `skillpilotId` in local storage or cookies,
  - remember additional preferences or display names **locally only**.

### 11.3 API / Tools conventions

Distinguish trusted browser/domain APIs from provider-facing AI contracts.

Trusted browser and internal domain endpoints may use `skillpilotId`, provided it
is always treated as an opaque pseudonymous access key and never as a name or
email address. Typical browser/domain endpoints include:

  - `POST /learners` → returns a new `skillpilotId` plus initial state,
  - `GET /learners/{skillpilotId}/state` → returns unified state (Curriculum + Frontier + Goals + `stateMachine`),
  - `POST /learners/{skillpilotId}/mastery` → updates mastery and returns **new frontier** immediately,
  - `POST /learners/{skillpilotId}/scope` → sets focus (e.g. "Stochastik") and updates planned goals,
  - `POST /learners/{skillpilotId}/active-goal` → locks the current atomic goal for the learning-coach loop.

Provider-facing contracts must use derived temporary context instead:

- Interim Custom GPT: the proposed separate launcher calls
  `POST /api/ui/learners/{skillpilotId}/chat-start`; the GPT redeems the one-time
  code and then uses nine locale-specific
  `/api/ai/{lang}/sessions/{chatSessionToken}/visible/...` Actions. Values needed
  after a user turn remain in Action context, with a real retention canary as a
  release gate. The separate `visible-chat-start` route remains an explicitly
  chosen emergency relay in which the footer, current selection, full canonical
  goal ID, and Recall card IDs are visible.
- Dormant legacy Claude beta adapter (`/api/claude/mcp`;
  `skillpilot.claude.enabled=false` is its master state): the transport
  authenticated an OAuth connection subject and resolved it inside the backend.
  It is neither the active Claude lane nor a release path; leave the dormant
  code untouched unless its cleanup is explicitly decided.
- Claude Connector v1 (`https://mcp-claude-v1.skillpilot.com/mcp`): connector
  OAuth, including optional `offline_access`, is transport-only. The shared
  first-party start creates a fresh opaque `spc_` learning session valid for
  exactly 24 hours only after the learner explicitly chooses Claude; every
  tool, including the app-only card-review tool, requires that unchanged
  `learningSessionId`. OAuth refresh never mints, renews or extends it, and the
  model never supplies a learner ID.
- Gemini controlled integration: the separate `gemini-v1` adapter uses its own
  `spg_` learning sessions with an absolute 24-hour lifetime and a one-hour
  action guard; see §12.2 for its limited acceptance status.
- Current multilingual OpenAI MCP App line `SkillPilot Coach v1`: OAuth authorizes the fixed registered App
  connection but does not select or identify the learner. `Lernen starten`
  atomically creates a new independent learning session with an
  absolute lifetime of at most 24 hours and inserts its
  `learningSessionId` into the prepared start message. Every fachlicher tool
  requires both a valid OAuth-authorized App request and exactly that current
  `learningSessionId`; the backend selects the learner only through the
  learning-session mapping. OAuth refresh, tool calls, retries, and ChatGPT
  reconnects must not extend the learning session. Before every new
  session-bound read or write, the backend requires at least `PT1H` of remaining
  absolute validity. Exactly one hour remaining is valid; less than one hour
  returns `SESSION_RENEWAL_REQUIRED` before the fachliche operation executes.
  A retry of an already committed write with the same tool name, canonically
  identical arguments, and the same `clientRequestId` may replay its stored
  result only while the session still has at least `PT1H` remaining, its pinned
  workflow and curriculum versions remain available, and its completed
  `stateVersion` is still the learner's current canonical revision. That replay
  performs no operation and no second mutation. Missing, invalid, or expired sessions
  return `SESSION_REQUIRED`, and unavailable pinned workflow or curriculum
  revisions return `SESSION_VERSION_UNAVAILABLE`. None is an OAuth failure.
- At the start of every learner turn, `get_skillpilot_context` must succeed in
  that assistant turn. Call it only once in that learner turn: after a
  successful context read, do not poll it again between steps of one
  server-owned workflow; after one successful state-changing call, its complete
  successor result is authoritative for the remainder of the same assistant
  turn and must not be redundantly reloaded.
- The OpenAI V1 model contract has no sessionless start tool, provider-side
  SkillPilot-ID input, or in-chat renewal. Without a current
  prepared start message, the coach gives only a short localized instruction
  to configure SkillPilot at `https://skillpilot.com/` and use **Lernen
  starten**, then stops. This is the sole locale exception: with no prepared
  session or context, it uses German for a German conversation and English for
  an English conversation only for that fixed instruction; this does not set a
  session locale. On `SESSION_REQUIRED`, `SESSION_RENEWAL_REQUIRED`, or
  `SESSION_VERSION_UNAVAILABLE`, it outputs `instruction` unchanged. If only
  `instructions` is available, it selects the exact entry using the last
  authoritative `communicationLocale`, otherwise the current conversation
  language. It includes the exact `startUrl` only if the selected instruction
  does not already contain it, gives no fachliche response, and neither retries
  the old session nor reconnects OAuth. The first-party UI creates a fresh
  session and opens a new chat.
- The first-party endpoint
  `POST /api/ui/learners/{skillpilotId}/openai/v1/launch` accepts the optional
  live-test-only JSON field `diagnosticSessionTtlSeconds` only while
  `SKILLPILOT_OPENAI_COACH_V1_DIAGNOSTIC_SESSION_TTL_ENABLED=true`. Its integer
  value must be between `3601` and `86400` seconds inclusive and must not exceed
  the normal `PT24H` learning-session lifetime. It affects only the independent
  session created by that one request; the next request without the field uses
  `PT24H` automatically. Prefer `3660` seconds for an approximately
  one-minute transition across the `PT1H` action guard or `5400` seconds for a
  90-minute soak. Never lower the global learning-session TTL for this test, and
  disable the diagnostic gate again after the live check.
- Under the 19 October 2026 decision (§0), the durable public OpenAI MCP
  endpoint and its exact OAuth Resource/Audience are both
  `https://mcp-openai.skillpilot.com/mcp`; current source binds this origin.
  Protected-resource metadata is published at the RFC 9728 path-insertion URL
  `https://mcp-openai.skillpilot.com/.well-known/oauth-protected-resource/mcp`,
  and the OpenAI domain challenge is scoped to the same dedicated host. The
  OAuth issuer `https://skillpilot.com/api/openai/v1` and the internal V1
  adapter are unchanged. Exactly one Resource/Audience is active; no public
  compatibility alias, redirect or dual audience exists. After the coordinated
  cutover the former host `mcp-coach-v1.skillpilot.com` fails closed with `404`
  like `mcp-coach-v2.skillpilot.com` through `mcp-coach-v9.skillpilot.com`,
  including discovery and domain challenge. Published Git beta packages that
  name the former host stay immutable history. Whether production has performed
  the cutover is an operational fact that source does not prove; see
  `docs/deploy/openai-stable-origin.md`. Earlier
  `mcp-coach-de-v*` and
  `mcp-coach-en-v*` names were unpublished local infrastructure and are not
  compatibility routes. The current V1 tool contract binds exactly two
  active, hash-bound MCP Apps resources: the image-only goal renderer and the
  interactive memory-practice launcher. Previously advertised image hash URIs
  remain byte-identically readable as passive resources. The unpublished
  provider-side start tools, resources, widgets, and runtime services are
  removed. Ordinary
  coaching, selection, mastery, Verified Recall, and exam flows remain normal
  MCP/chat flows without UI bindings; the memory-card review write is app-only
  and has no output template of its own.
- OAuth activation is independent per client profile, as authorized by the
  Product Owner on 11 September 2026. `chatgpt-cimd-jwt` requires the exactly
  pinned ChatGPT CIMD and `private_key_jwt`; the existing confidential Basic
  connection may remain as the explicit `chatgpt-basic-transition` profile.
  `chatgpt-native-cimd-public` additionally supports the uploaded desktop plugin
  with a pinned OpenAI native CIMD document, S256 PKCE, exact loopback callback
  host/path and a variable listener port. It uses the same V1 resource and
  issuer, with separate profile provenance and refresh-token rotation. `none`
  is the public client's token-endpoint method, not anonymous MCP access.
  `claude-cimd-public` is an authorized production beta using public CIMD,
  Authorization Code and S256 PKCE, not confidential client authentication.
  `claude-custom-confidential` and `claude-anthropic-held` use dedicated secret
  clients with an explicitly selected Basic or POST method. Only the latter
  requires Anthropic provisioning. Real host and intended installation-path
  acceptance are required separately for every production profile; manufacturer
  inquiries never block unrelated accepted profiles. No failed confidential
  authentication may fall back to a public profile, and there is no open DCR.
  The former global `SKILLPILOT_OAUTH_AUTHENTICATED_CLIENTS_REQUIRED=true`
  override is rejected with migration guidance. The historical database floor
  is retained as an old-binary barrier, not as an all-provider secret requirement.
  Drain pre-policy binaries during migration. Authorization provenance remains
  bound to its profile through MCP access, including public grants. Only exact
  existing Basic-transition grants may remain unmarked without being upgraded.
  Public refresh rotation includes durable reuse detection and token-family
  revocation. Retired revisions cannot be reactivated: a rollback to accepted
  configuration uses a new policy revision and new grants, never weaker checks.
  Assertion replay protection is atomic and durable across instances.
  This authenticates the OAuth host client, not plugin bytes, a particular
  plugin execution, or the learner. Learning-session authorization remains
  independent. Secrets never belong in public plugin packages. Activation,
  rotation, external provisioning and real-host evidence are documented in
  `docs/deploy/oauth-client-authentication.md`.
- The dedicated V1 edge requests ChatGPT's OpenAI-managed client certificate
  only for transport authentication; OAuth and the learning session remain
  mandatory and independent. Trust only the published OpenAI Root and
  Connectors intermediate CAs, client-authentication EKU, and exact SAN
  `mtls.prod.connectors.openai.com`; never pin a rotating leaf. The root-owned
  edge has only `observe` and `enforce`: `observe` accepts an absent certificate
  temporarily through to OAuth while recording only `OBSERVE_NO_CERT`, but
  always rejects an invalid presented certificate; `enforce` accepts external
  `/mcp` traffic only as `VERIFIED`. A certificate-less `LOCAL_OPERATOR` lane
  may exist only for an actual loopback socket peer. Never derive it from
  `X-Forwarded-For`, a request header, URL, query, or shared secret. Public
  protected-resource metadata and domain challenge remain certificate-free.
  The backend mode and root-owned nginx mode must match fail-closed. The
  hosted release's certificate acceptance remains a separate transport check;
  the authorized native desktop integration uses `observe` because that client
  does not supply the hosted OpenAI certificate. No certificate result replaces
  OAuth or a learning session.
- OpenAI MCP uses one App, public tool catalog, endpoint and
  registration for all languages; since the 19 October 2026 decision that
  identity also stays stable across package majors (§0). Plugin metadata, skill
  instructions, tool names, descriptions, schemas and stable machine values use
  neutral English. The backend pins the interaction language in the learning
  session and returns learner-facing payloads in that language; the model must
  communicate exclusively in that session language and must not infer it from
  the English control plane or host locale. Direct widget choices
  and answer submissions use app-only tools; later model turns reload current
  state through fachliche tools that also require the unchanged
  `learningSessionId`. Learner identity comes from the backend-owned
  learning-session mapping, not OAuth or conversation memory.
- Any new provider adapter must define its own minimum data projection and
  authentication/context boundary. Do not expose the permanent SkillPilot ID just
  because an internal facade accepts it.
- The SkillPilot Claude Connector v1 is a provider-isolated remote-MCP lane at
  `https://mcp-claude-v1.skillpilot.com/mcp`. Its OAuth connection, including
  optional `offline_access`, is transport-only and never selects a learner:
  every tool requires the lane's own current `spc_` learning session as
  `learningSessionId`, and it never accepts or exposes an OpenAI
  `learningSessionId`. Its base surface contains exactly fourteen tools
  (`ClaudeV1Contract.ALL_TOOL_NAMES`) and two content-addressed MCP Apps
  resources: the approved active-goal visualization and private normal memory
  practice. `choose_skillpilot_completion_route` and
  `confirm_skillpilot_completion_contract` are published additionally only
  while the backend completion workflow is available; the connector runbooks
  describe the fourteen-tool base surface. Normal-practice card
  fronts, backs and review capabilities stay in component-only metadata; the
  review tool is app-only, updates only the exact displayed card's repetition
  schedule and never changes mastery. Normal practice remains separate from
  strict Verified Recall. Learner-facing Claude responses translate tool
  results into the learning goal, feedback and next step and do not expose
  revisions, graph fields, capabilities or QA terminology unless the user asks
  an explicit developer or diagnostic question. The optional Claude
  Code/Cowork plugin bundles the same remote MCP server with a provider-specific
  Skill; it is a separate distribution lane, not a second service or identity.

LLM/learning-coach prompts should reinforce that:

- Nicknames are for **conversation only**.
- The permanent SkillPilot ID is never requested or exposed by an external AI.
- Persistence uses a valid OAuth-authorized App request plus the backend-owned
  mapping of the current `learningSessionId`. The prepared start message
  transports that temporary reference automatically; the learner never copies
  or re-enters it, and the permanent SkillPilot ID never enters the
  conversation.

---

## 12. AI Agent Integration (OpenAI MCP Apps, ChatGPT fallback, Claude & Gemini)

SkillPilot keeps its learning-state decisions provider-neutral in the backend and
uses separate provider-specific adapters. The ordinary learning start offers
three lanes with isolated provider sessions over the same saved learning
record: Claude (Connector v1), ChatGPT Desktop (Beta) and Gemini (Beta). The current multilingual OpenAI
channel is the provider-hosted MCP App with a chat-first tool contract,
one bounded read-only image-only MCP Apps UI result, and one independently
bound memory-practice UI result; its target packaging
combines that registered connection with a language-neutral English control-plane skill as
documented in
`docs/concept/runtime-workflows/skillpilot-owned-coach-architecture.md`. The
interim Custom GPT remains a separately tested compatibility channel and must
stay isolated from the MCP-App implementation; its visible session mode is only
an emergency fallback.

The billing boundary is a hard product requirement: the learner uses the model
under the provider's available free access or fixed-price consumer subscription.
SkillPilot must not make or relay a metered model-API call for this coach path.
The provider owns model inference and the free conversational turn; SkillPilot
owns only the authenticated domain state and deterministic application tools.
Under the current OpenAI App guidelines, the published OpenAI channel must not
explicitly target children under 13. Do not infer age from grade or curriculum;
exclude that age group from this provider channel unless a later authoritative
provider policy and product review explicitly permit it.

### 12.1 Key Features for AI

- **Hard privacy and responsibility boundary — no chat prose into Core:**
  the coach evaluates visible learner work and independently formulates its
  feedback and success response in the provider conversation. Neither raw
  answers, reasoning, chat excerpts, summaries, assessment explanations nor
  pieces of that response may be sent through SkillPilot merely to be echoed,
  hashed, logged, or stored. In particular, `workFeedback`, `outcomeFeedback`,
  Recall `feedback`, and equivalent renamed free-text fields are forbidden in
  active coach mutation inputs. Normal mastery carries only its structured
  completion request; Recall carries only the bound per-card `passed` values;
  an exam may carry its authorized numeric score. The backend validates the
  applicable rules and confirms persistence and canonical successor facts, not
  the coach's wording. Approved server-owned labels/option payloads and opaque
  credentials are copied unchanged and are not a free-text escape hatch.
  Reject unsupported top-level and nested input fields before domain calls,
  replay hashing, or persistence. Protect the rule with schema, adversarial
  input, and persistence regression tests for every active provider. A new
  chat-content collection use case requires an explicit Product Owner
  architecture decision; a generic string, an optional field, a character
  limit, or a logging justification does not authorize it. Existing published
  artifacts remain immutable history, not authority to restore the old fields.
  Historical stored data is not deleted or exported without a separate,
  explicitly scoped decision. The canonical contract is
  `docs/concept/runtime-workflows/provider-neutral-coach-boundary.md`.
- **Canonical ChatClient/backend contract:**
  `docs/concept/runtime-workflows/provider-neutral-coach-boundary.md` is the
  single durable source for communication and new tool-design decisions. The
  ChatClient understands and formulates; the backend knows, decides,
  validates, persists, and returns the next technical action. Other
  architecture, behavior, skill, policy, and runbook documents may specialize
  this boundary but must not redefine it.
- **Backend authority:** curriculum, personalization, scope, frontier, active goal,
  allowed transitions, Mastery, Verified Recall, and exam evaluation remain
  backend decisions.
- **Deterministic orchestration boundary:** the backend owns technical workflow
  orchestration: opaque IDs, counts, order, completeness, state transitions,
  concurrency, idempotency and the exact next action. The model owns natural
  language, didactic dialogue and semantic comparison of visible learner work
  with backend-released criteria. Never encode a deterministic technical loop
  in a prompt when one server operation can validate and execute it atomically.
  For Verified Recall this means one server-sized full batch, one full answer
  release after the learner submission, a feedback and closure turn, and one
  atomic result write after learner consent. The server-provided continuation
  is followed only when the learner agreed to continue. If the terminal successor
  authorizes an image, that continuation itself owns the renderer call with
  fully server-filled image-specific arguments and then teaching; the model
  derives no cross-flow arguments.
  The plugin checker must
  reject singular per-card Recall tools, model-facing Recall goal/count inputs,
  model-supplied state or retry fields on the capability-bound write, and a
  server Recall instruction longer than the concise cross-tool invariant.
- **Target OpenAI plugin:** maintain one durable public plugin
  (`skillpilot-coach`), not one per language or package major (§0). It
  combines one neutral English coach-control skill with one
  directly submitted MCP server, versioned tool contract, stable endpoint,
  and generated submission test suite. The backend-owned
  learning session pins the interaction language; all learner-facing payloads
  arrive in that language and the model must use it exclusively. Local pilot
  packages may reference the registered connection through `.app.json`.
- **Coach-skill boundary:** coaching role, dialogue, didactic scaffolding,
  semantic evaluation, response format and bounded error behavior belong in the
  skill. Deterministic multi-step tool sequencing belongs in the backend, not
  in model instructions.
  MCP server instructions contain only short cross-tool invariants; per-tool
  conditions stay in tool descriptions; current-step instructions stay in fresh
  tool results. Authorization, state-transition and already implemented safety
  guarantees stay in backend guards. Chat-only evidence is not a hard guarantee
  until a server-side evidence or submission receipt exists. The skill is never
  a source of learner state or authorization.
- **Coach-content maintenance:** current backend/MCP contract,
  ChatClient/backend communication contract, behavioral integration,
  `SKILL.md`, and its provider-specific workflow references are the active sources.
  Keep each coach rule in one instruction location: shared rules belong in the
  entrypoint, specialized rules in a clearly routed workflow. Use a reference
  read before that workflow only when the host can reliably load it. The Claude
  exam workflow is owned directly by its SKILL.md section after a real-host
  failure to load the former reference; do not restore a mandatory `Skill` tool
  or file lookup for exams. Do not duplicate those rules in a second policy.
  Preserve assessment, privacy and state invariants when shortening instructions;
  verify realistic coach decisions as well as package integrity. The frozen
  Custom-GPT and Visible-Session packages are historical baseline or isolated
  rollback artifacts, not active parity targets; do not edit them to mirror a
  current V1 feature. Obsolete `startCode`, `chatSessionToken`, Action,
  visible-relay, and model-built deep-link mechanics never return to V1.
- **MCP-App state rule:** user-facing labels and released learning content belong
  in `content` / `structuredContent`. Permanent-ID handling and Level 2
  curriculum or personalization configuration stay in the first-party WebGUI;
  V1 exposes neither their choices nor their mutation tools to the model.
  Widget-only click references remain in result `_meta` and app-only tools apply
  them directly. The
  `goalVisualization` projection is present only when the learner's default-on
  chat-visualization preference is enabled and an active atomic goal has a
  matching canonical image link. The dedicated read-only
  `render_skillpilot_goal_visualization` tool carries its dedicated
  `ui.resourceUri` and `openai/outputTemplate`; both bind the one active,
  hash-addressed image-only MCP Apps resource for that renderer. It passes bounded
  `goalVisualization` data in `structuredContent`, and the widget renders only
  the image after it loads successfully. The separate memory-practice launcher
  binds its own active resource, while its rating write is app-only. Ordinary
  context reads and other state mutations carry no UI metadata and never create
  a UI box. No user-agent or
  client-surface gate changes this contract. When the newest full result
  contains `goalVisualization` and permits the renderer, each previously unseen
  pair of the full context's `goalVisualization.goalId` and the authorizing
  result's top-level `stateVersion` creates a separate one-shot authorization
  only when the learner agreed to begin or continue that goal. The model never
  renders a next-task or successor image during feedback or pending closure.
  It renders that pair even if an
  earlier pair was already rendered. A repeated pair is rendered again only
  after an explicit learner request and a fresh qualifying result; it is never
  retried automatically. The pair is copied unchanged into `goalId` and
  `expectedStateVersion`. Every terminal Verified-Recall receipt that
  authorizes a successor image instead carries that complete renderer
  invocation inside its sole `continuation` as
  `renderGoalVisualizationThenTeachActiveGoal`; it is neither a sibling
  `presentationAction` nor a UI binding on the Recall write. Execute that
  renderer only after agreement to continue; after closure with a pause,
  wait for a later fresh context. Every
  fachlicher model-facing tool, including state reads, receives the unchanged
  `learningSessionId` to rehydrate state after a new turn, reload, or context
  compaction.
- **OpenAI identity/session rule:** OAuth authorizes the registered App
  transport but does not select the learner. An independent, absolute 24-hour
  server-side learning session addresses the learner for fachliche tools. Only
  an explicitly confirmed first-party `Lernen starten` action creates a new
  independent session and opens a new chat; neither bearer-token refresh nor
  MCP activity slides its expiry. New session-bound operations require at least
  one hour of remaining validity, including the exact `PT1H` boundary. Below
  that boundary, the coach stops and returns only the server-owned WebGUI start
  instruction. A replay with the same tool name, canonically identical
  arguments, and the same `clientRequestId` for an already committed write is
  also rejected below the one-hour action guard. It is returned only while the
  pinned versions remain available and its completed `stateVersion` is still
  the current canonical learner revision; it executes no fachliche operation.
  Session recovery means “start a fresh
  learning session in SkillPilot and open a new chat”, never “reconnect OAuth”.
- **Prototype boundary:** `ai/openai app/` contains an executable neutral
  Streamable-HTTP MCP Apps mechanism prototype and local host simulation with
  localized demo payload catalogs. It exposes one control-plane contract rather
  than one contract per language. Its no-auth, single-demo-state store is never
  production auth. The production Spring Boot adapter requires OAuth App
  authorization plus an explicit database-backed learning-session mapping and
  uses `CoachToolFacade`; do not route real learner data through the demo store.
- **Interim Custom GPT projection:** ten locale-specific Actions combine one-time
  start-code redemption with the compact nine-operation coach adapter, reload
  state on normal user turns, and protect Recall answers and exam solutions behind
  later Actions.
- **Private cross-turn default:** the temporary session token, selection
  reference, canonical active-goal ID, and Recall card IDs remain in Action
  context. A real cross-turn retention canary is a release gate because provider
  retention is empirical, not an official stability guarantee.
- **Visible emergency relay:** only an explicitly generated fallback start carries
  the temporary token and later required technical values in conversation text.
  A private chat never switches to this mode automatically.
- **Visible same-turn intake:** a natural multi-part request remains active only
  within the current assistant turn. Fresh uniquely matched selections may chain
  without displaying intermediate codes; a numbers-only reply is consumed by
  exactly one visible choice. This is a fallback optimization, not a replacement
  for the MCP-App target.
- **Provider-specific contracts:** German and English Custom GPTs have independent
  Instructions, seven Knowledge files each, and independent locale-fixed OpenAPI
  schemas. A one-size-fits-all schema is not allowed.
- **Claude lanes:** the active Claude channel is the provider-isolated
  Connector v1 with its optional plugin (§11.3, §12.2). The earlier OAuth/MCP
  beta adapter under `/api/claude/mcp` stays dormant and disabled by default
  (`skillpilot.claude.enabled=false`); it is not production-ready and not a
  release path. Do not extend, re-enable or clean it up without an explicit
  decision.
- **Shared coach boundary:** `CoachToolFacade` owns provider-neutral workflow
  guards and `CoachStateProjection` owns the normal model-facing allowlist.
  Provider adapters resolve their own temporary session or OAuth identity and
  render passgenaue tool responses. See
  `docs/concept/runtime-workflows/provider-neutral-coach-boundary.md`.

### 12.2 Setup Guides
- **Current Custom GPT Action Session:** See
  `ai/openai custom gpt/de/gpt_setup_guide.md` and
  `ai/openai custom gpt/en/gpt_setup_guide.md`. These guides create two
  independent new GPTs named `SkillPilot GPT Coach (de)` and
  `SkillPilot GPT Coach (en)` from empty Builder configurations.
- **OpenAI MCP Apps:** See `ai/openai app/README.md` and
  `ai/openai plugin/README.md`. The current canonical multilingual source
  plugin lives under `ai/openai plugin/skillpilot-coach`
  (`ai/openai plugin/skillpilot-coach-v1` is inactive historical source whose
  drafts, review records and published Git release bytes stay intact) and directly declares
  the production MCP server plus its language-neutral English control-plane
  skill. The current public submission package is MCP-only: it must not carry
  an old pilot `.app.json` mapping or a manifest `apps` reference. The rejected
  snapshot retains that historical wiring only as evidence. Host acceptance
  must verify the current direct MCP contract and both declared widget flows.
  Authored review cases and portal metadata live in `submission/`; these
  non-secret review worksheets are not included in the installable archive.
  Package SemVer, Contract Major, release drafts, published snapshots,
  lifecycle states and major-line retirement follow
  `docs/concept/runtime-workflows/openai-plugin-versioning-and-lifecycle.md`;
  release operations follow `docs/deploy/openai-plugin-v1-release.md`.
  A not-yet-published package version may be refreshed repeatedly under
  `contracts/drafts/` without a SemVer increment. Only a confirmed publication
  may create `contracts/published/` and advance `release-index.json`; published
  snapshots are immutable.
- **Claude Connector v1:** See `ai/claude/connector-v1/README.md`. The remote
  connector owns OAuth, MCP, all tools and both MCP Apps UIs; the optional
  plugin under `ai/claude/plugin/skillpilot-coach-v1/` adds only the coaching
  Skill and the declaration of that same connector. Release and publication
  follow `docs/deploy/claude-connector-v1-release.md` and
  `docs/deploy/claude-personal-marketplace-release.md`; published packages and
  their evidence are immutable.
- **Gemini controlled integration candidate:** `ai/gemini/coach/SKILL.md` and
  `ai/gemini/gateway` use the separate `gemini-v1` Spring adapter and `spg_`
  learning sessions. The ordinary **Lernen starten → Gemini (Beta)** entry
  prepares the private start message; the learner selects both the imported
  Skill and the connected Custom App. The 6 October 2026 controlled real-host
  test confirmed canonical context, a host-approved mastery save and the saved
  successor in a distinct new Gemini chat. This is one operator account and a
  separate development database, not public multi-user or production acceptance.
  The operator gateway loses grants on restart and requires reconnecting after
  at most one hour. Learning sessions expire absolutely after 24 hours and tools require
  one hour remaining. Backend-only deployment leaves Gemini disabled unless
  configured and does not install its loopback gateway or HTTPS edge. Follow
  `docs/deploy/gemini-integration.md` and `deploy/gemini-v1/README.md` for the
  prepared stable-origin installer and owner-operated activation. The installer
  preserves private keys and does not activate production services. The normal
  rollout requires the unchanged 0.1.0 skill ZIP in both artifacts and its public
  download; SPA HTML is an error. Preparation validates and copies the retained
  `ai/gemini/coach/artifacts/` ZIP without host-dependent recompression.
  Direct goal-image display in Gemini remains
  unresolved, and a direct link does not satisfy its acceptance. Preserve the
  independent synthetic PoC
  evidence and all published provider artifacts.
- **ChatGPT clean source:** `ai/openai custom gpt/` retains no prior GPT IDs,
  URLs, screenshots, Instructions, Knowledge, or rollback Builder bundle.
  `action-regression/` is test infrastructure only and is never uploaded.
- **OpenAPI specs are package-local:** The new locale packages own separate
  schemas under `ai/openai custom gpt/de/` and
  `ai/openai custom gpt/en/`. Do not place or treat a
  `skillpilot-api-4ai.*` file directly below `ai/` as a shared schema.

## 13. Curriculum Assets & Flashcard Decks
- **Source of Truth:** Canonical German Gymnasium decks live under `curricula/DE/Gymnasium/memory-decks/` (see §7.2), not beside the canonical landscape JSON. Decks of other curricula (`*_deck.json`) and their curriculum-related assets stay in the same directory as that curriculum's JSON files (e.g., `curricula/EU/CEFR/English_From_German/json/`).
- **Deployment:** `npm --prefix app run deploy:assets` (part of `prepare:runtime-assets` and therefore of `npm --prefix app run build`) copies the registered canonical decks to `app/public/data/` and `backend/src/main/resources/static/data/`. A new canonical deck must be registered in `scripts/deploy_curriculum_decks.ts`; that script covers only the canonical Gymnasium deck directory.
- **Development:** Edit the source deck and rerun the deployment step; never edit the deployed copies.

---

## 14. LaTeX Rendering Context (Cockpit vs. Exam Mode)

For math formulas in task content, always distinguish between:

- **Stored/escaped LaTeX text** (e.g. `\\( ... \\)` in JSON or raw payloads),
- **Rendered math output** (when a math renderer is active in UI).

Important behavior rule:

- In **exam mode / assessment mode**, task blocks may need to be shown **verbatim**.  
  In that case, do not silently rewrite or "repair" escaped LaTeX formatting.
- In **Cockpit/normal learning views**, formulas can appear properly rendered because a math renderer is active.

Practical note for explanations to users:

- Raw `\\( ... \\)` means LaTeX is present as escaped text but currently not rendered.
- Proper inline rendering form is `\\( Q = 900\\,\\mathrm{kJ} \\)`; block form is:

```latex
$$
\eta = \frac{W}{Q}
$$
```

When users report "formulas are broken", first clarify whether the issue is:

1. content encoding (wrong LaTeX in data), or
2. rendering context (correct LaTeX, but no active math renderer in that view).
