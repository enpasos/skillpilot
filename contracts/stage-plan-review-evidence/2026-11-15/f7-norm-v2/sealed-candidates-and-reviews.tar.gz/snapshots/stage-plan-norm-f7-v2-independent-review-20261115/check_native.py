#!/usr/bin/env python3
"""Native compiler verification/build in an isolated root; never writes active docs."""
from pathlib import Path
import json, shutil, sys, hashlib
BASE=Path('/home/enpasos/projects/skillpilot/tmp/stage-plan-norm-f7-candidate-20261115-v2')
REPO=BASE.parents[1]
ROOT=Path('/home/enpasos/projects/skillpilot/tmp/stage-plan-norm-f7-v2-independent-review-20261115/render-root')
ROOT.mkdir(exist_ok=True)
def overlay(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.is_symlink():dst.unlink()
 shutil.copyfile(src,dst)
if not (ROOT/'docs/compendia.json').exists():
 # All mutable output parents are real directories. Other files are read-only links.
 for src in (REPO/'docs').rglob('*'):
  rel=src.relative_to(REPO);dst=ROOT/rel
  if src.is_dir():dst.mkdir(parents=True,exist_ok=True)
  elif not dst.exists():dst.symlink_to(src)
 for src in REPO.iterdir():
  if src.name in ['docs','tmp','.git','scripts']:continue
  dst=ROOT/src.name
  if not dst.exists():dst.symlink_to(src)
 shutil.copytree(REPO/'scripts/doc_compendium',ROOT/'scripts/doc_compendium',dirs_exist_ok=True)
 for src in (REPO/'scripts').glob('*.py'):overlay(src,ROOT/'scripts'/src.name)
# Freeze all authored source bytes used in both compendia.
for dirname in ['docs/concept/skill-graph/source','docs/concept/glossary/source','docs/concept/skill-graph/architecture-source']:
 for src in (REPO/dirname).rglob('*'):
  if src.is_file():overlay(src,ROOT/src.relative_to(REPO))
for src in (BASE/'proposed').rglob('*'):
 if src.is_file():overlay(src,ROOT/src.relative_to(BASE/'proposed'))
for src in (REPO/'scripts').iterdir():
 dst=ROOT/'scripts'/src.name
 if not dst.exists():dst.symlink_to(src)
registry=json.loads((ROOT/'docs/compendia.json').read_text())
for entry in registry['compendia']:
 if entry['id'] not in ['skill-graph','glossary','skill-graph-architecture']:continue
 manifest=json.loads((ROOT/entry['manifestPath']).read_text())
 targets=[path for page in manifest['webPages'] for path in page['paths'].values()]
 for data in manifest.get('pdf',{}).values():targets+=data.get('outputPaths',[])
 if entry.get('buildJsonPath'):targets.append(entry['buildJsonPath'])
 for path in targets:
  p=ROOT/path
  if p.is_symlink():p.unlink()
sys.path.insert(0,str(ROOT/'scripts'))
from doc_compendium.engine import run_compendia_pipeline
run_compendia_pipeline(repo_root=ROOT,compendium_ids=['skill-graph','glossary','skill-graph-architecture'],verify_sources=True,web_and_tex=True,check_only=False,update_mkdocs_map=False)
run_compendia_pipeline(repo_root=ROOT,compendium_ids=['skill-graph','glossary','skill-graph-architecture'],verify_sources=True,web_and_tex=True,check_only=True,update_mkdocs_map=False)
print('Native DE/EN source verification, web/TeX generation, and generated-web freshness passed in isolated root.')
