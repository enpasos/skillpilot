from pathlib import Path
from collections import Counter
from itertools import permutations
import json,hashlib
ROOT=Path(__file__).resolve().parents[2]
C=ROOT/'tmp/stage-plan-norm-f7-candidate-20261115-v2'
OUT=Path(__file__).resolve().parent
pins=json.loads((C/'source-pins.json').read_text())['sources']
for entry in pins:
 for field,tree in [('beforeSha256','baseline'),('proposedSha256','proposed')]:
  assert hashlib.sha256((C/tree/entry['path']).read_bytes()).hexdigest()==entry[field]
old={x['id']:x for x in json.loads((C/'baseline/docs/concept/skill-graph/source/rules-and-gates.json').read_text())['rules']}
new={x['id']:x for x in json.loads((C/'proposed/docs/concept/skill-graph/source/rules-and-gates.json').read_text())['rules']}
assert len(old)==len(new)==145
counts=Counter(x['ampel'] for x in new.values());assert counts=={'hart':12,'teil':50,'offen':57,'opt':26}
changes=[(k,old[k]['ampel'],new[k]['ampel']) for k in old if old[k]['ampel']!=new[k]['ampel']]
assert changes==[('GD-U14','opt','offen'),('GD-P05','opt','offen')]
matrix=json.loads((C/'rule-decision-matrix.json').read_text())
expected={f'GD-U{i:02}' for i in range(1,16)}|{f'GD-P{i:02}' for i in range(1,12)}
assert len(matrix)==26 and {r['id'] for r in matrix}==expected
matrix_mismatches=[]
for row in matrix:
 for side,actual in [('old',old[row['id']]),('new',new[row['id']])]:
  for key in actual:
   if row[side].get(key)!=actual[key]:matrix_mismatches.append({'id':row['id'],'side':side,'field':key})
assert matrix_mismatches==[]

def witnesses(atoms,requires,blocks=(),after=()):
 result=[]
 for order in permutations(atoms):
  at={a:order.index(a) for a in atoms}
  if any(at[p]>=at[g] for g,p in requires):continue
  if any(max(at[a] for a in b)-min(at[a] for a in b)+1!=len(b) for b in blocks):continue
  if any(max(at[a] for a in v)>=min(at[a] for a in u) for u,v in after):continue
  result.append(order)
 return result
cases=[]
# R points from dependent to prerequisite; acquisition is prerequisite first.
assert witnesses('abc',[('a','b'),('b','c')])==[('c','b','a')]
assert not witnesses('abc',[('a','b'),('b','c')],[set('ac'),set('b')])
cases.append({'id':'atomic-dag-not-E2','atoms':['a','b','c'],'requires':[['a','b'],['b','c']],'blocks':[['a','c'],['b']],'atomicWitness':['c','b','a'],'blockWitnessCount':0})
# Own atomic child a beside child-unit V={b}: direct need orders b before a.
assert witnesses('ab',[('a','b')],[set('ab'),set('b')])==[('b','a')]
cases.append({'id':'E3-own-atom-exception','UOwn':['a'],'UChildUnits':{'V':['b']},'requires':[['a','b']],'declaredAfter':[],'validWitness':['b','a'],'v2FindingResolved':True})
# After orders all V before U but does not contribute to acquisition closure.
requires={('u','v1')};L={'u'}
while True:
 expanded=L|{p for a,p in requires if a in L}
 if expanded==L:break
 L=expanded
assert L=={'u','v1'} and 'v2' not in L
cases.append({'id':'after-no-scope-expansion','U':['u'],'V':['v1','v2'],'after':[['U','V']],'requires':[['u','v1']],'seed':['u'],'closedScope':sorted(L),'wholeVCompleted':False})
# Earlier goal a requiring carried later b is a real backflow, not auto preparation.
assert not witnesses('ab',[('a','b')],[set('a'),set('b')],[(set('b'),set('a'))])
cases.append({'id':'carried-late-not-auto-moved','sourceAssignment':{'a':'I','b':'II'},'learningPlacement':{'a':'I','b':'II'},'requires':[['a','b']],'backflow':True,'automaticMovePermitted':False})
# A guessed entry basis cannot remove b from actual L.
cases.append({'id':'entry-is-not-mastery','seed':['a'],'requires':[['a','b']],'assumedEntry':['b'],'actualClosedScope':['a','b'],'masteryWritten':[]})
# Recognition waits for every open own protected demand, not just one passed exam.
ordinary={'A'};protected={'Q1','Q2'};req={('Q1','A'),('Q2','A')}
def recognized(passed):
 needed={p for q,p in req if q in protected-passed}
 return ordinary-needed
assert recognized({'Q1'})==set() and recognized({'Q1','Q2'})=={'A'}
cases.append({'id':'local-recognition-all-open-demand','ownOrdinary':['A'],'ownProtected':['Q1','Q2'],'requires':[['Q1','A'],['Q2','A']],'afterQ1Recognized':[],'afterBothRecognized':['A'],'parentExamCanPassChild':False})
for row in matrix:
 assert row['old']==old[row['id']] and row['new']==new[row['id']]
assert hashlib.sha256((C/'candidate.patch').read_bytes()).hexdigest()=='bb38b836b9b7dd10c36d00cac2803f79ef435093af69a356c8d1c9e99926a3e8'
assert hashlib.sha256((C/'bundle-pins.json').read_bytes()).hexdigest()=='69b21b810c1792ddba8d1011902c8ce4912eaede5e29bcde5fbdf3846af12fb3'
bundle=json.loads((C/'bundle-pins.json').read_text())['sha256ByPath']
for name,digest in bundle.items():assert hashlib.sha256((C/name).read_bytes()).hexdigest()==digest,name
seal=json.loads((C/'v1-seal.json').read_text());v1=ROOT/seal['sealedDirectory']
assert len(seal['sha256ByPath'])==64
for name,digest in seal['sha256ByPath'].items():assert hashlib.sha256((v1/name).read_bytes()).hexdigest()==digest,name
for entry in pins:assert (C/'baseline'/entry['path']).read_bytes()==(v1/'baseline'/entry['path']).read_bytes(),entry['path']
# The exact pinned patch must describe all and only the 26 supplied source diffs.
import difflib
expected_patch=''.join(''.join(difflib.unified_diff((C/'baseline'/entry['path']).read_text().splitlines(keepends=True),(C/'proposed'/entry['path']).read_text().splitlines(keepends=True),fromfile='a/'+entry['path'],tofile='b/'+entry['path'])) for entry in pins)
assert expected_patch==(C/'candidate.patch').read_text()
# Both language summaries preserve the corrected own-atom exception, layer-local E4 and B9 boundary.
for lang in ['de','en']:
 text=new['GD-U14']['rule'][lang]
 assert ('mindestens ein Kind ein eigenes Atom' if lang=='de' else 'at least one child is an own atom') in text
 assert ('gedachte Wurzel' if lang=='de' else 'imaginary root') in text
 assert ('E4: Kein erklärtes Geschwister-after folgt aus den übrigen dort erklärten after' if lang=='de' else 'E4: No declared sibling after follows from the other after declarations there') in text
 assert 'E1/R4' in new['GD-U05']['milestone'][lang]
 assert 'R1' not in new['GD-U05']['milestone'][lang]
 assert ('B9 hebt' if lang=='de' else 'B9 retires') in new['GD-D03']['rule'][lang]
# Additional explicit B9 witness: u stays reachable from v1 despite incomplete V={v1,v2}.
mastered={'v1'};required={'v1'};V={'v1','v2'}
assert required<=mastered and not V<=mastered
cases.append({'id':'B9-frontier-with-open-other-unit-target','mastered':sorted(mastered),'uRequires':sorted(required),'V':sorted(V),'atomicDemandSatisfied':True,'VComplete':False,'afterCreatesLock':False})
result={'bundleFilesVerified':len(bundle),'v1SealedFilesVerified':64,'v2BaselinesByteEqualToV1':True,'all26MatrixSidesObjectEqual':True,'patchReconstructedExactly':True,'reviewedPatchSha256' :hashlib.sha256((C/'candidate.patch').read_bytes()).hexdigest(),'sourceFiles':len(pins),'allBeforeProposedPinsMatch':True,'rules':len(new),'counts':dict(counts),'statusChanges':changes,'matrixRows':len(matrix),'matrixMismatches':matrix_mismatches,'counterexamples':cases}
(OUT/'review-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
