"""This block is embedded in author_candidate.py; kept here for readable review mapping."""
# R1: E3 owns an atom exception at the smallest common unit; E4 uses declared after only.
name=S+'rules-and-gates.json';data=load(name)
for row in data['rules']:
 if row['id']=='GD-U14':
  row['rule']={
   'de':'B9 vom 14. November 2026 hebt das frühere Open/Cleared-Zugangsprofil im Zielmodell auf; keine Sperre ersetzt es. E3: Braucht a das Ziel b, betrachtet man die kleinste gemeinsame Einheit oder gedachte Wurzel. Liegen beide dort in verschiedenen Kind-Einheiten, folgt die Reihenfolge aus der dort erklärten Geschwister-after-Hülle. Ist mindestens ein Kind ein eigenes Atom, ordnet der Bedarf selbst; ein after zwischen Atom und Einheit wird nicht erklärt. E4: Kein erklärtes Geschwister-after folgt aus den übrigen dort erklärten after. Je Deklarationsschicht prüfen; die atomare requires-Minimalität bleibt separat. E3/E4 sind verbindlich, aber kein produktives hartes Gate.',
   'en':'B9 of 14 November 2026 retires the former Open/Cleared access profile in the target model; no lock replaces it. E3: If a requires b, inspect their smallest common unit or imaginary root. If both lie in different child units there, their order follows from that declared sibling after closure. If at least one child is an own atom, demand itself orders it; no after between an atom and a unit is declared. E4: No declared sibling after follows from the other after declarations there. Check per declaration layer; atomic requires minimality stays separate. E3/E4 are binding, but no production hard gate.'}
 # R2: Document rule must agree with its enforcement and binding B9.
 if row['id']=='GD-D03':
  row['rule']['de']=row['rule']['de'].replace('Ganzheitssperren und Examzugriff darunter sind offen, Zeitplanung bleibt gesondert.','B9 hebt das frühere Ganzheits-Zugangsprofil im Zielmodell auf. Direkter Prüfungszugang bleibt unter seinem Aufgaben-, Authentifizierungs-, Scope- und Sitzungsvertrag erhalten; keine Codeumstellung wird hier behauptet. Zeitplanung bleibt gesondert.')
  row['rule']['en']=row['rule']['en'].replace('unit-wide locks and direct exam access under them stay open, and time planning stays separate.','B9 retires the former whole-unit access profile in the target model. Direct assessment access remains under its task, authentication, scope, and session contract; no code migration is claimed here. Time planning stays separate.')
 # C3: U05 is E1/R4; R1 belongs to U06 only.
 if row['id']=='GD-U05':
  row['milestone']={'de':'Zielmodell: E1/R4 als eindeutige kleinste Einheitszuordnung; bestehende harte 1.2-Prüfungen bleiben. Keine vollständige neue Modellabnahme.','en':'Target model: E1/R4 as unique smallest-unit assignment; existing hard 1.2 checks remain. No full new-model acceptance.'}
dump(name,data)

# R2: The initial AGENTS rules must be current, not contradicted only by a later note.
name='AGENTS.md'
replace(name,'''- An explicitly authored whole-unit requirement belongs to the course. An atomic
  prerequisite does not automatically impose the entire foreign unit. Whether
  unit requirements guide recommendations or technically block starts, including
  direct assessment attempts, remains undecided; no new hard gate is authorized
  by this concept alone. Independent branches may proceed in parallel.''','''- **Whole-unit order (B9, 14 November 2026).** Only an explicitly authored
  `after` states the intended full completion of one unit before another
  starts; it is order, never a new whole-unit prerequisite type. Atomic
  prerequisites demand only their competencies. The former undecided access
  profile is retired in the binding target model: `after` blocks no starts
  or direct assessment attempts and changes neither frontier nor mastery.
  Task availability, authentication, scope and session binding remain their
  own contracts. This does not claim removal of historical code paths;
  independent branches may proceed in parallel.''')
replace(name,'recorded origin, never a contract. Whole-unit access locks stay undecided.','recorded origin, never a contract. The whole-unit access question left open\n  at that date was retired by B9 on 14 November 2026; only declared `after`\n  orders whole-unit completion, without need or access locks.')

# R2: The design sheet must assign whole-unit completion order only to authored after.
for lang in ['de','en']:
 name='docs/concept/skill-graph/architecture-source/chapters/12-learning-unit-design-and-examples.'+lang+'.md'
 if lang=='de':
  replace(name,'dafür bedarf es einer fachlich begründeten Ganz-Einheits-Voraussetzung.','Nur ein ausdrücklich erklärtes, fachlich begründetes `after` sagt, dass im vorgesehenen Lernfluss die gesamte andere Einheit vor Beginn abgeschlossen ist. Das ist eine Reihenfolge, kein zusätzlicher Voraussetzungstyp: Sie verändert weder atomaren Bedarf noch Frontier und sperrt keinen bewussten Prüfungsversuch.')
 else:
  replace(name,'that needs a subject-justified whole-unit prerequisite.','Only an explicitly authored, subject-justified `after` states that the whole other unit is complete before work begins in the intended flow. This is order, not an additional prerequisite type: it changes neither atomic demand nor frontier and locks no deliberate assessment attempt.')

# R4: Restrict F8-F13 to future unit migration; authorized K repairs continue now.
name=S+'implementation-status.json';data=load(name)
for row in data['poDecisions']:
 if row['de'].startswith('**14./15. November 2026:**'):
  row['de']=row['de'].replace('Neue fachliche Einheiten, Deckungsänderungen und produktive Leser benötigen weiterhin F8 bis F13 und ihre eigenen Nachweise.','Die künftige Einführung und Umstellung fachlicher Einheiten, ihre Cluster- und Prüfungsumzüge, Paketträger, produktiven Leser und neue Anerkennung folgen F8 bis F13 mit eigenen Nachweisen. Notwendige aktuelle Ziel-, Aufgaben-, Rubrik- und Deckungsreparaturen bleiben im delegierten K1–K13-Auftrag bereits jetzt zulässig; sie brauchen geeignete Aufgaben und aktuelle unabhängige Nachweise und dürfen falsche Voraussetzungen oder Abdeckung nicht bis F8 konservieren.')
  row['en']=row['en'].replace('New subject units, coverage changes, and production readers still require F8 to F13 and their own evidence.','Future introduction and migration of subject units, their cluster and assessment moves, package carriers, production readers, and new recognition follow F8 to F13 with their own evidence. Necessary current goal, task, rubric, and coverage repairs remain authorized now under delegated K1–K13; they require suitable tasks and current independent evidence and must not preserve false prerequisites or coverage until F8.')
 # C2: Time remains optional, P05's declared-unit E2 does not.
for row in data['boundaryTable']:
 if row['area']['en']=='Optional acquisition and time planning':
  row['repoStatus']={
   'de':'Das Zeit-/Budgetprofil bleibt optional (GD-P01–P04 und GD-P06–P11). GD-P05 enthält daneben die verbindliche E2-Pflicht erklärter Planeinheiten, noch ohne produktives hartes Gate. Kein produktives Curriculum- oder Laufzeit-Budgetgate wird behauptet; weight bedeutet niemals Minuten.',
   'en':'The time/budget profile remains optional (GD-P01–P04 and GD-P06–P11). GD-P05 additionally contains binding E2 for declared plan units, without a production hard gate yet. No production curriculum or runtime budget gate is claimed; weight never denotes minutes.'}
dump(name,data)

# C1: Both older umbrella definitions include declared cluster order and plan units.
name=S+'glossary-and-symbols.json';data=load(name)
for entry in data['frontmatterDistinctions']:
 if entry['term']['de']=='Cluster, Lerneinheit, Programmeinheit':
  entry['meaning']={
   'de':'Ein Cluster ist ein Ziel mit contains-Kindern. Eine Einheit ist ein ausdrücklich erklärter Cluster mit Lernversprechen und zusammenhängender Blockordnung nach E1 bis E4: fachliche Einheiten in der kanonischen Landschaft, Planeinheiten im gemeinsamen Landes-/Dauermodellplan. Eine Einheit mit Prüfungen belegt zusätzlich eigene Inhaltsziele. Programmeinheiten bilden organisatorische Struktur. Die bisherige learningUnit-Deklaration mit own und parentUnitId ist bis zur Migration der 1.2-Kompatibilitätsvertrag.',
   'en':'A cluster is a goal with contains children. A unit is an explicitly declared cluster with a learning promise and continuous block order under E1 to E4: subject units in the canonical landscape, plan units in the shared Land/duration plan. A unit with assessments additionally evidences own content goals. Program units form organizational structure. The existing learningUnit declaration with own and parentUnitId remains the 1.2 compatibility contract until migration.'}
 if entry['term']['de']=='verfasst, abgeleitet':
  entry['meaning']={
   'de':'Im Zielkern sind contains und requires verfasst; die Einheitenschicht erklärt zusätzlich Cluster als Einheiten und after als Ordnung ohne Bedarf. Effektive Anforderungen, Hüllen, eigene Zielmengen und notwendige Vorbereitung werden daraus abgeleitet.',
   'en':'The goal core authors contains and requires; the unit layer additionally declares clusters as units and after as order without demand. Effective requirements, closures, own goal sets, and necessary preparation derive from them.'}
for entry in data['glossary']:
 if entry['term']['en'].startswith('learning unit, child unit, required child'):
  entry['meaning']={
   'de':'Ausdrücklich erklärter Cluster mit Lernversprechen und zusammenhängender Blockordnung nach E1 bis E4; entweder kanonische fachliche Einheit oder Planeinheit im gemeinsamen Landes-/Dauermodellplan. Kindeinheiten sind die direkten erklärten Untereinheiten, Pflichtkinder die verpflichtenden darunter. Die bisherigen own- und parentUnitId-Felder gehören zum 1.2-Kompatibilitätsvertrag.',
   'en':'Explicitly declared cluster with a learning promise and continuous block order under E1 to E4; either a canonical subject unit or a plan unit in the shared Land/duration plan. Child units are the directly declared subunits, required children the mandatory ones. Existing own and parentUnitId fields belong to the 1.2 compatibility contract.'}
dump(name,data)

# Do not leave the narrowed K-repair authorization only in a status table.
for lang in ['de','en']:
 name=S+'chapters/03-learning-units.'+lang+'.md'
 marker='### '+('Motivation und eigener fachlicher Anspruch' if lang=='de' else 'Motivation and Distinct Domain Claims')
 add=('Notwendige aktuelle Fachkorrekturen an Zielen, Voraussetzungen, Aufgaben, Rubriken und Deckung bleiben im delegierten K1–K13-Auftrag bereits jetzt zulässig. Die F8-Grenze betrifft die künftige Einheiteneinführung und ihre Cluster-, Prüfungs-, Paket- und Laufzeitmigration; sie konserviert keine fachlich falsche Kante oder fehlende Prüfung. Jede solche Reparatur braucht ihre eigenen aktuellen unabhängigen Nachweise.\n\n' if lang=='de' else 'Necessary current subject-matter repairs of goals, prerequisites, tasks, rubrics, and coverage remain authorized now under delegated K1–K13. The F8 boundary concerns future unit introduction and its cluster, assessment, package, and runtime migration; it preserves no false edge or missing assessment. Each such repair needs its own current independent evidence.\n\n')
 replace(name,marker,add+marker)

# R3: Exact old values must come from an independent deep copy of baseline bytes.
oldrules={r['id']:r for r in json.loads((BEFORE/(S+'rules-and-gates.json')).read_text())['rules']}
currentrules={r['id']:r for r in load(S+'rules-and-gates.json')['rules']}
for item in matrix:
 item['old']=deepcopy(oldrules[item['id']])
 item['new']=deepcopy(currentrules[item['id']])
 assert item['old']==oldrules[item['id']]
 assert item['new']==currentrules[item['id']]
(BASE/'rule-decision-matrix.json').write_text(json.dumps(matrix,ensure_ascii=False,indent=2)+'\n')
