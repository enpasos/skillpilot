from pathlib import Path
from collections import Counter
from itertools import permutations
import json,hashlib
ROOT=Path(__file__).resolve().parents[2]
C=Path(__file__).resolve().parent
OUT=Path(__file__).resolve().parent
pins=json.loads((C/'source-pins.json').read_text())['sources']
for entry in pins:
 for field,tree in [('beforeSha256','baseline'),('proposedSha256','proposed')]:
  assert hashlib.sha256((C/tree/entry['path']).read_bytes()).hexdigest()==entry[field]
old={x['id']:x for x in json.loads((C/'baseline/docs/concept/skill-graph/source/rules-and-gates.json').read_text())['rules']}
new={x['id']:x for x in json.loads((C/'proposed/docs/concept/skill-graph/source/rules-and-gates.json').read_text())['rules']}
assert len(old)==len(new)==145
counts=Counter(x['ampel'] for x in new.values());assert counts=={'hart':12,'teil':50,'offen':57,'opt':26}
changes=[(k,old[k]['ampel'],new[k]['ampel']) for k in old if old[k]['ampel']!=new[k]['ampel']]
assert changes==[('GD-U14','opt','offen'),('GD-P05','opt','offen')]
matrix=json.loads((C/'rule-decision-matrix.json').read_text())
expected={f'GD-U{i:02}' for i in range(1,16)}|{f'GD-P{i:02}' for i in range(1,12)}
assert len(matrix)==26 and {r['id'] for r in matrix}==expected
matrix_mismatches=[]
for row in matrix:
 for side,actual in [('old',old[row['id']]),('new',new[row['id']])]:
  for key in actual:
   if row[side].get(key)!=actual[key]:matrix_mismatches.append({'id':row['id'],'side':side,'field':key})
assert matrix_mismatches==[],matrix_mismatches
for row in matrix:
 assert row['old']==old[row['id']]
 assert row['new']==new[row['id']]

def witnesses(atoms,requires,blocks=(),after=()):
 result=[]
 for order in permutations(atoms):
  at={a:order.index(a) for a in atoms}
  if any(at[p]>=at[g] for g,p in requires):continue
  if any(max(at[a] for a in b)-min(at[a] for a in b)+1!=len(b) for b in blocks):continue
  if any(max(at[a] for a in v)>=min(at[a] for a in u) for u,v in after):continue
  result.append(order)
 return result
cases=[]
# R points from dependent to prerequisite; acquisition is prerequisite first.
assert witnesses('abc',[('a','b'),('b','c')])==[('c','b','a')]
assert not witnesses('abc',[('a','b'),('b','c')],[set('ac'),set('b')])
cases.append({'id':'atomic-dag-not-E2','atoms':['a','b','c'],'requires':[['a','b'],['b','c']],'blocks':[['a','c'],['b']],'atomicWitness':['c','b','a'],'blockWitnessCount':0})
# Own atomic child a beside child-unit V={b}: direct need orders b before a.
assert witnesses('ab',[('a','b')],[set('ab'),set('b')])==[('b','a')]
cases.append({'id':'E3-own-atom-exception','UOwn':['a'],'UChildUnits':{'V':['b']},'requires':[['a','b']],'declaredAfter':[],'validWitness':['b','a'],'resolvedFinding':'GD-U14 now explicitly exempts own atomic children; only separate child units need declared sibling after.'})
# After orders all V before U but does not contribute to acquisition closure.
requires={('u','v1')};L={'u'}
while True:
 expanded=L|{p for a,p in requires if a in L}
 if expanded==L:break
 L=expanded
assert L=={'u','v1'} and 'v2' not in L
cases.append({'id':'after-no-scope-expansion','U':['u'],'V':['v1','v2'],'after':[['U','V']],'requires':[['u','v1']],'seed':['u'],'closedScope':sorted(L),'wholeVCompleted':False})
# Earlier goal a requiring carried later b is a real backflow, not auto preparation.
assert not witnesses('ab',[('a','b')],[set('a'),set('b')],[(set('b'),set('a'))])
cases.append({'id':'carried-late-not-auto-moved','sourceAssignment':{'a':'I','b':'II'},'learningPlacement':{'a':'I','b':'II'},'requires':[['a','b']],'backflow':True,'automaticMovePermitted':False})
# A guessed entry basis cannot remove b from actual L.
cases.append({'id':'entry-is-not-mastery','seed':['a'],'requires':[['a','b']],'assumedEntry':['b'],'actualClosedScope':['a','b'],'masteryWritten':[]})
# Recognition waits for every open own protected demand, not just one passed exam.
ordinary={'A'};protected={'Q1','Q2'};req={('Q1','A'),('Q2','A')}
def recognized(passed):
 needed={p for q,p in req if q in protected-passed}
 return ordinary-needed
assert recognized({'Q1'})==set() and recognized({'Q1','Q2'})=={'A'}
cases.append({'id':'local-recognition-all-open-demand','ownOrdinary':['A'],'ownProtected':['Q1','Q2'],'requires':[['Q1','A'],['Q2','A']],'afterQ1Recognized':[],'afterBothRecognized':['A'],'parentExamCanPassChild':False})
# These are author-run checks of the independent review counterexamples, not independent acceptance.
for lang in ['de','en']:
 rule=new['GD-U14']['rule'][lang]
 if lang=='de':
  assert 'kleinste gemeinsame Einheit oder gedachte Wurzel' in rule
  assert 'mindestens ein Kind ein eigenes Atom' in rule
  assert 'E4: Kein erklärtes Geschwister-after folgt aus den übrigen dort erklärten after' in rule
 else:
  assert 'smallest common unit or imaginary root' in rule
  assert 'at least one child is an own atom' in rule
  assert 'E4: No declared sibling after follows from the other after declarations there' in rule
 assert 'E1/R4' in new['GD-U05']['milestone'][lang]
 assert 'R1' not in new['GD-U05']['milestone'][lang]
 d3=new['GD-D03']['rule'][lang]
 assert ('B9 hebt' if lang=='de' else 'B9 retires') in d3
 assert ('Examzugriff darunter sind offen' if lang=='de' else 'unit-wide locks and direct exam access under them stay open') not in d3
 design=(C/('proposed/docs/concept/skill-graph/architecture-source/chapters/12-learning-unit-design-and-examples.'+lang+'.md')).read_text()
 assert ('dafür bedarf es einer fachlich begründeten Ganz-Einheits-Voraussetzung' if lang=='de' else 'that needs a subject-justified whole-unit prerequisite') not in design
 assert ('Nur ein ausdrücklich erklärtes, fachlich begründetes `after`' if lang=='de' else 'Only an explicitly authored, subject-justified `after`') in design
agents=(C/'proposed/AGENTS.md').read_text()
assert 'Whole-unit access locks stay undecided.' not in agents
assert 'direct assessment attempts, remains undecided' not in agents
assert 'never a new whole-unit prerequisite type' in agents
status=json.loads((C/'proposed/docs/concept/skill-graph/source/implementation-status.json').read_text())
po=next(v for v in status['poDecisions'] if v['de'].startswith('**14./15. November'))
assert 'Deckungsänderungen' not in po['de'] and 'coverage changes' not in po['en']
assert 'K1–K13' in po['de'] and 'K1–K13' in po['en']
assert 'bereits jetzt zulässig' in po['de'] and 'remain authorized now' in po['en']
opt=next(v for v in status['boundaryTable'] if v['area']['en']=='Optional acquisition and time planning')
assert 'GD-P05' in opt['repoStatus']['de'] and 'verbindliche E2' in opt['repoStatus']['de']
assert 'GD-P05' in opt['repoStatus']['en'] and 'binding E2' in opt['repoStatus']['en']
gloss=json.loads((C/'proposed/docs/concept/skill-graph/source/glossary-and-symbols.json').read_text())
umb=next(v for v in gloss['frontmatterDistinctions'] if v['term']['de']=='Cluster, Lerneinheit, Programmeinheit')
glu=next(v for v in gloss['glossary'] if v['term']['en'].startswith('learning unit, child unit, required child'))
for entry in [umb,glu]:
 for lang in ['de','en']:
  assert 'E1' in entry['meaning'][lang] and 'E4' in entry['meaning'][lang]
  assert ('Planeinheit' if lang=='de' else 'plan unit') in entry['meaning'][lang]
  assert '1.2' in entry['meaning'][lang]
# Re-check the sealed v1 author files and exact baseline inheritance.
seal=json.loads((C/'v1-seal.json').read_text());v1=ROOT/seal['sealedDirectory']
for name,digest in seal['sha256ByPath'].items():assert hashlib.sha256((v1/name).read_bytes()).hexdigest()==digest,name
for entry in pins:assert (C/'baseline'/entry['path']).read_bytes()==(v1/'baseline'/entry['path']).read_bytes()
# Authored after carries full intended order but never supplies extra need or a frontier lock.
explicit={'v1'};atomic_required={'v1'};whole_V={'v1','v2'}
assert atomic_required<=explicit and not whole_V<=explicit
cases.append({'id':'B9-frontier-with-open-other-unit-target','U':['u'],'V':sorted(whole_V),'authoredAfter':[['U','V']],'uRequires':sorted(atomic_required),'explicitMastery':sorted(explicit),'normalAtomicPrerequisitesSatisfied':True,'wholeVCompleted':False,'newWholeUnitPrerequisiteCreated':False,'afterAddsFrontierLock':False})
# E4 belongs to one declaration layer: a canonical chain remains necessary despite Land order.
canonical_after={('C','B'),('B','A')};land_after={('Y2','Y1')}
assert ('C','A') not in canonical_after
cases.append({'id':'E4-per-layer','canonicalAfter':sorted(canonical_after),'redundantCanonicalEdge':['C','A'],'landAfter':sorted(land_after),'landOrderRemovesCanonicalDeclaration':False,'atomicRequiresMinimalitySeparate':True})

result={'reviewedPatchSha256':hashlib.sha256((C/'candidate.patch').read_bytes()).hexdigest(),'sourceFiles':len(pins),'allBeforeProposedPinsMatch':True,'rules':len(new),'counts':dict(counts),'statusChanges':changes,'matrixRows':len(matrix),'matrixMismatches':matrix_mismatches,'v1SealedBytesUnchanged':True,'inheritedBaselinesUnchanged':True,'independentAcceptance':False,'purpose':'Author recheck responding to independent REVISE findings','counterexamples':cases}
(OUT/'review-fix-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
