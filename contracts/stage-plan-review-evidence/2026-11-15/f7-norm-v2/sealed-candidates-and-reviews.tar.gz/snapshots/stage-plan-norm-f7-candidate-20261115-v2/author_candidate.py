#!/usr/bin/env python3
"""Reproduce this documentation-only candidate from the captured baseline."""
from pathlib import Path
import difflib, hashlib, json, shutil
from copy import deepcopy
BASE=Path(__file__).resolve().parent
REPO=BASE.parents[1]
BEFORE=BASE/'baseline'
OUT=BASE/'proposed'
TOUCH=[
 'AGENTS.md',
 'scripts/doc_compendium/extensions/skill_graph.py',
 *[f'docs/concept/skill-graph/architecture-source/chapters/{ch}.{lang}.md' for ch in ['03-view-projection','12-learning-unit-design-and-examples'] for lang in ['de','en']],
 *[f'docs/concept/skill-graph/source/chapters/{ch}.{lang}.md' for ch in ['00-frontmatter','01-core','02-context','03-learning-units','04-planning','05-assessment'] for lang in ['de','en']],
 'docs/concept/skill-graph/source/rules-and-gates.json',
 'docs/concept/skill-graph/source/spec-manifest.json',
 'docs/concept/skill-graph/source/glossary-and-symbols.json',
 'docs/concept/skill-graph/source/implementation-status.json',
 *[f'docs/concept/glossary/source/chapters/{ch}.{lang}.md' for ch in ['01-curricula-and-graph','04-quality-and-distinctions'] for lang in ['de','en']],
]
for name in TOUCH:
 p=BEFORE/name
 if not p.exists():
  p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/name,p)
for name in TOUCH:
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(BEFORE/name,p)
def read(name):return (OUT/name).read_text()
def write(name,text): (OUT/name).write_text(text)
def replace(name,old,new):
 s=read(name)
 assert s.count(old)==1,(name,old[:120],s.count(old))
 write(name,s.replace(old,new))
def load(name):return json.loads(read(name))
def dump(name,data):
 # Preserve original formatting and untouched objects; edit semantic leaf spans.
 raw=read(name); spans={}; decoder=json.JSONDecoder()
 def ws(i):
  while i<len(raw) and raw[i].isspace():i+=1
  return i
 def scan(i,path):
  i=ws(i);start=i;value,end=decoder.raw_decode(raw,i);spans[path]=(start,end,value)
  if isinstance(value,dict):
   j=ws(i+1)
   for key in value:
    k,j=decoder.raw_decode(raw,j);j=ws(j);assert raw[j]==':'
    j=scan(ws(j+1),path+(key,));j=ws(j)
    if raw[j]==',':j=ws(j+1)
  elif isinstance(value,list):
   j=ws(i+1)
   for n in range(len(value)):
    j=scan(j,path+(n,));j=ws(j)
    if raw[j]==',':j=ws(j+1)
  return end
 scan(0,())
 changes=[]
 def visit(path,new):
  start,end,old=spans[path]
  if old==new:return
  if isinstance(old,dict) and isinstance(new,dict) and list(old)==list(new):
   for key in old:visit(path+(key,),new[key])
  elif isinstance(old,list) and isinstance(new,list) and len(old)==len(new):
   for n in range(len(old)):visit(path+(n,),new[n])
  else:changes.append((start,end,json.dumps(new,ensure_ascii=False,indent=2) if isinstance(new,(dict,list)) else json.dumps(new,ensure_ascii=False)))
 visit((),data)
 for start,end,text in sorted(changes,reverse=True):raw=raw[:start]+text+raw[end:]
 write(name,raw)
S='docs/concept/skill-graph/source/'
for lang in ['de','en']:
 write(S+'chapters/03-learning-units.'+lang+'.md',(BASE/('unit-chapter.'+lang+'.md')).read_text())

# Keep the formal goal graph's two relations; declare ordering in the unit layer.
for lang,text in {
'de': '''\n\nDaneben wird in der Einheitenschicht `after` ausdrücklich erklärt (Abschnitt~@ref{sec:unit-progression}): `U after V` ordnet den gesamten Umfang von U nach dem von V, ohne fachlichen Bedarf zu behaupten. Diese Relation ist weder eine zusätzliche `requires`-Kante noch eine Lernergebnisart. `requires` ist die besondere atomare Reihenfolge, die zusätzlich Bedarf ausdrückt. Ein `after` verändert weder Frontier noch Voraussetzungsabschluss, Fortschrittsnenner oder Mastery. Im verbindlichen Zielmodell zeigt keine Voraussetzung auf ein Prüfungsziel; vorhandene Gegenbeispiele sind fachlich zu reparierende Befunde, keine bereits behobenen Daten.\n''',
'en': '''\n\nThe unit layer additionally declares `after` explicitly (Section~@ref{sec:unit-progression}): `U after V` orders all of U after all of V without asserting subject-matter demand. This relation is neither another `requires` edge nor a learner-result kind. `requires` is the special atomic ordering that also expresses demand. An `after` changes neither frontier nor prerequisite closure, progress denominator, or mastery. In the binding target model no prerequisite points to an assessment goal; existing counterexamples are findings requiring subject-matter repair, not already corrected data.\n'''
}.items():
 name=S+'chapters/01-core.'+lang+'.md'
 marker='### '+('Attribute und stabile Identität' if lang=='de' else 'Attributes and Stable Identity')
 assert marker in read(name), marker
 replace(name,marker,text+'\n'+marker)

context={
'de': '''\n\n#### Landesautorität, Quellenzuordnung und Lernplatz.\n\nIm verbindlichen Zielmodell gibt es je Land und Dauermodell einen maßgeblichen Plan über alle gewählten Fächer. Seine vollständige Wurzel hat genau zwei Kinder, Sekundarstufe I und Sekundarstufe II, mit genau einem erklärten `after` von II nach I (Z3). Orientierungsziele, Übungsaufgaben und Prüfungen haben einen begründeten Platz innerhalb dieser Stufen; daneben steht nichts. Kursprofile wählen fachliche Anteile, aber keine widersprechenden Stufen desselben kanonischen Ziels. Eine Einstufensicht ist ein abgeleiteter Ausschnitt und benötigt keine künstliche leere Gegenstufe. Die bundesweite Sicht bleibt kanonische Gliederung und ist kein Landesplan.\n\n**Geführt in** bezeichnet die durch die Landesquelle belegte curriculare Zuordnung. **Steht in** bezeichnet den didaktischen Lernplatz. Eine ausdrücklich begründete frühere Vorbereitung darf den Lernplatz ändern, ohne die ursprüngliche Quellenzuordnung zu überschreiben; sie ist keine neue amtliche Pflicht. Fehlt Landesbeleg, darf eine kanonische Marke wie `dimensionTags.phase` nur eine ausdrücklich vorläufige **Standardzuordnung** begründen. Sie ersetzt weder Landesbeleg noch Quellenabdeckung und überschreibt keine maßgebliche Sicht. Routen prüfen die ausgewertete Lernplatzierung; Quellenprüfungen prüfen weiterhin die Quellenbelege. Unterschiedliche bisherige Leser bleiben bis zur gemeinsamen Umstellung ein Umsetzungsbefund.\n\nDie vorhandene [Stufenplan-Grundlage](repo:contracts/curriculum-package/v1.3/README.md) trennt gemeinsame Pläne, Fachautoritäten und Ausschnitte; die daraus erzeugten Kompatibilitätssichten sind keine zweite Autorquelle. Das Verzeichnis `v1.3` bezeichnet hier einen Entwicklungsvertrag für Stufenpläne, keine veröffentlichte Version des Curriculum-Pakets und keine fertige Umstellung der produktiven Leser. Noch ist kein echter Landesplan aktiviert.\n''',
'en': '''\n\n#### Land Authority, Source Assignment, and Learning Placement.\n\nThe binding target model has one authoritative plan per Land and duration model across the selected subjects. Its full root has exactly two children, Sekundarstufe I and Sekundarstufe II, with exactly one declared `after` from II to I (Z3). Orientation goals, practice tasks, and assessments have a justified place inside these stages; nothing sits beside them. Course profiles select subject contributions, never contradictory stages for the same canonical goal. A single-stage view is a derived excerpt and requires no artificial empty counterpart stage. The nationwide view remains the canonical structure and is no Land plan.\n\n**Carried in** (*geführt in*) means the curricular assignment evidenced by the Land's source. **Placed in** (*steht in*) means the didactic learning placement. Explicitly justified earlier preparation may change the learning placement without overwriting the original source assignment; it creates no new official obligation. Without Land evidence a canonical marker such as `dimensionTags.phase` may justify only an explicitly provisional **default assignment**. It substitutes for neither Land evidence nor source coverage and does not override an authoritative view. Routes inspect evaluated learning placement; source checks continue to inspect source evidence. Divergent existing readers remain an implementation finding until migrated together.\n\nThe existing [stage-plan foundation](repo:contracts/curriculum-package/v1.3/README.md) separates shared plans, subject authorities, and excerpts; generated compatibility views are not a second authoring authority. The `v1.3` directory here denotes a development contract for stage plans, not a published curriculum-package version or completed migration of production readers. No real Land plan is activated yet.\n'''
}
for lang,text in context.items():
 name=S+'chapters/02-context.'+lang+'.md'
 marker='#### '+('Kanonische Identität bleibt erhalten.' if lang=='de' else 'Canonical identity is preserved.')
 assert marker in read(name),marker
 replace(name,marker,text+'\n'+marker)
prep={
'de': '''\n\nDie Stelle einer verfassten `prerequisiteOnly`-Referenz behauptet weder eine amtliche Stufe noch einen Lernplatz. Im Zielmodell erhält ein notwendiges Atom, das der gewählte Plan nicht als Ausgangsziel führt, genau einen abgeleiteten Lernplatz in der Planeinheit seines frühesten tatsächlichen Bedarfs im vollständigen $L$. Dafür werden die vollständigen kanonischen Pfade unabhängig von Mastery durchlaufen; kein ganzes Fach und keine ganze Einheit werden ergänzt. Schon geführte Ziele werden nicht stillschweigend umplatziert: Ein früherer Bedarf an einem später geführten Ziel bleibt ein Rückgriff, bis eine belegte Fachkorrektur oder ausdrücklich begründete Vorbereitung ihn auflöst. Z4/E2 gelten für Vorbereitung und geführte Ziele gleichermaßen. Diese gemeinsame Platzierungsableitung für alle Leser ist noch nicht vollständig produktiv umgesetzt.\n''',
'en': '''\n\nThe authored position of a `prerequisiteOnly` reference asserts neither an official stage nor a learning placement. In the target model a necessary atom that the selected plan does not carry as a seed target receives exactly one derived learning placement in the plan unit of its earliest actual need within the full $L$. Full canonical paths are traversed independently of mastery; neither an entire subject nor an entire unit is added. Already carried targets are not silently moved: earlier demand for a later carried target remains a backflow until an evidenced subject-matter correction or explicitly justified preparation resolves it. Z4/E2 apply equally to preparation and carried targets. This shared placement derivation across all readers is not fully implemented in production yet.\n'''
}
for lang,text in prep.items():
 name=S+'chapters/02-context.'+lang+'.md'
 marker='### '+('Anwendbarkeit ist keine Platzierung' if lang=='de' else 'Applicability Is Not Placement')
 assert marker in read(name),marker
 replace(name,marker,text+'\n'+marker)

# Optional calendar reconstruction stays optional; stage-plan E2 is mandatory target semantics.
for lang,text in {
'de': '''\n\nEine erklärte Planeinheit gehört dagegen bereits zum verbindlichen Ordnungsmodell aus Abschnitt~@ref{sec:unit-progression}. Liegt ein benötigtes Ziel in einer späteren Planeinheit, ist das dort ein Verstoß gegen E2, auch ohne optionales Budgetprofil (`GD-P05`). Die angenommene Eintrittsbasis $B_\\pi$ darf diesen Rückgriff im wirklichen persönlichen Lernumfang $L=\\Closure(S)$ nicht ausblenden. Ein gestufter Diagnosebericht ist noch kein hartes Curriculum-Gate: erst Bericht, fachliche Behebung, Sperrklinke und bei null Verstößen das harte Gate. Der vorhandene Stufenplanbericht und seine optionale Null-Rückgriff-Prüfung aktivieren keinen echten Landesplan und ersetzen keine Quellen- oder Inhaltsprüfung.\n''',
'en': '''\n\nA declared plan unit, by contrast, already belongs to the binding ordering model in Section~@ref{sec:unit-progression}. A required goal placed in a later plan unit violates E2 there even without an optional budget profile (`GD-P05`). The assumed entry basis $B_\\pi$ must not hide this backflow in the actual Personal Curriculum $L=\\Closure(S)$. A staged diagnostic report is not yet a hard curriculum gate: reporting, subject-matter repair, a ratchet, and a hard gate at zero violations follow in that order. The existing stage-plan report and its optional zero-backflow check activate no real Land plan and replace neither source nor content review.\n'''
}.items():
 name=S+'chapters/04-planning.'+lang+'.md';marker='### '+('Aufwand, Reserve und Budget' if lang=='de' else 'Effort, Reserve, and Budget');replace(name,marker,text+'\n'+marker)
for lang in ['de','en']:
 name=S+'chapters/04-planning.'+lang+'.md'
 if lang=='de':replace(name,'Ein Kalenderabschnitt kann mehrere Einheiten enthalten; eine Einheit kann sich über mehrere Kalenderabschnitte erstrecken.','Ein bloßer Kalenderabschnitt kann mehrere fachliche Einheiten enthalten; ohne Erklärung als Planeinheit darf er eine fachliche Einheit zeitlich schneiden. Wird er als Planeinheit erklärt, gelten E1 bis E4. Die vollständige gemeinsame Einführung und die Prüfung, ob jedes Land eine fachliche Blatteinheit als Ganzes führt (B13), folgen erst nach F8; sie sind keine bereits bestandene Eigenschaft der drei bisherigen Einheiten.')
 else:replace(name,'One calendar period may host several learning units, and one learning unit may span multiple calendar periods','A mere calendar interval may contain several subject units; without declaration as a plan unit it may cut across a subject unit in time. Once declared as a plan unit, E1 to E4 apply. Full joint introduction and verification that every Land carries each subject leaf unit as a whole (B13) follow only after F8; they are no already-passed property of the three existing units.')
# Assessment ownership gets structural E1, no premature R1 for assessment-free rollout units.
for lang in ['de','en']:
 name=S+'chapters/05-assessment.'+lang+'.md'
 if lang=='de':
  replace(name,'| R4 | Jedes Erwerbsziel hat genau eine direkt zuständige Einheit. | Wie R1. |','| R4 / E1 | In der aufgelösten Gliederung ist die kleinste Einheit eines Ziels eindeutig; eigene Ziele und Kindeinheiten werden aus den erklärten Clustern abgeleitet. Für Inhaltsanerkennung ist die kleinste zuständige fachliche Einheit mit Prüfungen maßgeblich. | E1 ist der Strukturvertrag; die vollständige Endausbaustufe weist jedes Inhaltsziel einer Einheit mit Prüfungen zu. |')
  marker='#### Strukturbedingungen (R1, R3, R4).'
  text='''Die Regeln R1 bis R5 gelten für **Einheiten mit Prüfungen**, nicht als Behauptung einer Prüfungsdeckung jeder zunächst ohne Prüfungen erklärten Planeinheit. Solche Einheiten ordnen nur und erkennen nichts an. Die vorhandenen drei Einheiten bleiben bis F8 bis F11 im bisherigen 1.2-Vertrag geprüft; ihre `own`-Platzierungen werden durch diese Normfassung nicht umgeschrieben. R4 wird im Zielmodell zur Baumregel E1 (Abschnitt~@ref{sec:unit-progression}); die Mengenformel und die globale, revisionsgebundene Anerkennung ändern sich nicht.\n\n'''
  replace(name,'R4 macht den Vertrag eindeutig: Ein Ziel ohne oder mit mehreren direkt zuständigen Einheiten gehört zu keinem gültigen lokalen Vertrag.','R4/E1 macht den Vertrag eindeutig: Ein Inhaltsziel ohne zuständigen gültigen lokalen Prüfungsvertrag erhält keine implizite Anerkennung; es kann weiterhin ausdrücklich gemeistert werden. Eine Einheit ohne Prüfungen wird dadurch nicht zu einer Einheit mit Prüfungen.')
 else:
  replace(name,'| R4 | Every acquisition target has exactly one directly owning unit. | As R1. |','| R4 / E1 | The smallest unit of a goal is unique in the resolved structure; own goals and child units derive from declared clusters. Content recognition uses the smallest responsible subject unit with assessments. | E1 is the structural contract; full rollout assigns every content goal to a unit with assessments. |')
  marker='#### Structural conditions (R1, R3, R4).'
  text='''Rules R1 to R5 apply to **units with assessments**, not as a claim of assessment coverage for every initially assessment-free plan unit. Such units only order goals and recognize nothing. The three existing units remain checked under the previous 1.2 contract until F8 to F11; this normative edition does not rewrite their `own` placements. R4 becomes the tree rule E1 in the target model (Section~@ref{sec:unit-progression}); the set equation and global, revision-bound recognition remain unchanged.\n\n'''
  replace(name,'R4 makes the contract well defined: a goal with no or with several directly owning units belongs to no valid local contract.','R4/E1 makes the contract unambiguous: a content goal without a responsible valid local assessment contract gains no implicit recognition; it can still be mastered explicitly. This does not turn an assessment-free unit into a unit with assessments.')
 replace(name,marker,text+marker)
for lang,old,new in [
 ('de','Die Entscheidung über harte Einheitssperren und direkte Prüfungsversuche unter einem solchen optionalen Profil steht noch aus (Abschnitt~@ref{sec:learning-units}).','B9 vom 14. November 2026 verwirft harte Einheitssperren im verbindlichen Zielmodell; das frühere offene Zugangsprofil ist abgelöst (Abschnitt~@ref{sec:unit-progression}).'),
 ('en','Whether optional gated profiles later impose hard unit locks -- and how deliberate direct assessment attempts behave under them -- remains undecided (Section~@ref{sec:learning-units});','B9 of 14 November 2026 rejects hard whole-unit locks in the binding target model and retires the formerly open access profile (Section~@ref{sec:unit-progression});')
]:replace(S+'chapters/05-assessment.'+lang+'.md',old,new)

# Changes to all 26 U/P rule rows are explicit and preserve compatible old evidence.
updates={
'U01':('Erklärte Cluster tragen Lernversprechen und Ordnung; fachliche Einheiten gelten kanonisch, Planeinheiten je Land und Dauermodell über die gewählten Fächer. Einheiten mit Prüfungen ergänzen geprüften Anwendungsnachweis. Vollständige Landespläne haben nur Sekundarstufe I und II an der Wurzel, genau II after I (Z3); Einstufensichten sind Ausschnitte, die bundesweite Sicht ist kein Landesplan.','Declared clusters carry a promise and order; subject units apply canonically, plan units per Land and duration model across selected subjects. Units with assessments additionally provide reviewed application evidence. Full Land plans have only Sekundarstufe I and II at the root, exactly II after I (Z3); single-stage views are excerpts, the nationwide view is no Land plan.'),
'U02':('Motivation erklärt Nutzen vor Einzelangeboten. Nur echtes Orientierungsziel hat einen Ergebnisvertrag; eine Überschrift ist kein Ziel. Im vollständigen Landesplan liegen auch Orientierungsziele innerhalb einer Stufe. Abgeleiteter Abschluss beweist kein Motivationsgespräch.','Motivation explains use before individual offers. Only a genuine orientation goal has a result contract; a heading is no goal. In a full Land plan orientation goals also belong inside a stage. Derived completion proves no motivational conversation.'),
'U03':('Aggregat braucht keine neue Prüfung; Synthese kann Integration zusätzlich prüfen, ohne künstliche Inhaltsziele oder erneutes Bestehen der Kinder. Einheiten ohne Prüfungen ordnen nur. Im Endausbau liegt jedes Inhaltsziel in einer zuständigen fachlichen Einheit mit Prüfungen (B3, nach F8); R1 bis R5 und geprüfte Deckung gelten dort.','An aggregate needs no new assessment; synthesis may additionally test integration without artificial content goals or re-passing children. Assessment-free units only order goals. Full rollout assigns every content goal to a responsible subject unit with assessments (B3, after F8); R1 to R5 and reviewed coverage apply there.'),
'U04':('Im Zielmodell folgen Gesamtumfang, direkte Untereinheiten und eigene Atome aus dem erklärten Cluster; Zwischencluster ohne Einheit werden übersprungen. Kinder sind direkte Untereinheiten plus eigene Atome. Die bestehende rekursive Mengenformel bleibt; Gesamtumfang ist nicht leer. Die alte own/parentUnitId-Darstellung bleibt bis F9/F10 Kompatibilitätsvertrag.','In the target model total scope, direct child units, and own atoms derive from the declared cluster; intervening non-unit clusters are skipped. Children are direct child units plus own atoms. The recursive set equation remains; total scope is non-empty. The old own/parentUnitId representation remains the compatibility contract until F9/F10.'),
'U05':('R4 wird E1: Einheiten sind geschachtelt oder atomar disjunkt, die kleinste Einheit ist eindeutig. Im vollständigen Landesplan hat jedes Lernziel genau einen Platz; Eltern aggregieren ohne zweiten Erwerb. Für Anerkennung zählt nur der zuständige lokale Prüfungsvertrag. Keine Änderung von Fokus, Quellen oder Lernergebnissen.','R4 becomes E1: units are nested or atomically disjoint and the smallest unit is unique. Every learning target has exactly one place in the full Land plan; parents aggregate without a second acquisition. Recognition uses only the responsible local assessment contract. No change to focus, sources, or learner results.'),
'U06':('R1 gilt für Einheiten mit Prüfungen: Jedes eigene Inhaltsziel wird von einer eigenen Prüfung direkt oder transitiv vorausgesetzt; R2 verlangt zusätzlich echte geprüfte Aufgaben- und Rasterdeckung. Eine Einheit ohne Prüfungen ordnet nur und erkennt nichts an. Fehlende Deckung wird mit geeigneter Prüfung repariert, nie durch fachlich falschen Bedarf oder gelockertes Gate.','R1 applies to units with assessments: an own assessment directly or transitively requires each own content goal; R2 additionally requires real reviewed task and rubric coverage. An assessment-free unit only orders and recognizes nothing. Missing coverage is repaired with a suitable assessment, never fictitious demand or a relaxed gate.'),
'U07':('Einheit wird im autoritativen Eintrag der Platzierungsschicht auf einen Cluster erklärt; beliebiger contains-Cluster oder aufgeklappte Anzeige genügt nicht. Im Zielmodell ersetzen abgeleitete eigene Ziele und Untereinheiten die verfassten own-Platzierungen und Elternfelder. Fach- und Landesgliederung bleiben unterschieden.','A unit is declared by an authoritative placement-layer entry referencing a cluster; a generic contains cluster or expanded display is insufficient. In the target model derived own goals and child units replace authored own placements and parent fields. Subject and Land structures remain distinct.'),
'U08':('Vollabschluss ist T(U) vollständig in effektiver Beherrschung, rekursiv eigene Ziele plus Pflichtkinder. Keine zusätzliche Unit-Mastery und kein Rückwärtsschreiben. Abschluss des benötigten Anteils im Personal Curriculum ist kein Vollabschluss der ganzen Einheit und erweitert den Lernumfang nicht.','Full completion is all of T(U) effectively mastered, recursively own goals plus required children. No extra unit mastery or writing back. Completion of the required Personal Curriculum portion is not full-unit completion and never expands learning scope.'),
'U09':('Prüfungs- und Memorierziele bleiben explizit; Elternprüfung ersetzt keine Kindprüfung und keinen verifizierten Abruf. Synthese ist eigene Zusatzpflicht, Karten allein beweisen keine Anwendung. Umplatzierung von Abrufpflichten erzeugt keinen Kindabschluss.','Assessment and memory goals stay explicit; a parent assessment replaces neither child assessment nor verified recall. Synthesis is an additional own obligation; cards alone prove no application. Moving recall duties manufactures no child completion.'),
'U10':('Unveränderte Anerkennungsrechnung nur für eigene gewöhnliche Ziele gültiger revisionsgebundener Prüfungsverträge; offene eigene geschützte Verbraucher halten den Bedarf offen. Unabhängige Karte, Kind oder Elternsynthese nimmt gültige Anerkennung nicht zurück. Einheit ohne Prüfungsvertrag erkennt nichts an.','Unchanged recognition computation concerns only own ordinary goals of valid revision-bound assessment contracts; open own protected consumers keep demand open. An independent card, child, or parent synthesis does not revoke valid recognition. A unit without an assessment contract recognizes nothing.'),
'U11':('after wird nur zwischen Geschwistereinheiten erklärt und ordnet alle Atome der einen nach allen der anderen, ohne Bedarf. requires verbindet atomare Kompetenzen und verlangt keinen ganzen Einheitsabschluss; im Zielmodell zeigt es nie auf ein Prüfungsziel (B9). Frontier, Hülle und direkter Prüfungszugang bleiben.','after is declared only between sibling units and orders all atoms of one after all atoms of the other without demand. requires connects atomic competencies and demands no whole-unit completion; in the target model it never points to an assessment goal (B9). Frontier, closure, and direct assessment access remain.'),
'U12':('E2 gilt je Einheit einschließlich gedachter Wurzel: Der Kindgraph aus erklärtem after und projiziertem atomarem Bedarf ist azyklisch, rekursiv auch in den Kindern. Das ist die Block-Lernbarkeit; ein atomarer DAG allein genügt nicht. Rückgriffe einschließlich Vorbereitung sind Befunde und werden nicht ausgeblendet.','E2 applies per unit including the imaginary root: the child graph of declared after and projected atomic demand is acyclic, recursively within children too. This is block learnability; an atomic DAG alone is insufficient. Backflows including preparation remain findings and are never hidden.'),
'U13':('Atomare Normalform und transitive Minimalität aller verfassten requires bleiben verbindlich; vollständige aktuelle G17-Prüfung unverändert über 21 kanonische Gymnasialwurzeln. E4 für erklärte after ist eine gesonderte Pflicht in GD-U14 und nicht durch diesen bestehenden harten Nachweis belegt.','Atomic normal form and transitive minimality of all authored requires remain mandatory; complete current G17 validation still covers 21 canonical Gymnasium roots. E4 for declared after is a separate obligation in GD-U14 and is not proven by this existing hard evidence.'),
'U14':('Das frühere optionale Ganzheits-Zugangsprofil mit Open/Cleared ist durch B9 vom 14. November 2026 im Zielmodell aufgehoben. An seine Stelle tritt keine Sperre. E3/E4 sind verbindliche Ordnungsanforderungen: grenzüberschreitender Bedarf ist in der erklärten Geschwister-after-Hülle enthalten; kein after ist unter Geschwistern redundant. Je Deklarationsschicht prüfen. Diese Zielpflichten sind noch kein produktives hartes Gate.','B9 of 14 November 2026 retires the former optional whole-unit Open/Cleared access profile in the target model. No lock replaces it. E3/E4 are binding ordering requirements: cross-boundary demand is included in the declared sibling after closure; no sibling after is redundant. Check per declaration layer. These target obligations are not yet a production hard gate.'),
'U15':('Einheiten folgen fachlichen Erkenntnisübergängen; Einheiten mit Prüfungen sichern die geprüfte Anwendung der eigenen Inhaltsziele mit regulärer Bewertung und ohne zweites Ergebnis. Kein Schnitt nach Prüfungsvorrat, Quoten oder Kantendichte. Die gemeinsame Einführung fachlicher Einheiten und ihre länderweite Ganzheit (B3/B13) bleiben an F8 gebunden.','Units follow meaningful conceptual transitions; units with assessments establish reviewed application of own content goals under ordinary grading with no second result. No grouping by available assessments, quotas, or edge density. Joint introduction of subject units and their whole placement across Länder (B3/B13) remains conditional on F8.'),
'P01':('Das optionale Zeitbudgetprofil bleibt von verbindlich erklärten Planeinheiten verschieden. Ihre E1-bis-E4-Ordnung gilt ohne Budgetprofil; Kalenderintervalle allein erklären keine Einheit. Kein pauschaler Jahresabschlusszwang, keine Sperre oder neue Mastery.','The optional time-budget profile remains distinct from binding declared plan units. Their E1-to-E4 order applies without a budget profile; calendar intervals alone declare no unit. No universal yearly completion requirement, lock, or new mastery.'),
'P02':('Optionaler Kalenderplan nennt atomare Ziele, disjunkte angenommene Eintrittsbasis und eindeutige Erststufen. Im wirklichen Landesplan stammt die Ordnung aus gemeinsamer Land-/Dauermodellautorität; Kursprofile widersprechen ihr nicht. Basisannahme schreibt keine Ergebnisse und entfernt keine notwendigen Atome aus L.','An optional calendar plan declares atomic targets, a disjoint assumed entry basis, and unique first periods. Actual Land-plan order comes from shared Land/duration authority; course profiles do not contradict it. An entry assumption writes no results and removes no necessary atoms from L.'),
'P03':('Nur die hypothetische optionale Rekonstruktion endet an erklärter Eintrittsbasis. Reale Hüllenbildung und E2-Prüfung behalten vollständigen transitiven Bedarf, auch durch schon beherrschte Zwischenziele. Eine Planannahme ist keine Mastery oder amtliche Quellenzuordnung.','Only hypothetical optional reconstruction stops at a declared entry basis. Real closure and E2 checks retain full transitive demand, including through already mastered intermediate goals. A planning assumption is neither mastery nor official source assignment.'),
'P04':('Optionaler Abschlusszeuge ordnet sämtliche Stufenziele in globaler Frontier; kein Normalmodusfilter, Prüfungssprung oder vorweggenommene Anerkennung. Erklärte Planeinheiten verlangen zusätzlich Block-Lernbarkeit E2 unter after. Ein Zeuge erzeugt weder Lernergebnis noch Quellenbeleg.','An optional completion witness orders every period target in the global frontier; no normal-mode filter, assessment jump, or anticipated recognition. Declared plan units additionally require E2 block learnability under after. A witness creates neither learner results nor source evidence.'),
'P05':('Bedarf muss in der hypothetischen Eintrittsbasis oder spätestens der eigenen Stufe liegen. Bei erklärten Planeinheiten ist eine benötigte spätere Stufe ein E2-Verstoß, auch ohne optionales Zeitprofil und einschließlich Vorbereitung; Basisannahmen dürfen ihn im tatsächlichen L nicht verdecken. Graphgültigkeit zuerst.','Demand must lie in the hypothetical entry basis or no later than its own period. For declared plan units a required later stage violates E2 even without the optional time profile and including preparation; entry assumptions must not conceal it in actual L. Graph validity comes first.'),
'P06':('Der optionale endliche Frontier-Fixpunkt bleibt hypothetisch und verändert keine Lernerdaten. Für erklärte Planeinheiten prüft E2 dagegen die Kindgraphen aus atomarem Bedarf und after; der bestehende Stufenbericht ist Diagnose und optionale Null-Rückgriff-Prüfung, noch kein voll aktiviertes Landesgate.','The optional finite frontier fixed point stays hypothetical and changes no learner data. For declared plan units E2 instead checks child graphs from atomic demand and after; the existing stage report provides diagnosis and optional zero-backflow checking, not a fully activated Land gate.'),
'P07':('Zeitbehauptungen brauchen deklarierte Referenzlernende, Eintritt, Ziele, Kalender, Methode und Unsicherheit; gleiche kalibrierte Einheit, nichtnegative Arbeit/Reserve und positives Budget. Arbeit plus geschützte Reserve passt ins Budget, ohne Doppelverbuchung. Diese optionale Zeitpflicht ersetzt E2 nicht.','Time claims need declared reference learners, entry, targets, calendar, method, and uncertainty; one calibrated unit, nonnegative work/reserve, and positive budget. Work plus protected reserve fits the budget without double counting. This optional time obligation does not replace E2.'),
'P08':('Das optionale Aktivitätenmodell zählt tatsächliche Arbeit einmal. Kanonisches Atom wird fachübergreifend nicht doppelt als Erwerb gezählt; zusätzliche Anwendung kann Zeit kosten. Zusatzbedarf enthält nur notwendige Atome, nicht ganze fremde Einheiten; weight ist keine Minute.','The optional activity model counts actual work once. A canonical atom is not acquired twice across subjects; extra application may cost time. Additional demand contains only necessary atoms, not whole external units; weight is not a minute.'),
'P09':('Erfundene Rechenzahlen sind keine empirischen Curriculumdauern. Zusätzliche Fach-, Raum- und Terminbudgets getrennt erfüllen; konkrete Voraussetzungen vor Anwendung bereitstellen. Ein bestandenes Budget repariert keinen E2-Rückgriff oder fehlenden Prüfungsnachweis.','Invented example numbers are no empirical curriculum durations. Satisfy extra subject, room, and date budgets separately; provide prerequisites before application. A passing budget repairs neither E2 backflow nor missing assessment evidence.'),
'P10':('Optionale Zeitgültigkeit verlangt Struktur plus Zeit unter gebundenen Annahmen; ohne Zeitdaten nur Strukturbehauptung. Keine Garantie gleicher Lerngeschwindigkeit und kein Wirksamkeitsnachweis. Erklärte Landespläne benötigen unabhängig davon Z3 und E1 bis E4; der Weg zum harten Gate bleibt Bericht, Behebung, Sperrklinke, Nullverstöße.','Optional time validity requires structure plus time under bound assumptions; without time data only structural claims. No equal-speed guarantee or effectiveness proof. Declared Land plans separately require Z3 and E1 to E4; the path to a hard gate remains reporting, repair, ratchet, zero violations.'),
'P11':('Vollabschluss folgt eigenen Zielen und Pflichtkindern; Anteilabschluss ist kein Vollabschluss. Bloße Kalenderintervalle dürfen Einheiten schneiden; als Planeinheit erklärte Abschnitte müssen E2 erfüllen. B13-Ganzheit fachlicher Blatteinheiten wird erst nach F8 umgesetzt. after führt keine Jahres- oder Einheitssperre ein.','Full completion follows own goals and required children; portion completion is not full completion. Mere calendar intervals may cut across units; intervals declared plan units must satisfy E2. B13 whole placement of subject leaf units is implemented only after F8. after introduces no year or unit lock.'),
}
assert len(updates)==26
name=S+'rules-and-gates.json';data=load(name);oldrules={r['id']:deepcopy(r) for r in data['rules']}
for r in data['rules']:
 short=r['id'][3:]
 if short not in updates:continue
 r['rule']=dict(zip(['de','en'],updates[short]))
 # Keep exact existing evidence for the legacy footprint, never relabel it new-model acceptance.
 old=r['enforcement']
 r['enforcement']={lang:('Bestehender Kompatibilitätsstand (12.-November-Vertrag): ' if lang=='de' else 'Existing compatibility footprint (12 November contract): ')+old[lang]+(' Neue Zielpflicht: Aus dieser Prüfung folgen weder erklärte Landespläne noch vollständige E1-bis-E4- oder Laufzeitabnahme; F8 bis F13 bleiben getrennt.' if lang=='de' else ' New target obligation: this check proves neither declared Land plans nor full E1-to-E4 or runtime acceptance; F8 to F13 remain separate.') for lang in ['de','en']}
 if short in ['U05','U06']:
  r['milestone']={'de':'Zielmodell: E1 beziehungsweise R1 für Einheiten mit Prüfungen; bestehende harte 1.2-Prüfungen bleiben. Keine vollständige neue Modellabnahme.','en':'Target model: E1 or R1 for units with assessments; existing hard 1.2 checks remain. No full new-model acceptance.'}
 if short=='U13':
  r['enforcement']=old
  for lang,tail in [('de',' Die aktuelle Fassung erklärt E4 ausdrücklich separat; das bestehende harte Atom-Gate wird weder abgeschwächt noch als E4-Nachweis ausgegeben.'),('en',' This edition makes E4 explicitly separate; the existing hard atomic gate is neither weakened nor represented as E4 evidence.')]:r['enforcement'][lang]+=tail
  r['milestone']={'de':'BASIS vor M1–M7 über alle 21 kanonischen Wurzeln; E4 separat offen.','en':'BASIS before M1–M7 across all 21 canonical roots; E4 separately open.'}
 if short=='U14':
  # Retirement is documentary; live E3/E4 not represented as an optional access policy.
  r['ampel']='offen'
  r['milestone']={'de':'Verbindliches Zielmodell; kein produktives E3/E4-Gate. Früheres Zugangsprofil aufgehoben, nicht optional fortgeführt.','en':'Binding target model; no production E3/E4 gate. Former access profile retired rather than continued as optional.'}
  r['enforcement']={'de':'Historie: Das frühere Profil war unentschieden und beanspruchte keine implementierte Sperre. B9 hebt es im Zielmodell auf; historische Codepfade werden hier nicht gelöscht. E3/E4 warten auf F9/F10. Die Stufenplan-Grundlage prüft ausgewählte erklärte Stufenstrukturen; null echte Landespläne sind aktiviert.','en':'History: the former profile was undecided and claimed no implemented lock. B9 retires it in the target model; historical code paths are not deleted here. E3/E4 await F9/F10. The stage-plan foundation checks selected declared stage structures; zero real Land plans are activated.'}
 if short=='P05':
  r['ampel']='offen';r['milestone']={'de':'E2 verbindlich für erklärte Planeinheiten; optionales Zeitprofil getrennt. Bericht, Behebung, Sperrklinke, hart bei null.','en':'E2 binding for declared plan units; optional time profile separate. Report, repair, ratchet, hard at zero.'}
  r['enforcement']={'de':'Die Stufenplan-Grundlage und ihr Bericht prüfen erklärte Testpläne einschließlich transitiver Rückgriffe und Vorbereitung; --require-no-backflow ist eine ausdrücklich gewählte CLI-Prüfung. Kein echter Landesplan ist aktiviert, die produktiven Leser sind nicht vollständig umgestellt; kein neues hartes M-Gate.','en':'The stage-plan foundation and its report check declared test plans including transitive backflows and preparation; --require-no-backflow is an explicitly selected CLI check. No real Land plan is activated, production readers are not fully migrated; no new hard M gate.'}
for r in data['rules']:
 if r['id']=='GD-X06':
  for lang,tail in [('de',' Ein Land-/Dauermodellplan ist die gemeinsame Autorität; Sichten sind Ausschnitte. Eine kanonische Phasenmarke rechtfertigt nur eine gekennzeichnete vorläufige Standardzuordnung, nie Landesbeleg oder Quellenabdeckung.'),('en',' One Land/duration plan is the shared authority; views are excerpts. A canonical phase marker justifies only a labeled provisional default assignment, never Land evidence or source coverage.')]:r['rule'][lang]+=tail
 if r['id']=='GD-X13':
  for lang,tail in [('de',' Die Stelle einer prerequisiteOnly-Referenz ist keine Stufenaussage. Notwendige Atome außerhalb der geführten Ziele erhalten ihren Lernplatz am frühesten tatsächlichen Bedarf in L; bereits geführte späte Ziele werden nicht stillschweigend verschoben. Geführt in (Quelle) und steht in (Lernplatz) bleiben getrennt.'),('en',' The authored position of prerequisiteOnly asserts no stage. Necessary atoms outside carried targets receive learning placement at earliest actual need in L; already carried late targets are not silently moved. Carried in (source) and placed in (learning placement) stay distinct.')]:r['rule'][lang]+=tail
 for lang in ['de','en']:
  if r['id'] in ['GD-X06','GD-X13']:r['enforcement'][lang]+= ' '+('Stufenplan-Grundlage vorhanden; gemeinsame produktive Leserumstellung und echte Landesaktivierung noch offen.' if lang=='de' else 'Stage-plan foundation exists; shared production-reader migration and real Land activation remain open.')
# Remove now-superseded claims from preserved old enforcement prose.
for r in data['rules']:
 if r['id']=='GD-U13':
  r['enforcement']['de']=r['enforcement']['de'].replace('Die noch unentschiedene Unitrelation ist ausdrücklich keine zusätzliche Pflicht dieser Zeile und wird nicht als implementiert dargestellt.','E3/E4 gehören ausdrücklich nicht zum Nachweis dieser atomaren Pflicht und werden nicht als implementiert dargestellt.')
  r['enforcement']['en']=r['enforcement']['en'].replace('The still-undecided unit relation is explicitly not an additional obligation of this row and is not presented as implemented.','E3/E4 are explicitly outside the evidence for this atomic obligation and are not presented as implemented.')
# Compiler's fixed distribution is updated to reflect these explicit normative reclassifications.
from collections import Counter
counts=Counter(r['ampel'] for r in data['rules'])
for state in data['ampelSection']['states']:state['count']=counts[state['key']]
replace('scripts/doc_compendium/extensions/skill_graph.py', '{\"hart\": 12, \"teil\": 50, \"offen\": 55, \"opt\": 28}', '{\"hart\": 12, \"teil\": 50, \"offen\": 57, \"opt\": 26}')
data['ampelSection']['summary']={
 'de':f"**Stand 15. November 2026:** {counts['hart']} `HART` / {counts['teil']} `TEIL` / {counts['offen']} `OFFEN` / {counts['opt']} `OPT/DOK`. GD-U14 führt jetzt die offenen E3/E4-Zielpflichten statt des aufgehobenen Zugangsprofils; GD-P05 enthält die verbindliche E2-Pflicht für erklärte Planeinheiten. Kein neuer harter Nachweis, keine aktivierten Landespläne.",
 'en':f"**Status 15 November 2026:** {counts['hart']} `HARD` / {counts['teil']} `PARTIAL` / {counts['offen']} `OPEN` / {counts['opt']} `OPT/DOC`. GD-U14 now carries open E3/E4 target obligations instead of the retired access profile; GD-P05 includes binding E2 for declared plan units. No new hard evidence, no activated Land plans."
}
dump(name,data)
# Machine-readable review matrix: each of the 26 rows has the complete old/new fields.
matrix=[{'id':'GD-'+key,'old':oldrules['GD-'+key],'new':next(r for r in data['rules'] if r['id']=='GD-'+key),'decisionBasis':'B1–B16; E1–E4; Z1–Z10; handover 2.4 M1–M8','deliveryScope':'F7 normative source candidate; no runtime or Land activation'} for key in updates]
(BASE/'rule-decision-matrix.json').write_text(json.dumps(matrix,ensure_ascii=False,indent=2)+'\n')
# Shared glossary and compendium glossary use source-native authored files only.
terms=[
 ('Planeinheit','plan unit','Erklärte Einheit im gemeinsamen Plan eines Landes und Dauermodells über die gewählten Fächer, etwa Stufe, Jahrgang oder Phase; ordnet Lernen und ist keine neue Kompetenz.','Declared unit in the shared plan of one Land and duration model across selected subjects, such as stage, year, or phase; orders learning and creates no new competency.'),
 ('Fachliche Einheit','subject unit','Erklärter Cluster der kanonischen Fachlandschaft mit Lernversprechen; gilt in allen Ländern. Eine Einheit mit Prüfungen belegt zusätzlich die selbstständige Anwendung ihrer eigenen Inhaltsziele.','Declared cluster in the canonical subject landscape with a learning promise; applies across all Länder. A unit with assessments additionally demonstrates independent application of own content goals.'),
 ('after','after','Erklärte Reihenfolge zwischen Geschwistereinheiten: die vorausgehende Einheit ist im vorgesehenen Lernfluss vollständig abgeschlossen, bevor die andere beginnt. Vererbt Ordnung, keinen Bedarf; keine Sperre, Mastery oder Umfangserweiterung.','Declared order between sibling units: the preceding unit is fully complete in the intended flow before the other starts. Inherits order, not demand; no lock, mastery, or scope expansion.'),
 ('Rückgriff','backflow','Ein Ziel einer früheren Planeinheit braucht ein Ziel einer späteren, direkt oder transitiv. Das ist ein E2-Befund, auch bei Vorbereitung; Darstellung und Fokus dürfen ihn nicht verdecken.','A goal in an earlier plan unit requires a goal in a later one, directly or transitively. This is an E2 finding, including preparation; display and focus must not hide it.'),
 ('Vorbereitung','preparation','Notwendiges Atom außerhalb der geführten Ausgangsziele erhält im geschlossenen persönlichen Umfang einen abgeleiteten Lernplatz am frühesten tatsächlichen Bedarf. Begründete frühere Vorbereitung eines geführten Ziels bleibt ausdrücklich gekennzeichnet; die Quellenzuordnung bleibt erhalten.','A necessary atom outside the carried seed targets receives a derived learning placement at its earliest actual need in the closed personal scope. Justified earlier preparation of a carried target stays explicitly labeled; source assignment is preserved.'),
 ('Zusatzbedarf','additional demand','Notwendige Ziele außerhalb der gewählten fachlichen Ausgangsziele. Nur diese Atome werden ergänzt, unabhängig von Mastery; Anzeige nach Einheiten fügt keine ganze fremde Einheit hinzu.','Necessary goals outside the selected subject seed targets. Only these atoms are added, independently of mastery; displaying them by unit adds no entire external unit.'),
 ('geführt in / steht in','carried in / placed in','Geführt in bezeichnet die amtlich belegte curriculare Zuordnung; steht in den didaktischen Lernplatz. Frühere Vorbereitung oder kanonischer Standard erzeugt keinen Landesbeleg und schreibt kein Lernergebnis.','Carried in means officially evidenced curricular assignment; placed in means didactic learning placement. Earlier preparation or a canonical default creates neither Land evidence nor learner results.'),
 ('Standardzuordnung','default assignment','Ausdrücklich vorläufige didaktische Einordnung aus einer kanonischen Marke wie dimensionTags.phase, wenn Landesbeleg fehlt. Ersetzt weder Quellenbeleg noch Abdeckungsprüfung und überschreibt keine maßgebliche Sicht.','Explicitly provisional didactic assignment from a canonical marker such as dimensionTags.phase when Land evidence is absent. Replaces neither source evidence nor coverage checking and does not override an authoritative view.'),
 ('Prüfungslücke','assessment gap','Ein Inhaltsziel ohne geeignete geprüfte Aufgaben- und Rasterdeckung bleibt ein nicht bestandener Befund. Reparatur liefert echte Prüfung und Review, niemals fiktive Voraussetzungen oder gelockerte Qualitätsgates.','A content goal without suitable reviewed task and rubric coverage remains a failing finding. Repair supplies a real assessment and review, never fictitious prerequisites or relaxed quality gates.'),
]
name=S+'glossary-and-symbols.json';data=load(name)
for entry in data['glossary']:
 de=entry['term']['de']
 if de.startswith('verfasst, abgeleitet'):
  entry['meaning']={'de':'Verfasst sind gespeicherte Zielkanten und erklärte Einheiten mit after in ihrer eigenen Schicht. Hüllen, eigene Zielmengen und Lernplätze notwendiger Vorbereitung werden daraus abgeleitet.','en':'Authored data comprises stored goal edges and declared units with after in their own layer. Closures, own goal sets, and necessary-preparation placements derive from them.'}
 if de.startswith('Einheitsvoraussetzung, Einheitssperre'):
  entry['term']={'de':'Einheitssperre (aufgehobenes Zugangsprofil)','en':'whole-unit lock (retired access profile)'}
  entry['meaning']={'de':'Das früher offene Ganzheits-Zugangsprofil ist durch B9 vom 14. November 2026 im Zielmodell aufgehoben. after verlangt keine technische Sperre und verleiht keine Beherrschung; historische Codepfade werden damit nicht als entfernt behauptet.','en':'B9 of 14 November 2026 retires the formerly open whole-unit access profile in the target model. after imposes no technical lock and grants no mastery; this does not claim historical code paths have been removed.'}
 if de.startswith('Programmeinheit, Platzierung'):
  entry['meaning']={'de':'Organisatorische Struktur und Zuordnung stabiler Ziele. Bestehende fachliche learningUnit-Einträge nutzen own-Platzierungen; das Zielmodell leitet eigene Ziele und Kinder aus erklärten Clustern ab. Planeinheiten sind ausdrücklich erklärte Ordnungsabschnitte.','en':'Organizational structure and assignment of stable goals. Existing subject learningUnit entries use own placements; the target model derives own goals and children from declared clusters. Plan units are explicitly declared ordering sections.'}
 if de.startswith('Gültigkeitsregeln R1'):
  entry['meaning']={'de':'Bedingungen für Einheiten mit Prüfungen: eigener Prüfungspfad (R1), geprüfte Deckung (R2), Deckung nur im Bedarf (R3), eindeutige kleinste zuständige Einheit (R4/E1), revisionsgebundener Vertrag ohne nachträgliche Ergebniserweiterung (R5). Einheiten ohne Prüfungen erkennen nichts an.','en':'Conditions for units with assessments: own assessment path (R1), reviewed coverage (R2), coverage only within demand (R3), a unique smallest responsible unit (R4/E1), revision-bound contract with no retroactive result expansion (R5). Assessment-free units recognize nothing.'}
for de,en,md,me in terms:data['glossary'].append({'term':{'de':de,'en':en},'meaning':{'de':md,'en':me}})
dump(name,data)
for lang in ['de','en']:
 name='docs/concept/glossary/source/chapters/01-curricula-and-graph.'+lang+'.md'
 text='\n\n'
 for de,en,md,me in terms:
  text+='### '+(de if lang=='de' else en.capitalize())+' {unnumbered=true}\n\n'
  text+=('*EN: '+en+'*' if lang=='de' else '*DE: '+de+'*')+' — '+('siehe' if lang=='de' else 'see')+' [Einheitenkonzept](repo:docs/concept/skill-graph/learning-unit-wiring-concept-2026-11-14.md)\n\n'
  text+=(md if lang=='de' else me)+'\n\n'
 write(name,read(name).rstrip()+text)

# Dated status supersedes old implementation prose without rewriting its immutable evidence.
name=S+'implementation-status.json';data=load(name)
status={
'de':'**F7-Zielnorm, 15. November 2026:** Die Kapitel bilden jetzt B1 bis B16 und die Entscheidungen M1 bis M8 ab: erklärte Cluster und Planeinheiten, after als Ordnung ohne Bedarf, E1 bis E4, Z3, Quellenzuordnung gegenüber Lernplatz und früheste notwendige Vorbereitung. Der alte Stand vom 13. November im folgenden Absatz bleibt ein datierter historischer Audit und belegt keine neue Umsetzung. Die Stufenplan-Grundlage unter contracts/curriculum-package/v1.3/ ist ein Entwicklungsvertrag; null echte Landespläne sind aktiviert. Vorhandene Tests und Berichte sind automatisierte Strukturbelege, keine unabhängigen Inhaltsreviews, Aufgaben für Lernende oder gemessene Rückgriffreduktion. Produktive Leser, fachliche Clusterumstellung und Anerkennung bleiben bis F8 bis F13 getrennte Lieferungen. Kein neuer harter Gate-Erfolg, keine Veröffentlichung und keine main-Abnahme wird aus diesem Normkandidaten abgeleitet. ',
'en':'**F7 target specification, 15 November 2026:** The chapters now reflect B1 to B16 and decisions M1 to M8: declared clusters and plan units, after as order without demand, E1 to E4, Z3, source assignment versus learning placement, and earliest necessary preparation. The following 13 November paragraph remains a dated historical audit and evidences no new implementation. The stage-plan foundation under contracts/curriculum-package/v1.3/ is a development contract; zero real Land plans are activated. Existing tests and reports are automated structural evidence, not independent content reviews, learner assessment tasks, or measured backflow reduction. Production readers, subject-cluster migration, and recognition remain separate deliveries until F8 to F13. This normative candidate claims no new hard-gate pass, publication, or main acceptance. '
}
for lang in ['de','en']:data['stand']['body'][lang]=status[lang]+data['stand']['body'][lang]
data['poDecisions'].append({'de':'**14./15. November 2026:** B1 bis B16 und die delegierten Stufenentscheidungen M1 bis M8 sind die verbindliche Zielnorm; sie lösen das offene Einheits-Zugangsprofil ab. after ordnet ohne Bedarf und ohne Mastery. Ein gemeinsamer Landes-/Dauermodellplan, zwei Wurzelstufen, abgeleitete Ausschnitte, erhaltene Quellenzuordnung und frühester Vorbereitungsbedarf sind verbindlich. Neue fachliche Einheiten, Deckungsänderungen und produktive Leser benötigen weiterhin F8 bis F13 und ihre eigenen Nachweise.','en':'**14/15 November 2026:** B1 to B16 and delegated stage decisions M1 to M8 form the binding target specification; they supersede the open whole-unit access profile. after orders without demand or mastery. A shared Land/duration plan, two root stages, derived excerpts, preserved source assignment, and earliest preparation demand are binding. New subject units, coverage changes, and production readers still require F8 to F13 and their own evidence.'})
data['boundaryTable'].append({'area':{'de':'Erklärte Planeinheiten und after (Zielnorm vom 15. November)','en':'Declared plan units and after (15 November target specification)'},'spec':{'de':'Gemeinsame Land-/Dauermodellautorität, Z3, E1 bis E4 und frühester tatsächlicher Vorbereitungsbedarf; keine Sperre und keine Mastery aus Ordnung.','en':'Shared Land/duration authority, Z3, E1 to E4, and earliest actual preparation demand; no locks or mastery from order.'},'repoStatus':{'de':'Stufenplan-Grundlage und automatisierte Testfälle vorhanden; null echte Landespläne aktiviert. Der alte 1.2-Validator prüft die drei bisherigen fachlichen Einheiten, nicht die vollständige Zielnorm. Gemeinsame produktive Leser, Paketexport und Lernfluss F13 stehen aus.','en':'Stage-plan foundation and automated cases exist; zero real Land plans activated. The old 1.2 validator checks the three existing subject units, not the full target specification. Shared production readers, package export, and F13 learning flow remain pending.'}})
for x in data['boundaryTable']:
 if x['area']['en'].startswith('Recursive learning units'):
  for lang in ['de','en']:x['repoStatus'][lang]=('Kompatibilitätsstand des 12.-November-Vertrags; das Zielmodell der erklärten Cluster ersetzt ihn erst mit F9/F10. ' if lang=='de' else 'Compatibility footprint of the 12 November contract; the declared-cluster target model replaces it only with F9/F10. ')+x['repoStatus'][lang]
for x in data['sourceMappingTable']:
 if x['part']['en'].startswith('Recursive learning units'):
  x['role']={'de':'Zielnorm erklärter fachlicher Einheiten und Planeinheiten, E1 bis E4, abgeleiteter Abschluss und erhaltene lokale Anerkennungsrechnung; bestehende 1.2-Darstellung ausdrücklich als Kompatibilität, Zugangsprofil aufgehoben.','en':'Target specification of declared subject and plan units, E1 to E4, derived completion and preserved local recognition computation; existing 1.2 representation explicitly labeled compatibility, access profile retired.'}
  for lang in ['de','en']:x['sources'][lang]+=' [Einheitenkonzept](repo:docs/concept/skill-graph/learning-unit-wiring-concept-2026-11-14.md); [Stufenplan-Grundlage](repo:contracts/curriculum-package/v1.3/README.md).'
dump(name,data)

# Focused AGENTS mirror. Root should inspect this hunk against concurrent edits.
name='AGENTS.md'
replace(name,'Until the follow-up work in section 10 of the document is done, the tools\n  enforce the unit contract of 12 November and Graph Definition §11 to §13\n  describe the implemented state.','Until the follow-up work in section 10 of the document is done, the tools\n  enforce the unit contract of 12 November. Graph Definition §11 to §13\n  distinguish the binding target model from that implemented compatibility\n  contract; target wording does not assert completed migration.')
marker='\nThis is concept documentation plus a static authoring contract and validator,'
addition='''\n- **Stage authority and normative precedence (15 November 2026).** The F7\n  bilingual Graph Definition source states the binding target model and\n  labels the previous 1.2 ownership representation as compatibility. One\n  shared plan per Land and duration model governs all selected subjects;\n  course profiles may select contributions but cannot contradict the stage\n  of a stable goal. Its full root has only Sekundarstufe I and II, exactly\n  II `after` I; orientation, practice and assessment goals belong inside\n  these stages. A single-stage view is a derived excerpt; the nationwide\n  canonical structure is no Land plan. `Geführt in` means source-evidenced\n  curricular assignment; `steht in` means learning placement. A canonical\n  phase may justify an explicitly provisional default, never official\n  coverage. A support reference's authored position asserts no stage.\n  Necessary atoms outside the carried seed targets receive one derived\n  placement at their earliest actual need in the closed personal scope,\n  independently of mastery. Already carried late targets are not silently\n  moved; their backflows remain findings until explicitly repaired.\n  E1 to E4 apply per declaration layer and to derived preparation. R4 is\n  E1; R1 to R5 govern units with assessments. Assessment-free units only\n  order and recognize nothing. `GD-U14`'s formerly open access profile is\n  retired in the target model, without claiming historical code removal.\n  The stage-plan foundation under `contracts/curriculum-package/v1.3/` is\n  not a published package version. Zero real Land plans are activated;\n  shared production-reader migration remains open. Subject-unit migration,\n  B3/B13 acceptance, packages, recognition and learning-mode runtime require\n  F8 to F13 and their own evidence. Existing atomic G17 across the complete\n  21-root catalog, immutable V9 evidence, quality floors, focus rules,\n  learner results and recognition semantics remain unchanged.\n'''
replace(name,marker,'\n'+addition+marker)


# Remove stale active access-profile claims from the introductory and shared glossary sources.
for lang in ['de','en']:
 name=S+'chapters/00-frontmatter.'+lang+'.md'
 if lang=='de':
  replace(name,'Stand **11. November 2026**','Stand **15. November 2026**')
  # The table is concise; preserve all other status distinctions.
  old='Zeit- und Budgetplanung sowie bedingte Zugänge zu Lerneinheiten; harte Sperren und der direkte Prüfungszugang sind dafür noch nicht entschieden.'
  if old in read(name):replace(name,old,'Kalender- und Zeitbudgetplanung bleiben optional. Erklärte Planeinheiten unterliegen E1 bis E4; ein Ganzheits-Zugangsprofil entfällt durch B9.')
 else:
  replace(name,'as of **11 November 2026**','as of **15 November 2026**')
  replace(name,'Calendar and workload budgeting plus conditional entry to learning units; hard technical locks and direct assessment entry remain undecided there.','Calendar and workload budgeting remain optional. Declared plan units follow E1 to E4; B9 retires the whole-unit access profile.')
 name='docs/concept/glossary/source/chapters/04-quality-and-distinctions.'+lang+'.md'
 if lang=='de':
  old='ein technisches Ganz-Einheiten-Gate erfordert eine separate Policy.'
  if old in read(name):replace(name,old,'B9 verwirft technische Einheitssperren im Zielmodell; after ordnet ohne Bedarf oder Mastery.')
 else:replace(name,'a technical whole-unit gate requires a separate policy.','B9 rejects technical whole-unit locks in the target model; after orders without demand or mastery.')
# Keep core's two goal-edge kinds explicit without excluding authored unit-layer order.
for lang in ['de','en']:
 name=S+'chapters/01-core.'+lang+'.md'
 if lang=='de':replace(name,'nur sie werden von Autorinnen und Autoren gespeichert.','nur diese beiden werden im Zielkern gespeichert. Die Einheitenschicht erklärt daneben after in ihrem eigenen Vertrag.')
 else:
  old='only they are stored by curriculum authors.'
  if old in read(name):replace(name,old,'only these two relations are persisted in the goal core. The unit layer additionally declares after in its own contract.')
 name=S+'chapters/02-context.'+lang+'.md'
 if lang=='de':replace(name,'Die Relation `own` hält kontextfrei fest,','Im bestehenden Kompatibilitätsvertrag 1.2 hält die Relation `own` kontextfrei fest,')
 else:
  old='Relation `own` records'
  if old in read(name):replace(name,old,'In the existing 1.2 compatibility contract, relation `own` records')
name=S+'spec-manifest.json';data=load(name);data['documentDate']='2026-11-15'
from datetime import datetime,timezone
data['sourceDateEpoch']=str(int(datetime(2026,11,15,tzinfo=timezone.utc).timestamp()))
for wp in data['webPages']:
 if wp['id']=='learning-unit-progression':wp['titles']['en']='Unit Ordering and Rules E1 to E4 (§11.5)';wp['titles']['de']='Einheitsordnung und Regeln E1 bis E4 (§11.5)'
dump(name,data)
# Refresh state explanatory notes with the two explicitly reclassified target rows.
name=S+'rules-and-gates.json';data=load(name)
for state in data['ampelSection']['states']:
 if state['key']=='offen':
  state['ruleIdsNote']['de']+=' E3/E4 nach Ablösung des Zugangsprofils (GD-U14) und E2 für erklärte Planeinheiten (GD-P05) kommen als offene Zielpflichten hinzu; jetzt 57 Gruppen.'
  state['ruleIdsNote']['en']+=' E3/E4 after retirement of the access profile (GD-U14) and E2 for declared plan units (GD-P05) add open target obligations; now 57 groups.'
  state['ruleIdsNote']['de']=state['ruleIdsNote']['de'].replace('(**55 Gruppen**)','(**57 Gruppen**)')
  state['ruleIdsNote']['en']=state['ruleIdsNote']['en'].replace('(**55 groups**)','(**57 groups**)')
 if state['key']=='opt':
  state['ruleIdsNote']={'de':'Optionale Erwerbs- und Zeitplanung (GD-P01–P04, P06–P11, X33–X35, X37) sowie Anhang-, Modell- und PDF-Regeln (GD-D01–D12): 26 Gruppen. Die E2-Pflicht GD-P05 und E3/E4 GD-U14 sind verbindlich offen. Das frühere Zugangsprofil ist aufgehoben, nicht optional fortgeführt.','en':'Optional acquisition and time planning (GD-P01–P04, P06–P11, X33–X35, X37) plus appendix, model, and PDF rules (GD-D01–D12): 26 groups. E2 in GD-P05 and E3/E4 in GD-U14 are binding and open. The former access profile is retired rather than continued as optional.'}
dump(name,data)
for lang in ['de','en']:
 name=S+'chapters/01-core.'+lang+'.md'
 if lang=='de':replace(name,'**Aktueller Kandidat:**','**Historischer Auditstand, 13. November 2026:**')
 else:replace(name,'**Current candidate:**','**Historical audit state, 13 November 2026:**')

# Section titles follow the actual new headings; rule identities and references remain stable.
name=S+'rules-and-gates.json';data=load(name)
import re
heading_maps={lang:{m.group(2):m.group(1) for m in re.finditer(r'^#{2,4} (.*?) \{#(sec:[^ }]+).*?\}$',read(S+'chapters/03-learning-units.'+lang+'.md'),re.M)} for lang in ['de','en']}
for row in data['rules']:
 if row['part']=='U':
  for lang in ['de','en']:
   if row['sectionId'] in heading_maps[lang]:row['sectionTitle'][lang]=heading_maps[lang][row['sectionId']]
dump(name,data)
# Retire the same access-profile wording in adjacent rule references and overview prose.
name=S+'rules-and-gates.json';data=load(name)
for row in data['rules']:
 if row['id']=='GD-X30':row['enforcement']={'de':'Keine M7-Zusage. B9 hebt das frühere Ganzheits-Zugangsprofil im Zielmodell auf; direkter Prüfungszugang bleibt, ohne Behauptung einer Codeumstellung.','en':'No M7 claim. B9 retires the former whole-unit access profile in the target model; direct assessment access remains, without a claim of code migration.'}
 if row['id']=='GD-U11':row['milestone']={'de':'Verbindliches Ordnungsmodell; kein neues hartes Gate, keine Einheitssperre.','en':'Binding ordering model; no new hard gate or whole-unit lock.'}
 if row['id']=='GD-U13':row['enforcement']['en']=row['enforcement']['en'].replace('The undecided unit relation is explicitly not an additional obligation of this row and is not represented as implemented.','E3/E4 are explicitly outside the evidence for this atomic obligation and are not represented as implemented.')
 if row['id']=='GD-P11':
  row['enforcement']['de']+=' Das historische Zugangsprofil ist inzwischen durch B9 aufgehoben.'
  row['enforcement']['en']+=' B9 has since retired the historical access profile.'
 if row['id']=='GD-A15':
  row['rule']['de']=row['rule']['de'].replace('Optionale Ganzheitssperre unentschieden, Unitkonzept schafft weder Sperre noch Umgehung.','B9 hebt das frühere Ganzheits-Zugangsprofil im Zielmodell auf; after schafft weder Sperre noch Umgehung.')
  row['rule']['en']=row['rule']['en'].replace('Optional unit-wide locking stays undecided; the learning-unit concept creates neither a lock nor an auth bypass.','B9 retires the former whole-unit access profile in the target model; after creates neither a lock nor an auth bypass.')
 if row['id']=='GD-D03':
  row['enforcement']['de']=row['enforcement']['de'].replace('offene Unit-Zugangspolitik','durch B9 aufgehobene frühere Unit-Zugangspolitik')
  row['enforcement']['en']=row['enforcement']['en'].replace('undecided unit-access policy','the former unit-access policy retired by B9')
replacements={
 'ausdrücklich unentschiedene Sperrpolitik oder ':'',
 'explicitly undecided lock policy, or ':'',
 'undecided policy, or document checks':'document checks',
 'optionale Zeit-/Budgetplanung und offene Unit-Zugänge (`OPT/DOK`)':'optionale Zeit-/Budgetplanung (`OPT/DOK`); E2/E3/E4 für erklärte Einheiten sind verbindlich offen',
 'optional time/budget planning and undecided unit access (`OPT/DOC`)':'optional time/budget planning (`OPT/DOC`); E2/E3/E4 for declared units are binding and open',
 'Optionales Planungsprofil bzw. noch unentschiedene Ganzheitszugangspolitik.':'Optionales Zeit-/Budgetprofil; das frühere Ganzheits-Zugangsprofil ist durch B9 aufgehoben.',
 'Optional planning profile or still-undecided holistic unit-access policy.':'Optional time/budget profile; B9 retires the former whole-unit access profile.',
}
def revise(value):
 if isinstance(value,str):
  for old,new in replacements.items():value=value.replace(old,new)
  return value
 if isinstance(value,list):return [revise(v) for v in value]
 if isinstance(value,dict):return {k:revise(v) for k,v in value.items()}
 return value
data=revise(data);dump(name,data)
name=S+'implementation-status.json';impl=load(name)
for row in impl['boundaryTable']:
 if row['area']['en'].startswith('Recursive learning units'):
  row['spec']={'de':'Erklärte Cluster mit eindeutigen eigenen Zielen und Untereinheiten (E1/R4), abgeleitetem Abschluss, after-Ordnung (E2 bis E4) und getrenntem optionalem Zeitbudget. B9 hebt das frühere Ganzheits-Zugangsprofil auf.','en':'Declared clusters with unique own goals and child units (E1/R4), derived completion, after ordering (E2 to E4), and a separate optional time budget. B9 retires the former whole-unit access profile.'}
dump(name,impl)

# Refresh new-side matrix after heading refinements.
for item in matrix:item['new']=next(r for r in data['rules'] if r['id']==item['id'])
(BASE/'rule-decision-matrix.json').write_text(json.dumps(matrix,ensure_ascii=False,indent=2)+'\n')

# Adjacent authored contracts must not retain the superseded access question.
for lang in ['de','en']:
 name='docs/concept/skill-graph/architecture-source/chapters/12-learning-unit-design-and-examples.'+lang+'.md'
 if lang=='de':
  replace(name,'die gesonderte [Entscheidungsfrage zu Einheitsfolge und Zugang]','die verbindlichen [Ordnungsregeln E1 bis E4]')
  replace(name,'Das didaktische Prinzip steht damit fest. Ob daraus technische Startsperren folgen und wie sich bewusste Direktprüfungen unter einer solchen Sperre verhalten, bleibt eine gesonderte, noch offene Richtlinienfrage; siehe [Einheitsfolge und Zugang](repo:docs/concept/skill-graph/learning-unit-progression.md).','B9 vom 14. November 2026 verwirft technische Einheitssperren im verbindlichen Zielmodell. after erklärt die vorgesehene Reihenfolge ohne Bedarf, Mastery oder geänderte Frontier; siehe [Einheitsordnung](repo:docs/concept/skill-graph/learning-unit-progression.md).')
  add='**Normergänzung vom 15. November 2026:** Die Beispiele bleiben Kandidaten des früheren fachlichen Zuschnitts. Eine neue Einheit wird als Cluster erklärt; eigene Ziele und Kinder werden daraus abgeleitet. R1 bis R5 gelten für Einheiten mit Prüfungen; Einheiten ohne Prüfungen ordnen nur und erkennen nichts an. Die Umstellung bestehender Beispiele und der länderübergreifende Ganzheitstest B13 folgen erst nach der F8-Messung. Neue Grenzen oder Prüfungen brauchen eigene unabhängige Reviews.\n\n'
 else:
  replace(name,'the separate [progression and access decision]','the binding [ordering rules E1 to E4]')
  replace(name,'The didactic principle is thereby fixed. Whether technical start locks follow from it, and how deliberate direct assessment attempts behave under such a lock, remains a separate, undecided policy; see [progression and access](repo:docs/concept/skill-graph/learning-unit-progression.md).','B9 of 14 November 2026 rejects technical whole-unit locks in the binding target model. after declares intended order without demand, mastery, or frontier changes; see [unit ordering](repo:docs/concept/skill-graph/learning-unit-progression.md).')
  add='**Normative addition of 15 November 2026:** The examples remain candidates of the earlier subject-matter grouping. A new unit is declared as a cluster; own goals and children derive from it. R1 to R5 apply to units with assessments; assessment-free units only order and recognize nothing. Migration of existing examples and the cross-Land B13 whole-placement test follow only after F8 measurement. New boundaries or assessments need their own independent reviews.\n\n'
 marker='### '+('Tragfähige Grundlage schaffen' if lang=='de' else 'Establish a Secure Foundation')
 if marker not in read(name):
  # Keep the exact existing heading; no heading or anchor changes.
  marker=next(line for line in read(name).splitlines() if line.startswith('### '))
 replace(name,marker,add+marker)
 name='docs/concept/skill-graph/architecture-source/chapters/03-view-projection.'+lang+'.md'
 marker=next(line for line in read(name).splitlines() if line.startswith('### '))
 if lang=='de':add="""**Verbindliches Zielmodell, 15. November 2026:** Ein gemeinsamer Plan je Land und Dauermodell ist die Platzierungsautorität über die gewählten Fächer; Kursprofile wählen Anteile, nicht widersprechende Stufen desselben Ziels. Sichten einer Stufe sind daraus abgeleitete Ausschnitte. Die vollständige Wurzel trägt nur Sekundarstufe I und II, genau II after I; Orientierung, Übung und Prüfungen liegen innerhalb der Stufen. Die bundesweite Sicht ist kein Landesplan.\n\nGeführt in bezeichnet die belegte Quellenzuordnung, steht in den didaktischen Lernplatz. Eine kanonische Marke begründet höchstens eine gekennzeichnete vorläufige Standardzuordnung. Die Stelle einer prerequisiteOnly-Referenz behauptet keine Stufe. Notwendige Atome außerhalb der geführten Ziele erhalten ihren Lernplatz am frühesten tatsächlichen Bedarf im geschlossenen persönlichen Umfang; geführte späte Ziele werden nicht stillschweigend verschoben. Begründete frühere Vorbereitung erhält die ursprüngliche Quellenzuordnung. Quellenprüfungen und Routen prüfen ihre jeweils eigenen Aussagen.\n\nDie [Stufenplan-Grundlage](repo:contracts/curriculum-package/v1.3/README.md) enthält gemeinsame Autoritäten, Ausschnitte und daraus erzeugte Kompatibilitätssichten. Sie aktiviert null echte Landespläne; die gemeinsame produktive Leserumstellung steht aus. Das Verzeichnis v1.3 ist keine veröffentlichte Paketversion. Die nachstehenden bestehenden Feldverträge sind Kompatibilitätsstand, kein Nachweis einer abgeschlossenen Cluster-, Paket- oder Laufzeitmigration.\n\n"""
 else:add="""**Binding target model, 15 November 2026:** One shared plan per Land and duration model is the placement authority across selected subjects; course profiles select contributions rather than contradictory stages for the same goal. Single-stage views are derived excerpts. The full root carries only Sekundarstufe I and II, exactly II after I; orientation, practice, and assessments belong inside the stages. The nationwide view is no Land plan.\n\nCarried in means evidenced source assignment; placed in means didactic learning placement. A canonical marker justifies at most a labeled provisional default assignment. A prerequisiteOnly reference's position asserts no stage. Necessary atoms outside carried targets receive placement at earliest actual need in the closed personal scope; carried late targets are not silently moved. Justified earlier preparation preserves original source assignment. Source checks and routes inspect their own distinct claims.\n\nThe [stage-plan foundation](repo:contracts/curriculum-package/v1.3/README.md) contains shared authorities, excerpts, and generated compatibility views. It activates zero real Land plans; shared production-reader migration remains pending. The v1.3 directory is no published package version. Existing field contracts below are a compatibility footprint, not evidence of completed cluster, package, or runtime migration.\n\n"""
 replace(name,marker,add+marker)

for lang in ['de','en']:
 name='docs/concept/skill-graph/architecture-source/chapters/03-view-projection.'+lang+'.md'
 if lang=='de':
  replace(name,'Lerneinheiten werden in der Platzierungsschicht ihrer Skill-Landschaft deklariert (Entscheidung des Product Owners vom 12. November 2026):','Im bestehenden Kompatibilitätsvertrag werden Lerneinheiten in der Platzierungsschicht ihrer Skill-Landschaft deklariert (Entscheidung vom 12. November 2026):')
  replace(name,'bleibt eine separate explizite Kurspolitik.','folgt im Zielmodell den erklärten after und E1 bis E4; daraus entsteht keine Zugangssperre.')
 else:
  replace(name,'Learning units are declared in the placement layer of their skill landscape (Product Owner decision of 12 November 2026):','In the existing compatibility contract, learning units are declared in the placement layer of their skill landscape (decision of 12 November 2026):')
  replace(name,'remains a separate explicit course policy.','follows declared after and E1 to E4 in the target model; it creates no access lock.')
 name=S+'chapters/00-frontmatter.'+lang+'.md'
 if lang=='de':replace(name,'„Optional“ kennzeichnet ein Zusatzprofil, „offen“ oder „noch nicht entschieden“ eine bewusst unentschiedene Frage.','„Optional“ kennzeichnet ein Zusatzprofil. „Noch nicht entschieden“ kennzeichnet eine unentschiedene Frage; die Ampel OFFEN bezeichnet dagegen eine verbindliche Pflicht ohne belegtes hartes Gate.')
 else:replace(name,'“Optional” marks an additional profile; “open” or “not yet decided” marks a deliberately unresolved question.','“Optional” marks an additional profile. “Not yet decided” marks an unresolved question; the OPEN traffic light instead denotes a binding obligation without an evidenced hard gate.')

"""This block is embedded in author_candidate.py; kept here for readable review mapping."""
# R1: E3 owns an atom exception at the smallest common unit; E4 uses declared after only.
name=S+'rules-and-gates.json';data=load(name)
for row in data['rules']:
 if row['id']=='GD-U14':
  row['rule']={
   'de':'B9 vom 14. November 2026 hebt das frühere Open/Cleared-Zugangsprofil im Zielmodell auf; keine Sperre ersetzt es. E3: Braucht a das Ziel b, betrachtet man die kleinste gemeinsame Einheit oder gedachte Wurzel. Liegen beide dort in verschiedenen Kind-Einheiten, folgt die Reihenfolge aus der dort erklärten Geschwister-after-Hülle. Ist mindestens ein Kind ein eigenes Atom, ordnet der Bedarf selbst; ein after zwischen Atom und Einheit wird nicht erklärt. E4: Kein erklärtes Geschwister-after folgt aus den übrigen dort erklärten after. Je Deklarationsschicht prüfen; die atomare requires-Minimalität bleibt separat. E3/E4 sind verbindlich, aber kein produktives hartes Gate.',
   'en':'B9 of 14 November 2026 retires the former Open/Cleared access profile in the target model; no lock replaces it. E3: If a requires b, inspect their smallest common unit or imaginary root. If both lie in different child units there, their order follows from that declared sibling after closure. If at least one child is an own atom, demand itself orders it; no after between an atom and a unit is declared. E4: No declared sibling after follows from the other after declarations there. Check per declaration layer; atomic requires minimality stays separate. E3/E4 are binding, but no production hard gate.'}
 # R2: Document rule must agree with its enforcement and binding B9.
 if row['id']=='GD-D03':
  row['rule']['de']=row['rule']['de'].replace('Ganzheitssperren und Examzugriff darunter sind offen, Zeitplanung bleibt gesondert.','B9 hebt das frühere Ganzheits-Zugangsprofil im Zielmodell auf. Direkter Prüfungszugang bleibt unter seinem Aufgaben-, Authentifizierungs-, Scope- und Sitzungsvertrag erhalten; keine Codeumstellung wird hier behauptet. Zeitplanung bleibt gesondert.')
  row['rule']['en']=row['rule']['en'].replace('unit-wide locks and direct exam access under them stay open, and time planning stays separate.','B9 retires the former whole-unit access profile in the target model. Direct assessment access remains under its task, authentication, scope, and session contract; no code migration is claimed here. Time planning stays separate.')
 # C3: U05 is E1/R4; R1 belongs to U06 only.
 if row['id']=='GD-U05':
  row['milestone']={'de':'Zielmodell: E1/R4 als eindeutige kleinste Einheitszuordnung; bestehende harte 1.2-Prüfungen bleiben. Keine vollständige neue Modellabnahme.','en':'Target model: E1/R4 as unique smallest-unit assignment; existing hard 1.2 checks remain. No full new-model acceptance.'}
dump(name,data)

# R2: The initial AGENTS rules must be current, not contradicted only by a later note.
name='AGENTS.md'
replace(name,'''- An explicitly authored whole-unit requirement belongs to the course. An atomic
  prerequisite does not automatically impose the entire foreign unit. Whether
  unit requirements guide recommendations or technically block starts, including
  direct assessment attempts, remains undecided; no new hard gate is authorized
  by this concept alone. Independent branches may proceed in parallel.''','''- **Whole-unit order (B9, 14 November 2026).** Only an explicitly authored
  `after` states the intended full completion of one unit before another
  starts; it is order, never a new whole-unit prerequisite type. Atomic
  prerequisites demand only their competencies. The former undecided access
  profile is retired in the binding target model: `after` blocks no starts
  or direct assessment attempts and changes neither frontier nor mastery.
  Task availability, authentication, scope and session binding remain their
  own contracts. This does not claim removal of historical code paths;
  independent branches may proceed in parallel.''')
replace(name,'recorded origin, never a contract. Whole-unit access locks stay undecided.','recorded origin, never a contract. The whole-unit access question left open\n  at that date was retired by B9 on 14 November 2026; only declared `after`\n  orders whole-unit completion, without need or access locks.')

# R2: The design sheet must assign whole-unit completion order only to authored after.
for lang in ['de','en']:
 name='docs/concept/skill-graph/architecture-source/chapters/12-learning-unit-design-and-examples.'+lang+'.md'
 if lang=='de':
  replace(name,'dafür bedarf es einer fachlich begründeten Ganz-Einheits-Voraussetzung.','Nur ein ausdrücklich erklärtes, fachlich begründetes `after` sagt, dass im vorgesehenen Lernfluss die gesamte andere Einheit vor Beginn abgeschlossen ist. Das ist eine Reihenfolge, kein zusätzlicher Voraussetzungstyp: Sie verändert weder atomaren Bedarf noch Frontier und sperrt keinen bewussten Prüfungsversuch.')
 else:
  replace(name,'that needs a subject-justified whole-unit prerequisite.','Only an explicitly authored, subject-justified `after` states that the whole other unit is complete before work begins in the intended flow. This is order, not an additional prerequisite type: it changes neither atomic demand nor frontier and locks no deliberate assessment attempt.')

# R4: Restrict F8-F13 to future unit migration; authorized K repairs continue now.
name=S+'implementation-status.json';data=load(name)
for row in data['poDecisions']:
 if row['de'].startswith('**14./15. November 2026:**'):
  row['de']=row['de'].replace('Neue fachliche Einheiten, Deckungsänderungen und produktive Leser benötigen weiterhin F8 bis F13 und ihre eigenen Nachweise.','Die künftige Einführung und Umstellung fachlicher Einheiten, ihre Cluster- und Prüfungsumzüge, Paketträger, produktiven Leser und neue Anerkennung folgen F8 bis F13 mit eigenen Nachweisen. Notwendige aktuelle Ziel-, Aufgaben-, Rubrik- und Deckungsreparaturen bleiben im delegierten K1–K13-Auftrag bereits jetzt zulässig; sie brauchen geeignete Aufgaben und aktuelle unabhängige Nachweise und dürfen falsche Voraussetzungen oder Abdeckung nicht bis F8 konservieren.')
  row['en']=row['en'].replace('New subject units, coverage changes, and production readers still require F8 to F13 and their own evidence.','Future introduction and migration of subject units, their cluster and assessment moves, package carriers, production readers, and new recognition follow F8 to F13 with their own evidence. Necessary current goal, task, rubric, and coverage repairs remain authorized now under delegated K1–K13; they require suitable tasks and current independent evidence and must not preserve false prerequisites or coverage until F8.')
 # C2: Time remains optional, P05's declared-unit E2 does not.
for row in data['boundaryTable']:
 if row['area']['en']=='Optional acquisition and time planning':
  row['repoStatus']={
   'de':'Das Zeit-/Budgetprofil bleibt optional (GD-P01–P04 und GD-P06–P11). GD-P05 enthält daneben die verbindliche E2-Pflicht erklärter Planeinheiten, noch ohne produktives hartes Gate. Kein produktives Curriculum- oder Laufzeit-Budgetgate wird behauptet; weight bedeutet niemals Minuten.',
   'en':'The time/budget profile remains optional (GD-P01–P04 and GD-P06–P11). GD-P05 additionally contains binding E2 for declared plan units, without a production hard gate yet. No production curriculum or runtime budget gate is claimed; weight never denotes minutes.'}
dump(name,data)

# C1: Both older umbrella definitions include declared cluster order and plan units.
name=S+'glossary-and-symbols.json';data=load(name)
for entry in data['frontmatterDistinctions']:
 if entry['term']['de']=='Cluster, Lerneinheit, Programmeinheit':
  entry['meaning']={
   'de':'Ein Cluster ist ein Ziel mit contains-Kindern. Eine Einheit ist ein ausdrücklich erklärter Cluster mit Lernversprechen und zusammenhängender Blockordnung nach E1 bis E4: fachliche Einheiten in der kanonischen Landschaft, Planeinheiten im gemeinsamen Landes-/Dauermodellplan. Eine Einheit mit Prüfungen belegt zusätzlich eigene Inhaltsziele. Programmeinheiten bilden organisatorische Struktur. Die bisherige learningUnit-Deklaration mit own und parentUnitId ist bis zur Migration der 1.2-Kompatibilitätsvertrag.',
   'en':'A cluster is a goal with contains children. A unit is an explicitly declared cluster with a learning promise and continuous block order under E1 to E4: subject units in the canonical landscape, plan units in the shared Land/duration plan. A unit with assessments additionally evidences own content goals. Program units form organizational structure. The existing learningUnit declaration with own and parentUnitId remains the 1.2 compatibility contract until migration.'}
 if entry['term']['de']=='verfasst, abgeleitet':
  entry['meaning']={
   'de':'Im Zielkern sind contains und requires verfasst; die Einheitenschicht erklärt zusätzlich Cluster als Einheiten und after als Ordnung ohne Bedarf. Effektive Anforderungen, Hüllen, eigene Zielmengen und notwendige Vorbereitung werden daraus abgeleitet.',
   'en':'The goal core authors contains and requires; the unit layer additionally declares clusters as units and after as order without demand. Effective requirements, closures, own goal sets, and necessary preparation derive from them.'}
for entry in data['glossary']:
 if entry['term']['en'].startswith('learning unit, child unit, required child'):
  entry['meaning']={
   'de':'Ausdrücklich erklärter Cluster mit Lernversprechen und zusammenhängender Blockordnung nach E1 bis E4; entweder kanonische fachliche Einheit oder Planeinheit im gemeinsamen Landes-/Dauermodellplan. Kindeinheiten sind die direkten erklärten Untereinheiten, Pflichtkinder die verpflichtenden darunter. Die bisherigen own- und parentUnitId-Felder gehören zum 1.2-Kompatibilitätsvertrag.',
   'en':'Explicitly declared cluster with a learning promise and continuous block order under E1 to E4; either a canonical subject unit or a plan unit in the shared Land/duration plan. Child units are the directly declared subunits, required children the mandatory ones. Existing own and parentUnitId fields belong to the 1.2 compatibility contract.'}
dump(name,data)

# Do not leave the narrowed K-repair authorization only in a status table.
for lang in ['de','en']:
 name=S+'chapters/03-learning-units.'+lang+'.md'
 marker='### '+('Motivation und eigener fachlicher Anspruch' if lang=='de' else 'Motivation and Distinct Domain Claims')
 add=('Notwendige aktuelle Fachkorrekturen an Zielen, Voraussetzungen, Aufgaben, Rubriken und Deckung bleiben im delegierten K1–K13-Auftrag bereits jetzt zulässig. Die F8-Grenze betrifft die künftige Einheiteneinführung und ihre Cluster-, Prüfungs-, Paket- und Laufzeitmigration; sie konserviert keine fachlich falsche Kante oder fehlende Prüfung. Jede solche Reparatur braucht ihre eigenen aktuellen unabhängigen Nachweise.\n\n' if lang=='de' else 'Necessary current subject-matter repairs of goals, prerequisites, tasks, rubrics, and coverage remain authorized now under delegated K1–K13. The F8 boundary concerns future unit introduction and its cluster, assessment, package, and runtime migration; it preserves no false edge or missing assessment. Each such repair needs its own current independent evidence.\n\n')
 replace(name,marker,add+marker)

# R3: Exact old values must come from an independent deep copy of baseline bytes.
oldrules={r['id']:r for r in json.loads((BEFORE/(S+'rules-and-gates.json')).read_text())['rules']}
currentrules={r['id']:r for r in load(S+'rules-and-gates.json')['rules']}
for item in matrix:
 item['old']=deepcopy(oldrules[item['id']])
 item['new']=deepcopy(currentrules[item['id']])
 assert item['old']==oldrules[item['id']]
 assert item['new']==currentrules[item['id']]
(BASE/'rule-decision-matrix.json').write_text(json.dumps(matrix,ensure_ascii=False,indent=2)+'\n')

# Human review index and byte-bound source/diff evidence; no Git commands.
patch=[];pins=[]
for name in TOUCH:
 a=(BEFORE/name).read_text();b=read(name)
 if a==b:continue
 patch.extend(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
 pins.append({'path':name,'beforeSha256':hashlib.sha256((BEFORE/name).read_bytes()).hexdigest(),'proposedSha256':hashlib.sha256((OUT/name).read_bytes()).hexdigest()})
(BASE/'candidate.patch').write_text(''.join(patch))
(BASE/'source-pins.json').write_text(json.dumps({'candidate':'F7-author-candidate-2026-11-15-v2','activeFilesMutated':False,'sources':pins},ensure_ascii=False,indent=2)+'\n')
rows=['# F7: Entscheidungsmatrix der 26 Einheiten- und Planungsregeln','', 'Die vollständigen alten und neuen DE/EN-Felder stehen in `rule-decision-matrix.json`; diese Tabelle ist der Leseindex. Neue offene Zielpflichten sind kein harter Implementierungsnachweis.','', '| Regel | Änderung | Status alt → neu |','| --- | --- | --- |']
for row in matrix:
 rows.append('| '+row['id']+' | '+row['new']['rule']['de'].replace('|','\\|')+' | '+row['old']['ampel']+' → '+row['new']['ampel']+' |')
rows+=['','Zusätzlich gezielt: GD-X06 (vorläufige kanonische Standardzuordnung und gemeinsame Landesautorität), GD-X13 (Stelle der Voraussetzungshilfe, frühester tatsächlicher Bedarf und Quellenzuordnung/Lernplatz).','', 'GD-U13 bleibt hart ausschließlich für die unveränderte atomare 21-Wurzel-G17-Pflicht. GD-U14 führt E3/E4 offen nach Ablösung des optionalen Zugangsprofils; GD-P05 ist für erklärte Planeinheiten verbindlich, aber ohne neues hartes Gate. Bestehende harte 1.2-Prüfungen werden nicht abgewertet oder als Prüfung des neuen Modells ausgegeben.','', 'B3/B13 sind Zielnormen mit F8-Vorbedingung, keine abgeschlossene Umstellung. F8–F13 bleiben getrennte Folgelieferungen.']
(BASE/'decision-matrix.md').write_text('\n'.join(rows)+'\n')
print('Prepared',len(pins),'proposed files and',len(matrix),'rule decisions; no active source writes.')
