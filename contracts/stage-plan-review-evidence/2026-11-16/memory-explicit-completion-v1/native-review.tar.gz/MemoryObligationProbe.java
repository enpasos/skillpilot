import com.fasterxml.jackson.databind.ObjectMapper;
import com.skillpilot.backend.landscape.LearningGoal;
import com.skillpilot.backend.landscape.SkillLandscape;
import com.skillpilot.backend.completion.*;
import java.nio.file.*;
import java.util.*;
import java.security.MessageDigest;

/** Pure native completion evaluation; never creates or modifies a learner. */
public class MemoryObligationProbe {
 static final String O="65365dce-f33f-49d8-9516-42f75883aa86",M="4eefbd04-9e49-41ea-a087-9ad6ac71ec5a";
 static int checks=0;
 static void ok(boolean condition,String name){if(!condition)throw new AssertionError(name);checks++;System.out.println("PASS "+name);}
 static LearningGoal atom(String id,String...requires){var g=new LearningGoal();g.setId(id);g.setType("atomic");g.setContains(List.of());g.setRequires(List.of(requires));return g;}
 public static void main(String[]args)throws Exception{
  boolean fixed=args.length>1&&args[1].equals("expect-fixed");
  var mapper=new ObjectMapper().findAndRegisterModules();var landscape=mapper.readValue(Path.of(args[0]).toFile(),SkillLandscape.class);
  Map<String,LearningGoal> all=new LinkedHashMap<>(),pair=new LinkedHashMap<>();for(var g:landscape.getGoals()){all.put(g.getId(),g);if(g.getId().equals(O)||g.getId().equals(M))pair.put(g.getId(),g);}
  for(var clazz:List.of(CompletionProfileCompiler.class,CompletionEvaluator.class,CompiledAutomaticCompletion.class))try(var stream=clazz.getResourceAsStream("/"+clazz.getName().replace('.','/')+".class")){
   System.out.println("CLASS_SHA256 "+clazz.getSimpleName()+" "+HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(stream.readAllBytes())));
  }
  var compiler=new CompletionProfileCompiler();var evaluator=new CompletionEvaluator();
  var compiled=compiler.compileAutomatic(pair,Set.of(O,M),Set.of(O,M),"actual-fixture-readonly");
  var result=evaluator.evaluateAutomatic(compiled,Set.of(O));
  System.out.println("ACTUAL_PAIR orientationOnlyMastered: complete="+result.complete()+" waived="+result.waivedGoalIds()+" pending="+result.pendingTargetGoalIds()+" assessmentCount="+result.requiredAssessmentCount());
  if(!fixed){ok(result.waivedGoalIds().contains(M)&&result.complete()&&result.requiredAssessmentCount()==0,"BEFORE actualMemoryWronglyWaivedNoRemainingDemand");return;}
  ok(!result.complete()&&!result.waivedGoalIds().contains(M)&&result.pendingTargetGoalIds().contains(M),"actualMemoryRequiresOwnExplicitVerifiedMastery");
  ok(result.requiredAssessmentCount()==0&&result.masteredAssessmentGoalIds().isEmpty(),"memoryNeverReclassifiedAsAssessment");
  ok(!result.blockedByGoalIds().containsKey(M),"explicitMemoryDoesNotBlockItself");
  ok(evaluator.evaluateAutomatic(compiled,Set.of(O,M)).complete(),"actualMemoryExplicitPassCompletesPair");
  var definition=new CompletionProfileDefinition(1,"automatic:read-only-fixture","v1",Map.of("de","Test","en","Test"),"fixture",Map.of(),List.of(),null,List.of());
  var wrapped=compiler.compileAutomaticProfile(definition,pair,Set.of(O,M),Set.of(O,M),"actual-fixture-readonly");
  ok(!evaluator.evaluate(wrapped,Set.of(O)).complete()&&wrapped.protectedGoalIds().contains(M),"automaticProfileWrapperPreservesMemoryObligation");
  Set<String> allAtoms=new LinkedHashSet<>();for(var g:all.values())if(g.getContains()==null||g.getContains().isEmpty())allAtoms.add(g.getId());
  var global=compiler.compileAutomatic(all,allAtoms,allAtoms,"actual-full-math-readonly");var globalResult=evaluator.evaluateAutomatic(global,Set.of(O));
  ok(!globalResult.waivedGoalIds().contains(M)&&global.protectedGoalIds().contains(M),"actualFullMathContextKeepsUnmasteredMemory");
  ok(globalResult.requiredAssessmentCount()==global.assessmentGoalIds().size()&&!global.assessmentGoalIds().contains(M),"fullMathAssessmentCountsRemainSeparate");
  var extra=new LinkedHashMap<>(pair);extra.put("unrelated-memory",mapper.convertValue(pair.get(M),LearningGoal.class));extra.get("unrelated-memory").setId("unrelated-memory");
  var orientationOnly=compiler.compileAutomatic(extra,Set.of(O),extra.keySet(),"unrelated-memory-readonly");
  ok(!orientationOnly.contextGoalIds().contains(M)&&!orientationOnly.contextGoalIds().contains("unrelated-memory")&&evaluator.evaluateAutomatic(orientationOnly,Set.of(O)).complete(),"memoryOutsideActualContextDoesNotBlockOrWidenScope");
  var supporting=new LinkedHashMap<>(pair);supporting.put("ordinary-consumer",atom("ordinary-consumer",M));
  var supportCompiled=compiler.compileAutomatic(supporting,Set.of("ordinary-consumer"),supporting.keySet(),"supporting-memory-readonly");
  var supportResult=evaluator.evaluateAutomatic(supportCompiled,Set.of(O));
  ok(!supportResult.complete()&&!supportResult.waivedGoalIds().contains(M)&&!supportCompiled.targetGoalIds().contains(M),"supportingMemoryOutsideTargetsStillPreventsComplete");
  ok(evaluator.evaluateAutomatic(supportCompiled,Set.of(O,M)).complete(),"supportingMemoryExplicitPassAllowsComplete");
  var chain=new LinkedHashMap<String,LearningGoal>();var memory=mapper.convertValue(pair.get(M),LearningGoal.class);memory.setRequires(List.of("middle"));chain.put(M,memory);chain.put("middle",atom("middle","base"));chain.put("base",atom("base"));
  var chainCompiled=compiler.compileAutomatic(chain,chain.keySet(),chain.keySet(),"memory-transitive-readonly");var chainResult=evaluator.evaluateAutomatic(chainCompiled,Set.of("middle"));
  ok(!chainResult.waivedGoalIds().contains("base")&&M.equals(chainResult.blockedByGoalIds().get("base")),"openMemoryRetainsFullDemandThroughMasteredIntermediate");
  ok(!chainResult.blockedByGoalIds().containsKey(M),"chainMemoryHasNoSelfBlocker");
  var done=evaluator.evaluateAutomatic(chainCompiled,Set.of(M,"middle"));
  ok(done.complete()&&done.waivedGoalIds().contains("base")&&!done.masteredGoalIds().contains("base"),"dischargedOrdinaryDemandIsContextWaiverNotInventedMastery");
  System.out.println("PASS_FIXED checks="+checks);
 }
}
