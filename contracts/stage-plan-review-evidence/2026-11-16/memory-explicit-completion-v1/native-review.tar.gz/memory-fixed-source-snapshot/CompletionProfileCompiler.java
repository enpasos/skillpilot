package com.skillpilot.backend.completion;

import com.skillpilot.backend.landscape.LearningGoal;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * Strict canonical compilation. The caller resolves scope, identity aliases and qualified
 * references first; this compiler never silently repairs an unknown reference or self-edge.
 * References and contains/raw-requires cycles are checked globally. Other full-graph
 * authoring requirements remain the existing base-quality gates; compilation is not a
 * release approval. Expanded atomic cycles are checked only in the prerequisite-closed
 * context, so an unrelated expansion defect does not change this scope.
 */
public final class CompletionProfileCompiler {
    // One immutable entry per compiler; never retains learner state or trusts map identity.
    private volatile PrerequisiteTopology lastNormalizedTopology;

    /** Immutable, mastery-independent normalization shared with ordinary availability. */
    public static final class PrerequisiteTopology {
        private final Map<String, Node> nodes;
        private final Map<String, Set<String>> prerequisites;
        private final Map<String, Set<String>> effectiveGoalRequires;

        private PrerequisiteTopology(Map<String, Node> nodes,
                Map<String, Set<String>> prerequisites, Map<String, Set<String>> effectiveGoalRequires) {
            this.nodes = Map.copyOf(nodes);
            this.prerequisites = immutableSets(prerequisites);
            this.effectiveGoalRequires = immutableSets(effectiveGoalRequires);
        }

        private static Map<String, Set<String>> immutableSets(Map<String, Set<String>> values) {
            Map<String, Set<String>> result = new TreeMap<>();
            values.forEach((id, refs) -> result.put(id, java.util.Collections.unmodifiableSet(new TreeSet<>(refs))));
            return java.util.Collections.unmodifiableMap(result);
        }

        /**
         * Immutable, sorted atomic prerequisites after inheritance and cluster expansion.
         * Validate the selected context before traversing these edges.
         */
        public Set<String> directPrerequisites(String id) {
            if (!nodes.containsKey(id)) fail("MISSING_REFERENCE", "Unknown goal " + id);
            return prerequisites.get(id);
        }

        /** Full atomic demand; mastery and endpoint scope never stop traversal. */
        public Set<String> transitivePrerequisites(String id) {
            directPrerequisites(id);
            return java.util.Collections.unmodifiableSet(new TreeSet<>(reachable(id, prerequisites)));
        }

        /** Inherited and transitive goal-node requirements, before contains expansion. */
        public Set<String> transitiveGoalPrerequisites(String id) {
            directPrerequisites(id);
            return java.util.Collections.unmodifiableSet(new TreeSet<>(reachable(id, effectiveGoalRequires)));
        }

        public void validateContext(Set<String> roots) {
            Map<String, Set<String>> edges = new TreeMap<>();
            ArrayDeque<String> pending = new ArrayDeque<>(roots);
            while (!pending.isEmpty()) {
                String id = pending.removeFirst();
                if (edges.containsKey(id)) continue;
                Set<String> refs = directPrerequisites(id);
                edges.put(id, refs);
                pending.addAll(refs);
            }
            topologicalOrder(edges, "ATOMIC_CYCLE");
        }
    }

    /** Inherit globally, expand every required cluster, then traverse atomic edges. */
    public PrerequisiteTopology normalizePrerequisites(Map<String, LearningGoal> canonicalGoals) {
        if (canonicalGoals == null || canonicalGoals.isEmpty()) fail("MISSING_REFERENCE", "No canonical goals");
        Map<String, Node> nodes = snapshot(canonicalGoals);
        // Snapshot validation precedes reuse: in-place edits and invalid references remain visible.
        PrerequisiteTopology cached = lastNormalizedTopology;
        if (cached != null && cached.nodes.equals(nodes)) return cached;
        Map<String, Set<String>> contains = new TreeMap<>();
        Map<String, Set<String>> requires = new TreeMap<>();
        for (Node node : nodes.values()) {
            contains.put(node.id(), node.children());
            requires.put(node.id(), node.requires());
        }
        List<String> containsOrder = topologicalOrder(contains, "CONTAINS_CYCLE");
        topologicalOrder(requires, "REQUIRES_CYCLE");
        // Parent-before-child propagation follows every contains path, including multiple parents.
        Map<String, Set<String>> effective = new HashMap<>();
        for (Node node : nodes.values()) effective.put(node.id(), new TreeSet<>(node.requires()));
        for (String id : containsOrder) {
            for (String child : nodes.get(id).children()) effective.get(child).addAll(effective.get(id));
        }
        Map<String, Set<String>> atoms = new HashMap<>();
        for (int i = containsOrder.size() - 1; i >= 0; i--) {
            String id = containsOrder.get(i);
            Node node = nodes.get(id);
            Set<String> basis = new TreeSet<>();
            if (node.children().isEmpty()) basis.add(id);
            else for (String child : node.children()) basis.addAll(atoms.get(child));
            atoms.put(id, basis);
        }
        Map<String, Set<String>> expanded = new TreeMap<>();
        for (String id : nodes.keySet()) {
            Set<String> refs = new TreeSet<>();
            for (String prerequisite : effective.get(id)) refs.addAll(atoms.get(prerequisite));
            expanded.put(id, refs);
        }
        PrerequisiteTopology normalized = new PrerequisiteTopology(nodes, expanded, effective);
        lastNormalizedTopology = normalized;
        return normalized;
    }
    /** Adds existing scope metadata without requiring authored review or waiver grants. */
    public CompiledCompletionProfile compileAutomaticProfile(
            CompletionProfileDefinition definition,
            Map<String, LearningGoal> canonicalGoals,
            Set<String> resolvedScopeTargetIds,
            Set<String> level2TargetIds,
            String curriculumGeneration) {
        if (definition == null || definition.schemaVersion() != 1 || !text(definition.id())
                || !text(definition.revision()) || !text(definition.levelScopeRef())
                || !text(definition.title().get("de")) || !text(definition.title().get("en"))) {
            fail("INVALID_PROFILE", "Scope identity, version and titles are required");
        }
        CompiledAutomaticCompletion graph = compileAutomatic(canonicalGoals, resolvedScopeTargetIds,
                level2TargetIds, curriculumGeneration);
        return new CompiledCompletionProfile(definition, curriculumGeneration, graph.goalIds(),
                java.util.stream.IntStream.range(0, graph.size()).mapToObj(graph::prerequisiteIndices)
                        .toArray(int[][]::new),
                graph.order(), graph.targetGoalIds(), graph.assessmentGoalIds(), graph.protectedGoalIds(),
                List.of(), true);
    }

    /**
     * Compiles direct atomic prerequisite edges for automatic completion. Every
     * assessment and memory goal in the complete context remains an explicit
     * obligation until graded or verified recall confirms mastery. Orientation
     * and ordinary goals have no additional protected status.
     */
    public CompiledAutomaticCompletion compileAutomatic(
            Map<String, LearningGoal> canonicalGoals,
            Set<String> resolvedScopeTargetIds,
            Set<String> level2TargetIds,
            String curriculumGeneration) {
        if (!text(curriculumGeneration)) fail("INVALID_GENERATION", "Curriculum generation is required");
        CompiledCompletionGraph graph = compileGraph(canonicalGoals, resolvedScopeTargetIds, level2TargetIds,
                List.of(), List.of(), false);
        Set<String> assessments = new TreeSet<>();
        Set<String> explicitObligations = new TreeSet<>();
        for (String id : graph.contextGoalIds()) {
            if (isAssessment(canonicalGoals.get(id))) assessments.add(id);
            if (isAssessment(canonicalGoals.get(id)) || isMemory(canonicalGoals.get(id))) explicitObligations.add(id);
        }
        return new CompiledAutomaticCompletion(graph, assessments, explicitObligations, curriculumGeneration);
    }

    public CompiledCompletionProfile compile(
            CompletionProfileDefinition definition,
            Map<String, LearningGoal> canonicalGoals,
            Set<String> resolvedScopeTargetIds,
            Set<String> level2TargetIds,
            String curriculumGeneration) {
        validateDefinition(definition, curriculumGeneration);
        CompiledCompletionGraph graph = compileGraph(canonicalGoals, resolvedScopeTargetIds, level2TargetIds,
                definition.protectedGoalIds(), definition.rules(), true);
        return new CompiledCompletionProfile(definition, curriculumGeneration, graph.goalIds(),
                java.util.stream.IntStream.range(0, graph.size()).mapToObj(graph::prerequisiteIndices)
                        .toArray(int[][]::new),
                graph.order(), graph.targetGoalIds(), graph.assessmentGoalIds(), graph.protectedGoalIds(), graph.rules());
    }

    CompiledCompletionGraph compilePlan(LearningPlanCompletionContext context, Set<String> obligations) {
        Set<String> targets = new TreeSet<>(obligations);
        Set<String> protectedGoals = new TreeSet<>();
        List<CompletionProfileDefinition.WaiverRule> rules = new ArrayList<>();
        for (var profile : context.reviewedProfiles()) {
            if (!context.generation().equals(profile.curriculumGeneration())) {
                fail("STALE_REVIEW", "Plan and reviewed profile generations differ");
            }
            // A reviewed section may only discharge its own target obligations. Its
            // supporting-context waivers never acquire a broader planning scope.
            for (var rule : profile.definition().rules()) {
                List<String> waivable = rule.waivableGoalIds().stream()
                        .filter(profile.targetGoalIds()::contains).toList();
                if (waivable.isEmpty()) continue;
                targets.addAll(rule.assessmentGoalIds());
                rules.add(new CompletionProfileDefinition.WaiverRule(
                        profile.definition().id() + "::" + rule.ruleId(), rule.assessmentGoalIds(), waivable,
                        rule.rationale(), rule.reviewRef()));
            }
            protectedGoals.addAll(profile.protectedGoalIds());
        }
        CompiledCompletionGraph graph = compileGraph(context.canonicalGoals(), targets, context.level2TargetGoalIds(),
                List.copyOf(protectedGoals), rules, false);
        return new CompiledCompletionGraph(graph.goalIds(),
                java.util.stream.IntStream.range(0, graph.size()).mapToObj(graph::prerequisiteIndices)
                        .toArray(int[][]::new),
                graph.order(), graph.targetGoalIds(), graph.assessmentGoalIds(), graph.protectedGoalIds(),
                graph.rules(), obligations);
    }

    private CompiledCompletionGraph compileGraph(Map<String, LearningGoal> canonicalGoals,
            Set<String> resolvedScopeTargetIds, Set<String> level2TargetIds,
            List<String> declaredProtectedGoals, List<CompletionProfileDefinition.WaiverRule> declaredRules,
            boolean requireAssessment) {
        if (canonicalGoals == null || canonicalGoals.isEmpty()) fail("MISSING_REFERENCE", "No canonical goals");
        if (resolvedScopeTargetIds == null || resolvedScopeTargetIds.isEmpty()) fail("EMPTY_SCOPE", "Empty target scope");
        if (level2TargetIds == null) fail("FOREIGN_TARGET", "Missing authoritative Level-2 targets");

        PrerequisiteTopology topology = normalizePrerequisites(canonicalGoals);
        Map<String, Node> nodes = topology.nodes;

        Set<String> targets = sorted(resolvedScopeTargetIds);
        Set<String> assessments = new TreeSet<>();
        for (String id : targets) {
            Node node = nodes.get(id);
            if (node == null) fail("MISSING_REFERENCE", "Unknown target " + id);
            if (!node.children().isEmpty()) fail("TARGET_NOT_ATOMIC", "Target is a cluster: " + id);
            if (!level2TargetIds.contains(id)) fail("FOREIGN_TARGET", "Target outside Personal Curriculum: " + id);
            if (node.assessment()) assessments.add(id);
        }
        if (requireAssessment && assessments.isEmpty()) fail("NO_REQUIRED_ASSESSMENT", "Scope has no required assessment");

        Map<String, Set<String>> expanded = new TreeMap<>();
        Set<String> context = new TreeSet<>();
        ArrayDeque<String> pending = new ArrayDeque<>(targets);
        while (!pending.isEmpty()) {
            String id = pending.removeFirst();
            if (!context.add(id)) continue;
            Set<String> prerequisites = topology.directPrerequisites(id);
            expanded.put(id, prerequisites);
            pending.addAll(prerequisites);
        }
        List<String> order = topologicalOrder(expanded, "ATOMIC_CYCLE");

        Set<String> protectedIds = new TreeSet<>();
        for (String id : context) if (nodes.get(id).protectedGoal()) protectedIds.add(id);
        for (String id : declaredProtectedGoals) {
            if (!context.contains(id)) {
                if (requireAssessment) fail("MISSING_REFERENCE", "Protected goal outside context: " + id);
                continue;
            }
            protectedIds.add(id);
        }

        List<String> ids = List.copyOf(context);
        Map<String, Integer> indices = new HashMap<>();
        for (int i = 0; i < ids.size(); i++) indices.put(ids.get(i), i);
        int[][] edges = new int[ids.size()][];
        for (int i = 0; i < ids.size(); i++) {
            edges[i] = expanded.get(ids.get(i)).stream().mapToInt(indices::get).toArray();
        }

        List<CompiledCompletionProfile.CompiledRule> rules = new ArrayList<>();
        Set<String> ruleIds = new HashSet<>();
        Map<String, Set<String>> reachabilityByAssessment = new HashMap<>();
        for (var rule : declaredRules.stream()
                .sorted(java.util.Comparator.comparing(CompletionProfileDefinition.WaiverRule::ruleId,
                        java.util.Comparator.nullsFirst(String::compareTo))).toList()) {
            if (rule == null || !text(rule.ruleId()) || !ruleIds.add(rule.ruleId())
                    || !text(rule.rationale()) || !text(rule.reviewRef()) || rule.assessmentGoalIds().isEmpty()) {
                fail("INVALID_RULE", "Missing/duplicate rule identity, review or supporting assessments");
            }
            Set<String> supporting = unique(rule.assessmentGoalIds(), "INVALID_RULE", "supporting assessments");
            Set<String> waivable = unique(rule.waivableGoalIds(), "INVALID_RULE", "waivable goals");
            if (!assessments.containsAll(supporting)) fail("INVALID_RULE", "Rule assessment is not required in this scope: " + rule.ruleId());
            for (String id : waivable) {
                if (!context.contains(id)) fail("MISSING_REFERENCE", "Waivable goal outside context: " + id);
                if (protectedIds.contains(id)) fail("PROTECTED_GOAL", "Rule waives a protected goal: " + id);
                boolean reachable = false;
                for (String assessment : supporting) {
                    Set<String> reachableIds = reachabilityByAssessment.computeIfAbsent(assessment,
                            key -> reachable(key, expanded));
                    if (reachableIds.contains(id)) { reachable = true; break; }
                }
                if (!reachable) fail("RULE_NOT_PREREQUISITE", "Waivable goal is not a strict assessment prerequisite: " + id);
            }
            rules.add(new CompiledCompletionProfile.CompiledRule(rule.ruleId(),
                    supporting.stream().map(indices::get).toList(), waivable.stream().map(indices::get).toList(),
                    List.copyOf(supporting)));
        }
        return new CompiledCompletionGraph(ids, edges,
                order.stream().mapToInt(indices::get).toArray(), targets, assessments, protectedIds, rules);
    }

    private static Map<String, Node> snapshot(Map<String, LearningGoal> goals) {
        Map<String, Node> nodes = new TreeMap<>();
        for (var entry : goals.entrySet()) {
            LearningGoal goal = entry.getValue();
            if (!text(entry.getKey()) || goal == null || !entry.getKey().equals(goal.getId())) {
                fail("IDENTITY_CONFLICT", "Canonical key must equal the nonempty goal ID");
            }
            Set<String> children = unique(goal.getContains(), "MISSING_REFERENCE", "contains references");
            Set<String> requires = unique(goal.getRequires(), "MISSING_REFERENCE", "requires references");
            if (goal.getType() != null && !goal.getType().isBlank()
                    && ("atomic".equalsIgnoreCase(goal.getType()) != children.isEmpty())) {
                fail("IDENTITY_CONFLICT", "Explicit atomic/cluster type disagrees with contains: " + goal.getId());
            }
            boolean assessment = isAssessment(goal);
            nodes.put(goal.getId(), new Node(goal.getId(), children, requires, assessment,
                    assessment || isOrientation(goal) || isMemory(goal)));
        }
        for (Node node : nodes.values()) {
            for (String ref : node.children()) if (!nodes.containsKey(ref)) fail("MISSING_REFERENCE", "Unknown contains reference " + ref);
            for (String ref : node.requires()) if (!nodes.containsKey(ref)) fail("MISSING_REFERENCE", "Unknown requires reference " + ref);
        }
        return nodes;
    }

    /** Shared completion type semantics, including current compatible legacy encodings. */
    public static boolean isAssessment(LearningGoal goal) {
        return goal != null && ("exam".equalsIgnoreCase(goal.getNodeKind()) || goal.getExamData() != null
                || "practiceAssessment".equalsIgnoreCase(goal.getSemanticKind())
                || "assessment".equalsIgnoreCase(goal.getSemanticKind()));
    }

    public static boolean isOrientation(LearningGoal goal) {
        if (goal == null) return false;
        if (text(goal.getSemanticKind())) return "orientation".equalsIgnoreCase(goal.getSemanticKind().trim());
        return goal.getTags() != null && goal.getTags().stream().anyMatch(tag -> tag != null
                && ("orientation".equalsIgnoreCase(tag.trim()) || "motivation".equalsIgnoreCase(tag.trim())));
    }

    public static boolean isMemory(LearningGoal goal) {
        if (goal == null) return false;
        if ("memory".equalsIgnoreCase(goal.getNodeKind()) || "memory".equalsIgnoreCase(goal.getSemanticKind())
                || "memorization".equalsIgnoreCase(goal.getSemanticKind())) return true;
        if (goal.getExtendedData() != null && goal.getExtendedData().get("vocabularySource") instanceof String) return true;
        return goal.getTags() != null && goal.getTags().stream().anyMatch(tag -> tag != null
                && (tag.startsWith("srs-deck") || "memorization".equals(tag)));
    }

    private static void validateDefinition(CompletionProfileDefinition definition, String generation) {
        if (definition == null || definition.schemaVersion() != 1 || !text(definition.id())
                || !text(definition.revision()) || !text(definition.levelScopeRef()) || !text(generation)
                || !text(definition.title().get("de")) || !text(definition.title().get("en"))) {
            fail("INVALID_PROFILE", "Profile identity, version, scope, titles and generation are required");
        }
        var review = definition.review();
        if (review == null || !text(review.reference()) || !text(review.scopeRevision())
                || !text(review.taskRevision()) || !text(review.rubricRevision())) {
            fail("INVALID_PROFILE", "Reviewed scope, task and rubric revisions are required");
        }
        for (var entry : definition.applicability().entrySet()) {
            if (!text(entry.getKey()) || entry.getValue().isEmpty()) fail("INVALID_PROFILE", "Empty applicability dimension");
            unique(entry.getValue(), "INVALID_PROFILE", "applicability values");
        }
        unique(definition.protectedGoalIds(), "INVALID_PROFILE", "protected goals");
    }

    private static Set<String> reachable(String source, Map<String, Set<String>> edges) {
        Set<String> found = new HashSet<>();
        ArrayDeque<String> queue = new ArrayDeque<>(edges.get(source));
        while (!queue.isEmpty()) {
            String id = queue.removeFirst();
            if (found.add(id)) queue.addAll(edges.get(id));
        }
        return found;
    }

    private static List<String> topologicalOrder(Map<String, Set<String>> edges, String cycleCode) {
        Map<String, Integer> incoming = new HashMap<>();
        edges.keySet().forEach(id -> incoming.put(id, 0));
        edges.values().forEach(refs -> refs.forEach(id -> incoming.merge(id, 1, Integer::sum)));
        PriorityQueue<String> ready = new PriorityQueue<>();
        incoming.forEach((id, count) -> { if (count == 0) ready.add(id); });
        List<String> order = new ArrayList<>();
        while (!ready.isEmpty()) {
            String id = ready.remove();
            order.add(id);
            for (String to : edges.get(id)) if (incoming.merge(to, -1, Integer::sum) == 0) ready.add(to);
        }
        if (order.size() != edges.size()) fail(cycleCode, "Cycle in " + cycleCode.toLowerCase(Locale.ROOT));
        return order;
    }

    private static Set<String> unique(List<String> values, String code, String kind) {
        Set<String> result = new TreeSet<>();
        if (values == null) return result;
        for (String value : values) {
            if (!text(value) || !result.add(value)) fail(code, "Invalid or duplicate " + kind);
        }
        return result;
    }

    private static Set<String> sorted(Set<String> values) {
        Set<String> result = new TreeSet<>();
        for (String value : values) {
            if (!text(value)) fail("MISSING_REFERENCE", "Empty target reference");
            result.add(value);
        }
        return result;
    }

    private static boolean text(String value) { return value != null && !value.isBlank(); }
    private static void fail(String code, String detail) { throw new CompletionCompilationException(code, detail); }
    private record Node(String id, Set<String> children, Set<String> requires, boolean assessment, boolean protectedGoal) { }
}
