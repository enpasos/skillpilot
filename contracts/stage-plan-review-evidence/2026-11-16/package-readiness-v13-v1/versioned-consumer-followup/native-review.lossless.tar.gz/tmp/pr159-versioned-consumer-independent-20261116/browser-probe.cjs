'use strict'
const fs = require('node:fs')
const vm = require('node:vm')
const assert = require('node:assert/strict')
const source = fs.readFileSync('scripts/v1.3/package_consumer_browser_smoke.cjs', 'utf8')
const context = {
  require, console, URL, URLSearchParams,
  process: { argv: ['node', '--self-test'], stdout: process.stdout, stderr: process.stderr },
}
vm.runInNewContext(`${source}\nglobalThis.reviewExports = { isExactLearnerClosureResponse, isCatalogFallbackLandscapePath, assertNoForbiddenRequests };`, context)
assert.equal(context.process.exitCode, undefined)
const { isExactLearnerClosureResponse: match, isCatalogFallbackLandscapePath: fallback, assertNoForbiddenRequests } = context.reviewExports
const cases = []
function check(name, expected, response, learner = 'learner-a', root = 'root-a') {
  assert.equal(match(response, learner, root), expected, name)
  cases.push({ name, passed: true })
}
const endpoint = '/api/ui/learners/learner-a/landscapes/root-a/closure'
const valid = { path: endpoint, status: 200, method: 'GET' }
check('exact page GET', true, valid)
check('query accepted without changing path identity', true, { ...valid, path: `${endpoint}?lang=de&next=/other` })
check('percent encoded identities', true, { ...valid, path: '/api/ui/learners/a%2Fb/landscapes/r%20%C3%A4/closure' }, 'a/b', 'r ä')
for (const [name, response] of [
  ['wrong learner', { ...valid, path: endpoint.replace('learner-a', 'learner-b') }],
  ['wrong landscape', { ...valid, path: endpoint.replace('root-a', 'root-b') }],
  ['legacy unscoped endpoint', { ...valid, path: '/api/ui/landscapes/root-a/closure' }],
  ['suffix', { ...valid, path: `${endpoint}/extra` }],
  ['trailing slash', { ...valid, path: `${endpoint}/` }],
  ['query impersonation', { ...valid, path: `/other?next=${endpoint}` }],
  ['absolute URL cannot impersonate observed path', { ...valid, path: `https://example.com${endpoint}` }],
  ['wrong status', { ...valid, status: 404 }],
  ['redirect status', { ...valid, status: 302 }],
  ['status must be numeric', { ...valid, status: '200' }],
  ['POST cannot satisfy page fetch', { ...valid, method: 'POST' }],
  ['missing method', { path: endpoint, status: 200 }],
  ['missing response', null],
]) check(name, false, response)
for (const candidate of [endpoint, '/api/ui/landscapes/root-a/closure', '/api/ui/composition-views/offerings/a']) {
  assert.equal(fallback(candidate), true)
  cases.push({ name: `catalog failure guards ${candidate}`, passed: true })
}
assert.equal(fallback('/api/ui/learners/learner-a/state'), false)
cases.push({ name: 'unrelated learner state not treated as fallback', passed: true })
for (const candidate of ['http://example.com/api/x', 'http://127.0.0.1:18080/data/a', 'http://127.0.0.1:18080/curricula/a']) {
  assert.throws(() => assertNoForbiddenRequests([candidate], 'independent probe'))
  cases.push({ name: `original forbidden request rejection ${candidate}`, passed: true })
}
fs.writeFileSync('tmp/pr159-versioned-consumer-independent-20261116/browser-probe.actual.json', JSON.stringify({ cases, count: cases.length }, null, 2) + '\n')
console.log(`Independent native browser predicates: ${cases.length} cases PASS`)
