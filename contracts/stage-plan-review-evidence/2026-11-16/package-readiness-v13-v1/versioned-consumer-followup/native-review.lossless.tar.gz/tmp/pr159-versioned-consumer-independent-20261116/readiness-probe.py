from __future__ import annotations
import ast
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
OUT = ROOT / 'tmp/pr159-versioned-consumer-independent-20261116'
sys.path.insert(0, str(ROOT / 'scripts'))
import evaluate_curriculum_package_readiness as r
import generate_curriculum_package_v13_readiness as g

cases = []
def check(name, condition):
    assert condition, name
    cases.append({'name': name, 'passed': True})

base = r.trusted_contracts()
current = r.trusted_contracts(g.TARGET)
check('default remains v1', base.contract_dir == r.CONTRACT_DIR)
check('explicit current directory bound', current.contract_dir == g.TARGET)
check('all thirteen blocking readiness gates identical', len(current.policy['requiredChecks']) == 13 and current.policy['requiredChecks'] == base.policy['requiredChecks'])
check('all fifteen functional checks retained', len(r.FUNCTIONAL_CHECK_IDS) == 15)
for path, raw in g.generated_documents().items():
    check('reproducible ' + path.name, path.read_bytes() == raw)
schema = copy.deepcopy(current.consumer_report_schema)
schema['$id'] = base.consumer_report_schema['$id']
schema['properties']['$schema']['const'] = schema['$id']
schema['properties']['runner']['properties']['version']['const'] = '1.0.0'
check('consumer schema identical apart from versioned identity', schema == base.consumer_report_schema)
report = copy.deepcopy(current.report_schema)
for key in ('$id', 'title', 'description'):
    report[key] = base.report_schema[key]
report['properties']['$schema']['const'] = base.report_schema['$id']
report['properties']['scope']['const'] = base.report_schema['properties']['scope']['const']
report['properties']['policy']['properties']['id']['const'] = base.report_schema['properties']['policy']['properties']['id']['const']
check('readiness schema identical apart from explicit identity and description', report == base.report_schema)

old = (ROOT/'scripts/run_package_consumer_smoke.py').read_text()
new = (ROOT/'scripts/run_package_consumer_smoke_v13.py').read_text()
replacements = {
    'RUNNER_PATH = REPO_ROOT / "scripts/run_package_consumer_smoke.py"': 'RUNNER_PATH = REPO_ROOT / "scripts/run_package_consumer_smoke_v13.py"',
    'SCHEMA_PATH = REPO_ROOT / "contracts/curriculum-package/v1/package-consumer-smoke-report.schema.json"': 'SCHEMA_PATH = REPO_ROOT / "contracts/curriculum-package/v1.3/package-consumer-smoke-report.schema.json"',
    'https://skillpilot.com/schemas/curriculum-package/v1/package-consumer-smoke-report.schema.json': 'https://skillpilot.com/schemas/curriculum-package/v1.3/package-consumer-smoke-report.schema.json',
    'RUNNER_VERSION = "1.0.0"': 'RUNNER_VERSION = "1.1.0"',
    'scripts/package_consumer_browser_smoke.cjs': 'scripts/v1.3/package_consumer_browser_smoke.cjs',
    'b328b8ab63f8df6143602a2b2fd71fcf88008b7c4de7e2f9845a1fb476081f6e': 'f3bc947aee48eb9bbeac8e9f975b655f35cde6dfbd3f0a947801230ca0a92643',
}
for before, after in replacements.items():
    assert before in old
    old = old.replace(before, after)
check('entire runner differs only by closed version/schema/helper identity', old == new)

for index, gate in enumerate(current.policy['requiredChecks']):
    for mutation in ('remove', 'nonblocking'):
        policy = copy.deepcopy(current.policy)
        if mutation == 'remove':
            policy['requiredChecks'].pop(index)
        else:
            policy['requiredChecks'][index]['blocking'] = False
        r.assert_policy_rejection(current, policy, f'{mutation} {gate["id"]}')
        check(f'reject {mutation} {gate["id"]}', True)
for label, mutate in [
    ('old runner', lambda p: p.update(consumerSmokeRunner=base.policy['consumerSmokeRunner'])),
    ('arbitrary runner path', lambda p: p['consumerSmokeRunner'].update(path='/tmp/custom.py')),
    ('unmatched current hash', lambda p: p['consumerSmokeRunner'].update(sha256='0'*64)),
    ('wrong runtime', lambda p: p['target'].update(runtimeContractVersion='1.2')),
    ('old consumer schema', lambda p: p.update(consumerSmokeReportSchema=base.policy['consumerSmokeReportSchema'])),
]:
    policy = copy.deepcopy(current.policy)
    mutate(policy)
    r.assert_policy_rejection(current, policy, label)
    check('reject ' + label, True)
for directory in (g.TARGET.parent/'v1.1', g.TARGET.parent/'v1.2', Path('/tmp/untrusted-readiness')):
    try:
        r.trusted_contracts(directory)
    except r.ReadinessError:
        check('reject directory ' + str(directory), True)
    else:
        raise AssertionError(directory)

actual = json.loads((ROOT/'tmp/package-v13-assessment-material-ci-repair-20261116/46-current-package-consumer-smoke-report.json').read_bytes())
from jsonschema import Draft202012Validator
check('actual failed legacy report rejected by current consumer identity', bool(list(Draft202012Validator(current.consumer_report_schema).iter_errors(actual))))
check('actual failed legacy report remains failed', actual['status'] == 'failed')
check('all fifteen actual old-runner functional checks passed independently of its failed browser', len(actual['functionalChecks']) == 15 and all(x['result']=='passed' for x in actual['functionalChecks']))

historical = []
paths = subprocess.check_output(['git','ls-files','contracts/curriculum-package/v1','contracts/curriculum-package/v1.1','contracts/curriculum-package/v1.2','scripts/run_package_consumer_smoke.py','scripts/package_consumer_smoke_http.py','scripts/package_consumer_browser_smoke.cjs'], text=True).splitlines()
for path in paths:
    before = subprocess.check_output(['git','show','HEAD:'+path])
    after = (ROOT/path).read_bytes()
    assert before == after, path
    historical.append({'path':path,'bytes':len(after),'sha256':hashlib.sha256(after).hexdigest()})
check('every tracked historical 1.0-1.2 contract and sealed old helper byte identical to HEAD', len(historical)>100)
(OUT/'historical-raw-invariance.actual.json').write_text(json.dumps(historical,indent=2)+'\n')
(OUT/'readiness-probe.actual.json').write_text(json.dumps({'cases':cases,'count':len(cases)},indent=2)+'\n')
print(f'Independent native readiness checks: {len(cases)} cases PASS; {len(historical)} historical raw files unchanged')
