const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),vm=require('node:vm');
const root=path.resolve(__dirname,'../..'),ts=require(path.join(root,'app/node_modules/typescript'));
const sourcePath='app/scripts/buildFullStandaloneCurriculumPackage.ts',raw=fs.readFileSync(path.join(root,sourcePath),'utf8');
const ast=ts.createSourceFile(sourcePath,raw,ts.ScriptTarget.Latest,true),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const names=['SHA256_DIGEST_PATTERN','PACKAGE_PATH_PATTERN','WINDOWS_RESERVED_SEGMENT','compareCodeUnits','fail',
 'objectValue','stringValue','booleanValue','arrayValue','withoutDigestPrefix','assertSafePackagePath','portablePathKey',
 'assertNoSymlinkComponents','resolveRepositoryFile','fileIntegrity','sourceEntry','addEntry',
 'runtimeRequiredFor','mediaTypeForPath','attachManifestFile','manifestAssetDecision'];
const parts=names.map(name=>{const n=ast.statements.find(s=>ts.isVariableStatement(s)&&s.declarationList.declarations.some(d=>d.name.getText(ast)===name));if(!n)throw Error(name);return n.getText(ast)});
let end;function visit(n){if(ts.isExpressionStatement(n)&&n.expression.getText(ast).startsWith('binaryIds.forEach('))end=n;ts.forEachChild(n,visit)}visit(ast);
const start=raw.indexOf('const embeddedResources = arrayValue');if(start<0||!end)throw Error('Native binary-binding block not found');
const block=raw.slice(start,end.end);
const wrapped=parts.join('\n')+`\nconst run=(semanticIndex,buildInputs,resourceItems,review,materialProfile,repositoryRoot,requiredRole)=>{const entries=new Map();const resourceIndex={resources:resourceItems};${block};return entries;};globalThis.native={run,manifestAssetDecision};`;
const box=vm.createContext({...fs,...path,...crypto,Buffer,crc32:require('node:zlib').crc32});
vm.runInContext(ts.transpileModule(wrapped,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText,box);
const native=box.native,read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const model='tmp/package-v13-assessment-material-ci-repair-20261116/model/';
const resources=read(model+'data/resources/resource-index.json').resources.filter(r=>r.resourceKind==='assessment-material');
const ledgerPath='curricula/DE/Gymnasium/quality/package-redistribution/de-gymnasium-mathematik-v1.3.review.json',ledger=read(ledgerPath);
const ids=new Set(resources.map(r=>r.resourceId));
const baseline={semanticIndex:{binaryResources:read(model+'metadata/semantic-content-index.json').binaryResources.filter(x=>ids.has(x.resourceId))},
 buildInputs:{binaryResources:read(model+'metadata/build-inputs.json').binaryResources.filter(x=>ids.has(x.resourceId))},
 resourceItems:resources,review:{assetDecisions:ledger.assetDecisions.filter(x=>ids.has(x.resourceId))}};
const profile=read('contracts/curriculum-package/v1.3/profiles/full-standalone-v1.3.profile.json');
const requiredRole=n=>profile.roles.find(r=>r.role===n);const rows=[];
function pass(name,extra={}){rows.push({name,status:'PASS',...extra});console.log('PASS '+name)}
function run(b=baseline,is13=true){return native.run(b.semanticIndex,b.buildInputs,b.resourceItems,b.review,is13,root,requiredRole)}
function reject(name,mutate,pattern){const b=structuredClone(baseline);mutate(b);try{run(b)}catch(e){if(!pattern.test(e.message))throw e;pass(name,{rejection:e.message});return}throw Error('Accepted '+name)}
const before=JSON.stringify(baseline),entries=run();if(entries.size!==28||JSON.stringify(baseline)!==before)throw Error('Positive corpus/mutation');
for(const entry of entries.values()){const m=entry.manifestFile;if(m.provenanceClass!=='skillpilot-authored'||m.licenseExpression!==null||m.redistributionStatus!=='review-required'||m.runtimeRequired!==true)throw Error('Rights/runtime drift');}
pass('actual28-materials-pass-full-native-ID-path-bytes-hash-media-source-binding-and-projection',{files:28});
const decision=baseline.review.assetDecisions[0],resource=resources.find(r=>r.resourceId===decision.resourceId),original=JSON.stringify(decision);
const projected=native.manifestAssetDecision(decision,resource,true);if(projected===decision||JSON.stringify(decision)!==original)throw Error('Mutation');
if(JSON.stringify({...projected,provenanceClass:decision.provenanceClass})!==original)throw Error('Additional properties changed');
pass('projection-changes-only-provenance-class-without-ledger-mutation-or-rights-upgrade');
for(const d of ledger.assetDecisions.filter(d=>d.provenanceClass!=='skillpilot-authored-assessment-material')){
 if(native.manifestAssetDecision(d,{},false)!==d)throw Error('Other class altered');
}
pass('all836-other-asset-decisions-identity-unchanged');
function helperReject(name,d,r,is13=true){try{native.manifestAssetDecision(d,r,is13)}catch(e){pass(name,{rejection:e.message});return}throw Error('Helper accepted '+name)}
helperReject('helper-rejects-runtime12',decision,resource,false);
for(const [field,value]of[['resourceKind','goal-visualization'],['provider','Other provider'],['delivery','external'],['runtimeRequired',false]])helperReject('helper-rejects-'+field,decision,{...resource,[field]:value});
helperReject('helper-rejects-nonmaterial-path',{...decision,artifactPath:'assets/goal-visualizations/wrong.svg'},resource);
for(const field of['input','resource','decision'])reject('four-way-path-binding-'+field,b=>{
 const id=b.semanticIndex.binaryResources[0].resourceId;
 const row=field==='input'?b.buildInputs.binaryResources.find(x=>x.resourceId===id):field==='resource'?b.resourceItems.find(x=>x.resourceId===id):b.review.assetDecisions.find(x=>x.resourceId===id);row.artifactPath+='-wrong';
},/Binary artifact path mismatch/);
for(const field of['input','resource','decision'])reject('four-way-byte-binding-'+field,b=>{
 const id=b.semanticIndex.binaryResources[0].resourceId;
 const row=field==='input'?b.buildInputs.binaryResources.find(x=>x.resourceId===id):field==='resource'?b.resourceItems.find(x=>x.resourceId===id):b.review.assetDecisions.find(x=>x.resourceId===id);row.bytes++;
},/Binary byte-length mismatch/);
for(const field of['input','resource','decision'])reject('four-way-hash-binding-'+field,b=>{
 const id=b.semanticIndex.binaryResources[0].resourceId;
 const row=field==='input'?b.buildInputs.binaryResources.find(x=>x.resourceId===id):field==='resource'?b.resourceItems.find(x=>x.resourceId===id):b.review.assetDecisions.find(x=>x.resourceId===id);if(field==='decision')row.assetSha256='sha256:'+'0'.repeat(64);else row.sha256='0'.repeat(64);
},/Binary SHA-256 mismatch/);
reject('missing-review-ID-rejected-before-projection',b=>b.review.assetDecisions.pop(),/Binary resource sets differ/);
reject('duplicate-review-ID-rejected-before-projection',b=>b.review.assetDecisions.push(b.review.assetDecisions[0]),/Binary resource IDs must be unique/);
reject('media-type-drift-rejected-before-projection',b=>{const id=b.semanticIndex.binaryResources[0].resourceId;b.resourceItems.find(x=>x.resourceId===id).mediaType='text/html'},/Binary media-type mismatch/);
reject('wrong-existing-original-source-rejected-before-projection',b=>{b.buildInputs.binaryResources[0].sourcePath=b.buildInputs.binaryResources[1].sourcePath},/Binary source bytes drifted/);
const result={at:new Date().toISOString(),status:'PASS_BOUNDED_NATIVE_MANIFEST_ASSET_PROJECTION',caseCount:rows.length,cases:rows,
 sourcePath,sourceSHA256:sha(Buffer.from(raw)),extractedBlockSHA256:sha(Buffer.from(block)),extractedHelperNames:names,
 ledgerSHA256:sha(fs.readFileSync(path.join(root,ledgerPath))),
 method:'Exact current TypeScript AST private helpers and complete four-input binary-binding/application block; real28 resources/semantic records/build inputs/ledger decisions and actual source-file integrity reads. No full ZIP rebuild.',
 prerequisiteBoundary:'Full producer also executes actual redistribution checker before this block. Projection helper does not replace that checker or path/byte/schema validation.',
 wholePackageOrPublicationApproval:false};
fs.writeFileSync(path.join(__dirname,'final-manifest-native-cases.actual.json'),JSON.stringify(result,null,2)+'\n');console.log('PASS cases '+rows.length);
