from pathlib import Path
from types import SimpleNamespace
import copy, datetime, hashlib, json, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import validate_full_standalone_curriculum_package as validator

read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source = ROOT / 'scripts/validate_full_standalone_curriculum_package.py'
source_hash = sha(source)
manifest = read(OUT / 'actual-zip-manifest.raw.json')
review = read(OUT / 'actual-zip-redistributionReview.raw.json')
resources = read(OUT / 'actual-zip-resourceIndex.raw.json')['resources']
material_resources = [r for r in resources if r['resourceKind'] == 'assessment-material']
ids = {r['resourceId'] for r in material_resources}
records = {r['semanticBinding']['resourceId']: r for r in manifest['files']
           if r.get('semanticBinding', {}).get('kind') == 'binary-resource'}
authority = validator.load_trusted_context(ROOT / 'contracts/curriculum-package/v1.3').deterministic_render_authority
baseline = [manifest, {k: v for k, v in records.items() if k in ids},
            {r['resourceId']: r for r in material_resources},
            {**review, 'assetDecisions': [d for d in review['assetDecisions'] if d['resourceId'] in ids]}]
assert len(ids) == len(baseline[1]) == len(baseline[2]) == len(baseline[3]['assetDecisions']) == 28
rows = []
def call(inputs):
    m, rec, res, rev = inputs
    collector = validator.DiagnosticCollector()
    validator.validate_deterministic_render_provenance(SimpleNamespace(manifest=m),
        validator.PackageDocuments(values={validator.REDISTRIBUTION_REVIEW_PATH: rev}),
        rec, res, authority, collector)
    return collector.diagnostics
def passed(name, **extra):
    rows.append({'name': name, 'status': 'PASS', **extra})
    print('PASS', name, flush=True)
before = json.dumps(baseline, sort_keys=True)
assert not call(baseline)
assert json.dumps(baseline, sort_keys=True) == before
passed('actual-ZIP-all28-subtype-ledger-to-general-manifest-bindings-pass-without-input-mutation')
first = sorted(ids)[0]
def decision(value):
    return next(d for d in value[3]['assetDecisions'] if d['resourceId'] == first)
def negative(name, change):
    value = copy.deepcopy(baseline)
    change(value)
    ds = call(value)
    assert ds, name
    passed(name, diagnostics=sorted({d.code for d in ds}))
for name, change in [
    ('wrong-runtime-version', lambda v: v[0].update(runtimeContractVersion='1.2')),
    ('wrong-release-profile', lambda v: v[0].update(releaseProfile='full-standalone-learning-units-v1')),
    ('wrong-resource-kind', lambda v: v[2][first].update(resourceKind='goal-visualization')),
    ('wrong-resource-provider', lambda v: v[2][first].update(provider='Other provider')),
    ('wrong-decision-provider', lambda v: decision(v).update(provider='Other provider')),
    ('wrong-delivery', lambda v: v[2][first].update(delivery='external')),
    ('optional-material', lambda v: v[2][first].update(runtimeRequired=False)),
    ('wrong-resource-ID', lambda v: v[2][first].update(resourceId='forged-resource')),
    ('wrong-owner', lambda v: v[2][first].update(ownerGoalId='forged-owner')),
    ('wrong-decision-owner', lambda v: decision(v).update(ownerGoalId='forged-owner')),
    ('wrong-public-URL', lambda v: v[2][first].update(publicUrl='/assets/assessment-materials/other.svg')),
    ('wrong-resource-path', lambda v: v[2][first].update(artifactPath='assets/assessment-materials/other.svg')),
    ('wrong-media-type', lambda v: v[2][first].update(mediaType='text/html')),
    ('wrong-byte-count', lambda v: v[2][first].update(bytes=v[2][first]['bytes'] + 1)),
    ('wrong-resource-hash', lambda v: v[2][first].update(sha256='0' * 64)),
    ('wrong-decision-hash', lambda v: decision(v).update(assetSha256='sha256:' + '0' * 64)),
    ('wrong-provenance-source', lambda v: decision(v).update(provenanceSource='unbound-claim')),
    ('forged-uploader-claim', lambda v: decision(v).update(userProvided=True)),
    ('rights-status-upgrade', lambda v: decision(v).update(redistributionStatus='allowed')),
    ('license-upgrade', lambda v: decision(v).update(licenseExpression='Apache-2.0')),
    ('wrong-manifest-class', lambda v: v[1][first].update(provenanceClass='third-party')),
]:
    negative('native-asset-binding-rejects-' + name, change)

legacy = next(d for d in review['assetDecisions'] if d['resourceId'] not in ids
              and d['resourceId'] != authority.resource_id
              and d['provenanceClass'] != validator.DETERMINISTIC_RENDER_PROVENANCE_CLASS)
legacy_id = legacy['resourceId']
legacy_inputs = [manifest, {legacy_id: records[legacy_id]},
                 {legacy_id: next(r for r in resources if r['resourceId'] == legacy_id)},
                 {**review, 'assetDecisions': [legacy]}]
assert not call(legacy_inputs)
passed('actual-other-legacy-provenance-class-still-valid-without-projection')
forged = copy.deepcopy(legacy_inputs)
forged[3]['assetDecisions'][0]['provenanceClass'] = 'third-party' if legacy['provenanceClass'] != 'third-party' else 'skillpilot-authored'
assert any(d.code == 'REDISTRIBUTION_ASSET_BINDING_MISMATCH' for d in call(forged))
passed('other-provenance-class-mismatch-remains-strictly-rejected')
assert sha(source) == source_hash
report = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'PASS_BOUNDED_NATIVE_ASSET_BYTES_EXPECTATION_PROJECTION',
          'sourcePath': str(source.relative_to(ROOT)), 'sourceSHA256': source_hash,
          'caseCount': len(rows), 'cases': rows, 'inputDrift': [],
          'method': 'Direct actual validate_deterministic_render_provenance API on actual28 source/index/manifest/ledger tuples selected from the real ZIP; explicit28-resource subset for isolated binding tests, plus one actual legacy tuple. No full ZIP/schema/rights approval is inferred.',
          'unchangedRightsAndLicenseFieldsCompared': True,
          'onlyExpectedProvenanceClassProjectedForExact13Tuple': True,
          'sourceWrites': False, 'fullZipValidationReplayed': False}
(OUT / 'final-asset-reader-native-cases.actual.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS cases', len(rows), flush=True)
