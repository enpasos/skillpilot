from pathlib import Path
import copy, datetime, hashlib, json, os, sys, zipfile
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import curriculum_package_v13_contracts as contracts
import validate_curriculum_runtime_catalog_contract as runtime
import validate_curriculum_schema_catalog_contract as schema_catalog
from validate_full_standalone_curriculum_package import load_trusted_context

sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
source_paths = ['scripts/validate_curriculum_runtime_catalog_contract.py',
                'scripts/validate_curriculum_schema_catalog_contract.py']
pins = [{'path': p, 'sha256': sha((ROOT / p).read_bytes())} for p in source_paths]
archive_receipt = read(ROOT / 'tmp/package-v13-assessment-material-ci-repair-20261116/34-archive-reuse.actual.json')
archive = Path(archive_receipt['finalZip'])
selection = {}
with archive.open('rb') as stream:
    before = os.fstat(stream.fileno())
    with zipfile.ZipFile(stream) as package:
        for label, suffix in [('manifest', '/metadata/manifest.json'),
                              ('schemaCatalog', '/schemas/catalog.json'),
                              ('runtimeCatalog', '/data/runtime/catalog.json'),
                              ('resourceIndex', '/data/resources/resource-index.json'),
                              ('redistributionReview', '/metadata/provenance/redistribution-review.json')]:
            names = [n for n in package.namelist() if n.endswith(suffix)]
            assert len(names) == 1
            raw = package.read(names[0])
            selection[label] = {'entry': names[0], 'bytes': len(raw), 'sha256': sha(raw)}
            (OUT / ('actual-zip-' + label + '.raw.json')).write_bytes(raw)
        after = os.fstat(stream.fileno())
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
manifest = read(OUT / 'actual-zip-manifest.raw.json')
catalog = read(OUT / 'actual-zip-schemaCatalog.raw.json')
catalog_bytes = (OUT / 'actual-zip-schemaCatalog.raw.json').read_bytes()
actual_runtime = read(OUT / 'actual-zip-runtimeCatalog.raw.json')
trusted = load_trusted_context(ROOT / 'contracts/curriculum-package/v1.3')
validators = contracts.validators(ROOT)
rows = []
def passed(name, **extra):
    rows.append({'name': name, 'status': 'PASS', **extra})
    print('PASS', name, flush=True)
def reject_runtime(name, value, validator_id):
    diagnostics = runtime.validate_catalog(value, validators[validator_id])
    assert diagnostics, name
    passed(name, diagnostics=sorted({d.code for d in diagnostics}))

raw_actual = runtime.validate_catalog(actual_runtime, validators[contracts.CATALOG_SCHEMA_ID])
assert {d.code for d in raw_actual} == {'EXAM_NODES_UNVERIFIED'}
passed('actual-ZIP-new-version-capability-checks-have-only-preexisting-catalog-only-exam-warning',
       diagnostics=sorted({d.code for d in raw_actual}),
       boundary='Existing full-package wrapper separately checks schema-valid examData payloads and exact examNodes capability; the catalog-only warning is preserved here, not waived in source.')
assert not schema_catalog.validate_catalog_against_manifest(catalog, catalog_bytes, manifest, trusted.trusted_schema_bytes)
passed('actual-ZIP-schema-catalog-native-manifest-and-bootstrap-bindings-pass')

legacy = read(ROOT / 'contracts/curriculum-package/v1/fixtures/runtime-catalog/valid/minimal-mathematik.catalog.json')
assert not runtime.validate_catalog(legacy, validators[legacy['$schema']])
passed('original-minimal-runtime10-remains-valid')
sample = copy.deepcopy(legacy)
sample.update({'$schema': contracts.CATALOG_SCHEMA_ID, 'catalogVersion': '1.3',
               'runtimeContractVersion': '1.3', 'learningUnitReviews': []})
sample['capabilities'].extend(['learningUnitsV1', 'assessmentMaterialsV1'])
assert not runtime.validate_catalog(sample, validators[contracts.CATALOG_SCHEMA_ID])
passed('runtime13-empty-review-and-material-collections-still-declare-contract-capabilities')
for cap in ['learningUnitsV1', 'assessmentMaterialsV1']:
    value = copy.deepcopy(sample); value['capabilities'].remove(cap)
    reject_runtime('runtime13-rejects-missing-' + cap, value, contracts.CATALOG_SCHEMA_ID)
    value = copy.deepcopy(legacy); value['capabilities'].append(cap)
    reject_runtime('runtime10-rejects-forged-' + cap, value, legacy['$schema'])
value = copy.deepcopy(sample); value.update(runtimeContractVersion='1.2')
reject_runtime('runtime13-schema-rejects-wrong-runtime-version', value, contracts.CATALOG_SCHEMA_ID)
value = copy.deepcopy(sample); value['learningUnitReviews'] = None
reject_runtime('runtime13-rejects-nonarray-learning-unit-reviews', value, contracts.CATALOG_SCHEMA_ID)
value = copy.deepcopy(sample); value['capabilities'].append('assessmentCompletionV1')
reject_runtime('runtime13-does-not-enable-superseded-completion11-capability', value, contracts.CATALOG_SCHEMA_ID)
value = copy.deepcopy(sample); value['capabilities'].append('inventedCapability')
reject_runtime('runtime13-rejects-unknown-capability', value, contracts.CATALOG_SCHEMA_ID)

for name, mutation in [
    ('wrong-version', lambda m: m.update(runtimeContractVersion='1.2')),
    ('wrong-profile', lambda m: m.update(releaseProfile='full-standalone-v1')),
    ('wrong-schema-hash', lambda m: m['contractBindings']['runtimeCatalogSchema'].update(sha256='0' * 64)),
    ('wrong-schema-ID', lambda m: m['contractBindings']['runtimeCatalogSchema'].update(id='https://skillpilot.com/schemas/curriculum-package/v1/runtime-catalog.schema.json')),
    ('missing-schema-binding', lambda m: m['contractBindings'].pop('runtimeCatalogSchema')),
]:
    value = copy.deepcopy(manifest); mutation(value)
    diagnostics = schema_catalog.validate_catalog_against_manifest(catalog, catalog_bytes, value, trusted.trusted_schema_bytes)
    assert diagnostics, name
    passed('actual-schema-binding-rejects-' + name, diagnostics=sorted({d.code for d in diagnostics}))
without13 = {k: v for k, v in trusted.trusted_schema_bytes.items() if k != contracts.CATALOG_SCHEMA_ID}
diagnostics = schema_catalog.validate_catalog_against_manifest(catalog, catalog_bytes, manifest, without13)
assert diagnostics
passed('actual-schema-binding-cannot-grant13-without13-bootstrap-schema', diagnostics=sorted({d.code for d in diagnostics}))

drift = [p['path'] for p in pins if sha((ROOT / p['path']).read_bytes()) != p['sha256']]
assert not drift
report = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'PASS_BOUNDED_NATIVE_RUNTIME_AND_SCHEMA_CATALOG_READER_DELTA',
          'caseCount': len(rows), 'cases': rows, 'sourcePins': pins, 'inputDrift': drift,
          'actualZipMetadataSelection': {'path': str(archive), 'archiveBytes': before.st_size,
              'parentRecordedArchiveSHA256': archive_receipt['sha256'],
              'selectedEntries': selection, 'selectedArchiveFileDescriptorStable': True,
              'wholeArchiveRehashed': False},
          'method': 'Actual selected metadata from the existing real ZIP plus own in-memory negative version/profile/capability/hash mutations; direct unchanged native validator APIs. Legacy minimal fixture separately identified.',
          'wholeZipConsumerPipelineOrRightsApprovalClaimed': False, 'sourceWrites': False}
(OUT / 'final-reader-native-cases.actual.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS cases', len(rows), flush=True)
