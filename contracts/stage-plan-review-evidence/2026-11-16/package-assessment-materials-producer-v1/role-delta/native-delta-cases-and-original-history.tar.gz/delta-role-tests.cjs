const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '../..');
const ts = require(path.join(root, 'app/node_modules/typescript'));
const sourcePath = path.join(root, 'app/scripts/buildFullStandaloneCurriculumPackage.ts');
const raw = fs.readFileSync(sourcePath, 'utf8');
const source = ts.createSourceFile(sourcePath, raw, ts.ScriptTarget.Latest, true);
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const names = ['compareCodeUnits', 'fail', 'runtimeRequiredFor', 'mediaTypeForPath',
  'assertDecisionState', 'assertRedistributionReviewDerivedState', 'decisionClassifier', 'attachManifestFile'];
const declarations = [];
for (const name of names) {
  const node = source.statements.find(s => ts.isVariableStatement(s)
    && s.declarationList.declarations.some(d => d.name.getText(source) === name));
  if (!node) throw Error('Missing native variable: ' + name);
  declarations.push(node.getText(source));
}
let branch;
function visit(node) {
  if (ts.isIfStatement(node) && node.expression.getText(source) === 'assessmentByPath.has(path)') branch = node;
  ts.forEachChild(node, visit);
}
visit(source);
if (!branch) throw Error('Actual native assessment input branch not found');
const body = `if (${branch.expression.getText(source)}) ${branch.thenStatement.getText(source)} else fail('not a bound assessment input');`;
const wrapper = `const runNativeSourceBranch=(path, entry, assessmentByPath, consumedAssessmentPaths, materialProfile, requiredRole, classify)=>{${body};return entry;};`;
const typescript = declarations.join('\n') + '\n' + wrapper
  + '\nglobalThis.native = {decisionClassifier, runNativeSourceBranch};';
const sandbox = vm.createContext({ basename: path.basename });
vm.runInContext(ts.transpileModule(typescript, {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
}).outputText, sandbox);
const native = sandbox.native;
const read = p => JSON.parse(fs.readFileSync(path.join(root, p), 'utf8'));
const ledgerPath = 'curricula/DE/Gymnasium/quality/package-redistribution/de-gymnasium-mathematik-v1.3.review.json';
const profilePath = 'contracts/curriculum-package/v1.3/profiles/full-standalone-v1.3.profile.json';
const model = 'tmp/package-v13-assessment-material-ci-repair-20261116/model/';
const review = read(ledgerPath), profile = read(profilePath);
const build = read(model + 'metadata/build-inputs.json');
const exact = 'data/assessment-sources/stage-plan-direct-evidence-20261115-v7/reviewed-assessments.json';
const second = 'data/assessment-sources/task64-digital-correction-20261115-v1/reviewed-assessment.json';
const exactPaths = [exact, second].sort();
const actualJsonPaths = build.assessmentSources.filter(x => x.artifactPath.endsWith('.json')).map(x => x.artifactPath).sort();
if (JSON.stringify(actualJsonPaths) !== JSON.stringify(exactPaths)) throw Error('Actual JSON author-source inventory is not exactly the two allowlisted paths');
const expected = build.assessmentSources.find(x => x.artifactPath === exact);
if (!expected) throw Error('Exact source missing from actual hashed build input');
const original = fs.readFileSync(path.join(root, model, exact));
if (sha(original) !== expected.sha256 || original.length !== expected.bytes) throw Error('Actual model source bytes do not match build input');
const classify = native.decisionClassifier(review, 76);
const requiredRole = name => { const role = profile.roles.find(r => r.role === name); if (!role) throw Error(name); return role; };
const rows = [];
function pass(name, detail = {}) { rows.push({ name, status: 'PASS', ...detail }); console.log('PASS ' + name); }
function reject(name, f, pattern) { try { f(); } catch (e) { if (!pattern.test(e.message)) throw e; pass(name, { rejection: e.message }); return; } throw Error('Accepted invalid case: ' + name); }
function run(p = exact, isV13 = true, expectedOverrides = {}, entryOverrides = {}, bound = true) {
  const matching = build.assessmentSources.find(x => x.artifactPath === p) ?? expected;
  const entry = { relativePath: p, bytes: matching.bytes, sha256: matching.sha256, ...entryOverrides };
  const map = bound ? new Map([[p, { ...matching, artifactPath: p, ...expectedOverrides }]]) : new Map();
  return native.runNativeSourceBranch(p, entry, map, new Set(), isV13, requiredRole, classify);
}
const entry = run();
if (entry.manifestFile.role !== 'provenance-report' || entry.manifestFile.mediaType !== 'application/json'
  || entry.manifestFile.runtimeRequired !== false || entry.manifestFile.provenanceClass !== 'skillpilot-authored'
  || entry.manifestFile.redistributionStatus !== 'review-required' || entry.manifestFile.licenseExpression !== null
  || entry.manifestFile.semanticBinding.kind !== 'excluded-generated'
  || entry.manifestFile.sha256 !== sha(original)) throw Error('Incorrect JSON author-source manifest');
pass('actual-exact-bound-JSON-source-manifest-remains-content-and-pending', { manifest: entry.manifestFile });
const secondInput = build.assessmentSources.find(x => x.artifactPath === second);
const secondBytes = fs.readFileSync(path.join(root, model, second));
if (secondBytes.length !== secondInput.bytes || sha(secondBytes) !== secondInput.sha256) throw Error('Second actual JSON source bytes differ');
const secondEntry = run(second);
if (secondEntry.manifestFile.role !== 'provenance-report' || secondEntry.manifestFile.mediaType !== 'application/json'
  || secondEntry.manifestFile.redistributionStatus !== 'review-required' || secondEntry.manifestFile.licenseExpression !== null
  || secondEntry.manifestFile.provenanceClass !== 'skillpilot-authored' || secondEntry.manifestFile.runtimeRequired !== false) throw Error('Second source classification changed rights/runtime');
pass('second-exact-actual-JSON-source-manifest-and-complete-two-file-inventory', { manifest: secondEntry.manifestFile });
reject('second-JSON-source-inactive-lane-rejected', () => run(second, false), /package-documentation does not permit application\/json/);
reject('second-JSON-source-byte-drift-rejected', () => run(second, true, { bytes: secondInput.bytes + 1 }), /Assessment source drift/);
reject('second-JSON-similar-path-rejected', () => run(second + '.backup.json'), /package-documentation does not permit application\/json/);
reject('older-runtime-cannot-use-new-JSON-role', () => run(exact, false), /package-documentation does not permit application\/json/);
reject('exact-file-not-in-build-input-rejected', () => run(exact, true, {}, {}, false), /not a bound assessment input/);
reject('expected-byte-count-drift-rejected', () => run(exact, true, { bytes: expected.bytes + 1 }), /Assessment source drift/);
reject('expected-source-hash-drift-rejected', () => run(exact, true, { sha256: '0'.repeat(64) }), /Assessment source drift/);
reject('actual-source-hash-drift-rejected', () => run(exact, true, {}, { sha256: '0'.repeat(64) }), /Assessment source drift/);
for (const alternative of [exact + '.backup.json', exact + '/child.json', exact.replace('20261115-v7', '20261115-v8'),
  exact.replace('reviewed-assessments', 'reviewed-assessment')]) {
  reject('similar-JSON-path-cannot-enter-exact-role:' + alternative, () => run(alternative), /package-documentation does not permit application\/json/);
  const decision = classify('provenance-report', alternative);
  if (decision.classId === 'skillpilot-data') throw Error('Exact override prefix-matched similar path');
  pass('similar-provenance-path-does-not-get-file-override:' + alternative, { fallbackClass: decision.classId });
}
const markdown = build.assessmentSources.find(x => x.artifactPath.endsWith('.md'));
const mdEntry = native.runNativeSourceBranch(markdown.artifactPath,
  { relativePath: markdown.artifactPath, bytes: markdown.bytes, sha256: markdown.sha256 },
  new Map([[markdown.artifactPath, markdown]]), new Set(), true, requiredRole, classify);
if (mdEntry.manifestFile.role !== 'package-documentation' || mdEntry.manifestFile.provenanceClass !== 'skillpilot-authored') throw Error('Markdown role was broadened');
pass('normal-markdown-source-keeps-original-text-only-role');
const metadata = classify('provenance-report', 'metadata/build-inputs.json');
if (metadata.classId !== 'generated-metadata') throw Error('Technical provenance JSON classification changed from the actual prior policy');
pass('technical-provenance-metadata-classification-unchanged');
const broadened = structuredClone(review);
broadened.pathClassificationOverrides[1].pathPrefix = 'data/assessment-sources/';
reject('broadened-directory-override-rejected-by-native-closed-policy',
  () => native.decisionClassifier(broadened, 76), /overrides differ from the closed package policy/);
const legacy = structuredClone(review);
legacy.targetReleaseProfile.profileId = 'full-standalone-learning-units-v1';
reject('new-file-override-not-accepted-in-runtime12-review',
  () => native.decisionClassifier(legacy, 76), /overrides differ from the closed package policy/);

const result = { at: new Date().toISOString(), status: 'PASS_EXACT_NATIVE_ROLE_CLASSIFICATION_DELTA',
  method: 'TypeScript AST extracts exact current private helpers and exact assessment-source branch; real current ledger, target profile and actual byte-bound model source. No source edits and no duplicate full package/ZIP build.',
  sourcePath: path.relative(root, sourcePath), sourceSHA256: sha(Buffer.from(raw)),
  extractedHelpers: names, extractedBranchSHA256: sha(Buffer.from(body)),
  extractedBranch: body, ledgerSHA256: sha(fs.readFileSync(path.join(root, ledgerPath))),
  profileSHA256: sha(fs.readFileSync(path.join(root, profilePath))), caseCount: rows.length, cases: rows,
  fullPackageOrConsumerApprovalClaimed: false };
fs.writeFileSync(path.join(__dirname, 'delta-role-native-cases.actual.json'), JSON.stringify(result, null, 2) + '\n');
console.log('PASS cases ' + rows.length);
