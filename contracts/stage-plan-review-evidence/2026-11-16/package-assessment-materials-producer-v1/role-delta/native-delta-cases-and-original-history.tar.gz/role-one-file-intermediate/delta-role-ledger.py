from pathlib import Path
import copy, datetime, hashlib, importlib.util, json, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import generate_curriculum_package_redistribution_review as current
import generate_curriculum_package_v13_contracts as generator

read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
oldroot = OUT / 'epoch1-source-snapshot'
oldpath = oldroot / 'scripts/generate_curriculum_package_redistribution_review.py'
spec = importlib.util.spec_from_file_location('original_redistribution_epoch1', oldpath)
original = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = original
spec.loader.exec_module(original)
checks = []
def passed(name, **kw):
    checks.append({'name': name, 'status': 'PASS', **kw})
    print('PASS', name, flush=True)

assert current.CLASS_SPECS == original.CLASS_SPECS
assert current.PATH_CLASSIFICATION_OVERRIDES == original.PATH_CLASSIFICATION_OVERRIDES
passed('fresh-import-default-policy-identical-to-epoch1')
current.select_runtime_v13_candidate()
original.select_runtime_v13_candidate()
assert current.CLASS_SPECS == original.CLASS_SPECS
assert list(current.PATH_CLASSIFICATION_OVERRIDES[:-1]) == list(original.PATH_CLASSIFICATION_OVERRIDES)
exact = 'data/assessment-sources/stage-plan-direct-evidence-20261115-v7/reviewed-assessments.json'
assert current.PATH_CLASSIFICATION_OVERRIDES[-1] == {
    'role': 'provenance-report', 'pathPrefix': exact,
    'classId': 'skillpilot-data', 'provenanceClass': 'skillpilot-authored'}
passed('only-runtime13-adds-one-exact-content-file-override')

ledger_path = ROOT / 'curricula/DE/Gymnasium/quality/package-redistribution/de-gymnasium-mathematik-v1.3.review.json'
review = read(ledger_path)
old = read(oldroot / 'curricula/DE/Gymnasium/quality/package-redistribution/de-gymnasium-mathematik-v1.3.review.json')
actual_without_override = copy.deepcopy(review)
actual_without_override['pathClassificationOverrides'].pop()
assert actual_without_override == old
passed('actual-ledger-delta-only-one-override-all864-asset-decisions-byte-value-unchanged')
assert review['summary']['publicationReady'] is False
assert review['summary']['pendingAssetCount'] == 864
assert review['summary']['pendingClassCount'] == 3
assert review['summary']['automaticAllowedClassCount'] == 1
assert review['summary']['humanApprovedAssetCount'] == review['summary']['humanApprovedClassCount'] == 0
passed('source-role-fix-does-not-grant-rights-or-publication')

model = ROOT / 'tmp/package-v13-assessment-material-ci-repair-20261116/model'
source = current.load_source_model(model)
schema_path = ROOT / 'contracts/curriculum-package/v1.3/package-redistribution-review.schema.json'
schema = read(schema_path)
assert not current.validate_review(review, source, schema)
passed('actual-current-ledger-validates-against-current-source-model-and-schema')
expected = generator.generated()[schema_path]
assert schema_path.read_bytes() == expected
passed('current-review-schema-is-exact-generator-output')

for name, mutation in [
    ('similar-file', lambda o: o.update(pathPrefix=exact + '.backup.json')),
    ('directory-broadening', lambda o: o.update(pathPrefix='data/assessment-sources/')),
    ('different-directory', lambda o: o.update(pathPrefix=exact.replace('20261115-v7', '20261115-v8'))),
    ('foreign-class', lambda o: o.update(classId='generated-metadata')),
    ('foreign-provenance', lambda o: o.update(provenanceClass='software-contract')),
    ('wrong-role', lambda o: o.update(role='package-documentation')),
]:
    value = copy.deepcopy(review)
    mutation(value['pathClassificationOverrides'][-1])
    codes = sorted({d.code for d in current.validate_review(value, source, schema)})
    assert 'PATH_CLASSIFICATION_OVERRIDE_DRIFT' in codes and 'SCHEMA' in codes, (name, codes)
    passed('native-review-rejects-' + name, diagnostics=codes)
missing = copy.deepcopy(review)
missing['pathClassificationOverrides'].pop()
assert 'PATH_CLASSIFICATION_OVERRIDE_DRIFT' in {d.code for d in current.validate_review(missing, source, schema)}
passed('native-review-rejects-missing-exact-source-classification')

old_contracts = read(OUT / 'historical-contract-invariance.actual.json')['files']
assert all(sha(ROOT / e['path']) == e['currentSHA256'] for e in old_contracts)
passed('all127-historical-contract-and-ledger-files-still-byte-identical')
priorpins = read(OUT / 'input-pins.final-revision.actual.json')['pins']
preserved = [e for e in priorpins if '/model/' in e['path']
             or e['path'].endswith('.profile.json')
             or e['path'] in ['scripts/compile_curriculum_release_model.py', 'scripts/validate_curriculum_release_model.py']]
assert all(sha(ROOT / e['path']) == e['sha256'] for e in preserved)
passed('all-actual-model-build-profile-target-profile-compiler-validator-bytes-unchanged', files=len(preserved))

paths = ['app/scripts/buildFullStandaloneCurriculumPackage.ts',
         'scripts/generate_curriculum_package_redistribution_review.py',
         'scripts/generate_curriculum_package_v13_contracts.py',
         'contracts/curriculum-package/v1.3/package-redistribution-review.schema.json',
         str(ledger_path.relative_to(ROOT))]
report = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'PASS_BOUNDED_ROLE_AND_LICENSE_CLASSIFICATION_DELTA',
          'caseCount': len(checks), 'checks': checks,
          'inputPins': [{'path': p, 'sha256': sha(ROOT / p)} for p in paths],
          'contentDigest': review['contentDigest'],
          'sourceWrites': False, 'fullPackageBuildOrConsumerReplayClaimed': False}
(OUT / 'delta-role-ledger-cases.actual.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS cases', len(checks), flush=True)
