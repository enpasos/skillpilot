from pathlib import Path
import collections, copy, datetime, gzip, hashlib, json, re, sys, time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import curriculum_package_v13_contracts as contracts
import curriculum_assessment_materials as svg
import generate_curriculum_package_redistribution_review as redistribution
import validate_curriculum_release_model as validator
import compile_curriculum_release_model as compiler

MODEL = ROOT / "tmp/package-v13-assessment-material-ci-repair-20261116/model"
PROFILE = ROOT / "contracts/curriculum-package/v1.3/profiles/de-gymnasium-mathematik-release-model-v1.3.profile.json"
LEDGER = ROOT / "curricula/DE/Gymnasium/quality/package-redistribution/de-gymnasium-mathematik-v1.3.review.json"
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
results = []

def passed(name, **extra):
    results.append({"name": name, "status": "PASS", **extra})
    print("PASS", name, flush=True)

def reject(name, function, exceptions=(ValueError, validator.ValidationError, redistribution.ReviewError)):
    try:
        function()
    except exceptions as error:
        passed(name, rejection=str(error)[:500], exception=type(error).__name__)
    else:
        raise AssertionError("Adversarial mutation accepted: " + name)

profile = read(PROFILE)
source_goals = read(ROOT / profile["canonicalLandscape"]["sourcePath"])["goals"]
source_by_id = {g["id"]: g for g in source_goals}
resource_index = read(MODEL / "data/resources/resource-index.json")
materials = [r for r in resource_index["resources"] if r["resourceKind"] == "assessment-material"]
build_inputs = read(MODEL / "metadata/build-inputs.json")
declarations = profile["resources"]["assessmentMaterials"]
decl_by_url = {r["url"]: r for r in declarations}
material_by_url = {r["publicUrl"]: r for r in materials}

# Independent traversal of actual DE/EN task bodies. No producer helper is used.
uses = []
for g in source_goals:
    by_url = collections.defaultdict(list)
    for field in ("taskContent", "taskContentEn"):
        body = g.get("examData", {}).get(field)
        if not isinstance(body, str):
            continue
        tokens = re.findall(r"/assets/assessment-materials/[^\s)\"'<>]+", body)
        for url in sorted(set(tokens)):
            assert re.fullmatch(r"/assets/assessment-materials/[A-Za-z0-9._/-]+\.(svg|png)", url), url
            assert g["examData"]["reviewStatus"] == "released"
            by_url[url].append(field)
    for url, fields in sorted(by_url.items()):
        uses.append({"goalId": g["id"], "url": url, "taskFields": fields,
                     "resourceId": material_by_url[url]["resourceId"]})
uses.sort(key=lambda x: (x["url"], x["goalId"]))
assert uses == build_inputs["assessmentMaterialUses"]
assert len(uses) == 31 and len(materials) == len(declarations) == 28
assert set(material_by_url) == set(decl_by_url) == {u["url"] for u in uses}
assert collections.Counter(m["mediaType"] for m in materials) == {"image/svg+xml": 18, "image/png": 10}
passed("independent-actual-DE-EN-body-use-inventory", uniqueFiles=28, taskUrlPairs=31,
       svgFiles=18, pngFiles=10, svgUses=19, pngUses=12)

for material in materials:
    url = material["publicUrl"]
    declaration = decl_by_url[url]
    owner = material["ownerGoalId"]
    task_users = sorted({u["goalId"] for u in uses if u["url"] == url})
    assert owner in source_by_id and owner in task_users
    assert material["landscapeId"] == "68a8ac50-f5f5-4e24-8aa9-5e408ca01ced"
    assert material["artifactPath"] == url[1:]
    assert material["delivery"] == "embedded" and material["runtimeRequired"] is True
    original = ROOT / "app/public" / url[1:]
    assert original.stat().st_size == material["bytes"] == declaration["bytes"]
    assert sha(original) == material["sha256"] == declaration["sha256"]
    assert sha(ROOT / declaration["sourceArtifactPath"]) == declaration["sourceArtifactSha256"]
    assert source_by_id[owner]["examData"]["sourceArtifactPath"] == declaration["sourceArtifactPath"]
    assert material["license"] == "CC-BY-4.0" and material["provider"] == "SkillPilot"
    if material["mediaType"] == "image/svg+xml":
        content = original.read_bytes()
        svg.validate_static_assessment_svg(content)
        assert sha(original) == hashlib.sha256(content).hexdigest()
    else:
        assert validator.image_media_type(original) == "image/png"
passed("all28-byte-exact-originals-and-owned-source-bindings")

validators = contracts.validators(ROOT)
assert not list(validators[contracts.RESOURCE_SCHEMA_ID].iter_errors(resource_index))
catalog_path = MODEL / "data/runtime/catalog.json"
catalog = read(catalog_path)
assert not list(validators[contracts.CATALOG_SCHEMA_ID].iter_errors(catalog))
material_index = next(i for i, r in enumerate(resource_index["resources"])
                      if r["resourceKind"] == "assessment-material")
for name, mutation in [
    ("material-external-delivery", lambda r: r.update(delivery="external", runtimeRequired=False)),
    ("material-false-runtime-required", lambda r: r.update(runtimeRequired=False)),
    ("material-external-url-injection", lambda r: r.update(externalUrl="https://example.invalid/a.svg")),
    ("material-script-media", lambda r: r.update(mediaType="text/javascript")),
    ("material-unknown-authority-field", lambda r: r.update(rightsApproved=True)),
]:
    value = copy.deepcopy(resource_index)
    mutation(value["resources"][material_index])
    assert list(validators[contracts.RESOURCE_SCHEMA_ID].iter_errors(value)), name
    passed("schema-rejects-" + name)
old_index = copy.deepcopy(resource_index)
old_index["$schema"] = "https://skillpilot.com/schemas/curriculum-package/v1/resource-index.schema.json"
old_index["indexFormatVersion"] = "1.0"
assert list(validators[old_index["$schema"]].iter_errors(old_index))
passed("historical-v1-resource-schema-does-not-accept-new-material-lane")
for name, mutation in [
    ("missing-material-capability", lambda c: c["capabilities"].remove("assessmentMaterialsV1")),
    ("wrong-runtime-version", lambda c: c.update(runtimeContractVersion="1.2")),
    ("unknown-capability", lambda c: c["capabilities"].append("arbitraryMaterials")),
]:
    value = copy.deepcopy(catalog)
    mutation(value)
    assert list(validators[contracts.CATALOG_SCHEMA_ID].iter_errors(value)), name
    passed("schema-rejects-" + name)

for name, body in [
    ("external-fill", '<rect fill="url(https://example.invalid/x)"/>'),
    ("escaped-external-fill", '<rect fill="u\\72l(https://example.invalid/x)"/>'),
    ("escaped-external-filter", '<g filter="\\75rl(https://example.invalid/x)"/>'),
    ("foreign-xhtml-refresh", '<meta xmlns="http://www.w3.org/1999/xhtml" http-equiv="refresh" content="0;url=https://example.invalid/"/>'),
    ("svg-tiny-handler", '<handler type="application/ecmascript">alert(1)</handler>'),
    ("metadata-xhtml", '<metadata><meta xmlns="http://www.w3.org/1999/xhtml"/></metadata>'),
    ("external-image", '<image href="https://example.invalid/x.png"/>'),
    ("event-attribute", '<rect onload="alert(1)"/>'),
    ("css-import", '<style>@import "https://example.invalid/x.css";</style>'),
]:
    reject("python-svg-rejects-" + name,
           lambda body=body: svg.validate_static_assessment_svg(
               ('<svg xmlns="http://www.w3.org/2000/svg">' + body + '</svg>').encode()))
for label, body in [("nonreleased", "/assets/assessment-materials/math/x.svg"),
                    ("unsupported-gif", "/assets/assessment-materials/math/x.gif"),
                    ("query-alias", "/assets/assessment-materials/math/x.svg?x=1")]:
    goal = {"id": "probe", "examData": {"reviewStatus": "draft" if label == "nonreleased" else "released",
                                         "taskContent": body}}
    reject("task-use-reader-rejects-" + label,
           lambda goal=goal: contracts.task_material_uses([goal]))
reject("missing-native-source-asset", lambda: redistribution.verify_asset_source(
    "tmp/pr159-package13-producer-independent-review-20261116/no-such-material.svg", 1, "0" * 64))
reject("wrong-native-source-asset-hash", lambda: redistribution.verify_asset_source(
    "app/public" + materials[0]["publicUrl"], materials[0]["bytes"], "0" * 64))
reject("compiler-rejects-public-root-escape", lambda: compiler.safe_join(ROOT / "app/public", "../private.svg"),
       exceptions=(compiler.CompilationError, ValueError))

# Reconstruct the expected model using the real independent validator. No model writes.
context = validator.load_trusted_context(PROFILE)
expected = validator.build_expected_model(context, MODEL)
validator.complete_expected_model(context, expected)
documents = validator.validate_output_files(context, expected)
validator.validate_cross_document_integrity(context, expected, documents)
passed("actual-v13-model-independent-trusted-reconstruction-and-cross-document-check",
       contentDigest=expected["contentDigest"])
compiled_goals = {g["id"]: g for g in documents[expected["landscapePath"]]["goals"]}
for use in uses:
    for field in use["taskFields"]:
        assert compiled_goals[use["goalId"]]["examData"][field] == source_by_id[use["goalId"]]["examData"][field]
passed("all31-original-DE-EN-task-stimulus-body-references-byte-value-preserved")
closure = documents[expected["closurePath"]]
material_ids = {m["resourceId"] for m in materials}
assert material_ids <= {x["id"] for x in closure["seeds"] if x["kind"] == "resource"}
assert material_ids <= {x["key"]["id"] for x in closure["definitions"] if x["key"]["kind"] == "resource"}
assert closure["externalRuntimeDependencies"] == [] and closure["unresolvedHardReferences"] == []
passed("material-payload-roots-in-actual-closed-owned-resource-graph",
       boundary="Package payload roots, not pedagogical prerequisites or learner results.")
mutation = copy.deepcopy(closure)
mutation["definitions"] = [x for x in mutation["definitions"]
                           if x["key"] != {"kind": "resource", "id": materials[0]["resourceId"]}]
reject("closure-missing-required-material-definition", lambda: validator.validate_closure_integrity(
    mutation, context, expected, documents))
mutation2 = copy.deepcopy(closure)
mutation2["seeds"].append({"kind": "resource", "id": "task-material:unowned-orphan"})
reject("closure-unowned-orphan-resource-root", lambda: validator.validate_closure_integrity(
    mutation2, context, expected, documents))

redistribution.select_runtime_v13_candidate()
source = redistribution.load_source_model(MODEL)
ledger = read(LEDGER)
schema = read(ROOT / "contracts/curriculum-package/v1.3/package-redistribution-review.schema.json")
assert not redistribution.validate_review(ledger, source, schema)
fresh = redistribution.build_review(source)
assert not redistribution.validate_review(fresh, source, schema)
assert ledger["summary"]["publicationReady"] is False
assert ledger["summary"]["pendingAssetCount"] == 864
indices = [i for i, a in enumerate(ledger["assetDecisions"])
           if a["provenanceClass"] == redistribution.ASSESSMENT_MATERIAL_PROVENANCE_CLASS]
assert len(indices) == 28
assert all(ledger["assetDecisions"][i]["decisionStatus"] == "pending-human-review" for i in indices)
assert all("promptPath" not in ledger["assetDecisions"][i] and "promptSha256" not in ledger["assetDecisions"][i]
           for i in indices)
passed("actual-ledger-and-fresh-generator-baseline-exact-864-pending-and-no-material-prompts",
       materialDecisions=28, publicationReady=False)
index = indices[0]

def ledger_case(name, mutation, expected_code):
    value = copy.deepcopy(ledger)
    mutation(value, value["assetDecisions"][index])
    codes = sorted({d.code for d in redistribution.validate_review(value, source, schema)})
    assert expected_code in codes, (name, codes)
    passed("redistribution-rejects-" + name, diagnostics=codes)

ledger_case("missing-provenance", lambda v, a: a.pop("assessmentMaterialEvidence"), "ASSET_PROVENANCE_DRIFT")
ledger_case("source-sha-drift", lambda v, a: a["assessmentMaterialEvidence"]["sources"][0].update(sha256="sha256:" + "0" * 64), "ASSET_PROVENANCE_DRIFT")
ledger_case("lost-shared-use", lambda v, a: a["assessmentMaterialEvidence"].update(useGoalIds=[]), "ASSET_PROVENANCE_DRIFT")
ledger_case("invented-prompt", lambda v, a: a.update(promptPath="invented.md", promptSha256="sha256:" + "0" * 64), "SCHEMA")
ledger_case("automatic-apache-rights", lambda v, a: a.update(redistribution.automatic_apache_decision(source.root_license)), "ASSET_AUTOMATIC_ALLOWED_FORBIDDEN")
ledger_case("fictitious-human-approval", lambda v, a: a.update(decisionStatus="human-approved", redistributionStatus="allowed", licenseExpression="CC-BY-4.0"), "ALLOWED_EVIDENCE_INCOMPLETE")
ledger_case("asset-hash-rebinding", lambda v, a: a.update(assetSha256="sha256:" + "0" * 64), "ASSET_DEFINITION_DRIFT")
ledger_case("foreign-owner", lambda v, a: a.update(ownerGoalId="00000000-0000-4000-8000-000000000000"), "ASSET_DEFINITION_DRIFT")
ledger_case("extra-material-prompt-policy", lambda v, a: a.update(automaticRightsApproval=True), "SCHEMA")
ledger_case("publication-overclaim", lambda v, a: v["summary"].update(publicationReady=True), "SUMMARY_DRIFT")

# Missing use inventory, foreign source and stale authored-source claims fail at the source boundary.
item = materials[0]
bad = copy.deepcopy(profile)
next(x for x in bad["resources"]["assessmentMaterials"] if x["resourceId"] == item["resourceId"])["sourceArtifactSha256"] = "0" * 64
reject("redistribution-stale-authored-material-source", lambda: redistribution.assessment_material_base(item, bad, source_goals))
bad_owner = copy.deepcopy(item)
bad_owner["ownerGoalId"] = "00000000-0000-4000-8000-000000000000"
reject("redistribution-material-foreign-owner-source", lambda: redistribution.assessment_material_base(bad_owner, profile, source_goals))

pins = read(OUT / "input-pins.before.actual.json")
drift = [p["path"] for p in pins["pins"] if sha(ROOT / p["path"]) != p["sha256"]]
report = {"at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "status": "PASS_FOCUSED_INDEPENDENT_V13_PRODUCER_AND_REDISTRIBUTION_REVIEW_PROBES",
          "checkCount": len(results), "checks": results, "inputDrift": drift,
          "readOnlyInputs": True, "sourceWrites": False,
          "conformanceContentDigest": expected["contentDigest"],
          "actualLedgerSHA256": sha(LEDGER),
          "boundary": "Actual model trusted reconstruction, actual ledger plus independent in-memory adversarial mutations. No fixture result is presented as a browser/host or learner-flow measurement; no rights/publication/plan activation or remote CI approval."}
(OUT / "checks.actual.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
assert not drift, drift
print("PASS checks", len(results), "input drift", len(drift), flush=True)
