#!/usr/bin/env python3
"""Generate and verify the DPK-005 Mathematik redistribution review ledger.

The ledger records provenance evidence and redistribution decisions without
turning provider labels into licenses.  The real release-model resource index,
build-input hashes, repository assets, prompt metadata, and root LICENSE are
all verified locally.  No network access is used.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import shlex
import sys
import tempfile
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker


REPO_ROOT = Path(__file__).resolve().parents[1]
CONTRACT_ROOT = REPO_ROOT / "contracts/curriculum-package/v1"
DEFAULT_SCHEMA = CONTRACT_ROOT / "package-redistribution-review.schema.json"
DEFAULT_LEDGER = (
    REPO_ROOT
    / "curricula/DE/Gymnasium/quality/package-redistribution"
    / "de-gymnasium-mathematik-v1.review.json"
)
DEFAULT_RELEASE_ROOT = REPO_ROOT / "tmp/curriculum-release-model/mathematik-a"

SCHEMA_ID = (
    "https://skillpilot.com/schemas/curriculum-package/v1/"
    "package-redistribution-review.schema.json"
)
REVIEW_ID = "de-gymnasium-mathematik-v1"
PACKAGE_ID = "org.skillpilot.curriculum.de.gymnasium.mathematik"
PROFILE_ID = "de-gymnasium-mathematik-release-model-v1"
RESOURCE_INDEX_PATH = "data/resources/resource-index.json"
BUILD_INPUTS_PATH = "metadata/build-inputs.json"
CONFORMANCE_PATH = "metadata/release-model-conformance.json"
CONTENT_INDEX_PATH = "metadata/semantic-content-index.json"
ROOT_LICENSE_PATH = "LICENSE"
PROJECT_LICENSE_POLICY_PATH = "LICENSING.md"
PROJECT_LICENSE_DECISION_REFERENCE = "LICENSING.md#project-rule"
TARGET_PROFILE_PATH = "contracts/curriculum-package/v1/profiles/full-standalone-v1.profile.json"
TARGET_PROFILE_ID = "full-standalone-v1"
APACHE_LICENSE_ID = "Apache-2.0"
CONTENT_LICENSE_ID = "CC-BY-4.0"
CONTENT_LICENSE_PATH = "LICENSES/CC-BY-4.0.txt"
# Earlier declared own-work licenses remain valid; new own content uses CC-BY-4.0.
OWN_CONTENT_LICENSE_IDS = frozenset({APACHE_LICENSE_ID, CONTENT_LICENSE_ID})
ROOT_APACHE_LICENSE_BYTES = 10089
ROOT_APACHE_LICENSE_SHA256 = (
    "6bbe4ace8a1818f89b96dfdda9f9d4b9a178bc047c3dc2511a3d93d51f86d7ae"
)
LEGACY_IMAGE_LICENSE_NOTE = "AI-generated, SkillPilot-curated"
SKILLPILOT_AUTHORED_LICENSE_NOTE = "SkillPilot-authored"
AI_ASSISTED_NATIVE_PROVIDER = (
    "Repository-native SVG / Playwright Chromium (reviewed Nano fallback)"
)
AI_ASSISTED_NATIVE_LICENSE_NOTES = (
    "AI-assisted repository-native visualization; redistribution review required",
    "Repository-native, SkillPilot-curated (AI-assisted)",
)
AI_ASSISTED_NATIVE_PROVENANCE_CLASS = "ai-assisted-repository-native"
DETERMINISTIC_RENDER_PROVIDER = (
    "Deterministically rendered from reviewed SVG assessment source"
)
DETERMINISTIC_RENDER_PROVENANCE_CLASS = "skillpilot-authored-deterministic-render"
DETERMINISTIC_RENDER_PROVENANCE_SOURCE = "hash-bound-skillpilot-source-render"
DETERMINISTIC_RENDER_CONTRACT_ID = "rsvg-convert-fixed-png-v1"
ASSESSMENT_MATERIAL_PROVENANCE_CLASS = "skillpilot-authored-assessment-material"
ASSESSMENT_MATERIAL_PROFILE_PATH = (
    "contracts/curriculum-package/v1.3/profiles/de-gymnasium-mathematik-release-model-v1.3.profile.json"
)

PATH_CLASSIFICATION_OVERRIDES: tuple[dict[str, str], ...] = (
    {
        "role": "package-documentation",
        "pathPrefix": "data/assessment-sources/",
        "classId": "skillpilot-data",
        "provenanceClass": "skillpilot-authored",
    },
)

USER_PROVIDED_RE = re.compile(r"user-provided", re.IGNORECASE)
# This imported batch has its own active prompt and image receipt. Older
# per-goal prompt.de.md files describe withdrawn Nano images and stay historical.
# Neither this provenance binding nor the receipt's machine review clears rights.
USER_PROVIDED_IMPORT = {
    "provider": "ChatGPT image generation (user-provided via Astra)",
    "packageId": "math-m7-astra-user-prompts-20260924-v1",
    "receiptPath": "curricula/DE/Gymnasium/quality/goal-visualization-review/m7-astra-user-prompts-20260924-v1/user-image-sight-and-prompt21-receipt-20260924-v2.json",
    "receiptSha256": "2006852f3713294e891b1b9637a54df0ba847f56c8ef70b33a18654a03c1bc6d",
    "promptPath": "curricula/DE/Gymnasium/quality/goal-visualization-review/m7-astra-user-prompts-20260924-v1/prompts.md",
    "promptSha256": "6d50e0c2736a2207948adcb5637ab37a15c29196748f4268b39eac8783a73767",
}
# The unchanged first user image was withdrawn in the immutable September 24
# receipt and independently reactivated on September 27. Never reinterpret the
# old receipt as active or transfer a human release approval from that event.
USER_PROVIDED_REACTIVATION = {
    "goalId": "06ce2b1b-e888-5322-9ed9-dfc6d322956a",
    "receiptPath": "curricula/DE/Gymnasium/quality/goal-visualization-review/m7-ln-existing-keep-20260927-v1/user-image-reactivation-receipt.json",
    "reviewPath": "curricula/DE/Gymnasium/quality/goal-visualization-review/m7-ln-existing-keep-20260927-v1/README.md",
    "reviewSha256": "37f991ba7178fd1570007317768e855cf114353c30e642627995d064e3c1556d",
    "qaPath": "curricula/DE/Gymnasium/quality/goal-visualization-qa/mathematik.qa.json",
}
# Exact current Codex image-generator labels.  A project license by itself is
# never provenance; the prompt must independently repeat the provider verbatim.
CODEX_IMAGE_PROVIDERS = frozenset({
    "OpenAI/ChatGPT-Codex imagegen (model/version not exposed)",
    "ChatGPT/Codex imagegen (model/version not exposed)",
    "OpenAI/ChatGPT-Codex image generation",
    "OpenAI/Codex image_gen.imagegen (model version not exposed)",
})
# Exact generator/edit labels used by newer image batches. The per-goal prompt
# must still repeat the provider verbatim; a project license grants no provenance.
ADDITIONAL_IMAGE_PROVIDERS = frozenset({
    "Google Gemini / Nano Banana 2 (gemini-3.1-flash-image)",
    "Google Gemini gemini-3.1-flash-image (thinking_level=high)",
    "Google Gemini gemini-3-pro-image",
    "Gemini Nano Banana Pro; ChatGPT/Codex imagegen edit",
})
# Existing reviewed prompts use several older provider headings, including two
# verbatim image-generation prompts with the provider recorded in the linked
# immutable review instead.  Preserve those prompt bytes and accept only these
# exact resource/provider/prompt-hash bindings; this is provenance, not rights
# clearance or image-quality approval.  New prompts must use '- Provider: ...'.
LEGACY_PROMPT_PROVIDER_BINDINGS = {
    "goal-resource:308f19e2-e202-5300-a2fa-1eaa717f4e73:0": ("OpenAI/ChatGPT-Codex imagegen (model/version not exposed)", "11d5459efecc12683d92a2309261d3bc41afac13a0442b9fc0e739514f6189c2"),
    "goal-resource:3017e774-8d9f-5129-828f-7684db5afc1e:0": ("ChatGPT/Codex imagegen (model/version not exposed)", "756222480cad90d5dada3d8b16d097fe90ab49df051e89460cabbe910b75c4df"),
    "goal-resource:0f6c1df6-0e30-54ae-8098-e9422833ba80:0": ("ChatGPT/Codex imagegen (model/version not exposed)", "b80e1affcc18a347effd77e8f8f99a8519996770a6cd73557b4a6c03c3ed2d93"),
    "goal-resource:bc6e4c14-d4f7-537e-8e83-9b5c0086e807:1": ("ChatGPT/Codex imagegen (model/version not exposed)", "17079d2280679cad77ef4f72f87052dcd801782052b99472cd14e03b8baa5687"),
    "goal-resource:9b6f4d7d-a804-5666-b7ea-85bb3c73da4a:0": ("OpenAI / ChatGPT-Codex image generation", "200da417a37792f7b37d80ff9e62048271b23233925f02a05de1b02d46667fa7"),
    "goal-resource:aa00edfa-cf8d-500e-994f-7e33a5ebd045:0": ("OpenAI / ChatGPT-Codex image generation", "d0b1ed0a9f46ef4ac26224e1694157133beba681d95cbd70f1eeab10db7b2b61"),
    "goal-resource:04fe49bf-8c3e-5986-ae83-3c69c0c3e4c8:0": ("ChatGPT/Codex imagegen (model/version not exposed)", "b89d64899d4f2d1d79cd573d33daeee7ceb30f82989403a315b5ccfad2df3120"),
    "goal-resource:d8f1fd06-785e-5d15-a8e5-7d8b36f91287:0": ("OpenAI/ChatGPT-Codex imagegen (model/version not exposed)", "bf944a32b73022a6d1760e78e4b7b3994b226a9594a909879d1a69e40265f333"),
    "goal-resource:a8fdbaeb-7c0a-58ff-aab5-2fb871ae2fb0:0": ("OpenAI/ChatGPT-Codex imagegen (model/version not exposed)", "e9bd3e36d1f96284ab89a8e202caebd22d11b38bb4b99bcb1f6e06692f21b91c"),
}
REVIEW_ONLY_PROMPT_PROVIDER_EVIDENCE = {
    "goal-resource:bc6e4c14-d4f7-537e-8e83-9b5c0086e807:1",
    "goal-resource:04fe49bf-8c3e-5986-ae83-3c69c0c3e4c8:0",
}
REVIEW_ONLY_PROVIDER_NOTE = (
    "curricula/DE/Gymnasium/quality/goal-visualization-review/"
    "math-m7-ln-hyperbola-mobile-png-20260923-v1.md"
)
REVIEW_ONLY_PROVIDER_NOTE_SHA256 = "de9a97fb8b76865cefe55a8a65e0d641fcb381c7ddc115bc616799fe4c9edd43"
# These active PNGs replaced historical Gemini JPGs. Their original prompt.de.md
# remains historical; bind redistribution evidence to the current edit/revision.
ACTIVE_PROMPT_OVERRIDES = {
    "goal-resource:1dd0266c-41b4-5481-b64b-7b718cfe799b:0": "curricula/DE/Gymnasium/visualizations/mathematik/1dd0266c-41b4-5481-b64b-7b718cfe799b/prompt.imagegen-perspective-correction.de.md",
    "goal-resource:5518ceb3-f668-5b52-a9b1-57653b16ca98:0": "curricula/DE/Gymnasium/visualizations/mathematik/5518ceb3-f668-5b52-a9b1-57653b16ca98/prompt.imagegen-correction.de.md",
    "goal-resource:2850e8f6-2330-50d3-a577-d519540d9924:0": "curricula/DE/Gymnasium/visualizations/mathematik/2850e8f6-2330-50d3-a577-d519540d9924/prompt.imagegen-correction.de.md",
    "goal-resource:803d910d-96d1-5118-b9ca-29e93d0da76d:0": "curricula/DE/Gymnasium/visualizations/mathematik/803d910d-96d1-5118-b9ca-29e93d0da76d/prompt.imagegen-correction.de.md",
    "goal-resource:d3c42193-f1b7-5c6d-a991-bf034d99359f:0": "curricula/DE/Gymnasium/visualizations/mathematik/d3c42193-f1b7-5c6d-a991-bf034d99359f/prompt.imagegen-r3.de.md",
    "goal-resource:5619ca5b-dc2a-504e-ad89-2e0ca0a83822:0": "curricula/DE/Gymnasium/visualizations/mathematik/5619ca5b-dc2a-504e-ad89-2e0ca0a83822/prompt.imagegen-cube-choice.de.md",
    "goal-resource:e105bad8-b4e5-53fc-b02e-604f1df5b503:0": "curricula/DE/Gymnasium/visualizations/mathematik/e105bad8-b4e5-53fc-b02e-604f1df5b503/prompt.imagegen-coordinate-correction.de.md",
    "goal-resource:985d5529-a586-50eb-bd7f-2db2be8906d1:0": "curricula/DE/Gymnasium/visualizations/mathematik/985d5529-a586-50eb-bd7f-2db2be8906d1/prompt.imagegen-final.de.md",
    "goal-resource:7d37513b-fa1a-54cc-9e2a-9279a381f0f0:0": "curricula/DE/Gymnasium/visualizations/mathematik/7d37513b-fa1a-54cc-9e2a-9279a381f0f0/prompt.imagegen-central-dilation.de.md",
    "goal-resource:0f4f9957-8afe-4aab-9dd8-c26c9aee2afd:0": "curricula/DE/Gymnasium/visualizations/mathematik/0f4f9957-8afe-4aab-9dd8-c26c9aee2afd/prompt.imagegen-edit.de.md",
    "goal-resource:49f9059a-876c-5051-8146-d008b5cc691c:0": "curricula/DE/Gymnasium/visualizations/mathematik/49f9059a-876c-5051-8146-d008b5cc691c/prompt.imagegen-neutral-title.de.md",
    "goal-resource:71fe4a39-38e8-5c6a-8eef-ff4783fe70c2:0": "curricula/DE/Gymnasium/visualizations/mathematik/71fe4a39-38e8-5c6a-8eef-ff4783fe70c2/prompt.imagegen-neutral-title.de.md",
    "goal-resource:5ba7b5aa-7ad5-5605-bcb5-f4aa4b4c6b2d:0": "curricula/DE/Gymnasium/visualizations/mathematik/5ba7b5aa-7ad5-5605-bcb5-f4aa4b4c6b2d/prompt.imagegen-correction.de.md",
    "goal-resource:eb070ed2-7ef4-5afe-b203-190ebb0116af:0": "curricula/DE/Gymnasium/visualizations/mathematik/eb070ed2-7ef4-5afe-b203-190ebb0116af/prompt.imagegen-correction.de.md",
}
PROMPT_PROVIDER_RE = re.compile(r"^- Provider: (.+)$", re.MULTILINE)
PROMPT_SOURCE_SVG_RE = re.compile(r"^- Immutable SVG: `([^`]+)`$", re.MULTILINE)
PROMPT_SOURCE_SVG_SHA_RE = re.compile(
    r"^- SVG SHA-256: `([a-f0-9]{64})`$", re.MULTILINE
)
PROMPT_RENDERER_RE = re.compile(
    r"^- Renderer: (librsvg rsvg-convert) ([0-9]+(?:\.[0-9]+){2})$",
    re.MULTILINE,
)
PROMPT_RENDER_COMMAND_RE = re.compile(r"^- Befehl: `([^`]+)`$", re.MULTILINE)
PROMPT_OUTPUT_PNG_SHA_RE = re.compile(
    r"^- PNG SHA-256: `([a-f0-9]{64})`$", re.MULTILINE
)
SHA256_RE = re.compile(r"^sha256:[a-f0-9]{64}$")

CLASS_SPECS: tuple[dict[str, Any], ...] = (
    {
        "classId": "skillpilot-data",
        "artifactRoles": [
            "canonical-landscape",
            "card-deck",
            "composition-view",
            "mapping",
            "migration-aliases",
        ],
        "provenanceClass": "skillpilot-authored",
    },
    {
        "classId": "official-source-evidence",
        "artifactRoles": ["source-goal-reference-index", "source-index"],
        "provenanceClass": "official-source-metadata",
    },
    {
        "classId": "software-contracts",
        "artifactRoles": [
            "license",
            "release-profile",
            "schema",
            "schema-catalog",
            "semantic-contract",
        ],
        "provenanceClass": "software-contract",
    },
    {
        "classId": "generated-metadata",
        "artifactRoles": [
            "card-index",
            "composition-view-index",
            "dependency-closure",
            "embedded-goal-dependency",
            "package-documentation",
            "provenance-report",
            "quality-evidence",
            "resource-index",
            "runtime-catalog",
            "semantic-content-index",
            "validation-report",
        ],
        "provenanceClass": "generated-metadata",
    },
)

DECISION_FIELDS = (
    "decisionStatus",
    "redistributionStatus",
    "licenseExpression",
    "reviewer",
    "reviewedAt",
    "reviewEvidence",
)


class ReviewError(RuntimeError):
    """The trusted local input cannot support a redistribution review."""


def ai_assisted_native_claim(provider: str, note: str, resource_id: str) -> bool:
    """Recognize only the closed metadata pair, without inferring rights or rendering proof."""
    native_note = note in AI_ASSISTED_NATIVE_LICENSE_NOTES
    if provider == AI_ASSISTED_NATIVE_PROVIDER or native_note:
        if provider != AI_ASSISTED_NATIVE_PROVIDER or not (
            native_note or note == LEGACY_IMAGE_LICENSE_NOTE or note in OWN_CONTENT_LICENSE_IDS
        ):
            raise ReviewError(
                f"AI-assisted native provider/provenance pair differs on {resource_id!r}"
            )
        return True
    return False


def validate_image_license_input(provider: str, note: str, resource_id: str) -> bool:
    """Accept the explicit own-contribution grant without treating it as provenance proof."""
    native = ai_assisted_native_claim(provider, note, resource_id)
    if native:
        return True
    if note in {LEGACY_IMAGE_LICENSE_NOTE, SKILLPILOT_AUTHORED_LICENSE_NOTE}:
        return False
    if note in OWN_CONTENT_LICENSE_IDS:
        # These are existing generator or uploader provenance claims, never rights
        # clearance. Unknown third-party origins cannot become AI-authored merely
        # by carrying a project license. The exact deterministic provider still routes
        # through deterministic_render_evidence below, never around its proof.
        if (
            provider == "Google Gemini / Nano Banana Pro"
            or provider.startswith("Google Gemini / Nano Banana Pro (")
            or provider in ADDITIONAL_IMAGE_PROVIDERS
            or provider.startswith("OpenAI ")
            or provider in CODEX_IMAGE_PROVIDERS
            or USER_PROVIDED_RE.search(provider) is not None
            or provider == DETERMINISTIC_RENDER_PROVIDER
        ):
            return False
        raise ReviewError(
            f"{note} is not provenance evidence for image {resource_id!r}; "
            "the generator or uploader claim must be recorded independently"
        )
    raise ReviewError(
        f"Unexpected image license/provenance note on {resource_id!r}: {note!r}"
    )


@dataclass(frozen=True, order=True)
class Diagnostic:
    code: str
    path: str
    message: str


@dataclass(frozen=True)
class SourceModel:
    package_id: str
    content_digest: str
    profile_id: str
    release_id: str
    resource_index_sha256: str
    build_inputs_sha256: str
    target_profile_sha256: str
    target_non_binary_roles: tuple[str, ...]
    root_license: dict[str, Any]
    project_license_grant: dict[str, Any]
    asset_bases: tuple[dict[str, Any], ...]
    asset_set_sha256: str
    external_resource_count: int


def duplicate_safe_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ReviewError(f"Duplicate JSON object key {key!r}")
        result[key] = value
    return result


def reject_nonfinite(value: str) -> None:
    raise ReviewError(f"Non-finite JSON number {value!r} is forbidden")


def read_json(path: Path) -> Any:
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as error:
        raise ReviewError(f"Cannot read {path}: {error}") from error
    try:
        return json.loads(
            raw,
            object_pairs_hook=duplicate_safe_object,
            parse_constant=reject_nonfinite,
        )
    except (json.JSONDecodeError, ReviewError) as error:
        raise ReviewError(f"Invalid JSON in {path}: {error}") from error


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError as error:
        raise ReviewError(f"Cannot hash {path}: {error}") from error
    return digest.hexdigest()


def digest(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return f"sha256:{sha256_bytes(payload)}"


def require_object(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ReviewError(f"{label} must be an object")
    return value


def require_list(value: Any, label: str) -> list[Any]:
    if not isinstance(value, list):
        raise ReviewError(f"{label} must be an array")
    return value


def repo_file(relative_path: str) -> Path:
    if not isinstance(relative_path, str) or not relative_path or "\\" in relative_path:
        raise ReviewError(f"Unsafe repository path {relative_path!r}")
    unresolved = REPO_ROOT / relative_path
    if unresolved.is_symlink():
        raise ReviewError(f"Repository input must not be a symlink: {relative_path}")
    candidate = unresolved.resolve()
    try:
        candidate.relative_to(REPO_ROOT.resolve())
    except ValueError as error:
        raise ReviewError(f"Repository path escapes the checkout: {relative_path!r}") from error
    if not candidate.is_file() or candidate.is_symlink():
        raise ReviewError(f"Repository input must be a regular non-symlink file: {relative_path}")
    return candidate


def release_file(release_root: Path, relative_path: str) -> Path:
    unresolved = release_root / relative_path
    if unresolved.is_symlink():
        raise ReviewError(f"Release-model input must not be a symlink: {relative_path}")
    candidate = unresolved.resolve()
    try:
        candidate.relative_to(release_root.resolve())
    except ValueError as error:
        raise ReviewError(f"Release-model path escapes its root: {relative_path!r}") from error
    if not candidate.is_file() or candidate.is_symlink():
        raise ReviewError(f"Missing regular release-model file: {relative_path}")
    return candidate


def verify_asset_source(source_path: str, expected_bytes: int, expected_sha256: str) -> None:
    path = repo_file(source_path)
    actual_bytes = path.stat().st_size
    if actual_bytes != expected_bytes:
        raise ReviewError(
            f"Asset byte drift for {source_path}: expected {expected_bytes}, got {actual_bytes}"
        )
    actual_sha256 = sha256_file(path)
    if actual_sha256 != expected_sha256:
        raise ReviewError(
            f"Asset hash drift for {source_path}: expected {expected_sha256}, got {actual_sha256}"
        )


def user_import_prompt_evidence(
    provider: str, owner_goal_id: str, source_path: str,
    byte_count: int, asset_sha256: str,
) -> dict[str, Any] | None:
    if provider != USER_PROVIDED_IMPORT["provider"]:
        return None
    receipt_path = repo_file(USER_PROVIDED_IMPORT["receiptPath"])
    prompt_path = repo_file(USER_PROVIDED_IMPORT["promptPath"])
    for label, path in (("receipt", receipt_path), ("prompt", prompt_path)):
        if sha256_file(path) != USER_PROVIDED_IMPORT[f"{label}Sha256"]:
            raise ReviewError(f"User import {label} hash drift for {owner_goal_id!r}")
    receipt = require_object(read_json(receipt_path), "user import receipt")
    if receipt.get("schemaVersion") != 2 or receipt.get("packageId") != USER_PROVIDED_IMPORT["packageId"]:
        raise ReviewError("Unexpected user import receipt identity")
    rows = require_list(receipt.get("rows"), "user import receipt rows")
    matches = [row for row in rows if isinstance(row, dict) and row.get("goalId") == owner_goal_id]
    if len(matches) != 1:
        raise ReviewError(f"User import has no unique goal binding for {owner_goal_id!r}")
    row = matches[0]
    number = row.get("promptNumber")
    original_path = row.get("sourcePath")
    if type(number) is not int or number < 1 or row.get("sha256") != f"sha256:{asset_sha256}":
        raise ReviewError(f"User import image binding differs for {owner_goal_id!r}")
    evidence_receipt_path = USER_PROVIDED_IMPORT["receiptPath"]
    evidence_receipt_sha256 = USER_PROVIDED_IMPORT["receiptSha256"]
    if owner_goal_id == USER_PROVIDED_REACTIVATION["goalId"]:
        reactivation = USER_PROVIDED_REACTIVATION
        review_path = repo_file(reactivation["reviewPath"])
        if sha256_file(review_path) != reactivation["reviewSha256"]:
            raise ReviewError(f"User image reactivation review drift for {owner_goal_id!r}")
        active_url = source_path.removeprefix("app/public")
        expected_receipt = {
            "schemaVersion": 1,
            "event": "reactivated-pilot-machine-reviewed",
            "goalId": owner_goal_id,
            "promptNumber": number,
            "assetSha256": f"sha256:{asset_sha256}",
            "sourcePath": original_path,
            "activeImageUrl": active_url,
            "historicalReceiptPath": USER_PROVIDED_IMPORT["receiptPath"],
            "reviewPath": reactivation["reviewPath"],
            "reviewSha256": f"sha256:{reactivation['reviewSha256']}",
            "humanReleaseApproved": False,
        }
        current_receipt_path = repo_file(reactivation["receiptPath"])
        current_receipt = read_json(current_receipt_path)
        qa = require_object(read_json(repo_file(reactivation["qaPath"])), "visualization QA")
        qa_rows = require_list(qa.get("records"), "visualization QA records")
        matching_qa = [item for item in qa_rows if isinstance(item, dict) and item.get("goalId") == owner_goal_id]
        if (
            row.get("status") != "withdrawn_quality_hold"
            or row.get("currentImageUrl") != ""
            or current_receipt != expected_receipt
            or len(matching_qa) != 1
            or matching_qa[0].get("visualizationState") != "available"
            or matching_qa[0].get("imageUrl") != active_url
            or matching_qa[0].get("assetSha256") != f"sha256:{asset_sha256}"
            or matching_qa[0].get("aiApproved") != "yes"
            or matching_qa[0].get("aiApprovedAssetSha256") != f"sha256:{asset_sha256}"
        ):
            raise ReviewError(f"User image reactivation binding differs for {owner_goal_id!r}")
        evidence_receipt_path = reactivation["receiptPath"]
        evidence_receipt_sha256 = sha256_file(current_receipt_path)
    elif (
        row.get("status") != "active_machine_v_approved_current_p_reviewed"
        or not isinstance(row.get("currentImageUrl"), str)
        or source_path != "app/public" + row["currentImageUrl"]
    ):
        raise ReviewError(f"User import active image binding differs for {owner_goal_id!r}")
    verify_asset_source(original_path, byte_count, asset_sha256)
    prompt_text = prompt_path.read_text(encoding="utf-8")
    heading = rf"^## {number}\. {re.escape(owner_goal_id)} — [^\n]+\n\n\S"
    if len(re.findall(heading, prompt_text, re.MULTILINE)) != 1:
        raise ReviewError(f"User import prompt/goal binding differs for {owner_goal_id!r}")
    return {
        "promptPath": USER_PROVIDED_IMPORT["promptPath"],
        "promptSha256": f"sha256:{USER_PROVIDED_IMPORT['promptSha256']}",
        "userProvidedImportEvidence": {
            "receiptPath": evidence_receipt_path,
            "receiptSha256": f"sha256:{evidence_receipt_sha256}",
            "promptNumber": number,
            "sourcePath": original_path,
            "sourceSha256": f"sha256:{asset_sha256}",
        },
    }


def unique_prompt_match(pattern: re.Pattern[str], prompt_text: str, label: str) -> Any:
    matches = pattern.findall(prompt_text)
    if len(matches) != 1:
        raise ReviewError(f"Prompt must contain exactly one {label}; found {len(matches)}")
    return matches[0]


def deterministic_render_evidence(
    prompt_text: str,
    artifact_path: str,
    output_bytes: int,
    output_sha256: str,
) -> dict[str, Any]:
    source_path = unique_prompt_match(PROMPT_SOURCE_SVG_RE, prompt_text, "immutable SVG")
    if not source_path.startswith("curricula/DE/Gymnasium/assessments/") or not source_path.endswith(".svg"):
        raise ReviewError(
            "Deterministic render source must be a reviewed SVG below "
            "curricula/DE/Gymnasium/assessments/"
        )
    declared_source_sha256 = unique_prompt_match(
        PROMPT_SOURCE_SVG_SHA_RE, prompt_text, "source SVG SHA-256"
    )
    source_file = repo_file(source_path)
    actual_source_sha256 = sha256_file(source_file)
    if actual_source_sha256 != declared_source_sha256:
        raise ReviewError(
            f"Deterministic render source hash drift for {source_path}: "
            f"declared {declared_source_sha256}, got {actual_source_sha256}"
        )

    renderer, renderer_version = unique_prompt_match(
        PROMPT_RENDERER_RE, prompt_text, "renderer/version binding"
    )
    command = unique_prompt_match(
        PROMPT_RENDER_COMMAND_RE, prompt_text, "render command"
    )
    try:
        command_parts = shlex.split(command, posix=True)
    except ValueError as error:
        raise ReviewError(f"Invalid deterministic render command: {error}") from error
    if len(command_parts) != 10 or command_parts[0] != "rsvg-convert":
        raise ReviewError("Deterministic render command must be the closed rsvg-convert form")
    expected_flags = ["--width", "--height", "--format", "--output"]
    if command_parts[1:8:2] != expected_flags:
        raise ReviewError("Deterministic render command flags or order changed")
    try:
        width = int(command_parts[2])
        height = int(command_parts[4])
    except ValueError as error:
        raise ReviewError("Deterministic render dimensions must be integers") from error
    if not 1 <= width <= 16384 or not 1 <= height <= 16384:
        raise ReviewError("Deterministic render dimensions are outside the closed bounds")
    output_format = command_parts[6]
    if output_format != "png":
        raise ReviewError("Deterministic render output format must be png")
    if command_parts[8] != Path(artifact_path).name:
        raise ReviewError("Deterministic render output filename differs from the artifact")
    if command_parts[9] != Path(source_path).name:
        raise ReviewError("Deterministic render source filename differs from the bound SVG")

    declared_output_sha256 = unique_prompt_match(
        PROMPT_OUTPUT_PNG_SHA_RE, prompt_text, "output PNG SHA-256"
    )
    if declared_output_sha256 != output_sha256:
        raise ReviewError(
            "Deterministic render prompt output SHA-256 differs from the active asset"
        )
    return {
        "contractId": DETERMINISTIC_RENDER_CONTRACT_ID,
        "sourcePath": source_path,
        "sourceBytes": source_file.stat().st_size,
        "sourceSha256": f"sha256:{actual_source_sha256}",
        "renderer": renderer,
        "rendererVersion": renderer_version,
        "width": width,
        "height": height,
        "format": output_format,
        "command": command,
        "outputBytes": output_bytes,
        "outputSha256": f"sha256:{output_sha256}",
    }


def assessment_material_base(
    item: dict[str, Any], declaration: dict[str, Any], goals: list[dict[str, Any]],
) -> dict[str, Any]:
    """Bind an own assessment source without inventing an image prompt or rights approval."""
    matches = [row for row in declaration["resources"]["assessmentMaterials"]
               if row["resourceId"] == item["resourceId"]]
    if len(matches) != 1:
        raise ReviewError("Assessment material has no unique current source declaration")
    declared = matches[0]
    for field in ("ownerGoalId", "order", "title", "provider", "description", "language", "license",
                  "mediaType", "bytes", "sha256"):
        if item.get(field) != declared.get(field):
            raise ReviewError(f"Assessment material declaration drift: {field}")
    url = declared["url"]
    if (item.get("publicUrl") != url or item.get("artifactPath") != url.removeprefix("/")
            or not url.startswith("/assets/assessment-materials/")
            or item.get("mediaType") not in {"image/svg+xml", "image/png"}
            or item.get("provider") != "SkillPilot" or item.get("license") != CONTENT_LICENSE_ID):
        raise ReviewError("Assessment material is outside its declared own-source lane")
    declared_source = repo_file(declared["sourceArtifactPath"])
    if sha256_file(declared_source) != declared["sourceArtifactSha256"]:
        raise ReviewError("Assessment material authored-source hash drift")
    uses = [goal for goal in goals if any(
        url in goal.get("examData", {}).get(field, "") for field in ("taskContent", "taskContentEn"))]
    if item["ownerGoalId"] not in {goal["id"] for goal in uses}:
        raise ReviewError("Assessment material owner has no actual task reference")
    sources: dict[str, str] = {}
    for goal in uses:
        exam = goal["examData"]
        if exam.get("reviewStatus") != "released" or not isinstance(exam.get("sourceArtifactPath"), str):
            raise ReviewError("Assessment material needs a released task with an authored source")
        source_path = exam["sourceArtifactPath"]
        if not source_path.startswith("curricula/DE/Gymnasium/assessments/mathematik/"):
            raise ReviewError("Assessment material source is outside the own Mathematics assessment tree")
        sources[source_path] = "sha256:" + sha256_file(repo_file(source_path))
    if declared["sourceArtifactPath"] not in sources:
        raise ReviewError("Declared authored source is not used by an actual assessment")
    base = {
        "resourceId": item["resourceId"], "ownerGoalId": item["ownerGoalId"],
        "artifactPath": item["artifactPath"], "mediaType": item["mediaType"], "bytes": item["bytes"],
        "assetSha256": "sha256:" + item["sha256"], "provider": item["provider"],
        "legacyLicenseNote": item["license"], "provenanceClass": ASSESSMENT_MATERIAL_PROVENANCE_CLASS,
        "provenanceSource": "hash-bound-assessment-source", "userProvided": False,
        "assessmentMaterialEvidence": {
            "declarationPath": ASSESSMENT_MATERIAL_PROFILE_PATH,
            "declarationSha256": "sha256:" + sha256_file(repo_file(ASSESSMENT_MATERIAL_PROFILE_PATH)),
            "sources": [{"path": path, "sha256": value} for path, value in sorted(sources.items())],
            "useGoalIds": sorted(goal["id"] for goal in uses),
        },
    }
    base["provenanceFingerprint"] = digest(base)
    return base


def load_source_model(release_root: Path) -> SourceModel:
    if not release_root.is_dir() or release_root.is_symlink():
        raise ReviewError(f"Release-model root must be a regular directory: {release_root}")

    conformance_path = release_file(release_root, CONFORMANCE_PATH)
    content_index_path = release_file(release_root, CONTENT_INDEX_PATH)
    resource_index_path = release_file(release_root, RESOURCE_INDEX_PATH)
    build_inputs_path = release_file(release_root, BUILD_INPUTS_PATH)

    conformance = require_object(read_json(conformance_path), "release conformance")
    content_index = require_object(read_json(content_index_path), "semantic content index")
    resource_index = require_object(read_json(resource_index_path), "resource index")
    build_inputs = require_object(read_json(build_inputs_path), "build inputs")
    target_profile_path = repo_file(TARGET_PROFILE_PATH)
    target_profile = require_object(read_json(target_profile_path), "target release profile")

    if conformance.get("passed") is not True:
        raise ReviewError("Release-model conformance is not passed")
    package_id = conformance.get("packageId")
    content_digest = conformance.get("contentDigest")
    profile_id = conformance.get("profileId")
    release_id = conformance.get("releaseId")
    if package_id != PACKAGE_ID:
        raise ReviewError(f"Unexpected packageId {package_id!r}")
    if profile_id != PROFILE_ID:
        raise ReviewError(f"Unexpected release-model profile {profile_id!r}")
    if not isinstance(content_digest, str) or not SHA256_RE.fullmatch(content_digest):
        raise ReviewError("Release-model contentDigest is malformed")
    if content_index.get("contentDigest") != content_digest:
        raise ReviewError("Semantic content index and conformance contentDigest differ")
    if not isinstance(release_id, str) or not release_id:
        raise ReviewError("Release-model releaseId is missing")
    if target_profile.get("profileId") != TARGET_PROFILE_ID:
        raise ReviewError(
            f"Unexpected target release profile {target_profile.get('profileId')!r}"
        )
    target_role_items = require_list(target_profile.get("roles"), "target release profile roles")
    target_roles: list[str] = []
    for index, value in enumerate(target_role_items):
        item = require_object(value, f"target release profile roles[{index}]")
        role = item.get("role")
        if not isinstance(role, str) or not role:
            raise ReviewError(f"target release profile roles[{index}] has no role")
        target_roles.append(role)
    duplicate_target_roles = sorted(
        role for role, count in Counter(target_roles).items() if count > 1
    )
    if duplicate_target_roles:
        raise ReviewError(f"Duplicate target package roles: {duplicate_target_roles!r}")
    if "binary-asset" not in target_roles:
        raise ReviewError("Target release profile has no binary-asset role")
    target_non_binary_roles = tuple(sorted(set(target_roles) - {"binary-asset"}))

    resources = require_list(resource_index.get("resources"), "resource index resources")
    material_candidate = TARGET_PROFILE_ID == "full-standalone-v1.3"
    material_declaration = (read_json(repo_file(ASSESSMENT_MATERIAL_PROFILE_PATH))
                            if material_candidate else None)
    material_goals = (read_json(repo_file(material_declaration["canonicalLandscape"]["sourcePath"]))["goals"]
                      if material_declaration else [])
    embedded = [
        item
        for item in resources
        if isinstance(item, dict)
        and item.get("delivery") == "embedded"
        and (item.get("resourceKind") == "goal-visualization"
             or (material_candidate and item.get("resourceKind") == "assessment-material"))
        and item.get("resourceType") == "image"
    ]
    external_count = sum(
        1 for item in resources if isinstance(item, dict) and item.get("delivery") == "external"
    )
    if len(embedded) + external_count != len(resources):
        raise ReviewError("Resource index contains an unsupported resource class")

    build_binary = require_list(build_inputs.get("binaryResources"), "build binary resources")
    build_by_id: dict[str, dict[str, Any]] = {}
    for index, value in enumerate(build_binary):
        item = require_object(value, f"binaryResources[{index}]")
        resource_id = item.get("resourceId")
        if not isinstance(resource_id, str) or not resource_id:
            raise ReviewError(f"binaryResources[{index}] has no resourceId")
        if resource_id in build_by_id:
            raise ReviewError(f"Duplicate build-input resourceId {resource_id!r}")
        build_by_id[resource_id] = item

    resource_ids = [item.get("resourceId") for item in embedded]
    if not all(isinstance(value, str) and value for value in resource_ids):
        raise ReviewError("Embedded image resourceId is missing")
    duplicate_resource_ids = sorted(
        resource_id for resource_id, count in Counter(resource_ids).items() if count > 1
    )
    if duplicate_resource_ids:
        raise ReviewError(f"Duplicate embedded resource IDs: {duplicate_resource_ids[:5]}")
    if set(resource_ids) != set(build_by_id):
        raise ReviewError("Resource index and build-input binary resource sets differ")

    asset_bases: list[dict[str, Any]] = []
    artifact_paths: set[str] = set()
    for item in embedded:
        resource_id = item["resourceId"]
        owner_goal_id = item.get("ownerGoalId")
        artifact_path = item.get("artifactPath")
        media_type = item.get("mediaType")
        byte_count = item.get("bytes")
        asset_sha256 = item.get("sha256")
        provider = item.get("provider")
        legacy_license_note = item.get("license")
        if not all(
            isinstance(value, str) and value
            for value in (
                owner_goal_id,
                artifact_path,
                media_type,
                asset_sha256,
                provider,
                legacy_license_note,
            )
        ) or not isinstance(byte_count, int):
            raise ReviewError(f"Embedded resource {resource_id!r} is incomplete")
        if artifact_path in artifact_paths:
            raise ReviewError(f"Duplicate embedded artifactPath {artifact_path!r}")
        artifact_paths.add(artifact_path)
        is_material = item.get("resourceKind") == "assessment-material"
        ai_assisted_native = False if is_material else validate_image_license_input(
            provider, legacy_license_note, resource_id)

        build_item = build_by_id[resource_id]
        expected_build = {
            "artifactPath": artifact_path,
            "bytes": byte_count,
            "resourceId": resource_id,
            "sha256": asset_sha256,
        }
        actual_build = {key: build_item.get(key) for key in expected_build}
        if actual_build != expected_build:
            raise ReviewError(
                f"Resource/build-input mismatch for {resource_id!r}: {actual_build!r}"
            )
        source_path = build_item.get("sourcePath")
        if not isinstance(source_path, str):
            raise ReviewError(f"Build input {resource_id!r} has no sourcePath")
        verify_asset_source(source_path, byte_count, asset_sha256)
        if is_material:
            if source_path != "app/public" + item["publicUrl"]:
                raise ReviewError("Assessment material build source does not match its original public URL")
            asset_bases.append(assessment_material_base(item, material_declaration, material_goals))
            continue

        import_evidence = user_import_prompt_evidence(
            provider, owner_goal_id, source_path, byte_count, asset_sha256
        )
        prompt_relative = (
            import_evidence["promptPath"] if import_evidence
            else ACTIVE_PROMPT_OVERRIDES.get(
                resource_id,
                "curricula/DE/Gymnasium/visualizations/mathematik/"
                f"{owner_goal_id}/prompt.de.md",
            )
        )
        prompt_path = repo_file(prompt_relative)
        prompt_text = prompt_path.read_text(encoding="utf-8")
        provider_match = PROMPT_PROVIDER_RE.search(prompt_text)
        prompt_sha256 = sha256_file(prompt_path)
        legacy_binding = LEGACY_PROMPT_PROVIDER_BINDINGS.get(resource_id)
        if legacy_binding is not None and legacy_binding != (provider, prompt_sha256):
            raise ReviewError(
                f"Historical prompt/provider binding differs for resource {resource_id!r}"
            )
        if not import_evidence and (provider_match is None or provider_match.group(1) != provider):
            if legacy_binding is None:
                raise ReviewError(
                    f"Prompt provider metadata differs for resource {resource_id!r}"
                )
        if resource_id in REVIEW_ONLY_PROMPT_PROVIDER_EVIDENCE and (
            sha256_file(repo_file(REVIEW_ONLY_PROVIDER_NOTE))
            != REVIEW_ONLY_PROVIDER_NOTE_SHA256
        ):
            raise ReviewError(
                f"Historical provider review differs for resource {resource_id!r}"
            )
        deterministic_evidence: dict[str, Any] | None = None
        if legacy_license_note == SKILLPILOT_AUTHORED_LICENSE_NOTE or (
            legacy_license_note in OWN_CONTENT_LICENSE_IDS
            and provider == DETERMINISTIC_RENDER_PROVIDER
        ):
            if provider != DETERMINISTIC_RENDER_PROVIDER:
                raise ReviewError(
                    f"SkillPilot-authored asset {resource_id!r} lacks the closed "
                    "deterministic-render provider"
                )
            user_provided = False
            provenance_class = DETERMINISTIC_RENDER_PROVENANCE_CLASS
            provenance_source = DETERMINISTIC_RENDER_PROVENANCE_SOURCE
            deterministic_evidence = deterministic_render_evidence(
                prompt_text,
                artifact_path,
                byte_count,
                asset_sha256,
            )
        elif ai_assisted_native:
            user_provided = False
            provenance_class = AI_ASSISTED_NATIVE_PROVENANCE_CLASS
            provenance_source = "provider-pipeline-claim"
        else:
            if provider == DETERMINISTIC_RENDER_PROVIDER:
                raise ReviewError(
                    f"Deterministic asset {resource_id!r} is incorrectly labeled as AI-generated"
                )
            user_provided = USER_PROVIDED_RE.search(provider) is not None
            provenance_class = (
                "user-provided-generated-claim"
                if user_provided
                else "ai-generated-curated"
            )
            provenance_source = (
                "user-provided-generated-claim"
                if user_provided
                else "provider-pipeline-claim"
            )
        base = {
            "resourceId": resource_id,
            "ownerGoalId": owner_goal_id,
            "artifactPath": artifact_path,
            "mediaType": media_type,
            "bytes": byte_count,
            "assetSha256": f"sha256:{asset_sha256}",
            "provider": provider,
            "legacyLicenseNote": legacy_license_note,
            "provenanceClass": provenance_class,
            "provenanceSource": provenance_source,
            "userProvided": user_provided,
            "promptPath": prompt_relative,
            "promptSha256": f"sha256:{prompt_sha256}",
        }
        if deterministic_evidence is not None:
            base["deterministicRenderEvidence"] = deterministic_evidence
        if import_evidence is not None:
            base["userProvidedImportEvidence"] = import_evidence["userProvidedImportEvidence"]
        base["provenanceFingerprint"] = digest(base)
        asset_bases.append(base)

    asset_bases.sort(key=lambda item: item["resourceId"])
    asset_set_sha256 = digest(
        [
            {
                "resourceId": item["resourceId"],
                "assetSha256": item["assetSha256"],
                "provenanceFingerprint": item["provenanceFingerprint"],
            }
            for item in asset_bases
        ]
    )

    root_license_path = repo_file(ROOT_LICENSE_PATH)
    root_license_bytes = root_license_path.stat().st_size
    root_license_sha256 = sha256_file(root_license_path)
    if (
        root_license_bytes != ROOT_APACHE_LICENSE_BYTES
        or root_license_sha256 != ROOT_APACHE_LICENSE_SHA256
    ):
        raise ReviewError(
            "Root LICENSE bytes differ from the reviewed Apache-2.0 trust anchor"
        )
    root_license = {
        "licenseId": APACHE_LICENSE_ID,
        "path": ROOT_LICENSE_PATH,
        "bytes": root_license_bytes,
        "sha256": f"sha256:{root_license_sha256}",
    }
    return SourceModel(
        package_id=package_id,
        content_digest=content_digest,
        profile_id=profile_id,
        release_id=release_id,
        resource_index_sha256=f"sha256:{sha256_file(resource_index_path)}",
        build_inputs_sha256=f"sha256:{sha256_file(build_inputs_path)}",
        target_profile_sha256=f"sha256:{sha256_file(target_profile_path)}",
        target_non_binary_roles=target_non_binary_roles,
        root_license=root_license,
        project_license_grant=load_project_license_grant(),
        asset_bases=tuple(asset_bases),
        asset_set_sha256=asset_set_sha256,
        external_resource_count=external_count,
    )


def load_project_license_grant() -> dict[str, Any]:
    """Bind the owner's license grant, separately from whole-artifact rights clearance."""
    policy_bytes = (REPO_ROOT / PROJECT_LICENSE_POLICY_PATH).read_bytes()
    policy_text = policy_bytes.decode("utf-8")
    if not re.search(r"^## Project rule$", policy_text, re.MULTILINE):
        raise ReviewError("Project licensing policy is missing the project rule anchor")
    content_license_bytes = (REPO_ROOT / CONTENT_LICENSE_PATH).read_bytes()
    return {
        "softwareLicenseExpression": APACHE_LICENSE_ID,
        "contentLicenseExpression": CONTENT_LICENSE_ID,
        "contentLicenseDocument": {
            "path": CONTENT_LICENSE_PATH,
            "bytes": len(content_license_bytes),
            "sha256": f"sha256:{hashlib.sha256(content_license_bytes).hexdigest()}",
        },
        "scope": "skillpilot-owned-contributions",
        "decisionDate": "2026-09-21",
        "decisionAuthority": "project-owner",
        "decisionReference": PROJECT_LICENSE_DECISION_REFERENCE,
        "policyPath": PROJECT_LICENSE_POLICY_PATH,
        "policySha256": f"sha256:{hashlib.sha256(policy_bytes).hexdigest()}",
        "policyBytes": len(policy_bytes),
        "policyText": policy_text,
        "doesNotClearRedistribution": True,
    }


def pending_decision() -> dict[str, Any]:
    return {
        "decisionStatus": "pending-human-review",
        "redistributionStatus": "review-required",
        "licenseExpression": None,
        "reviewer": None,
        "reviewedAt": None,
        "reviewEvidence": [],
    }


def automatic_apache_decision(root_license: dict[str, Any]) -> dict[str, Any]:
    return {
        "decisionStatus": "automatic-allowed",
        "redistributionStatus": "allowed",
        "licenseExpression": APACHE_LICENSE_ID,
        "reviewer": None,
        "reviewedAt": None,
        "reviewEvidence": [
            {
                "kind": "root-license",
                "reference": root_license["path"],
                "sha256": root_license["sha256"],
            }
        ],
    }


def class_base(spec: dict[str, Any], root_license: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(spec)
    fingerprint_input: dict[str, Any] = {"class": spec}
    if spec["classId"] == "software-contracts":
        fingerprint_input["automaticLicenseEvidence"] = root_license
    result["classFingerprint"] = digest(fingerprint_input)
    return result


def preserve_decision(
    base: dict[str, Any],
    previous: dict[str, Any] | None,
    fingerprint_field: str,
    fallback: dict[str, Any],
) -> dict[str, Any]:
    result = copy.deepcopy(base)
    if previous is not None and previous.get(fingerprint_field) == base[fingerprint_field]:
        if all(field in previous for field in DECISION_FIELDS):
            result.update({field: copy.deepcopy(previous[field]) for field in DECISION_FIELDS})
            return result
    if previous is not None and previous.get("decisionStatus") in {
        "human-approved",
        "prohibited",
    }:
        raise ReviewError(
            "Completed redistribution decision became stale for "
            f"{base.get('classId') or base.get('resourceId')!r}; review the changed evidence"
        )
    result.update(copy.deepcopy(fallback))
    return result


def derive_summary(review: dict[str, Any], external_resource_count: int) -> dict[str, Any]:
    classes = review.get("classDecisions", [])
    assets = review.get("assetDecisions", [])
    class_counts = Counter(
        item.get("decisionStatus") for item in classes if isinstance(item, dict)
    )
    asset_counts = Counter(
        item.get("decisionStatus") for item in assets if isinstance(item, dict)
    )
    pending_classes = class_counts["pending-human-review"]
    pending_assets = asset_counts["pending-human-review"]
    prohibited_classes = class_counts["prohibited"]
    prohibited_assets = asset_counts["prohibited"]
    publication_ready = (
        pending_classes == 0
        and pending_assets == 0
        and prohibited_classes == 0
        and prohibited_assets == 0
        and all(
            isinstance(item, dict) and item.get("redistributionStatus") == "allowed"
            for item in [*classes, *assets]
        )
    )
    return {
        "classDecisionCount": len(classes),
        "automaticAllowedClassCount": class_counts["automatic-allowed"],
        "pendingClassCount": pending_classes,
        "humanApprovedClassCount": class_counts["human-approved"],
        "prohibitedClassCount": prohibited_classes,
        "assetCount": len(assets),
        "externalResourceCount": external_resource_count,
        "userProvidedAssetCount": sum(
            1 for item in assets if isinstance(item, dict) and item.get("userProvided") is True
        ),
        "pendingAssetCount": pending_assets,
        "humanApprovedAssetCount": asset_counts["human-approved"],
        "prohibitedAssetCount": prohibited_assets,
        "humanReviewItemCount": pending_classes + pending_assets,
        "publicationReady": publication_ready,
    }


def build_review(source: SourceModel, previous: Any | None = None) -> dict[str, Any]:
    previous_object = previous if isinstance(previous, dict) else {}
    previous_classes = {
        item.get("classId"): item
        for item in previous_object.get("classDecisions", [])
        if isinstance(item, dict) and isinstance(item.get("classId"), str)
    }
    class_decisions: list[dict[str, Any]] = []
    for spec in CLASS_SPECS:
        base = class_base(spec, source.root_license)
        fallback = (
            automatic_apache_decision(source.root_license)
            if spec["classId"] == "software-contracts"
            else pending_decision()
        )
        class_decisions.append(
            preserve_decision(
                base,
                previous_classes.get(spec["classId"]),
                "classFingerprint",
                fallback,
            )
        )

    previous_assets = {
        item.get("resourceId"): item
        for item in previous_object.get("assetDecisions", [])
        if isinstance(item, dict) and isinstance(item.get("resourceId"), str)
    }
    asset_decisions = [
        preserve_decision(
            base,
            previous_assets.get(base["resourceId"]),
            "provenanceFingerprint",
            pending_decision(),
        )
        for base in source.asset_bases
    ]
    review: dict[str, Any] = {
        "$schema": SCHEMA_ID,
        "reviewFormatVersion": "1.0",
        "reviewId": REVIEW_ID,
        "packageId": source.package_id,
        "contentDigest": source.content_digest,
        "sourceReleaseModel": {
            "profileId": source.profile_id,
            "releaseId": source.release_id,
            "resourceIndexPath": RESOURCE_INDEX_PATH,
            "resourceIndexSha256": source.resource_index_sha256,
            "buildInputsPath": BUILD_INPUTS_PATH,
            "buildInputsSha256": source.build_inputs_sha256,
        },
        "targetReleaseProfile": {
            "profileId": TARGET_PROFILE_ID,
            "path": TARGET_PROFILE_PATH,
            "sha256": source.target_profile_sha256,
            "nonBinaryRoles": list(source.target_non_binary_roles),
        },
        "rootLicenseEvidence": copy.deepcopy(source.root_license),
        "projectLicenseGrant": copy.deepcopy(source.project_license_grant),
        "classDecisions": class_decisions,
        "pathClassificationOverrides": [
            copy.deepcopy(item) for item in PATH_CLASSIFICATION_OVERRIDES
        ],
        "assetSetSha256": source.asset_set_sha256,
        "assetDecisions": asset_decisions,
    }
    review["summary"] = derive_summary(review, source.external_resource_count)
    return review


def schema_diagnostics(review: Any, schema: dict[str, Any]) -> list[Diagnostic]:
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    diagnostics: list[Diagnostic] = []
    for error in sorted(
        validator.iter_errors(review),
        key=lambda item: tuple(str(part) for part in item.absolute_path),
    ):
        path = "/" + "/".join(str(part) for part in error.absolute_path)
        diagnostics.append(Diagnostic("SCHEMA", path, error.message))
    return diagnostics


def evidence_kinds(decision: dict[str, Any]) -> set[str]:
    evidence = decision.get("reviewEvidence")
    if not isinstance(evidence, list):
        return set()
    return {
        item.get("kind")
        for item in evidence
        if isinstance(item, dict) and isinstance(item.get("kind"), str)
    }


def validate_decision_policy(
    decision: dict[str, Any],
    path: str,
    *,
    asset: bool,
    root_license: dict[str, Any],
) -> list[Diagnostic]:
    diagnostics: list[Diagnostic] = []
    status = decision.get("decisionStatus")
    redistribution = decision.get("redistributionStatus")
    expression = decision.get("licenseExpression")
    if status == "pending-human-review":
        expected = {
            "redistributionStatus": "review-required",
            "licenseExpression": None,
            "reviewer": None,
            "reviewedAt": None,
            "reviewEvidence": [],
        }
        actual = {key: decision.get(key) for key in expected}
        if actual != expected:
            diagnostics.append(
                Diagnostic(
                    "PENDING_DECISION_NOT_CLOSED",
                    path,
                    "Pending decisions must remain null/unreviewed and review-required",
                )
            )
        return diagnostics

    if status == "automatic-allowed":
        if asset:
            diagnostics.append(
                Diagnostic(
                    "ASSET_AUTOMATIC_ALLOWED_FORBIDDEN",
                    path,
                    "Binary assets can never be allowed from provider metadata automatically",
                )
            )
            return diagnostics
        expected_evidence = [
            {
                "kind": "root-license",
                "reference": root_license["path"],
                "sha256": root_license["sha256"],
            }
        ]
        if (
            decision.get("classId") != "software-contracts"
            or redistribution != "allowed"
            or expression != APACHE_LICENSE_ID
            or decision.get("reviewer") is not None
            or decision.get("reviewedAt") is not None
            or decision.get("reviewEvidence") != expected_evidence
        ):
            diagnostics.append(
                Diagnostic(
                    "CLASS_AUTOMATIC_POLICY_INVALID",
                    path,
                    "Only software contracts may inherit Apache-2.0 from the exact root LICENSE",
                )
            )
        return diagnostics

    if status == "human-approved":
        if redistribution != "allowed":
            diagnostics.append(
                Diagnostic("ALLOWED_STATUS_MISMATCH", path, "Human approval must be allowed")
            )
        if (
            not isinstance(expression, str)
            or not expression.strip()
            or expression in {
                "NONE", "NOASSERTION", LEGACY_IMAGE_LICENSE_NOTE,
                *AI_ASSISTED_NATIVE_LICENSE_NOTES,
            }
        ):
            diagnostics.append(
                Diagnostic(
                    "ALLOWED_LICENSE_INVALID",
                    f"{path}/licenseExpression",
                    "An allowed decision needs a concrete license expression",
                )
            )
        kinds = evidence_kinds(decision)
        required_kinds: set[str]
        if asset:
            required_kinds = {"project-license-decision"}
            if decision.get("provenanceClass") not in {
                    DETERMINISTIC_RENDER_PROVENANCE_CLASS, ASSESSMENT_MATERIAL_PROVENANCE_CLASS}:
                required_kinds.add("provider-terms-review")
            if decision.get("userProvided") is True:
                required_kinds.add("uploader-rights-attestation")
        else:
            class_id = decision.get("classId")
            required_kinds = (
                {"official-work-legal-review", "project-license-decision"}
                if class_id == "official-source-evidence"
                else {"project-license-decision"}
            )
        missing = sorted(required_kinds - kinds)
        if missing:
            diagnostics.append(
                Diagnostic(
                    "ALLOWED_EVIDENCE_INCOMPLETE",
                    f"{path}/reviewEvidence",
                    f"Missing evidence kinds: {missing}",
                )
            )
        return diagnostics

    if status == "prohibited":
        if redistribution != "prohibited":
            diagnostics.append(
                Diagnostic(
                    "PROHIBITED_STATUS_MISMATCH",
                    path,
                    "A prohibited decision must block redistribution",
                )
            )
        return diagnostics

    diagnostics.append(Diagnostic("DECISION_STATUS_UNKNOWN", path, f"Unknown status {status!r}"))
    return diagnostics


def validate_review(
    review: Any,
    source: SourceModel,
    schema: dict[str, Any],
) -> list[Diagnostic]:
    diagnostics = schema_diagnostics(review, schema)
    if not isinstance(review, dict):
        return sorted(diagnostics)

    expected_identity = {
        "$schema": SCHEMA_ID,
        "reviewFormatVersion": "1.0",
        "reviewId": REVIEW_ID,
        "packageId": source.package_id,
        "contentDigest": source.content_digest,
    }
    for field, expected in expected_identity.items():
        if review.get(field) != expected:
            diagnostics.append(
                Diagnostic(
                    "REVIEW_IDENTITY_MISMATCH",
                    f"/{field}",
                    f"Expected {expected!r}",
                )
            )

    expected_release = {
        "profileId": source.profile_id,
        "releaseId": source.release_id,
        "resourceIndexPath": RESOURCE_INDEX_PATH,
        "resourceIndexSha256": source.resource_index_sha256,
        "buildInputsPath": BUILD_INPUTS_PATH,
        "buildInputsSha256": source.build_inputs_sha256,
    }
    if review.get("sourceReleaseModel") != expected_release:
        diagnostics.append(
            Diagnostic(
                "SOURCE_RELEASE_MODEL_DRIFT",
                "/sourceReleaseModel",
                "Release-model IDs or input hashes differ from the current compiled model",
            )
        )
    expected_target_profile = {
        "profileId": TARGET_PROFILE_ID,
        "path": TARGET_PROFILE_PATH,
        "sha256": source.target_profile_sha256,
        "nonBinaryRoles": list(source.target_non_binary_roles),
    }
    if review.get("targetReleaseProfile") != expected_target_profile:
        diagnostics.append(
            Diagnostic(
                "TARGET_RELEASE_PROFILE_DRIFT",
                "/targetReleaseProfile",
                "Target profile hash or declared non-binary role set changed",
            )
        )
    if review.get("pathClassificationOverrides") != list(PATH_CLASSIFICATION_OVERRIDES):
        diagnostics.append(
            Diagnostic(
                "PATH_CLASSIFICATION_OVERRIDE_DRIFT",
                "/pathClassificationOverrides",
                "Assessment-source path classification must remain explicit and exact",
            )
        )
    if review.get("rootLicenseEvidence") != source.root_license:
        diagnostics.append(
            Diagnostic(
                "ROOT_LICENSE_EVIDENCE_DRIFT",
                "/rootLicenseEvidence",
                "Root LICENSE bytes or SHA-256 changed",
            )
        )
    if review.get("projectLicenseGrant") != source.project_license_grant:
        diagnostics.append(
            Diagnostic(
                "PROJECT_LICENSE_GRANT_DRIFT",
                "/projectLicenseGrant",
                "Project-owned contributions must carry the exact separate owner license grant and policy",
            )
        )
    if review.get("assetSetSha256") != source.asset_set_sha256:
        diagnostics.append(
            Diagnostic(
                "ASSET_SET_DIGEST_DRIFT",
                "/assetSetSha256",
                "Asset/provenance set digest differs from current inputs",
            )
        )

    raw_classes = review.get("classDecisions")
    classes = [item for item in raw_classes if isinstance(item, dict)] if isinstance(raw_classes, list) else []
    class_ids = [item.get("classId") for item in classes]
    for class_id, count in sorted(Counter(class_ids).items(), key=lambda item: str(item[0])):
        if count > 1:
            diagnostics.append(
                Diagnostic(
                    "CLASS_DECISION_DUPLICATE",
                    "/classDecisions",
                    f"Duplicate class decision {class_id!r}",
                )
            )
    expected_class_ids = [spec["classId"] for spec in CLASS_SPECS]
    if class_ids != expected_class_ids:
        diagnostics.append(
            Diagnostic(
                "CLASS_DECISION_COVERAGE_DRIFT",
                "/classDecisions",
                f"Expected class order and coverage {expected_class_ids!r}",
            )
        )
    classes_by_id = {item.get("classId"): item for item in classes}
    for index, spec in enumerate(CLASS_SPECS):
        item = classes_by_id.get(spec["classId"])
        if item is None:
            continue
        base = class_base(spec, source.root_license)
        for field, expected in base.items():
            if item.get(field) != expected:
                diagnostics.append(
                    Diagnostic(
                        "CLASS_DEFINITION_DRIFT",
                        f"/classDecisions/{index}/{field}",
                        f"Expected {expected!r}",
                    )
                )
        diagnostics.extend(
            validate_decision_policy(
                item,
                f"/classDecisions/{index}",
                asset=False,
                root_license=source.root_license,
            )
        )

    role_owners: dict[str, list[str]] = {}
    for item in classes:
        class_id = item.get("classId")
        roles = item.get("artifactRoles")
        if not isinstance(class_id, str) or not isinstance(roles, list):
            continue
        for role in roles:
            if isinstance(role, str):
                role_owners.setdefault(role, []).append(class_id)
    expected_role_set = set(source.target_non_binary_roles)
    actual_role_set = set(role_owners)
    missing_roles = sorted(expected_role_set - actual_role_set)
    unknown_roles = sorted(actual_role_set - expected_role_set)
    duplicate_role_owners = {
        role: owners for role, owners in sorted(role_owners.items()) if len(owners) != 1
    }
    if missing_roles or unknown_roles or duplicate_role_owners:
        diagnostics.append(
            Diagnostic(
                "CLASS_ROLE_COVERAGE_DRIFT",
                "/classDecisions",
                "Non-binary target roles must have one default class; "
                f"missing={missing_roles}, unknown={unknown_roles}, "
                f"duplicates={duplicate_role_owners}",
            )
        )

    raw_assets = review.get("assetDecisions")
    assets = [item for item in raw_assets if isinstance(item, dict)] if isinstance(raw_assets, list) else []
    resource_ids = [item.get("resourceId") for item in assets]
    for resource_id, count in sorted(Counter(resource_ids).items(), key=lambda item: str(item[0])):
        if count > 1:
            diagnostics.append(
                Diagnostic(
                    "ASSET_RESOURCE_DUPLICATE",
                    "/assetDecisions",
                    f"Duplicate resourceId {resource_id!r}",
                )
            )
    artifact_paths = [item.get("artifactPath") for item in assets]
    for artifact_path, count in sorted(Counter(artifact_paths).items(), key=lambda item: str(item[0])):
        if count > 1:
            diagnostics.append(
                Diagnostic(
                    "ASSET_PATH_DUPLICATE",
                    "/assetDecisions",
                    f"Duplicate artifactPath {artifact_path!r}",
                )
            )

    expected_by_id = {item["resourceId"]: item for item in source.asset_bases}
    actual_by_id = {
        item["resourceId"]: item
        for item in assets
        if isinstance(item.get("resourceId"), str)
    }
    missing_ids = sorted(set(expected_by_id) - set(actual_by_id))
    obsolete_ids = sorted(set(actual_by_id) - set(expected_by_id))
    if missing_ids:
        diagnostics.append(
            Diagnostic(
                "ASSET_DECISION_MISSING",
                "/assetDecisions",
                f"Missing {len(missing_ids)} current assets; first={missing_ids[:5]!r}",
            )
        )
    if obsolete_ids:
        diagnostics.append(
            Diagnostic(
                "ASSET_DECISION_OBSOLETE",
                "/assetDecisions",
                f"Found {len(obsolete_ids)} obsolete assets; first={obsolete_ids[:5]!r}",
            )
        )
    expected_order = sorted(expected_by_id)
    if resource_ids != expected_order:
        diagnostics.append(
            Diagnostic(
                "ASSET_DECISION_ORDER_DRIFT",
                "/assetDecisions",
                "Asset decisions must be sorted by current resourceId",
            )
        )

    field_codes = {
        "assetSha256": "ASSET_HASH_DRIFT",
        "provider": "ASSET_PROVIDER_DRIFT",
        "provenanceClass": "ASSET_PROVENANCE_DRIFT",
        "provenanceSource": "ASSET_PROVENANCE_DRIFT",
        "userProvided": "ASSET_PROVENANCE_DRIFT",
        "promptSha256": "ASSET_PROVENANCE_DRIFT",
        "deterministicRenderEvidence": "ASSET_PROVENANCE_DRIFT",
        "userProvidedImportEvidence": "ASSET_PROVENANCE_DRIFT",
        "assessmentMaterialEvidence": "ASSET_PROVENANCE_DRIFT",
        "provenanceFingerprint": "ASSET_PROVENANCE_DRIFT",
    }
    for resource_id in sorted(set(expected_by_id) & set(actual_by_id)):
        expected = expected_by_id[resource_id]
        actual = actual_by_id[resource_id]
        index = resource_ids.index(resource_id)
        if "userProvidedImportEvidence" in actual and "userProvidedImportEvidence" not in expected:
            diagnostics.append(Diagnostic(
                "ASSET_PROVENANCE_DRIFT",
                f"/assetDecisions/{index}/userProvidedImportEvidence",
                "No asset-bound user import exists for this resource",
            ))
        for field, expected_value in expected.items():
            if actual.get(field) != expected_value:
                diagnostics.append(
                    Diagnostic(
                        field_codes.get(field, "ASSET_DEFINITION_DRIFT"),
                        f"/assetDecisions/{index}/{field}",
                        f"Expected current value {expected_value!r}",
                    )
                )
        diagnostics.extend(
            validate_decision_policy(
                actual,
                f"/assetDecisions/{index}",
                asset=True,
                root_license=source.root_license,
            )
        )

    expected_summary = derive_summary(review, source.external_resource_count)
    if review.get("summary") != expected_summary:
        diagnostics.append(
            Diagnostic(
                "SUMMARY_DRIFT",
                "/summary",
                f"Expected derived summary {expected_summary!r}",
            )
        )
    return sorted(set(diagnostics))


def print_summary(review: dict[str, Any]) -> None:
    summary = review["summary"]
    print(
        "Redistribution review: "
        f"{review['packageId']} {review['contentDigest']}"
    )
    print(
        "Classes: "
        f"{summary['classDecisionCount']} total, "
        f"{summary['automaticAllowedClassCount']} automatic Apache-2.0, "
        f"{summary['pendingClassCount']} pending, "
        f"{summary['prohibitedClassCount']} prohibited"
    )
    print(
        "Images: "
        f"{summary['assetCount']} total, "
        f"{summary['pendingAssetCount']} pending, "
        f"{summary['userProvidedAssetCount']} user-provided claims, "
        f"{summary['prohibitedAssetCount']} prohibited"
    )
    print(
        f"External metadata-only resources: {summary['externalResourceCount']}; "
        f"human review items: {summary['humanReviewItemCount']}"
    )
    print(
        "Publication redistribution: "
        + ("READY" if summary["publicationReady"] else "BLOCKED")
    )


def write_json_atomic(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ReviewError(f"Refusing to replace symlink ledger {path}")
    payload = (
        json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def run_user_import_prompt_self_test() -> None:
    from unittest.mock import patch

    goal_id = "fc047e6e-5d6d-460f-99fc-ade3a23b9a8e"
    image = b"exact user supplied image"
    image_sha = sha256_bytes(image)
    public_path = f"app/public/assets/{goal_id}.png"
    prompt = f"## 21. {goal_id} — Winkelbeziehungen\n\nThe active imported prompt.\n"
    receipt = {
        "schemaVersion": 2,
        "packageId": USER_PROVIDED_IMPORT["packageId"],
        "rows": [{
            "goalId": goal_id, "promptNumber": 21,
            "status": "active_machine_v_approved_current_p_reviewed",
            "sha256": f"sha256:{image_sha}",
            "currentImageUrl": f"/assets/{goal_id}.png",
            "sourcePath": "incoming.png",
            "humanReleaseApproved": False,
        }],
    }
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        historical_prompt = root / "prompt.de.md"
        historical_prompt.write_text("- Provider: Google Gemini / Nano Banana Pro\n")
        original_historical_bytes = historical_prompt.read_bytes()
        bindings = dict(USER_PROVIDED_IMPORT, receiptPath="receipt.json", promptPath="prompts.md")
        with patch.dict(USER_PROVIDED_IMPORT, bindings, clear=True), patch(__name__ + ".REPO_ROOT", root):
            def reset() -> None:
                (root / "receipt.json").write_text(json.dumps(receipt), encoding="utf-8")
                (root / "prompts.md").write_text(prompt, encoding="utf-8")
                (root / "incoming.png").write_bytes(image)
                for label, filename in (("receipt", "receipt.json"), ("prompt", "prompts.md")):
                    USER_PROVIDED_IMPORT[f"{label}Sha256"] = sha256_file(root / filename)

            arguments = (USER_PROVIDED_IMPORT["provider"], goal_id, public_path, len(image), image_sha)
            reset()
            actual = user_import_prompt_evidence(*arguments)
            if actual is None or actual["promptPath"] != "prompts.md" or actual["userProvidedImportEvidence"]["promptNumber"] != 21:
                raise ReviewError("Self-test did not choose the active asset-bound user prompt")
            if historical_prompt.read_bytes() != original_historical_bytes:
                raise ReviewError("Self-test changed the historical provider prompt")
            if user_import_prompt_evidence("Google Gemini / Nano Banana Pro", *arguments[1:]) is not None:
                raise ReviewError("Self-test changed the legacy prompt path")

            def rejected(label: str) -> None:
                try:
                    user_import_prompt_evidence(*arguments)
                except ReviewError:
                    return
                raise ReviewError(f"Self-test accepted invalid user import: {label}")

            for filename in ("receipt.json", "prompts.md", "incoming.png"):
                reset()
                (root / filename).unlink()
                rejected(f"missing {filename}")
                reset()
                (root / filename).write_bytes(b"tampered input")
                rejected(f"drifted {filename}")

            mutations = [
                ("missing goal", lambda value: value.update(rows=[])),
                ("duplicate goal", lambda value: value["rows"].append(copy.deepcopy(value["rows"][0]))),
                ("withdrawn image", lambda value: value["rows"][0].update(status="withdrawn_quality_hold")),
                ("wrong image", lambda value: value["rows"][0].update(sha256="sha256:" + "0" * 64)),
                ("wrong URL", lambda value: value["rows"][0].update(currentImageUrl="/assets/other.png")),
                ("wrong prompt", lambda value: value["rows"][0].update(promptNumber=20)),
                ("boolean prompt", lambda value: value["rows"][0].update(promptNumber=True)),
                ("missing source path", lambda value: value["rows"][0].pop("sourcePath")),
                ("escaping source path", lambda value: value["rows"][0].update(sourcePath="../outside.png")),
            ]
            for label, mutation in mutations:
                reset()
                value = copy.deepcopy(receipt)
                mutation(value)
                (root / "receipt.json").write_text(json.dumps(value), encoding="utf-8")
                USER_PROVIDED_IMPORT["receiptSha256"] = sha256_file(root / "receipt.json")
                rejected(label)
    print("User-import prompt self-test passed: active binding with historical prompt preserved, legacy path unchanged, 15 rejected missing/drift/mismatch cases.")


def run_self_test(
    review: dict[str, Any], source: SourceModel, schema: dict[str, Any]
) -> None:
    run_user_import_prompt_self_test()
    baseline = validate_review(review, source, schema)
    if baseline:
        raise ReviewError(
            "Self-test baseline is invalid: "
            + "; ".join(f"{item.code} {item.path}" for item in baseline[:10])
        )

    for note in (*AI_ASSISTED_NATIVE_LICENSE_NOTES, LEGACY_IMAGE_LICENSE_NOTE, *sorted(OWN_CONTENT_LICENSE_IDS)):
        if not ai_assisted_native_claim(AI_ASSISTED_NATIVE_PROVIDER, note, "fixture"):
            raise ReviewError("Self-test rejected an exact AI-assisted native claim")
    for provider in (
        "Google Gemini / Nano Banana Pro (gemini-3-pro-image)",
        "user-provided generated image",
    ):
        if ai_assisted_native_claim(provider, LEGACY_IMAGE_LICENSE_NOTE, "fixture"):
            raise ReviewError("Self-test reclassified an unchanged legacy provider claim")
    invalid_native_pairs = [
        ("unknown provider", AI_ASSISTED_NATIVE_LICENSE_NOTES[0]),
        ("unknown provider", AI_ASSISTED_NATIVE_LICENSE_NOTES[1]),
        (DETERMINISTIC_RENDER_PROVIDER, AI_ASSISTED_NATIVE_LICENSE_NOTES[0]),
        (AI_ASSISTED_NATIVE_PROVIDER + " ", AI_ASSISTED_NATIVE_LICENSE_NOTES[0]),
        (AI_ASSISTED_NATIVE_PROVIDER, SKILLPILOT_AUTHORED_LICENSE_NOTE),
        (AI_ASSISTED_NATIVE_PROVIDER, "unknown provenance"),
    ]
    for provider, note in invalid_native_pairs:
        try:
            ai_assisted_native_claim(provider, note, "fixture")
        except ReviewError:
            pass
        else:
            raise ReviewError("Self-test accepted a mismatched AI-assisted native pair")

    fresh_review = build_review(source)
    imported_indexes = [
        index for index, item in enumerate(fresh_review["assetDecisions"])
        if "userProvidedImportEvidence" in item
    ]
    if not imported_indexes or any(
        {key: fresh_review["assetDecisions"][index][key] for key in DECISION_FIELDS} != pending_decision()
        for index in imported_indexes
    ):
        raise ReviewError("User import provenance inferred a redistribution approval")
    native_indexes = [
        index for index, item in enumerate(fresh_review["assetDecisions"])
        if item["provenanceClass"] == AI_ASSISTED_NATIVE_PROVENANCE_CLASS
    ]
    if not native_indexes:
        raise ReviewError("Self-test has no current AI-assisted native asset")
    for index in native_indexes:
        item = fresh_review["assetDecisions"][index]
        if (
            {key: item[key] for key in DECISION_FIELDS} != pending_decision()
            or item["provenanceSource"] != "provider-pipeline-claim"
            or "deterministicRenderEvidence" in item
        ):
            raise ReviewError("AI-assisted native metadata inferred rights or rendering proof")
    if validate_review(fresh_review, source, schema):
        raise ReviewError("Fresh pending AI-assisted native evidence failed validation")

    asset_validator = Draft202012Validator(
        {"$defs": schema["$defs"], "$ref": "#/$defs/assetDecision"},
        format_checker=FormatChecker(),
    )
    provider_cases = (
        ("Google Gemini / Nano Banana Pro", False),
        ("Google Gemini / Nano Banana Pro (gemini-3-pro-image)", False),
        *((provider, False) for provider in sorted(ADDITIONAL_IMAGE_PROVIDERS)),
        ("OpenAI / ChatGPT-Codex image generation", False),
        *((provider, False) for provider in sorted(CODEX_IMAGE_PROVIDERS)),
        (AI_ASSISTED_NATIVE_PROVIDER, True),
        ("user-provided generated image", False),
    )
    for provider, expected_native, license_id in (
        (provider, native, license_id)
        for license_id in sorted(OWN_CONTENT_LICENSE_IDS)
        for provider, native in provider_cases
    ):
        if validate_image_license_input(provider, license_id, "fixture") != expected_native:
            raise ReviewError("Explicit project license changed generator provenance")
        base = copy.deepcopy(source.asset_bases[native_indexes[0]])
        user_provided = USER_PROVIDED_RE.search(provider) is not None
        base.update({
            "provider": provider,
            "legacyLicenseNote": license_id,
            "provenanceClass": AI_ASSISTED_NATIVE_PROVENANCE_CLASS if expected_native else (
                "user-provided-generated-claim" if user_provided else "ai-generated-curated"
            ),
            "provenanceSource": "user-provided-generated-claim" if user_provided else "provider-pipeline-claim",
            "userProvided": user_provided,
        })
        del base["provenanceFingerprint"]
        base["provenanceFingerprint"] = digest(base)
        decision = preserve_decision(base, None, "provenanceFingerprint", pending_decision())
        asset_validator.validate(decision)
        if {key: decision[key] for key in DECISION_FIELDS} != pending_decision():
            raise ReviewError("An explicit project grant automatically cleared an image")
        if validate_decision_policy(decision, "/fixture", asset=True, root_license=source.root_license):
            raise ReviewError("Pending image with explicit project license failed policy validation")
    deterministic_base = next(
        copy.deepcopy(base) for base in source.asset_bases
        if base["provenanceClass"] == DETERMINISTIC_RENDER_PROVENANCE_CLASS
    )
    prompt_text = repo_file(deterministic_base["promptPath"]).read_text(encoding="utf-8")
    evidence_arguments = (
        deterministic_base["artifactPath"], deterministic_base["bytes"],
        deterministic_base["assetSha256"].removeprefix("sha256:"),
    )
    if deterministic_render_evidence(prompt_text, *evidence_arguments) != deterministic_base["deterministicRenderEvidence"]:
        raise ReviewError("Explicit-license deterministic render changed the required provenance proof")
    for invalid_prompt in ("", re.sub(PROMPT_SOURCE_SVG_SHA_RE, "- SVG SHA-256: `" + "0" * 64 + "`", prompt_text)):
        try:
            deterministic_render_evidence(invalid_prompt, *evidence_arguments)
        except ReviewError:
            pass
        else:
            raise ReviewError("Explicit-license deterministic render accepted missing or false proof")
    for license_id in sorted(OWN_CONTENT_LICENSE_IDS):
        if validate_image_license_input(DETERMINISTIC_RENDER_PROVIDER, license_id, "fixture"):
            raise ReviewError("A deterministic render was reclassified as an AI-native claim")
        deterministic_base["legacyLicenseNote"] = license_id
        del deterministic_base["provenanceFingerprint"]
        deterministic_base["provenanceFingerprint"] = digest(deterministic_base)
        deterministic_decision = preserve_decision(
            deterministic_base, None, "provenanceFingerprint", pending_decision()
        )
        asset_validator.validate(deterministic_decision)
        if {key: deterministic_decision[key] for key in DECISION_FIELDS} != pending_decision():
            raise ReviewError("An explicit deterministic-render license bypassed rights review")
        missing_proof = copy.deepcopy(deterministic_decision)
        del missing_proof["deterministicRenderEvidence"]
        if asset_validator.is_valid(missing_proof):
            raise ReviewError("Explicit-license deterministic render schema accepted missing proof")

    for provider, license_id in (
        (provider, license_id)
        for provider in ("unknown provider", "Third-party photo agency")
        for license_id in sorted(OWN_CONTENT_LICENSE_IDS)
    ):
        try:
            validate_image_license_input(provider, license_id, "fixture")
        except ReviewError:
            pass
        else:
            raise ReviewError("A license alone created an unsupported provenance claim")

    cases: list[tuple[str, str, Any]] = []

    def case(name: str, expected_code: str, mutation: Any) -> None:
        cases.append((name, expected_code, mutation))

    preserved_review = build_review(source, review)
    for field in ("classDecisions", "assetDecisions", "summary"):
        if preserved_review[field] != review[field]:
            raise ReviewError("The project license grant must not change redistribution decisions")
    for field, value in (
        ("softwareLicenseExpression", CONTENT_LICENSE_ID),
        ("contentLicenseExpression", APACHE_LICENSE_ID),
        ("scope", "all-materials"),
        ("policySha256", f"sha256:{'0' * 64}"),
        ("policyText", "Unverified blanket permission"),
        ("doesNotClearRedistribution", False),
    ):
        case(
            f"project-license-grant-{field}-drift", "PROJECT_LICENSE_GRANT_DRIFT",
            lambda review, field=field, value=value: review["projectLicenseGrant"].update({field: value}),
        )
    case(
        "project-license-grant-missing", "PROJECT_LICENSE_GRANT_DRIFT",
        lambda review: review.pop("projectLicenseGrant"),
    )

    native_index = native_indexes[0]
    case(
        "native-provider-pair-drift", "SCHEMA",
        lambda value: value["assetDecisions"][native_index].update(
            {"provider": "unknown provider"}
        ),
    )
    case(
        "native-provenance-note-pair-drift", "SCHEMA",
        lambda value: value["assetDecisions"][native_index].update(
            {"legacyLicenseNote": SKILLPILOT_AUTHORED_LICENSE_NOTE}
        ),
    )
    case(
        "native-authored-provenance-overclaim", "ASSET_PROVENANCE_DRIFT",
        lambda value: value["assetDecisions"][native_index].update(
            {"provenanceClass": DETERMINISTIC_RENDER_PROVENANCE_CLASS}
        ),
    )
    case(
        "native-render-proof-overclaim", "SCHEMA",
        lambda value: value["assetDecisions"][native_index].update(
            {"provenanceSource": "hash-bound-skillpilot-source-render"}
        ),
    )
    case(
        "native-pending-license-overclaim", "PENDING_DECISION_NOT_CLOSED",
        lambda value: value["assetDecisions"][native_index].update(
            {"licenseExpression": "Apache-2.0"}
        ),
    )
    case(
        "native-automatic-approval", "ASSET_AUTOMATIC_ALLOWED_FORBIDDEN",
        lambda value: value["assetDecisions"][native_index].update(
            automatic_apache_decision(source.root_license)
        ),
    )
    for note_index, note in enumerate(AI_ASSISTED_NATIVE_LICENSE_NOTES):
        case(
            f"native-provenance-note-is-not-license-{note_index}",
            "ALLOWED_LICENSE_INVALID",
            lambda value, note=note: value["assetDecisions"][native_index].update({
                "decisionStatus": "human-approved",
                "redistributionStatus": "allowed",
                "licenseExpression": note,
                "reviewer": "fixture-reviewer",
                "reviewedAt": "2026-07-11T00:00:00Z",
                "reviewEvidence": [
                    {"kind": kind, "reference": "fixture", "sha256": None}
                    for kind in ("project-license-decision", "provider-terms-review")
                ],
            }),
        )

    case(
        "duplicate-asset",
        "ASSET_RESOURCE_DUPLICATE",
        lambda value: value["assetDecisions"].append(copy.deepcopy(value["assetDecisions"][0])),
    )
    case(
        "missing-asset",
        "ASSET_DECISION_MISSING",
        lambda value: value["assetDecisions"].pop(),
    )

    def obsolete(value: dict[str, Any]) -> None:
        value["assetDecisions"][0]["resourceId"] = "goal-resource:obsolete:0"

    case("obsolete-asset", "ASSET_DECISION_OBSOLETE", obsolete)
    case(
        "asset-hash-drift",
        "ASSET_HASH_DRIFT",
        lambda value: value["assetDecisions"][0].update(
            {"assetSha256": f"sha256:{'0' * 64}"}
        ),
    )
    case(
        "provider-drift",
        "ASSET_PROVIDER_DRIFT",
        lambda value: value["assetDecisions"][0].update({"provider": "unknown provider"}),
    )
    import_index = imported_indexes[0]
    case(
        "user-import-receipt-hash-drift", "ASSET_PROVENANCE_DRIFT",
        lambda value: value["assetDecisions"][import_index]["userProvidedImportEvidence"].update(
            receiptSha256="sha256:" + "0" * 64
        ),
    )
    case(
        "user-import-evidence-removed", "ASSET_PROVENANCE_DRIFT",
        lambda value: value["assetDecisions"][import_index].pop("userProvidedImportEvidence"),
    )
    legacy_user_index = next(
        index for index, item in enumerate(review["assetDecisions"])
        if item["userProvided"] and "userProvidedImportEvidence" not in item
    )
    case(
        "user-import-evidence-invented", "ASSET_PROVENANCE_DRIFT",
        lambda value: value["assetDecisions"][legacy_user_index].update(
            userProvidedImportEvidence=copy.deepcopy(review["assetDecisions"][import_index]["userProvidedImportEvidence"])
        ),
    )
    case(
        "prompt-evidence-drift",
        "ASSET_PROVENANCE_DRIFT",
        lambda value: value["assetDecisions"][0].update(
            {"promptSha256": f"sha256:{'0' * 64}"}
        ),
    )
    user_index = next(
        index
        for index, item in enumerate(review["assetDecisions"])
        if item["userProvided"] is True
    )
    case(
        "user-provenance-erased",
        "ASSET_PROVENANCE_DRIFT",
        lambda value: value["assetDecisions"][user_index].update(
            {
                "userProvided": False,
                "provenanceClass": "ai-generated-curated",
                "provenanceSource": "provider-pipeline-claim",
            }
        ),
    )
    deterministic_index = next(
        index
        for index, item in enumerate(review["assetDecisions"])
        if item["provenanceClass"] == DETERMINISTIC_RENDER_PROVENANCE_CLASS
    )
    case(
        "deterministic-render-source-hash-drift",
        "ASSET_PROVENANCE_DRIFT",
        lambda value: value["assetDecisions"][deterministic_index][
            "deterministicRenderEvidence"
        ].update({"sourceSha256": f"sha256:{'0' * 64}"}),
    )
    case(
        "deterministic-render-output-hash-drift",
        "ASSET_PROVENANCE_DRIFT",
        lambda value: value["assetDecisions"][deterministic_index][
            "deterministicRenderEvidence"
        ].update({"outputSha256": f"sha256:{'0' * 64}"}),
    )
    case(
        "deterministic-render-evidence-removed",
        "ASSET_PROVENANCE_DRIFT",
        lambda value: value["assetDecisions"][deterministic_index].pop(
            "deterministicRenderEvidence"
        ),
    )

    def deterministic_render_relabelled_as_ai(value: dict[str, Any]) -> None:
        item = value["assetDecisions"][deterministic_index]
        item.update(
            {
                "legacyLicenseNote": LEGACY_IMAGE_LICENSE_NOTE,
                "provenanceClass": "ai-generated-curated",
                "provenanceSource": "provider-pipeline-claim",
            }
        )

    case(
        "deterministic-render-ai-relabel",
        "ASSET_PROVENANCE_DRIFT",
        deterministic_render_relabelled_as_ai,
    )

    def unsupported_allowed(value: dict[str, Any]) -> None:
        item = value["assetDecisions"][0]
        item.update(
            {
                "decisionStatus": "human-approved",
                "redistributionStatus": "allowed",
                "licenseExpression": "Apache-2.0",
                "reviewer": "fixture-reviewer",
                "reviewedAt": "2026-07-11T00:00:00Z",
                "reviewEvidence": [
                    {
                        "kind": "project-license-decision",
                        "reference": "fixture",
                        "sha256": None,
                    }
                ],
            }
        )

    case("allowed-without-provider-review", "ALLOWED_EVIDENCE_INCOMPLETE", unsupported_allowed)

    def automatic_asset(value: dict[str, Any]) -> None:
        item = value["assetDecisions"][0]
        item.update(automatic_apache_decision(source.root_license))

    case("automatic-asset-license", "ASSET_AUTOMATIC_ALLOWED_FORBIDDEN", automatic_asset)
    case(
        "content-digest-drift",
        "REVIEW_IDENTITY_MISMATCH",
        lambda value: value.update({"contentDigest": f"sha256:{'0' * 64}"}),
    )
    case(
        "root-license-drift",
        "ROOT_LICENSE_EVIDENCE_DRIFT",
        lambda value: value["rootLicenseEvidence"].update(
            {"sha256": f"sha256:{'0' * 64}"}
        ),
    )
    case(
        "asset-order-drift",
        "ASSET_DECISION_ORDER_DRIFT",
        lambda value: value["assetDecisions"].__setitem__(
            slice(0, 2), list(reversed(value["assetDecisions"][:2]))
        ),
    )

    def unauthorized_automatic_class(value: dict[str, Any]) -> None:
        item = value["classDecisions"][0]
        item.update(automatic_apache_decision(source.root_license))

    case(
        "unauthorized-automatic-class",
        "CLASS_AUTOMATIC_POLICY_INVALID",
        unauthorized_automatic_class,
    )

    def missing_class_role(value: dict[str, Any]) -> None:
        value["classDecisions"][2]["artifactRoles"].remove("semantic-contract")

    case("missing-class-role", "CLASS_ROLE_COVERAGE_DRIFT", missing_class_role)
    case(
        "target-profile-drift",
        "TARGET_RELEASE_PROFILE_DRIFT",
        lambda value: value["targetReleaseProfile"].update(
            {"sha256": f"sha256:{'0' * 64}"}
        ),
    )
    case(
        "assessment-path-override-removed",
        "PATH_CLASSIFICATION_OVERRIDE_DRIFT",
        lambda value: value["pathClassificationOverrides"].clear(),
    )
    case(
        "summary-overclaim",
        "SUMMARY_DRIFT",
        lambda value: value["summary"].update({"publicationReady": True}),
    )

    if TARGET_PROFILE_ID == "full-standalone-v1.3":
        material_indexes = [i for i, value in enumerate(review["assetDecisions"])
                            if value["provenanceClass"] == ASSESSMENT_MATERIAL_PROVENANCE_CLASS]
        declaration = read_json(repo_file(ASSESSMENT_MATERIAL_PROFILE_PATH))
        if len(material_indexes) != len(declaration["resources"]["assessmentMaterials"]):
            raise ReviewError("Assessment-material source declarations are not completely reviewed")
        for index in material_indexes:
            value = fresh_review["assetDecisions"][index]
            if ({key: value[key] for key in DECISION_FIELDS} != pending_decision()
                    or "promptPath" in value or "promptSha256" in value):
                raise ReviewError("Assessment provenance invented a prompt or redistribution approval")
        material_index = material_indexes[0]
        case("material-source-evidence-loss", "ASSET_PROVENANCE_DRIFT",
             lambda value: value["assetDecisions"][material_index].pop("assessmentMaterialEvidence"))
        case("material-declaration-hash-drift", "ASSET_PROVENANCE_DRIFT",
             lambda value: value["assetDecisions"][material_index]["assessmentMaterialEvidence"].update(
                 {"declarationSha256": "sha256:" + "0" * 64}))
        case("material-source-hash-drift", "ASSET_PROVENANCE_DRIFT",
             lambda value: value["assetDecisions"][material_index]["assessmentMaterialEvidence"]["sources"][0].update(
                 {"sha256": "sha256:" + "0" * 64}))
        case("material-task-use-loss", "ASSET_PROVENANCE_DRIFT",
             lambda value: value["assetDecisions"][material_index]["assessmentMaterialEvidence"]["useGoalIds"].clear())
        case("material-automatic-rights-approval", "ASSET_AUTOMATIC_ALLOWED_FORBIDDEN",
             lambda value: value["assetDecisions"][material_index].update(automatic_apache_decision(source.root_license)))
        case("material-fictitious-prompt", "SCHEMA",
             lambda value: value["assetDecisions"][material_index].update(
                 {"promptPath": "invented.md", "promptSha256": "sha256:" + "0" * 64}))

    stale_completed = copy.deepcopy(review["assetDecisions"][0])
    stale_completed["decisionStatus"] = "human-approved"
    stale_completed["provenanceFingerprint"] = f"sha256:{'0' * 64}"
    try:
        preserve_decision(
            {
                key: value
                for key, value in review["assetDecisions"][0].items()
                if key not in DECISION_FIELDS
            },
            stale_completed,
            "provenanceFingerprint",
            pending_decision(),
        )
    except ReviewError:
        pass
    else:
        raise ReviewError("Self-test failed to reject a stale completed redistribution review")

    for name, expected_code, mutation in cases:
        candidate = copy.deepcopy(review)
        mutation(candidate)
        diagnostics = validate_review(candidate, source, schema)
        codes = {item.code for item in diagnostics}
        if expected_code not in codes:
            raise ReviewError(
                f"Self-test {name!r} missed {expected_code}; got {sorted(codes)}"
            )
    print(
        "Redistribution review self-test passed: "
        f"{len(cases)} fail-closed mutations, {len(invalid_native_pairs)} rejected native "
        "metadata pairs, exact native pending claims and stale completed-review guard"
    )


def select_completion_candidate() -> None:
    """Use new static bindings without changing old reviews or approving content."""
    global PROFILE_ID, TARGET_PROFILE_ID, TARGET_PROFILE_PATH, SCHEMA_ID, REVIEW_ID, CLASS_SPECS
    if TARGET_PROFILE_ID == "full-standalone-completion-v1":
        return
    PROFILE_ID = "de-gymnasium-mathematik-completion-release-model-v1"
    TARGET_PROFILE_ID = "full-standalone-completion-v1"
    TARGET_PROFILE_PATH = "contracts/curriculum-package/v1.1/profiles/full-standalone-completion-v1.profile.json"
    SCHEMA_ID = SCHEMA_ID.replace("/v1/", "/v1.1/")
    REVIEW_ID = "de-gymnasium-mathematik-completion-v1"
    CLASS_SPECS = tuple({**spec, "artifactRoles": spec["artifactRoles"] +
                        (["completion-profile", "completion-scope", "completion-rule-review"] if spec["classId"] == "skillpilot-data" else [])}
                        for spec in CLASS_SPECS)


def select_learning_unit_candidate() -> None:
    """Runtime 1.2: bind the learning-unit release profile; old reviews stay untouched, nothing is approved."""
    global PROFILE_ID, TARGET_PROFILE_ID, TARGET_PROFILE_PATH, SCHEMA_ID, REVIEW_ID, CLASS_SPECS
    if TARGET_PROFILE_ID == "full-standalone-learning-units-v1":
        return
    PROFILE_ID = "de-gymnasium-mathematik-learning-units-release-model-v1"
    TARGET_PROFILE_ID = "full-standalone-learning-units-v1"
    TARGET_PROFILE_PATH = "contracts/curriculum-package/v1.2/profiles/full-standalone-learning-units-v1.profile.json"
    SCHEMA_ID = SCHEMA_ID.replace("/v1/", "/v1.2/")
    REVIEW_ID = "de-gymnasium-mathematik-learning-units-v1"
    CLASS_SPECS = tuple({**spec, "artifactRoles": spec["artifactRoles"] +
                        (["learning-unit-coverage-review"] if spec["classId"] == "skillpilot-data" else [])}
                        for spec in CLASS_SPECS)


def select_runtime_v13_candidate() -> None:
    """Select unpublished 1.3; existing ledgers and all rights decisions remain untouched."""
    global PROFILE_ID, TARGET_PROFILE_ID, TARGET_PROFILE_PATH, SCHEMA_ID, REVIEW_ID, CLASS_SPECS
    if TARGET_PROFILE_ID == "full-standalone-v1.3":
        return
    PROFILE_ID = "de-gymnasium-mathematik-release-model-v1.3"
    TARGET_PROFILE_ID = "full-standalone-v1.3"
    TARGET_PROFILE_PATH = "contracts/curriculum-package/v1.3/profiles/full-standalone-v1.3.profile.json"
    SCHEMA_ID = SCHEMA_ID.replace("/v1/", "/v1.3/")
    REVIEW_ID = "de-gymnasium-mathematik-v1.3"
    CLASS_SPECS = tuple({**spec, "artifactRoles": spec["artifactRoles"] +
                        (["learning-unit-coverage-review"] if spec["classId"] == "skillpilot-data" else [])}
                       for spec in CLASS_SPECS)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--generate", action="store_true", help="Generate or refresh the ledger")
    action.add_argument("--check", action="store_true", help="Validate the committed ledger")
    action.add_argument("--self-test", action="store_true", help="Run mutation tests")
    parser.add_argument(
        "--release-root",
        type=Path,
        default=DEFAULT_RELEASE_ROOT,
        help="Compiled DPK-004 release-model directory",
    )
    parser.add_argument(
        "--ledger", type=Path, default=None, help="Review ledger path (completion candidates use a separate default)"
    )
    parser.add_argument(
        "--schema", type=Path, default=DEFAULT_SCHEMA, help="Trusted review schema"
    )
    parser.add_argument("--completion-candidate", action="store_true", help="bind the reviewed completion-capable runtime profile; no publication approval")
    parser.add_argument("--learning-unit-candidate", action="store_true",
                        help="bind the runtime-1.2 learning-unit profile; no publication approval")
    parser.add_argument("--runtime-v13-candidate", action="store_true",
                        help="bind unpublished runtime 1.3 and exact assessment-material provenance")
    args = parser.parse_args()
    if sum((args.completion_candidate, args.learning_unit_candidate, args.runtime_v13_candidate)) > 1:
        parser.error("Runtime candidates require one exact profile")
    if args.ledger is None:
        args.ledger = (DEFAULT_LEDGER.with_name("de-gymnasium-mathematik-completion-v1.review.json")
                       if args.completion_candidate
                       else DEFAULT_LEDGER.with_name("de-gymnasium-mathematik-learning-units-v1.review.json")
                       if args.learning_unit_candidate
                       else DEFAULT_LEDGER.with_name("de-gymnasium-mathematik-v1.3.review.json")
                       if args.runtime_v13_candidate else DEFAULT_LEDGER)
    if args.runtime_v13_candidate:
        if args.ledger.resolve() in {
                DEFAULT_LEDGER.resolve(),
                DEFAULT_LEDGER.with_name("de-gymnasium-mathematik-learning-units-v1.review.json").resolve(),
                DEFAULT_LEDGER.with_name("de-gymnasium-mathematik-completion-v1.review.json").resolve()}:
            parser.error("Runtime 1.3 must preserve all earlier review ledgers")
        select_runtime_v13_candidate()
        if args.schema == DEFAULT_SCHEMA:
            args.schema = CONTRACT_ROOT.parent / "v1.3/package-redistribution-review.schema.json"
    if args.learning_unit_candidate:
        if args.ledger.resolve() == DEFAULT_LEDGER.resolve():
            parser.error("Learning-unit candidates must use a separate ledger; the existing V1 review is preserved")
        select_learning_unit_candidate()
        if args.schema == DEFAULT_SCHEMA:
            args.schema = CONTRACT_ROOT.parent / "v1.2/package-redistribution-review.schema.json"
    if args.completion_candidate:
        if args.ledger.resolve() == DEFAULT_LEDGER.resolve():
            parser.error("Completion candidates must use a separate ledger; the existing V1 review is preserved")
        select_completion_candidate()
        if args.schema == DEFAULT_SCHEMA:
            args.schema = CONTRACT_ROOT.parent / "v1.1/package-redistribution-review.schema.json"

    try:
        schema = require_object(read_json(args.schema), "redistribution review schema")
        Draft202012Validator.check_schema(schema)
        source = load_source_model(args.release_root)
        if args.generate:
            previous = read_json(args.ledger) if args.ledger.exists() else None
            review = build_review(source, previous)
            diagnostics = validate_review(review, source, schema)
            if diagnostics:
                for item in diagnostics:
                    print(f"[{item.code}] {item.path}: {item.message}", file=sys.stderr)
                raise ReviewError("Refusing to write an invalid redistribution review")
            write_json_atomic(args.ledger, review)
            print(f"Wrote {args.ledger.relative_to(REPO_ROOT)}")
            print_summary(review)
            return 0

        review = require_object(read_json(args.ledger), "redistribution review ledger")
        if args.self_test:
            run_self_test(review, source, schema)
            return 0
        diagnostics = validate_review(review, source, schema)
        if diagnostics:
            for item in diagnostics:
                print(f"[{item.code}] {item.path}: {item.message}", file=sys.stderr)
            return 1
        print_summary(review)
        print("Redistribution review ledger is current and internally consistent.")
        return 0
    except (ReviewError, OSError, ValueError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
