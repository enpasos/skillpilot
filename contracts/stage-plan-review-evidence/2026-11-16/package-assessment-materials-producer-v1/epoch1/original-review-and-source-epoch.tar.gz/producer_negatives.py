from pathlib import Path
import copy, hashlib, json, sys, datetime
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import compile_curriculum_release_model as producer

profile = json.loads((ROOT / "contracts/curriculum-package/v1.3/profiles/de-gymnasium-mathematik-release-model-v1.3.profile.json").read_text())
results = []
for name in ("missing-actual-task-stimulus-declaration", "unused-orphan-stimulus-declaration"):
    variant = copy.deepcopy(profile)
    if name.startswith("missing"):
        variant["resources"]["assessmentMaterials"].pop()
    else:
        extra = copy.deepcopy(variant["resources"]["assessmentMaterials"][0])
        extra["url"] = "/assets/assessment-materials/mathematik/no-actual-task-use.svg"
        extra["resourceId"] = "task-material:" + "0" * 64
        extra["order"] = 10000
        variant["resources"]["assessmentMaterials"].append(extra)
    path = OUT / (name + ".profile.json")
    path.write_text(json.dumps(variant, ensure_ascii=False, indent=2) + "\n")
    destination = OUT / ("negative-model-" + name)
    try:
        producer.compile_model(path, destination)
    except producer.CompilationError as error:
        assert "Required task-image references and the closed material inventory differ" in str(error), str(error)
        result = {"case": name, "status": "REJECTED_BY_ACTUAL_COMPILER", "error": str(error),
                  "profileSHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
                  "destination": str(destination.relative_to(ROOT))}
        print(json.dumps(result), flush=True)
        results.append(result)
    else:
        raise AssertionError("Actual producer accepted invalid material inventory: " + name)
(OUT / "actual-producer-negative-cases.actual.json").write_text(json.dumps({
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "status": "PASS_ACTUAL_PRODUCER_NEGATIVE_CASES", "cases": results,
    "sourceWrites": False, "onlyTmpProfileAndOutputWrites": True}, indent=2) + "\n")
