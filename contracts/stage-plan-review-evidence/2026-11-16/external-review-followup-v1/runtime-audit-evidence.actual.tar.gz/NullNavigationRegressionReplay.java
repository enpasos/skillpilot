package com.skillpilot.backend.service;
public class NullNavigationRegressionReplay {
 public static void main(String[] args) {
  boolean failed=false;
  try { new AutomaticCompletionAtomicDomainTest().completedWorkDoesNotInventCompletionForNullOrEmptyNavigation(); }
  catch (NullPointerException ex) { failed=true; System.out.println("OBSERVED_NULL_CONTAINS_NPE="+ex.getMessage()); }
  if(args[0].equals("before") && !failed) throw new AssertionError("Regression did not detect the unguarded null stream");
  if(args[0].equals("after") && failed) throw new AssertionError("Fixed regression unexpectedly still throws");
  System.out.println("EXPECTED_"+args[0].toUpperCase()+"_OUTCOME_CONFIRMED");
 }
}
