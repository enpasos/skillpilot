package com.skillpilot.backend.service;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import com.fasterxml.jackson.databind.*;
import com.skillpilot.backend.api.*;
import com.skillpilot.backend.completion.*;
import com.skillpilot.backend.domain.*;
import com.skillpilot.backend.landscape.*;
import com.skillpilot.backend.repository.*;
import com.skillpilot.backend.service.*;
import java.nio.file.*;
import java.util.*;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

/** Diagnostics through public LearnerService methods with real, pinned b5 catalog/views.
 * Only persistence and events are in-memory doubles; no synthetic GoalProjection is constructed. */
public class PublicAtomicDomainReplay {
 static final String ROOT="a0e13c56-c25f-4742-9272-3a1a603ee52e";
 static final class ObservingCompletion extends CompletionApplicationService {
  final List<Map<String,Object>> observations=new ArrayList<>();
  ObservingCompletion(){super(new CompletionProfileCatalog(Map.of(),Map.of(),"b5-public-atomic-audit",true));}
  @Override public synchronized CompiledCompletionProfile compileAutomatic(CompletionProfileDefinition definition,
      String identity,Map<String,LearningGoal> graph,Set<String> targets,Set<String> level2){
   var row=new LinkedHashMap<String,Object>();row.put("profile",definition.id());row.put("requestedTargets",targets.size());
   row.put("unknownTargets",targets.stream().filter(id->!graph.containsKey(id)).sorted().toList());
   row.put("explicitClusterTargets",targets.stream().filter(id->graph.containsKey(id)&&"cluster".equals(graph.get(id).getType())).sorted().toList());
   try { var result=super.compileAutomatic(definition,identity,graph,targets,level2);row.put("status","compiled");row.put("compiledTargets",result.targetGoalIds().size());return result; }
   catch(RuntimeException e){row.put("status","failed");row.put("type",e.getClass().getName());row.put("message",e.getMessage());if(e instanceof CompletionCompilationException c)row.put("code",c.code());throw e;}
   finally{observations.add(row);}
  }
 }
 public static void main(String[] args)throws Exception{
  Path repo=Path.of(args[0]),output=Path.of(args[1]);var mapper=new ObjectMapper().findAndRegisterModules().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
  var properties=new LandscapeProperties();properties.setDirectory(repo.resolve("curricula").toString());
  var mappings=new GoalMappingService(properties,mapper);mappings.pinRuntimeGeneration();
  var landscapes=new LandscapeService(properties,mapper,mappings);landscapes.pinRuntimeGeneration();
  var contains=new TreeMap<String,List<String>>();landscapes.getAll().forEach(l->l.getGoals().forEach(g->contains.put(g.getId(),g.getContains()==null?List.of():g.getContains())));
  var compositions=new CompositionViewService(properties,mapper,()->contains);
  var decks=new DeckResourceService(properties);decks.pinRuntimeGeneration();
  var learnerRepo=mock(LearnerRepository.class);var masteryRepo=mock(MasteryRepository.class);var clients=mock(LearnerClientStateRepository.class);var planned=mock(PlannedGoalRepository.class);
  final Learner[] current={null};var focus=new ArrayList<String>();
  when(learnerRepo.findById(anyString())).thenAnswer(x->Optional.ofNullable(current[0]));
  when(learnerRepo.findBySkillpilotIdForUpdate(anyString())).thenAnswer(x->Optional.ofNullable(current[0]));
  when(learnerRepo.existsById(anyString())).thenReturn(true);when(learnerRepo.save(any(Learner.class))).thenAnswer(x->x.getArgument(0));
  when(masteryRepo.findByLearner_SkillpilotId(anyString())).thenReturn(List.of());
  when(planned.findByLearner_SkillpilotId(anyString())).thenAnswer(x->focus.stream().map(id->new PlannedGoal(current[0],id)).toList());
  var service=new LearnerService(learnerRepo,clients,masteryRepo,planned,landscapes,mappings,decks,mapper,mock(ApplicationEventPublisher.class));
  ReflectionTestUtils.setField(service,"compositionViewService",compositions);
  var automatic=new ObservingCompletion();ReflectionTestUtils.setField(service,"completionApplicationService",automatic);
  ReflectionTestUtils.setField(service,"completionCanonicalGraphResolver",new CompletionCanonicalGraphResolver(landscapes,mapper));
  var results=new ArrayList<Map<String,Object>>();
  for(String subject:List.of("68a8ac50-f5f5-4e24-8aa9-5e408ca01ced","7f6fc60c-9fcc-4cc2-b07e-f897a1d0338a"))
   for(String duration:List.of("G8","G9"))for(String stage:List.of("SekI","SekII","CrossStage"))
    for(String course:stage.equals("SekI")?List.of(""):List.of("GK","LK","GK+LK")){
     var config=new LinkedHashMap<String,Object>();config.put(ROOT,Map.of("selected",true,"filterId","DE-HE","stage",stage,"durationModel",duration));
     if(!stage.equals("SekII"))config.put("__skillpilot_stage_scope_sek1__",Map.of("selected",true));
     if(!stage.equals("SekI"))config.put("__skillpilot_stage_scope_sek2__",Map.of("selected",true));
     config.put(subject,course.isEmpty()?Map.of("selected",true):Map.of("selected",true,"filterId",course));
     config.put(CurriculumPersonalizationPlanner.FLOW_STATE_CONFIG_KEY,Map.of(CurriculumPersonalizationPlanner.ROOT_LANDSCAPE_ID_KEY,ROOT,CurriculumPersonalizationPlanner.COMPLETED_OPTION_IDS_KEY,List.of(),CurriculumPersonalizationPlanner.MIGRATION_COMPLETED_KEY,true));
     var learner=new Learner();learner.setSkillpilotId("atomic-audit-"+UUID.randomUUID());learner.setSelectedCurriculum(ROOT);learner.setPersonalCurriculum(mapper.writeValueAsString(config));learner.setAutoPilot(false);learner.setLearningState(LearningState.FRONTIER);current[0]=learner;
     var row=new LinkedHashMap<String,Object>();row.put("subject",subject);row.put("jurisdiction","DE-HE");row.put("duration",duration);row.put("stage",stage);row.put("course",course);row.put("personalCurriculum",config);
     automatic.observations.clear();focus.clear();
     try{
      var scope=service.getPlanningScope(learner.getSkillpilotId(),subject);row.put("publicPlanningScopeAtoms",scope.totalAtomicGoalCount());
      var state=service.getCoachLearnerState(learner.getSkillpilotId());row.put("defaultStatus",state.levelCompletion()==null?null:state.levelCompletion().calculationStatus());row.put("defaultNotice",state.levelCompletion()==null?null:state.levelCompletion().notice());
      focus.add(scope.scopeAtomicGoalIds().getFirst());var narrow=service.getCoachLearnerState(learner.getSkillpilotId());row.put("narrowFocus",List.copyOf(focus));row.put("narrowStatus",narrow.levelCompletion()==null?null:narrow.levelCompletion().calculationStatus());
     }catch(RuntimeException e){row.put("publicErrorType",e.getClass().getName());row.put("publicError",e.getMessage());}
     row.put("actualCompileCalls",List.copyOf(automatic.observations));results.add(row);mapper.writerWithDefaultPrettyPrinter().writeValue(output.toFile(),results);
     System.out.println("PUBLIC_SCOPE "+subject+" "+duration+" "+stage+" "+course+" status="+row.get("defaultStatus")+" error="+row.get("publicError"));
    }
 }
}
