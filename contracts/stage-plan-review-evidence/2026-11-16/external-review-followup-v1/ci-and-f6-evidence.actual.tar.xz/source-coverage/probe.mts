import {readFileSync,writeFileSync} from 'node:fs'
import {collectAuthoritativeTargetAtomicGoalIds} from '../../app/scripts/compositionViewSourceCoverage.ts'
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8')),p='curricula/DE/Gymnasium/',physics=read(p+'canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json'),math=read(p+'canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json')
const ids=['d61ea362-f6c3-5eab-ac30-2d0e265ac0f6','677a192d-8bbe-57fc-bb7a-1c1ed5fba32b'],rows=[]
for(const name of ['de-he-gk','de-he-lk','de-bb-gk','de-bb-lk','de-by-gk','de-by-lk']){const view=read(p+'composition-views/physik/'+name+'.view.json'),visible=collectAuthoritativeTargetAtomicGoalIds(physics,view);rows.push({view:name,goals:ids.map(id=>({id,selected:visible.has(id)}))})}
const task='2f8a3a90-717d-5ac1-b54e-facca26e9008';for(const name of ['de-by-gk','de-by-lk']){const view=read(p+'composition-views/mathematik/'+name+'.view.json'),visible=collectAuthoritativeTargetAtomicGoalIds(math,view);rows.push({view:'math:'+name,goals:[{id:task,selected:visible.has(task)}]})}
writeFileSync(process.argv[2],JSON.stringify({rows},null,2)+'\n');console.log(JSON.stringify(rows,null,2))
