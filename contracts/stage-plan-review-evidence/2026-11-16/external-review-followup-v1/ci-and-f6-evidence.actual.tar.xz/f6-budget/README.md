Separate follow-up to local checkpoint4286f492, preserving the original F6 receipt. A complete report may evaluate at most1,024 selections across all declared plans. Exact BigInt preflight counts the whole inventory before constructing any Cartesian product. Exceeding the operational limit returns SPR-SELECTION-LIMIT, invalid-input and an empty scope list; there is no truncated or partially passing report.

The focused tests exercise exactly1,024 accepted cases,1,025 rejected cases, a later oversized plan after an otherwise valid prefix, and a40-subject product beyond Number precision. Existing15/30 independent profile/subset cases, nested UI/materializer tests,51 materialization negatives, strict targeted TypeScript and lint remain passing.

This limit supports the bounded pilot; it is not acceptance of large20-subject plans or a claim of native mixed-profile/real-plan measurement. No current PR source, original receipt, commit or remote branch was changed by this agent.
