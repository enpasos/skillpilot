import assert from 'node:assert/strict';
import fs from 'node:fs';
import {diagnoseStagePlanLearningFlow} from '/home/enpasos/projects/skillpilot/app/src/utils/stagePlanReport';
import {validateStagePlanCatalog,STAGE_PLAN_SCHEMA,PLAN_COMPOSITION_SCHEMA} from '/home/enpasos/projects/skillpilot/app/src/utils/stagePlan';
const base='/tmp/skillpilot-f6-independent-review-20261116';
const scope={schoolForm:'Gymnasium',jurisdiction:'DE-HE',durationModel:'G9'};
const plan={ $schema:STAGE_PLAN_SCHEMA,planFormatVersion:'1.0',planId:'independent-combined',scope,
 rootUnit:{id:'root',label:'Fixture',children:['early','late']},
 units:[{id:'early',label:'Early',kind:'stage',stage:'SekI',parentUnitId:'root',after:[]},{id:'late',label:'Late',kind:'stage',stage:'SekII',parentUnitId:'root',after:['early']}],
 subjectViews:['GK','LK','ALL'].map(courseProfile=>({landscapeId:'subject',courseProfile,viewId:'view-'+courseProfile}))};
const goals=new Map([['p',{id:'p',title:'P',type:'atomic',requires:['q']}],['q',{id:'q',title:'Q',type:'atomic',requires:[]}],['x',{id:'x',title:'X',type:'atomic',requires:[]}]]);
const view=(courseProfile:string,early:string[],late:string[])=>({$schema:PLAN_COMPOSITION_SCHEMA,viewFormatVersion:'1.1',viewId:'view-'+courseProfile,landscapeId:'subject',language:'de',scope:{...scope,courseProfile,stage:'CrossStage'},planBinding:{planId:plan.planId},rootNodes:[early,late].map((ids,index)=>({kind:'structure',id:['early','late'][index],label:['Early','Late'][index],planUnitId:['early','late'][index],children:ids.map(goalId=>({kind:'goalEntry',goalId}))}))});
const views=[view('GK',['p'],[]),view('LK',[],['q']),view('ALL',['x'],[])];

views.find(v=>v.scope.courseProfile==='LK')!.rootNodes.forEach(n=>n.children=[]);
const report=diagnoseStagePlanLearningFlow({plans:[plan],views,goals});
assert.equal(report.status,'invalid-input');assert.deepEqual(report.scopes,[]);
assert(report.findings.some(f=>f.code==='SPR-INVENTORY'&&f.message.includes('no atomic targets')));
fs.writeFileSync(base+'/empty-course.actual.json',JSON.stringify(report,null,2));console.log('EMPTY_DECLARED_COURSE_INVALIDATES_COMPLETE_REPORT_WITHOUT_PASSING_PREFIX');
