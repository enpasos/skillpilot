import com.fasterxml.jackson.databind.ObjectMapper;
import com.skillpilot.backend.landscape.LandscapeProperties;
import com.skillpilot.backend.service.CompositionViewService;
import java.util.*;
import java.nio.file.*;
public class AliasRuntimeReplay {
 public static void main(String[] args) throws Exception {
  var props=new LandscapeProperties();props.setDirectory(args[0]);var mapper=new ObjectMapper();
  var service=new CompositionViewService(props,mapper,()->Map.of("p",List.<String>of(),"q",List.<String>of(),"x",List.<String>of()));
  var scope=new LinkedHashMap<String,String>(Map.of("schoolForm","Gymnasium","jurisdiction","DE-HE","durationModel","G9","stage","CrossStage"));
  scope.put("courseProfile","GK+LK");var combined=service.findLearnerScopeView("subject",scope);

  if(!new HashSet<>((List<String>)combined.get("mergedFromViewIds")).equals(Set.of("view-LK","view-GK","view-gk-lower")))throw new AssertionError(combined);
  mapper.writerWithDefaultPrettyPrinter().writeValue(Path.of(args[1]).toFile(),combined);
  System.out.println("ACTUAL_RUNTIME_COMBINED_MERGES_BOTH_CASE_ALIAS_GK_AUTHORITIES_AND_LK");
 }
}
