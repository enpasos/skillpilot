import com.fasterxml.jackson.databind.ObjectMapper;
import com.skillpilot.backend.landscape.LandscapeProperties;
import com.skillpilot.backend.service.CompositionViewService;
import java.util.*;
import java.nio.file.*;
public class CombinedRuntimeReplay {
 public static void main(String[] args) throws Exception {
  var props=new LandscapeProperties();props.setDirectory(args[0]);var mapper=new ObjectMapper();
  var service=new CompositionViewService(props,mapper,()->Map.of("p",List.<String>of(),"q",List.<String>of(),"x",List.<String>of()));
  var scope=new LinkedHashMap<String,String>(Map.of("schoolForm","Gymnasium","jurisdiction","DE-HE","durationModel","G9","stage","CrossStage"));
  scope.put("courseProfile","GK+LK");var combined=service.findLearnerScopeView("subject",scope);
  scope.put("courseProfile","ALL");var all=service.findLearnerScopeView("subject",scope);
  if(!List.of("view-LK","view-GK").equals(combined.get("mergedFromViewIds")))throw new AssertionError(combined);
  if(!"view-ALL".equals(all.get("viewId")))throw new AssertionError(all);
  var result=Map.of("method","CompositionViewService.findLearnerScopeView","GK+LK",combined,"ALL",all);
  mapper.writerWithDefaultPrettyPrinter().writeValue(Path.of(args[1]).toFile(),result);
  System.out.println("ACTUAL_RUNTIME_GK_PLUS_LK_MERGES_GK_LK_WHILE_ALL_IS_SEPARATE_EXACT_AUTHORITY");
 }
}
