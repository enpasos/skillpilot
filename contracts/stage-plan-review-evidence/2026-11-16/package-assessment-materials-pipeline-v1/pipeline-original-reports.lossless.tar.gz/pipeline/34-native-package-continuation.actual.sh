#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="/home/enpasos/projects/skillpilot"
PROFILE="contracts/curriculum-package/v1.3/profiles/de-gymnasium-mathematik-release-model-v1.3.profile.json"
PACKAGE_PROFILE="contracts/curriculum-package/v1.3/profiles/full-standalone-v1.3.profile.json"
CONTRACTS_DIR="contracts/curriculum-package/v1.3"
REDISTRIBUTION_LEDGER="curricula/DE/Gymnasium/quality/package-redistribution/de-gymnasium-mathematik-v1.3.review.json"
OUTPUT_BASE="tmp/curriculum-release-model"
OUTPUT_A="${OUTPUT_BASE}/mathematik-v1.3-a"
OUTPUT_B="${OUTPUT_BASE}/mathematik-v1.3-b"
PACKAGE_OUTPUT="${OUTPUT_BASE}/full-standalone-package"
PACKAGE_ARCHIVE_ROOT="skillpilot-curriculum-de-gymnasium-mathematik-0.1.0-runtime.1.json"
PACKAGE_ZIP="${PACKAGE_OUTPUT}/${PACKAGE_ARCHIVE_ROOT}.zip"
# Keep the shell-owned stdout target outside the Builder's atomically replaced
# output directory. Otherwise the open report file can be renamed into and
# removed with the Builder backup during promotion.
PACKAGE_BUILD_REPORT="${OUTPUT_BASE}/full-standalone-package-build-summary.json"
PACKAGE_VALIDATION_REPORT="${PACKAGE_OUTPUT}/full-package-validation-report.json"
PACKAGE_READINESS_REPORT="${PACKAGE_OUTPUT}/readiness-report.json"
PACKAGE_CONSUMER_SMOKE_REPORT="${PACKAGE_OUTPUT}/package-consumer-smoke-report.json"
PACKAGE_CONSUMER_SMOKE_WORK="${OUTPUT_BASE}/package-consumer-smoke"
PACKAGE_STORE="${OUTPUT_BASE}/provisioned-store"
PACKAGE_INSTALL_REPORT="${PACKAGE_OUTPUT}/provision-install.json"
PACKAGE_VERIFY_REPORT="${PACKAGE_OUTPUT}/provision-verify.json"
PACKAGE_ACTIVATE_REPORT="${PACKAGE_OUTPUT}/provision-activate.json"
PACKAGE_STATUS_REPORT="${PACKAGE_OUTPUT}/provision-status.json"
EXPECTED_CONTENT_DIGEST="sha256:4e371d4e3fa31ccabfc9b32e061ada55d18fc8a8ebf1f087d9a6109469645a04"
cd "${ROOT_DIR}"

python3 -B scripts/validate_full_standalone_curriculum_package.py \
  --contracts-dir "${CONTRACTS_DIR}" \
  --zip "${PACKAGE_ZIP}" \
  --report "${PACKAGE_VALIDATION_REPORT}"

python3 -B - "${PACKAGE_ZIP}" "${PACKAGE_VALIDATION_REPORT}" <<'PY'
import hashlib
import json
import sys
import zipfile
from pathlib import Path

zip_path = Path(sys.argv[1])
report = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
with zipfile.ZipFile(zip_path) as archive:
    root = report["package"]["archiveRoot"]
    manifest_bytes = archive.read(f"{root}/metadata/manifest.json")
    manifest = json.loads(manifest_bytes)
    closure_records = [
        record for record in manifest["files"]
        if record.get("role") == "dependency-closure"
    ]
    if len(closure_records) != 1:
        raise SystemExit("real package has no exact dependency-closure record")
    closure = json.loads(archive.read(f"{root}/{closure_records[0]['path']}"))

expected = {
    "manifestSha256": hashlib.sha256(manifest_bytes).hexdigest(),
    "closureDigest": closure["closureDigest"],
    "definitionIndexDigest": closure["definitionIndexDigest"],
}
actual = {key: report["package"].get(key) for key in expected}
if report.get("reportFormatVersion") != 2:
    raise SystemExit("real package validator report is not protocol v2")
if report.get("validatorId") != "skillpilot-full-standalone-package-validator-v2":
    raise SystemExit("real package validator identity is not v2")
if manifest.get("supportedSkillpilotSoftware") != ">=0.1.0 <1.0.0":
    raise SystemExit("real package does not accept curriculum-consumer API version 0.1.0")
if actual != expected:
    raise SystemExit(f"real package validator binding mismatch: {actual!r} != {expected!r}")
if any(gate.get("status") != "passed" for gate in report.get("gates", {}).values()):
    raise SystemExit("real package validator report does not pass every gate")
PY

python3 -B scripts/provision_curriculum_package.py install \
  --contracts-dir "${CONTRACTS_DIR}" \
  --store "${PACKAGE_STORE}" \
  --zip "${PACKAGE_ZIP}" \
  > "${PACKAGE_INSTALL_REPORT}"

PACKAGE_OUTER_SHA256="$(python3 -B - "${PACKAGE_INSTALL_REPORT}" <<'PY'
import json
import sys

print(json.load(open(sys.argv[1], encoding="utf-8"))["outerZipSha256"])
PY
)"

python3 -B scripts/provision_curriculum_package.py verify \
  --store "${PACKAGE_STORE}" \
  --outer-sha256 "${PACKAGE_OUTER_SHA256}" \
  > "${PACKAGE_VERIFY_REPORT}"

python3 -B scripts/provision_curriculum_package.py activate \
  --store "${PACKAGE_STORE}" \
  --outer-sha256 "${PACKAGE_OUTER_SHA256}" \
  --expected-active-sha256 none \
  --consumer-version 0.1.0 \
  > "${PACKAGE_ACTIVATE_REPORT}"

python3 -B scripts/provision_curriculum_package.py status \
  --store "${PACKAGE_STORE}" \
  > "${PACKAGE_STATUS_REPORT}"

python3 -B - \
  "${PACKAGE_BUILD_REPORT}" \
  "${PACKAGE_INSTALL_REPORT}" \
  "${PACKAGE_VERIFY_REPORT}" \
  "${PACKAGE_ACTIVATE_REPORT}" \
  "${PACKAGE_STATUS_REPORT}" <<'PY'
import json
import sys

build, install, verify, activate, status = [
    json.load(open(path, encoding="utf-8")) for path in sys.argv[1:]
]
if install.get("outerZipSha256") != build.get("zipSha256"):
    raise SystemExit("provisioner outer ZIP identity differs from builder")
if install.get("contentDigest") != build.get("contentDigest"):
    raise SystemExit("provisioner contentDigest differs from builder")
if verify.get("outerZipSha256") != install.get("outerZipSha256"):
    raise SystemExit("provisioner verify identity differs from install")
if verify.get("manifestFiles") != build.get("manifestFileCount"):
    raise SystemExit("provisioner verify manifest count differs from builder")
active_sha = activate.get("activeLockSha256")
if not isinstance(active_sha, str) or status.get("activeLockSha256") != active_sha:
    raise SystemExit("provisioner activation/status lock binding differs")
packages = (status.get("active") or {}).get("packages") or []
if len(packages) != 1 or packages[0].get("outerZipSha256") != build.get("zipSha256"):
    raise SystemExit("provisioner active lock does not select the built ZIP")
PY

python3 -B scripts/evaluate_curriculum_package_readiness.py \
  --contracts-dir "${CONTRACTS_DIR}" \
  --zip "${PACKAGE_ZIP}" \
  --consumer-smoke-store "${PACKAGE_STORE}" \
  --consumer-smoke-work-dir "${PACKAGE_CONSUMER_SMOKE_WORK}" \
  --consumer-smoke-report "${PACKAGE_CONSUMER_SMOKE_REPORT}" \
  --report "${PACKAGE_READINESS_REPORT}" \
  --expect-status not-ready-incomplete \
  --compact \
  >/dev/null

python3 -B - "${PACKAGE_CONSUMER_SMOKE_REPORT}" "${PACKAGE_READINESS_REPORT}" <<'PY'
import json
import sys

smoke, readiness = [json.load(open(path, encoding="utf-8")) for path in sys.argv[1:]]
if smoke.get("status") != "passed" or smoke.get("summary") != {
    "required": 15,
    "passed": 15,
    "failed": 0,
    "notRun": 0,
}:
    raise SystemExit("real package consumer smoke did not pass its closed 15-check set")
checks = {check["id"]: check for check in readiness.get("checks", [])}
consumer = checks.get("consumer.hermetic-package-only") or {}
if consumer.get("result") != "pass":
    raise SystemExit("readiness report did not accept the hermetic consumer proof")
consumer_evidence = readiness.get("consumerEvidence") or {}
if consumer_evidence.get("status") != "accepted":
    raise SystemExit("readiness report did not bind the consumer-smoke evidence")
if consumer_evidence.get("provenance") != "self-executed" or not consumer_evidence.get("freshReport"):
    raise SystemExit("readiness report did not self-execute fresh consumer evidence")
if not readiness.get("evaluator", {}).get("completeForPolicy"):
    raise SystemExit("readiness evaluator did not complete the full policy")
if consumer_evidence.get("assemblySha256") != smoke.get("application", {}).get("assemblySha256"):
    raise SystemExit("readiness report assembly binding differs from consumer report")
if consumer_evidence.get("evidenceBundleSha256") != smoke.get("evidenceBundle", {}).get("sha256"):
    raise SystemExit("readiness report evidence-tree binding differs from consumer report")
decision = readiness.get("decision") or {}
if decision.get("status") != "not-ready-incomplete" or decision.get("standaloneProfileReady") is not False:
    raise SystemExit("open human publication gates were incorrectly overridden by consumer operability")
PY

echo "Remaining actual package phases passed: independent ZIP validation, secure provisioning/activation, hermetic consumer and human-gated readiness. Model/ZIP phases are evidenced separately."
