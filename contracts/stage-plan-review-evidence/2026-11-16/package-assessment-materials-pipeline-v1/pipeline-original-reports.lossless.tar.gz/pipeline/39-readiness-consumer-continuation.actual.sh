#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="/home/enpasos/projects/skillpilot"
PROFILE="contracts/curriculum-package/v1.3/profiles/de-gymnasium-mathematik-release-model-v1.3.profile.json"
PACKAGE_PROFILE="contracts/curriculum-package/v1.3/profiles/full-standalone-v1.3.profile.json"
CONTRACTS_DIR="contracts/curriculum-package/v1.3"
REDISTRIBUTION_LEDGER="curricula/DE/Gymnasium/quality/package-redistribution/de-gymnasium-mathematik-v1.3.review.json"
OUTPUT_BASE="tmp/curriculum-release-model"
OUTPUT_A="${OUTPUT_BASE}/mathematik-v1.3-a"
OUTPUT_B="${OUTPUT_BASE}/mathematik-v1.3-b"
PACKAGE_OUTPUT="${OUTPUT_BASE}/full-standalone-package"
PACKAGE_ARCHIVE_ROOT="skillpilot-curriculum-de-gymnasium-mathematik-0.1.0-runtime.1.json"
PACKAGE_ZIP="${PACKAGE_OUTPUT}/${PACKAGE_ARCHIVE_ROOT}.zip"
# Keep the shell-owned stdout target outside the Builder's atomically replaced
# output directory. Otherwise the open report file can be renamed into and
# removed with the Builder backup during promotion.
PACKAGE_BUILD_REPORT="${OUTPUT_BASE}/full-standalone-package-build-summary.json"
PACKAGE_VALIDATION_REPORT="${PACKAGE_OUTPUT}/full-package-validation-report.json"
PACKAGE_READINESS_REPORT="${PACKAGE_OUTPUT}/readiness-report.json"
PACKAGE_CONSUMER_SMOKE_REPORT="${PACKAGE_OUTPUT}/package-consumer-smoke-report.json"
PACKAGE_CONSUMER_SMOKE_WORK="${OUTPUT_BASE}/package-consumer-smoke"
PACKAGE_STORE="${OUTPUT_BASE}/provisioned-store"
PACKAGE_INSTALL_REPORT="${PACKAGE_OUTPUT}/provision-install.json"
PACKAGE_VERIFY_REPORT="${PACKAGE_OUTPUT}/provision-verify.json"
PACKAGE_ACTIVATE_REPORT="${PACKAGE_OUTPUT}/provision-activate.json"
PACKAGE_STATUS_REPORT="${PACKAGE_OUTPUT}/provision-status.json"
EXPECTED_CONTENT_DIGEST="sha256:4e371d4e3fa31ccabfc9b32e061ada55d18fc8a8ebf1f087d9a6109469645a04"
cd "${ROOT_DIR}"

python3 -B scripts/evaluate_curriculum_package_readiness.py \
  --contracts-dir "${CONTRACTS_DIR}" \
  --zip "${PACKAGE_ZIP}" \
  --consumer-smoke-store "${PACKAGE_STORE}" \
  --consumer-smoke-work-dir "${PACKAGE_CONSUMER_SMOKE_WORK}" \
  --consumer-smoke-report "${PACKAGE_CONSUMER_SMOKE_REPORT}" \
  --report "${PACKAGE_READINESS_REPORT}" \
  --expect-status not-ready-incomplete \
  --compact \
  >/dev/null

python3 -B - "${PACKAGE_CONSUMER_SMOKE_REPORT}" "${PACKAGE_READINESS_REPORT}" <<'PY'
import json
import sys

smoke, readiness = [json.load(open(path, encoding="utf-8")) for path in sys.argv[1:]]
if smoke.get("status") != "passed" or smoke.get("summary") != {
    "required": 15,
    "passed": 15,
    "failed": 0,
    "notRun": 0,
}:
    raise SystemExit("real package consumer smoke did not pass its closed 15-check set")
checks = {check["id"]: check for check in readiness.get("checks", [])}
consumer = checks.get("consumer.hermetic-package-only") or {}
if consumer.get("result") != "pass":
    raise SystemExit("readiness report did not accept the hermetic consumer proof")
consumer_evidence = readiness.get("consumerEvidence") or {}
if consumer_evidence.get("status") != "accepted":
    raise SystemExit("readiness report did not bind the consumer-smoke evidence")
if consumer_evidence.get("provenance") != "self-executed" or not consumer_evidence.get("freshReport"):
    raise SystemExit("readiness report did not self-execute fresh consumer evidence")
if not readiness.get("evaluator", {}).get("completeForPolicy"):
    raise SystemExit("readiness evaluator did not complete the full policy")
if consumer_evidence.get("assemblySha256") != smoke.get("application", {}).get("assemblySha256"):
    raise SystemExit("readiness report assembly binding differs from consumer report")
if consumer_evidence.get("evidenceBundleSha256") != smoke.get("evidenceBundle", {}).get("sha256"):
    raise SystemExit("readiness report evidence-tree binding differs from consumer report")
decision = readiness.get("decision") or {}
if decision.get("status") != "not-ready-incomplete" or decision.get("standaloneProfileReady") is not False:
    raise SystemExit("open human publication gates were incorrectly overridden by consumer operability")
PY

echo "Actual readiness and fresh hermetic consumer phases passed; model, ZIP and store phases are evidenced separately."
