# Gezielter öffentlicher Physik-Quellenindex-Fix

16. November 2026. Konkreter CI-Fehler in CurriculumCI, Job 133122374448, vom Root zugewiesen. Eigene tatsächlich ausgeführte lokale Reproduktion `check-before.actual.log`: genau sieben veraltete Physik-Zielbeschreibungen, Exit 1.

Der echte bestehende Generator wurde für genau die sieben IDs mit aktuellen Eingängen ausgeführt (`commands.actual.json`, `generated-seven.actual.json`, Exit 0). Anschließend wurden ausschließlich die daraus erzeugten aktuellen `items[*].goal.description`-Werte in den bestehenden öffentlichen Index übernommen. Der ganze Rest wurde strukturell verglichen und blieb identisch; auch die ursprüngliche rohe Byteformatierung außerhalb der sieben Textspannen blieb erhalten. Kein Generator oder Checker wurde verändert. Nur `app/public/data/goal-source-rationales-physics-public.json` wurde im Hauptworkspace geschrieben.

`exact-public-index.diff` und `targeted-change.actual.json` benennen alle sieben alten/neuen Texte. Titel, 438-Element-Inventar, Request/Summary, Quellenpassagen, Quellenrouten, Mappingreviewdaten, MEM-Status, Einschränkungen und ursprünglicher generatedAt-Wert sind unverändert. Eine zusätzliche Änderung alternativer Quellenrouten, die der heutige Generator beim Bewegungsziel ce431132 erzeugt, wurde nicht mit übernommen: Sie ist kein Teil dieses gezielten Deskriptions-Freshnessfehlers und bedarf hier keines erfundenen neuen Herkunftsreviews.

Der identische fehlgeschlagene npm-Check besteht nach dem Fix mit Exit 0, einschließlich beider konfigurierten Indizes (Mathematik754, Physik438). `git diff --check` für die Datei besteht. Keine breite Curriculum-QA, kein vollständiger CI-/Main-Abschluss und kein Commit/Push durch den bearbeitenden Agenten.

Die HE-Planarbeit wurde unverändert im separaten Worktree eingecheckt als TMP-Checkpoint (kein Gitcommit): `/tmp/skillpilot-stage-plan-he-runtime-20261116/tmp/physics-he-plan-authoring-20261116/g9/checkpoint.actual.json`.
