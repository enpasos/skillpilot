from pathlib import Path
import datetime,gzip,hashlib,io,json,subprocess,tarfile
root=Path('/home/enpasos/projects/skillpilot'); src=Path(__file__).resolve().parent
out=root/'contracts/stage-plan-review-evidence/2026-11-16/ci-metadata-and-browser-followup-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
down=json.loads((src/'downstream.actual.json').read_text())
front=json.loads((src/'frontend-artifact-checks.actual.json').read_text())
repairs=json.loads((src/'downstream-repairs.actual.json').read_text())
assert len(down['results'])==28
assert [(x['name'],x['exitCode']) for x in down['results'] if x['exitCode']] == [('Check Goal Source Rationale Coverage Report',1),('Test Physics Source Method Routes',1),('Test Physics Semiconductor Source Repair',1)]
assert [(x['command'],x['exitCode']) for x in front if x['exitCode']] == [('npm run check:ai-transparency-inventory',1)]
assert all(x['observedTerminalExitCode']==0 for x in repairs['commands'])
for x in repairs['commands']:
 assert sha(root/x['log'])==x['logSha256']
 for p in x['outputPins']: assert sha(root/p['path'])==p['sha256']
files=sorted(p for p in src.iterdir() if p.is_file() and (p.name.endswith(('.actual.log','.actual.json','.py','.patch'))))
archive=out/'downstream-checks.evidence.actual.tar.gz';assert not archive.exists()
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in files:
  data=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for p in files: assert tar.extractfile(p.name).read()==p.read_bytes()
physics=json.loads((out/'physics-author-receipt.actual.json').read_text())
for pin in physics['changedFiles']: assert sha(root/pin['path'])==pin['sha256']
assert all(c['exitCode']==0 for c in physics['commands'])
inputs=[p['path'] for p in physics['changedFiles']]+[
 'app/public/data/goal-source-rationales-physics-public.json',
 'app/scripts/testPersonalCurriculumProjectionUi.ts',
 'curricula/DE/Gymnasium/quality/goal-visualization-review/physik-rollout-status.json',
 'curricula/DE/Gymnasium/quality/goal-visualization-review/physik-rollout-status.md',
 'docs/qa-ci/status/goal-source-rationale-coverage.json',
 'docs/qa-ci/status/goal-source-rationale-coverage.md',
 'docs/legal/ai-transparency-inventory.json',
 'docs/dev/stage-plan-management-summary.md',
 '.github/workflows/ci.yml',
 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json',
 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json',
]
receipt={
 'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'baseHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'sourcePins':[{'path':p,'sha256':sha(root/p)} for p in inputs],
 'downstreamCommands':down,
 'frontendArtifactChecks':front,
 'intentionalGeneratedReportRepairs':repairs,
 'physicsRepairReceipt':'physics-author-receipt.actual.json',
 'resolution':'The two failed Physics steps were repaired and their exact normal commands passed on final pinned bytes in the separate physics author receipt. The two initially stale downstream reports were regenerated or refreshed only in measured fields; their normal checks subsequently exited zero. All other listed downstream steps exited zero on this candidate. The first interrupted build has no claimed successful exit; its complete retry passed.',
 'archive':{'path':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':[{'path':p.name,'sha256':sha(p),'bytes':p.stat().st_size} for p in files]},
 'limits':'Local commands and actual independent reviews, not a new complete remote CI result or main acceptance. No new real Land plan, curriculum/source approval or learner mastery change.'
}
(out/'local-checks.actual.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'sha256':sha(archive)}))
