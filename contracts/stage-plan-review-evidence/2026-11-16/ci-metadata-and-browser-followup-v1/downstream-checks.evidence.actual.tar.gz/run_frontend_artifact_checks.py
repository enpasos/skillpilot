from pathlib import Path
import datetime,hashlib,json,os,subprocess
root=Path('/home/enpasos/projects/skillpilot');out=Path(__file__).resolve().parent
steps=['test:learner-map-build','test:service-worker-update-lifecycle','check:ai-transparency-inventory','check:frontend-shell-assets','check:ai-transparency-artifact']
records=[]
for name in steps:
 log=out/f'frontend-{name.replace(":","-")}.actual.log'
 assert not log.exists()
 record={'command':f'npm run {name}','cwd':'app','startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with log.open('w') as stream:
  result=subprocess.run(['npm','run',name],cwd=root/'app',stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 record.update(exitCode=result.returncode,finishedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log=str(log.relative_to(root)),logSha256=hashlib.sha256(log.read_bytes()).hexdigest());records.append(record)
 (out/'frontend-artifact-checks.actual.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps({'step':name,'exitCode':result.returncode}),flush=True)
