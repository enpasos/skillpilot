import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import yaml

root = Path('/home/enpasos/projects/skillpilot')
out = Path(__file__).resolve().parent
workflow = root / '.github/workflows/ci.yml'
jobs = yaml.safe_load(workflow.read_text())['jobs']
commands = []
for job, start in [
    ('curriculum-integrated-build', 'Check goal visualization rollout coverage'),
    ('graph-validation', 'Check Goal Source Rationale All-Relevant Report'),
]:
    active = False
    for step in jobs[job]['steps']:
        active |= step.get('name') == start
        if active and 'run' in step:
            commands.append({'job': job, 'name': step['name'], 'command': step['run'], 'workingDirectory': step.get('working-directory', 'app')})
receipt = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'workflowSha256': hashlib.sha256(workflow.read_bytes()).hexdigest(),
    'note': 'Exact downstream workflow commands; local environment and generated files, not remote acceptance.',
    'results': [],
}
receipt_path = out / 'downstream.actual.json'
if receipt_path.exists():
    previous = json.loads(receipt_path.read_text())
    assert previous['head'] == receipt['head'] and previous['workflowSha256'] == receipt['workflowSha256']
    receipt = previous
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
           SEMANTIC_ROUTE_POLICY_BASE='64793bdc2270ce67feced439ae20ef03a59e2abe',
           MATURITY_POLICY_BASE='64793bdc2270ce67feced439ae20ef03a59e2abe')
for i, command in enumerate(commands, 1):
    if i <= len(receipt['results']):
        continue
    record = dict(command, startedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    log = out / f'downstream-{i:02d}.actual.log'
    if log.exists():
        interrupted = log.with_name(log.name.replace('.actual.log', '.interrupted.actual.log'))
        assert not interrupted.exists()
        log.rename(interrupted)
        record['previousAttempt'] = {'log': str(interrupted.relative_to(root)), 'runnerExitCode': 143, 'commandExitCode': None, 'accepted': False}
    with log.open('w') as stream:
        result = subprocess.run(['bash', '-e', '-o', 'pipefail', '-c', command['command']],
                                cwd=root / command['workingDirectory'], env=env, start_new_session=True,
                                stdout=stream, stderr=subprocess.STDOUT)
    record.update(exitCode=result.returncode, finishedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), log=str(log.relative_to(root)))
    receipt['results'].append(record)
    (out / 'downstream.actual.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'step': i, 'name': command['name'], 'exitCode': result.returncode}), flush=True)
print(json.dumps({'completed': len(commands), 'failed': sum(x['exitCode'] != 0 for x in receipt['results'])}), flush=True)
