#!/usr/bin/env python3
from biology_original_context_helpers import *
PAIR='curricula/DE/Gymnasium/quality/goal-visualization-review/biologie-neuro21-paired-current-visual-synthesis-root-20261007-v1/twenty-one-exact-rasters-paired-visual-decisions.actual.receipt.json'
def main():
 a=Audit('/dev/shm/skillpilot-v-biology-neuro21-original-families');pr,pairs=original(PAIR)
 for pair in pairs['entries']:
  ref=pair['reviewA']if'neuro-three-supplied'in pair['reviewA']['path']else pair['reviewB'];refs=[pr];r=bound(ref,refs);rr=refs[-1];extra=[]
  if 'first-seven-independent-v-b'in rr['path']:
   v=next(v for v in r['records']if v['canonicalGoalId']==pair['goalId']);assert v['decision']=='KEEP'and v['originalFullSizeActuallyViewed']and all(w['seenByReviewer']for w in v['actualBrowserDisplaysActuallyViewed']);g=v['wholeCurrentStage02CandidateGoal'];asset=v['unchangedOriginalAsset'];views=[w['screenshot']for w in v['actualBrowserDisplaysActuallyViewed']];actor=r['reviewerRole'];date=r['reviewedAtUTC'];reason=v['reasonDe']
  elif 'next-eleven-independent-v-b'in rr['path']:
   v=one(r['rows'],pair['goalId']);assert v['decision']=='KEEP'and v['actualOriginalViewedWithViewImageOriginal']and all(w['viewedWithViewImageOriginal']for w in v['actualDisplays']);g=v['wholeOperativeCandidateGoal'];asset=v['asset'];views=v['actualDisplays'];actor=r['reviewerAgent'];date=r['reviewedAtUTC'];reason=v['scientificAndVisualObservationsDe']
  elif 'neuro-three-supplied'in rr['path']:
   v=one(r['rows'],pair['goalId']);assert v['decision']=='KEEP'and all(w['viewedWithTool']=='view_image original detail'for w in v['actualWidthChecks']);g=v['wholeOperativeBio21CandidateGoal'];asset=v['originalActualViewed'];views=[w['actualViewedScreenshot']for w in v['actualWidthChecks']];actor=r['reviewerAgent'];date=r['reviewedAtUTC'];reason=v['findings']
  else:
   assert 'ce19-v2-independent-v-b'in rr['path']and r['goalId']==pair['goalId']and r['verdict']=='KEEP'and r['independentAIVisualApproval']is True
   g=r['wholeBilingualGoalActuallyRead'];asset=r['selectedAsset'];views=[];actor=r['reviewerTask'];date=r['createdAt'];reason=r['ownFindings']
   # Preserve actual frozen original context; no present-day AGENTS/source is read
   # as a substitute for these historical review inputs.
   for inp in r['reviewInputs']:
    if inp['purpose'].startswith('neutral-author-'):bound(inp['frozenSnapshot'],refs)
   extra=['Original narrative records own original/360/680 observations; auxiliary screenshot hashes are not invented from the later paired receipt.']
  assert g['id']==pair['goalId'] and asset['sha256'].removeprefix('sha256:')==pair['asset']['sha256'].removeprefix('sha256:')
  a.record('biology-neuro21-'+rr['path'].split('/')[-2],rr,g,asset,views,refs,actor,date,reason,extra)
 a.finish('neuro21-original-context-family-census',21)
if __name__=='__main__':main()
