#!/usr/bin/env python3
from biology_original_context_helpers import *
BASE='curricula/DE/Gymnasium/quality/goal-evidence/2026-10-11/biologie-open18-current397-independent-a-20261011-v1/'
def main():
 a=Audit('/dev/shm/skillpilot-v-biology-open18-original-family');sr,s=original(BASE+'FINAL.original-independent-a.freeze.json');refs=[sr]
 v18=bound(next(z for z in s['records']if z['path'].endswith('/visual/V18.original-360-680.own-valid-origin-and-actual-delta-decisions.json')),refs);v18ref=refs[-1]
 v23=bound(next(z for z in s['records']if z['path'].endswith('/visual/V23.actual-whole-pages-and-PND0762-original-360-680.findings.json')),refs);v23ref=refs[-1]
 terminal=bound(next(z for z in s['records']if z['path'].endswith('/FINAL.original-independent-a.targeted-findings.json')),refs)
 f=bound(s['neutralInputFreeze'],refs);whole=bound(next(z for z in f['files']if z['path'].endswith('/candidate/whole484-current397-open18.author.inactive.json')),refs)['goals']
 for v in v18['records']:
  gid=v['goalId'];page=one(v23['records'],gid);assert v['decision']=='KEEP'and page['decision']=='KEEP'and page['htmlWholePageActuallySeen']and page['pdfWholePageActuallySeen'];local=list(refs)
  asset=v['currentOriginalBinding'];views=[page['htmlCaptureBinding'],page['pdfCaptureBinding']]
  if v['currentOriginalExactlySameAsOwnValidReviewedOriginal']:
   prior=bound(v['ownValidOriginalScientificJudgment']['file'],local);p=one(prior.get('records',prior.get('rows')),gid);assert p.get('decision',p.get('verdict'))=='KEEP'
   pa=p.get('original',p.get('originalRaster'));assert pa['sha256'].removeprefix('sha256:')==asset['sha256'].removeprefix('sha256:')
   if'actualOriginalAndBothWidthsInspected'in p:assert p['actualOriginalAndBothWidthsInspected']is True
   else:assert p['originalActuallyViewedWith']=='tools.view_image detail original'
   extra=['The original full-raster judgment is retained byte-exact, while current full-page context was actually inspected in this original followup.']
  else:
   assert gid=='5a44f356-ab0a-5d15-b976-889e22c8d32e'and page['newOriginalActuallySeen']and page['newPND360And680ActuallySeen'];extra=['This one record is the actual new PND raster/context review, not retention of the superseded original.']
  for w in v['currentWidthBindings']:views.append({'path':w['capturePath'],'sha256':w['sha256']})
  a.record('biology-open18-original-current-context-plus-exact-prior-pixels',v23ref,one(whole,gid),asset,views,local,None,terminal['completedAtUTC'],page['ownScientificObservation'],extra+['No explicit original actor-name field is present in these original records; reviewId='+s['reviewId']+' is preserved as run attribution only. Native receipt reviewer metadata remains open; no actor is inferred from a current QA row.'])
 a.finish('open18-original-context-family-census',18)
if __name__=='__main__':main()
