#!/usr/bin/env python3
"""Closed historical multi-file review families, preserving author/reviewer separation."""
from pathlib import Path
import collections,datetime,json,re,runpy
H=Path(__file__).resolve().parent;K=runpy.run_path(str(H/'qualify-nine-economics-context-families.py'));ROOT=K['ROOT'];SOURCE=K['SOURCE'];QA=K['QA'];COMMIT=K['COMMIT'];original=K['original'];sha=K['sha'];B=runpy.run_path(str(H/'qualify-first-two-families.py'))
OUT=Path('/dev/shm/skillpilot-v-six-economics-sealed-families')
FAMILIES={
 'wirtschaft-ten-new-INACTIVE-original360680-image-fit-independent-a-READONLY-v1':10,
 'wirtschaft-four-corrected-current-scope-image-candidates-independent-c-READONLY-v1':4,
 'wirtschaft-by-ten-specific-illustrations-independent-B-20261009-v1':10,
 'wirtschaft-BE14-independent-root-actual-native-phone-desktop-V-review-20261009-v1':14,
 'wirtschaft-BE-four-product-power-grounds-procedure-independent-native-phone-desktop-V-review-20261009-v1':4,
 'wirtschaft-contract-types-one-independent-B-20261009-v1':1,
}
def one(rows,gid):
 x=[r for r in rows if r.get('goalId',r.get('id'))==gid];assert len(x)==1,(gid,len(x));return x[0]
def bound(b,refs):
 r,v=original(b['path'],b['sha256']);refs.append(r);return v

def main():
 OUT.mkdir(exist_ok=False);active={p:sha(p)for p in[SOURCE,QA]};ownerref,owner=B['owner_source'](SOURCE,COMMIT);goals={g['id']:g for g in json.loads((ROOT/SOURCE).read_bytes())['goals']};qa=json.loads((ROOT/QA).read_bytes())['records'];rows=[]
 for f,n in FAMILIES.items():
  selected=[r for r in qa if f in r['aiNotes']];assert len(selected)==n
  for current in selected:
   gid=current['goalId'];ps=[p for p in re.findall(r'curricula/[^\s`)]+\.json',current['aiNotes'])if f in p]
   if f.startswith('wirtschaft-contract-types-one'):ps=[p for p in ps if p.endswith('image.review.receipt.json')]
   assert len(ps)==1,(gid,ps);rr,r=original(ps[0]);refs=[rr];views=[];missing_aux=[]
   if f.startswith('wirtschaft-ten-new-'):
    rb=next(x for x in r['manifest']if x['path']==r['recordsPath']);records=bound(rb,refs);v=one(records,gid);assert v['decision']=='KEEP'and v['reviewAuthority']=='independent_ai_candidate'
    ib=next(x for x in r['manifest']if x['path'].endswith('/'+v['actualWholeGoalPAndPageInputPath']));inputs=bound(ib,refs);g=one(inputs,gid)['wholeCurrentGoal'];a=v['actualOriginal'];views=v['actualInspectionViews'];assert v['actualViewedWidths']==['native original',360,680]
    actor=r['reviewer'];date=r['sealedAt'];reason=v['observedDe'];date_basis='Original seal timestamp, not interpolated from current QA.'
   elif f.startswith('wirtschaft-four-corrected-'):
    assert r['actualFourCurrentInputPayloadsWholeExact']is True;v=one(r['reviews'],gid);assert v['decision']=='KEEP'and v['newUnresolvedImageFindings']==[]
    g=bound(v['wholeCurrentGoalAndP'],refs)['wholeCurrentGoal'];a=v['candidate'];views=v['inspectionViews'];assert all(x['actuallyVisuallyInspected']is True for x in views)
    actor=r['reviewer'];date=r['actualUTC'];reason=v['actualNewEvidence'];date_basis='Original actualUTC'
   elif f.startswith('wirtschaft-by-ten-'):
    if 'images'in r:
     initial=r;v=one(r['images'],gid);assert v['decision']=='KEEP';a={'path':v['assetPath'],'sha256':v['assetSha256']};views=v['inspectionDerivatives'];reason=v['fachlicherBefundDe'];actor=r['reviewerIdentity'];date=r['completedAt']
    else:
     assert r['goalId']==gid and r['decision']=='KEEP' and r['actualNativeViewSeen']==[1672,941]
     initial=bound(r['originalV10Receipt'],refs);prior=one(initial['images'],gid);assert prior['decision']=='REVISE'
     a={'path':r['assetPath'],'sha256':r['assetSha256']};views=r['actualInspectionDerivativesSeen'];assert all(v['actualSeen']is True for v in views);reason=r['resolvedOriginalFindingDe'];actor=r['reviewer'];date=r['completedAt']
    assert initial['actualWholeGoalInputsRead']==10
    ib=next(b for b in initial['inputGuards']if b['path'].endswith('/whole-goals.candidate.json'));g=one(bound(ib,refs),gid);date_basis='Original completedAt'
   elif f.startswith('wirtschaft-BE14-'):
    judgments=bound(r['independentJudgments'],refs);v=one(judgments,gid);assert v['decision']=='KEEP'and v['independentFromImageAuthor']is True and v['wholeGoalDEENAndP2ActuallyRead']is True
    assert all(v[k]is True for k in ['actualNative1672x941Seen','actualPhone360x203Seen','actualDesktop680x383Seen'])
    # The independent seal binds BOTH the original contracts and the selected
    # author manifest. The author manifest is input, not the positive verdict.
    g=one(bound(r['exactOriginalEighteenWholeGoalInput'],refs),gid)
    entry=one(bound(r['authorManifest'],refs)['records'],gid);assert all(g[k]==entry['wholeGoal'][k]for k in ['title','description','titleEn','descriptionEn'])
    assert entry['selectedCandidateSha256']==v['selectedCandidateSha256'];a={'path':entry['selectedCandidatePath'],'sha256':entry['selectedCandidateSha256']};actor=v['reviewer'];date=r['createdAt'];reason=v['reasonDe'];date_basis='Original independent review receipt createdAt'
   elif f.startswith('wirtschaft-BE-four-'):
    v=one(bound(r['individualWholeBoundJudgments'],refs),gid);assert v['decision']=='KEEP' and v['independentVContentApprovedForExactlyThisAsset']is True and v['visualBlockingFindings']==[]
    g=bound(v['wholeCurrentGoalBinding'],refs);a=v['selectedAsset'];assert v['actualViews']['viewImageActuallySeenAllThree']is True;views=[v['actualViews'][k]for k in ['native','phone','desktop']]
    actor=r['reviewer'];date=r['createdAt'];reason=v['wholeGoalPFitDe'];date_basis='Original independent review receipt createdAt'
   else:
    assert r['goalId']==gid and r['decision']=='KEEP' and r['openFindings']==[]
    full=bound(r['boundWholeGoalAndFullPositiveReview'],refs);assert full['goalId']==gid and full['actualWholeBilingualGoalRead']is True
    gb=next(b for b in full['inputWholeByteBindings']if b['path'].endswith('/candidate-whole-goal.before-image.inert.json'));g=bound(gb,refs)
    a=r['asset'];views=r['actualPhoneAndDesktopViews'];actor=r['independence']['reviewerAgentIdentity'];date=r['completedAt'];reason=r['ownSubjectMatterObservationsDe'];date_basis='Original completedAt'
   assert g['id']==gid and actor and date and reason
   ar,_=original(a['path'],a['sha256']);B['require_asset'](ar,current,a['sha256'].removeprefix('sha256:'))
   for view in views:
    if view['path'].startswith('tmp/'):
     # The original record still binds these original auxiliary widths.
     # Missing tmp copies are reported, never invented or regenerated here.
     missing_aux.append({'path':view['path'],'sha256':view['sha256'],'availableNow':(ROOT/view['path']).exists()});continue
    vr,_=original(view['path'],view['sha256']);refs.append(vr)
   context={k:g[k]for k in ['title','description','titleEn','descriptionEn']};mismatch=[k for k,v in context.items()if v!=goals[gid].get(k)]
   rows.append({'family':f,'goalId':gid,'status':'open-original-context-differs'if mismatch else'matching-original-context-closed-adapter-pending','profile':'economics-original-sealed-context-chain-adapter-pending','originalReview':rr,'originalContextChain':refs,'ownerSource':ownerref,'reviewedAsset':ar,'originalContext':context,'currentContext':{k:goals[gid].get(k)for k in context},'mismatchingFields':mismatch,'originalReviewer':actor,'originalReviewedAt':date,'originalDateMeaning':date_basis,'originalReason':reason,'originalDecision':'KEEP','originalAndCurrentAssetBytesVerified':True,'auxiliaryOriginalWidthLocators':missing_aux,'nativeQualificationAdapterAvailable':False})
 assert len(rows)==43 and len({r['goalId']for r in rows})==43;assert all(sha(p)==h for p,h in active.items())
 out={'schemaVersion':1,'kind':'six-sealed-original-context-economics-families','acceptedRepositoryCommit':COMMIT,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'activeInputs':[{'path':p,'sha256':h}for p,h in active.items()],'counts':dict(collections.Counter(r['status']for r in rows)),'rows':rows,'scope':{'newVisualReview':False,'activeWrites':False,'nativeQualificationAdapterAvailable':False,'globalInventoryCompleteness':False}}
 p=OUT/'family-census.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':len(rows),'counts':out['counts'],'sha256':__import__('hashlib').sha256(p.read_bytes()).hexdigest()}))
if __name__=='__main__':main()
