"""Audit-only helper: original text/asset evidence, no native capability issuance."""
from biology_original_context_helpers import *
class SubjectAudit(Audit):
 def __init__(self,out,subject):
  self.out=Path(out);self.out.mkdir(exist_ok=False);self.subject=subject
  source=f'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_{subject.upper()}.de.json';qa=f'curricula/DE/Gymnasium/quality/goal-visualization-qa/{subject}.qa.json'
  self.pins={p:sha(p)for p in[source,qa]};self.goals={g['id']:g for g in json.loads((ROOT/source).read_bytes())['goals']};self.qa={r['goalId']:r for r in json.loads((ROOT/qa).read_bytes())['records']};self.ownerref,_=B['owner_source'](source,COMMIT);self.rows=[]
