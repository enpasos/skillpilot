#!/usr/bin/env python3
"""Three closed original V families; no new image judgments or active writes."""
from pathlib import Path
import collections,datetime,hashlib,json,runpy
H=Path(__file__).resolve().parent;K=runpy.run_path(str(H/'qualify-six-economics-sealed-families.py'));ROOT=K['ROOT'];original=K['original'];COMMIT=K['COMMIT'];B=K['B'];bound=K['bound'];one=K['one'];sha=K['sha']
SOURCE='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_BIOLOGIE.de.json';QA='curricula/DE/Gymnasium/quality/goal-visualization-qa/biologie.qa.json';BASE='curricula/DE/Gymnasium/quality/goal-evidence/'
OUT=Path('/dev/shm/skillpilot-v-three-biology-original-context-families')
EV=BASE+'2026-10-08/biologie-he-evolution-eighteen-final-raster-native-independent-a-20261008-v1/actual-eighteen-current-D-P-V.independent-a.first.verdict.json'
ST=BASE+'2026-10-08/biologie-stoffwechsel-visualization-independent-b-final17-20261008-v1/actual-final17-and-retained2.visualization.independent-b.first-verdict.json'
Q1=BASE+'2026-10-10/biologie-q1-eight-title-methyl-current-native-independent-a-20261010-v2/FIRST.assessments.json'
def main():
 OUT.mkdir(exist_ok=False);pins={p:sha(p)for p in[SOURCE,QA]};goals={g['id']:g for g in json.loads((ROOT/SOURCE).read_bytes())['goals']};qa={r['goalId']:r for r in json.loads((ROOT/QA).read_bytes())['records']};ownerref,_=B['owner_source'](SOURCE,COMMIT);rows=[]
 def record(f,rr,v,g,a,views,refs,actor,date,reason,extra=None):
  gid=g['id'];assert gid==v['goalId'] and gid in qa
  ar,_=original(a['path'],a['sha256']);claimed=a['sha256'].removeprefix('sha256:');assetmatch=qa[gid]['assetSha256']=='sha256:'+claimed
  if assetmatch:B['require_asset'](ar,qa[gid],claimed)
  for av in views:vr,_=original(av['path'],av['sha256']);refs.append(vr)
  ctx={k:g[k]for k in ['title','description','titleEn','descriptionEn']if k in g};assert 'title'in ctx and 'description'in ctx
  mismatch=[k for k,val in ctx.items()if val!=goals[gid].get(k)];status='matching-original-context-closed-adapter-pending'
  if not assetmatch:status='open-original-reviewed-asset-differs'
  elif mismatch:status='open-original-context-differs'
  rows.append({'family':f,'goalId':gid,'status':status,'originalReview':rr,'originalContextChain':refs,'ownerSource':ownerref,'reviewedAsset':ar,'originalContext':ctx,'currentContext':{k:goals[gid].get(k)for k in ctx},'mismatchingFields':mismatch,'originalAndCurrentAssetBytesVerified':assetmatch,'originalReviewer':actor,'originalReviewedAt':date,'originalReason':reason,'nativeQualificationAdapterAvailable':False,'boundaries':extra or []})
 rr,r=original(EV);assert r['reviewAuthority']=='ai_candidate'and r['actualViews']['fullPNGs']==18
 for v in r['records']:
  assert v['actualVisualizationDecision']=='KEEP' and v['findings']==[]
  record('biology-evolution18-embedded-original',rr,v,v['wholeGoalBody'],v['actualFullPNG'],v['actualWidthCaptures']+[v['actualCompleteNativePage']],[rr],r['role'],r['recordedAt'],v['substantiveActualVisualObservationsDe'],['Original attribution is the recorded independent-A role, not an invented named reviewer.'])
 rr,r=original(ST);refs=[rr];entry=bound(r['authorEntry'],refs);freeze=bound(entry['authorInitialInputFreeze'],refs);whole=bound(freeze['whole19Source'],refs)['wholeGoals']
 for v in r['individuallyActuallyReviewedNow']:
  assert v['decision']=='KEEP' and v['actuallyInspectedOriginal'] and v['actuallyInspected360And680'] and v['wholeGoalExact']
  record('biology-stoffwechsel17-linked-original',rr,v,one(whole,v['goalId']),v['actualRaster'],v['inspectionViews'],list(refs),r['reviewerIdentity'],r['createdAt'],v['actualScientificAndRepresentationEvidence'],['The image descriptionDe is not used as the original goal description; the hash-bound whole19 input supplies the goal text.'])
 for carry in r['priorExactKEEPCarryForward']:
  local=list(refs);prior=bound(carry['priorVerdict'],local);pr=local[-1];inp=bound(prior['contextInput'],local);v=one(prior['verdicts'],carry['goalId']);assert v['verdict']=='KEEP_ACTUAL_V_CANDIDATE' and all(v[k]for k in ['actualOriginalRasterOpened','actual360RasterOpened','actual680RasterOpened'])
  g=next(z['wholeCurrentGoal']for z in inp['goals']if z['wholeCurrentGoal']['id']==v['goalId'])
  record('biology-stoffwechsel2-original-prior-keep',pr,v,g,v['actualAsset'],[z['asset']for z in v['inspectionViewBytes']],local,prior['reviewer'],prior['reviewedAt'],v['scienceDe'],['The prior actual review is retained with its original timestamp; the later technical carry is not a new review.'])
 rr,r=original(Q1);refs=[rr];entry=bound(r['entry'],refs);whole=bound(entry['neutralWholeFirstInputs']['whole479CurrentGoalBodiesWithTwoTitleFieldsAndEightRasterLinks'],refs)['goals']
 for v in r['goals']:
  assert v['V']=='KEEP_EXACT_CURRENT_RASTER'and v['wholeNativeHtmlAndPdfActuallySighted']is True
  sightings=v['rasterSightingsExactRetention'];assert len(sightings)==3
  for s in sightings:
   assert s['currentBytesExactToOwnInspectedRaster'] and s['priorOwnActualVisualInspection']['actuallyVisuallyInspected'];assert s['current']['sha256']==s['priorOwnActualVisualInspection']['sha256']
  record('biology-q1-eight-title-methyl-current-original',rr,v,one(whole,v['goalId']),sightings[0]['current'],[s['current']for s in sightings[1:]]+[s['priorOwnActualVisualInspection']for s in sightings],list(refs),r['role'],r['createdAt'],v['visualAssessment'],['Actual current full native contexts were seen; unchanged original raster sightings remain explicitly retained. Original role attribution is preserved.'])
 assert len(rows)==45 and len({r['goalId']for r in rows})==45;assert all(sha(p)==h for p,h in pins.items())
 result={'schemaVersion':1,'kind':'three-biology-original-context-family-census','acceptedRepositoryCommit':COMMIT,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'activeInputs':[{'path':p,'sha256':h}for p,h in pins.items()],'rows':rows,'counts':dict(collections.Counter(r['status']for r in rows)),'scope':{'newVisualReview':False,'activeWrites':False,'nativeAdapterAvailable':False,'globalCompleteness':False}}
 p=OUT/'family-census.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':len(rows),'counts':result['counts'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
if __name__=='__main__':main()
