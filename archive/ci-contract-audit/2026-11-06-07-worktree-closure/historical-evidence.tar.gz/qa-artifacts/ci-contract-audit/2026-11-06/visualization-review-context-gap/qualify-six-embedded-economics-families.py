#!/usr/bin/env python3
"""Finite DE-context historical family qualification; never a new image review."""
from pathlib import Path
import collections,datetime,hashlib,json,re,runpy
H=Path(__file__).resolve().parent
K=runpy.run_path(str(H/'qualify-first-two-families.py'))
ROOT=K['ROOT']; COMMIT=K['ECON_COMMIT']; SOURCE=K['ECON_SOURCE']; QA=K['ECON_QA']
OUT=ROOT/'qa-artifacts/ci-contract-audit/2026-11-06/visualization-context-six-embedded-economics-families'
FAMILIES={
 'wirtschaft-e1-seventeen-image-author-20261008-v1':17,
 'wirtschaft-e2-fourteen-image-author-20261008-v1':14,
 'wirtschaft-e2-twenty-image-author-20261008-v1':19,
 'wirtschaft-q1-seventeen-image-author-20261008-v1':17,
 'wirtschaft-q2-monetary-social-seventeen-image-author-20261008-v1':17,
 'wirtschaft-q3-twenty-three-image-author-20261008-v1':21,
}
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
def original(p,h=None):
 ref,raw=K['original'](p,COMMIT)
 if h: assert ref['sha256']==h.removeprefix('sha256:'),(p,h)
 return ref,json.loads(raw) if p.endswith('.json') else raw

def main():
 OUT.mkdir(exist_ok=False)
 active={p:sha(p) for p in [SOURCE,QA]}
 assert active[SOURCE]=='3a60e7ba51cac98666f3943cee3ebb77c129c653f9fdde9f4c09bb20446da9b3'
 owner_ref,owner=K['owner_source'](SOURCE,COMMIT);owner_ids={g['id'] for g in owner['goals']}
 goals={g['id']:g for g in json.loads((ROOT/SOURCE).read_bytes())['goals']}
 qa=json.loads((ROOT/QA).read_bytes())['records'];rows=[]
 for family,n in FAMILIES.items():
  selected=[r for r in qa if family in r['aiNotes']];assert len(selected)==n
  for current in selected:
   gid=current['goalId'];paths=[p for p in re.findall(r'curricula/[^\s`)]+\.json',current['aiNotes']) if family in p]
   assert len(paths)==1,(gid,paths)
   ref,r=original(paths[0]);assert r['goalId']==gid and gid in owner_ids
   assert current['landscapeId']==owner['landscapeId']
   assert r['decision']=='KEEP' and r['machineApproval'] in ['Approved AI','Reviewed AI']
   assert r['imageAuthorIsReviewer'] is False and r['humanApproved'] is False
   assert r['blockingFindings']==[]
   assert all(r['actualInspection'][k] is True for k in ['nativeViewed','width360Viewed','width680Viewed'])
   assert r['independentReviewer'] and r['actualInspection']['fachlichePruefung']
   assert r['reviewDate']=='2026-10-08'
   asset,_=original(r['assetPath'],r['assetSha256']);K['require_asset'](asset,current,r['assetSha256'].removeprefix('sha256:'))
   refs=[ref];assert {d['width'] for d in r['derivatives']}=={360,680}
   for d in r['derivatives']:
    dr,_=original(d['path'],d['sha256']);refs.append(dr)
   # Genuine exact embedded DE input is sufficient to census this DE-only
   # family. Do not reconstruct unseen EN input from a nearby source.
   context={'title':r['goalTitle'],'description':r['goalDescription']}
   mismatch=[k for k,v in context.items() if v!=goals[gid][k]]
   original_date={'reviewDate':r['reviewDate']}
   if 'reviewedAt' in r:original_date['reviewedAt']=r['reviewedAt']
   rows.append({'family':family,'goalId':gid,'status':'open-original-context-differs' if mismatch else 'matching-original-context-closed-adapter-pending','profile':'economics-embedded-de-actual-three-views-v1-adapter-pending','originalReview':ref,'originalContextChain':refs,'ownerSource':owner_ref,'reviewedAsset':asset,'originalContext':context,'currentContext':{k:goals[gid][k] for k in context},'mismatchingFields':mismatch,'originalReviewer':r['independentReviewer'],'originalReviewDateFields':original_date,'originalReason':r['actualInspection']['fachlichePruefung'],'originalDecision':r['decision'],'originalAndCurrentAssetBytesVerified':True,'nativeQualificationAdapterAvailable':False,'boundary':'Date-only original records retain date-only evidence; no timestamp or English review context is fabricated.'})
 assert len(rows)==105 and len({r['goalId'] for r in rows})==105
 assert all(sha(p)==v for p,v in active.items())
 output={'schemaVersion':1,'kind':'six-closed-embedded-economics-original-context-families','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'acceptedRepositoryCommit':K['ACCEPTED'],'historicalCommit':COMMIT,'activeInputs':[{'path':p,'sha256':h}for p,h in active.items()],'counts':dict(collections.Counter(r['status']for r in rows)),'familyCounts':{f:dict(collections.Counter(r['status']for r in rows if r['family']==f))for f in FAMILIES},'rows':rows,'scope':{'newVisualReview':False,'newAiOrHumanApproval':False,'nativeQualifiedReceipt':False,'activeWrites':False,'globalInventoryCompleteness':False}}
 p=OUT/'family-census.json';p.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'rows':len(rows),'counts':output['counts'],'sha256':sha(str(p.relative_to(ROOT)))}))
if __name__=='__main__':main()
