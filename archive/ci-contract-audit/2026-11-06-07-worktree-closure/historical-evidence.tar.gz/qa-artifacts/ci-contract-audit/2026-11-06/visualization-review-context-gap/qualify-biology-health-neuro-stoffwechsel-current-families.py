#!/usr/bin/env python3
from biology_original_context_helpers import *
BASE='curricula/DE/Gymnasium/quality/goal-evidence/2026-10-10/'
def array(v):return v if isinstance(v,list)else v['goals']
def main():
 a=Audit('/dev/shm/skillpilot-v-biology-health-neuro-stoffwechsel-current-families')
 rr,r=original(BASE+'biologie-health-twelve-current353-genuine-independent-a-root-20261010-v1/FIRST.current353-twelve-whole-science-source-native-raster.independent-A.json');refs=[rr];e=bound(r['neutralInputs'],refs);whole=bound(e['wholeDeEnGoals'],refs)['wholeCurrentGoalObjects'];rasters=bound(e['actualRasterOriginal360680'],refs)['records'];assert r['actualScope']['actualOriginalImages']==12 and r['actualScope']['actual360Views']==12 and r['actualScope']['actual680Views']==12
 for v in r['D12Judgments']:
  if v['V']['decision']!='keep':continue
  views=one(rasters,v['goalId'])['actualRasterViews'];asset=next(z for z in views if z['role']=='original')
  a.record('biology-health12-ten-positive-original-first-judgments',rr,one(whole,v['goalId']),asset,views,list(refs),r['reviewer'],r['createdAt'],v['V']['reason'],['The two original targeted image/alt holds are explicitly excluded from this positive family; no later technical status overwrites them.'])
 rr,r=original(BASE+'biologie-neuro-verhalten-hormone-ten-current-v3-independent-a-20261010-v2/current-native-ten-independent.A.json');refs=[rr];e=bound(r['neutralCurrentEntry'],refs);whole=bound(e['coreInputs']['wholeDEENGoals'],refs)['wholeGoalBodies'];bound(r['firstReview'],refs);assert r['nativeHTMLWholePagesActuallySeen']==10 and r['nativePDFWholePagesActuallySeen']==10
 for v in r['goalRows']:
  assert v['rawVisualDecision']=='ready_current_independent_A_candidate'and v['currentCanonicalAndPageContextReviewed']is True
  rasters=v['actualCurrentRasterViews'];a.record('biology-neuro-ten-original-current-native-followup',rr,one(whole,v['goalId']),rasters['originalPNG'],[rasters[k]for k in ['proportional360','proportional680','nativeHTMLPage','nativePDFPage']],list(refs),r['reviewerAgent'],r['createdAt'],v['visualFinding'],['Nine original raster judgments were explicitly retained; current native contexts and one corrected successor were actually reviewed. The original first review is preserved in the chain.'])
 rr,r=original(BASE+'biologie-stoffwechsel-two-findings-current-followup-independent-a-20261010-v1/final-current-native-eight-independent.A.json');refs=[rr];e=bound(r['currentNeutralEntry'],refs);whole=bound(e['coreInputs']['whole479After'],refs)['goals']
 for v in r['currentGoalDecisions']:
  assert v['V']=='KEEP_independent_machine_candidate';rasters=v['currentRasterAndRender'];a.record('biology-stoffwechsel-eight-original-current-native-followup',rr,one(whole,v['goalId']),rasters['originalPNG'],[rasters[k]for k in ['proportional360','proportional680','nativeHTMLPage','nativePDFPage']],list(refs),r['reviewer'],r['reviewedAt'],v['scientificRationale'],['Current targeted findings and preserved six earlier judgments remain distinguished by the original resolutionOrReuse field; no new census-time inspection occurs.'])
 a.finish('health-ten-neuro-ten-stoffwechsel-eight-original-context-family-census',28)
if __name__=='__main__':main()
