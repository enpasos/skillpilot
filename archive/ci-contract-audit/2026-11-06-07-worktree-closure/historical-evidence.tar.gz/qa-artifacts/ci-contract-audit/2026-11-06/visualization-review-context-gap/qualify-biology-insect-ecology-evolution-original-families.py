"""Four exact original V families, audit only; no image review or active write."""
import json
from biology_original_context_helpers import *
def bound(x):return original(x['path'],x['sha256'])
def one(rows,suffix):return next(r for r in rows if r['path'].endswith(suffix))
A=Audit('/dev/shm/skillpilot-v-biology-insect-ecology-evolution-original-families')
base='curricula/DE/Gymnasium/quality/goal-evidence/'
p=base+'2026-10-10/biologie-sek1-insect-eight-current-native-and-raster-independent-a-20261010-v1/FIRST.actual-eight-raster-independent-a.verdict.json'
rr,r=original(p);ir,inp=bound(r['currentWholeEightDEENGoalsRead']);er,entry=bound(r['neutralEntry']);goals={g['id']:g for g in inp['goals']}
for x in r['actual24RasterViews']:
 if x['ownDecision']=='REVISE':continue
 assert x['ownDecision']=='KEEP_MACHINE_CANDIDATE' and 'all 24 returned image blocks actually inspected' in x['actualInspectionMethod']
 A.record('biology-insect8-original-a',rr,goals[x['goalId']],x['actualViewedOriginal'],[x['actualViewedPhone360'],x['actualViewedPc680']],[ir,er],r['role'],r['sealedAt'],x['rationaleDe'],['Original attribution is role text, not an invented agent identity. No native page or whole-P approval inferred.'])
p=base+'2026-10-07/biologie-ecology20b-twelve-current391-independent-a-20261007-v1/independent-a.final.freeze.json'
sr,s=original(p);rr,r=bound(one(s['frozenFiles'],'V12.actual-raster-widths-pages-independent-a.final.json'));ir,inp=bound(one(s['frozenFiles'],'inputs/exact-twelve-neutral-whole-goals-and-twentyfour-cases.json'));goals={g['wholeGoal']['id']:g['wholeGoal']for g in inp['goals']};mr,_=bound(r['selectedManifest'])
for x in r['records']:
 assert x['scientificVisualVerdict']=='PASS' and x['aiApproved']=='yes' and x['actualSeen']==['full','360','680','native-book-page']
 A.record('biology-ecology20b12-original-a',rr,goals[x['goalId']],x['actualRaster'],x['actualCaptures']+[x['actualNativePageCapture']],[sr,ir,mr],x['aiReviewer'],x['aiReviewedAt'],x['rationaleDe'],['Original review records native PDF inspection; this audit verifies original raster, responsive captures and the archived page capture, not the historical PDF alias.'])
p=base+'2026-10-09/biologie-evolution-twelve-rasters-independent-v-a-v1/twelve-actual-rasters.independent-A.pixel-FIRST.verdict.json'
rr,r=original(p);ir,_=bound(r['sourceInput'])
for x in r['images']:
 if x['machinePixelDecision']!='KEEP':continue
 assert x['actuallyInspectedSeparateOriginal360And680'] and x['inspectionCount']==3
 A.record('biology-evolution12-original-a-first11',rr,x['wholeGoal'],x['selectedPng'],[q['binding']for q in x['displayCaptures']],[ir],r['reviewer'],r['createdAt'],x['originalAnd360And680Observations'],['Original held ordinal14 deliberately excluded; later technical pair is not an approval.'])
p=base+'2026-10-09/biologie-evolution-six-root-rasters-independent-v-a-v1/six-root-rasters.pixel-FIRST.independent-A.verdict.json'
rr,r=original(p);ir,_=bound(r['pixelFirstNeutralInput']);fr,_=bound(r['inputFirst'])
for x in r['rows']:
 assert x['decision']=='KEEP' and len(x['actualViewsPersonallySeen'])==3
 A.record('biology-evolution6-original-a',rr,x['wholeGoal'],x['asset'],x['actualViewsPersonallySeen'],[ir,fr],r['reviewerId'],r['createdAtUtc'],x['independentReasoning'],['Prior whole-science authorship disclosed by original reviewer; this is the recorded visual review only. Reconstruction metadata revisions remain distinct.'])
A.finish('four-biology-original-visual-context-families',36)
