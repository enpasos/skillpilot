"""Explicit original Math V record forms, not a generic review-pointer authority."""
from multi_subject_original_context_helpers import *
A=SubjectAudit('/dev/shm/skillpilot-v-math-explicit-original-context-families','mathematik')
base='curricula/DE/Gymnasium/quality/goal-visualization-review/'
def emit(f,rr,g,a,actor,date,reason,refs=[],bounds=[]):
 if A.qa[g['id']]['assetSha256']!='sha256:'+a['sha256'].removeprefix('sha256:'):
  A.rows.append({'family':f,'goalId':g['id'],'status':'open-original-reviewed-asset-differs','originalReview':rr,'originalContext':g,'originalReviewedAssetClaim':a,'originalAndCurrentAssetBytesVerified':False,'boundaries':bounds+['Historical review names an asset different from the current approved asset. No current qualification and no reconstructed old asset claim.']});return
 A.record(f,rr,g,a,[],[rr]+refs,actor,date,reason,bounds)
for name in ['independent-review-b-first4.json','independent-review-b-last7.json','independent-review-b-v2.json']:
 rr,r=original(base+'math-m7-statistics-corrections-11-20260920-v1/'+name)
 for x in r['records']:
  if x['decision']!='accept':continue
  assert x['inspected']
  g={'id':x['goalId'],'title':x['title'],'description':x['descriptionDe']}
  if 'descriptionEn'in x:g['descriptionEn']=x['descriptionEn']
  emit('math-statistics11-'+name,rr,g,{'path':x['candidatePath'],'sha256':x['assetSha256']},x.get('reviewer',r['reviewer']),x.get('actualReviewedAt',r.get('actualReviewedAt')),x['rationale'])
for folder,name,view,decision,reason in [('math-m7-v-only-corrections-13-20260920-v1','root-independent-ten.receipt.json','actualViewed','accepted_pilot','independentChecks'),('math-m7-stochastics-foundations-20260920-v1','root-independent-eight.receipt.json','actuallyViewedByRoot','accept_candidate','checks')]:
 rr,r=original(base+folder+'/'+name)
 for x in r['records']:
  assert x[view] and x['decision']==decision
  emit(folder,rr,x['previousGoal'],{'path':x['candidatePath'],'sha256':x['candidateSha256']},r['reviewer'],r['reviewedAt'],x[reason],bounds=['The previousGoal is embedded in the original actual-raster verdict itself; no current context interpolation.'])
rr,r=original(base+'math-m7-proof-six-v-gate-20260921-v1/review.json')
for x in r['records']:
 assert x['inspected']and x['keep']and x['decision']=='accept_current_asset'
 emit('math-proof-six-original',rr,x['goalSnapshot'],{'path':x['assetPath'],'sha256':x['assetSha256']},r['reviewer'],r['actualReviewedAt'],{'checks':x['checks'],'goalAlignment':x['goalAlignment']})
rr,r=original(base+'math-m7-missing-algebra-logic-4-20260920-v1/independent-review-a.json');ir,_=original(r['inputManifestPath'],r['inputSha256'])
for x in r['records']:
 assert x['inspected']and x['decision']=='accepted_pilot'and x['actualAssetSha256']==x['candidateSha256']
 emit('math-algebra-logic-four-original-a',rr,{'id':x['goalId'],'title':x['goalTitle'],'description':x['goalDescription']},{'path':x['candidatePath'],'sha256':x['candidateSha256']},r['reviewer']['id'],x['actualReviewedAt'],x['rationale'],[ir])
rr,r=original(base+'math-m7-stochastics-pass2-four-20260920-v1/independent-review-b.json');ir,_=original(r['inputPath'],r['inputSha256'])
for x in r['records']:
 if x['decision']!='accept_current_asset':continue
 assert x['inspected']and x['actualCandidateSha256']==x['candidateSha256']
 emit('math-stochastics-pass2-two-original-b',rr,x['goal'],{'path':x['candidatePath'],'sha256':x['candidateSha256']},r['reviewer'],x['actualReviewedAt'],x['rationale'],[ir],['Original timestamp format is retained verbatim; a closed adapter must normalize it without inventing a new review.'])
for folder in ['math-m7-functions-20260920-v1','math-m7-open-calculus-20260920-v1']:
 for p in sorted((ROOT/base/folder).glob('*/review-b*.json')):
  rr,r=original(str(p.relative_to(ROOT)))
  if r.get('decision')!='accept_candidate':continue
  assert r['independenceStatement'] and 'description'in r
  g={'id':r['goalId'],'title':r['title'],'description':r['description']}
  if 'descriptionEn'in r:g['descriptionEn']=r['descriptionEn']
  emit(folder+'-original-b',rr,g,{'path':r['candidatePath'],'sha256':r['candidateSha256']},r['reviewer'],r['reviewDate'],r['checks'],bounds=['Original reviewDate is date-only; no time-of-day is invented.'])
for folder in ['math-b040-integrals-and-series-v1','math-b040-series-split-v1']:
 for p in sorted((ROOT/base/folder).glob('independent-candidate-review-v*.json')):
  rr,r=original(str(p.relative_to(ROOT)))
  for x in r['records']:
   if x['decision']!='accept' or x['goalId']not in A.qa:continue
   assert x['image']['actuallyViewed']
   g={'id':x['goalId'],**{k:v for k,v in x['goalContext'].items()if k in ['title','description','titleEn','descriptionEn']}}
   emit(folder+'-'+p.name,rr,g,x['image'],x['reviewer']['agent'],x['reviewedAtObserved'],x['subjectSpecificChecks'],bounds=['Original observed timestamp is documentation time, not invented exact image invocation time.'])
for name in ['fresh-b-current-eleven.review.json','fresh-b-pythagoras-four.review.json']:
 rr,r=original(base+'m7-current-image-repairs-20260928-v1/'+name)
 for x in r['reviews']:
  if x['decision']!='keep':continue
  assert x['asset'].get('originalViewed',x.get('originalView',{}).get('viewed',False))
  g={'id':x['goalId'],**{k:v for k,v in x['goalText'].items()if k!='goalId'}}
  emit('math-fresh-b-current-'+name,rr,g,{'path':x['asset']['path'],'sha256':x['asset']['digest']},r['reviewer']['agentTask'],r['reviewedAt'],{'math':x['mathematicalReviewDe'],'fit':x['didacticFitDe']},bounds=['Original full-image bytes verified. Ephemeral 360px preview is recorded in the original verdict but is not represented as an archived current asset.'])
A.finish('math-explicit-original-context-family-census',len(A.rows))
