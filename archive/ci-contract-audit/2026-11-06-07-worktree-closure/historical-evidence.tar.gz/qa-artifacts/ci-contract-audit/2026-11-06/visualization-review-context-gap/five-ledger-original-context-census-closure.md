# Endlicher Abgleich vorhandener V-Originalkontexte

Abgeschlossen am 7. November 2026. Diese Inventur umfasst genau die fünf aktiven V-Ledger des zentralen Deep-Registers: **2.562 eindeutige Einträge, davon 2.483 `curricularAtomic`**. Jeder Eintrag erhält genau einen Status. Sie erteilt keine neue Bildfreigabe und ändert keine aktive Quelle oder QA-Zeile.

| Fach | Einträge | Bestehendes geschlossenes Profil | Passender Originaltext und Asset, Adapter offen | Originalkette nicht geschlossen | Textdrift | Assetdrift |
|---|---:|---:|---:|---:|---:|---:|
| Mathematik | 832 | 2 | 133 | 680 | 14 | 3 |
| Physik | 509 | 0 | 4 | 503 | 2 | 0 |
| Chemie | 478 | 0 | 155 | 308 | 13 | 2 |
| Biologie | 397 | 0 | 355 | 41 | 1 | 0 |
| Wirtschaftswissenschaften | 346 | 16 | 298 | 18 | 14 | 0 |
| Gesamt | **2.562** | **18** | **945** | **1.550** | **44** | **5** |

Für die 2.483 curricularAtomic-Einträge lauten dieselben Zahlen: 18 / 937 / 1.481 / 42 / 5. Die anderen 79 Einträge werden nicht aus dem Nenner entfernt.

**963 Ziele haben einen passenden vorhandenen Originalkontext.** Nur die bereits separat geprüften 18 Kandidaten gehören zu vorhandenen geschlossenen Profilen. Die übrigen 945 sind fachlich unveränderte Originaltext-/Asset-Ketten für künftig einzeln zu prüfende Adapter. Unter diesen 945 bleiben zusätzlich **32 ursprüngliche Metadatenbindungen ungeklärt**: Chemie acht, Biologie 23 und Wirtschaft eines. Fehlende Urheberangaben oder Reviewzeiten werden weder aus aktuellen Ledgern noch aus Dateinamen, Commitzeiten oder diesem Audit ergänzt. Die anderen 913 haben mindestens eine passende Kette mit erfasster ursprünglicher Attribution und Zeitangabe; Datum ohne Uhrzeit bleibt Datum ohne Uhrzeit.

**1.599 aktuelle Kontextbindungen bleiben offen.** Bei 49 ist ein konkreter Text- oder Bildwechsel gegenüber dem gefundenen Original belegt; bei 1.550 konnte die Kette im festgelegten Suchraum nicht geschlossen werden. Vor Weiterverwendung benötigen diese Ziele einen echten aktuellen Kontextreview oder eine unabhängig nachgewiesene, bisher fehlende Originalkette. Das ist kein Beweis, dass außerhalb dieses Suchraums niemals weitere Originalbelege existiert haben. Fehlende Bindung bedeutet ebenso wenig, dass das Bild fachlich falsch ist oder neu erzeugt werden muss.

## Was tatsächlich verglichen wurde

Die Tabellen zählen originale positive Bildentscheidungen mit eingebettetem Zieltext oder mit einem ausdrücklich gehashten ursprünglichen Zieleingang. Die Originalentscheidung muss die tatsächlichen Bildbytes betreffen. DE-Titel und DE-Beschreibung werden gegen die heutige Quelle verglichen; vorhandene ursprüngliche EN-Felder ebenfalls. Nicht vorhandene EN-Felder werden nicht aus heutigen Quellen ergänzt. Die 5.124 heutigen Public-/Canonical-Bildpfade wurden tatsächlich gehasht und gegen ihre aktuellen QA-Bindungen geprüft. Alle Source-, QA-, Kind- und Registry-Pins blieben unverändert.

Die neuen Familienbelege sind **keine universellen Qualifikations-Receipts**. Ein künftiger geschlossener Adapter muss seine ursprünglichen Kontextfelder einschließlich gegebenenfalls vorhandener Niveau-/Darstellungsangaben, Attribution, Zeitform, Rolle, Asset- und Eingabebindungen tatsächlich validieren. Diese Inventur behauptet für die 945 Fälle keine vollständige Prüfung eines noch nicht implementierten Profils. Die erfassten Text-/Asset-Gleichheiten ersetzen weder fehlende mobile Originalinspektionen noch andere damals ausdrücklich offene Bedingungen. Ganze Zielobjekte in Originaleingängen sind keine pauschale Gleichheitsfreigabe für `requires`, Quellenzuordnung, Scope oder Assessmentverträge.

Eine alte negative oder abweichende Kette bleibt unverändert erhalten, auch wenn eine andere echte positive Kette das heutige Ziel und Bild bindet. Die Gesamttabelle enthält sämtliche Familienketten und unterscheidet sie von bloßen Suchtreffern. Aktuelle QA-Zeilen, D-/P-Entscheidungen, Bilderzeugung, technische Adoption und zeitlich benachbarte Git-Quellen sind keine Ersatzautorität für einen fehlenden V-Originaltext.

## Endlicher Suchraum und erhaltene Belege

Die Discovery ist an Git `7ab16f4afc45b3f384577e04b5ba85b680a7678d` gebunden: 124.615 ausgewählte committed Artefakte, 89.417 Dateien mit aktuellen Ziel-IDs. Der strukturierte Suchindex enthält 112.195 Kandidatenrecords aus 87.956 Dateien; ein Suchtreffer ist kein Review. Zusätzlich sind 4.411 Alias-Locators vollständig aufgelöst. Konkrete originale Input-, Seal-, Review- und Assetverweise wurden in geschlossenen Familien verfolgt. Die Chemieprüfung umfasst unabhängig alle 478 Einträge, 185 erhaltene Originalketten, 76 Originalreviewdateien und 18 historische Batchberichte. Ein darin erhaltener historischer HOLD ist ausschließlich Abweichungsbeleg und wird niemals als positive Kette gezählt.

Nicht behauptet wird eine erschöpfende Untersuchung jedes früher gelöschten Gitblobs, privater Sitzungen oder ungetrackter alter Temp-Dateien. Die ausdrücklich genannten alten `tmp/fresh-ai-review/{physik,mathematik}/fresh-review-combined.jsonl` sind heute nicht vorhanden. Die vorhandenen Juli-Tabellen mit Titel, Bildhash und Sichturteil erhalten ihren historischen Wert; ein fehlender originaler Beschreibungseingang wird dadurch nicht rekonstruiert. Der einzelne strukturierte Parsefehler des großen Index betrifft eine als `.jsonl` benannte nicht normative Source-Literalliste und keinen V-Review.

Der vollständige schreibfreie Schlusslauf ist im eigenen RAM-Paket `/dev/shm/skillpilot-v-five-ledger-completed-census/` gesichert. Wegen knapper Rootplatte wurden die großen Artefakte noch nicht zusätzlich in das Repository kopiert. Das Paket enthält eine disjunkte maschinenlesbare Tabelle, CSV, vollständige Originalketten, die unveränderte Chemieprüfung, Metadatenlücken und bytegenaue ursprüngliche Familienartefakte samt Reproduktionsskripten. Die ursprünglichen 105-Fälle-Belege und 18 Receipt-Kandidaten bleiben unverändert.

| Artefakt | SHA-256 |
|---|---|
| `final-packet-manifest.json` | `1bd1f694dfe9a68a76978928b8b5535f73f5f1e5e128502d462d6ed1ad98d03a` |
| `five-ledger-disjoint-context-census.json.gz` | `bb39c8b480bd01544fd99aa4f797dd7daf6bb8ab4688fe9f55de0e4389354e4a` |
| `summary.json` | `e4c728b991df2a71a00e5d93728a77d3e2837efa79a6c82fa64cbc2e4b7399b1` |
| `matching-original-metadata-audit.json.gz` | `27386caa5e1658c625f0ab059935f9b3ddce01fcd1bbaca2e244baa44ea5b7d3` |
| `family-originals-and-reproduction-scripts.tar.gz` | `a5f923c7aacfa9f0ac21ffe44508b2afe3b8ee39e273d6d2838ac9873f76edf9` |

Keine aktive V-Zeile, Quelle oder Lernerinformation wurde geändert. Es wurden keine neuen Bilder betrachtet, keine Human-Reviews behauptet, keine native Capability ausgegeben und kein V-, M7- oder Gesamt-CI-Pass abgeleitet. Die getrennten Git-/ODB-Angriffstests des neuen Validator-Kerns werden durch diese Inventur weder ersetzt noch als eigener Testlauf ausgegeben.
