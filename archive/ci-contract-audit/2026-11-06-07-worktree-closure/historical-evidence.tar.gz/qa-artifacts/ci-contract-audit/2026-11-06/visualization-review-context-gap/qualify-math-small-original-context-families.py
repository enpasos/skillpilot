#!/usr/bin/env python3
from multi_subject_original_context_helpers import *
a=SubjectAudit('/dev/shm/skillpilot-v-math-small-original-context-families','mathematik');base='curricula/DE/Gymnasium/quality/goal-visualization-review/'
def emit(f,rr,g,asset,actor,date,reason,bs=[]):
 h=asset['sha256'].removeprefix('sha256:');bounds=list(bs)
 if a.qa[g['id']]['assetSha256']!='sha256:'+h:
  a.rows.append({'family':f,'goalId':g['id'],'status':'open-original-reviewed-asset-differs','originalReview':rr,'originalContext':g,'originalReviewedAssetClaim':asset,'originalAndCurrentAssetBytesVerified':False});return
 if asset['path'].startswith('tmp/'):
  old=asset['path'];asset={'path':'app/public'+a.qa[g['id']]['imageUrl'],'sha256':h};bounds.append('Original review names temporary raster '+old+' with exact SHA. The retained public Git image is verified byte-identical to that original reviewed hash; this is an explicit content-byte alias, not a goal-context or basename inference.')
 a.record(f,rr,g,asset,[],[rr],actor,date,reason,bounds)
rr,r=original(base+'math-m7-proof-six-v-gate-20260921-v1/proof-strategy-addendum.json')
for x in r['records']:
 assert x['inspected']and x['decision']=='accept_current_asset';emit('math-proof-strategy-original-addendum',rr,x['goalSnapshot'],{'path':x['assetPath'],'sha256':x['assetSha256']},r['reviewer'],r['actualReviewedAt'],x['rationale'])
rr,r=original(base+'math-m7-open-spatial-probability-20260920-v1/audit.json')
for x in r['records']:
 if x['decision']!='KEEP':continue
 assert x['imageInspected'];emit('math-spatial-five-original-keep-judgments',rr,{'id':x['goalId'],**{k:x[k]for k in ['title','description','descriptionEn']if k in x}},{'path':x['currentImagePath'],'sha256':x['currentImageSha256']},r['reviewer'],r['reviewDate'],x['checks'],['Original status is targeted-candidate-preparation-not-gate-approval; only actual image content judgment is identified. No integration approval or date-time is invented.'])
rr,r=original(base+'m7-pythagoras-proof-png-20260928-v1/review/png-independent-review.json');assert r['decision']=='accept'and r['candidate']['actualOriginalViewed'];emit('math-pythagoras-original-independent-png',rr,r['goalText'],r['candidate'],r['reviewer']['agent'],r['reviewedAt'],r['checks'])
rr,r=original(base+'m7-current-image-repairs-20260928-v1/fresh-b-converse-png-independent-review.json')
for x in r['reviews']:
 if x['decision']not in ['accept','keep']:continue
 assert x['candidate']['actualOriginalViewed'];emit('math-converse-original-positive-png',rr,x['goalText'],x['candidate'],r['reviewer']['agent'],r['reviewedAt'],{k:v for k,v in x.items()if k in ['checks','correctFeatures','rationale','decisionRationale']})
rr,r=original(base+'math-m7-proof-holds-20260921-v1/1e164a09-0a2b-55ab-b927-08a4a278f72b/independent-review.json');c=r['currentGoalBinding'];assert r['decision']=='accepted_pilot'and r['candidate']['actuallyViewed'];emit('math-plausibility-original-independent',rr,{'id':r['goalId'],'title':c['titleDe'],'titleEn':c['titleEn'],'description':c['descriptionDe'],'descriptionEn':c['descriptionEn']},r['candidate'],r['reviewer'],r['reviewedAt'],r['mathematicalChecks'])
rr,r=original(base+'math-b042-current-image-repairs-v1/281e0c6e-independent-current-raster-review-v1.json');assert r['decision']=='pass';emit('math-rotational-volume-original-independent',rr,{'id':r['goalId'],'title':r['currentTitleDe'],'description':r['currentDescriptionDe']},r['asset'],r['reviewerAgent'],r['reviewedAt'],r['verdictReason'])
a.finish('math-small-original-context-families',len(a.rows))
