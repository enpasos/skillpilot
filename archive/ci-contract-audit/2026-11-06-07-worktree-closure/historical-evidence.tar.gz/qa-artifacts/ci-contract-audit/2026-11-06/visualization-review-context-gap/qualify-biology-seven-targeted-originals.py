#!/usr/bin/env python3
from biology_original_context_helpers import *
BASE='curricula/DE/Gymnasium/quality/goal-evidence/'
def main():
 a=Audit('/dev/shm/skillpilot-v-biology-seven-targeted-originals')
 rr,r=original(BASE+'2026-10-08/biologie-stoffwechsel-two-basic-images-independent-a-20261008-v2/two-basic-images.independent-a.first.verdicts.json');refs=[rr];bound(r['ownFirstInputFreeze'],refs)
 for v in r['records']:
  assert v['verdict']=='APPROVE_AI_VISUAL_GATE_EXACT_CURRENT_RASTER';a.record('biology-basic-respiration-photosynthesis-original-two',rr,v['wholeCurrentBilingualGoal'],v['asset'],v['actualIndependentlySeenViews'],list(refs),r['reviewer'],r['createdAtUtc'],v['ownDidacticJudgmentDe'])
 rr,r=original(BASE+'2026-10-10/biologie-sek1-insect-eight-current-native-and-raster-independent-a-20261010-v1/FIRST.current-fcc1-native-raster-DP-independent-a.verdict.json');refs=[rr];e=bound(r['neutralEntry'],refs);whole=bound(next(x for x in e['wholeInputs']if x['path'].endswith('whole479-with-eight-rasters-fcc-adult.inactive.json')),refs)['goals'];assert r['actualVisualDecision']=='KEEP_MACHINE_CANDIDATE'
 a.record('biology-frog-corrected-original-raster-and-current-whole-goal',rr,one(whole,r['goalId']),r['currentAsset'],r['actualFiveViews'],refs,None,r['sealedAt'],r['actualVisualFindingDe'],['Original reviewer role is recorded, but the verdict contains no explicit named reviewer; no name is invented.'])
 rr,r=original(BASE+'2026-10-10/biologie-health-twelve-current353-genuine-independent-a-root-20261010-v1/FINAL.two-targeted-actual-raster-public-alt-native-P-context.independent-A.json');refs=[rr];first=bound(r['first'],refs);e=bound(first['neutralInputs'],refs);whole=bound(e['wholeDeEnGoals'],refs)['wholeCurrentGoalObjects'];bound(r['whole394ContextProof'],refs)
 for v in r['targetedJudgments']:
  assert v['V']=='keep_current_machine_candidate';c=one(r['actualWholeHtmlPdfCapturesViewed'],v['goalId']);vs=[c['htmlCapture'],c['pdfCapture']];asset=r['unchangedPrenatalOriginalViewedAgain']
  if v['goalId'].startswith('6add'):vs+=r['actualNew6addOriginal360680Viewed'];asset=vs[2]
  a.record('biology-health-two-original-targeted-context-successors',rr,one(whole,v['goalId']),asset,vs,list(refs),None,r['createdAt'],v['reason'],['Original followup names its independent A role and exact first-review chain but no explicit reviewer name; attribution remains open. No human approval.'])
 p=BASE+'2026-10-07/biologie-cellcycle-evolution-two-independent-a-20261007-v1/';sr,s=original(p+'final-independent-A-two-goal-dossier.freeze.json');refs=[sr];f=bound(s['authorFinalFreeze'],refs);ap=str(Path(s['authorFinalFreeze']['path']).parent)+'/'
 z=next(x for x in f['files']if x['path']=='current-two-whole-DEEN-goals.exact.json');whole=bound(dict(z,path=ap+z['path']),refs);whole=whole if isinstance(whole,list)else whole.get('goals',whole.get('records'))
 z=next(x for x in s['files']if x['path'].endswith('V2.actual-raster-widths-pages-independent-a.final.json'));rr,r=original(z['path'],z['sha256']);refs.append(rr);bound(r['selectedManifest'],refs)
 for v in r['records']:
  assert v['decision']=='KEEP'and v['actualSeen']==['full','360','680','native-book-page'];a.record('biology-cellcycle-evolution-original-sealed-final-two',rr,one(whole,v['goalId']),{'path':v['sourcePath'],'sha256':v['assetSha256']},v['actualCaptures'],list(refs),v['aiReviewer'],v['aiReviewedAt'],v['ownIndependentNote'])
 a.finish('biology-seven-targeted-original-review-context-census',7)
if __name__=='__main__':main()
