#!/usr/bin/env python3
from multi_subject_original_context_helpers import *
a=SubjectAudit('/dev/shm/skillpilot-v-math-original-sixty-two-input-family','mathematik')
for n in [1,2]:
 rr,r=original(f'curricula/DE/Gymnasium/quality/goal-visualization-review/math-m7-v-only-current-62-20260920-v1/part-{n}.review.json');ir,i=original(r['inputPath'],r['inputSha256'])
 for v in r['records']:
  if v['decision']!='accept_current_asset':continue
  x=one(i['records'],v['goalId']);assert v['inspected']and v['assetSha256']==x['assetSha256']and v['assetPath']==x['assetPath']
  g={'id':v['goalId'],**{k:x[k]for k in ['title','description','descriptionEn']if k in x}}
  a.record(f'math-current62-original-part-{n}',rr,g,{'path':v['assetPath'],'sha256':v['assetSha256']},[],[rr,ir],r['reviewer'],r['actualReviewedAt'],v['rationale'],['Only original positive records count; 13 original corrections remain historical negative decisions. The exact description comes from the review-hashed original input, not the current ledger.'])
a.finish('math-current62-original-positive-context-census',49)
