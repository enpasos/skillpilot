#!/usr/bin/env python3
from biology_original_context_helpers import *
BASE='curricula/DE/Gymnasium/quality/goal-evidence/'
def main():
 a=Audit('/dev/shm/skillpilot-v-biology-human-flora-he7-original-families')
 for family,b in [('human20','2026-10-07/biologie-human20-final-raster-native-independent-a-20261007-v1/'),('flora20','2026-10-08/biologie-flora-fauna20-final-raster-native-independent-a-20261008-v1/')]:
  sr,s=original(BASE+b+'first-final-D-P-V20.independent-a.freeze.json');refs=[sr];r=bound(next(z for z in s['frozenFiles']if z['path'].endswith('/actual-twenty-V-first-independent-a.verdicts.json')),refs);rr=refs[-1];af=bound(s['exactAuthorInputSeal'],refs);files=af.get('files',af.get('frozenFiles'))
  if family=='human20':gb=next(z for z in files if z['path'].endswith('/candidate/canonical.current474-twenty-new-raster-author.json'));whole=bound(gb,refs)['goals']
  else:gb=next(z for z in files if z['path'].endswith('/current20-whole-DEEN-goals.actual.json'));whole=bound(gb,refs)
  if isinstance(whole,dict):whole=whole['goals']
  for v in r['records']:
   assert v['machineCandidateDecision']=='KEEP'and v['scientificAndVisualVerdict']=='PASS'
   a.record('biology-'+family+'-original-sealed-native-context',rr,one(whole,v['goalId']),v['actualObservedFullRaster'],v['actualObservedChromiumCaptures']+[v['actualObservedNativePdfPage'].get('capture',v['actualObservedNativePdfPage'])],list(refs),r['actualAgent'],r['recordedAt'],v['substantiveActualObservationsDe'],['For Flora20, nine exact prior original inspections were retained and eleven originals newly viewed; the original recorded review boundary is preserved.']if family=='flora20'else[])
 b=BASE+'2026-10-08/biologie-he7-ten-final-raster-native-independent-a-20261008-v1/';sr,s=original(b+'completed-native-D10-P10-V10.independent-a.final.freeze.json');refs=[sr];r=bound(next(z for z in s['ownFiles']if z['path'].endswith('/actual-ten-full-PNG-widths-native-pages-V.independent-a.first.verdict.json')),refs);rr=refs[-1];af=bound(s['authorInput'],refs);whole=bound(next(z for z in af['frozenFiles']if z['path'].endswith('/current10-whole-DEEN-goals.actual.json')),refs)
 if isinstance(whole,dict):whole=whole['goals']
 for v in r['records']:
  assert v['decision']=='KEEP'
  a.record('biology-he7-ten-original-sealed-native-context',rr,one(whole,v['goalId']),v['actualFullRaster'],v['actualBothWidths']+[v['actualNativePage']],list(refs),r['role'],r['recordedAt'],v['substantiveActualObservationsDe'],['Original attribution is the recorded independent-A role, not an invented named reviewer.'])
 a.finish('human20-flora20-he7ten-original-context-family-census',50)
if __name__=='__main__':main()
