#!/usr/bin/env python3
"""Resolve the finite original-discovery symlink set without treating aliases as reviews."""
from pathlib import Path
import collections,gzip,hashlib,json,os,posixpath,subprocess
ROOT=Path(__file__).resolve().parents[4]
BASE=ROOT/'qa-artifacts/ci-contract-audit/2026-11-06/visualization-five-ledger-original-evidence-census-full'
OUT=Path('/dev/shm/skillpilot-v-original-discovery-aliases');OUT.mkdir(exist_ok=False)
summary=json.loads((BASE/'discovery-summary.json').read_bytes());accepted=summary['acceptedRepositoryCommit']
tree={}
for item in subprocess.check_output(['git','--no-replace-objects','ls-tree','-r','-z',accepted],cwd=ROOT).decode().split('\0'):
 if item:
  mt,p=item.split('\t',1);mode,kind,oid=mt.split(' ');tree[p]=(mode,kind,oid)
indexed={r['path']for r in json.loads(gzip.decompress((BASE/'artifact-discovery.json.gz').read_bytes()))['files']}
cache={};rows=[]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def oid(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def read(path):
 if path in cache:return cache[path]
 mode,kind,expected=tree[path];assert kind=='blob'
 if mode=='120000':
  assert (ROOT/path).is_symlink();raw=os.readlink(ROOT/path).encode()
 else:
  assert mode in ('100644','100755')and not(ROOT/path).is_symlink();raw=(ROOT/path).read_bytes()
 assert oid(raw)==expected,path
 ref={'path':path,'gitMode':mode,'gitBlob':expected,'sha256':sha(raw),'size':len(raw)}
 cache[path]=(ref,raw if mode=='120000'else None);return cache[path]
for issue in summary['issues']:
 assert issue['kind']=='non-regular-git-input'and issue['mode']=='120000'
 p=issue['path'];cur=p;chain=[];visited=set()
 for _ in range(64):
  assert cur not in visited;visited.add(cur);parts=cur.split('/');changed=False
  for i in range(1,len(parts)+1):
   prefix='/'.join(parts[:i]);meta=tree.get(prefix)
   if meta and meta[0]=='120000':
    ref,raw=read(prefix);target=raw.decode();assert not target.startswith('/');chain.append({**ref,'linkText':target})
    cur=posixpath.normpath(posixpath.join(posixpath.dirname(prefix),target,*parts[i:]));assert cur!='..'and not cur.startswith('../');changed=True;break
  if not changed:break
 else:raise AssertionError('alias-depth')
 ref,_=read(cur);assert ref['gitMode']in('100644','100755')
 assert (ROOT/p).resolve()==(ROOT/cur).resolve()
 classification='already-indexed-regular-target'if cur in indexed else 'quality-target-without-current-goal-mention'if cur.startswith('curricula/DE/Gymnasium/quality/')else'outside-quality-canonical-runtime-or-status-target'
 rows.append({'alias':p,'declaredGitLinkChain':chain,'finalRegularTarget':ref,'classification':classification})
value={'schemaVersion':1,'kind':'finite-original-discovery-alias-resolution','acceptedRepositoryCommit':accepted,'aliases':len(rows),'distinctRegularTargets':len({r['finalRegularTarget']['path']for r in rows}),'classificationCounts':dict(collections.Counter(r['classification']for r in rows)),'rows':rows,'scope':'All 4411 nonregular Git inputs are resolved from authenticated exact link text to authenticated regular file bytes. This is discovery provenance, never a visual review or context approval.'}
raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'))+'\n').encode();compressed=gzip.compress(raw,6,mtime=0);(OUT/'alias-resolution.json.gz').write_bytes(compressed)
result={k:v for k,v in value.items()if k!='rows'};result.update({'compressedSha256':sha(compressed),'uncompressedSha256':sha(raw),'compressedBytes':len(compressed)});(OUT/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
