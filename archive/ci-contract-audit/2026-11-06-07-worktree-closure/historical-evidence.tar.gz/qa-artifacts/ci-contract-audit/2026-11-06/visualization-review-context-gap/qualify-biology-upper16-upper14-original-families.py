#!/usr/bin/env python3
from biology_original_context_helpers import *
BASE='curricula/DE/Gymnasium/quality/goal-evidence/'
def main():
 a=Audit('/dev/shm/skillpilot-v-biology-upper16-upper14-original-families');b=BASE+'2026-10-08/biologie-upper-sixteen-whole-independent-a-resumed-v1/';sr,s=original(b+'independent-a.first-verdict.freeze.json');refs=[sr];r=bound(next(z for z in s['actualFiles']if z['path'].endswith('/whole-native-DPV.actual-observations.first.json')),refs);rr=refs[-1];entry=bound(s['neutralEntry'],refs)
 gb=next(z for z in entry['inputBindings']if z['path'].endswith('/input/current-whole-canonical.snapshot.json'));whole=bound(gb,refs)['goals'];assert entry['descriptionsAndDependenciesUnchanged']is True
 for v in r['observations']:
  assert v['imageDecision']=='KEEP'and v['actualOriginalFullAnd360And680Inspected']is True and v['nativeWholePDFPageActuallyViewed']is True
  views=[next(z for z in s['actualFiles']if z['path']==v[k])for k in ['responsive360Path','responsive680Path']]
  a.record('biology-upper16-original-input-snapshot-and-first-V-seal',rr,one(whole,v['goalId']),v['imageBinding'],views,list(refs),r['reviewer'],r['completedAt'],v['imageObservationsDe'],['Original text comes from the explicitly hash-bound whole canonical input snapshot supplied to this independent review, not a current source lookup. The neutral entry declares unchanged descriptions and dependencies; candidate image links do not supply original text.'])
 b=BASE+'2026-10-09/biologie-upper-science-fourteen-independent-a-v1/';cr,c=original(b+'current-fourteen-combined-DPV-review.independent-a.json');refs=[cr];first=bound(c['originalNativeFirstVerdictBinding'],refs);fr=refs[-1];target=bound(c['targetedNativeTwoVerdictBinding'],refs);tr=refs[-1]
 for combined in c['entries']:
  gid=combined['goalId'];origins=[(fr,first,v)for v in first['entries']if v['goalId']==gid]+[(tr,target,v)for v in target['entries']if v['goalId']==gid]
  good=[z for z in origins if z[2]['rasterDecision']=='KEEP'and z[2]['independentVisualApproval']is True and z[2]['currentWholeGoal']==combined['currentWholeGoal']and z[2]['actualImageBinding']['sha256']==combined['actualImageBinding']['sha256']]
  assert good,(gid,'no matching independent original')
  # Multiple original positive contexts are retained as explicit alternatives;
  # this chooses no authority from file order or newer timestamps.
  rr,r,v=good[0];local=list(refs);local.extend(z[0]for z in good[1:]);views=v['actualOriginal360680ViewEvidence']
  if all('actualPixelsVisuallyInspected'in z for z in views):assert all(z['actualPixelsVisuallyInspected']is True for z in views)
  else:
   assert gid in ['4edb6169-1202-5651-b23f-dcb6eddb58ba','788cda1f-8ca3-5241-8d73-50d9952e9da3']and[z['width']for z in views]==[360,680]
   assert ('All three inspected sizes'in v['visualReason']or'at original/360/680'in v['visualReason'])
  a.record('biology-upper14-matching-original-native-V',rr,v['currentWholeGoal'],v['actualImageBinding'],[z.get('binding',z)for z in views],local,r['reviewer'],r['reviewedAt'],v['visualReason'],['The combined record is only a locator. The selected original independent record itself contains the full reviewed goal and actual original/360/680 sightings. Other matching original positive references, if any, remain in the chain. No later rebind creates a review.'])
 a.finish('upper16-upper14-original-context-family-census',30)
if __name__=='__main__':main()
