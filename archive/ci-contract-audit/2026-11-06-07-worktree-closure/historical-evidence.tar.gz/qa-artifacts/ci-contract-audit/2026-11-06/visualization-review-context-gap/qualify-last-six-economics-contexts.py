#!/usr/bin/env python3
from pathlib import Path
import collections,datetime,json,re,runpy,hashlib
H=Path(__file__).resolve().parent;K=runpy.run_path(str(H/'qualify-six-economics-sealed-families.py'));ROOT=K['ROOT'];SOURCE=K['SOURCE'];QA=K['QA'];COMMIT=K['COMMIT'];original=K['original'];sha=K['sha'];bound=K['bound'];one=K['one'];B=K['B']
OUT=Path('/dev/shm/skillpilot-v-last-six-economics-contexts')
FAMILIES={'wirtschaft-BE18-three-elasticities-levels-independent-native-phone-desktop-review-20261009-v1':3,'wirtschaft-two-BB-science-BWL-VWL-independent-native-phone-desktop-V-review-20261009-v1':2,'wirtschaft-one-Montan-independent-native-phone-desktop-V-review-20261009-v1':1}
def main():
 OUT.mkdir(exist_ok=False);active={p:sha(p)for p in[SOURCE,QA]};ownerref,_=B['owner_source'](SOURCE,COMMIT);goals={g['id']:g for g in json.loads((ROOT/SOURCE).read_bytes())['goals']};qa=json.loads((ROOT/QA).read_bytes())['records'];rows=[]
 for f,n in FAMILIES.items():
  selected=[r for r in qa if f in r['aiNotes']];assert len(selected)==n
  for current in selected:
   gid=current['goalId'];ps=[p for p in re.findall(r'curricula/[^\s`)]+\.json',current['aiNotes'])if f in p];assert len(ps)==1;rr,r=original(ps[0]);refs=[rr];metadata_open=[]
   if f.startswith('wirtschaft-BE18-three-'):
    v=one(bound(r['individualJudgments'],refs),gid);assert v['decision']=='KEEP' and all(x['actualViewImage']is True for x in v['actualViews'])
    guard=bound(r['beforeGuard'],refs);gb=next(b for b in guard['files']if b['path'].endswith('/whole-eighteen-new-goal-contracts.exact-sourceV3.candidate.json'));g=one(bound(gb,refs),gid);a=v['asset'];views=v['actualViews'];actor=r['reviewer'];date=r['createdAt'];reason=v['semanticReviewDe']
   elif f.startswith('wirtschaft-one-Montan-'):
    m=bound(r['manifest'],refs);ib=next(b for b in m['contentFiles']if b['path'].endswith('/actual-bound-whole-goal-positive-two-cases-and-style-reference-inputs.json'));inp=bound(ib,refs)
    gb=next(b for b in inp['files']if b['path'].endswith('/actual-thirteen-whole-goal-native-P26-independent-read.snapshot.json'));g=one(bound(gb,refs)['wholeGoals'],gid)
    vb=next(b for b in m['contentFiles']if b['path'].endswith('/individual-whole-native-phone-desktop-Montan-V-judgment.json'));v=bound(vb,refs);assert v['goalId']==gid and v['decision']=='KEEP';views=v['wholeCandidateViews'];assert all(x['decision']=='KEEP' and x['actuallyViewedWith']=='tools.view_image original'for x in views)
    a=r['candidateAsset'];actor=r['reviewer'];date=None;reason=v['fachlicheFindings'];metadata_open=['Original terminal review/individual judgment contains no review timestamp. Current aggregate aiReviewedAt and nearby Git/guard times must not be substituted.']
   else:
    initial=bound(r['originalREVISEReceipt'],refs)if 'originalREVISEReceipt'in r else r
    m=bound(initial['manifest'],refs);vb=next(b for b in m['files']if b['path']==initial['individualJudgmentPath']);judgments=bound(vb,refs);prior=one(judgments['judgments'],gid)
    ib=next(b for b in m['files']if b['path'].endswith('/actual-before-two-current-BB-contract-P4-and-native-six-view.guards.json'));guard=bound(ib,refs);gb=next(b for b in guard['guards']if b['path'].endswith('/whole-two-current-BB-science-and-BWL-VWL-contracts.author-intake.json'));g=one(bound(gb,refs),gid)
    if 'originalREVISEReceipt'in r:
     assert prior['decision']=='REVISE'and r['decision']=='KEEP'and r['wholeCurrentGoalUnchanged']is True
     cm=bound(r['manifest'],refs);vb=next(b for b in cm['files']if b['path'].endswith('/actual-independent-three-view-bounded-science-arrow-removal-KEEP.judgment.json'));v=bound(vb,refs);assert v['goalId']==gid and v['machineScientificVApproved']is True and all(z['actualViewImageSeen']is True for z in v['views']);views=v['views'];a=next(z for z in views if z['sha256']==r['exactApprovedAssetSha256']);reason=v['findings'];actor=r['reviewer'];date=r['at']
    else:
     assert prior['decision']=='KEEP'and prior['scientificVApproved']is True
     a=next(b for b in guard['guards']if b['sha256']==prior['assetSha256']);views=[];reason=prior['findings'];actor=judgments['reviewer'];date=judgments['at']
   assert g['id']==gid and actor and reason
   ar,_=original(a['path'],a['sha256']);B['require_asset'](ar,current,a['sha256'].removeprefix('sha256:'))
   for v in views:vr,_=original(v['path'],v['sha256']);refs.append(vr)
   ctx={k:g[k]for k in ['title','description','titleEn','descriptionEn']};mismatch=[k for k,v in ctx.items()if v!=goals[gid].get(k)]
   rows.append({'family':f,'goalId':gid,'status':'open-original-context-differs'if mismatch else'matching-original-context-closed-adapter-pending','profile':'economics-linked-original-contract-v1-adapter-pending','originalReview':rr,'originalContextChain':refs,'ownerSource':ownerref,'reviewedAsset':ar,'originalContext':ctx,'currentContext':{k:goals[gid].get(k)for k in ctx},'mismatchingFields':mismatch,'originalReviewer':actor,'originalReviewedAt':date,'originalReason':reason,'originalDecision':'KEEP','originalAndCurrentAssetBytesVerified':True,'nativeReceiptMetadataOpen':metadata_open,'nativeQualificationAdapterAvailable':False})
 assert len(rows)==6 and all(sha(p)==h for p,h in active.items())
 out={'schemaVersion':1,'kind':'last-six-current-economics-original-context-chains','acceptedRepositoryCommit':COMMIT,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'activeInputs':[{'path':p,'sha256':h}for p,h in active.items()],'counts':dict(collections.Counter(r['status']for r in rows)),'rows':rows,'scope':{'newVisualReview':False,'activeWrites':False,'nativeQualificationAdapterAvailable':False,'globalInventoryCompleteness':False}}
 p=OUT/'family-census.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':6,'counts':out['counts'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
if __name__=='__main__':main()
