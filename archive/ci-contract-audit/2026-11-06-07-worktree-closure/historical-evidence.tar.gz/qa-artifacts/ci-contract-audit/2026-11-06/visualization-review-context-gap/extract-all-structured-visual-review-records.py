#!/usr/bin/env python3
"""Locate structured original visual decisions; no qualification is inferred."""
from pathlib import Path
import collections
import gzip
import hashlib
import json
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT / 'qa-artifacts/ci-contract-audit/2026-11-06/visualization-five-ledger-original-evidence-census-full'
OUT = Path('/dev/shm/skillpilot-v-full-review-record-index')
CENSUS = json.loads((ROOT / 'qa-artifacts/ci-contract-audit/2026-11-06/visualization-review-context-gap/five-ledger-field-census.json').read_bytes())
GOALS = {}
for subject in CENSUS['subjects']:
    for goal in json.loads((ROOT / subject['inputs'][1]['path']).read_bytes())['goals']:
        GOALS[goal['id']] = goal
ACTIVE = {}
for subject in CENSUS['subjects']:
    for row in json.loads((ROOT / subject['inputs'][0]['path']).read_bytes())['records']:
        ACTIVE[row['goalId']] = row
assert len(ACTIVE) == 2562
NAMES = {'goalid', 'id', 'skillpilotid', 'canonicalgoalid'}
TITLE = {'title', 'titlede', 'goaltitle', 'goaltitlede', 'currentgoaltitle', 'currenttitle', 'currenttitlede', 'currenttitledeactuallyread', 'canonicaltitle'}
DESCRIPTION = {'description', 'descriptionde', 'goaldescription', 'goaldescriptionde', 'currentgoaldescription', 'currentgoaldescriptionde', 'currentdescription', 'currentdescriptionde', 'currentdescriptiondeactuallyread', 'canonicaldescription'}


def norm(key):
    return re.sub('[^a-z0-9]', '', key.lower())


def flat_strings(value, pointer='', max_depth=8):
    if max_depth < 0:
        return
    if isinstance(value, dict):
        for key, child in value.items():
            p = pointer + '/' + key.replace('~', '~0').replace('/', '~1')
            if isinstance(child, str):
                yield p, key, child
            elif isinstance(child, (dict, list)):
                yield from flat_strings(child, p, max_depth-1)
    elif isinstance(value, list):
        for i, child in enumerate(value):
            if isinstance(child, (dict, list)):
                yield from flat_strings(child, pointer+'/'+str(i), max_depth-1)


def walk(value, pointer='', inherited_goal=None, depth=0):
    if depth > 16:
        return
    if isinstance(value, dict):
        explicit = [v for k, v in value.items() if norm(k) in NAMES and isinstance(v, str) and v in ACTIVE]
        gid = explicit[0] if len(set(explicit)) == 1 else inherited_goal
        yield pointer, value, gid, bool(explicit)
        for key, child in value.items():
            if isinstance(child, (dict, list)):
                yield from walk(child, pointer+'/'+key.replace('~','~0').replace('/','~1'), key if key in ACTIVE else gid, depth+1)
    elif isinstance(value, list):
        for i, child in enumerate(value):
            if isinstance(child, (dict, list)):
                yield from walk(child, pointer+'/'+str(i), inherited_goal, depth+1)


def main():
    OUT.mkdir(exist_ok=False)
    files = json.loads(gzip.decompress((BASE/'artifact-discovery.json.gz').read_bytes()))['files']
    selected = [f for f in files if not f['aggregateOnly'] and f['path'].endswith(('.json', '.jsonl'))]
    # A review may identify its goal only in its filename; do not omit that
    # bounded form just because the document body contains no repeated UUID.
    accepted = json.loads((BASE/'discovery-summary.json').read_bytes())['acceptedRepositoryCommit']
    seen = {f['path'] for f in files}
    tree = subprocess.check_output(['git','--no-replace-objects','ls-tree','-r','-z',accepted,'--','curricula/DE/Gymnasium/quality'],cwd=ROOT).decode().split('\0')
    path_only_added = []
    for item in tree:
        if not item: continue
        mt, path = item.split('\t',1);mode,kind,blob=mt.split(' ')
        if path in seen or mode not in ('100644','100755') or not path.endswith(('.json','.jsonl')):continue
        if not any(gid in path for gid in ACTIVE):continue
        raw=(ROOT/path).read_bytes()
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
        extra={'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'gitBlob':blob,'aggregateOnly':False,'discovery':'goal-identifier-in-path'}
        selected.append(extra);path_only_added.append(extra)

    found = []
    parse_issues = []
    started = time.time()
    for number, file in enumerate(selected, 1):
        raw = (ROOT/file['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == file['sha256']
        try:
            docs = [('', json.loads(raw))] if file['path'].endswith('.json') else [('@line'+str(i+1), json.loads(line)) for i,line in enumerate(raw.splitlines()) if line.strip()]
        except (ValueError, UnicodeError) as error:
            parse_issues.append({'path':file['path'],'error':str(error)});continue
        for line, doc in docs:
            root = doc if isinstance(doc, dict) else {}
            root_keys = [k for k in root if any(s in norm(k) for s in ('review','inspect','view','seen','sight'))]
            path_visual = any(token in file['path'].lower() for token in ('visual', 'image', 'raster', 'png'))
            file_goals = [gid for gid in ACTIVE if gid in file['path']]
            file_goal = file_goals[0] if len(file_goals) == 1 else None
            for pointer, record, gid, explicit in walk(doc, inherited_goal=file_goal):
                if not gid or not (explicit or (pointer == '' and file_goal)):
                    continue
                if 'aiApproved' in record and 'chatGptNotes' in record:
                    continue
                direct_keys = list(record)
                visual_keys = [k for k in direct_keys if norm(k) == 'v' or any(s in norm(k) for s in ('visual','image','raster','pixel','png'))]
                decisions = {k:v for k,v in record.items() if isinstance(v,str) and (norm(k) in ('decision','verdict','v','overallverdict','overallrecommendation','recommendation')
                    or any(s in norm(k) for s in ('decision','verdict','outcome')))}
                approval_keys = {k:v for k,v in record.items() if norm(k) in ('aiapproved','approved','accepted','aidecision','aireviewdecision','reviewdecision') and isinstance(v,(bool,str))}
                if not visual_keys and not (path_visual and (decisions or approval_keys)):
                    continue
                if not decisions and not approval_keys and not any('decision' in norm(k) or 'review' in norm(k) for k in visual_keys):
                    continue
                # Record this as a possible original judgment only. Negative
                # findings, technical adoptions and author records remain visible.
                fields = list(flat_strings(record))
                text_locations = [{'pointer':p,'field':key,'value':v,'kind':'title' if norm(key) in TITLE else 'description'}
                    for p,key,v in fields if norm(key) in TITLE | DESCRIPTION]
                hash_value = ACTIVE[gid]['assetSha256'].removeprefix('sha256:')
                asset_locations = [{'pointer':p,'field':key,'value':v} for p,key,v in fields if v.removeprefix('sha256:')==hash_value]
                # A truthful broad verdict must still be distinguished from a
                # preparation or integration record before later qualification.
                found.append({'goalId':gid,'subject':ACTIVE[gid]['subject'], 'path':file['path'], 'sha256':file['sha256'],
                    'pointer':line+pointer,'recordKeys':direct_keys,'rootReviewKeys':root_keys,
                    'rootRole':root.get('role',root.get('kind',root.get('reviewType'))),
                    'decisions':decisions,'approvalFields':approval_keys,'visualKeys':visual_keys,'textLocations':text_locations,
                    'matchingImageHashLocations':asset_locations,
                    'currentTitlePresent':any(v['kind']=='title' and v['value']==GOALS[gid]['title'] for v in text_locations),
                    'currentDescriptionPresent':any(v['kind']=='description' and v['value']==GOALS[gid]['description'] for v in text_locations),
                    'disposition':'discovery-only-not-qualified'})
        if number%3000==0:
            print(json.dumps({'scanned':number,'selected':len(selected),'records':len(found),'seconds':round(time.time()-started)}),flush=True)
    payload={'schemaVersion':1,'scope':'Possible original structured visual decisions. This index deliberately includes rejected, stale, technical and generation records; matching names/text/hash alone do not approve them.','sourceDiscovery':str(BASE.relative_to(ROOT)),'records':found,'parseIssues':parse_issues,'pathOnlyAdded':path_only_added}
    raw=(json.dumps(payload,ensure_ascii=False,separators=(',',':'))+'\n').encode(); compressed=gzip.compress(raw,6,mtime=0)
    (OUT/'structured-visual-review-records.json.gz').write_bytes(compressed)
    summary={'schemaVersion':1,'sourceArtifacts':len(selected),'possibleRecords':len(found),'goalsWithPossibleRecords':len({r['goalId'] for r in found}),
        'directContextAndAssetMatches':sum(r['currentTitlePresent'] and r['currentDescriptionPresent'] and bool(r['matchingImageHashLocations']) for r in found),
        'parseIssues':parse_issues,'sha256':hashlib.sha256(compressed).hexdigest(),'uncompressedSha256':hashlib.sha256(raw).hexdigest(),'seconds':round(time.time()-started)}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)


if __name__=='__main__':
    main()
