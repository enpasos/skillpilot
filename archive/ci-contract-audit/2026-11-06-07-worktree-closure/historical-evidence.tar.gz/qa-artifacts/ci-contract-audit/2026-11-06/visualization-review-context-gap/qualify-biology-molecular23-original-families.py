#!/usr/bin/env python3
from biology_original_context_helpers import *
PAIR='curricula/DE/Gymnasium/quality/goal-evidence/2026-10-09/biologie-molecular-genetics-reviewed-integration-root-v1/checks/current23-genuine-V-pair.actual.json'
def main():
 a=Audit('/dev/shm/skillpilot-v-biology-molecular23-original-families');pairref,pairs=original(PAIR)
 for pair in pairs['visualPairs']:
  lr,raw=original(pair['firstReview']['path'],pair['firstReview']['sha256']);v=json.loads(raw.splitlines()[pair['firstJsonlLine']-1]);assert v['goalId']==pair['goalId']and v['decision']=='PASS_KEEP_RASTER_CANDIDATE'and v['reviewAuthority']=='ai_candidate';refs=[pairref,lr]
  first=bound(v['firstPixelJudgment'],refs);rr=refs[-1];items=first.get('images',first.get('rows',first.get('perRasterJudgments',[first])));p=one(items,v['goalId']);assert p['wholeCurrentGoal']==v['wholeCurrentGoal']
  verdict=p.get('decision',p.get('pixelVerdict'));assert verdict in ['KEEP','PASS_KEEP_RASTER_CANDIDATE']
  if 'selectedActualOriginal'in p:
   asset=p['selectedActualOriginal'];views=p['inspectionDerivatives'];assert all(p[k]is True for k in ['actualOriginalViewed','actual360Viewed','actual680Viewed']);reason=p['scientificMechanism']
  elif 'selectedOriginal'in p:
   asset=p['selectedOriginal'];views=[x['binding']for x in p['actualViews']];assert all(x['actuallyViewed']for x in p['actualViews']);reason=p.get('scienceAndGeometryReasoning',p.get('scientificMechanismAndGeometry'))
  elif 'actualSelectedPNG'in p:
   asset=p['actualSelectedPNG'];views=[x['binding']for x in p['actualViewsSeen']];assert p['actualViewCount']==3;reason=p['scientificAndGeometricJudgments']
  else:
   asset=p['actualSelectedRaster'];views=[x['binding']for x in p['actualViewsSeen']];assert len(views)==3;reason=p['scienceAndGeometryReasoning']
  assert asset['sha256'].removeprefix('sha256:')==v['assetBinding']['sha256'].removeprefix('sha256:')
  a.record('biology-molecular23-original-'+rr['path'].split('/')[-2],rr,p['wholeCurrentGoal'],asset,views,refs,first.get('reviewer',first.get('reviewerAgent')),first.get('firstJudgmentAt',first.get('createdAt')),reason,['Technical pairing only locates the original review. The actual first pixel judgment supplies goal body, decision, original attribution/time and exact asset. Later metadata-only successors are not new pixel reviews.'])
 a.finish('molecular23-original-context-family-census',23)
if __name__=='__main__':main()
