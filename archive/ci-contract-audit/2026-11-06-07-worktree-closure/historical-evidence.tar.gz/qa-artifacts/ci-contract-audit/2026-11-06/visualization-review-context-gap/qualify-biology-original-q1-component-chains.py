#!/usr/bin/env python3
from biology_original_context_helpers import *
BASE='curricula/DE/Gymnasium/quality/'
def pick(files,s):return next(x for x in files if x['path'].endswith(s))
def main():
 a=Audit('/dev/shm/skillpilot-v-biology-original-q1-component-chains')
 p=BASE+'goal-visualization-review/biologie-q1-four-new-independent-v-qa-20261005-v1/'
 rr,r=original(p+'independent-v-qa.receipt.json')
 for v in r['goals']:
  assert v['candidateDecision']=='PASS_INACTIVE_REVISED_SCOPE'
  s=v['operativeScope'];g={'id':v['goalId'],'title':s['proposedTitleDe'],'description':s['proposedDescriptionDe'],'titleEn':s['proposedTitleEn'],'descriptionEn':s['proposedDescriptionEn']}
  views=[{'path':z['path'],'sha256':z['fileSha256']}for z in v['actualNativePhoneDesktopInspections']];assert all(z['actualImageViewed']for z in v['actualNativePhoneDesktopInspections'])
  a.record('biology-original-four-proposed-scope-V-review',rr,g,{'path':v['candidateImagePath'],'sha256':v['assetSha256']},views,[rr],r['reviewer'],r['reviewedAtUtc'],v['scientificFindings']+v['responsiveFindings'])
 p=BASE+'goal-evidence/2026-10-05/biologie-q1-tf-methylation-current-independent-a-m-v-v1/'
 sr,s=original(p+'independent-a-m-v.final.freeze.json');refs=[sr]
 rr,r=original(p+'visualization.exact-goal-asset-bindings.candidate.json',pick(s['files'],'visualization.exact-goal-asset-bindings.candidate.json')['sha256']);refs.append(rr)
 native=bound(pick(s['files'],'visualization.native-candidate.qa.json'),refs)
 fr,f=original(r['inputFreezePath'],r['inputFreezeDigest']);refs.append(fr);bound(f['goalSnapshot'],refs)
 for i,v in enumerate(r['bindings']):
  assert v['decision']=='keep'and v['verdict']=='pass';g=v['goal'];q=one(native['records'],g['id']);assert q['aiApproved']=='yes'and q['description']==g['description']
  x=v['assets'][0];views=[pick(s['files'],f'native-goal-card-{i}-{w}.png')for w in[360,680]]
  a.record('biology-tf-methylation-original-V-full-goal-and-native-row',rr,g,{'path':x['preparedPath'],'sha256':x['sha256']},views,list(refs),q['aiReviewer'],q['aiReviewedAt'],q['aiNotes'],['Native row is contemporaneously sealed in the actual independent V review, not a later aggregate.'])
 p=BASE+'goal-evidence/2026-10-05/biologie-q1-bacterial-structure-fission-current-independent-d-b-v1/'
 sr,s=original(p+'independent-review.final.freeze.json');refs=[sr]
 rr,r=original(p+'independent-p-a-m-v-scientific-decisions.json',pick(s['files'],'independent-p-a-m-v-scientific-decisions.json')['sha256']);refs.append(rr)
 frozen=bound(pick(s['files'],'candidate-freeze-and-pdf-preparation.actual.json'),refs)
 ap=BASE+'goal-evidence/2026-10-05/biologie-q1-bacterial-structure-fission-native-candidate-v1/'
 ar,af=original(ap+'author-native-candidate.final.freeze.json',frozen['candidateFreezeSHA256']);refs.append(ar)
 snapshot=bound(pick(af['files'],'prospective-canonical.snapshot.json'),refs)
 for v in r['rows']:
  assert v['visualDecision']=='KEEP/PASS';g=one(snapshot['goals'],v['goalId']);asset={'path':a.qa[g['id']]['canonicalAssetPath'],'sha256':v['actualPixelSHA256']}
  views=[pick(s['files'],x.removeprefix(str(ROOT)+'/'))for x in v['actuallyReadResizedViews']]
  a.record('biology-bacterial-original-whole-input-freeze-V-review',rr,g,asset,views,list(refs),r['reviewer'],r['reviewedAt'],v['visualReason'],['Original private asset path is retained as a historical locator; only the exact original SHA is resolved to identical archived canonical bytes. The source JSON hash in the review refers to curriculum source evidence, not goal wording; wording comes exclusively from the explicitly verified author input freeze.'])
 a.finish('biology-original-q1-component-context-chains',8)
if __name__=='__main__':main()
