from biology_original_context_helpers import *
A=Audit('/dev/shm/skillpilot-v-biology-q1-seven-ethics-carrier-originals')
base='curricula/DE/Gymnasium/quality/goal-visualization-review/'
rr,r=original(base+'biologie-q1-seven-new-visuals-independent-v-qa-v1/seven-independent-visual-verdicts.actual.json');refs=[rr];bound(r['goalTextSource'],refs)
assert r['ownJudgementFromActualViewedImages']and not r['generationPerformedByThisReviewer']
for x in r['records']:
 assert x['decision']=='KEEP'and x['nativeImageActuallyViewedIndependentlyWithViewImage']
 g={'id':x['goalId']}
 for k,v in x['goalBinding'].items():
  assert hashlib.sha256(v['text'].encode()).hexdigest()==v['utf8Sha256'];g[k]=v['text']
 for q in x['actualDisplayBindings']:assert q['actuallyViewedIndependentlyWithViewImage']
 A.record('biology-q1-seven-original-visual',rr,g,x['asset'],[{'path':q['screenshot'],'sha256':q['screenshotSha256']}for q in x['actualDisplayBindings']],list(refs),r['reviewer'],r['createdAtUTC'],{'science':x['actualScienceFinding'],'scope':x['representationLimits']})
rr,r=original(base+'biologie-q1-four-risk-ethics-raster-independent-b-20261010-v1/FIRST.review.actual.json');refs=[rr];goals=bound(r['neutralBindings']['wholeFourGoalBodies'],refs)
if isinstance(goals,dict):goals=goals['records']
assert r['wholeFourGoalsAndProfilesAndEightBilingualCasesRead']and r['actualImageViewsBeforeFirst']==12
for x in r['records']:
 assert x['decision']=='KEEP'and x['wholeGoalReadDeEn'];im=x['imageBindings'];g=one(goals,x['goalId'])
 A.record('biology-q1-four-risk-ethics-original-b',rr,g,im['originalPNG'],[im['phone360PNG'],im['desktop680PNG']],list(refs),r['reviewer'],r['createdAt'],x['subjectFindingsDe'])
rr,r=original(base+'biologie-q1-carrier-hidden-continuity-independent-a-v3/v5-final/independent-v5-a.actual-visual-science-verdict.json')
assert r['decision']=='KEEP_ONE_EXACT_FINAL_V5_CANDIDATE' and all(x['personallyInspected']for x in r['reviewedActualRasterSizes'])
A.record('biology-q1-carrier-v5-original-a',rr,r['currentWholeGoal'],r['reviewedCandidate'],[x['input']for x in r['reviewedActualRasterSizes']],[rr],r['reviewer'],r['createdAtUTC'],r['actualIndividualFindings'])
A.finish('biology-q1-seven-ethics-carrier-original-contexts',12)
