#!/usr/bin/env python3
"""Finite audit census, not an approval adapter or a new visual review.

All current rows receive exactly one classification. Original family records
are retained in full; a later matching positive chain does not rewrite an older
negative/drifting chain. No active input is written.
"""
from pathlib import Path
import collections,csv,datetime,glob,gzip,hashlib,json,re,shutil,subprocess
ROOT=Path(__file__).resolve().parents[4]
HERE=Path(__file__).resolve().parent
OUT=Path('/dev/shm/skillpilot-v-five-ledger-completed-census')
INDEX=ROOT/'qa-artifacts/ci-contract-audit/2026-11-06/visualization-five-ledger-original-evidence-census-full'
CHEM=Path('/dev/shm/skillpilot-v-chemistry-census')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def ref(p):
 p=Path(p);return {'path':str(p.relative_to(ROOT))if p.is_relative_to(ROOT)else str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def get(p):
 p=Path(p);return json.loads(gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes())
def norm(v):return re.sub(r'\s+',' ',v.strip())if isinstance(v,str)else v
def write_gz(name,value):
 raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode();p=OUT/name
 p.write_bytes(gzip.compress(raw,mtime=0));return {**ref(p),'uncompressedSha256':sha(raw),'uncompressedBytes':len(raw)}
def main():
 OUT.mkdir(exist_ok=False)
 fieldpath=HERE/'five-ledger-field-census.json';field=get(fieldpath)
 inputs=[field['registry']]+[v for s in field['subjects']for v in s['inputs']]
 for r in inputs:assert sha((ROOT/r['path']).read_bytes())==r['sha256'],r['path']
 qas={};goals={};pins={};kinds={(r['subject'],r['goalId']):r['curricularAtomic']for r in field['rows']}
 for s in field['subjects']:
  sub=s['subject'];qp,sp=s['inputs'][:2];qas[sub]={r['goalId']:r for r in get(ROOT/qp['path'])['records']};goals[sub]={g['id']:g for g in get(ROOT/sp['path'])['goals']};pins[sub]={'qa':qp,'source':sp}
 discoveryPath=INDEX/'goal-evidence-candidates.json.gz';discovery={(r['subject'],r['goalId']):r for r in get(discoveryPath)['rows']}
 structuredPath=Path('/dev/shm/skillpilot-v-full-review-record-index/structured-visual-review-records.json.gz');structured=collections.defaultdict(list)
 for r in get(structuredPath)['records']:structured[(r['subject'],r['goalId'])].append(r)
 familyPaths=sorted([Path(x)for x in glob.glob('/dev/shm/skillpilot-v-*/family-census.json')]+list((ROOT/'qa-artifacts/ci-contract-audit/2026-11-06').glob('visualization-context-*/family-census.json')))
 families=[];chains=[];bygoal=collections.defaultdict(list)
 for p in familyPaths:
  d=get(p);f=ref(p);families.append(f)
  for i,r in enumerate(d.get('rows',[])):
   entry={'chainId':f['sha256']+':'+str(i),'familyArtifact':f,'familyPointer':'/rows/'+str(i),'record':r};chains.append(entry);bygoal[r['goalId']].append(entry)
 chemPath=CHEM/'chemie-478-context-census.json.gz';chem=get(chemPath);chemBy={r['goalId']:r for r in chem['rows']}
 assert ref(chemPath)['sha256']=='0f7d21c6f844e7deffc78ab69eba9d247d0a8553d48bbb92b00ef2121f4dc1af'
 chemChainsPath=CHEM/'chemie-original-chains.json.gz';assert ref(chemChainsPath)['sha256']=='a02e66080bb56d3c498cd4d1181d242e8329432442cb203f2d4e7708f4b16216'
 # Current byte verification is a necessary comparison input, never original
 # review authority. Cache identical source/public paths to avoid repeated I/O.
 assetcache={};rows=[]
 for sub,qs in qas.items():
  for gid,q in qs.items():
   g=goals[sub][gid];assert norm(q['title'])==norm(g['title'])and norm(q['description'])==norm(g['description'])
   assert q['aiApproved']=='yes'and q['aiApprovedAssetSha256']==q['assetSha256']
   assert any(z.get('url')==q['imageUrl']for z in g.get('resourceLinks',[])),gid
   assets=[]
   for key in ['publicAssetPath','canonicalAssetPath']:
    path=q[key]
    if path not in assetcache:assetcache[path]=sha((ROOT/path).read_bytes())
    assert assetcache[path]==q['assetSha256'].removeprefix('sha256:'),path
    assets.append({'path':path,'sha256':assetcache[path]})
   ev=bygoal.get(gid,[]);supported=[e for e in ev if e['record']['status']=='supported-profile-qualified-candidate'];matching=[e for e in ev if e['record']['status']=='matching-original-context-closed-adapter-pending'];drift=[e for e in ev if e['record']['status']=='open-original-context-differs'];assetdrift=[e for e in ev if e['record']['status']=='open-original-reviewed-asset-differs']
   # Independently recheck every positive family's text against today's input.
   for e in supported+matching:
    r=e['record'];ctx=r.get('originalContext',{'title':r.get('originalTitle'),'description':r.get('originalDescription')})
    assert ctx.get('title')and ctx.get('description'),(gid,e['chainId'])
    assert all(norm(v)==norm(g.get(k))for k,v in ctx.items()if v is not None),(gid,e['chainId'])
    assert r['reviewedAsset']['sha256'].removeprefix('sha256:')==q['assetSha256'].removeprefix('sha256:'),gid
   if supported:status='supported-profile-qualified-candidate'
   elif matching:status='matching-original-context-closed-adapter-pending'
   elif drift:status='hold-original-context-differs'
   elif assetdrift:status='hold-original-reviewed-asset-differs'
   else:status='hold-original-context-unclosed-in-bounded-corpus'
   chemref=None
   if sub=='chemie':
    cr=chemBy[gid];status=cr['status'];chemref={'artifact':ref(chemPath),'goalId':gid,'selectedChainId':cr['selectedChainId']}
   di=discovery[(sub,gid)];sr=structured[(sub,gid)]
   candidatepaths={r['path']:r for r in di['candidates']}
   exact=di['locatorDiscovery']['resolvedFiles'];closest={}
   for r in sr:
    p=r['path']
    if 'goal-visualization-review/'in p and (r.get('decisions')or r.get('approvalFields')):
     closest[p]={'path':p,'sha256':r['sha256'],'recordPointers':sorted({x['pointer']for x in sr if x['path']==p})}
   rows.append({'subject':sub,'goalId':gid,'curricularAtomic':kinds[(sub,gid)],'status':status,
    'currentTitle':g['title'],'currentDescription':g['description'],'currentQaReviewerRoutingOnly':q['aiReviewer'],'currentQaReviewedAtRoutingOnly':q['aiReviewedAt'],
    'currentInputs':pins[sub],'currentAssetCopies':assets,'currentAssetSha256':q['assetSha256'],
    'allOriginalChainIds':[e['chainId']for e in ev],'supportedOriginalChainIds':[e['chainId']for e in supported],'matchingOriginalChainIds':[e['chainId']for e in matching],
    'chemistryIndependentCensus':chemref,'discoveryIndexGoalKey':{'subject':sub,'goalId':gid},'candidateFileCount':len(candidatepaths),'structuredCandidateRecordCount':len(sr),'structuredCandidateFileCount':len({r['path']for r in sr}),
    'originalNotesLocatorDiscovery':di['locatorDiscovery'],'closestActualReviewRecordCandidates':list(closest.values()),
    'newVisualReviewPerformed':False,'nativeQualificationIssuedByThisCensus':False,'activeQaChanged':False,
    'boundary':'A matching original context is not a new approval and not an installed profile. Missing original review context stays open; same-image aggregate rows, generation, D/P results, technical imports and nearby Git source snapshots cannot supply it.'})
 assert len(rows)==2562 and len({(r['subject'],r['goalId'])for r in rows})==2562
 assert sum(r['curricularAtomic']for r in rows)==2483
 for r in inputs:assert sha((ROOT/r['path']).read_bytes())==r['sha256'],r['path']
 count=lambda rs:dict(collections.Counter(r['status']for r in rs))
 summary={'schemaVersion':1,'kind':'finite-five-ledger-historical-visual-context-census','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),
  'rows':len(rows),'curricularAtomicRows':2483,'counts':count(rows),'curricularAtomicCounts':count([r for r in rows if r['curricularAtomic']]),
  'subjects':{s:{'rows':len(qas[s]),'counts':count([r for r in rows if r['subject']==s]),'curricularAtomicCounts':count([r for r in rows if r['subject']==s and r['curricularAtomic']])}for s in qas},
  'currentInputs':inputs,'initialFieldCensus':ref(fieldpath),'familyCensusArtifacts':families,'historicalFamilyRows':len(chains),'chemistryIndependentCensus':ref(chemPath),'chemistryOriginalChains':ref(chemChainsPath),'chemistryFreeze':ref(CHEM/'freeze-manifest.json'),
  'searchInputs':[ref(INDEX/'artifact-discovery.json.gz'),ref(discoveryPath),ref(structuredPath),ref(Path('/dev/shm/skillpilot-v-original-discovery-aliases/alias-resolution.json.gz'))],
  'finiteSearchBoundary':{'discoveryCommit':'7ab16f4afc45b3f384577e04b5ba85b680a7678d','selectedCommittedFiles':124615,'filesWithCurrentIds':89417,'structuredCandidateFiles':87956,'structuredCandidateRecords':112195,'resolvedSymlinkLocators':4411,'everyCurrentRowClassifiedExactlyOnce':True,
   'notClaimed':['Exhaustive review of every deleted historical Git blob, private session or untracked old tmp file.','A proof that no additional original chain could ever be recovered.','A new content/visual review, human approval or current full V/M7/CI pass.'],
   'unclosedMeaning':'No adequate current original-context chain was established within this pinned corpus and the explicitly followed original references. Current context must be freshly reviewed or an authentic previously missing original chain independently supplied before reuse. No generated reconstruction or copied current description can close it.'},
  'allCurrentSourceQaKindPinsUnchanged':True,'currentAssetPathsHashed':len(assetcache),'newImagesViewed':0,'activeWrites':0,'nativeCapabilitiesIssued':0,'historicalOriginalsRewritten':0}
 artifacts=[write_gz('five-ledger-disjoint-context-census.json.gz',{'summary':summary,'rows':rows}),write_gz('non-chemistry-original-context-chains.json.gz',chains)]
 for name in ['chemie-original-chains.json.gz','chemie-478-context-census.json.gz','search-manifest.json','freeze-manifest.json']:
  dst=OUT/('chemistry-'+name);shutil.copyfile(CHEM/name,dst);artifacts.append(ref(dst))
 p=OUT/'summary.json';p.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');artifacts.append(ref(p))
 with (OUT/'five-ledger-status.csv').open('w')as f:
  w=csv.DictWriter(f,fieldnames=['subject','goalId','curricularAtomic','status','currentTitle','currentQaReviewerRoutingOnly']);w.writeheader();w.writerows({k:r[k]for k in w.fieldnames}for r in rows)
 artifacts.append(ref(OUT/'five-ledger-status.csv'))
 (OUT/'artifact-hashes.json').write_text(json.dumps({'artifacts':artifacts,'script':ref(Path(__file__))},indent=2)+'\n')
 print(json.dumps({'rows':2562,'counts':summary['counts'],'subjects':summary['subjects'],'summarySha256':sha(p.read_bytes()),'packet':str(OUT)},ensure_ascii=False))
if __name__=='__main__':main()
