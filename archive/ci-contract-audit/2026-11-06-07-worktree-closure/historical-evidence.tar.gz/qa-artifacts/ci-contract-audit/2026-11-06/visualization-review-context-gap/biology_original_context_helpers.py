"""Audit-only exact original references; not a native review qualification adapter."""
from pathlib import Path
import collections,datetime,hashlib,json,runpy
H=Path(__file__).resolve().parent;K=runpy.run_path(str(H/'qualify-three-biology-original-context-families.py'));ROOT=K['ROOT'];original=K['original'];COMMIT=K['COMMIT'];B=K['B'];bound=K['bound'];one=K['one'];sha=K['sha'];SOURCE=K['SOURCE'];QA=K['QA']
class Audit:
 def __init__(self,out):
  self.out=Path(out);self.out.mkdir(exist_ok=False);self.pins={p:sha(p)for p in[SOURCE,QA]};self.goals={g['id']:g for g in json.loads((ROOT/SOURCE).read_bytes())['goals']};self.qa={r['goalId']:r for r in json.loads((ROOT/QA).read_bytes())['records']};self.ownerref,_=B['owner_source'](SOURCE,COMMIT);self.rows=[]
 def record(self,f,rr,g,a,views,refs,actor,date,reason,boundaries=[]):
  gid=g['id'];assert gid in self.qa;ar,_=original(a['path'],a['sha256']);h=a['sha256'].removeprefix('sha256:');same=self.qa[gid]['assetSha256']=='sha256:'+h
  if same:B['require_asset'](ar,self.qa[gid],h)
  for av in views:vr,_=original(av['path'],av['sha256']);refs.append(vr)
  ctx={k:g[k]for k in ['title','description','titleEn','descriptionEn']if k in g};assert 'title'in ctx and'description'in ctx;diff=[k for k,val in ctx.items()if val!=self.goals[gid].get(k)]
  status='matching-original-context-closed-adapter-pending'
  if not same:status='open-original-reviewed-asset-differs'
  elif diff:status='open-original-context-differs'
  self.rows.append({'family':f,'goalId':gid,'status':status,'originalReview':rr,'originalContextChain':refs,'ownerSource':self.ownerref,'reviewedAsset':ar,'originalContext':ctx,'currentContext':{k:self.goals[gid].get(k)for k in ctx},'mismatchingFields':diff,'originalAndCurrentAssetBytesVerified':same,'originalReviewer':actor,'originalReviewedAt':date,'originalReason':reason,'boundaries':boundaries,'nativeQualificationAdapterAvailable':False})
 def finish(self,kind,n):
  assert len(self.rows)==n;assert all(sha(p)==h for p,h in self.pins.items());result={'schemaVersion':1,'kind':kind,'acceptedRepositoryCommit':COMMIT,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'activeInputs':[{'path':p,'sha256':h}for p,h in self.pins.items()],'rows':self.rows,'counts':dict(collections.Counter(r['status']for r in self.rows)),'scope':{'newVisualReview':False,'activeWrites':False,'nativeAdapterAvailable':False,'globalCompleteness':False}};p=self.out/'family-census.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':n,'counts':result['counts'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
