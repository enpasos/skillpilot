#!/usr/bin/env python3
from multi_subject_original_context_helpers import *
P='curricula/DE/Gymnasium/quality/goal-visualization-review/'
def main():
 a=SubjectAudit('/dev/shm/skillpilot-v-math-late-six-originals','mathematik')
 def add(f,rr,r,g,asset,actor,date,reason,extra=[]):
  h=asset['sha256']; gid=g['id'];assert a.qa[gid]['assetSha256'].removeprefix('sha256:')==h.removeprefix('sha256:')
  a.record(f,rr,g,{'path':a.qa[gid]['canonicalAssetPath'],'sha256':h},[],[rr],actor,date,reason,['Historical generated/private asset locator: '+asset['path'],'Exact reviewed asset SHA resolved to byte-identical retained canonical Git bytes; no text is obtained from this alias. Historical viewport evidence is not newly executed or independently reproduced.']+extra)
 rr,r=original(P+'m7-comic-png-three-20260928-v1/png-independent-review.json')
 for v in r['reviews']:
  assert v['mathDecision']==v['visualDecision']=='accept'and v['actualOriginalViewed'];add('math-three-final-png-original-goal-text-review',rr,r,v['goalText'],v['source'],r['reviewer'],r['recordedAt'],v['mathChecks']+v['visualChecks'],['The original review expressly did not perform a mobile360 review. Context qualification does not create it.'])
 rr,r=original(P+'m7-current-image-repairs-20260928-v1/fresh-b-converse-png-independent-review.json')
 for v in r['reviews']:
  if v['decision']!='pass':continue
  assert v['candidate']['actualOriginalViewed'];add('math-converse-criterion-original-accepted-context',rr,r,v['goalText'],v['candidate'],r['reviewer'],r['reviewedAt'],v['mathChecks']+v['readabilityChecks'])
 rr,r=original(P+'m7-current-image-repairs-20260928-v1/fresh-b-converse-proof-exact-png-independent-review.json');assert r['decision']=='pass'and r['candidate']['actualOriginalViewed'];add('math-converse-proof-corrected-original-accepted-context',rr,r,r['goalText'],r['candidate'],r['reviewer'],r['reviewedAt'],r['logicAndLabels']+r['visualAndMobileChecks'])
 rr,r=original(P+'math-b042-current-image-repairs-v1/independent-image-review-v1.json')
 for v in r['results']:
  if v['verdict']!='pass_as_teaching_candidate':continue
  g={'id':v['goalId'],'title':v['currentTitleDe'],'description':v['currentDescriptionDe']};add('math-integration-combination-original-independent-context',rr,r,g,{'path':v['imagePath'],'sha256':v['imageSha256']},r['reviewer'],r['completedAt'],v['positiveControls']+[v['scopeConclusion']])
 a.finish('math-six-additional-original-positive-contexts',6)
if __name__=='__main__':main()
