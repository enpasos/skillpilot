#!/usr/bin/env python3
"""Report original metadata gaps without completing or rewriting old reviews."""
from pathlib import Path
import json,gzip,hashlib,collections
ROOT=Path(__file__).resolve().parents[4]
OUT=Path('/dev/shm/skillpilot-v-five-ledger-completed-census')
def sha(b):return hashlib.sha256(b).hexdigest()
def get(p):return json.loads(gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes())
def main():
 census=get(OUT/'five-ledger-disjoint-context-census.json.gz');chains={x['chainId']:x['record']for x in get(OUT/'non-chemistry-original-context-chains.json.gz')};chem={x['goalId']:x for x in get(OUT/'chemistry-chemie-478-context-census.json.gz')['rows']};rows=[]
 for r in census['rows']:
  if r['status']!='matching-original-context-closed-adapter-pending':continue
  if r['subject']=='chemie':
   cr=chem[r['goalId']];rs=[cr['selectedOriginalChain']]
  else:rs=[chains[x]for x in r['matchingOriginalChainIds']]
  choices=[]
  for x in rs:
   actor=x.get('originalReviewer');date=x.get('originalReviewedAt')or x.get('originalReviewDateFields');refs=[x['originalReview']]
   # The initial finite family manifest did not duplicate these metadata keys.
   # Read only its already SHA-bound original root fields, never current QA.
   if 'originalTitle'in x:
    rr=x['originalReview'];raw=(ROOT/rr['path']).read_bytes();assert sha(raw)==rr['sha256'];o=json.loads(raw);actor=o.get('reviewer');date=o.get('reviewedAt')or o.get('actualCompletedAt')
   missing=[]
   if not actor:missing.append('original-reviewer-not-extracted')
   if not date:missing.append('original-review-time-not-extracted')
   choices.append({'originalReview':x['originalReview'],'originalReviewer':actor,'originalReviewTimeEvidence':date,'missingOriginalMetadata':missing})
  complete=any(not x['missingOriginalMetadata']for x in choices)
  rows.append({'subject':r['subject'],'goalId':r['goalId'],'atLeastOneMatchingChainWithCapturedOriginalActorAndTime':complete,'matchingOriginalMetadataAlternatives':choices,'nativeQualificationIssued':False})
 assert len(rows)==945
 gap=[r for r in rows if not r['atLeastOneMatchingChainWithCapturedOriginalActorAndTime']]
 d={'kind':'original-metadata-followup-only','matchingOriginalContextRows':945,'atLeastOneCapturedActorAndTime':945-len(gap),'metadataStillUnresolved':len(gap),'unresolvedBySubject':dict(collections.Counter(r['subject']for r in gap)),'boundary':'Date-only evidence remains date-only. Null original metadata is not filled from aggregate QA, filenames, commit times or this audit. A closed profile must validate the actual historical form; this report issues no native qualification. A missing extracted actor/time is an additional unresolved qualification boundary, not an assertion that new images must be generated or no authentic attribution could be recovered.','rows':rows}
 raw=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();p=OUT/'matching-original-metadata-audit.json.gz';p.write_bytes(gzip.compress(raw,mtime=0));print(json.dumps({'rows':945,'unresolved':len(gap),'bySubject':d['unresolvedBySubject'],'sha256':sha(p.read_bytes()),'rawSha256':sha(raw)}))
if __name__=='__main__':main()
