#!/usr/bin/env python3
"""Closed NI18 and Bio8-V19 original input/review seal profiles, no fresh review."""
from pathlib import Path
import collections,datetime,hashlib,json,runpy
H=Path(__file__).resolve().parent;K=runpy.run_path(str(H/'qualify-three-biology-original-context-families.py'));ROOT=K['ROOT'];original=K['original'];COMMIT=K['COMMIT'];B=K['B'];bound=K['bound'];one=K['one'];sha=K['sha'];SOURCE=K['SOURCE'];QA=K['QA']
OUT=Path('/dev/shm/skillpilot-v-biology-two-sealed-original-families')
NI='curricula/DE/Gymnasium/quality/goal-visualization-review/biologie-ni-eighteen-current-independent-v-v1/'
BIO='curricula/DE/Gymnasium/quality/goal-evidence/2026-10-11/biologie-bio8-current369-v6-genuine-independent-a-root-20261011-v1/'
def main():
 OUT.mkdir(exist_ok=False);pins={p:sha(p)for p in[SOURCE,QA]};goals={g['id']:g for g in json.loads((ROOT/SOURCE).read_bytes())['goals']};qa={r['goalId']:r for r in json.loads((ROOT/QA).read_bytes())['records']};ownerref,_=B['owner_source'](SOURCE,COMMIT);rows=[]
 def rec(f,rr,v,g,a,views,refs,actor,date,reason,extra):
  gid=v['goalId'];assert gid in qa;ar,_=original(a['path'],a['sha256']);h=a['sha256'].removeprefix('sha256:');same=qa[gid]['assetSha256']=='sha256:'+h
  if same:B['require_asset'](ar,qa[gid],h)
  for item in views:vr,_=original(item['path'],item['sha256']);refs.append(vr)
  context={k:g[k]for k in ['title','description','titleEn','descriptionEn']if k in g};assert 'title'in context and'description'in context
  differences=[k for k,val in context.items()if val!=goals[gid].get(k)];status='matching-original-context-closed-adapter-pending'
  if not same:status='open-original-reviewed-asset-differs'
  elif differences:status='open-original-context-differs'
  rows.append({'family':f,'goalId':gid,'status':status,'originalReview':rr,'originalContextChain':refs,'ownerSource':ownerref,'reviewedAsset':ar,'originalContext':context,'currentContext':{k:goals[gid].get(k)for k in context},'mismatchingFields':differences,'originalAndCurrentAssetBytesVerified':same,'originalReviewer':actor,'originalReviewedAt':date,'originalReason':reason,'boundaries':extra,'nativeQualificationAdapterAvailable':False})
 sr,s=original(NI+'independent-v-science.before-native.final.freeze.json');refs=[sr]
 rb=next(b for b in s['files']if b['path'].endswith('/independent-eighteen-actual-image-science-and-legibility-verdicts.json'));r=bound(rb,refs);rr=refs[-1]
 inp=bound(next(b for b in s['files']if b['path'].endswith('/exact-eighteen-current-image-inputs-and-view-files.snapshot.json')),refs);assert inp['authorFreezeSHA256']==s['authorFreezeSHA256']
 for v in r['rows']:
  assert v['decision']=='KEEP'and v['actualOriginal360680ViewsSeen'];g=one(inp['rows'],v['goalId']);assert g['currentGoalFingerprint']==v['currentGoalFingerprint'] and g['currentPageFingerprint']==v['currentPageFingerprint']and g['assetSHA256'].removeprefix('sha256:')==v['assetSHA256'].removeprefix('sha256:')
  ctx={'title':g['titleDe'],'description':g['descriptionDe'],'descriptionEn':g['descriptionEn']}
  a={'path':g['originalView'],'sha256':g['viewFileSHA256']};views=[{'path':z['path'],'sha256':z['SHA256']}for z in g['mobileDesktopViews']]
  rec('biology-ni18-original-snapshot-and-verdict-seal',rr,v,ctx,a,views,list(refs),r['reviewer'],r['reviewedAtUTC'],v['manualScientificReview'],['Original title/description are read from the actual independently sealed input snapshot, not current native QA fields. No original English title is claimed.'])
 sr,s=original(BIO+'original-independent-a.freeze.json');refs=[sr]
 r=bound(next(b for b in s['files']if b['path'].endswith('/V19-originals-widths-wholeHTML-PDF.own-scientific-review.json')),refs);rr=refs[-1]
 check=bound(next(b for b in s['files']if b['path'].endswith('/FIRST.actual-neutral-input-check.json')),refs)
 whole=bound(next(b for b in check['checkedBindings']if b['path'].endswith('/candidate/whole484-current369-Bio3-combined.author.inactive.json')),refs)['goals']
 for v in r['records']:
  assert v['decision']=='KEEP' and all(v[k]is True for k in['actualOriginalInspected','actual360and680PixelsInspected','actualWholeHTMLandPDFPagesInspected'])
  capture=v['ownBrowserCaptureBindings'];assert capture['source']['sha256']==v['original']['sha256']and capture['actualDisplayWidths']==[360,680]
  rec('biology-bio8-v19-original-neutral-input-and-review-seal',rr,v,one(whole,v['goalId']),v['original'],[capture['capture']],list(refs),s['reviewer'],s['createdAtUTC'],v['ownScienceAndRepresentationRationale'],['Timestamp is the original independent seal time, not a newly inferred pixel-view time. Original reviewer explicitly did not claim fully blind review.'])
 assert len(rows)==37 and len({r['goalId']for r in rows})==37;assert all(sha(p)==h for p,h in pins.items())
 result={'schemaVersion':1,'kind':'two-biology-sealed-original-context-family-census','acceptedRepositoryCommit':COMMIT,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'activeInputs':[{'path':p,'sha256':h}for p,h in pins.items()],'rows':rows,'counts':dict(collections.Counter(r['status']for r in rows)),'scope':{'newVisualReview':False,'activeWrites':False,'nativeAdapterAvailable':False,'globalCompleteness':False}}
 p=OUT/'family-census.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':len(rows),'counts':result['counts'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
if __name__=='__main__':main()
