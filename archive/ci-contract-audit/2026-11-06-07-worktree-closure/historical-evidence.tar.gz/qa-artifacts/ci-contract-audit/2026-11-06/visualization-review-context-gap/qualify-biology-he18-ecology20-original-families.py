#!/usr/bin/env python3
"""Two further original independent input/review seals; no new visual approval."""
from pathlib import Path
import collections,datetime,hashlib,json,runpy
H=Path(__file__).resolve().parent;K=runpy.run_path(str(H/'qualify-three-biology-original-context-families.py'));ROOT=K['ROOT'];original=K['original'];COMMIT=K['COMMIT'];B=K['B'];bound=K['bound'];one=K['one'];sha=K['sha'];SOURCE=K['SOURCE'];QA=K['QA']
OUT=Path('/dev/shm/skillpilot-v-biology-he18-ecology20-original-families')
HE='curricula/DE/Gymnasium/quality/goal-evidence/2026-10-08/biologie-he9-eighteen-final-raster-native-independent-a-20261008-v1/'
EC='curricula/DE/Gymnasium/quality/goal-evidence/2026-10-07/biologie-ecology20-current391-independent-a-20261007-v1/'
def main():
 OUT.mkdir(exist_ok=False);pins={p:sha(p)for p in[SOURCE,QA]};goals={g['id']:g for g in json.loads((ROOT/SOURCE).read_bytes())['goals']};qa={r['goalId']:r for r in json.loads((ROOT/QA).read_bytes())['records']};ownerref,_=B['owner_source'](SOURCE,COMMIT);rows=[]
 def rec(f,rr,v,g,a,views,refs,actor,date,reason):
  gid=v['goalId'];assert gid==g['id'] and gid in qa;ar,_=original(a['path'],a['sha256']);h=a['sha256'].removeprefix('sha256:');same=qa[gid]['assetSha256']=='sha256:'+h
  if same:B['require_asset'](ar,qa[gid],h)
  for av in views:vr,_=original(av['path'],av['sha256']);refs.append(vr)
  ctx={k:g[k]for k in ['title','description','titleEn','descriptionEn']if k in g};assert 'title'in ctx and'description'in ctx;diff=[k for k,val in ctx.items()if val!=goals[gid].get(k)]
  status='matching-original-context-closed-adapter-pending'
  if not same:status='open-original-reviewed-asset-differs'
  elif diff:status='open-original-context-differs'
  rows.append({'family':f,'goalId':gid,'status':status,'originalReview':rr,'originalContextChain':refs,'ownerSource':ownerref,'reviewedAsset':ar,'originalContext':ctx,'currentContext':{k:goals[gid].get(k)for k in ctx},'mismatchingFields':diff,'originalAndCurrentAssetBytesVerified':same,'originalReviewer':actor,'originalReviewedAt':date,'originalReason':reason,'nativeQualificationAdapterAvailable':False})
 sr,s=original(HE+'completed-native-D18-P18-V18.independent-a.final.freeze.json');refs=[sr]
 r=bound(next(b for b in s['frozenFiles']if b['path'].endswith('/actual-eighteen-V-first-independent-a.verdicts.json')),refs);rr=refs[-1]
 whole=bound(next(b for b in s['frozenFiles']if b['path'].endswith('/pending/exact-eighteen-whole-goals-profiles-and-forty-conditional-DEEN-cases.input.json')),refs)['records'];gs={z['goal']['id']:z['goal']for z in whole}
 assert r['actualReadCounts']=={'completeOriginalPNGs':18,'chromium360':18,'chromium680':18,'completeNativeGoalPages':18}
 for v in r['records']:
  assert v['machineCandidateDecision']=='KEEP'and v['scientificAndVisualVerdict']=='PASS'
  rec('biology-he18-original-whole-input-and-first-verdict-seal',rr,v,gs[v['goalId']],v['actualObservedFullRaster'],v['actualObservedChromiumCaptures']+[v['actualObservedNativePdfPage']],list(refs),r['actualAgent'],r['recordedAt'],v['substantiveActualObservationsDe'])
 sr,s=original(EC+'final-independent-a-dossier.freeze.json');refs=[sr]
 r=bound(next(b for b in s['files']if b['path'].endswith('/V20.actual-raster-full-width-page-independent-a.final.json')),refs);rr=refs[-1]
 af=bound(s['authorInputFreeze'],refs);gb=next(b for b in af['files']if b['path']=='current20-whole-DEEN-goals.actual.json');gb={**gb,'path':str(Path(s['authorInputFreeze']['path']).parent/gb['path'])};whole=bound(gb,refs)
 if isinstance(whole,dict):whole=whole['goals']
 selected=bound(r['selectedManifest'],refs)['images']
 for v in r['records']:
  assert v['decision']=='KEEP'and v['aiApproved']=='yes'and v['actualSeen']==['full','360','680','native-book-page']
  a={'path':v['sourcePath'],'sha256':v['assetSha256']};sel=one(selected,v['goalId']);assert sel['path']==a['path']and sel['sha256'].removeprefix('sha256:')==a['sha256'].removeprefix('sha256:')
  rec('biology-ecology20-original-whole-input-and-first-verdict-seal',rr,v,one(whole,v['goalId']),a,v['capturesActuallySeen'],list(refs),v['aiReviewer'],v['aiReviewedAt'],v['aiNotes'])
 assert len(rows)==38 and len({r['goalId']for r in rows})==38;assert all(sha(p)==h for p,h in pins.items())
 result={'schemaVersion':1,'kind':'he18-ecology20-original-context-family-census','acceptedRepositoryCommit':COMMIT,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'activeInputs':[{'path':p,'sha256':h}for p,h in pins.items()],'rows':rows,'counts':dict(collections.Counter(r['status']for r in rows)),'scope':{'newVisualReview':False,'activeWrites':False,'nativeAdapterAvailable':False,'globalCompleteness':False}}
 p=OUT/'family-census.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':len(rows),'counts':result['counts'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
if __name__=='__main__':main()
