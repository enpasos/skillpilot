from biology_original_context_helpers import *
A=Audit('/dev/shm/skillpilot-v-biology-targeted-he9-stoffwechsel-original-families')
base='curricula/DE/Gymnasium/quality/goal-evidence/2026-10-08/'
rr,r=original(base+'biologie-he9-split-four-final-raster-native-independent-a-20261008-v1/actual-whole-four-D-P-V-first.independent-a.verdict.json')
for x in r['records']:
 assert x['actualVisualizationDecision']=='KEEP'
 A.record('biology-he9-split-four-original-a',rr,x['wholeGoalBody'],x['actualFullPNG'],x['actualWidthCaptures']+[x['actualCompleteNativePage']],[rr],r['role'],r['recordedAt'],x['substantiveActualVisualObservationsDe'])
rr,r=original(base+'biologie-he-evolution-one-cat-anatomy-targeted-independent-a-20261008-v2/actual-current-one-D-P-V.independent-a.first.verdict.json')
assert r['visualizationDecision']=='KEEP'
A.record('biology-evolution-cat-one-original-a',rr,r['wholeCurrentGoal'],r['actualFullPNG'],r['actualWidths']+[r['actualWholeNativeOnePhysical3'],r['actualAdditionalWholeNativeEighteenPhysical6']],[rr],r['role'],r['recordedAt'],r['reasonDe'])
rr,r=original(base+'biologie-he9-genetic-method19-current-raster-native-independent-a-20261008-v1/current-one-whole-source-cases-class-AM-D-P-V.independent-a.first.json')
assert r['visualDecision']=='KEEP'
A.record('biology-he9-genetic-method19-original-a',rr,r['exactCurrentWholeGoal'],r['actualOriginal'],r['actualWidths']+[r['actualWholeNativePage3']],[rr],r['artifactKind'],r['recordedAt'],r['visualScientificObservations'],['Original role attribution retained without inventing named reviewer.'])
for folder,file in [('biologie-stoffwechsel-final-two-actual-visual-independent-a-20261008-v1','final-two-actual-visual-independent-a.first.verdicts.json'),('biologie-stoffwechsel-first-photosynthesis-actual-visual-independent-a-20261008-v1','first-photosynthesis-actual-visual-independent-a.first.verdicts.json'),('biologie-stoffwechsel-third-antenna-targeted-visual-independent-a-addendum-20261008-v3','third-antenna-v3.independent-a.first-addendum.verdicts.json')]:
 rr,r=original(base+folder+'/'+file);refs=[rr];bound(r['inputFreeze'],refs);bound(r['actualReadingReceipt'],refs)
 for x in r['rows']:
  assert x['observedFullOriginal'] and x['observedActual360And680'] and x['ownDecision']=='APPROVE_AI_VISUAL_GATE_EXACT_CURRENT_RASTER'
  A.record(folder,rr,x['wholeCurrentGoal'],x['actualOriginalAsset'],[z['screenshot']if 'screenshot'in z else z for z in x['actualPreviewBindings']],list(refs),r['reviewerTask'],r['createdAtUtc'],{'fit':x['wholeGoalFitDe'],'science':x['actualScientificObservationDe'],'limit':x['scopeLimitDe']})
A.finish('biology-targeted-he9-stoffwechsel-original-context-families',10)
