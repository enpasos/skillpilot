#!/usr/bin/env python3
from pathlib import Path
import collections,datetime,hashlib,json,re,runpy
H=Path(__file__).resolve().parent;K=runpy.run_path(str(H/'qualify-nine-economics-context-families.py'));ROOT=K['ROOT'];SOURCE=K['SOURCE'];QA=K['QA'];COMMIT=K['COMMIT'];original=K['original'];sha=K['sha'];BASE=runpy.run_path(str(H/'qualify-first-two-families.py'))
OUT=ROOT/'qa-artifacts/ci-contract-audit/2026-11-06/visualization-context-economics-q4-corrections';FAMILY='wirtschaft-q4-twenty-seven-image-author-20261008-v1'
def main():
 OUT.mkdir(exist_ok=False);active={p:sha(p)for p in [SOURCE,QA]};ownerref,owner=BASE['owner_source'](SOURCE,COMMIT);goals={g['id']:g for g in json.loads((ROOT/SOURCE).read_bytes())['goals']};qa=json.loads((ROOT/QA).read_bytes())['records'];selected=[r for r in qa if FAMILY in r['aiNotes']];assert len(selected)==11;rows=[]
 for current in selected:
  gid=current['goalId'];paths=[p for p in re.findall(r'curricula/[^\s`)]+\.json',current['aiNotes'])if FAMILY in p];assert len(paths)==1
  rr,r=original(paths[0]);assert r['goalId']==gid and r['decision']=='KEEP' and r['reviewerAgent']=='/root/economics_visual_memory_audit'
  refs=[rr]
  if 'wholeCurrentPreparedGoal'in r:
   assert r['wholeCurrentDeEnGoalActuallyRead'] is True
   g=r['wholeCurrentPreparedGoal'];assert g['id']==gid;context={k:g[k]for k in ['title','description','titleEn','descriptionEn']};views=r['actualInspectedViews'];ap,ah=r['imagePath'],r['imageSha256'];reason=r['rationaleDe']
  elif 'currentGoalTitle'in r:
   assert r['independentOfAuthor']is True and r['fullWholeCurrentDeEnGoalActuallyRead']is True
   context={k:r[v]for k,v in [('title','currentGoalTitle'),('description','currentGoalDescriptionDe'),('descriptionEn','currentGoalDescriptionEn')]};views=r['actualInspectedViews'];ap,ah=r['imagePath'],r['imageSha256'];reason=r['rationaleDe']
   ir,_=original(r['actualPreparedInputsPath'],r['actualPreparedInputsSha256']);refs.append(ir)
  else:
   assert r['role']=='independent_actual_visual_reviewer'
   context={k:r[v]for k,v in [('title','goalTitleDe'),('description','goalDescriptionDe'),('descriptionEn','goalDescriptionEn')]};views=r['actualDerivativePaths'];ap,ah=r['candidatePath'],r['assetSha256'];reason=r['findings'];assert r['actualViews']==['entire native1672x941','entire360x203','entire680x383']
   ir,_=original(r['actualGoalInputPath'],r['actualGoalInputFileSha256']);refs.append(ir)
  ar,_=original(ap,ah);BASE['require_asset'](ar,current,ah.removeprefix('sha256:'))
  assert {360,680}<={v.get('width')for v in views}
  for v in views:
   ref,_=original(v['path'],v['sha256']);refs.append(ref)
  mismatch=[k for k,v in context.items()if v!=goals[gid].get(k)]
  rows.append({'family':FAMILY,'goalId':gid,'status':'open-original-context-differs'if mismatch else'matching-original-context-closed-adapter-pending','profile':'economics-q4-corrected-embedded-context-adapter-pending','originalReview':rr,'originalContextChain':refs,'ownerSource':ownerref,'reviewedAsset':ar,'originalContext':context,'currentContext':{k:goals[gid].get(k)for k in context},'mismatchingFields':mismatch,'originalReviewer':r['reviewerAgent'],'originalReviewedAt':r['reviewedAt'],'originalReason':reason,'originalDecision':'KEEP','originalAndCurrentAssetBytesVerified':True,'nativeQualificationAdapterAvailable':False})
 assert all(sha(p)==v for p,v in active.items());out={'schemaVersion':1,'kind':'eleven-original-q4-correction-contexts','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'acceptedRepositoryCommit':COMMIT,'activeInputs':[{'path':p,'sha256':h}for p,h in active.items()],'counts':dict(collections.Counter(r['status']for r in rows)),'rows':rows,'scope':{'newVisualReview':False,'activeWrites':False,'nativeQualificationAdapterAvailable':False,'globalInventoryCompleteness':False}}
 p=OUT/'family-census.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':len(rows),'counts':out['counts'],'sha256':sha(str(p.relative_to(ROOT)))}))
if __name__=='__main__':main()
