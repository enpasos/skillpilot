#!/usr/bin/env python3
"""Nine closed historical context formats; no present-day image judgment."""
from pathlib import Path
import collections,datetime,hashlib,json,re,runpy
H=Path(__file__).resolve().parent;K=runpy.run_path(str(H/'qualify-first-two-families.py'))
ROOT=K['ROOT'];COMMIT=K['ACCEPTED'];SOURCE=K['ECON_SOURCE'];QA=K['ECON_QA']
OUT=ROOT/'qa-artifacts/ci-contract-audit/2026-11-06/visualization-context-nine-economics-context-families'
FAMILIES={
 'wirtschaft-q1-nine-independent-image-review-20261008-v1':9,
 'wirtschaft-q2-labour-twelve-independent-image-review-20261008-v1':11,
 'wirtschaft-q3-trade-finance-sixteen-independent-image-review-20261008-v1':16,
 'wirtschaft-q4-twenty-seven-independent-image-review-20261008-v1':15,
 'wirtschaft-q3-site-competition-one-independent-image-review-20261008-v2':1,
 'wirtschaft-one-Montan-executive-director-independent-native-phone-desktop-V-review-20261009-v1':1,
 'wirtschaft-e-law-twenty-independent-image-review-20261008-v1':19,
 'wirtschaft-e-company-twenty-independent-bounded-image-review-20261008-v2':1,
 'wirtschaft-by-eleven-independent-image-review-20261008-v1':11,
}
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
def original(p,h=None):
 p=p.removeprefix('/home/enpasos/projects/skillpilot/')
 assert not p.startswith('/') and '..' not in Path(p).parts
 ref,raw=K['original'](p,COMMIT)
 if h:assert ref['sha256']==h.removeprefix('sha256:'),(p,h)
 return ref,json.loads(raw) if p.endswith('.json') else raw

def main():
 OUT.mkdir(exist_ok=False);active={p:sha(p)for p in [SOURCE,QA]}
 assert active[SOURCE]=='3a60e7ba51cac98666f3943cee3ebb77c129c653f9fdde9f4c09bb20446da9b3'
 ownerref,owner=K['owner_source'](SOURCE,COMMIT);ownerids={g['id']for g in owner['goals']}
 goals={g['id']:g for g in json.loads((ROOT/SOURCE).read_bytes())['goals']};qa=json.loads((ROOT/QA).read_bytes())['records'];rows=[]
 for f,n in FAMILIES.items():
  selected=[r for r in qa if f in r['aiNotes']];assert len(selected)==n
  for current in selected:
   gid=current['goalId'];ps=[p for p in re.findall(r'curricula/[^\s`)]+\.json',current['aiNotes'])if f in p];assert len(ps)==1
   rr,r=original(ps[0]);assert r['goalId']==gid and gid in ownerids and current['landscapeId']==owner['landscapeId']
   refs=[rr];context={};views=[]
   if f.startswith('wirtschaft-e-law-'):
    assert r['decision']=='KEEP' and r['actualSizesInspected']==['native','360','680']
    if 'currentDescriptionDeActuallyRead'in r:
     assert r['machineReviewCandidateOnly'] is True
     context={k:r[v]for k,v in [('title','currentTitleDeActuallyRead'),('description','currentDescriptionDeActuallyRead'),('titleEn','currentTitleEnActuallyRead'),('descriptionEn','currentDescriptionEnActuallyRead')]}
     cr,c=original(r['wholeGoalCandidatePath'],r['wholeGoalCandidateSHA']);refs.append(cr)
     gs=[g for g in c if g['id']==gid];assert len(gs)==1 and all(gs[0][k]==v for k,v in context.items())
     actor=r['reviewer']['agentIdentity']
    else:
     assert r['actualNativeBeforeMetadataAndPersistedCorrectionArgumentsAndGenerationProvenanceRead'] is True
     br,b=original(r['actualNativeBeforeReceiptPath'],r['actualNativeBeforeReceiptDigest']);refs.append(br)
     ms=[o for o in b['actualNativeOutputs']if o['path'].endswith('/metadata.json')];assert len(ms)==1
     mr,m=original(ms[0]['path'],ms[0]['sha256']);refs.append(mr);assert m['skillpilotId']==gid
     context={k:m[k]for k in ['title','description']};actor=r['reviewerAgentIdentity']
    ap,ah=r['assetPath'],r['assetSha256'];views=r['actualInspectionDerivatives'];date=r['actualCompletedAt'];reason=r['actualFindings'];profile='economics-law-original-or-hashbound-correction'
   elif f.startswith('wirtschaft-e-company-'):
    assert r['reviewDecision']=='KEEP' and all(r['actualViewed'][k]is True for k in ['wholeNative','width360','width680'])
    context={k:r[v]for k,v in [('title','titleDe'),('description','descriptionDe'),('titleEn','titleEn'),('descriptionEn','descriptionEn')]}
    actor=r['reviewerAgentIdentity'];date=r['reviewedAt'];reason=r['findings'];ap,ah=r['assetPath'],r['assetSha256'];views=r['inspectionDerivatives'];profile='economics-company-corrected-full-bilingual-context'
   elif f.startswith('wirtschaft-by-eleven-'):
    assert r['decision']=='KEEP' and r['reviewAuthority']=='ai_candidate'
    g=r.get('currentWholeGoalCandidate',r.get('wholeDEENGoalRetained'));assert g['id']==gid
    context={k:g[k]for k in ['title','description','titleEn','descriptionEn']}
    views=r['actualViews'];assert len(views)==3 and all(v['actuallyViewed'] is True for v in views)
    native=[v for v in views if v['width']not in [360,680]];assert len(native)==1
    ap,ah=native[0]['path'],native[0]['sha256'];actor=r['reviewerAgent'];date=r['actualCompletedAt'];reason=r['rationale'];profile='economics-by-eleven-original-or-corrected-whole-contract'
   else:
    assert r['decision']=='KEEP' and r['reviewer']['authority']=='ai_candidate' and r['reviewer']['independentOfImageAuthor'] is True
    assert r['openFindings']==[]
    if f.startswith('wirtschaft-one-Montan-executive-'):
     g=r['wholeGoalContract'];assert g['id']==gid;context={k:g[k]for k in ['title','description','titleEn','descriptionEn']}
     gr,g2=original(r['sourceGoalSnapshot']['path'],r['sourceGoalSnapshot']['sha256']);refs.append(gr);assert g==g2
     reason=r['scientificReview'];profile='economics-director-whole-contract'
    else:
     context={k:r[v]for k,v in [('title','currentTitleDe'),('description','currentDescriptionDe'),('titleEn','currentTitleEn'),('descriptionEn','currentDescriptionEn')]if v in r}
     if 'wholeGoalCandidatePath'in r:
      gr,gs=original(r['wholeGoalCandidatePath'],r['wholeGoalCandidateSha256']);refs.append(gr);matches=[g for g in gs if g['id']==gid]
      assert len(matches)==1 and all(matches[0][k]==v for k,v in context.items())
     reason=r['actualSubjectReview'];profile='economics-actual-inspections-embedded-context'
    views=r['inspections'];assert len(views)==3 and all(v['actualViewImage']is True for v in views)
    native=[v for v in views if v['width']not in [360,680]];assert len(native)==1
    ap,ah=native[0]['path'],native[0]['sha256'];assert r['assetSha256'].removeprefix('sha256:')==ah.removeprefix('sha256:')
    actor=r['reviewer']['agentIdentity'];date=r['reviewedAt']
   assert context.get('title') and context.get('description') and actor and date and reason
   ar,_=original(ap,ah);K['require_asset'](ar,current,ah.removeprefix('sha256:'))
   for v in views:
    vr,_=original(v['path'],v['sha256']);refs.append(vr)
   mismatch=[k for k,v in context.items()if v!=goals[gid].get(k)]
   rows.append({'family':f,'goalId':gid,'status':'open-original-context-differs'if mismatch else'matching-original-context-closed-adapter-pending','profile':profile+'-adapter-pending','originalReview':rr,'originalContextChain':refs,'ownerSource':ownerref,'reviewedAsset':ar,'originalContext':context,'currentContext':{k:goals[gid].get(k)for k in context},'mismatchingFields':mismatch,'originalReviewer':actor,'originalReviewedAt':date,'originalReason':reason,'originalDecision':'KEEP','originalAndCurrentAssetBytesVerified':True,'nativeQualificationAdapterAvailable':False})
 assert len(rows)==84 and len({r['goalId']for r in rows})==84
 assert all(sha(p)==v for p,v in active.items())
 output={'schemaVersion':1,'kind':'nine-closed-economics-original-context-families','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'acceptedRepositoryCommit':COMMIT,'archivalCommitMeaning':'Existing original review/input/image bytes captured at an actual ancestor commit; commit time is not claimed as the actual original review time. Original review timestamps remain separately unchanged.','activeInputs':[{'path':p,'sha256':h}for p,h in active.items()],'counts':dict(collections.Counter(r['status']for r in rows)),'familyCounts':{f:dict(collections.Counter(r['status']for r in rows if r['family']==f))for f in FAMILIES},'rows':rows,'scope':{'newVisualReview':False,'newAiOrHumanApproval':False,'nativeQualifiedReceipt':False,'activeWrites':False,'globalInventoryCompleteness':False}}
 p=OUT/'family-census.json';p.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':len(rows),'counts':output['counts'],'sha256':sha(str(p.relative_to(ROOT)))}))
if __name__=='__main__':main()
