"""Finite independent mechanism probes; never SourceA or QA acceptance.

Runs only the reviewed namespace mechanics in an independent RAM directory.
Source/tool captures are read-only routed; dependencies are independent copies.
The recorded dependency alteration is a harmless comment, made before capture.
"""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path('/dev/shm/source-a-namespace-independent-review-20261107')
PACKET = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from closed_namespace import CapturedView, run
from trace_contract import NamespaceContract, runtime_for
from identity_qa_read_trace import authenticate_trace


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def store(name, value):
    (PACKET / name).write_text(json.dumps(value, indent=2) + '\n')


def authenticate(launch):
    contract = NamespaceContract(launch)
    facts = authenticate_trace(launch.trace, launch.cwd, contract, launch,
                               runtime_for(launch))
    return contract, facts


def save_run(label, launch, facts):
    result = {'role': launch.role, 'runId': launch.namespace.run_id,
              'exitCode': launch.returncode, 'traceSha256': launch.trace_sha256,
              'processCount': facts['processCount'],
              'sourceReadCount': len(facts['actualSourceReadOrMapPaths']),
              'stdout': launch.stdout.decode(),
              'ramEvidence': str(launch.evidence_directory)}
    for name, raw in [('recorder.strace', launch.recorder_trace.encode()),
                      ('authenticated.json', json.dumps(facts).encode()),
                      ('kernel-namespace-proof.json',
                       json.dumps(launch.namespace.bootstrap).encode())]:
        (PACKET / (label + '-' + name + '.gz')).write_bytes(
            gzip.compress(raw, mtime=0))
    return result


view = CapturedView()
view.verify()
expected = next(x for x in view.capture['dependencies']
                if x['path'] == 'get-tsconfig/dist/index.mjs')
visible = '/qa/pair/original80/app/node_modules/get-tsconfig/dist/index.mjs'
result = {
    'purpose': 'finite independent mechanism counterexamples, no SourceA/QA pass',
    'harness': {'root': str(ROOT),
                'sourceAndTools': 'read-only routed from frozen author capture',
                'dependencies': 'independent copied tree, one harmless added comment',
                'originalCaptureMutated': False},
    'dependencyDrift': {'manifestSha256': expected['sha256'],
                        'capturedSha256': view.entries[visible].sha256,
                        'manifestBytes': expected['bytes'],
                        'capturedBytes': view.entries[visible].bytes,
                        'constructionAndVerificationAccepted': True}}
store('probe-results.json', result)
launch = run(view, 'original')
try:
    contract, facts = authenticate(launch)
    result['dependencyDrift']['nativeWriter'] = save_run('drift-writer', launch, facts)
    actual = next(x for x in facts['files']
                  if x['path'] == 'app/node_modules/get-tsconfig/dist/index.mjs')
    result['dependencyDrift']['actualDependencyRead'] = actual
    sealed = contract.sealed_outputs
    path = next(iter(sealed.slots))
    original_binding = dict(sealed.slots[path])
    result['sealedSubstitution'] = {
        'originalRunId': sealed.run_id,
        'originalWriterTrace': sealed.writer_trace,
        'originalBinding': original_binding}
finally:
    launch.namespace.release()

# Write a different, still semantically valid report only in reviewer scratch.
# No private token, constructor, object.__setattr__, or implementation patch.
foreign = ROOT / 'foreign-report-created-after-writer.json'
foreign.write_bytes(Path(original_binding['physical']).read_bytes() + b'\n')
foreign.chmod(0o400)
stat = foreign.stat()
sealed.slots[path].update(physical=str(foreign), sha256=sha(foreign.read_bytes()),
                          bytes=stat.st_size, device=stat.st_dev, inode=stat.st_ino)
sealed.run_id = 'unrelated-writer-run-id'
sealed.writer_trace = '0' * 64
sealed.verify('original', view)
result['sealedSubstitution'].update({
    'publicNestedSlotMutationAccepted': True,
    'publicRunIdMutationAccepted': True,
    'publicTraceMutationAccepted': True,
    'substitutedBinding': dict(sealed.slots[path]),
    'substitutedRunId': sealed.run_id,
    'substitutedWriterTrace': sealed.writer_trace})
store('probe-results.json', result)
reader = run(view, 'original', entry='namespace-reader.ts', reader_outputs=sealed)
try:
    contract, facts = authenticate(reader)
    result['sealedSubstitution']['nativeReader'] = save_run('substituted-reader', reader, facts)
finally:
    reader.namespace.release()
store('probe-results.json', result)
print(json.dumps(result, indent=2))
