"""Read-only ordinary comparison; does not import or execute captured programs."""
from pathlib import Path
import sys, json, hashlib, os, stat
ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'implementation'))
from namespace_records import dependency_records, validate_dependencies

capture_root = Path('/dev/shm/source-a-closed-namespace-native-candidate-20261107')
manifest_bytes = (capture_root / 'capture-inputs.json').read_bytes()
manifest_sha = hashlib.sha256(manifest_bytes).hexdigest()
assert manifest_sha == '85ff31b0a32e744086123784af446a04c6a11b11db8f81da3bce211e08851de9'
manifest = json.loads(manifest_bytes)
expected = dependency_records(manifest['dependencies'])
dependency_root = capture_root / 'dependencies'
rows = []
for directory, directories, files in os.walk(dependency_root, followlinks=False):
    for name in sorted(directories + files):
        path = Path(directory) / name
        mode = path.lstat().st_mode
        row = {'path': path.relative_to(dependency_root).as_posix()}
        if stat.S_ISLNK(mode):
            row.update(kind='symlink', target=os.readlink(path))
        elif stat.S_ISDIR(mode):
            row.update(kind='directory')
        else:
            assert stat.S_ISREG(mode), 'Unexpected non-regular capture entry'
            raw = path.read_bytes()
            row.update(kind='file', sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), executable=bool(mode & 0o111))
        rows.append(row)
rows.sort(key=lambda row: row['path'])
validate_dependencies(expected, rows)
tree_sha = hashlib.sha256(json.dumps(rows, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
assert tree_sha == manifest['dependencyTreeSha256']
result = {
    'kind': 'ordinary-read-only-unmodified-capture-metadata-comparison',
    'captureManifestSha256': manifest_sha, 'dependencyTreeSha256': tree_sha,
    'entries': len(rows), 'files': sum(row['kind'] == 'file' for row in rows),
    'directories': sum(row['kind'] == 'directory' for row in rows),
    'aliases': sum(row['kind'] == 'symlink' for row in rows),
    'bytes': sum(row.get('bytes', 0) for row in rows),
    'fieldsCompared': ['path', 'kind', 'target', 'sha256', 'bytes', 'executable'],
    'result': 'exact-match', 'nativeProgramsExecuted': False,
    'capturedInputFilesWritten': False, 'doesNotAssertSourceAOrQaAcceptance': True,
}
(ROOT / 'unmodified-manifest-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
