# SPDX-License-Identifier: Apache-2.0
"""Only pure value/metadata unit cases; no process, file output or namespace run."""
import copy
from dataclasses import FrozenInstanceError
import json
import unittest
from namespace_records import dependency_records, validate_dependencies, SealedReceipt


class DependencyMetadataTests(unittest.TestCase):
    def setUp(self):
        self.rows = [
            {'path': 'pkg', 'kind': 'directory'},
            {'path': 'pkg/data.txt', 'kind': 'file', 'sha256': 'a' * 64, 'bytes': 3, 'executable': False},
            {'path': '.bin/pkg', 'kind': 'symlink', 'target': '../pkg/tool'},
        ]
        self.expected = dependency_records(self.rows)

    def test_exact_value_match_ignores_inventory_order(self):
        validate_dependencies(self.expected, list(reversed(copy.deepcopy(self.rows))))
        self.assertEqual(self.expected, dependency_records(copy.deepcopy(self.rows)))

    def test_missing_metadata_is_never_a_default(self):
        for field in ['sha256', 'bytes', 'executable']:
            with self.subTest(field=field):
                rows = copy.deepcopy(self.rows)
                del rows[1][field]
                with self.assertRaises(ValueError):
                    validate_dependencies(self.expected, rows)

    def test_different_metadata_is_rejected(self):
        for field, value in [('sha256', 'b' * 64), ('bytes', 4), ('executable', True)]:
            with self.subTest(field=field):
                rows = copy.deepcopy(self.rows)
                rows[1][field] = value
                with self.assertRaises(ValueError):
                    validate_dependencies(self.expected, rows)

    def test_wrong_types_and_alias_values_are_rejected(self):
        for field, value in [('sha256', None), ('bytes', True), ('executable', 0)]:
            rows = copy.deepcopy(self.rows)
            rows[1][field] = value
            with self.assertRaises(ValueError):
                validate_dependencies(self.expected, rows)
        rows = copy.deepcopy(self.rows)
        rows[2]['target'] = '../pkg/other'
        with self.assertRaises(ValueError):
            validate_dependencies(self.expected, rows)

    def test_membership_duplicates_and_unexpected_fields_are_rejected(self):
        for rows in [self.rows[:-1], self.rows + [self.rows[1]], self.rows + [{'path': 'extra', 'kind': 'directory'}]]:
            with self.assertRaises(ValueError):
                validate_dependencies(self.expected, rows)
        rows = copy.deepcopy(self.rows)
        rows[1]['timestamp'] = 1
        with self.assertRaises(ValueError):
            validate_dependencies(self.expected, rows)

    def test_fixed_records_do_not_follow_mutable_input(self):
        self.rows[1]['bytes'] = 4
        self.assertEqual(next(row.bytes for row in self.expected if row.kind == 'file'), 3)
        with self.assertRaises(FrozenInstanceError):
            self.expected[0].path = 'other'


class ImmutableReceiptTests(unittest.TestCase):
    def setUp(self):
        self.rows = {'/fixture/report.json': {
            'physical': '/fixture/report.json', 'sha256': 'a' * 64, 'bytes': 3, 'inode': 2, 'device': 1,
        }}
        self.receipt = SealedReceipt('original', 'unit-run', self.rows, 'b' * 64, 'c' * 64)

    def test_top_level_metadata_is_immutable(self):
        for field, value in [('role', 'candidate'), ('run_id', 'other'), ('writer_trace', 'd' * 64), ('view_signature', 'd' * 64), ('slots', {})]:
            with self.subTest(field=field), self.assertRaises(FrozenInstanceError):
                setattr(self.receipt, field, value)

    def test_nested_records_and_outer_mapping_are_immutable(self):
        with self.assertRaises(TypeError):
            self.receipt.slots['/fixture/report.json']['bytes'] = 4
        with self.assertRaises(TypeError):
            self.receipt.slots['/fixture/extra.json'] = {}

    def test_original_input_and_json_exports_are_detached(self):
        self.rows['/fixture/report.json']['bytes'] = 4
        exported = self.receipt.slot_records()
        exported['/fixture/report.json']['bytes'] = 5
        self.assertEqual(self.receipt.slots['/fixture/report.json']['bytes'], 3)
        self.assertEqual(json.loads(json.dumps(self.receipt.slot_records()))['/fixture/report.json']['bytes'], 3)

    def test_value_equality_roundtrip(self):
        other = SealedReceipt('original', 'unit-run', self.receipt.slot_records(), 'b' * 64, 'c' * 64)
        self.assertEqual(self.receipt, other)
        self.assertIsNot(self.receipt.slots, other.slots)

    def test_missing_and_invalid_metadata_is_rejected(self):
        for field in ['physical', 'sha256', 'bytes', 'inode', 'device']:
            rows = copy.deepcopy(self.rows)
            del rows['/fixture/report.json'][field]
            with self.assertRaises(ValueError):
                SealedReceipt('original', 'unit-run', rows, 'b' * 64, 'c' * 64)


if __name__ == '__main__':
    unittest.main(verbosity=2)
