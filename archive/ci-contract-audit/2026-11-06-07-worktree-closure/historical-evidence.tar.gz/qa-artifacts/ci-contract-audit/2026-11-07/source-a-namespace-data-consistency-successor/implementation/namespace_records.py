# SPDX-License-Identifier: Apache-2.0
"""Pure immutable values for the existing private namespace controller."""
from collections.abc import Mapping
from dataclasses import dataclass
import re
from types import MappingProxyType


def _require(value, message):
    if not value:
        raise ValueError(message)


def _sha(value):
    return isinstance(value, str) and re.fullmatch('[a-f0-9]{64}', value) is not None


@dataclass(frozen=True, slots=True)
class DependencyRecord:
    path: str
    kind: str
    sha256: str | None = None
    bytes: int = 0
    executable: bool = False
    target: str | None = None


def dependency_records(rows):
    """Require every declared field; missing metadata is never a default match."""
    records = {}
    for row in rows:
        _require(isinstance(row, Mapping), 'Dependency row must be a record')
        path, kind = row.get('path'), row.get('kind')
        _require(isinstance(path, str) and path and path not in records, 'Missing/duplicate dependency path')
        _require(kind in ('directory', 'file', 'symlink'), 'Invalid dependency kind: ' + path)
        keys = {'path', 'kind'} | ({'sha256', 'bytes', 'executable'} if kind == 'file' else {'target'} if kind == 'symlink' else set())
        _require(set(row) == keys, 'Missing/unexpected dependency metadata: ' + path)
        if kind == 'file':
            _require(_sha(row['sha256']) and type(row['bytes']) is int and row['bytes'] >= 0
                     and type(row['executable']) is bool, 'Invalid dependency file metadata: ' + path)
        if kind == 'symlink':
            _require(isinstance(row['target'], str) and row['target'], 'Invalid dependency alias metadata: ' + path)
        records[path] = DependencyRecord(**row)
    return tuple(records[path] for path in sorted(records))


def validate_dependencies(expected, observed_rows):
    """Compare observations to independently fixed immutable manifest records."""
    observed = dependency_records(observed_rows)
    _require(observed == expected, 'Dependency records differ from fixed manifest (membership/kind/alias/SHA/bytes/executable)')


@dataclass(frozen=True, slots=True)
class SealedReceipt:
    role: str
    run_id: str
    slots: object
    writer_trace: str
    view_signature: str

    def __post_init__(self):
        _require(isinstance(self.role, str) and self.role and isinstance(self.run_id, str) and self.run_id,
                 'Output receipt needs role and writer run')
        _require(_sha(self.writer_trace) and _sha(self.view_signature), 'Output receipt needs exact trace and input frame')
        _require(isinstance(self.slots, Mapping), 'Output slots must be a record')
        frozen = {}
        for path, row in self.slots.items():
            _require(isinstance(path, str) and path and isinstance(row, Mapping) and set(row) == {'physical', 'sha256', 'bytes', 'inode', 'device'},
                     'Incomplete output slot record')
            _require(isinstance(row['physical'], str) and row['physical'] and _sha(row['sha256'])
                     and all(type(row[k]) is int and row[k] >= 0 for k in ('bytes', 'inode', 'device')),
                     'Invalid output slot metadata')
            frozen[path] = MappingProxyType(dict(row))
        object.__setattr__(self, 'slots', MappingProxyType(frozen))

    def slot_records(self):
        """Detached JSON export; exported values never become authority again."""
        return {path: dict(row) for path, row in self.slots.items()}
