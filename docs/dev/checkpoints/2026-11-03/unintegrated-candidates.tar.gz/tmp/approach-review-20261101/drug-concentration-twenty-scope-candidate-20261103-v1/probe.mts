import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { collectMathAtomicSupportContext } from '/home/enpasos/projects/skillpilot/app/scripts/mathStageScopePolicy.ts'
import { collectCompositionProjectionRoleGoalIds } from '/home/enpasos/projects/skillpilot/app/src/utils/authoring/compositionViewAuthoring.ts'
const R='/home/enpasos/projects/skillpilot', H=resolve(R,'tmp/approach-review-20261101/drug-concentration-twenty-scope-candidate-20261103-v1')
const canonPath='curricula/DE/Gymnasium/canonical', viewPath='curricula/DE/Gymnasium/composition-views/mathematik'
const goals=new Map<string,any>()
for(const p of readdirSync(resolve(R,canonPath)).filter(p=>p.endsWith('.de.json')).sort()) for(const g of JSON.parse(readFileSync(resolve(R,canonPath,p),'utf8')).goals) goals.set(g.id,g)
const TASK='5d3fd2c4-7c7e-569e-ae02-75486573f3cc', prep=collectMathAtomicSupportContext([TASK],goals)
console.log(JSON.stringify(prep,null,2))
const facts:any[]=[]
for(const c of ['ni','nw','sl','sn','st']) for(const suf of ['lk','sekii-lk']) {
 const p=`${viewPath}/de-${c}-${suf}.view.json`, v=JSON.parse(readFileSync(resolve(R,p),'utf8')),roles=collectCompositionProjectionRoleGoalIds(v.rootNodes,goals)
 const matches=(id:string,ns:any[]=v.rootNodes,path:any[]=[]):any[]=>ns.flatMap(n=>n.kind==='structure'?matches(id,n.children,[...path,{id:n.id,label:n.label}]):n.goalId===id?[{path,node:n}]:[])
 facts.push({path:p,viewId:v.viewId,taskPresent:roles.targetGoalIds.has(TASK),prepInTarget:prep.supportUnionGoalIds.filter(id=>roles.targetGoalIds.has(id)),prepPOnly:prep.supportUnionGoalIds.filter(id=>roles.prerequisiteOnlyGoalIds.has(id)),prepNotExplicit:prep.supportUnionGoalIds.filter(id=>!roles.targetGoalIds.has(id)&&!roles.prerequisiteOnlyGoalIds.has(id)),special:['0e8417d7-effb-5314-93ba-a571b01726ce','f4935b24-d8a9-5eb7-a5eb-6d34a9e09b2d','49f9059a-876c-5051-8146-d008b5cc691c'].map(id=>({id,matches:matches(id)}))})
}
writeFileSync(resolve(H,'probe-result.json'),JSON.stringify({prep,wholeObjects:[TASK,...prep.supportUnionGoalIds].map(id=>goals.get(id)),views:facts},null,2)+'\n')
for(const f of facts) console.log(JSON.stringify({...f,prepInTarget:f.prepInTarget.length,prepPOnly:f.prepPOnly.length},null,2))
console.log('WHOLE_PREPARATION_CONTRACTS')
for(const id of prep.supportUnionGoalIds){const g=goals.get(id);console.log(JSON.stringify({id,title:g.title,description:g.description,requires:g.requires,examData:g.examData,nodeKind:g.nodeKind,phase:g.phase??g.dimensionTags?.phase,sourceRef:g.sourceRef}))}
