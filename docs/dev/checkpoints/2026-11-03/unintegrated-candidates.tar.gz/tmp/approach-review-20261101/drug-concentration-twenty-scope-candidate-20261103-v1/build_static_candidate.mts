import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync, lstatSync, realpathSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
import { collectMathAtomicSupportContext, collectKnownMathSupportContext, applyMathAssessmentScopeOperations } from '/home/enpasos/projects/skillpilot/app/scripts/mathStageScopePolicy.ts'
import { collectCompositionProjectionRoleGoalIds, compileCompositionView } from '/home/enpasos/projects/skillpilot/app/src/utils/authoring/compositionViewAuthoring.ts'
import { normalizeCanonicalLandscape } from '/home/enpasos/projects/skillpilot/app/src/utils/authoring/canonicalAuthoring.ts'

const ROOT='/home/enpasos/projects/skillpilot'
const HERE=resolve(ROOT,'tmp/approach-review-20261101/drug-concentration-twenty-scope-candidate-20261103-v1')
const OUT=resolve(HERE,'candidate-v1')
assert(!existsSync(OUT),'separate new private candidate required')
const TASK='5d3fd2c4-7c7e-569e-ae02-75486573f3cc', MATH='68a8ac50-f5f5-4e24-8aa9-5e408ca01ced'
const CAN='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
const POL='app/scripts/config/math-country-seki-stage-policy.json'
const VIEWS='curricula/DE/Gymnasium/composition-views/mathematik'
const AUTHOR='curricula/DE/Gymnasium/quality/source-scope-review/mathematik/2026-11-03/drug-concentration-twenty/author-source-and-exact-operations.json'
const PRIORITY='tmp/approach-review-20261101/astra-remaining-math-three-groups-priority-20261103-v1/priority-decision.json'
const COMPACT='tmp/approach-review-20261101/next-existing-route-triage-v30-20261103-v1/v30-compact-native-scope-facts.json'
const sha=(bytes:string|Buffer)=>createHash('sha256').update(bytes).digest('hex')
const stable=(value:any):any=>Array.isArray(value)?value.map(stable):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).sort(([a],[b])=>a<b?-1:a>b?1:0).map(([k,v])=>[k,stable(v)])):value
const objectHash=(value:any)=>sha(JSON.stringify(stable(value)))
const text=(v:any)=>JSON.stringify(v,null,2)+'\n'
const sort=(x:Iterable<string>)=>[...new Set(x)].sort()
const pins:Record<string,{sha256:string,bytes:number}>={}, before=new Map<string,Buffer>()
const bytes=(p:string)=>{const b=readFileSync(resolve(ROOT,p));pins[p]={sha256:sha(b),bytes:b.length};before.set(p,b);return b}
const read=(p:string)=>JSON.parse(bytes(p).toString('utf8'))
const write=(p:string,b:Buffer|string)=>{
 const target=resolve(OUT,p);assert(target.startsWith(OUT+'/'));mkdirSync(dirname(target),{recursive:true})
 for(let parent=dirname(target);parent!==dirname(OUT);parent=dirname(parent)){assert(!lstatSync(parent).isSymbolicLink()&&realpathSync(parent)===parent);if(parent===OUT)break}
 assert(!existsSync(target));writeFileSync(target,b,{flag:'wx'});assert(lstatSync(target).nlink===1)
}
const priority=read(PRIORITY);assert.equal(pins[PRIORITY].sha256,'a720d1ca3ff341563c663db28c4080cdd9c96baea5297f6f8b9aaa205529c659')
bytes('tmp/approach-review-20261101/astra-remaining-math-three-groups-priority-20261103-v1/review.md')
const canon=read(CAN);assert.equal(pins[CAN].sha256,'5f23d314ed1b31caae2e5994921c5fa2599ca7e7f718a5b9fc9d61334713bf37')
assert.equal(canon.goals.length,1265)
const goals=new Map<string,any>(),landscapes=new Map<string,any>()
for(const name of readdirSync(resolve(ROOT,'curricula/DE/Gymnasium/canonical')).filter(p=>p.endsWith('.de.json')).sort()){
 const src=read(`curricula/DE/Gymnasium/canonical/${name}`);landscapes.set(src.landscapeId,normalizeCanonicalLandscape(src))
 for(const g of src.goals){assert(!goals.has(g.id));goals.set(g.id,g)}
}
const task=goals.get(TASK),support=collectMathAtomicSupportContext([TASK],goals)
assert.equal(support.supportUnionGoalIds.length,77)
const priorTask=priority.wholeTasksRead.find((x:any)=>x.id===TASK)
assert.deepEqual(task.requires,priorTask.directRequires)
assert.equal(objectHash(task),priorTask.wholeGoalSnapshotSha256)
assert.deepEqual(task.examData.coveredGoalIds??[],[])
assert.equal(task.examData.scoring.maxPoints,30);assert.equal(task.examData.scoring.passingPoints,15)
assert.equal(support.tasks[0].effectiveDirectPrerequisiteIds.length,4)
const policy=read(POL),allViews=new Map<string,any>(),paths=new Map<string,string>()
for(const name of readdirSync(resolve(ROOT,VIEWS)).filter(p=>p.endsWith('.view.json')).sort()){
 const p=`${VIEWS}/${name}`,v=read(p);assert(!allViews.has(v.viewId));allViews.set(v.viewId,v);paths.set(v.viewId,p)
}
assert.equal(allViews.size,108)
for(const p of ['app/scripts/mathStageScopePolicy.ts','app/src/utils/authoring/compositionViewAuthoring.ts','app/src/utils/authoring/canonicalAuthoring.ts','app/scripts/generateMathCountrySekICompositionViews.ts','app/scripts/generateMathDurationCompositionViews.ts','AGENTS.md'])bytes(p)
const sourceCases:any[]=[]
const pageReads:Record<string,number[]>={NI:[48,49,52],NW:[27,28],SL:[9,13,19,20,38,39,40,41],SN:[18,52,54],ST:[64,65,66]}
for(const country of ['NI','NW','SL','SN','ST']){
 const base=`curricula/DE/Gymnasium/input/${country}/upper-secondary/source-extraction`
 const p=`${base}/${readdirSync(resolve(ROOT,base)).find(p=>p.includes('MATHEMATIK')&&p.endsWith('.json'))}`
 const extraction=read(p)
 const doc=country==='SL'?extraction.sourceDocuments.find((d:any)=>d.key==='SL_GOS_MATHEMATIK_LK_2019'):extraction.sourceDocuments[0]
 bytes(doc.path)
 sourceCases.push({jurisdiction:`DE-${country}`,sourceExtraction:{path:p,...pins[p]},primaryDocument:{path:doc.path,...pins[doc.path]},pdfPagesRead:pageReads[country],
   officialCorridor:country==='NI'?'eA: PDF/printed48 improper integrals and verification of antiderivatives;49 exponential/polynomial combinations and asymptotic behaviour;52 parameter families near the end of qualification. Extraction47/48 must not replace the actual48/49 locators.'
     :country==='NW'?'LK: printed27 parameter-dependent exponential/polynomial functions, product/chain rules and context interpretation;28(19),(22),(23) given antiderivatives, improper integrals and composed-function applications.'
     :country==='SL'?'LK: printed13 families and parameters;19 improper integrals including definition gaps;38-40 exponential functions, growth comparison, parameter-dependent composites and unbounded areas. The exponential module belongs to the third/fourth main-phase semester (printed9).'
     :country==='SN'?'LK11/12 printed40 (PDF52) differential analysis; printed42 (PDF54) regular integral calculus and CAS for composed functions. No explicit improper-integral contract was found in this read corridor.'
     :'eA printed62-64 (PDF64-66): limits, derivative analysis, families and regular integrals of composed functions; no explicit improper-integral contract in this read corridor.',
   disposition:['NI','NW','SL'].includes(country)?'GROUP_A_OWN_INTEGRATIVE_EXTENSION_PROPOSAL_REQUIRES_COUNTER_REVIEW':'GROUP_B_SEPARATELY_DECIDABLE_OWN_LATE_LK_EXTENSION_PROPOSAL_OFFICIAL_SOURCE_HOLD',
   sourceLimits:country==='SL'?['Partial integration is expressly facultative on printed20. This task does not prescribe a method; no mandatory mastery of that separate whole method is claimed. The given solution and all existing preparation remain unchanged.']
     :country==='NI'||country==='NW'?['The whole preparation f493 includes singularities; its full normative source coverage is not newly approved from a generic improper-integral bullet. The existing target stays unchanged; this candidate is an own integrative assessment label, not an official-exam or full-source PASS.']
     :['A broad current applicability cache and membership in the existing target are not sufficient source evidence. The proposal explicitly selects an own late LK extension after the actual offered regular calculus corridor; official improper-integral coverage remains HOLD, and the independent counter-review may retain the whole8-context group on HOLD.'],
   ownAcquisitionDecision:['SN','ST'].includes(country)?'The whole existing77-atom environment is retained. The mathematical extension uses the already-authored full improper-integral and exponential-asymptotic competencies, then integrates limits, an exponential/polynomial family and total exposure in one meaningful application. Its location is after the actual offered integral corridor in the late function-family section, with no invented school-year assignment. It introduces neither another integration-method prerequisite nor an official curriculum claim.':null})
}
const scopes=read(COMPACT);assert.equal(pins[COMPACT].sha256,'8bba77e313f372a5cedb8da4e9b4a1a973976eb30a1a15c705a44061638095b3')
assert.equal(scopes.length,161)
const role=(v:any)=>collectCompositionProjectionRoleGoalIds(v.rootNodes,goals)
const atomic=(set:Iterable<string>)=>sort([...set].filter(id=>!goals.get(id)?.contains?.length))
const pcViews=(row:any)=>row.compositionViewIds.flatMap((id:string)=>id.startsWith('merged:')?id.slice(7).split('+'):[id])
const pcRoles=(row:any,views:Map<string,any>)=>{
 const rs=pcViews(row).map((id:string)=>{assert(views.has(id),id);return role(views.get(id))})
 const target=atomic(rs.flatMap((r:any)=>[...r.targetGoalIds])),T=new Set(target)
 return {targetGoalIds:target,prerequisiteOnlyGoalIds:atomic(rs.flatMap((r:any)=>[...r.prerequisiteOnlyGoalIds])).filter(id=>!T.has(id))}
}
// The authoring role collector expands raw authored subtrees. It does not apply
// native applicability filtering, so preserve both whole sets and never pass
// off the authoring union as a fresh backend Personal Curriculum resolution.
const roleVersusNativeBaseline=scopes.map((row:any)=>{
 const actual=pcRoles(row,allViews).targetGoalIds,native=new Set<string>(row.targets),A=new Set(actual)
 return {scope:row.scope,authoringOnlyTargetGoalIds:actual.filter(id=>!native.has(id)),nativeOnlyTargetGoalIds:row.targets.filter((id:string)=>!A.has(id))}
})
assert.equal(scopes.filter((r:any)=>r.targets.includes(TASK)).length,32)
const twenty=scopes.filter((r:any)=>['DE-NI','DE-NW','DE-SL','DE-SN','DE-ST'].includes(r.scope.split('/')[0])&&['SekII','CrossStage'].includes(r.scope.split('/')[1])&&['LK','GK+LK'].includes(r.scope.split('/')[3]))
assert.equal(twenty.length,20)
const selected=new Set(twenty.map((r:any)=>r.scope))
const groupA=twenty.filter((r:any)=>['DE-NI','DE-NW','DE-SL'].includes(r.scope.split('/')[0])).map((r:any)=>r.scope)
const groupB=twenty.filter((r:any)=>['DE-SN','DE-ST'].includes(r.scope.split('/')[0])).map((r:any)=>r.scope)
const operations:any[]=[],afterViews=new Map(allViews),viewFacts:any[]=[]
for(const country of ['ni','nw','sl','sn','st'])for(const suffix of ['lk','sekii-lk']){
 const path=`${VIEWS}/de-${country}-${suffix}.view.json`,v=JSON.parse(before.get(path)!.toString('utf8'))
 const anchor=country==='nw'?'nw-q-phase-advanced-topics-lk':'function-families'
 const isOwnLate=['sn','st'].includes(country)
 const op={id:`own-drug-concentration-${v.viewId}`,viewId:v.viewId,goalIds:[TASK],action:'include-target',anchorStructureId:anchor,
   label:isOwnLate?'Eigene späte LK-Vertiefung (SkillPilot): Wirkstoffkonzentration und uneigentliche AUC':'Zusätzliche vertiefende Prüfung (SkillPilot): Wirkstoffkonzentration, Wendestelle und uneigentliche AUC',
   sourceDecision:`${AUTHOR}#${isOwnLate?'snStEightOwnExtensionProposedScopes':'niNwSlTwelveProposedScopes'}`}
 const authoredStructureOrder:string[]=[]
 const ordered=(ns:any[]):void=>{for(const n of ns)if(n.kind==='structure'){authoredStructureOrder.push(n.id);ordered(n.children)}}
 ordered(v.rootNodes)
 const integralAnchor=country==='nw'?'nw-q-phase-functions-analysis-lk':'integral-and-differential'
 assert(authoredStructureOrder.indexOf(integralAnchor)>=0&&authoredStructureOrder.indexOf(anchor)>authoredStructureOrder.indexOf(integralAnchor),'actual late anchor follows offered integral corridor')
 const next=applyMathAssessmentScopeOperations(v,goals,[op]),a=role(v),b=role(next)
 assert.deepEqual(applyMathAssessmentScopeOperations(next,goals,[op]),next,'idempotent normal operation')
 assert.deepEqual(sort([...b.targetGoalIds].filter(id=>!a.targetGoalIds.has(id))),[TASK]);assert.deepEqual(sort([...a.targetGoalIds].filter(id=>!b.targetGoalIds.has(id))),[])
 assert.deepEqual(sort(a.prerequisiteOnlyGoalIds),sort(b.prerequisiteOnlyGoalIds))
 const preview=compileCompositionView(next,normalizeCanonicalLandscape(canon),normalizeCanonicalLandscape({...canon,goals:[...goals.values()]}),landscapes)
 const fatal=preview.findings.filter((d:any)=>['CPV-004','CPV-005','CPV-006','CPV-007','CPV-009'].includes(d.code))
 assert.deepEqual(fatal,[],'no fatal productive static composition diagnostics')
 operations.push(op);afterViews.set(v.viewId,next)
 viewFacts.push({path,viewId:v.viewId,operation:op,operationGroup:isOwnLate?'B_SN_ST_OWN_LATE_LK_8':'A_NI_NW_SL_12',actualAcquisitionAnchors:{integralAnchor,lateAssessmentAnchor:anchor,lateAnchorFollowsIntegralCorridor:true},beforeWholeTargetGoalIds:sort(a.targetGoalIds),afterWholeTargetGoalIds:sort(b.targetGoalIds),beforeWholePrerequisiteOnlyGoalIds:sort(a.prerequisiteOnlyGoalIds),afterWholePrerequisiteOnlyGoalIds:sort(b.prerequisiteOnlyGoalIds),staticCompilerFindingCodes:sort(preview.findings.map((x:any)=>x.code))})
}
const contextFacts=twenty.map((row:any)=>{
 const beforeRoles=pcRoles(row,allViews),afterRoles=pcRoles(row,afterViews),beforeT=new Set(beforeRoles.targetGoalIds),afterT=new Set(afterRoles.targetGoalIds)
 const known=collectKnownMathSupportContext(beforeRoles.targetGoalIds,goals)
 assert(support.supportUnionGoalIds.every(id=>known.has(id)),'whole preparation freshly present before task selection')
 assert(support.supportUnionGoalIds.every(id=>row.context.includes(id)),'matches bounded old native context')
 assert(!beforeT.has(TASK));assert.equal(afterT.has(TASK),selected.has(row.scope))
 const outsideT=support.supportUnionGoalIds.filter(id=>!beforeT.has(id))
 assert.equal(outsideT.length,row.scope.includes('/CrossStage/')?0:44)
 return {scope:row.scope,compositionViewIds:row.compositionViewIds,decision:groupB.includes(row.scope)?'GROUP_B_OWN_LATE_LK_AUTHOR_PROPOSAL_PENDING_SEPARATE_COUNTER_REVIEW_OFFICIAL_SOURCE_HOLD':'GROUP_A_OWN_INTEGRATIVE_AUTHOR_PROPOSAL_PENDING_COUNTER_REVIEW',
   beforeWholeAuthoredTargetGoalIds:beforeRoles.targetGoalIds,afterWholeAuthoredTargetGoalIdsStaticPrediction:afterRoles.targetGoalIds,
   beforeWholeNativeBaselineTargetGoalIds:row.targets,afterWholeNativeTargetGoalIdsStaticPrediction:sort([...row.targets,TASK]),
   beforeWholePrerequisiteOnlyGoalIds:beforeRoles.prerequisiteOnlyGoalIds,afterWholePrerequisiteOnlyGoalIdsStaticPrediction:afterRoles.prerequisiteOnlyGoalIds,
   directAndEffectivePreparationUnchanged:support,earlierAcquisitionBasisOutsideTarget:outsideT,
   earlierBasisContracts:outsideT.map(id=>({id,title:goals.get(id).title,phase:goals.get(id).phase??goals.get(id).dimensionTags?.phase})),
   acquisitionDecision:'Earlier arithmetic, algebra and graph literacy remain context support; the33 upper-secondary contracts stay current targets. The new own integrative task is appended to the late family/advanced-analysis corridor after the existing calculus content. No legacyQ4 absolute year inference and no foundation promotion.',
   nativeBaselineVersusRawAuthoringRoles:roleVersusNativeBaseline.find((x:any)=>x.scope===row.scope),actualRuntimeEligibilityNeededOrFocusReceipt:false}
})
const negativeFacts=scopes.filter((r:any)=>!selected.has(r.scope)).map((row:any)=>{
 const a=pcRoles(row,allViews),b=pcRoles(row,afterViews);assert.deepEqual(a,b,'every negative whole target/explicit role set unchanged')
 return {scope:row.scope,compositionViewIds:row.compositionViewIds,rawAuthoredTaskTargetBefore:a.targetGoalIds.includes(TASK),rawAuthoredTaskTargetAfter:b.targetGoalIds.includes(TASK),nativeBaselineTaskTargetBefore:row.targets.includes(TASK),nativeTaskTargetAfterStaticPrediction:row.targets.includes(TASK),disposition:row.targets.includes(TASK)?'EXISTING_SELECTION_PRESERVED_NOT_REAPPROVED':'NEGATIVE_NO_NEW_SELECTION'}
})
assert.equal(negativeFacts.length,141);assert.equal(negativeFacts.filter((x:any)=>x.nativeBaselineTaskTargetBefore).length,32)
const author={schemaVersion:1,status:'PRIVATE_AUTHOR_PROPOSAL_REQUIRES_INDEPENDENT_COUNTER_REVIEW',kind:'bounded-existing-whole-assessment-scope-proposal',taskGoalId:TASK,
   baselineCanonical:{path:CAN,...pins[CAN]},priorityDecision:{path:PRIORITY,...pins[PRIORITY]},exactTwentyReviewedScopes:twenty.map((x:any)=>x.scope),niNwSlTwelveProposedScopes:sort(groupA),snStEightOwnExtensionProposedScopes:sort(groupB),operations,
   separatelyDecidableOperationGroups:[{id:'A_NI_NW_SL_12',status:'AUTHOR_PROPOSAL_REQUIRES_COUNTER_REVIEW',scopes:sort(groupA),operations:operations.filter(o=>!o.viewId.includes('-sn-')&&!o.viewId.includes('-st-'))},{id:'B_SN_ST_OWN_LATE_LK_8',status:'SEPARATE_AUTHOR_PROPOSAL_REQUIRES_COUNTER_REVIEW_OFFICIAL_SOURCE_HOLD',scopes:sort(groupB),operations:operations.filter(o=>o.viewId.includes('-sn-')||o.viewId.includes('-st-'))}],
   sourceCases,wholeTaskPreservation:{wholeTaskObjectSha256:sha(JSON.stringify(task)),wholeExamDataSha256:sha(JSON.stringify(task.examData)),rawRequires:task.requires,effectiveDirectPrerequisiteIds:support.tasks[0].effectiveDirectPrerequisiteIds,preparationAtomCount:77,coveredGoalIds:[],maxPoints:30,passingPoints:15,noCoverageAdded:true},
   ownCompetencyAndSourceLabel:'Zusätzliche vertiefende Prüfung (SkillPilot): Wirkstoffkonzentration, Wendestelle und uneigentliche AUC. This is the existing integrative competency/task identity; no second identity and no declaration of an official state exam.',
   scopeRationale:'One coherent parameter-dependent concentration model unites qualitative behaviour, maximum, inflection and convergent total exposure. Its actual calculus acquisition corridor and currently complete77-atom preparation justify a narrow own integrative assessment proposal, independently of endpoint counts. NI/NW/SL12 have an explicit improper-integral source corridor. The separate SN/ST8 proposal is an expressly own late LK extension, without an official claim or approved scope; counter-review may approve or HOLD it independently.',
   separateScoringMeaning:'The existing15/30 one-bit pass remains authoritative. Parts1-3 total19, so passing does not prove every AUC or improper-integral competence. No new scoredGoal or rubric guarantee is claimed.',
   holds:['All10 proposed view operations and the exact policy bytes still require independent review.','SN/ST8 official improper-integral source coverage remains HOLD. Its separately decidable own late LK extension group is not yet approved scope.','SL partial integration remains facultative; the existing solution uses it but the task and rubric prescribe no method. No mandatory partial-integration contract is created.','Full normative source coverage of the broad f493 singularity contract is not newly approved for NI/NW from generic bullets.','No Source21, source coverage, producer fixpoint, Stage, native161, runtime, M7 or human acceptance run.','No assessment-start class or JVM evidence is produced by this data-only proposal.'],
   jointIntegrationConflict:'The separate SH-cylinder private candidate also changes math-country-seki-stage-policy.json. Merge operations/bindings against one fresh base and obtain one later exact policy review; never copy one complete policy over the other. This candidate does not edit Canon or the duration layout.'}
const payload=new Map<string,Buffer>([[AUTHOR,Buffer.from(text(author))]])
for(const f of viewFacts)payload.set(f.path,Buffer.from(text(afterViews.get(f.viewId))))
policy.assessmentScopeOperations.push(...operations)
policy.stageDecisionBindings.push({path:AUTHOR,sha256:sha(payload.get(AUTHOR)!)})
const rebind=(value:any):void=>{if(!value||typeof value!=='object')return;if(typeof value.path==='string'&&typeof value.sha256==='string'&&payload.has(value.path))value.sha256=sha(payload.get(value.path)!);for(const x of Object.values(value))rebind(x)}
rebind(policy)
// Retain the old review receipt path as history; its hash cannot approve this new
// exact policy. No receipt is rewritten or manufactured.
payload.set(POL,Buffer.from(text(policy)))
for(const [path,b]of payload)write(`overlay/${path}`,b)
write('twenty-contexts-before-after.json',text(contextFacts));write('ten-views-before-after.json',text(viewFacts));write('negative141-contexts.json',text(negativeFacts))
write('whole-task-and-preparation.json',text({wholeTask:task,wholePreparationObjects:support.supportUnionGoalIds.map(id=>goals.get(id)),effectiveSupport:support}))
write('authoring-roles-versus-bounded-native-baseline.json',text({explanation:'Whole raw authoring roles and historical native161 target sets are different layers; no new native target resolution is claimed. Current canonical bytes match V30; every read current view is hash-bound.',scopes:roleVersusNativeBaseline}))
const manifest={status:'STATIC_AUTHOR_CANDIDATE_NOT_INDEPENDENTLY_APPROVED',changedLeafCount:payload.size,changedLeaves:[...payload].map(([path,b])=>({path,beforeSha256:before.has(path)?sha(before.get(path)!):null,afterSha256:sha(b),bytes:b.length})),inputBindings:Object.entries(pins).map(([path,v])=>({path,...v})),
   counts:{reviewedPcScopes:20,proposedNewPcScopes:20,groupAProposedPcScopes:12,separatelyDecidableOwnGroupBProposedPcScopes:8,officialSourceHoldPcScopes:8,existingSelectedPcScopes:32,predictedSelectedPcScopesIfBothGroupsApproved:52,negativeUnchangedPcScopes:141,changedViews:10,canonicalGoalsUnchanged:1265,wholePreparationAtomsUnchanged:77},
   checks:['V30 exact Canon and task object match using stable-key whole-object hash','fresh108 raw authoring roles compared with all161 bounded native baseline target sets without conflating applicability semantics','whole77-atom preparation recomputed from complete current canonical universe','20 whole before/after authoring target and explicit-role sets, plus complete bounded native baseline/predicted target sets','141 negative whole raw authoring target/explicit-role equality checks','10 real helper operations and idempotent replays','10 actual acquisition anchors after offered integral corridors','10 productive static composition previews without fatal structural findings','all actually read current input hashes rechecked after authoring'],
   noRootOrGitClassJVMSourceProducerNativeWrites:true,pending:'Concrete independent counter-review; then joint integration/rebinding and required unchanged gates.'}
for(const [p,v]of Object.entries(pins))assert.equal(sha(readFileSync(resolve(ROOT,p))),v.sha256,`input changed during static preparation ${p}`)
write('manifest.json',text(manifest));console.log(JSON.stringify({out:OUT,counts:manifest.counts,changedLeaves:manifest.changedLeaves.map(x=>x.path)}))
