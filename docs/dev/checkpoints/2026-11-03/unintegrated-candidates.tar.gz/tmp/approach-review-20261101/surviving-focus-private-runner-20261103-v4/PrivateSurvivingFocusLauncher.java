import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectMethod;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.xml.stream.XMLOutputFactory;
import org.junit.platform.engine.TestExecutionResult;
import org.junit.platform.engine.support.descriptor.ClassSource;
import org.junit.platform.engine.support.descriptor.MethodSource;
import org.junit.platform.launcher.TestExecutionListener;
import org.junit.platform.launcher.TestIdentifier;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;

/** A private launcher for the existing Platform API; no application or curriculum harness. */
public class PrivateSurvivingFocusLauncher {
    public static void main(String[] args) throws Exception {
        String[] suites = java.util.Arrays.copyOfRange(args, 4, args.length);
        if (suites.length == 0) throw new AssertionError("No finite whole suites selected");
        Path output = Path.of(args[0]);
        Files.createDirectories(output);
        var builder = LauncherDiscoveryRequestBuilder.request()
                .configurationParameter("junit.jupiter.execution.parallel.enabled", "false");
        for (String suite : suites) builder.selectors(selectClass(suite));
        var request = builder.build();
        var summary = new SummaryGeneratingListener();
        var records = new Records();
        var launcher = LauncherFactory.create();
        launcher.registerTestExecutionListeners(summary, records);
        List<String> origins = new ArrayList<>();
        Path expectedPrivateClasses = Path.of(args[1]).toAbsolutePath().normalize();
        Path expectedPrivateMain = Path.of(System.getProperty("skillpilot.focus.private.main.classes")).toAbsolutePath().normalize();
        Path expectedRootTest = Path.of(args[2]).toAbsolutePath().normalize();
        Path expectedRootMain = Path.of(args[3]).toAbsolutePath().normalize();
        List<String> privateTests = List.of("StoredCompositionFocusTest");
        for (String name : suites) {
            Path actual = Path.of(Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();
            Path expected = privateTests.stream().anyMatch(n -> name.endsWith("." + n)) ? expectedPrivateClasses : expectedRootTest;
            origins.add(name + " " + actual);
            if (!expected.equals(actual)) throw new AssertionError("Unexpected test origin: " + name + " " + actual);
        }
        for (String name : List.of("com.skillpilot.backend.service.LearnerService",
                "com.skillpilot.backend.completion.AssessmentTaskContract",
                "com.skillpilot.backend.completion.CompletionNavigationPolicy",
                "com.skillpilot.backend.completion.CompletionWorkflowState",
                "com.skillpilot.backend.service.LearnerService$GoalProjection",
                "com.skillpilot.backend.service.CompositionViewService",
                "com.skillpilot.backend.service.CompositionViewService$CompositionCanonicalFocusResolution")) {
            Path actual = Path.of(Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();
            origins.add(name + " " + actual);
            Path expected = name.startsWith("com.skillpilot.backend.service.LearnerService") ? expectedPrivateMain : expectedRootMain;
            if (!expected.equals(actual)) throw new AssertionError("Unexpected private/runtime dependency origin: " + name + " " + actual);
        }
        for (String name : List.of("com.skillpilot.backend.landscape.LearningGoal",
                "com.skillpilot.backend.service.LearnerLearningPlanService",
                "com.skillpilot.backend.completion.CompletionApplicationService")) {
            Path actual = Path.of(Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();
            origins.add(name + " " + actual);
            if (!expectedRootMain.equals(actual)) throw new AssertionError("Untouched dependency not from Root: " + name);
        }
        Path expectedResources = Path.of(System.getProperty("skillpilot.focus.fixture.resources")).toRealPath();
        for (String resource : List.of("de-sh-seki-g8.after.view.json", "de-sh-seki-g9.after.view.json", "sh-runtime-fixture-basis.json",
                "math-v30.before.de.json.gz", "overview-v30.de.json.gz",
                "de-sh-seki-g8.before.view.json.gz", "de-sh-seki-g9.before.view.json.gz", "sh-flow-source-closure.json.gz")) {
            var url = PrivateSurvivingFocusLauncher.class.getClassLoader().getResource("composition-focus-reparenting/" + resource);
            Path actual = url == null ? null : Path.of(url.toURI()).toRealPath();
            if (actual == null || !actual.equals(expectedResources.resolve("composition-focus-reparenting").resolve(resource)))
                throw new AssertionError("Unexpected frozen test resource: " + resource + " " + actual);
            origins.add(resource + " " + actual);
        }
        try (var input = Files.lines(Path.of(System.getProperty("skillpilot.focus.private.main.names")))) {
            for (String name : input.toList()) {
                Path actual = Path.of(Class.forName(name, false, PrivateSurvivingFocusLauncher.class.getClassLoader())
                        .getProtectionDomain().getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();
                if (!expectedPrivateMain.equals(actual)) throw new AssertionError("Main nested class origin changed: " + name);
                origins.add(name + " " + actual);
            }
        }
        Files.write(output.resolve("class-origins.txt"), origins);
        launcher.execute(request);
        var result = summary.getSummary();
        try (PrintWriter writer = new PrintWriter(Files.newBufferedWriter(output.resolve("summary.txt")))) {
            result.printTo(writer);
            result.printFailuresTo(writer);
        }
        result.printTo(new PrintWriter(System.out, true));
        result.printFailuresTo(new PrintWriter(System.out, true));
        records.write(output);
        String counts = "{\n  \"testsFound\": " + result.getTestsFoundCount()
                + ",\n  \"testsStarted\": " + result.getTestsStartedCount()
                + ",\n  \"testsSucceeded\": " + result.getTestsSucceededCount()
                + ",\n  \"testsFailed\": " + result.getTestsFailedCount()
                + ",\n  \"testsSkipped\": " + result.getTestsSkippedCount()
                + ",\n  \"testsAborted\": " + result.getTestsAbortedCount()
                + ",\n  \"containersFailed\": " + result.getContainersFailedCount() + "\n}\n";
        Files.writeString(output.resolve("summary-counts.json"), counts);
        // A cached Spring test context can keep non-daemon server threads alive.
        // Exit only after the full XML/text reports, using the real JUnit outcome.
        int exitCode = result.getTestsFoundCount() == 0 || result.getTestsStartedCount() != result.getTestsFoundCount() ? 2
                : result.getTestsFailedCount() > 0 || result.getTestsAbortedCount() > 0
                    || result.getContainersFailedCount() > 0 || result.getTestsSkippedCount() > 0 ? 1 : 0;
        System.exit(exitCode);
    }

    private static final class Records implements TestExecutionListener {
        private final Map<String, Long> started = new LinkedHashMap<>();
        private final List<Row> rows = new ArrayList<>();

        @Override
        public void executionStarted(TestIdentifier id) {
            if (id.isTest()) {
                started.put(id.getUniqueId(), System.nanoTime());
                System.out.println("TEST_STARTED " + id.getUniqueId());
                System.out.flush();
            }
        }

        @Override
        public void executionFinished(TestIdentifier id, TestExecutionResult result) {
            if (!id.isTest()) return;
            String trace = result.getThrowable().map(error -> {
                var text = new StringWriter();
                error.printStackTrace(new PrintWriter(text));
                return text.toString();
            }).orElse("");
            String cls = id.getSource().map(source -> source instanceof MethodSource method ? method.getClassName()
                    : source instanceof ClassSource type ? type.getClassName() : source.toString()).orElse("");
            double seconds = (System.nanoTime() - started.getOrDefault(id.getUniqueId(), System.nanoTime())) / 1e9;
            rows.add(new Row(id.getUniqueId(), id.getDisplayName(), cls, result.getStatus().name(), seconds, trace));
            System.out.println("TEST_FINISHED " + result.getStatus().name() + " " + id.getUniqueId() + " " + seconds + "s");
            System.out.flush();
        }

        @Override
        public void executionSkipped(TestIdentifier id, String reason) {
            if (id.isTest()) rows.add(new Row(id.getUniqueId(), id.getDisplayName(), "", "SKIPPED", 0, reason));
        }

        void write(Path output) throws Exception {
            try (PrintWriter text = new PrintWriter(Files.newBufferedWriter(output.resolve("all-test-results.txt")))) {
                for (Row row : rows) {
                    text.println(row.status + " " + row.id + " " + row.seconds + "s");
                    text.println(row.name);
                    if (!row.trace.isEmpty()) text.println(row.trace);
                }
            }
            try (var stream = Files.newOutputStream(output.resolve("junit.xml"))) {
                var xml = XMLOutputFactory.newFactory().createXMLStreamWriter(stream, "UTF-8");
                xml.writeStartDocument("UTF-8", "1.0");
                xml.writeStartElement("testsuite");
                xml.writeAttribute("name", "PrivateSurvivingFocus");
                xml.writeAttribute("timestamp", Instant.now().toString());
                xml.writeAttribute("tests", Integer.toString(rows.size()));
                xml.writeAttribute("failures", Long.toString(rows.stream().filter(row -> row.status.equals("FAILED")).count()));
                xml.writeAttribute("skipped", Long.toString(rows.stream().filter(row -> row.status.equals("SKIPPED") || row.status.equals("ABORTED")).count()));
                for (Row row : rows) {
                    xml.writeStartElement("testcase");
                    xml.writeAttribute("name", row.name);
                    xml.writeAttribute("classname", row.className);
                    xml.writeAttribute("time", Double.toString(row.seconds));
                    if (!row.status.equals("SUCCESSFUL")) {
                        xml.writeStartElement(row.status.equals("FAILED") ? "failure" : "skipped");
                        xml.writeCharacters(row.trace);
                        xml.writeEndElement();
                    }
                    xml.writeStartElement("system-out");
                    xml.writeCharacters(row.id);
                    xml.writeEndElement();
                    xml.writeEndElement();
                }
                xml.writeEndElement();
                xml.writeEndDocument();
                xml.close();
            }
        }
    }

    private record Row(String id, String name, String className, String status, double seconds, String trace) { }
}
