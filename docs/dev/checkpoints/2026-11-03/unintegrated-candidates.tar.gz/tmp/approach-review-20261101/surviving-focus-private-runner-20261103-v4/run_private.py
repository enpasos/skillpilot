"""Finite test-only V4 compilation and whole-suite validation; fixed Root 947+431 reused."""
from pathlib import Path
import argparse,fcntl,hashlib,json,subprocess,time
R=Path('/home/enpasos/projects/skillpilot')
H=Path(__file__).resolve().parent
B=R/'tmp/approach-review-20261101'
V4=B/'surviving-focus-runtime-test-successor-20261103-v4'
MAIN=B/'surviving-focus-runtime-candidate-20261103-v1/overlay/backend/src/main/java/com/skillpilot/backend/service/LearnerService.java'
TEST=V4/'overlay/backend/src/test/java/com/skillpilot/backend/service/StoredCompositionFocusTest.java'
RESOURCES=V4/'overlay/backend/src/test/resources'
REUSE=V4/'reused-private-main-class-hashes.json'
IMAP=B/'mcp-eight-root-import-x6xdeebc/current-input-hashes.json'
CMAP=B/'mcp-fixture-actual-root-20261103/actual-root/current-class-hashes.json'
JAVA=Path('/tmp/skillpilot-curriculum-ci-corretto-25.0.2.10.1/bin')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
pin=lambda p:dict(path=str(p.relative_to(R)),sha256=sha(p),bytes=p.stat().st_size)
write=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n')
parser=argparse.ArgumentParser()
parser.add_argument('--phase',choices=['prepare','compile','stored','boundaries'],default='prepare')
parser.add_argument('--run-name',default='private-run-r1')
parser.add_argument('--slot-authorization',default='')
args=parser.parse_args()
assert args.run_name.startswith('private-run-') and '/' not in args.run_name
O=H/args.run_name
CP=(H/'existing-root-classpath.txt').read_text().strip()
assert sha(IMAP)=='c2c9949ff8a8c95e6b5caff102df29e93b9f80e95dfdbd12fa5bc3146f123a8c'
assert sha(CMAP)=='302303e4aa9ae1a345824cafebee7ec5f28bbe9aef0f0602a6f37c8fb40bb6cd'
inputs,classes=read(IMAP),read(CMAP)
assert len(inputs)==9554 and len(classes)==1378
assert sum('/main/' in p for p in classes)==947 and sum('/test/' in p for p in classes)==431
assert sha(MAIN)=='afa77b6b4aee61e1354105f3ee5c1cd56167cdf9bb81fdb35535415bb3fd3132'
assert sha(TEST)=='9fec66097b3042690bd37b3962aee902138872c030e2174905a03df3dd8c4dc5'
assert sha(V4/'fixture-freeze-v4.json')=='82d27407871c1af23d97014e2a01dcd856bbc73492b80dc54e8a11abb0458681'
for row in read(V4/'fixture-freeze-v4.json')['files']:assert sha(R/row['path'])==row['sha256'],row['path']
reuse=read(REUSE)
PRIVATE_MAIN=R/reuse['classRoot']
assert len(reuse['classes'])==33
assert all(Path(p).exists() for p in CP.split(':'))
stored=['com.skillpilot.backend.service.StoredCompositionFocusTest']
boundaries=[
 'com.skillpilot.backend.completion.AssessmentTaskStartTest',
 'com.skillpilot.backend.service.AutomaticCompletionIntegrationTest',
 'com.skillpilot.backend.ai.CoachToolFacadeTest',
 'com.skillpilot.backend.service.CompositionBoundCanonicalFocusRegressionTest',
 'com.skillpilot.backend.service.ProjectionRoleLearnerServiceTest',
 'com.skillpilot.backend.service.srs.SrsPracticeStateGuardTest',
 'com.skillpilot.backend.service.SrsMasteryBatchQueryTest',
 'com.skillpilot.backend.service.AssessmentCompletionSrsIntegrationTest',
]
plan=dict(status='FINITE_V4_TEST_ONLY_RUNNER',
 compileSources=[pin(p) for p in [TEST,H/'PrivateSurvivingFocusLauncher.java']],
 runnerSources=[pin(H/'run_private.py'),pin(H/'reused-main-class-names.txt')],
 reusedMain=pin(REUSE),mainSource=pin(MAIN),resources=[pin(p) for p in sorted(RESOURCES.rglob('*')) if p.is_file()],
 inputMap=pin(IMAP),classMap=pin(CMAP),rootCounts=dict(inputs=9554,main=947,test=431),
 classpath=pin(H/'existing-root-classpath.txt'),storedWholeSuite=stored,boundaryWholeSuites=boundaries,
 noRootCompileMutationHostClone=True)
if args.phase=='prepare':
 assert not (H/'runner-ready.json').exists()
 write(H/'runner-ready.json',plan)
 print(json.dumps(dict(prepared=pin(H/'runner-ready.json'),javaStarted=False)),flush=True)
 raise SystemExit(0)
assert args.slot_authorization.strip(),'No parent execution authorization'
assert read(H/'runner-ready.json')==plan,'Runner changed after freeze'
lock=open(H/'one-jvm.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
if args.phase=='compile':
 O.mkdir(exist_ok=False);(O/'classes').mkdir();(O/'empty-sourcepath').mkdir()
 write(O/'authorization.json',dict(parentAuthorization=args.slot_authorization,staticV4ReviewReportedPass=True))
else:
 assert read(O/'compile.execution.json')['exitCode']==0
 if args.phase=='boundaries':
  proof=read(O/'stored/results/summary-counts.json')
  assert proof['testsFound']>0 and proof['testsFound']==proof['testsStarted']==proof['testsSucceeded']
  assert all(proof[k]==0 for k in ['testsFailed','testsSkipped','testsAborted','containersFailed'])
commands=[]
def guard():
 for rel,digest in inputs.items():assert sha(R/rel)==digest,rel
 actual={str(p.relative_to(R)):sha(p) for kind in ['main','test']
         for p in (R/'backend/build/classes/java'/kind).rglob('*.class')}
 assert actual==classes,'Root947/431 class drift'
 for row in plan['compileSources']+plan['runnerSources']+plan['resources']+[plan['mainSource'],plan['reusedMain']]:
  assert sha(R/row['path'])==row['sha256'],row['path']
 for name,digest in reuse['classes'].items():assert sha(PRIVATE_MAIN/name)==digest,name
 if (O/'private-test-class-hashes.json').exists():
  assert {str(p.relative_to(O/'classes')):sha(p) for p in (O/'classes').rglob('*.class')}==read(O/'private-test-class-hashes.json')
def run(name,argv):
 guard();target=O if name=='compile' else O/name
 if target!=O:target.mkdir(exist_ok=False)
 assert not (O/(name+'.started.json')).exists(),'Preserve all terminal attempts'
 log=O/(name+'.log')
 started=time.monotonic()
 with log.open('xb',buffering=0) as output:
  process=subprocess.Popen([str(a) for a in argv],cwd=R/'backend',stdout=output,stderr=subprocess.STDOUT)
  write(O/(name+'.started.json'),dict(pid=process.pid,argv=[str(a) for a in argv],output='Authentic process stdout+stderr only; no pipe writes'))
  print(json.dumps(dict(started=name,pid=process.pid,log=str(log))),flush=True)
  code=process.wait()
 row=dict(name=name,exitCode=code,seconds=round(time.monotonic()-started,2),log=pin(log))
 write(O/(name+'.execution.json'),row);commands.append(row);guard();print(json.dumps(row),flush=True)
 return code
guard()
if args.phase=='compile':
 code=run('compile',[JAVA/'javac','-J-Xmx1800m','-encoding','UTF-8','-implicit:none','-sourcepath',O/'empty-sourcepath',
  '-cp',str(PRIVATE_MAIN)+':'+CP,'-d',O/'classes',TEST,H/'PrivateSurvivingFocusLauncher.java'])
 if code==0:
  private={str(p.relative_to(O/'classes')):sha(p) for p in (O/'classes').rglob('*.class')}
  allowed=['com/skillpilot/backend/service/StoredCompositionFocusTest','PrivateSurvivingFocusLauncher']
  assert all(any(p==prefix+'.class' or p.startswith(prefix+'$') for prefix in allowed) for p in private),private
  assert 'com/skillpilot/backend/service/StoredCompositionFocusTest$Fixture.class' in private
  write(O/'private-test-class-hashes.json',private)
else:
 suites=stored if args.phase=='stored' else boundaries
 classpath=str(O/'classes')+':'+str(PRIVATE_MAIN)+':'+str(RESOURCES)+':'+CP
 code=run(args.phase,[JAVA/'java','-Xmx3200m','-Dskillpilot.focus.fixture.resources='+str(RESOURCES),
  '-Dskillpilot.focus.private.main.classes='+str(PRIVATE_MAIN),'-Dskillpilot.focus.private.main.names='+str(H/'reused-main-class-names.txt'),
  '-Dskillpilot.focus.regression.root='+str(R),'-cp',classpath,'PrivateSurvivingFocusLauncher',O/args.phase/'results',O/'classes',
  R/'backend/build/classes/java/test',R/'backend/build/classes/java/main',*suites])
guard()
summary=read(O/args.phase/'results/summary-counts.json') if (O/args.phase/'results/summary-counts.json').exists() else None
if code==0 and args.phase!='compile':
 assert summary and summary['testsFound']>0 and summary['testsFound']==summary['testsStarted']==summary['testsSucceeded']
 assert all(summary[k]==0 for k in ['testsFailed','testsSkipped','testsAborted','containersFailed'])
write(O/(args.phase+'.result.json'),dict(status='ACTUAL_PRIVATE_V4_'+args.phase.upper(),exitCode=code,commands=commands,summary=summary,
 inputMap=pin(IMAP),classMap=pin(CMAP),root947431And9554InputGuardsUnchanged=True,reused33PrivateMainClassesUnchanged=True,
 mixedPrivateCandidateAndRootDependencies=True,rootMutation=False,noFullBackendOrHostAcceptance=True))
print(json.dumps(dict(phase=args.phase,exitCode=code,summary=summary)),flush=True)
raise SystemExit(code)
