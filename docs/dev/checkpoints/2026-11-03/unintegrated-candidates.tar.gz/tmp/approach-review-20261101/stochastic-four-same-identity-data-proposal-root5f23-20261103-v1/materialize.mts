import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { dirname, join, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { fingerprintSemanticKindSourceGoal } from '../curricular-assessment-role-common-root9554-20261103-v1/candidate/app/scripts/goalBookModel'
import { bindCurricularReviewLandscape, isAuthoritativeCurricularReviewGoal } from '../curricular-assessment-role-common-root9554-20261103-v1/candidate/app/scripts/lib/curricularReviewPopulation'
import { collectRouteTerminalAutonomyGoals, concreteExamReadinessIssues } from '../curricular-assessment-role-common-root9554-20261103-v1/candidate/app/scripts/generateCurriculumQualityStatus'
import { collectCompositionProjectionRoleGoalIds } from '../../../app/src/utils/authoring/compositionViewAuthoring'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../../..')
const here = dirname(fileURLToPath(import.meta.url))
const content = join(root, 'tmp/approach-review-20261101/stochastic-models-test-decisions-own-content-candidates-20261103-v1')
const output = join(here, 'proposed-data')
assert.ok(!existsSync(output), 'Never overwrite a frozen/private predecessor')
mkdirSync(output)
const hash = (bytes: Uint8Array | string) => createHash('sha256').update(bytes).digest('hex')
const read = (path: string) => JSON.parse(readFileSync(path, 'utf8'))
const pin = (path: string) => ({ path: relative(root, path), sha256: hash(readFileSync(path)) })
const canonicalPath = 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
const ledgerPath = 'curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json'
const before = read(join(root, canonicalPath))
const ledgerBefore = read(join(root, ledgerPath))
assert.equal(hash(readFileSync(join(root, canonicalPath))), '5f23d314ed1b31caae2e5994921c5fa2599ca7e7f718a5b9fc9d61334713bf37')
assert.equal(hash(readFileSync(join(root, ledgerPath))), '1a4cdb4df95d99d4ab378966f80374c35462ce4660a5423b1292bff73df16bca')
assert.equal(ledgerBefore.counts.curricularAtomic, 807)
const after = structuredClone(before)
const ledgerAfter = structuredClone(ledgerBefore)
const forms = [
  { id: '03357e70-2280-532f-b629-5dfa31dc44eb', folder: 'test-comparison-033-draft-by-sol-child' },
  { id: 'ae3483e3-4712-56a1-a881-2e1f8a1a8df9', folder: 'rubric-followup-r2/power-graph-ae348' },
  { id: '5dbf149c-d335-552c-a918-768a12e09201', folder: 'normal-model-5dbf' },
  { id: '7d9c565c-8df1-40ca-b3c6-2d4ec51e9140', folder: 'normal-density-7d9c' },
]
const ids = new Set(forms.map(f => f.id))
const proposedMetadata: unknown[] = []
const fingerprints: unknown[] = []
const wholeContracts: unknown[] = []
const inputPins: unknown[] = []
for (const form of forms) {
  const original = before.goals.find((g: any) => g.id === form.id)
  const target = after.goals.find((g: any) => g.id === form.id)
  assert.ok(original && !original.examData && !original.contains.length)
  const folder = join(content, form.folder)
  let exam: any
  if (form.id.startsWith('033')) {
    const contract = read(join(folder, 'ordinary-rubric-contract.json'))
    const text = (name: string) => readFileSync(join(folder, name), 'utf8')
    const de = text('solution-and-rubric.de.md'), en = text('solution-and-rubric.en.md')
    const rows = (s: string) => new Map([...s.matchAll(/^\| ([a-z_]+) \| (.+) \| 1 \|$/gm)].map(m => [m[1],m[2]]))
    const deRows = rows(de), enRows = rows(en)
    assert.equal(deRows.size, contract.steps.length)
    assert.equal(enRows.size, contract.steps.length)
    exam = {
      reviewStatus: 'released', coveredGoalIds: [form.id], coveredStrands: ['L5'], demandLevels: ['AB1','AB2','AB3'],
      taskContent: text('task.de.md'), taskContentEn: text('task.en.md'), solutionContent: de, solutionContentEn: en,
      scoring: { maxPoints: contract.maxPoints, passingPoints: contract.passingPoints,
        steps: contract.steps.map((s: any) => ({ ...s, description: deRows.get(s.id), descriptionEn: enRows.get(s.id) })) },
    }
    inputPins.push(...['task.de.md','task.en.md','solution-and-rubric.de.md','solution-and-rubric.en.md','ordinary-rubric-contract.json'].map(p => pin(join(folder,p))))
    proposedMetadata.push({goalId:form.id,coveredStrands:['L5'],demandLevels:['AB1','AB2','AB3'],
      rationale:'Actual binomial probabilities and error/power interpretation; compare and justify two decisions in their stated operating contexts. No official task/source coverage inferred.'})
  } else {
    const draftPath = join(folder, 'whole-content-draft.json')
    const draft = read(draftPath)
    assert.equal(draft.existingGoalId, form.id)
    exam = structuredClone(draft.examData)
    assert.equal(exam.reviewStatus, 'draft')
    // Only the content-release proposal changes. Scope/program authorization is
    // still absent; this file set is expressly NOT an activatable Root package.
    exam.reviewStatus = 'released'
    inputPins.push(pin(draftPath))
    proposedMetadata.push({goalId:form.id,coveredStrands:exam.coveredStrands,demandLevels:exam.demandLevels,
      rationale:'Exactly the independently reviewed whole-content draft metadata; no new source or target claim.'})
  }
  assert.deepEqual(exam.coveredGoalIds,[form.id])
  assert.equal(exam.scoring.steps.reduce((n: number,s: any) => n+s.points,0),exam.scoring.maxPoints)
  target.nodeKind = 'exam'
  target.examData = exam
  const strip = (g: any) => { const x=structuredClone(g); delete x.nodeKind; delete x.examData; return x }
  assert.deepEqual(strip(target),strip(original))
  const row = ledgerAfter.decisions.find((d: any) => d.goalId === form.id)
  assert.equal(row.semanticKind, 'curricularAtomic')
  const oldFingerprint = row.sourceFingerprint
  row.sourceFingerprint = fingerprintSemanticKindSourceGoal(target)
  fingerprints.push({goalId:form.id,before:oldFingerprint,after:row.sourceFingerprint})
  wholeContracts.push({goalId:form.id,before:original,after:target,changedFields:['nodeKind','examData']})
}
for (let i=0;i<before.goals.length;i++) {
  assert.equal(before.goals[i].id,after.goals[i].id)
  if (!ids.has(before.goals[i].id)) assert.deepEqual(after.goals[i],before.goals[i])
}
for (let i=0;i<ledgerBefore.decisions.length;i++) {
  const a=structuredClone(ledgerAfter.decisions[i]),b=structuredClone(ledgerBefore.decisions[i])
  if(ids.has(a.goalId)) {delete a.sourceFingerprint;delete b.sourceFingerprint}
  assert.deepEqual(a,b)
}
assert.deepEqual(ledgerAfter.counts,ledgerBefore.counts)
const bound=bindCurricularReviewLandscape(after,ledgerAfter,canonicalPath)
assert.equal(bound.goals.filter(isAuthoritativeCurricularReviewGoal).length,807)
assert.throws(()=>bindCurricularReviewLandscape(after,ledgerBefore,canonicalPath),/stale semantic-kind decision/)
const badBasis=structuredClone(ledgerAfter);badBasis.decisions[0].decisionBasis='unreviewed-own-anything'
assert.throws(()=>bindCurricularReviewLandscape(after,badBasis,canonicalPath),/closed JSON Schema/)
const terminalProfile={terminalAutonomyClusterIds:[],goalSelector:(g: any)=>ids.has(g.id)}
const actualTerminals=collectRouteTerminalAutonomyGoals(bound,terminalProfile)
assert.deepEqual(actualTerminals.map(g=>g.id).sort(),[...ids].sort())
for(const goal of actualTerminals) assert.deepEqual(concreteExamReadinessIssues(goal),[])

// Static authoring roles only: no PersonalCurriculum/Native/readiness claim.
const oldMap=new Map(before.goals.map((g: any)=>[g.id,g])) as any
const newMap=new Map(after.goals.map((g: any)=>[g.id,g])) as any
const viewDirectory=join(root,'curricula/DE/Gymnasium/composition-views/mathematik')
const roleRows=[]
for(const name of readdirSync(viewDirectory).filter(n=>n.endsWith('.view.json')).sort()) {
  const path=join(viewDirectory,name),view=read(path)
  const a=collectCompositionProjectionRoleGoalIds(view.rootNodes,oldMap)
  const b=collectCompositionProjectionRoleGoalIds(view.rootNodes,newMap)
  const sorted=(v:Iterable<string>)=>[...v].sort()
  assert.deepEqual(sorted(a.targetGoalIds),sorted(b.targetGoalIds))
  assert.deepEqual(sorted(a.prerequisiteOnlyGoalIds),sorted(b.prerequisiteOnlyGoalIds))
  roleRows.push({...pin(path),viewId:view.viewId,staticTargetAndPOnlySetsEqual:true})
}
const files:any[]=[]
function put(path:string,bytes:Uint8Array|string) {
  const dest=join(output,path);mkdirSync(dirname(dest),{recursive:true});writeFileSync(dest,bytes,{flag:'wx'})
  files.push({path,beforeSha256:existsSync(join(root,path))?hash(readFileSync(join(root,path))):null,
    candidatePath:relative(root,dest),candidateSha256:hash(readFileSync(dest))})
}
put(canonicalPath,JSON.stringify(after,null,2)+'\n')
put(ledgerPath,JSON.stringify(ledgerAfter,null,2)+'\n')
const mediaManifest=read(join(content,'task-media-manifest.json'))
for(const media of mediaManifest.media) for(const ext of ['png','svg']) {
  const entry=media[ext],source=join(content,entry.path)
  assert.equal(hash(readFileSync(source)),entry.sha256)
  const path=entry.path.replace(/^task-media\//,'')
  assert.ok(path.startsWith('app/public/assets/assessment-materials/'))
  assert.ok(!existsSync(join(root,path)),'Never overwrite published media')
  put(path,readFileSync(source))
}
for(const goal of after.goals.filter((g:any)=>ids.has(g.id))) for(const field of ['taskContent','taskContentEn']) {
  for(const match of goal.examData[field].matchAll(/!\[[^\]]*\]\((\/assets\/[^)]+)\)/g))
    assert.ok(existsSync(join(output,'app/public',match[1])),match[1])
}
const result={status:'PRIVATE_NON_ACTIVATABLE_FOUR_SAME_ID_DATA_AND_ASSET_PROPOSAL_SCOPE_REVIEW_REQUIRED',
  base:{canonical:pin(join(root,canonicalPath)),ledger:pin(join(root,ledgerPath)),schema:pin(join(root,'contracts/curriculum-package/v1/curriculum-ontology-profile.schema.json'))},
  importProposalOnly:files,wholeFourGoalContracts:wholeContracts,ledgerFingerprintOnlyChanges:fingerprints,
  strictParser807AndStaleUnknownBasisNegativeChecks:true,staticCompositionViewRoleComparisons:roleRows,
  newlyObservedQaTerminals:actualTerminals.map(g=>g.id),concreteTaskReadinessPassedForProposedContentOnly:true,
  metadataProposal:proposedMetadata,exactApprovedContentInputs:inputPins,
  reviewStatusMeaning:'released is proposed for independently approved task content only; without finite scope/program decisions, exact evidence revalidation and normal checks these bytes MUST NOT be imported',
  preserved:{allIds:true,allRequires:true,allContains:true,allOtherGoalParts:true,allOldExamData:true,
    oldGoalVisualizations:true,allLedgerKindsCountsAndDecisionBases:true,curricularAtomicCount:807,
    noNewMasteryOrOutcomeQualification:true,noAssessmentFromRequiresOrBoundaryAdded:true,
    allViewsAndMappingsAndPoliciesUnmodified:true},
  holds:['No finite PC/year/program allowance yet; static view membership is not a placement approval',
    'HE Q4.2 elective/additional status, not universal compulsory task;ae348 old sourceRef S51 points to printedS52 and is retained pending separate locator correction',
    'All four whole contracts are LK; neither packet title nor broad jurisdiction cache authorizes GK/SekI',
    'The four BW SekI exception pairs concern42d300/837b, not any of these four forms',
    'Actual48/47/41/31 entry/support/acquisition contexts and ALL/union membership require finite review',
    'Existing Atomicity/Memory/other fingerprint-sensitive review rows must be revalidated exactly; no automatic rebind',
    'No complete source compiler/producer/native/Stage/M7/Root acceptance'],
  no5743CanonReplacement:true,noRootOrJvmOrSourcePipelineWrites:true}
writeFileSync(join(here,'data-and-assets-proposal.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({proposal:pin(join(here,'data-and-assets-proposal.json')),leaves:files.length,staticViews:roleRows.length,curricularAtomic:807}))
