from pathlib import Path
import difflib
import hashlib
import json
import subprocess

ROOT=Path('/home/enpasos/projects/skillpilot')
HERE=Path(__file__).resolve().parent
path='app/scripts/testGoalBookModel.ts'
src=ROOT/path
dst=HERE/'candidate'/path
assert not dst.exists()
before=src.read_text()
old='''assert.deepEqual(
  complexQ4Assessment.requires,
  complexQ4Assessment.examData.coveredGoalIds,
  'Q4 complex-number exam prerequisites must match its claimed assessment coverage',
)
'''
new='''// Preparation can be broader than the whole contracts assessed by this task.
// The reviewed task observes only multiplication by i in the Gaussian plane;
// it does not assess the complete addition/subtraction/multiplication/division goal.
assert.deepEqual(
  [...complexQ4Assessment.requires].sort(),
  [
    '5922affd-b1f9-5ad9-963e-25d3734c3b72',
    'eda8580e-1f10-5dbd-9aaf-92367f40a6bd',
    '9a0987cd-1e6e-5c09-a602-9fda43b8f655',
    'a7fb1a7a-8315-5bcb-842e-48293293dfcc',
  ].sort(),
  'Q4 complex-number task retains its four independently reviewed preparation goals',
)
assert.deepEqual(
  [...complexQ4Assessment.examData.coveredGoalIds].sort(),
  [
    '5922affd-b1f9-5ad9-963e-25d3734c3b72',
    'eda8580e-1f10-5dbd-9aaf-92367f40a6bd',
    '9a0987cd-1e6e-5c09-a602-9fda43b8f655',
  ].sort(),
  'Q4 complex-number task claims only its three independently reviewed assessed contracts',
)
assert.ok(complexQ4Assessment.requires.includes('a7fb1a7a-8315-5bcb-842e-48293293dfcc'))
assert.ok(
  !complexQ4Assessment.examData.coveredGoalIds.includes('a7fb1a7a-8315-5bcb-842e-48293293dfcc'),
  'Gaussian-plane preparation must not be promoted to whole-contract assessment coverage',
)
'''
assert before.count(old)==1
after=before.replace(old,new)
prefix,suffix=before.split(old)
assert after==prefix+new+suffix
assert "'The Q4 complex-number task does not assess optional Mandelbrot iterations'" in suffix
dst.parent.mkdir(parents=True)
dst.write_text(after)
patch=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
(HERE/'single-test-leaf.patch').write_text(patch)
check=subprocess.run(['git','apply','--check',str((HERE/'single-test-leaf.patch').relative_to(ROOT))],cwd=ROOT,capture_output=True,text=True)
assert check.returncode==0,check.stderr
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=lambda p:{'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size}
jsonsha=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
canpath=ROOT/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
canonical=json.loads(canpath.read_text());byid={g['id']:g for g in canonical['goals']}
goal=byid['a8525adc-fad3-53f5-953f-213bd37b09e8']
required=['5922affd-b1f9-5ad9-963e-25d3734c3b72','eda8580e-1f10-5dbd-9aaf-92367f40a6bd','9a0987cd-1e6e-5c09-a602-9fda43b8f655','a7fb1a7a-8315-5bcb-842e-48293293dfcc']
covered=required[:-1]
assert sorted(goal['requires'])==sorted(required)
assert sorted(goal['examData']['coveredGoalIds'])==sorted(covered)
reviewpath=ROOT/'curricula/DE/Gymnasium/assessments/mathematik/completion-integrity-2026-11-01/contract-corrections-v1/independent-upper-candidate-review.json'
review=json.loads(reviewpath.read_text());case=review['cases'][23]
assert case['goalId']==goal['id']
assert case['afterExactlyApprovedDelta']=='PASS'
assert case['preparationVerdict']==case['taskSolutionRubricVerdict']=='PASS'
assert case['remainingFindings'][0]['goalId']==required[-1]
for key in ['taskContent','solutionContent','scoring']:
    assert jsonsha(goal['examData'][key])==case['fieldSha256'][key]
assert jsonsha(goal['requires'])==case['requiresSha256']
assert jsonsha(goal['requires'])==case['fieldSha256']['coveredGoalIds']
assert set(goal['requires'])-{case['remainingFindings'][0]['goalId']}==set(covered)
snapshotpath=ROOT/'tmp/approach-review-20261101/astra-complex-numbers-scope-review/family-and-protected-contracts.json'
snapshot=json.loads(snapshotpath.read_text())['relatedGoals'][2]
assert snapshot==goal
source=ROOT/goal['examData']['sourceArtifactPath']
assert goal['sourceRef']==str(source.relative_to(ROOT))+'#aufgabe'
assert source.read_text().split('## Aufgabe\n\n',1)[1].strip()==goal['examData']['taskContent'].strip()
common=ROOT/'tmp/approach-review-20261101/curricular-assessment-role-common-root9554-20261103-v1/source-review-request.json'
assert sha(common)=='17ee3a21df866613ba9ff4fee8a7b0d8a3e596b346ed5873fdfe6dacdd9f295c'
mapfile=ROOT/'tmp/approach-review-20261101/mcp-eight-root-import-x6xdeebc/current-input-hashes.json'
inputs=json.loads(mapfile.read_text())
for p,digest in inputs.items(): assert sha(ROOT/p)==digest,p
doc={'status':'ONE_TEST_LEAF_DRAFT_PENDING_INDEPENDENT_SOURCE_COUNTERREVIEW_NO_NODE_RUN_YET',
 'importFiles':[{'path':path,'beforeSha256':sha(src),'candidatePath':str(dst.relative_to(ROOT)),'candidateSha256':sha(dst)}],
 'patch':pin(HERE/'single-test-leaf.patch'),'preparer':pin(Path(__file__).resolve()),
 'sourceBasis':{'actualWholeQ4Goal':goal,'canonical':pin(canpath),
   'exactSourceRef':goal['sourceRef'],'taskSourceArtifact':pin(source),
   'sourceArtifactTaskEqualsCurrentTaskContent':True,
   'independentTaskSolutionRubricAndCoverageReview':{'file':pin(reviewpath),'pointer':'/cases/23',
       'case':case,'taskSolutionAndScoringCurrentJsonHashesMatchReviewedFields':True,
       'currentRequiresHashMatchesReviewedRequiresHash':True,
       'coverageAfterExactlyApprovedRemoval':'The historical candidate coverage was the same4 list; the review explicitly removes only the entire a7fb contract. Current coverage equals the remaining3 exactly.'},
   'independentScopeWholeContractSnapshot':{'file':pin(snapshotpath),'pointer':'/relatedGoals/2','wholeGoalExactlyEqualsCurrentRoot':True},
   'preparationGoal':byid[required[-1]]},
 'preserved':{'allOtherTestBytesExactPrefixAndSuffix':True,'existingMandelbrotNegativeByteExact':True,
   'allProductRuntimeTaskRubricRequiresCoverageSourceAndScopeDataUnchanged':True,
   'originalCommon16Freeze':pin(common),
   'bothHistoricalWholeGoalbookExit1Baseline':pin(ROOT/'tmp/approach-review-20261101/curricular-assessment-role-common-root9554-20261103-v1/current-checks-r2/execution.json')},
 'staticChecks':{'exactCurrent4RequiredAnd3CoveredSets':True,'sortingCopiesPreserveInputsAndRejectDuplicateEntries':True,
   'a7fbRequiredAndNotCoveredExplicitlyAsserted':True,'gitApplyCheckExitCode':check.returncode},
 'guard':{'rootInputMap':pin(mapfile),'count':len(inputs),'allBytesUnchanged':True,
   'AGENTSNotIncludedInThatMap': 'AGENTS.md' not in inputs,'guidanceSeparatelyBound':pin(ROOT/'AGENTS.md')},
 'actualTestExecution':{'newGoalbookRunPerformed':False,'noJvm':True,'reason':'Independent exact source counterreview required before new private full Goalbook execution'},
 'remaining':['independent one-leaf source counterreview','then one private whole Goalbook suite with reviewed Common16+this test leaf on the same source basis','Root adoption only by coordinator']}
(HERE/'source-review-request.json').write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'request':pin(HERE/'source-review-request.json'),'singleTestLeaf':doc['importFiles'][0],'patch':doc['patch']},ensure_ascii=False))
