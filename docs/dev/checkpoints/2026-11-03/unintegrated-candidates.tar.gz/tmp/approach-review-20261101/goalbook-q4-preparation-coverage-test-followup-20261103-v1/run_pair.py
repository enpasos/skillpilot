from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

ROOT=Path('/home/enpasos/projects/skillpilot')
HERE=Path(__file__).resolve().parent
COMMON=ROOT/'tmp/approach-review-20261101/curricular-assessment-role-common-root9554-20261103-v1'
RUN=HERE/'whole-goalbook-pair-r1'
RUN.mkdir(exist_ok=False)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p): return {'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
common=json.loads((COMMON/'source-review-request.json').read_text())
q4=json.loads((HERE/'source-review-request.json').read_text())
assert sha(COMMON/'source-review-request.json')=='17ee3a21df866613ba9ff4fee8a7b0d8a3e596b346ed5873fdfe6dacdd9f295c'
assert sha(HERE/'source-review-request.json')=='fb43598dd6baeb8b73e16f8367904c8245fb47728b76163c33aa7e409a4188b5'
review=ROOT/'tmp/approach-review-20261101/astra-common16-and-q4-test-review-20261103-v1/q4-test-counterreview.STATIC_PASS.json'
assert sha(review)=='a9d72fecec01ab7c8a5397806227cd737a1034734ac8004ed52680aef7393dd2'
mapfile=ROOT/'tmp/approach-review-20261101/mcp-eight-root-import-x6xdeebc/current-input-hashes.json'
classfile=ROOT/'tmp/approach-review-20261101/mcp-fixture-actual-root-20261103/actual-root/current-class-hashes.json'
inputs=json.loads(mapfile.read_text());classes=json.loads(classfile.read_text())
assert len(inputs)==9554 and len(classes)==1378
assert sum('/main/' in p for p in classes)==947
assert sum('/test/' in p for p in classes)==431
def guard():
    for path,digest in {**inputs,**classes}.items(): assert sha(ROOT/path)==digest,path
    for row in common['importFiles']+q4['importFiles']:
        old=ROOT/row['path'];new=ROOT/row['candidatePath']
        assert (sha(old) if old.exists() else None)==row['beforeSha256'],row['path']
        assert sha(new)==row['candidateSha256'],row['candidatePath']
    actual=set()
    for kind in ['main','test']:
        actual.update(str(p.relative_to(ROOT)) for p in (ROOT/'backend/build/classes/java'/kind).rglob('*.class'))
    assert actual==set(classes)
guard()
began=now()
testsource=ROOT/q4['importFiles'][0]['candidatePath']
def overlay(name,base):
    out=RUN/name
    directory=out/'app/scripts';directory.mkdir(parents=True)
    for source in (base/'app/scripts').iterdir():
        destination=directory/source.name
        if source.name=='testGoalBookModel.ts':destination.write_bytes(testsource.read_bytes())
        else:destination.symlink_to(source)
    for path in ['app/src','app/public','app/node_modules','app/package.json','contracts','curricula','docs']:
        destination=out/path;destination.parent.mkdir(parents=True,exist_ok=True);destination.symlink_to(ROOT/path)
    assert sha(directory/'testGoalBookModel.ts')==q4['importFiles'][0]['candidateSha256']
    return out
sides=[('root-product-code',ROOT),('common16-product-code',COMMON/'candidate')]
results=[]
events=RUN/'events.jsonl'
for name,base in sides:
    out=overlay(name,base)
    command=['node','app/node_modules/tsx/dist/cli.mjs',str((out/'app/scripts/testGoalBookModel.ts').relative_to(ROOT))]
    stdout=RUN/(name+'.stdout.log');stderr=RUN/(name+'.stderr.log')
    start=now();clock=time.monotonic()
    with stdout.open('wb') as sout,stderr.open('wb') as serr:
        process=subprocess.Popen(command,cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=sout,stderr=serr)
        event={'event':'started','name':name,'pid':process.pid,'time':start,'command':command}
        with events.open('a') as f:f.write(json.dumps(event)+'\n')
        print(json.dumps(event),flush=True)
        code=process.wait()
    result={'name':name,'pid':process.pid,'command':command,'startedAt':start,'finishedAt':now(),
            'durationSeconds':round(time.monotonic()-clock,3),'exitCode':code,'stdout':pin(stdout),'stderr':pin(stderr),
            'sameReviewedTestLeaf':pin(out/'app/scripts/testGoalBookModel.ts'),
            'actualGoalbookSource':pin((out/'app/scripts/goalBookModel.ts').resolve()),
            'scope':'whole unshortened testGoalBookModel suite, same current Root curriculum and exact same reviewed new test source'}
    results.append(result)
    with events.open('a') as f:f.write(json.dumps({'event':'finished',**result})+'\n')
    print(json.dumps({'finished':name,'pid':process.pid,'exitCode':code}),flush=True)
guard()
assert sha(COMMON/'common-role.patch')==common['patch']['sha256']
plan=common['importFiles']+q4['importFiles']
assert len(plan)==len({p['path'] for p in plan})==17
report={'status':'TWO_ACTUAL_WHOLE_GOALBOOK_RUNS_TERMINAL_NO_ROOT_ADOPTION',
        'startedAt':began,'finishedAt':now(),'runner':pin(Path(__file__).resolve()),'actualRuns':results,
        'bothWholeSuitesPassed':all(row['exitCode']==0 for row in results),
        'commonSourceRequest':pin(COMMON/'source-review-request.json'),'q4SourceRequest':pin(HERE/'source-review-request.json'),
        'independentQ4StaticReview':pin(review),
        'beforeAfterGuards':{'inputMap':pin(mapfile),'inputs':len(inputs),'classMap':pin(classfile),'mainClasses':947,'testClasses':431,
            'all9554SourcesAnd1378ClassBytesAndClassInventoryExact':True,'allFrozenCandidateAndBeforeHashesExact':True,
            'AGENTSNotInThisMap':True,'guidanceSeparate':pin(ROOT/'AGENTS.md')},
        'historicalFailuresRetained':[pin(COMMON/'current-checks-r2/execution.json'),pin(COMMON/'terminal-current-checks-handoff.json')],
        'scopeBoundary':'Node-only Goalbook code and test evidence; no JVM, Native, Source21, producer, Stage, Root, CI or M7 claim.',
        'noRootCodeDataClassSymlinkWrites':True}
(RUN/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
handoff={'status':'REVIEWABLE_SEVENTEEN_SOURCE_IMPORT_PROPOSAL_NOT_AUTHORIZED_ROOT_IMPORT',
         'actualPair':pin(RUN/'execution.json'),'importFiles':plan,
         'common16IndependentReviewStillSeparate':True,'q4IndependentReview':pin(review),
         'preserved':'807 curricularAtomic,closed enum,strict fingerprints,sole binary mastery and all Root task/R/target data',
         'noAutomaticRootImport':True}
(RUN/'seventeen-file-import-proposal.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps({'terminalReport':pin(RUN/'execution.json'),'importProposal':pin(RUN/'seventeen-file-import-proposal.json'),
                  'exitCodes':[r['exitCode'] for r in results]}),flush=True)
