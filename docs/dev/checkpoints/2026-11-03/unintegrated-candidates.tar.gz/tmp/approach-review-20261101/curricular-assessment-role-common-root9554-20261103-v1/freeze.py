from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/enpasos/projects/skillpilot')
HERE = Path(__file__).resolve().parent
OUT = HERE/'candidate'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p): return {'path': str(p.relative_to(ROOT)), 'sha256': sha(p), 'bytes': p.stat().st_size}
rows = json.loads((HERE/'import-files.json').read_text())
patch = []
for row in rows:
    p=ROOT/row['path']; q=ROOT/row['candidatePath']
    assert (sha(p) if p.exists() else None) == row['beforeSha256']
    row['candidateSha256']=sha(q)
    patch.extend(difflib.unified_diff((p.read_text() if p.exists() else '').splitlines(keepends=True),
                 q.read_text().splitlines(keepends=True), fromfile='a/'+row['path'], tofile='b/'+row['path']))
(HERE/'common-role.patch').write_text(''.join(patch))
(HERE/'import-files.json').write_text(json.dumps(rows,indent=2)+'\n')
check=subprocess.run(['git','apply','--check',str((HERE/'common-role.patch').relative_to(ROOT))],cwd=ROOT,capture_output=True,text=True)
assert check.returncode==0,check.stderr
raw = (ROOT/'app/scripts/goalBookModel.ts').read_text()
old = raw[raw.index('const parseSemanticKindLedger = ('):raw.index('\nconst parseGoalVisualizationQa = (')].strip()
new=(OUT/'app/scripts/lib/semanticKindLedger.ts').read_text()
new=new[new.index('export const parseSemanticKindLedger = ('):].strip()
new=new.replace('export const parseSemanticKindLedger', 'const parseSemanticKindLedger',1).replace(
    '  fingerprintSemanticKindSourceGoal: (goal: Record<string, unknown>) => string,\n','',1)
assert old == new
assert 'export const parseSemanticKindLedger' not in (OUT/'app/scripts/goalBookModel.ts').read_text()
baseline=(HERE/'node-book-root-baseline.stderr.log').read_text()
candidate=(HERE/'node-book-r2.stderr.log').read_text()
for text in [baseline,candidate]:
    assert 'Q4 complex-number exam prerequisites must match its claimed assessment coverage' in text
    assert "'a7fb1a7a-8315-5bcb-842e-48293293dfcc'" in text
normalized = lambda s:s.replace(str(OUT)+'/',str(ROOT)+'/')
assert normalized(candidate)==baseline
guard=ROOT/'tmp/approach-review-20261101/mcp-eight-root-import-x6xdeebc/current-input-hashes.json'
inputs=json.loads(guard.read_text())
for path,digest in inputs.items(): assert sha(ROOT/path)==digest,path
doc={
 'status':'PRIVATE_COMMON_ASSESSMENT_ROLE_SOURCE_CANDIDATE_FOR_REVIEW_NOT_ROOT_OR_M7',
 'basis':{'actualRootInputMap':pin(guard),'inputCount':len(inputs),'allInputBytesStillExact':True,
          'canonical':pin(ROOT/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'),
          'ledger':pin(ROOT/'curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json'),
          'closedSchema':pin(ROOT/'contracts/curriculum-package/v1/curriculum-ontology-profile.schema.json')},
 'importFiles':rows,'patch':pin(HERE/'common-role.patch'),
 'scope':{'curricularAtomicCount':807,'noClassificationOrDataChanges':True,'oneBinaryMasteryUnchanged':True,
  'sharedBy':'same-identity5743 and the four independently approved stochastic forms',
  'notIncluded':['5743-specific ordinary relocation helper/test','already active closed enum/schema migration',
                'any Java/runtime/start/mastery/provider code','data/media/placements','QA floors or source pipeline execution'],
  'noGoalBookParserExport':True,
  'sharedStrictParserConsumers':['actual goalBookModel private parse wrapper','actual curricularReviewPopulation authoring/review binding'],
  'parserBodyExactAfterSignatureExtraction':True,'existingFingerprintAlgorithmAndPublicExportUnchanged':True,
  'noTransientDecisionBasisNormalizationInTests':True,
  'workflowDelta':'only add the existing3-case Python population suite; every actual current MCP/Math/CI clause retained'},
 'actualChecks':[
  {'name':'existing and new hard-route/population/CQS target/POnly/absence/unready/duration cases','exitCode':0,
   'stdout':pin(HERE/'node-routes.stdout.log'),'stderr':pin(HERE/'node-routes.stderr.log')},
  {'name':'both independent Python population selectors,3 cases','exitCode':0,
   'stdout':pin(HERE/'python-population.stdout.log'),'stderr':pin(HERE/'python-population.stderr.log')},
  {'name':'unmodified whole public Goalbook builder suite on actual Root','exitCode':1,
   'stdout':pin(HERE/'node-book-root-baseline.stdout.log'),'stderr':pin(HERE/'node-book-root-baseline.stderr.log')},
  {'name':'same whole Goalbook builder suite through private shared parser','exitCode':1,
   'stdout':pin(HERE/'node-book-r2.stdout.log'),'stderr':pin(HERE/'node-book-r2.stderr.log'),
   'exactErrorTextEqualAfterOnlyPrivateSourcePrefixNormalization':True,
   'observedFailure':'existing Q4 complex-number requires list expects3; actual4 includesa7fb1a7a',
   'notAWholeSuitePass':True,
   'strictPublicBuilderCasesReached':'closed-schema, nonauthoritative, stale fingerprint, wrong contract, unknown field and inconsistent count assertions precede this later failure'},
  {'name':'git apply --check','exitCode':check.returncode}],
 'retainedPreparationFailure':{'description':'first private public-book invocation lacked the read-only public asset link; source unchanged; no asset copied',
  'stdout':pin(HERE/'node-book.stdout.log'),'stderr':pin(HERE/'node-book.stderr.log'),'exitCode':1},
 'reviewBasis':[
  pin(ROOT/'tmp/approach-review-20261101/astra-quadratic5743-static-code-data-r2-review-20261103-v1/counterreview.HOLD.json'),
  pin(ROOT/'tmp/approach-review-20261101/astra-quadratic5743-cqs-media-followups-20261103-v1/cqs-r3-counterreview.PASS.json'),
  pin(ROOT/'tmp/approach-review-20261101/astra-stochastic-four-same-identity-content-review-20261103-v1/rubric-followup-r2-counterreview.PASS.json')],
 'remaining':['independent review of this exact rebase/extraction','scope decision before same-ID data activation',
              'actual final combined source/producer/native/stage checks','Root adoption only by coordinator'],
 'noJvmRootClassDataGitWrites':True,
}
(HERE/'source-review-request.json').write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps({'request':pin(HERE/'source-review-request.json'),'sourceLeaves':len(rows),'patch':pin(HERE/'common-role.patch')}))
