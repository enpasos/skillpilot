"""Actual finite Node/Python recheck; preserve the known Root suite failure."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/home/enpasos/projects/skillpilot')
HERE = Path(__file__).resolve().parent
RUN = HERE / 'current-checks-r2'
RUN.mkdir(exist_ok=False)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p): return {'path': str(p.relative_to(ROOT)), 'sha256': sha(p), 'bytes': p.stat().st_size}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
request_path = HERE / 'source-review-request.json'
request = json.loads(request_path.read_text())
assert sha(request_path) == '17ee3a21df866613ba9ff4fee8a7b0d8a3e596b346ed5873fdfe6dacdd9f295c'
mapfile = ROOT / request['basis']['actualRootInputMap']['path']
root_map = json.loads(mapfile.read_text())
assert len(root_map) == 9554
def guards():
    for path, digest in root_map.items(): assert sha(ROOT / path) == digest, path
    for row in request['importFiles']:
        old = ROOT / row['path']
        assert (sha(old) if old.exists() else None) == row['beforeSha256'], row['path']
        assert sha(ROOT / row['candidatePath']) == row['candidateSha256'], row['candidatePath']
guards()
started = now()
tsx = ['node', 'app/node_modules/tsx/dist/cli.mjs']
private = str((HERE/'candidate').relative_to(ROOT))
commands = [
    ('goalbook-unmodified-root', tsx+['app/scripts/testGoalBookModel.ts']),
    ('goalbook-identical-test-private-common-code', tsx+[private+'/app/scripts/testGoalBookModel.ts']),
    ('hard-route-cqs-population', tsx+[private+'/app/scripts/testHardLearningRouteValidation.ts']),
    ('python-population', ['python3', private+'/scripts/test_curricular_assessment_population.py']),
    ('patch-applicability', ['git','apply','--check',str((HERE/'common-role.patch').relative_to(ROOT))]),
]
results=[]
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
for name,command in commands:
    begin=now(); clock=time.monotonic()
    out=RUN/(name+'.stdout.log');err=RUN/(name+'.stderr.log')
    with out.open('wb') as stdout,err.open('wb') as stderr:
        child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
        pid=child.pid
        print(json.dumps({'started':name,'pid':pid}),flush=True)
        code=child.wait()
    results.append({'name':name,'command':command,'pid':pid,'startedAt':begin,'finishedAt':now(),
                    'durationSeconds':round(time.monotonic()-clock,3),'exitCode':code,'stdout':pin(out),'stderr':pin(err)})
    print(json.dumps({'finished':name,'exitCode':code}),flush=True)
assert [row['exitCode'] for row in results] == [1,1,0,0,0]
baseline=(RUN/'goalbook-unmodified-root.stderr.log').read_text()
candidate=(RUN/'goalbook-identical-test-private-common-code.stderr.log').read_text()
assert baseline == candidate.replace(str(HERE/'candidate')+'/',str(ROOT)+'/')
assert (RUN/'goalbook-unmodified-root.stdout.log').read_bytes()==(RUN/'goalbook-identical-test-private-common-code.stdout.log').read_bytes()
assert 'Q4 complex-number exam prerequisites must match its claimed assessment coverage' in baseline
assert "'a7fb1a7a-8315-5bcb-842e-48293293dfcc'" in baseline
test_path=ROOT/'app/scripts/testGoalBookModel.ts'
private_test=HERE/'candidate/app/scripts/testGoalBookModel.ts'
assert test_path.read_bytes()==private_test.read_bytes()
canonical_path=ROOT/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
canonical=json.loads(canonical_path.read_text())
by_id={g['id']:g for g in canonical['goals']}
goal=by_id['a8525adc-fad3-53f5-953f-213bd37b09e8']
requires=goal['requires'];covered=goal['examData']['coveredGoalIds']
assert len(requires)==4 and len(covered)==3
assert sorted(set(requires)-set(covered))==['a7fb1a7a-8315-5bcb-842e-48293293dfcc']
guards()
report={
 'status':'FINITE_CHECKS_TERMINAL_WITH_EXISTING_ROOT_GOALBOOK_FAILURE_NOT_ALL_GREEN',
 'startedAt':started,'finishedAt':now(),'sourceRequest':pin(request_path),'runner':pin(Path(__file__).resolve()),
 'actualCommands':results,'overallAllTestsPassed':False,
 'rootBeforeAfter':{'inputMap':pin(mapfile),'count':len(root_map),'allBytesExact':True,'candidate16AndBeforeHashesExact':True},
 'goalbookBaselineComparison':{'bothExitCode':1,'sameUnmodifiedWholeTestSource':pin(test_path),
    'privateTestCopy':pin(private_test),'stdoutByteEqual':True,
    'stderrExactlyEqualAfterOnlyPrivateRepositoryPrefixReplacement':True,
    'failureMessage':'Q4 complex-number exam prerequisites must match its claimed assessment coverage',
    'failureLocation':'app/scripts/testGoalBookModel.ts:1104',
    'actualWholeQ4Goal':goal,'goalCanonicalSource':pin(canonical_path),
    'requiresCount':len(requires),'coveredGoalIdsCount':len(covered),
    'requiresNotCovered':[{'id':i,'wholeGoal':by_id[i]} for i in requires if i not in covered],
    'noAssertionOrCurriculumChanged':True,
    'semanticBoundary':'requires expresses preparation; coveredGoalIds expresses assessed coverage. Their current inequality is preserved and not repaired or declared wrong by this code rebase.',
    'strictPublicBuilderCasesBeforeFailure':['nonauthoritative decision','stale source fingerprint','wrong fingerprint contract','unknown ledger property','unknown decision property','inconsistent counts'],
    'laterGoalbookAssertionsNotReached':True},
 'greenFiniteChecks':['actual hard-route/CQS/population target/POnly/absent/duration/unready and closed-enum/stale-fingerprint assertions','3 independent Python population cases','git apply --check'],
 'noWholeGoalbookSuiteOrM7OrCiPassClaim':True,'noJvmRootCodeDataClassGitOrNewHostWrites':True,
}
(RUN/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'terminalReport':pin(RUN/'execution.json'),'commandExits':[r['exitCode'] for r in results]}),flush=True)
