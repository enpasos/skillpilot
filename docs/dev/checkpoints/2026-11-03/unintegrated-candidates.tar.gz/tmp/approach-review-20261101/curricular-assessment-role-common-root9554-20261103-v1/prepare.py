from pathlib import Path
import difflib
import hashlib
import json
import os

ROOT = Path('/home/enpasos/projects/skillpilot')
HERE = Path(__file__).resolve().parent
OLD = ROOT / 'tmp/approach-review-20261101/quadratic5743-same-identity-followup-candidate-20261103-v1'
OUT = HERE / 'candidate'
assert not OUT.exists()
OUT.mkdir()
request = json.loads((OLD / 'static-review-request.r2.json').read_text())
excluded = {'contracts/curriculum-package/v1/curriculum-ontology-profile.schema.json',
            'app/scripts/mathStageScopePolicy.ts', 'app/scripts/testMathStageScopePolicy.ts'}
sources = {r['path']: ROOT / r['candidatePath'] for r in request['codeFilesAgainstCurrentRoot']
           if r['path'] not in excluded}
for row in json.loads((OLD / 'cqs-consumer-r3-files.json').read_text()):
    sources[row['path']] = ROOT / row['candidatePath']
texts = {path: src.read_text() for path, src in sources.items()}

# One existing closed-schema/full-ledger/fingerprint implementation, shared by
# actual goal-book compilation and the actual authoring/review consumers.
bookpath = 'app/scripts/goalBookModel.ts'
book = (ROOT / bookpath).read_text()
start = book.index('const parseSemanticKindLedger = (')
end = book.index('\nconst parseGoalVisualizationQa = (', start)
parser = book[start:end]
parser = parser.replace('const parseSemanticKindLedger = (', 'export const parseSemanticKindLedger = (', 1)
parser = parser.replace('  landscapePath: string,\n',
                        '  landscapePath: string,\n  fingerprintSemanticKindSourceGoal: (goal: Record<string, unknown>) => string,\n', 1)
kindstart = book.index('const SEMANTIC_KINDS = new Set([')
kindend = book.index('\n\n', kindstart)
kinds = book[kindstart:kindend]
contractstart = book.index('export const SEMANTIC_KIND_SOURCE_FINGERPRINT_CONTRACT_ID = (')
contractend = book.index('\nconst SEMANTIC_KIND_SOURCE_FINGERPRINT_DOMAIN', contractstart)
contract = book[contractstart:contractend]
resultstart = book.index('interface SemanticKindLedgerResult {')
resultend = book.index('\n\n', resultstart)
result = book[resultstart:resultend]
shared = '''import { readFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import Ajv2020 from 'ajv/dist/2020.js'
import addFormats from 'ajv-formats'

'''+kinds+'\n\n'+contract+'\n'+result+'''

const SEMANTIC_KIND_LEDGER_SCHEMA_PATH = resolve(
  dirname(fileURLToPath(import.meta.url)),
  '../../../contracts/curriculum-package/v1/curriculum-ontology-profile.schema.json',
)
const createSchemaValidator = (schemaPath: string, includeFormats = false) => {
  const ajv = new Ajv2020({ allErrors: true, strict: true })
  if (includeFormats) addFormats(ajv)
  const schema = JSON.parse(readFileSync(schemaPath, 'utf8')) as Record<string, unknown>
  return { ajv, validate: ajv.compile(schema) }
}
let cachedSemanticKindLedgerSchemaValidator: ReturnType<typeof createSchemaValidator> | null = null
const fail = (message: string): never => { throw new Error(`Semantic-kind ledger: ${message}`) }
const asRecord = (value: unknown, label: string): Record<string, unknown> => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return fail(`${label} must be an object.`)
  return value as Record<string, unknown>
}
const nonEmptyString = (value: unknown, label: string): string => {
  if (typeof value !== 'string' || value.trim() === '') return fail(`${label} must be a non-empty string.`)
  return value.trim()
}

/** Shared authoring validator. The caller supplies the existing pinned source
 * fingerprint implementation; execution form never replaces semantic kind. */
'''+parser+'\n'
texts['app/scripts/lib/semanticKindLedger.ts'] = shared
book = book[:start]+'''const parseSemanticKindLedger = (
  value: unknown, rawLandscape: unknown, landscapeId: string, landscapePath: string,
) => validateSemanticKindLedger(value, rawLandscape, landscapeId, landscapePath,
  fingerprintSemanticKindSourceGoal)
'''+book[end:]
book = book.replace(kinds+'\n\n', '', 1).replace(result+'\n\n', '', 1)
book = book.replace(contract+'\n', '', 1)
book = book.replace("const SEMANTIC_KIND_LEDGER_SCHEMA_PATH = resolve(\n  REPOSITORY_ROOT,\n  'contracts/curriculum-package/v1/curriculum-ontology-profile.schema.json',\n)\n", '', 1)
book = book.replace('let cachedSemanticKindLedgerSchemaValidator: ReturnType<typeof createSchemaValidator> | null = null\n', '', 1)
book = "import { parseSemanticKindLedger as validateSemanticKindLedger } from './lib/semanticKindLedger'\nexport { SEMANTIC_KIND_SOURCE_FINGERPRINT_CONTRACT_ID } from './lib/semanticKindLedger'\n"+book
texts[bookpath] = book
pop = texts['app/scripts/lib/curricularReviewPopulation.ts']
pop = pop.replace("import { parseSemanticKindLedger } from '../goalBookModel'",
                  "import { fingerprintSemanticKindSourceGoal } from '../goalBookModel'\nimport { parseSemanticKindLedger } from './semanticKindLedger'")
pop = pop.replace('ledger, landscape, landscape.landscapeId, landscapePath,',
                  'ledger, landscape, landscape.landscapeId, landscapePath, fingerprintSemanticKindSourceGoal,')
texts['app/scripts/lib/curricularReviewPopulation.ts'] = pop
# Root already has the exact reviewed closed basis migration. Never hide a real
# ledger incompatibility with a transient basis-string normalization in a test.
testpath = 'app/scripts/testHardLearningRouteValidation.ts'
test = texts[testpath]
a = test.index('// These exact independently reviewed own-assessment cases')
b = test.index('freshLedger.decisions.find', a)
test = test[:a]+'''// Use the actual current closed-schema ledger without rewriting decision bases.
const freshLedger = structuredClone(ledger)
'''+test[b:]
texts[testpath] = test
# Preserve every current CI addition from the actual eight-file Root import.
workflowpath = '.github/workflows/assessment-completion.yml'
workflow = (ROOT/workflowpath).read_text()
needle = '          python3 ../scripts/test_assessment_completion_package.py\n'
assert workflow.count(needle) == 1
texts[workflowpath] = workflow.replace(needle, needle+'          python3 ../scripts/test_curricular_assessment_population.py\n')

rows, patches = [], []
for path, text in sorted(texts.items()):
    target = OUT/path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
    old = ROOT/path
    oldtext = old.read_text() if old.exists() else ''
    assert text != oldtext, path
    rows.append({'path': path, 'beforeSha256': hashlib.sha256(old.read_bytes()).hexdigest() if old.exists() else None,
                 'candidatePath': str(target.relative_to(ROOT)), 'candidateSha256': hashlib.sha256(target.read_bytes()).hexdigest()})
    patches.extend(difflib.unified_diff(oldtext.splitlines(keepends=True), text.splitlines(keepends=True),
                                      fromfile='a/'+path, tofile='b/'+path))
(HERE/'import-files.json').write_text(json.dumps(rows, indent=2)+'\n')
(HERE/'common-role.patch').write_text(''.join(patches))

# A sparse read-only dependency tree; changed leaves above are private regular
# files. No resource assets or whole backend/host is copied.
for d in ['app/scripts', 'app/scripts/lib', 'scripts']:
    (OUT/d).mkdir(parents=True, exist_ok=True)
    for src in (ROOT/d).iterdir():
        dst=OUT/d/src.name
        if not dst.exists(): dst.symlink_to(src)
for path in ['app/src', 'app/node_modules', 'app/package.json', 'app/tsconfig.scripts.json', 'contracts', 'curricula']:
    dst=OUT/path
    if not dst.exists(): dst.symlink_to(ROOT/path)
print(json.dumps({'privateImportFiles': len(rows), 'noRootWrites': True, 'noJvm': True}))
