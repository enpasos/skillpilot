import { isAuthoritativeCurricularReviewGoal, loadCurricularReviewLandscape } from './lib/curricularReviewPopulation'
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { LearningGoal, SkillLandscape } from '../src/landscapeTypes'
import { normalizeCompositionView } from '../src/utils/authoring/compositionViewAuthoring'
import { JURISDICTION_LABELS } from '../src/utils/jurisdictionMetadata'
import type { ApplicabilityEvidence } from './applicabilityCompiler'
import { buildApplicabilityCompilation } from './applicabilityCompiler'
import { collectAuthoritativeTargetAtomicGoalIds } from './compositionViewSourceCoverage'
import { createReviewedRequiresClosureCoverageChecker } from './sourceCoverageEvidence'

const scriptDir = dirname(fileURLToPath(import.meta.url))
const repoRoot = resolve(scriptDir, '../..')
const statusDir = resolve(repoRoot, 'docs/qa-ci/status')
const auditJsonPath = resolve(statusDir, 'curriculum-source-coverage-audit.json')
const auditMarkdownPath = resolve(statusDir, 'curriculum-source-coverage-audit.md')
const surrogateEvidencePath = resolve(
  repoRoot,
  'curricula/DE/Gymnasium/provenance/canonical-goal-surrogate-evidence-registry.json',
)

const TARGET_LANDSCAPE_IDS = [
  '68a8ac50-f5f5-4e24-8aa9-5e408ca01ced',
  '7f6fc60c-9fcc-4cc2-b07e-f897a1d0338a',
]

const compositionViewDirectoryByLandscapeId = new Map<string, string>([
  ['68a8ac50-f5f5-4e24-8aa9-5e408ca01ced', 'mathematik'],
  ['7f6fc60c-9fcc-4cc2-b07e-f897a1d0338a', 'physik'],
])

type CoverageStatus = 'covered' | 'partial' | 'error' | 'none'

interface GoalReference {
  goalId: string
  title: string
}

interface JurisdictionAudit {
  jurisdiction: string
  labelDe: string
  labelEn: string
  status: CoverageStatus
  viewStatus: CoverageStatus
  sourceBackedAtomicGoals: number
  surrogateBackedAtomicGoals: number
  missingSourceBackedAtomicGoals: number
  visibleAtomicGoals: number
  visibleCoveredAtomicGoals: number
  nonVisibleMissingSourceBackedAtomicGoals: number
  unsupportedAssignedAtomicGoals: number
  partialSourceLinkedAtomicGoals: number
  projectionWarnings: number
  projectionErrors: number
  missingSourceBackedAtomicGoalIds: GoalReference[]
  unsupportedAssignedAtomicGoalIds: GoalReference[]
}

interface CurriculumAudit {
  landscapeId: string
  title: string
  file: string
  totalAtomicGoals: number
  summary: CurriculumAuditSummary
  jurisdictions: JurisdictionAudit[]
}

interface CurriculumAuditSummary {
  jurisdictions: number
  coveredJurisdictions: number
  partialJurisdictions: number
  errorJurisdictions: number
  coveredViews: number
  partialViews: number
  errorViews: number
  unsupportedVisibleAtomicGoals: number
  nonVisibleMissingSourceBackedAtomicGoals: number
}

interface SourceCoverageAudit {
  schemaVersion: 1
  generatedAt: string
  generatedBy: string
  evidencePolicy: {
    sourceBackedEvidenceKinds: Array<'provenance' | 'mapping'>
    surrogateEvidenceKinds: Array<'requires-closure'>
    nonCoverageEvidenceKinds: Array<'override' | 'child-union' | 'requires-closure' | 'assessment-requires'>
  }
  curricula: CurriculumAudit[]
}

interface SurrogateEvidenceEntry {
  landscapeId?: string
  goalId?: string
  jurisdiction?: string
  evidenceType?: 'requires-closure'
  requiredByGoalId?: string
  status?: 'accepted' | 'rejected' | 'stale'
  rationale?: string
}

type CoverageReport = ReturnType<typeof buildApplicabilityCompilation>['reports'][number]
type CoverageGoalReport = CoverageReport['goals'][number]

function readLandscapeForReport(report: CoverageReport): SkillLandscape | null {
  const absolutePath = resolve(repoRoot, report.file)
  if (!existsSync(absolutePath)) return null
  return loadCurricularReviewLandscape(JSON.parse(readFileSync(absolutePath, 'utf8')) as SkillLandscape, absolutePath, repoRoot)
}

function collectFiles(directory: string): string[] {
  if (!existsSync(directory)) return []
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const absolutePath = join(directory, entry.name)
    if (entry.isDirectory()) return collectFiles(absolutePath)
    return entry.isFile() && entry.name.endsWith('.view.json') ? [absolutePath] : []
  })
}

function readAuthoritativeTargetAtomicGoalIdsByJurisdiction(
  landscape: SkillLandscape,
): Map<string, Set<string>> {
  const directoryName = compositionViewDirectoryByLandscapeId.get(landscape.landscapeId)
  if (!directoryName) return new Map<string, Set<string>>()

  const result = new Map<string, Set<string>>()
  const directory = resolve(repoRoot, 'curricula/DE/Gymnasium/composition-views', directoryName)
  for (const file of collectFiles(directory)) {
    const rawView = JSON.parse(readFileSync(file, 'utf8')) as unknown
    const view = normalizeCompositionView(rawView)
    const jurisdiction = view.scope.jurisdiction
    if (
      view.landscapeId !== landscape.landscapeId
      || typeof jurisdiction !== 'string'
      || !Object.prototype.hasOwnProperty.call(JURISDICTION_LABELS, jurisdiction)
    ) {
      continue
    }

    const targetGoalIds = result.get(jurisdiction) ?? new Set<string>()
    collectAuthoritativeTargetAtomicGoalIds(landscape, rawView)
      .forEach((goalId) => targetGoalIds.add(goalId))
    result.set(jurisdiction, targetGoalIds)
  }
  return result
}

function isMemoryGoal(goal: LearningGoal): boolean {
  const tags = goal.tags ?? []
  return goal.nodeKind === 'memory'
    || tags.includes('memorization')
    || tags.some((tag) => tag.startsWith('srs-deck:'))
}

function isPracticeOrAssessmentGoal(goal: LearningGoal): boolean {
  return (goal.tags ?? []).includes('Practice') || (goal.tags ?? []).includes('Assessment')
}

function isCurriculumSourceCoverageGoal(goal: LearningGoal | undefined): boolean {
  if (!goal) return false
  const authoritative = isAuthoritativeCurricularReviewGoal(goal)
  if (authoritative !== undefined) return authoritative
  if (isMemoryGoal(goal) || isPracticeOrAssessmentGoal(goal)) return false
  const tags = goal.tags ?? []
  if (tags.includes('Motivation') || tags.includes('Orientation')) return false
  if (goal.examData) return false
  return true
}

function hasSourceBackedJurisdictionEvidence(
  evidence: ApplicabilityEvidence,
  jurisdiction: string,
): boolean {
  return evidence.dimension === 'jurisdiction'
    && evidence.value === jurisdiction
    && (evidence.kind === 'provenance' || evidence.kind === 'mapping')
}

function hasPassgenauJurisdictionEvidence(
  evidence: ApplicabilityEvidence,
  jurisdiction: string,
): boolean {
  return evidence.dimension === 'jurisdiction'
    && evidence.value === jurisdiction
    && (evidence.kind === 'provenance' || (evidence.kind === 'mapping' && evidence.mappingStrength !== 'partial'))
}

function hasDirectSourceBackedJurisdictionEvidence(
  goal: CoverageGoalReport,
  jurisdiction: string,
): boolean {
  return goal.evidence.some((entry) => hasSourceBackedJurisdictionEvidence(entry, jurisdiction))
}

function hasPartialSourceLinkedJurisdictionEvidence(
  goal: CoverageGoalReport,
  jurisdiction: string,
): boolean {
  const matchingEvidence = goal.evidence.filter((entry) =>
    entry.dimension === 'jurisdiction' && entry.value === jurisdiction)
  return matchingEvidence.length > 0
    && !matchingEvidence.some((entry) => hasPassgenauJurisdictionEvidence(entry, jurisdiction))
    && matchingEvidence.some((entry) => entry.kind === 'mapping' && entry.mappingStrength === 'partial')
}

function surrogateEvidenceKey(landscapeId: string, goalId: string, jurisdiction: string): string {
  return [landscapeId, goalId, jurisdiction].join('|')
}

function readAcceptedSurrogateEvidenceByKey(): Map<string, SurrogateEvidenceEntry[]> {
  const entriesByKey = new Map<string, SurrogateEvidenceEntry[]>()
  if (!existsSync(surrogateEvidencePath)) return entriesByKey
  const registry = JSON.parse(readFileSync(surrogateEvidencePath, 'utf8')) as { entries?: SurrogateEvidenceEntry[] }
  for (const entry of registry.entries ?? []) {
    if (
      entry.status !== 'accepted'
      || entry.evidenceType !== 'requires-closure'
      || typeof entry.landscapeId !== 'string'
      || typeof entry.goalId !== 'string'
      || typeof entry.jurisdiction !== 'string'
      || typeof entry.requiredByGoalId !== 'string'
      || typeof entry.rationale !== 'string'
      || entry.rationale.trim().length === 0
    ) {
      continue
    }
    const key = surrogateEvidenceKey(entry.landscapeId, entry.goalId, entry.jurisdiction)
    entriesByKey.set(key, [...(entriesByKey.get(key) ?? []), entry])
  }
  return entriesByKey
}

function roundPercent(numerator: number, denominator: number): number {
  if (denominator <= 0) return 0
  return Math.round((numerator / denominator) * 1000) / 10
}

function buildCurriculumAuditSummary(jurisdictions: JurisdictionAudit[]): CurriculumAuditSummary {
  return {
    jurisdictions: jurisdictions.length,
    coveredJurisdictions: jurisdictions.filter((entry) => entry.status === 'covered').length,
    partialJurisdictions: jurisdictions.filter((entry) => entry.status === 'partial').length,
    errorJurisdictions: jurisdictions.filter((entry) => entry.status === 'error').length,
    coveredViews: jurisdictions.filter((entry) => entry.viewStatus === 'covered').length,
    partialViews: jurisdictions.filter((entry) => entry.viewStatus === 'partial').length,
    errorViews: jurisdictions.filter((entry) => entry.viewStatus === 'error').length,
    unsupportedVisibleAtomicGoals: jurisdictions.reduce(
      (sum, entry) => sum + entry.unsupportedAssignedAtomicGoals,
      0,
    ),
    nonVisibleMissingSourceBackedAtomicGoals: jurisdictions.reduce(
      (sum, entry) => sum + entry.nonVisibleMissingSourceBackedAtomicGoals,
      0,
    ),
  }
}

function pushGeneratedMarkdownNotice(lines: string[]): void {
  lines.push('> Generated artifact. Do not edit manually.')
  lines.push('>')
  lines.push('> Generated by: `app/scripts/generateCurriculumSourceCoverageAudit.ts`')
  lines.push('> Regenerate with: `cd app && npm run quality:source-coverage-audit`')
  lines.push('> Source of truth: `app/scripts/generateCurriculumSourceCoverageAudit.ts`')
  lines.push('> Source of truth: `curricula/DE/Gymnasium/canonical/`')
  lines.push('> Source of truth: `curricula/DE/Gymnasium/provenance/canonical-goal-surrogate-evidence-registry.json`')
  lines.push('')
}

function renderMarkdown(audit: SourceCoverageAudit): string {
  const lines: string[] = []
  lines.push('# Curriculum Source Coverage Audit')
  lines.push('')
  pushGeneratedMarkdownNotice(lines)
  lines.push(`Generated: ${audit.generatedAt}`)
  lines.push('')
  lines.push('This audit separates inhaltliche Abdeckung from passgenaue Zuordnung. `provenance`, reviewed `mapping` entries including `partial`, and explicitly reviewed requires-closure surrogate entries count as Lehrplan evidence; `partial` mappings remain visible as quality warnings. `override`, `child-union`, automatic `requires-closure`, and `assessment-requires` do not count as source coverage.')
  lines.push('')
  lines.push('`Covered` means direct source/mapping evidence plus explicitly accepted surrogate evidence. `Direct` excludes surrogate evidence; `Surrogate-only` is the accepted requires-closure bridge count. `View status` evaluates only learner-facing `target` atoms in authoritative jurisdiction composition views; `prerequisiteOnly` atoms and applicability inherited only through `requires-closure` outside those views are not source targets.')
  lines.push('')
  lines.push('The authoritative curricularAtomic population stays in source coverage even when a competency has an assessment execution form. Non-curricular practice/assessment, memory and orientation stay excluded. Landscapes without an authoritative ledger retain their legacy exclusions; memory traceability is handled by the separate memory-card review.')
  lines.push('')
  lines.push('The Applicability compiler supplies source evidence and projection findings; learner-facing visibility is resolved from the same composition-view target projection used by the Workbench `Curriculum Quality` counters. Those counters additionally include extracted source atoms and fully covered source original goals.')
  lines.push('')

  for (const curriculum of audit.curricula) {
    lines.push(`## ${curriculum.title}`)
    lines.push('')
    lines.push(`Source-coverage atomic goals: ${curriculum.totalAtomicGoals}`)
    lines.push(`Global status: ${curriculum.summary.coveredJurisdictions}/${curriculum.summary.jurisdictions} covered, ${curriculum.summary.partialJurisdictions} partial, ${curriculum.summary.errorJurisdictions} error.`)
    lines.push(`View status: ${curriculum.summary.coveredViews}/${curriculum.summary.jurisdictions} covered, ${curriculum.summary.partialViews} partial, ${curriculum.summary.errorViews} error.`)
    lines.push(`Unsupported visible atomic goals: ${curriculum.summary.unsupportedVisibleAtomicGoals}. Non-visible missing source-backed atomic goals: ${curriculum.summary.nonVisibleMissingSourceBackedAtomicGoals}.`)
    lines.push('')
    lines.push('| Bundesland | Status | View status | Covered | Direct | Surrogate-only | Missing | Visible | Visible covered | Unsupported visible | Partial source links | Warnings | Errors |')
    lines.push('| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |')
    for (const entry of curriculum.jurisdictions) {
      const sourcePercent = roundPercent(entry.sourceBackedAtomicGoals, curriculum.totalAtomicGoals)
      const directSourceBackedAtomicGoals = Math.max(
        0,
        entry.sourceBackedAtomicGoals - entry.surrogateBackedAtomicGoals,
      )
      lines.push(`| ${entry.jurisdiction} | ${entry.status} | ${entry.viewStatus} | ${entry.sourceBackedAtomicGoals}/${curriculum.totalAtomicGoals} (${sourcePercent}%) | ${directSourceBackedAtomicGoals} | ${entry.surrogateBackedAtomicGoals} | ${entry.missingSourceBackedAtomicGoals} | ${entry.visibleAtomicGoals} | ${entry.visibleCoveredAtomicGoals} | ${entry.unsupportedAssignedAtomicGoals} | ${entry.partialSourceLinkedAtomicGoals} | ${entry.projectionWarnings} | ${entry.projectionErrors} |`)
    }
    lines.push('')
  }

  return `${lines.join('\n')}\n`
}

function buildAudit(): SourceCoverageAudit {
  const compilation = buildApplicabilityCompilation()
  const targetIds = new Set(TARGET_LANDSCAPE_IDS)
  const surrogateEntriesByKey = readAcceptedSurrogateEvidenceByKey()
  const curricula: CurriculumAudit[] = []

  for (const report of compilation.reports) {
    if (!targetIds.has(report.landscapeId)) continue
    const landscape = readLandscapeForReport(report)
    const goalById = new Map((landscape?.goals ?? []).map((goal) => [goal.id, goal]))
    const authoritativeTargetAtomicGoalIdsByJurisdiction = landscape
      ? readAuthoritativeTargetAtomicGoalIdsByJurisdiction(landscape)
      : new Map<string, Set<string>>()
    const atomicGoals = report.goals.filter((goal) =>
      goal.goalType === 'atomic' && isCurriculumSourceCoverageGoal(goalById.get(goal.goalId)))
    const jurisdictions = report.projections.map((projection) => {
      const coverageEvidence = createReviewedRequiresClosureCoverageChecker({
        landscapeId: report.landscapeId,
        jurisdiction: projection.value,
        goals: report.goals,
        canonicalGoalById: goalById,
        surrogateEntriesByKey,
        isEligibleCanonicalGoal: isCurriculumSourceCoverageGoal,
      })
      const sourceBackedAtomicGoals = atomicGoals.filter((goal) =>
        coverageEvidence.hasCoverageBackedJurisdictionEvidence(goal))
      const surrogateBackedAtomicGoals = atomicGoals.filter((goal) =>
        !hasDirectSourceBackedJurisdictionEvidence(goal, projection.value)
        && coverageEvidence.hasReviewedRequiresClosureSurrogateEvidence(goal))
      const authoritativeTargetAtomicGoalIds = authoritativeTargetAtomicGoalIdsByJurisdiction
        .get(projection.value) ?? new Set<string>()
      const visibleAtomicGoals = atomicGoals.filter((goal) =>
        authoritativeTargetAtomicGoalIds.has(goal.goalId))
      const unsupportedAssignedAtomicGoals = visibleAtomicGoals.filter((goal) =>
        !coverageEvidence.hasCoverageBackedJurisdictionEvidence(goal))
      const visibleCoveredAtomicGoals = visibleAtomicGoals.filter((goal) =>
        coverageEvidence.hasCoverageBackedJurisdictionEvidence(goal))
      const missingSourceBackedAtomicGoals = atomicGoals.filter((goal) =>
        !coverageEvidence.hasCoverageBackedJurisdictionEvidence(goal))
      const nonVisibleMissingSourceBackedAtomicGoals = missingSourceBackedAtomicGoals.filter((goal) =>
        !authoritativeTargetAtomicGoalIds.has(goal.goalId))
      const partialSourceLinkedAtomicGoals = visibleAtomicGoals.filter((goal) =>
        hasPartialSourceLinkedJurisdictionEvidence(goal, projection.value))
      const labels = JURISDICTION_LABELS[projection.value]
      const status: CoverageStatus = projection.errors > 0 || unsupportedAssignedAtomicGoals.length > 0
        ? 'error'
        : sourceBackedAtomicGoals.length === 0
          ? 'none'
          : sourceBackedAtomicGoals.length < atomicGoals.length || projection.warnings > 0
            ? 'partial'
            : 'covered'
      const viewStatus: CoverageStatus = projection.errors > 0 || unsupportedAssignedAtomicGoals.length > 0
        ? 'error'
        : visibleAtomicGoals.length === 0
          ? 'none'
          : projection.warnings > 0
            ? 'partial'
            : 'covered'

      return {
        jurisdiction: projection.value,
        labelDe: labels.de,
        labelEn: labels.en,
        status,
        viewStatus,
        sourceBackedAtomicGoals: sourceBackedAtomicGoals.length,
        surrogateBackedAtomicGoals: surrogateBackedAtomicGoals.length,
        missingSourceBackedAtomicGoals: missingSourceBackedAtomicGoals.length,
        visibleAtomicGoals: visibleAtomicGoals.length,
        visibleCoveredAtomicGoals: visibleCoveredAtomicGoals.length,
        nonVisibleMissingSourceBackedAtomicGoals: nonVisibleMissingSourceBackedAtomicGoals.length,
        unsupportedAssignedAtomicGoals: unsupportedAssignedAtomicGoals.length,
        partialSourceLinkedAtomicGoals: partialSourceLinkedAtomicGoals.length,
        projectionWarnings: projection.warnings,
        projectionErrors: projection.errors,
        missingSourceBackedAtomicGoalIds: missingSourceBackedAtomicGoals.map((goal) => ({
          goalId: goal.goalId,
          title: goal.title,
        })),
        unsupportedAssignedAtomicGoalIds: unsupportedAssignedAtomicGoals.map((goal) => ({
          goalId: goal.goalId,
          title: goal.title,
        })),
      } satisfies JurisdictionAudit
    })

    curricula.push({
      landscapeId: report.landscapeId,
      title: report.title,
      file: report.file,
      totalAtomicGoals: atomicGoals.length,
      summary: buildCurriculumAuditSummary(jurisdictions),
      jurisdictions,
    })
  }

  return {
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    generatedBy: 'app/scripts/generateCurriculumSourceCoverageAudit.ts',
    evidencePolicy: {
      sourceBackedEvidenceKinds: ['provenance', 'mapping'],
      surrogateEvidenceKinds: ['requires-closure'],
      nonCoverageEvidenceKinds: ['override', 'child-union', 'requires-closure', 'assessment-requires'],
    },
    curricula,
  }
}

const audit = buildAudit()

function formatGoalExamples(goals: GoalReference[], limit = 5): string {
  const examples = goals.slice(0, limit).map((goal) => `${goal.goalId} (${goal.title})`)
  if (goals.length > limit) examples.push(`... +${goals.length - limit} more`)
  return examples.join(', ')
}

function collectAuditProblems(auditToCheck: SourceCoverageAudit): string[] {
  const problems: string[] = []

  for (const curriculum of auditToCheck.curricula) {
    if (curriculum.totalAtomicGoals === 0) {
      problems.push(`${curriculum.title}: no source-coverage atomic goals found.`)
    }

    for (const entry of curriculum.jurisdictions) {
      if (entry.viewStatus !== 'covered') {
        problems.push(
          `${curriculum.title} ${entry.jurisdiction}: visible projection status is ${entry.viewStatus} `
            + `(visible=${entry.visibleAtomicGoals}, covered=${entry.visibleCoveredAtomicGoals}, `
            + `unsupported=${entry.unsupportedAssignedAtomicGoals}, warnings=${entry.projectionWarnings}, `
            + `errors=${entry.projectionErrors}).`,
        )
      }

      if (entry.unsupportedAssignedAtomicGoals > 0) {
        problems.push(
          `${curriculum.title} ${entry.jurisdiction}: ${entry.unsupportedAssignedAtomicGoals} visible atomic goals `
            + `lack direct or reviewed surrogate source evidence: `
            + formatGoalExamples(entry.unsupportedAssignedAtomicGoalIds),
        )
      }

      if (entry.projectionErrors > 0) {
        problems.push(
          `${curriculum.title} ${entry.jurisdiction}: ${entry.projectionErrors} projection errors reported.`,
        )
      }
    }
  }

  return problems
}

function writeAudit(auditToWrite: SourceCoverageAudit): void {
  mkdirSync(statusDir, { recursive: true })
  writeFileSync(auditJsonPath, `${JSON.stringify(auditToWrite, null, 2)}\n`)
  writeFileSync(auditMarkdownPath, renderMarkdown(auditToWrite))
  console.log(`Wrote ${auditJsonPath}`)
  console.log(`Wrote ${auditMarkdownPath}`)
}

if (process.argv.includes('--check')) {
  const problems = collectAuditProblems(audit)
  if (problems.length > 0) {
    console.error('Curriculum source coverage audit check failed:')
    for (const problem of problems) {
      console.error(`- ${problem}`)
    }
    process.exit(1)
  }

  console.log('Curriculum source coverage audit check passed.')
} else {
  writeAudit(audit)
}
