from pathlib import Path
import hashlib,json,difflib,concurrent.futures
R=Path('/home/enpasos/projects/skillpilot');H=Path(__file__).resolve().parent
V30=R/'tmp/approach-review-20261101/he5-cuboid48-probability-two-edge-source-ref-v29-candidate-20261103-v1/producer-host'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def pin(p):return {'path':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size}
bindings=[]
for label,rel in [('rootInputs','tmp/approach-review-20261101/joint-g8-plan-activation-root-import-ss5dfd0k/current-input-hashes.json'),('rootClasses','tmp/approach-review-20261101/root-joint-g8-plan-activation-checks-20261103/current-class-hashes.json')]:
 p=R/rel;d=json.loads(p.read_text())
 def check(row):
  path,wanted=row;got=sha(R/path);return None if got==wanted else {'path':path,'expected':wanted,'actual':got}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:diff=[x for x in pool.map(check,d.items()) if x]
 assert not diff,(label,diff)
 bindings.append({'kind':label,'binding':pin(p),'actualReadFiles':len(d),'differences':diff})
(H/'root-post-static-guards.json').write_text(json.dumps({'status':'FULL_CURRENT_ROOT_GUARDBYTES_READ_EXACT_NO_WRITES','bindings':bindings},indent=2)+'\n')
code=[];patch=[]
for p in sorted((H/'code-r1').rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=str(p.relative_to(H/'code-r1'))
 if not (rel.startswith('app/scripts/') or rel.startswith('scripts/') or rel.startswith('contracts/')):continue
 assert p.stat().st_nlink==1
 before=R/rel;old=before.read_text() if before.exists() else '';new=p.read_text()
 assert old!=new,rel
 code.append({'path':rel,'beforeSha256':sha(before) if before.exists() else None,'candidatePath':str(p.relative_to(R)),'candidateSha256':sha(p),'bytes':p.stat().st_size})
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(H/'code-static-r1.patch').write_text(''.join(patch))
data=json.loads((H/'data-r2.handoff.json').read_text())
files=data['exactFiles']
for item in files:
 if item['path']=='app/scripts/config/math-country-seki-stage-policy.json':
  p=H/'data-r3'/item['path'];item.update(candidatePath=str(p.relative_to(R)),candidateSha256=sha(p),bytes=p.stat().st_size)
 assert sha(R/item['candidatePath'])==item['candidateSha256']
 assert item['beforeSha256']==(sha(V30/item['path']) if (V30/item['path']).exists() else None)
assert len({x['path'] for x in files+code})==len(files+code)
checks=[]
for name,out,err,exitcode in [
 ('existing-and-new-hard-route/population-fixtures','node-route-and-population-r4.stdout.log','node-route-and-population-r4.stderr.log',0),
 ('existing-and-new-stage-placement-fixtures','node-stage-policy-r2.stdout.log','node-stage-policy-r2.stderr.log',0),
 ('real-three-ledger-parser-and-adversarial-checks','actual-ledger-parser.stdout.log','actual-ledger-parser.stderr.log',0),
 ('independent-Python-compiler-and-validator-selector-tests','python-population.stdout.log','python-population.stderr.log',0),
 ('whole-108-role-sets-and-161-static-unions-and75-operation-replays','node-data-and-code-r2.stdout.log','node-data-and-code-r2.stderr.log',0),
 ('exploratory-all-script-typecheck-baseline','tsc-root-baseline.stdout.log','tsc-root-baseline.stderr.log',2),
 ('exploratory-all-script-typecheck-candidate','tsc-code-r1.stdout.log','tsc-code-r1.stderr.log',2),
]:checks.append({'name':name,'exitCode':exitcode,'stdout':pin(H/out),'stderr':pin(H/err)})
doc={'status':'AUTHOR_STATIC_CODE_AND_DATA_REQUEST_NOT_NATIVE_STAGE_OR_RUNTIME_APPROVAL','rootUnchangedBindings':pin(H/'root-post-static-guards.json'),
 'immutableV30BaseManifest':pin(V30.parent/'final-producer-host-input-manifest.json'),
 'codeFilesAgainstCurrentRoot':code,'codePatch':pin(H/'code-static-r1.patch'),'dataFilesAgainstFrozenV30':files,
 'dataStaticFullHandoff':pin(H/'data-r2.handoff.json'),'singleDirectCodePinSuccessor':'Only POL.nativeStageHelper.sha256 is superseded by data-r3;69 other frozen data leaves remain data-r2 bytes.',
 'separateDecisionBasisCorrection':pin(H/'decision-basis-proposal-r2/proposal.json'),
 'actualClosedParserEvidence':pin(H/'actual-ledger-parser-results.json'),
 'actualComponentAndOperationEvidence':pin(H/'actual-component-role-and-normal-operation-results.json'),
 'preciseReviewRecordsStillPending':pin(H/'pending-precise-review-record-revalidation.json'),
 'mediaProposalSeparateNotTestedOrInThisCodeDataImport':pin(H/'media-proposal-r2/request.json'),
 'checks':checks,'typecheckLimit':pin(H/'typescript-diagnostics-comparison.json'),
 'preserved':{'goalIds':1265,'curricularAtomic':807,'oldWholeExamDataCount':176,'wholeTargetRoleSetsAcross108Views':True,'staticActual161ComponentIdentityUnions':True,'same5743ExistingTargetScopes':76,'no5743ScopesOutsideOld76':True,'noCurricularQaDenominatorDrop':True,'same16_12_cap11Content':True,'noMasteryWrites':True,'frozenV30Unchanged':True},
 'actualDataDelta':{'oneExistingGoalAddsExamExecutionForm':'5743b8f9-86cb-4e24-8859-351708d070ab','fourNegativePowerRequiresRemoved':True,'oneNaturalPowerRequiresAddedAt5743':True,'wholeSupport52to50':True,'changedPhysicalViews':52,'normalOperations':74,'separateNeutralBwProducerSourceOperations':1,'wholeFiveGoalFingerprintChanges':data['exact5WholeGoalChanges'],'programPlacements':data['programPlacementDelta']},
 'pendingGates':['independent exact code/data/materialization review','specific same-ID stored-active ordinary0 explicit-assessment-start behavior; no automatic grading accepted','independent revalidation of the two stale5743 review fingerprints and requires-sensitive evidence','coordinated real Java compile/tests for media/workflow proposals','normal83+18 producer preview/check and all Source/compiler/coverage on the final combined host','actual native161 before/after on final reviewed data and runtime','independent Stage receipt and current actual Root import/nachlauf; no Root or Git authorization from this author request'],
 'noRootJvmOrNativeExecutionByThisTask':True,
 'retainedAttempts':['data-r1: author assumption that all altered viewIDs belong to101 rejected neutral BW producer source; corrected exact one separately','first route negative fixture accidentally created a disconnected cycle; retained, replaced by the existing genuine reversed-route topology','first stage fixture compared structural canonical references as atomic targets; exact atomic role contract now used and old failure retained','unmodified current ledger closed-schema failure remains preserved; correction is explicit stable enum proposal with exact historical labels','first combined-check runner used an incorrect private evidence path; no data mutation; corrected successor executed0']}
(H/'static-review-request.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'request':pin(H/'static-review-request.json'),'codeFiles':len(code),'dataFiles':len(files),'rootGuards':bindings}))
