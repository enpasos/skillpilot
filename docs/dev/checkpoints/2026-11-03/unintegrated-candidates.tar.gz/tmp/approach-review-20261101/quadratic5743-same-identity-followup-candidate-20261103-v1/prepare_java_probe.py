from pathlib import Path
import hashlib,json
R=Path('/home/enpasos/projects/skillpilot');H=Path(__file__).resolve().parent;P=H/'java-probe-r1';P.mkdir()
rel='backend/src/test/java/com/skillpilot/backend/service/AutomaticCompletionFrontierTest.java';s=(R/rel).read_text();pos=s.index('    private void readyAssessment()')
s=s[:pos]+'''    /** Same stable competency/result identity, now with an assessment execution form. */
    private void sameIdentityAssessmentForm() {
        readyAssessment();
        graph.get("B").setNodeKind("exam");
        graph.get("B").setSemanticKind("curricularAtomic");
        graph.get("B").setExamData(graph.get("Q").getExamData());
    }

    private com.skillpilot.backend.completion.CompletionCallContext sameIdentityOwner() {
        return new com.skillpilot.backend.completion.CompletionCallContext(
                "claude", "same-id-owner", Instant.now().plusSeconds(600), true);
    }

    private void recordSameIdentityObservation(String label,
            com.skillpilot.backend.api.UnifiedLearnerStateResponse state) throws Exception {
        var mapper = new ObjectMapper().findAndRegisterModules();
        var record = mapper.createObjectNode();
        record.put("syntheticFixtureNotLearnerData", true);
        record.put("scenario", label);
        record.put("activeGoalId", learner.getActiveGoalId());
        record.put("completionWorkflow", learner.getCompletionWorkflow());
        record.put("personalCurriculum", learner.getPersonalCurriculum());
        record.set("focus", mapper.valueToTree(focus));
        record.set("mastery", mapper.valueToTree(mastery));
        record.set("state", mapper.valueToTree(state));
        var out = java.nio.file.Path.of(System.getProperty("skillpilot.private.output"));
        java.nio.file.Files.writeString(out.resolve("same-identity-" + label + ".json"),
                mapper.writerWithDefaultPrettyPrinter().writeValueAsString(record));
    }

    @Test void sameIdentityExistingMasteryOneRemainsAuthoritativeAfterExamForm() throws Exception {
        sameIdentityAssessmentForm();
        mastery.put("B", 1.0);
        var owner = sameIdentityOwner();
        var state = com.skillpilot.backend.completion.CompletionCallContext.with(owner,
                () -> service.getCoachLearnerState(LEARNER));
        recordSameIdentityObservation("mastery-one", state);
        assertThat(state.levelCompletion().assessments()).anySatisfy(assessment -> {
            assertThat(assessment.goalId()).isEqualTo("B");
            assertThat(assessment.mastered()).isTrue();
        });
        assertThat(mastery).containsExactlyEntriesOf(Map.of("B", 1.0));
        verify(masteryRepository, never()).save(any());
    }

    @Test void sameIdentityStoredActiveZeroDoesNotBecomeAnAssessmentSubmission() throws Exception {
        sameIdentityAssessmentForm();
        learner.setActiveGoalId("B");
        learner.setLearningState(LearningState.TEACHING);
        var owner = sameIdentityOwner();
        var state = com.skillpilot.backend.completion.CompletionCallContext.with(owner,
                () -> service.getCoachLearnerState(LEARNER));
        recordSameIdentityObservation("stored-zero", state);
        assertThat(mastery).isEmpty();
        assertThat(state.levelCompletion().directAssessmentRunning()).isFalse();
        assertThat(learner.getCompletionWorkflow()).isNull();
        verify(masteryRepository, never()).save(any());
    }

    @Test void sameIdentityStoredOrdinaryActiveNeedsNewExplicitStartBeforeEvaluation() throws Exception {
        sameIdentityAssessmentForm();
        learner.setActiveGoalId("B");
        learner.setLearningState(LearningState.TEACHING);
        var owner = sameIdentityOwner();
        var state = com.skillpilot.backend.completion.CompletionCallContext.with(owner,
                () -> service.getCoachLearnerState(LEARNER));
        recordSameIdentityObservation("before-evaluation-without-start", state);
        var facade = new com.skillpilot.backend.ai.CoachToolFacade(service, null,
                new com.skillpilot.backend.ai.CoachStateProjection("https://skillpilot.test"), null);
        // This is a deliberate behavioral counterexample probe, not a change
        // to the runtime or a claim that the current code already refuses it.
        assertThatThrownBy(() -> com.skillpilot.backend.completion.CompletionCallContext.with(owner,
                () -> facade.getExamEvaluation(LEARNER,
                        new com.skillpilot.backend.ai.CoachToolFacade.ExamEvaluationRequest("B"))))
                .isInstanceOf(org.springframework.web.server.ResponseStatusException.class);
        assertThat(mastery).isEmpty();
        verify(masteryRepository, never()).save(any());
    }

    @Test void sameIdentityExplicitOwnedStartUsesTheNormalTaskOnlyWorkflow() throws Exception {
        sameIdentityAssessmentForm();
        learner.setActiveGoalId("B");
        learner.setLearningState(LearningState.TEACHING);
        var owner = sameIdentityOwner();
        service.startCompletionAssessment(LEARNER,
                new com.skillpilot.backend.api.CompletionAssessmentStart("automatic:personal-curriculum", "B",
                        learner.getCoachStateRevision()), "claude", owner.sessionBinding(), owner.expiresAt());
        var state = com.skillpilot.backend.completion.CompletionCallContext.with(owner,
                () -> service.getCoachLearnerState(LEARNER));
        recordSameIdentityObservation("explicit-start", state);
        assertThat(state.levelCompletion().directAssessmentRunning()).isTrue();
        assertThat(state.activeGoal().id()).isEqualTo("B");
        var safe = new com.skillpilot.backend.ai.CoachStateProjection("https://skillpilot.test").project(state);
        assertThat(safe.activeGoal().examData().getTaskContent()).isEqualTo("Assessment task.");
        assertThat(safe.activeGoal().examData().getSolutionContent()).isNull();
        assertThat(mastery).isEmpty();
        verify(masteryRepository, never()).save(any());
    }

'''+s[pos:]
p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
old=H.parent/'typed-uncovered-plan-activation-runtime-candidate-20261103-v1/TypedUncoveredActivationRuntimeLauncher.java';launcher=old.read_text();launcher=launcher.replace('TypedUncoveredActivationRuntimeLauncher','SameIdentityMediaRuntimeLauncher')
a=launcher.index('    private static final String[] SUITES = {');b=launcher.index('    public static void main',a)
launcher=launcher[:a]+'''    private static final String[] SUITES = {
        "com.skillpilot.backend.ai.CoachStateProjectionTest",
        "com.skillpilot.backend.openai.mcp.de.OpenAiDeCoachContextProjectorTest",
        "com.skillpilot.backend.ai.visiblesession.VisibleSessionServiceTest",
        "com.skillpilot.backend.connectors.claude.v1.mcp.ClaudeV1CoachContextProjectorTest",
        "com.skillpilot.backend.connectors.gemini.v1.mcp.GeminiV1CoachContextProjectorTest"
    };
    private static final String SERVICE = "com.skillpilot.backend.service.AutomaticCompletionFrontierTest";
    private static final String[] CASES = {
        "sameIdentityExistingMasteryOneRemainsAuthoritativeAfterExamForm",
        "sameIdentityStoredActiveZeroDoesNotBecomeAnAssessmentSubmission",
        "sameIdentityStoredOrdinaryActiveNeedsNewExplicitStartBeforeEvaluation",
        "sameIdentityExplicitOwnedStartUsesTheNormalTaskOnlyWorkflow"
    };

'''+launcher[b:]
a=launcher.index('        builder.selectors(selectMethod(');b=launcher.index('        launcher.execute(request);',a)
launcher=launcher[:a]+'''        for (String method : CASES) builder.selectors(selectMethod(SERVICE, method));
        var request = builder.build();
        var summary = new SummaryGeneratingListener();
        var records = new Records();
        var launcher = LauncherFactory.create();
        launcher.registerTestExecutionListeners(summary, records);
        List<String> origins = new ArrayList<>();
        Path privateClasses = Path.of(args[1]).toAbsolutePath().normalize();
        Path rootMain = Path.of(args[2]).toAbsolutePath().normalize();
        Path rootTest = Path.of(args[3]).toAbsolutePath().normalize();
        for (String name : List.of("com.skillpilot.backend.ai.CoachStateProjection",
                "com.skillpilot.backend.ai.CoachStateProjectionTest", SERVICE,
                "com.skillpilot.backend.service.LearnerService",
                "com.skillpilot.backend.service.CompositionViewService",
                "com.skillpilot.backend.ai.TaskImageTransport")) {
            Path actual = Path.of(Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();
            Path expected = name.contains("CoachStateProjection") || name.equals(SERVICE) ? privateClasses : rootMain;
            if (!expected.equals(actual)) throw new AssertionError("Unexpected class origin: " + name + " " + actual);
            origins.add(name + " " + actual);
        }
        for (String name : SUITES) {
            Path actual = Path.of(Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();
            Path expected = name.endsWith(".CoachStateProjectionTest") ? privateClasses : rootTest;
            if (!expected.equals(actual)) throw new AssertionError("Unexpected reader suite origin: " + name + " " + actual);
            origins.add(name + " " + actual);
        }
        Files.write(output.resolve("class-origins.txt"), origins);
'''+launcher[b:]
a=launcher.index('        if (exitCode == 0) {');b=launcher.index('        System.exit(exitCode);',a);launcher=launcher[:a]+launcher[b:]
(P/'SameIdentityMediaRuntimeLauncher.java').write_text(launcher)
media=json.loads((H/'media-proposal-r2/request.json').read_text())
sources=[R/x['candidatePath'] for x in media['files']]+[p,P/'SameIdentityMediaRuntimeLauncher.java']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
doc={'status':'READY_FOR_COORDINATED_PRIVATE_COMPILE_AND_DIAGNOSTIC_TEST_NOT_EXECUTED','sourceFiles':[{'path':str(q.relative_to(R)),'sha256':sha(q)} for q in sources],
 'sourceBefore':{'path':rel,'sha256':sha(R/rel)},'privateOutput':str((P/'run').relative_to(R)),
 'classpathFile':{'path':'tmp/completion-integrity-runtime-classpath.txt','sha256':sha(R/'tmp/completion-integrity-runtime-classpath.txt')},
 'javaHome':'/tmp/skillpilot-curriculum-ci-corretto-25.0.2.10.1','jvmMaxHeap':'768m','wholeReaderSuites':['com.skillpilot.backend.ai.CoachStateProjectionTest','com.skillpilot.backend.openai.mcp.de.OpenAiDeCoachContextProjectorTest','com.skillpilot.backend.ai.visiblesession.VisibleSessionServiceTest','com.skillpilot.backend.connectors.claude.v1.mcp.ClaudeV1CoachContextProjectorTest','com.skillpilot.backend.connectors.gemini.v1.mcp.GeminiV1CoachContextProjectorTest'],
 'sameIdentityCases':['sameIdentityExistingMasteryOneRemainsAuthoritativeAfterExamForm','sameIdentityStoredActiveZeroDoesNotBecomeAnAssessmentSubmission','sameIdentityStoredOrdinaryActiveNeedsNewExplicitStartBeforeEvaluation','sameIdentityExplicitOwnedStartUsesTheNormalTaskOnlyWorkflow'],
 'expectedBoundary':'No prediction of all-green. In particular evaluation-before-new-start is an intentional strict counterexample probe. Any actual failure remains a product/fixture finding to diagnose, never a relaxed expected result.',
 'fixtureMeaning':'Synthetic same stable B competency changed to curricularAtomic+exam form before first canonical graph compilation; tests actual productive LearnerService/Facade/Projection. No real learner,5743 content assessment or full submission grading claimed.',
 'runtimeClassPolicy':'Only private CoachStateProjection and two test classes plus launcher overlay. LearnerService/CVS and other reader suites must originate from current Root; no R4 focus classes mixed.',
 'rootGuardMap':'tmp/approach-review-20261101/joint-g8-plan-activation-root-import-ss5dfd0k/current-input-hashes.json','rootClassMap':'tmp/approach-review-20261101/root-joint-g8-plan-activation-checks-20261103/current-class-hashes.json'}
(P/'compile-test-plan.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n');print(sha(P/'compile-test-plan.json'))
