import assert from 'node:assert/strict'
import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs'
import {dirname,resolve} from 'node:path'
import {fileURLToPath} from 'node:url'
import {applyMathAssessmentScopeOperations} from './code-r1/app/scripts/mathStageScopePolicy'
import {collectCompositionProjectionRoleGoalIds,compileCompositionView} from '../../../app/src/utils/authoring/compositionViewAuthoring'
import {normalizeCanonicalLandscape} from '../../../app/src/utils/authoring/canonicalAuthoring'
const H=dirname(fileURLToPath(import.meta.url)),R='/home/enpasos/projects/skillpilot'
const B=resolve(R,'tmp/approach-review-20261101/he5-cuboid48-probability-two-edge-source-ref-v29-candidate-20261103-v1/producer-host'),C=resolve(H,'data-r2')
const VIEW='curricula/DE/Gymnasium/composition-views/mathematik/',CAN='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
const SRC='curricula/DE/Gymnasium/assessments/mathematik/quadratic-three-conditions-same-identity-2026-11-03-v1/author-exact-scope-and-program-operations.json'
const load=(p:string)=>JSON.parse(readFileSync(p,'utf8'))
const raw=load(resolve(C,CAN)),canonical=normalizeCanonicalLandscape(raw),goals=new Map<string,any>()
for(const name of readdirSync(resolve(B,'curricula/DE/Gymnasium/canonical')).filter(n=>n.endsWith('.json'))){
 const rel='curricula/DE/Gymnasium/canonical/'+name,doc=rel===CAN?raw:load(resolve(B,rel))
 for(const g of doc.goals)goals.set(g.id,g)
}
const source=load(resolve(C,SRC)),ops=[...source.normalOperations,...source.separateNeutralBwSourceOperations]
const oldViews=new Map<string,any>(),newViews=new Map<string,any>(),roles=new Map<string,string[]>(),proof:any[]=[]
const atomic=(s:Iterable<string>)=>[...s].filter(id=>!goals.get(id)?.contains?.length).sort()
for(const filename of readdirSync(resolve(B,VIEW)).filter(n=>n.endsWith('.json')).sort()){
 const rel=VIEW+filename,before=load(resolve(B,rel)),after=existsSync(resolve(C,rel))?load(resolve(C,rel)):before
 const a=collectCompositionProjectionRoleGoalIds(before.rootNodes,goals),b=collectCompositionProjectionRoleGoalIds(after.rootNodes,goals)
 assert.deepEqual(atomic(a.targetGoalIds),atomic(b.targetGoalIds),rel+' targets')
 assert.deepEqual(atomic(a.prerequisiteOnlyGoalIds),atomic(b.prerequisiteOnlyGoalIds),rel+' support')
 const localOps=ops.filter((x:any)=>x.viewId===before.viewId)
 if(localOps.length){
  const actual=applyMathAssessmentScopeOperations(before,goals,localOps)
  assert.deepEqual(actual,after,'Normal operation bridge differs '+rel)
  assert.deepEqual(applyMathAssessmentScopeOperations(after,goals,localOps),after,'Replay '+rel)
  const compiled=compileCompositionView(after,canonical)
  assert(!compiled.findings.some(f=>f.severity==='error'),JSON.stringify(compiled.findings))
  let occurrences=0;const walk=(ns:any[])=>{for(const n of ns){if(n.sourceGoalId==='5743b8f9-86cb-4e24-8859-351708d070ab')occurrences++;walk(n.children)}};walk(compiled.compiledRootNodes)
  assert.equal(occurrences,1,'Existing5743 must remain a single visible competency/exam')
 }
 oldViews.set(before.viewId,before);newViews.set(after.viewId,after);roles.set(before.viewId,atomic(a.targetGoalIds))
 proof.push({path:rel,viewId:before.viewId,wholeAtomicTargetsEqual:true,wholeAtomicPOnlyEqual:true,newOperationCount:localOps.length,productiveCompileAndSingle5743Checked:localOps.length>0})
}
const inventory=load(resolve(dirname(B),'static-161-pairs-108-views-and-contexts.r2.json'))
const expected=new Set([...source.earlier8AndOther68ExactPairs.rows.map((r:any)=>r.scope),...source.earlier8AndOther68ExactPairs.firstEightCarriedFromPriorIndependentReview])
assert.equal(expected.size,76)
const scopeProof=inventory.all161ScopeRows.map((row:any)=>{
 const components=row.compositionViewIds.flatMap((id:string)=>id.startsWith('merged:')?id.slice('merged:'.length).split('+'):[id])
 assert(components.every((id:string)=>oldViews.has(id)&&newViews.has(id)),'Unknown actual component '+row.scope)
 const before=[...new Set(components.flatMap((id:string)=>roles.get(id)!))].sort()
 const after=[...new Set(components.flatMap((id:string)=>atomic(collectCompositionProjectionRoleGoalIds(newViews.get(id).rootNodes,goals).targetGoalIds)))].sort()
 assert.deepEqual(after,before,'Static composition-role union differs '+row.scope)
 const has=after.includes('5743b8f9-86cb-4e24-8859-351708d070ab');assert.equal(has,expected.has(row.scope),'Exact76 boundary '+row.scope)
 return {scope:row.scope,actualReportedViewIds:row.compositionViewIds,components,hasExisting5743Target:has,wholeAtomicRoleUnionEqual:true}
})
writeFileSync(resolve(H,'actual-component-role-and-normal-operation-results.json'),JSON.stringify({status:'STATIC_PRODUCTIVE_AUTHORING_CHECK_NOT_FRESH_NATIVE_RESOLVER_OR_FULL_PRODUCER_RUN',viewCount:proof.length,scopeCount:scopeProof.length,exact5743Scopes:expected.size,other85Scopes:85,normalOperationCount:source.normalOperations.length,neutralBwSourceOperationCount:source.separateNeutralBwSourceOperations.length,
 premise:'Existing actual161 scope/component identities carried unchanged from the independently bound V30 inventory. Whole per-component atomic T/POnly sets and all old availability fields are preserved; static union equality does not claim actual merged tree/focus/eligibility/needed equality.',views:proof,scopes:scopeProof},null,2)+'\n',{flag:'wx'})
console.log('108 whole role sets, 161 static component unions, 76 existing5743 targets and75 productive exact placement replays checked.')
