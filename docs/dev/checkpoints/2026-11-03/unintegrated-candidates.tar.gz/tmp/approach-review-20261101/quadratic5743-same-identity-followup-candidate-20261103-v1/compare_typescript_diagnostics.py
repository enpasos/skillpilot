from pathlib import Path
from collections import defaultdict
import json,re,hashlib
R=Path('/home/enpasos/projects/skillpilot');H=Path(__file__).resolve().parent
def parse(p):
 rows=[]
 for line in p.read_text().splitlines():
  m=re.match(r'^(.*?)\((\d+),(\d+)\): error (TS\d+): (.*)$',line)
  if m:
   f,ln,col,code,msg=m.groups();f=f.replace(str(H/'code-r1')+'/', '').replace(str((H/'code-r1').relative_to(R))+'/', '').replace(str(R)+'/', '')
   rows.append({'file':f,'line':int(ln),'column':int(col),'code':code,'message':msg})
  elif rows:rows[-1]['message']+='\n'+line
 return rows
a=parse(H/'tsc-root-baseline.stdout.log');b=parse(H/'tsc-code-r1.stdout.log')
key=lambda x:(x['file'],x['code'],x['message'])
aa=defaultdict(list);bb=defaultdict(list)
for x in a:aa[key(x)].append({'line':x['line'],'column':x['column']})
for x in b:bb[key(x)].append({'line':x['line'],'column':x['column']})
same=[];gone=[];new=[]
for k in sorted(set(aa)|set(bb)):
 n=min(len(aa[k]),len(bb[k]));same.extend({'file':k[0],'code':k[1],'message':k[2],'rootLocation':u,'candidateLocation':v} for u,v in zip(aa[k][:n],bb[k][:n]))
 gone.extend({'file':k[0],'code':k[1],'message':k[2],'location':x} for x in aa[k][n:])
 new.extend({'file':k[0],'code':k[1],'message':k[2],'location':x} for x in bb[k][n:])
union=lambda s:set(re.findall(r'"DE-[A-Z]{2}"',s))
sameunion=(len(gone)==len(new)==1 and gone[0]['file']==new[0]['file'] and gone[0]['code']==new[0]['code'] and union(gone[0]['message'])==union(new[0]['message']))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
doc={'status':'EXACT_FILE_CODE_FULL_MESSAGE_COMPARISON_NO_TYPECHECK_PASS','rootLogSha256':sha(H/'tsc-root-baseline.stdout.log'),'candidateLogSha256':sha(H/'tsc-code-r1.stdout.log'),'rootExit':2,'candidateExit':2,'rootDiagnostics':len(a),'candidateDiagnostics':len(b),'exactMatchedDiagnostics':same,'rootOnlyExactText':gone,'candidateOnlyExactText':new,'knownRemainingDifference':{'sameFileAndCodeAndJurisdictionMembers':sameunion,'explanation':'The same applicabilityCompiler Set<string>/Iterable<jurisdiction-union> mismatch renders the same16 union members in a different order because candidate import ordering differs. Both full messages remain explicit above; this is not ignored to claim identical diagnostics or successful typecheck.'},'lineColumnShifts':[x for x in same if x['rootLocation']!=x['candidateLocation']],'lineShiftMeaning':'Added selector imports/branches shift existing diagnostics in edited files; exact messages and both locations are preserved. Unmodified dependency diagnostics remain independently visible.'}
(H/'typescript-exact-diagnostic-comparison.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exactMatches':len(same),'rootOnly':len(gone),'candidateOnly':len(new),'knownUnionOrder':sameunion,'lineColumnShifts':len(doc['lineColumnShifts']),'sha256':sha(H/'typescript-exact-diagnostic-comparison.json')}))
