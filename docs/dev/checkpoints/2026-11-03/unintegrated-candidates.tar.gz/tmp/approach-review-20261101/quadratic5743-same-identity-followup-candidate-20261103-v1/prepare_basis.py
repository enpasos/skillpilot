from pathlib import Path
import json,hashlib,copy
R=Path('/home/enpasos/projects/skillpilot');H=Path(__file__).resolve().parent
B=R/'tmp/approach-review-20261101/he5-cuboid48-probability-two-edge-source-ref-v29-candidate-20261103-v1/producer-host'
OUT=H/'decision-basis-proposal';OUT.mkdir(exist_ok=False)
SC='contracts/curriculum-package/v1/curriculum-ontology-profile.schema.json'
LED='curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json'
CAN='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
VALUE='independently-reviewed-own-assessment'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
schema=json.loads((R/SC).read_text());allowed=schema['$defs']['semanticKindDecision']['properties']['decisionBasis']['enum']
assert VALUE not in allowed
schema['$defs']['semanticKindDecision']['properties']['decisionBasis']['enum']=allowed+[VALUE]
write(OUT/SC,schema)
records=[]
for name,base in [('root',R),('v30',B)]:
 old=json.loads((base/LED).read_text());new=copy.deepcopy(old);goals={x['id']:x for x in json.loads((base/CAN).read_text())['goals']};rows=[]
 for row in new['decisions']:
  if row['decisionBasis'] in allowed:continue
  assert row['semanticKind']=='practiceAssessment' and row['decisionStatus']=='authoritative'
  assert row['decisionBasis'].startswith('independently-reviewed-own-')
  goal=goals[row['goalId']];src=goal['examData']['sourceArtifactPath'];p=base/src
  assert p.is_file()
  # Preserve complete exact historical labels and existing local evidence.
  evidence=[]
  directory=p.parent
  for q in sorted(directory.glob('*.json')):
   if any(t in q.name.lower() for t in ['review','pass','scope','decision']):
    json.loads(q.read_text());evidence.append({'path':str(q.relative_to(base)),'sha256':sha(q)})
  if 'e3-own-assessments' in src:
   for q in sorted(directory.parent.glob('*.json')):
    if any(t in q.name.lower() for t in ['review','pass','scope']):
     json.loads(q.read_text());evidence.append({'path':str(q.relative_to(base)),'sha256':sha(q)})
  rows.append({'goalId':row['goalId'],'before':row['decisionBasis'],'after':VALUE,'sourceFingerprint':row['sourceFingerprint'],'task':{'path':src,'sha256':sha(p)},'existingLocalEvidence':evidence})
  row['decisionBasis']=VALUE
 assert len(rows)==(9 if name=='root' else 10)
 for before,after in zip(old['decisions'],new['decisions']):
  assert {k:v for k,v in before.items() if k!='decisionBasis'}=={k:v for k,v in after.items() if k!='decisionBasis'}
 assert {k:v for k,v in old.items() if k!='decisions'}=={k:v for k,v in new.items() if k!='decisions'}
 write(OUT/name/LED,new)
 records.append({'lineage':name,'baseRoot':str(base.relative_to(R)) if base!=R else '.', 'canonicalSha256':sha(base/CAN),'path':LED,'beforeSha256':sha(base/LED),'candidatePath':str((OUT/name/LED).relative_to(R)),'candidateSha256':sha(OUT/name/LED),'exactChangedRows':rows})
write(OUT/'proposal.json',{'status':'PENDING_INDEPENDENT_REVIEW_NO_ROOT_OR_V30_MUTATION','stableClosedDecisionBasis':VALUE,'schemaFile':{'path':SC,'beforeSha256':sha(R/SC),'candidatePath':str((OUT/SC).relative_to(R)),'candidateSha256':sha(OUT/SC)},'lineages':records,'preserved':['all semantic kinds','counts','goal fingerprints','authoritative status','all goal objects','precise historical basis labels and cited evidence'],'noSourceCoverageOrNewContentReviewClaim':True})
print('Separate basis proposal:',sha(OUT/'proposal.json'))
