from pathlib import Path
import json,hashlib,os,difflib
R=Path('/home/enpasos/projects/skillpilot');H=Path(__file__).resolve().parent;C=H/'code-r3';C.mkdir()
rel='app/scripts/generateCurriculumQualityStatus.ts';s=(H/'code-r1'/rel).read_text()
s="import { hasHardRouteAssessmentRole } from './lib/hardLearningRouteValidation'\n"+s
needle='function terminalAutonomyGoalsForRouteScope('
s=s.replace(needle,'''function isCurricularAssessmentTerminal(goal: LearningGoal): boolean {
  return isAtomicGoal(goal)
    && isAuthoritativeCurricularReviewGoal(goal) === true
    && hasHardRouteAssessmentRole(goal, goal.semanticKind)
}

/** Curricular membership and terminal execution are independent roles. */
export function collectRouteTerminalAutonomyGoals(
  landscape: SkillLandscape, profile: Pick<RouteProfile, 'terminalAutonomyClusterIds' | 'goalSelector'>,
): LearningGoal[] {
  const byId = new Map(landscape.goals.map(goal => [goal.id, goal]))
  const configured = profile.terminalAutonomyClusterIds
    .flatMap(clusterId => byId.get(clusterId)?.contains ?? [])
    .map(id => byId.get(id))
    .filter((goal): goal is LearningGoal => !!goal && isAtomicGoal(goal) && !isMemoryGoal(goal))
  const curricular = landscape.goals.filter(profile.goalSelector).filter(isCurricularAssessmentTerminal)
  return [...new Map([...configured, ...curricular].map(goal => [goal.id, goal])).values()]
}

export function terminalAutonomyGoalsForRouteScope(''',1)
s=s.replace('  fallbackTerminalAutonomyGoals: LearningGoal[],\n): LearningGoal[] {','  fallbackTerminalAutonomyGoals: LearningGoal[],\n  actualTargetGoalIds: ReadonlySet<string>,\n): LearningGoal[] {',1)
a=s.index('  if (!clusterIds) return fallbackTerminalAutonomyGoals',s.index('export function terminalAutonomyGoalsForRouteScope'))
b=s.index('\n}\n',a)
s=s[:a]+'''  const configured = (clusterIds
    ? clusterIds.flatMap(clusterId => goalById.get(clusterId)?.contains ?? [])
      .map(goalId => goalById.get(goalId))
      .filter((goal): goal is LearningGoal => !!goal && isAtomicGoal(goal) && !isMemoryGoal(goal))
    : fallbackTerminalAutonomyGoals)
    .filter(goal => !isCurricularAssessmentTerminal(goal))
  // A protected curricular support atom never creates an independent target.
  const curricular = fallbackTerminalAutonomyGoals.filter(goal =>
    isCurricularAssessmentTerminal(goal) && actualTargetGoalIds.has(goal.id))
  return [...new Map([...configured, ...curricular].map(goal => [goal.id, goal])).values()]'''+s[b:]
old='''    const scopedTerminalGoals = terminalAutonomyGoalsForRouteScope(
      goalById,
      profile,
      view.scope,
      terminalAutonomyGoals,
    )
''';assert old in s;s=s.replace(old,'',1)
needle='      const expectedTerminalGoalIds = scopedTerminalGoals'
s=s.replace(needle,'''      const scopedTerminalGoals = terminalAutonomyGoalsForRouteScope(
        goalById, profile, view.scope, terminalAutonomyGoals, visibleTargetAtomicGoalIds,
      )
'''+needle,1)
old='''  const terminalAutonomyGoals = profile.terminalAutonomyClusterIds
    .flatMap((clusterId) => goalById.get(clusterId)?.contains ?? [])
    .map((goalId) => goalById.get(goalId))
    .filter((goal): goal is LearningGoal => !!goal)
    .filter((goal) => isAtomicGoal(goal) && !isMemoryGoal(goal))''';assert old in s;s=s.replace(old,'  const terminalAutonomyGoals = collectRouteTerminalAutonomyGoals(landscape, profile)',1)
s=s.replace('function concreteExamReadinessIssues(goal: LearningGoal): string[] {','export function concreteExamReadinessIssues(goal: LearningGoal): string[] {',1)
p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
reltest='app/scripts/testHardLearningRouteValidation.ts';t=(H/'code-r1'/reltest).read_text();t="import { collectRouteTerminalAutonomyGoals, terminalAutonomyGoalsForRouteScope, concreteExamReadinessIssues } from './generateCurriculumQualityStatus'\n"+t
t+='''
// The actual CQS global/scoped consumer sees the same competency as a terminal,
// while retaining the old duration-folder contract and all curricular members.
const cqsProfile = {
  terminalAutonomyClusterIds: [],
  terminalAutonomyClusterIdsByDurationModel: { G8: [], G9: [] },
  goalSelector: (g: {id: string}) => g.id === targetId,
}
const cqsTerminals = collectRouteTerminalAutonomyGoals(bound, cqsProfile)
assert.deepEqual(cqsTerminals.map(g => g.id), [targetId])
assert.equal(bound.goals.find(g => g.id === targetId)!.semanticKind, 'curricularAtomic')
const cqsMap = new Map(bound.goals.map(g => [g.id, g]))
for (const durationModel of ['G8', 'G9']) {
  assert.deepEqual(terminalAutonomyGoalsForRouteScope(cqsMap, cqsProfile as any, {durationModel}, cqsTerminals,
    new Set([targetId])).map(g => g.id), [targetId], 'a same-ID target remains an endpoint outside the old exam folders')
  assert.deepEqual(terminalAutonomyGoalsForRouteScope(cqsMap, cqsProfile as any, {durationModel}, cqsTerminals,
    new Set()), [], 'prerequisite-only or absent curricular assessment does not import a new obligation')
}
const ordinaryBound = bindCurricularReviewLandscape(raw, { ...freshLedger, decisions: freshLedger.decisions.map((d: any) =>
  d.goalId === targetId ? { ...d, sourceFingerprint: fingerprintSemanticKindSourceGoal(raw.goals.find((g: any) => g.id === targetId)) } : d) }, canonicalPath)
assert.deepEqual(collectRouteTerminalAutonomyGoals(ordinaryBound, cqsProfile), [], 'an ordinary endpoint is not a CQS assessment terminal')
const cqsTask = bound.goals.find(g => g.id === targetId)!
assert.deepEqual(concreteExamReadinessIssues(cqsTask), [])
const unready = { ...cqsTask, examData: { ...cqsTask.examData!, solutionContent: '' } }
assert.ok(concreteExamReadinessIssues(unready).includes('missing solutionContent'), 'selection cannot suppress the real task/rubric gate')
console.log('CQS same-ID global/scoped terminal and unready-task regressions passed.')
'''
p=C/reltest;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(t)
# Exact readonly dependency leaves, with physical writable parents.
for directory in ['app/scripts','app/scripts/lib']:
 (C/directory).mkdir(parents=True,exist_ok=True)
 for old in (R/directory).iterdir():
  if old.is_file():
   src=H/'code-r1'/directory/old.name
   if not src.exists():src=old
   dest=C/directory/old.name
   if not dest.exists():dest.symlink_to(src)
for rel in ['app/src','app/node_modules','contracts','curricula']:
 (C/rel).parent.mkdir(parents=True,exist_ok=True)
 (C/rel).symlink_to((H/'code-r1'/rel) if rel=='contracts' else R/rel,target_is_directory=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];diff=[]
for rel in ['app/scripts/generateCurriculumQualityStatus.ts',reltest]:
 before=H/'code-r1'/rel;after=C/rel
 rows.append({'path':rel,'frozenR2BeforeSha256':sha(before),'rootBeforeSha256':sha(R/rel),'candidatePath':str(after.relative_to(R)),'candidateSha256':sha(after)})
 diff.extend(difflib.unified_diff(before.read_text().splitlines(True),after.read_text().splitlines(True),fromfile='r2/'+rel,tofile='r3/'+rel))
(H/'cqs-consumer-r3.patch').write_text(''.join(diff));(H/'cqs-consumer-r3-files.json').write_text(json.dumps(rows,indent=2)+'\n')
