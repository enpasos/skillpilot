from pathlib import Path
import hashlib,json
R=Path('/home/enpasos/projects/skillpilot');H=Path(__file__).resolve().parent;C=H/'media-proposal-r1';C.mkdir()
paths=[]
def put(rel,s):
 p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
 paths.append({'path':rel,'beforeSha256':hashlib.sha256((R/rel).read_bytes()).hexdigest(),'candidatePath':str(p.relative_to(R)),'candidateSha256':hashlib.sha256(p.read_bytes()).hexdigest()})
p='backend/src/main/java/com/skillpilot/backend/ai/CoachStateProjection.java';s=(R/p).read_text();needle='        List<GoalSourceLink> resourceLinks = rewriteResourceLinks(goal.resourceLinks());'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
        // Teaching visualizations can contain worked solutions. Assessment task
        // media stay in examData/IMAGE_PATH and keep their existing transport.
        if (("exam".equalsIgnoreCase(goal.nodeKind()) || goal.examData() != null) && resourceLinks != null) {
            resourceLinks = resourceLinks.stream().filter(link -> link == null
                    || !("goal-visualization".equals(link.type())
                        || "goal-visualization".equals(link.resourceType()))).toList();
        }
''')
put(p,s)
p='backend/src/test/java/com/skillpilot/backend/ai/CoachStateProjectionTest.java';s=(R/p).read_text();needle='''        assertThat(projected.activeGoal().resourceLinks().get(1).url())
                .isEqualTo("/assets/private-visualization.png");''';assert needle in s
s=s.replace(needle,'''        assertThat(projected.activeGoal().resourceLinks()).hasSize(1);
        assertThat(projected.activeGoal().resourceLinks()).noneMatch(link -> "goal-visualization".equals(link.type()));
        assertThat(projected.stateMachine().activeGoal().resourceLinks()).hasSize(1);
        assertThat(source.activeGoal().resourceLinks()).hasSize(2);''')
pos=s.index('    private static void assertTaskOnlyExam(')
s=s[:pos]+'''    @Test
    void assessmentExecutionSuppressesOnlyWorkedGoalVisualizationsAndKeepsTaskMedia() {
        FrontierGoal raw = releasedExam("same-curricular-id");
        var state = new UnifiedLearnerStateResponse(null, null, List.of(), null, List.of(),
                List.of(), Set.of(), "TEACHING", raw,
                new StateMachineInfo("TEACHING", "teachActiveGoal", List.of(), List.of(), raw));
        var safe = projection.project(state).activeGoal();
        assertTaskOnlyExam(safe);
        assertThat(safe.resourceLinks()).singleElement().satisfies(link ->
                assertThat(link.url()).isEqualTo("https://skillpilot.test/ai-assets/reference.pdf"));
        assertThat(raw.resourceLinks()).hasSize(2);
        FrontierGoal ordinary = new FrontierGoal(raw.id(), raw.title(), raw.description(), raw.type(),
                "tutor", "curricularAtomic", raw.reason(), raw.tags(), raw.resourceLinks(),
                raw.sourceRef(), raw.sourceLicense(), raw.sourceLicenseUrl(), null, false);
        var ordinaryState = new UnifiedLearnerStateResponse(null, null, List.of(), null, List.of(),
                List.of(), Set.of(), "TEACHING", ordinary,
                new StateMachineInfo("TEACHING", "teachActiveGoal", List.of(), List.of(), ordinary));
        assertThat(projection.project(ordinaryState).activeGoal().resourceLinks()).hasSize(2);
    }

'''+s[pos:]
put(p,s)
image='app/public/assets/goal-visualizations/mathematik/5743b8f9-86cb-4e24-8859-351708d070ab/5743b8f9-86cb-4e24-8859-351708d070ab.jpg'
doc={'status':'PRIVATE_PROPOSAL_PENDING_INDEPENDENT_REVIEW_AND_COORDINATED_JVM_NOT_A_RUNTIME_PASS','hintImage':{'path':image,'sha256':hashlib.sha256((R/image).read_bytes()).hexdigest(),'visuallyRead':True,'finding':'Worked three-condition reconstruction, including(0,1)→c=1, full LGS and solved coefficients.'},'files':paths,
 'sharedOfferPath':'CoachStateProjection.rewriteGoal filters only goal-visualization links for actual exam execution form. taskContent, IMAGE_PATH headers, task image links and other resources retain their existing transport.',
 'readers':['ClaudeV1CoachContextProjector.projectContext→CoachStateProjection.project→projectGoalVisualization','GeminiV1CoachContextProjector.projectContext→CoachStateProjection.project→projectGoalVisualization','OpenAiDeCoachContextProjector.project→stateProjection.project→goalVisualization','VisibleSessionService→VisibleSessionAiStatePreparer.prepare→CoachStateProjection.project→visibleResources'],
 'rendererPath':'Claude/Gemini render_skillpilot_goal_visualization reads the context goalVisualization offer; after shared suppression no assessment offer is minted. OpenAI offer likewise absent. Actual fixed-task media use their existing separate readers.',
 'frontendExistingRule':'GoalCard.isPrimaryVisualizationVisible excludes examDataForDisplay; no UI/image edit proposed.',
 'pending':['independent source review','actual private compilation and relevant suites','same-ID stored-active workflow start boundary is a separate open check'],'noImageBytesOrRootChanges':True}
(C/'request.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
print(hashlib.sha256((C/'request.json').read_bytes()).hexdigest())
