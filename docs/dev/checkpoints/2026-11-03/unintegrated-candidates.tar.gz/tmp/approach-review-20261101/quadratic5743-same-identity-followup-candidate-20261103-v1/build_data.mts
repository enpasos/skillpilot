import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {existsSync,lstatSync,mkdirSync,readFileSync,readdirSync,writeFileSync,copyFileSync} from 'node:fs'
import {dirname,relative,resolve} from 'node:path'
import {fileURLToPath} from 'node:url'
import {fingerprintSemanticKindSourceGoal} from '../../../app/scripts/goalBookModel'
import {collectMathAtomicSupportContext,relocateReviewedMathStageTargets} from '../../../app/scripts/mathStageScopePolicy'
import {collectCompositionProjectionRoleGoalIds,compileCompositionView} from '../../../app/src/utils/authoring/compositionViewAuthoring'
import {normalizeCanonicalLandscape} from '../../../app/src/utils/authoring/canonicalAuthoring'
const R='/home/enpasos/projects/skillpilot',H=dirname(fileURLToPath(import.meta.url))
const B=resolve(R,'tmp/approach-review-20261101/he5-cuboid48-probability-two-edge-source-ref-v29-candidate-20261103-v1/producer-host')
const C=resolve(H,process.argv[2]??'data-r1');assert(!existsSync(C),'Use a new physical output')
const D=resolve(R,'tmp/approach-review-20261101/astra-quadratic-remaining-68-scope-review-20261103-v1')
const CONTENT=resolve(R,'tmp/approach-review-20261101/quadratic-three-conditions-own-task-candidate-20261103-v1')
const CAN='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json',LED='curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json'
const POL='app/scripts/config/math-country-seki-stage-policy.json',LAY='app/scripts/config/math-duration-split-spanning-tree-policy.json'
const VIEW='curricula/DE/Gymnasium/composition-views/mathematik/'
const ART='curricula/DE/Gymnasium/assessments/mathematik/quadratic-three-conditions-same-identity-2026-11-03-v1'
const ID='5743b8f9-86cb-4e24-8859-351708d070ab',LGS='546bf0b3-6921-416b-a2ef-8fd37d429dc7',POS='d658e26a-e351-4bca-824e-f346deaa87c5'
const load=(p:string)=>JSON.parse(readFileSync(p,'utf8')),hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex')
const stable=(x:any):any=>Array.isArray(x)?x.map(stable):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])])):x
const oh=(x:any)=>createHash('sha256').update(JSON.stringify(stable(x))).digest('hex')
const pin=(p:string)=>({path:relative(R,p),sha256:hash(p),bytes:readFileSync(p).length})
const reads:Record<string,string>={}
const read=(rel:string)=>{reads[rel]=hash(resolve(B,rel));return load(resolve(B,rel))}
function write(rel:string,x:any){const p=resolve(C,rel);assert(p.startsWith(C+'/'));let q=dirname(p);while(!existsSync(q))q=dirname(q);for(;;q=dirname(q)){assert(!lstatSync(q).isSymbolicLink(),'Symlink ancestor '+q);if(q==='/')break}mkdirSync(dirname(p),{recursive:true});writeFileSync(p,JSON.stringify(x,null,2)+'\n',{flag:'wx'})}
function copy(src:string,name:string){const rel=ART+'/'+name,p=resolve(C,rel);mkdirSync(dirname(p),{recursive:true});assert(!existsSync(p));copyFileSync(src,p);assert.equal(hash(p),hash(src));return rel}
assert.equal(hash(D+'/decision.json'),'b46c259bb7720a70cb12188e7626599cd20d4113d657527ba824c5437d313cc8')
assert.equal(hash(D+'/classification-followup-decision.json'),'c5d5ea722cb0fee40ff3c4ec4e406019790e30f7430678755cc53df4db8f2e09')
assert.equal(hash(D+'/separate-negative-powers-preparation-correction.json'),'3f9c73c7cdc95e9b3ded9471c50c6cf78bc31437564db1506a244d3266a4e453')
assert.equal(hash(CONTENT+'/whole-content-draft.json'),'a59a58d1099875f35cb6d9650ef90e2d0dfba2f5654103d50a9d5bc52becbaec')
const decision=load(D+'/decision.json'),classification=load(D+'/classification-followup-decision.json'),repair=load(D+'/separate-negative-powers-preparation-correction.json'),pairs=load(D+'/exact-68-task-pc-decisions.json')
const before=read(CAN),after=structuredClone(before),old=new Map<string,any>(before.goals.map((g:any)=>[g.id,g])),goals=new Map<string,any>(after.goals.map((g:any)=>[g.id,g]))
assert.deepEqual(old.get(ID),repair.goal5743)
for(const row of repair.wholeFourConsumers)assert.deepEqual(old.get(row.id),row,'Whole consumer mismatch '+row.id)
for(const edge of repair.exactFourRemovalPairs){const g=goals.get(edge.consumerGoalId);assert.equal(g.requires.filter((id:string)=>id===edge.removeRequiresGoalId).length,1);g.requires=g.requires.filter((id:string)=>id!==edge.removeRequiresGoalId)}
const draft=load(CONTENT+'/whole-content-draft.json'),task=goals.get(ID)
task.nodeKind='exam';task.examData=structuredClone(draft.examData);task.examData.reviewStatus='released';task.examData.sourceArtifactPath=ART+'/task.de.md'
assert.deepEqual(task.examData.coveredGoalIds,[ID]);task.requires=repair.necessaryPositivePowerPreservation.finalRequiresCandidate
for(const key of ['title','titleEn','description','descriptionEn','core','weight','tags','applicability','resourceLinks','type','contains','dimensionTags','shortKey'])assert.deepEqual(task[key],old.get(ID)[key])
// Program context is authored per jurisdiction/duration; no canonical phase heuristic.
const placementDelta:any[]=[]
function place(goalId:string,jurisdiction:string,durationModel:string,year:number){
 const context={jurisdiction,schoolForm:'Gymnasium',stage:'SekI',durationModel},unitId='de-gym-math-j'+year
 assert(after.programUnits.some((x:any)=>x.id===unitId))
 const matches=after.goalPlacements.filter((x:any)=>x.goalId===goalId&&x.relation==='primary'&&oh(x.context)===oh(context))
 assert(matches.length<=1,'Ambiguous primary placement');const prev=structuredClone(matches[0]??null)
 if(matches.length)matches[0].unitId=unitId;else after.goalPlacements.push({goalId,unitId,relation:'primary',context})
 placementDelta.push({goalId,context,before:prev,after:{goalId,unitId,relation:'primary',context}})
}
for(const jur of ['DE-BB','DE-BE'])for(const duration of ['G8','G9']){place(LGS,jur,duration,9);place(ID,jur,duration,10)}
place(ID,'DE-HE','G8',9);place(ID,'DE-HE','G9',9);place(LGS,'DE-HE','G9',9)
place(LGS,'DE-SL','G9',9);place(LGS,'DE-ST','G8',10);place(ID,'DE-ST','G8',10)
for(const duration of ['G8','G9'])place(LGS,'DE-RP',duration,9)
const full=new Map<string,any>()
for(const name of readdirSync(resolve(B,'curricula/DE/Gymnasium/canonical')).filter(n=>n.endsWith('.json')).sort()){
 const rel='curricula/DE/Gymnasium/canonical/'+name,doc=rel===CAN?after:read(rel)
 for(const g of doc.goals){assert(!full.has(g.id));full.set(g.id,g)}
}
const beforeFull=new Map(full);for(const g of before.goals)beforeFull.set(g.id,g)
const supportBefore=collectMathAtomicSupportContext([ID],beforeFull),supportAfter=collectMathAtomicSupportContext([ID],full)
assert.equal(supportBefore.supportUnionGoalIds.length,51);assert.equal(supportAfter.supportUnionGoalIds.length,49)
assert(supportAfter.supportUnionGoalIds.includes(POS));assert(!supportAfter.supportUnionGoalIds.includes(repair.negativePowerGoal.id))
write(CAN,after)
const ledgerBefore=read(LED),ledger=structuredClone(ledgerBefore),fpChanges:any[]=[]
for(const row of ledger.decisions){const g=old.get(row.goalId);assert.equal(row.sourceFingerprint,fingerprintSemanticKindSourceGoal(g),'Stale input FP '+row.goalId);const next=fingerprintSemanticKindSourceGoal(goals.get(row.goalId));if(next!==row.sourceFingerprint){fpChanges.push({goalId:row.goalId,before:row.sourceFingerprint,after:next});row.sourceFingerprint=next}}
assert.equal(fpChanges.length,5);assert.equal(ledger.decisions.find((x:any)=>x.goalId===ID).semanticKind,'curricularAtomic')
// Separate stable-basis repair is explicitly bound; the frozen V30 ledger stays untouched.
const basis=load(resolve(H,'decision-basis-proposal-r2/proposal.json'));const basisRows=basis.lineages.find((x:any)=>x.lineage==='v30').exactChangedRows
for(const change of basisRows){const row=ledger.decisions.find((x:any)=>x.goalId===change.goalId);assert.equal(row.decisionBasis,change.before);row.decisionBasis=change.after}
assert.deepEqual(ledger.counts,ledgerBefore.counts);write(LED,ledger)
for(const lang of ['de','en']){copy(CONTENT+`/task.${lang}.md`,`task.${lang}.md`);copy(CONTENT+`/solution-and-rubric.${lang}.md`,`solution-and-rubric.${lang}.md`)}
copy(CONTENT+'/whole-content-draft.json','reviewed-whole-content-draft.json')
copy(resolve(R,'tmp/approach-review-20261101/astra-remaining-material-scope/quadratic-three-conditions-content-review-20261103-v1/whole-content.PASS.json'),'whole-content.PASS.json')
for(const name of ['decision.json','classification-followup-decision.json','source-corridor-decisions.json','separate-negative-powers-preparation-correction.json','exact-68-task-pc-decisions.json','primary-bindings-and-read-sections.json','review.md'])copy(D+'/'+name,name)
const SRC=ART+'/author-exact-scope-and-program-operations.json',operations:any[]=[],viewDeltas:any[]=[],allViews:any[]=[]
const roots=(ns:any[]):any[]=>ns.flatMap(n=>n.kind==='structure'?[n,...roots(n.children)]:[])
const atoms=(ids:Iterable<string>)=>[...ids].filter(id=>!full.get(id)?.contains?.length).sort()
const compiled=normalizeCanonicalLandscape(after)
for(const filename of readdirSync(resolve(B,VIEW)).filter(n=>n.endsWith('.json')).sort()){
 const rel=VIEW+filename,v=read(rel),roles=collectCompositionProjectionRoleGoalIds(v.rootNodes,full);let out=structuredClone(v)
 if(!roles.targetGoalIds.has(ID)){allViews.push({path:rel,changed:false,target5743:false});continue}
 const jur=v.scope?.jurisdiction,dm=v.scope?.durationModel,structures=roots(v.rootNodes)
 const choose=(ids:string[])=>{const hits=ids.filter(id=>structures.filter(n=>n.id===id).length===1);assert(hits.length,'Missing actual program anchor '+filename+' '+ids);return hits[0]}
 let anchor:string|undefined,prepAnchor:string|undefined,label:string|undefined
 if(['DE-BB','DE-BE'].includes(jur)){anchor=choose(['j10']);prepAnchor=choose(['j9']);label='Prüfung: Quadratische Funktion aus drei Bedingungen bestimmen'}
 else if(jur==='DE-BW'){anchor=choose(['sek1']);label='Jahrgangsband 9/10: eigene Zusatzkompetenz – quadratische Funktionen aus drei Bedingungen'}
 else if(jur==='DE-HE'){anchor=choose(dm?[`j9-${dm.toLowerCase()}-kompetenzen`]:['j9-quadratics-applications','j9']);if(dm==='G9')prepAnchor=choose(['j9-g9-kompetenzen']);label='Zusatzkompetenz: drei Bedingungen (HE: Dreivariablen-Erweiterung fakultativ)'}
 else if(jur==='DE-RP'){anchor=choose(dm?[`rp-klasse9-10-msa-${dm.toLowerCase()}-kompetenzen`]:['j9-quadratics-applications','j9']);prepAnchor=anchor;label='Zusatzkompetenz: drei Bedingungen (RP: V / Vertiefung)'}
 else if(jur==='DE-SL'){anchor=choose(['j9-quadratics-applications','j9']);prepAnchor=choose(['j9']);label='Zusatzkompetenz: drei Bedingungen (SL: Vorschlag/Hinweis)'}
 else if(jur==='DE-ST'){anchor=choose(['j10']);prepAnchor=anchor;label='Prüfung: Quadratische Rekonstruktion mit drei Unbekannten (J10)'}
 else if(['DE-HB','DE-HH','DE-NI','DE-NW','DE-SN'].includes(jur)){anchor=choose(['j9-quadratics-applications','j9']);label='Eigene Zusatzkompetenz: Quadratische Funktion aus drei Bedingungen bestimmen'}
 if(!anchor){allViews.push({path:rel,changed:false,target5743:true,reason:'Earlier reviewed BY/ALL placement retained'});continue}
 const ops:any[]=[]
 if(prepAnchor){ops.push({id:'quadratic5743-preparation-'+v.viewId,viewId:v.viewId,goalIds:[LGS],action:'relocate-existing-target',anchorStructureId:prepAnchor,label:'Vorbereitung: lineare Gleichungssysteme',sourceDecision:SRC})}
 ops.push({id:'quadratic5743-terminal-'+v.viewId,viewId:v.viewId,goalIds:[ID],action:'relocate-existing-target',anchorStructureId:anchor,label,sourceDecision:SRC})
 for(const op of ops){out=relocateReviewedMathStageTargets(out,full,op.goalIds,op.anchorStructureId,op.id,op.label,op.goalIds.filter((id:string)=>id===ID))}
 const next=collectCompositionProjectionRoleGoalIds(out.rootNodes,full)
 assert.deepEqual(atoms(next.targetGoalIds),atoms(roles.targetGoalIds),'Whole target set changed '+filename)
 assert.deepEqual(atoms(next.prerequisiteOnlyGoalIds),atoms(roles.prerequisiteOnlyGoalIds),'Support role changed '+filename)
 const result=compileCompositionView(out,compiled);assert(!result.findings.some(f=>f.severity==='error'),'Compilation '+filename+' '+JSON.stringify(result.findings))
 // Exact reapplication uses the same existing authoring implementation.
 let replay=out;for(const op of ops)replay=relocateReviewedMathStageTargets(replay,full,op.goalIds,op.anchorStructureId,op.id,op.label,op.goalIds.filter((id:string)=>id===ID))
 assert.deepEqual(replay,out,'Placement replay drift '+filename)
 write(rel,out);operations.push(...ops)
 const oldStructures=roots(v.rootNodes),newStructures=roots(out.rootNodes)
 viewDeltas.push({path:rel,viewId:v.viewId,scope:v.scope,operations:ops,wholeTargetsEqual:true,wholePOnlyEqual:true,
  removedStructureReferences:oldStructures.filter(n=>!newStructures.some(m=>m.id===n.id)).map(n=>({id:n.id,wholeObject:n})),
  retainedOldStructureIds:oldStructures.filter(n=>newStructures.some(m=>m.id===n.id)).map(n=>n.id),beforeSha256:reads[rel],afterSha256:hash(resolve(C,rel))})
 allViews.push({path:rel,changed:true,target5743:true})
}
const policy=read(POL),layout=read(LAY)
const normalIds=new Set([...policy.countries.map((x:any)=>x.outputViewId),...policy.existingStageViews.map((x:any)=>x.outputViewId),...policy.durationOutputViewIds])
const normalOps=operations.filter(x=>normalIds.has(x.viewId)),separateOps=operations.filter(x=>!normalIds.has(x.viewId))
assert.equal(separateOps.length,0,'Unmanaged unexpected placement; ALL/BY are unchanged')
policy.assessmentScopeOperations.push(...normalOps)
policy.stageDecisionBindings.push({path:SRC,sha256:'PENDING_AUTHOR_FILE_HASH'})
const reserved='curricula/DE/Gymnasium/quality/source-scope-review/mathematik/2026-11-03/stage-scope-implementation-quadratic5743-same-identity.review.json'
policy.reviewReceiptPath=reserved
// All old numeric template pins remain historical, never relabeled as current output hashes.
write(SRC,{status:'AUTHOR_PROPOSAL_PENDING_INDEPENDENT_STATIC_NATIVE_SOURCE_AND_STAGE_REVIEW',goalId:ID,
 sameStableMasteryAndTargetIds:true,noNewGoalIds:true,preserveCurricularAtomicAndAllCounts:true,wholeApprovedContent:pin(CONTENT+'/whole-content-draft.json'),
 scopeDecision:pin(D+'/decision.json'),classificationDecision:pin(D+'/classification-followup-decision.json'),preparationDecision:pin(D+'/separate-negative-powers-preparation-correction.json'),
 earlier8AndOther68ExactPairs:pairs,programPlacements:placementDelta,normalOperations:normalOps,
 bwMappingLimit:{unchangedPartialMappingPointer:'/mappings/172',unchangedDecisionPointer:'/decisions/155',meaning:'Given roots to quadratic equation overlaps only partially. Own additional whole reconstruction in later9/10 is independently justified; no source coverage upgrade.'},
 optionalStatus:'HE faculty extension, RP V/Vertiefung and SL Vorschlag/Hinweis are explicitly preserved in the new local labels; no individual elective choice inferred.',
 workflowAndEvidenceGatesPending:['fresh strict fingerprints/review records for actual changed contracts','fresh full SourceCompiler/cache validation','same-ID former active ordinary exam-start and complete-submission checks','no ordinary solved goal visualization during assessment','all161 Native scope/demand/focus/path comparisons','independent normal Stage receipt'],reservedReceiptPath:reserved})
policy.stageDecisionBindings.at(-1).sha256=hash(resolve(C,SRC))
layout.inputs.sourceScopeDecisions.push({path:SRC,sha256:hash(resolve(C,SRC))})
function pins(x:any){if(!x||typeof x!=='object')return;if(!Array.isArray(x)&&typeof x.path==='string'&&typeof x.sha256==='string'&&existsSync(resolve(C,x.path)))x.sha256=hash(resolve(C,x.path));for(const v of Object.values(x))pins(v)}
pins(policy);pins(layout)
write(POL,policy);write(LAY,layout)
for(const [rel,sha]of Object.entries(reads))assert.equal(hash(resolve(B,rel)),sha,'V30 base drift '+rel)
const files:any[]=[];function collect(p:string){for(const name of readdirSync(p)){const q=resolve(p,name),s=lstatSync(q);assert(!s.isSymbolicLink());if(s.isDirectory())collect(q);else{assert(s.isFile()&&s.nlink===1);const rel=relative(C,q);files.push({path:rel,beforeSha256:existsSync(resolve(B,rel))?hash(resolve(B,rel)):null,candidatePath:relative(R,q),candidateSha256:hash(q),bytes:s.size})}}}collect(C)
writeFileSync(C+'.handoff.json',JSON.stringify({status:'STATIC_AUTHOR_CANDIDATE_PENDING_INDEPENDENT_REVIEW_NOT_NATIVE_OR_STAGE',baseRoot:relative(R,B),candidateRoot:relative(R,C),sourceBindings:[pin(D+'/decision.json'),pin(D+'/classification-followup-decision.json')],
 exactFiles:files,goalCountBefore:before.goals.length,goalCountAfter:after.goals.length,oldWholeExamDataUnchanged:before.goals.filter((g:any)=>g.examData).every((g:any)=>oh(g.examData)===oh(goals.get(g.id).examData)),
 exact5WholeGoalChanges:fpChanges,sameCurricularCounts:ledger.counts,stableBasisProposal:pin(resolve(H,'decision-basis-proposal-r2/proposal.json')),programPlacementDelta:placementDelta,
 beforeAndAfterFullAtomicSupport:{before:supportBefore,after:supportAfter},all108Views:allViews,changedViews:viewDeltas,
 normalOperations:normalOps.length,rootUnchanged:true,v30RelevantReadBindings:reads,reservedReceiptAbsent:!existsSync(resolve(C,reserved)),
 pending:['independent static code/data review','all76 scope and all85 unaffected scope actual Native checks','full before/after Source/coverage and normal83+18','current review evidence revalidation','same-ID workflow/media regression','Stage and Root approval']},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({candidate:C,files:files.length,viewChanges:viewDeltas.length,operations:normalOps.length,supportBefore:52,supportAfter:50,handoffSha256:hash(C+'.handoff.json')}))
