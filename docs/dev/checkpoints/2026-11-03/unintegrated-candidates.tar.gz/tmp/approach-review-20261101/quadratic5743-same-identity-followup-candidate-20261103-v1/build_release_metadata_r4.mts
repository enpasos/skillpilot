import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { dirname, resolve, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import { fingerprintSemanticKindSourceGoal } from '../../../app/scripts/goalBookModel'
import { concreteExamReadinessIssues, examReleaseCoverageIssues } from './code-r4/app/scripts/generateCurriculumQualityStatus'
const R='/home/enpasos/projects/skillpilot', H=dirname(fileURLToPath(import.meta.url)), C=resolve(H,'data-r4')
assert(!existsSync(C)); mkdirSync(C)
const CAN='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json', LED='curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json'
const POL='app/scripts/config/math-country-seki-stage-policy.json', LAY='app/scripts/config/math-duration-split-spanning-tree-policy.json', ID='5743b8f9-86cb-4e24-8859-351708d070ab'
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex'), load=(p:string)=>JSON.parse(readFileSync(p,'utf8'))
const pin=(p:string)=>({path:relative(R,p),sha256:hash(p)})
const before=load(resolve(H,'data-r2',CAN)), after=structuredClone(before), goal=after.goals.find((g:any)=>g.id===ID), old=before.goals.find((g:any)=>g.id===ID)
assert.deepEqual(examReleaseCoverageIssues(old),['missing coveredStrands','missing demandLevels'])
goal.examData.coveredStrands=['L1','L4']; goal.examData.demandLevels=['AB1','AB2']
assert.deepEqual(examReleaseCoverageIssues(goal),[]); assert.deepEqual(concreteExamReadinessIssues(goal),[])
const withoutMetadata=structuredClone(goal); delete withoutMetadata.examData.coveredStrands; delete withoutMetadata.examData.demandLevels
assert.deepEqual(withoutMetadata,old)
function write(rel:string,text:string){const p=resolve(C,rel);mkdirSync(dirname(p),{recursive:true});writeFileSync(p,text,{flag:'wx'})}
const writeJson=(rel:string,x:any)=>write(rel,JSON.stringify(x,null,2)+'\n')
writeJson(CAN,after)
const ledger=load(resolve(H,'data-r2',LED)), row=ledger.decisions.find((x:any)=>x.goalId===ID), prior=row.sourceFingerprint
assert.equal(prior,fingerprintSemanticKindSourceGoal(old)); row.sourceFingerprint=fingerprintSemanticKindSourceGoal(goal); assert.notEqual(row.sourceFingerprint,prior)
writeJson(LED,ledger)
const reviewed=load(resolve(R,'tmp/approach-review-20261101/astra-quadratic5743-static-code-data-r2-review-20261103-v1/two-exact-review-revalidations.PASS.json'))
const reviewChanges=[]
const normalize=(v:any)=>String(v??'').normalize('NFKC').replace(/\s+/g,' ').trim()
const stable=(x:any):string=>Array.isArray(x)?'['+x.map(stable).join(',')+']':x&&typeof x==='object'?'{'+Object.entries(x).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>JSON.stringify(k)+':'+stable(v)).join(',')+'}':JSON.stringify(x)
for(const review of reviewed.rows){
 const p=resolve(R,review.path), text=readFileSync(p,'utf8'), lines=text.split('\n'); let changed=0
 const next=lines.map((line:string)=>{if(!line)return line;const r=JSON.parse(line);if(r.goalId!==ID)return line
  assert.equal(r.fingerprint,review.oldFingerprint)
  const payload={ruleVersion:r.ruleVersion,goalId:goal.id,shortKey:goal.shortKey??'',title:normalize(goal.title),titleEn:normalize(goal.titleEn),description:normalize(goal.description),descriptionEn:normalize(goal.descriptionEn),phase:normalize(goal.dimensionTags?.phase),area:normalize(goal.dimensionTags?.area),topicCode:normalize(goal.dimensionTags?.topicCode),nodeKind:normalize(goal.nodeKind)}
  const fp='sha256:'+createHash('sha256').update(stable(payload)).digest('hex'); assert.equal(fp,review.newFingerprint)
  Object.assign(r,{fingerprint:fp,reviewer:review.reviewer,reviewedAt:review.reviewedAt,reason:review.reason}); changed++; return JSON.stringify(r)
 }).join('\n'); assert.equal(changed,1); write(review.path,next); reviewChanges.push({path:review.path,beforeSha256:hash(p),afterSha256:hash(resolve(C,review.path)),fingerprint:review.newFingerprint})
}
const changed=new Map([[CAN,hash(resolve(C,CAN))],[LED,hash(resolve(C,LED))],...reviewChanges.map(x=>[x.path,x.afterSha256])])
const rebind=(x:any)=>{if(!x||typeof x!=='object')return;if(typeof x.path==='string'&&typeof x.sha256==='string'&&changed.has(x.path))x.sha256=changed.get(x.path);for(const v of Object.values(x))rebind(v)}
for(const rel of [POL,LAY]){const p=resolve(H,rel===POL?'data-r3':'data-r2',rel), doc=load(p); rebind(doc);writeJson(rel,doc)}
writeFileSync(resolve(H,'release-metadata-r4-review-request.json'),JSON.stringify({status:'AUTHOR_METADATA_SUCCESSOR_ACTUAL_RELEASE_CHECK_PASSED_PENDING_INDEPENDENT_RECOUPLING',beforeCanonical:pin(resolve(H,'data-r2',CAN)),afterCanonical:pin(resolve(C,CAN)),exactFields:{coveredStrands:['L1','L4'],demandLevels:['AB1','AB2']},reason:{L1:'Algebraic numerical conditions and systematic solution of the three-coefficient linear system.',L4:'Quadratic functional relation reconstructed from point conditions and checked as a function.',AB1:'Substitution, arithmetic and checking explicitly given points.',AB2:'Connecting the three conditions, systematic solution and explanation of the routine algorithm.',noAB3:'No novel unstructured transfer is demanded.'},unchangedWholeGoalExceptTheseTwoFields:true,allOtherGoalsUnchanged:true,contentSolutionAndScoringExactlyUnchanged:true,actualReleaseIssuesBefore:examReleaseCoverageIssues(old),actualReleaseIssuesAfter:examReleaseCoverageIssues(goal),actualTaskReadinessAfter:concreteExamReadinessIssues(goal),semanticGoalFingerprint:{before:prior,after:row.sourceFingerprint},counts:ledger.counts,exactPreviouslyApprovedTwoReviewRows:reviewChanges,previousIndependentReview:pin(resolve(R,'tmp/approach-review-20261101/astra-quadratic5743-static-code-data-r2-review-20261103-v1/two-exact-review-revalidations.PASS.json')),requested:'Independently recouple exactly these two previously revalidated records to the actual current metadata goal; no other review row changed.',files:[CAN,LED,POL,LAY,...reviewChanges.map(x=>x.path)].map(path=>({path,candidatePath:relative(R,resolve(C,path)),candidateSha256:hash(resolve(C,path))})),codeReleaseCheckExport:pin(resolve(H,'code-r4/app/scripts/generateCurriculumQualityStatus.ts')),noJvmNativeRootStageClaim:true},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({beforeIssues:examReleaseCoverageIssues(old),afterIssues:examReleaseCoverageIssues(goal),goalFp:row.sourceFingerprint,request:pin(resolve(H,'release-metadata-r4-review-request.json'))}))
