import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFileSync,writeFileSync} from 'node:fs'
import {dirname,resolve} from 'node:path'
import {fileURLToPath} from 'node:url'
import {parseSemanticKindLedger} from './code-r1/app/scripts/goalBookModel'
const H=dirname(fileURLToPath(import.meta.url)),R='/home/enpasos/projects/skillpilot'
const CAN='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json',LED='curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json'
const B=resolve(R,'tmp/approach-review-20261101/he5-cuboid48-probability-two-edge-source-ref-v29-candidate-20261103-v1/producer-host')
const load=(p:string)=>JSON.parse(readFileSync(p,'utf8')),sha=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex')
const result:any[]=[]
for(const [label,base,ledgerPath] of [
 ['real-root-with-separate-basis-only-successor',R,resolve(H,'decision-basis-proposal-r2/root',LED)],
 ['real-v30-with-separate-basis-only-successor',B,resolve(H,'decision-basis-proposal-r2/v30',LED)],
 ['same-identity-5743-data-successor',resolve(H,'data-r2'),resolve(H,'data-r2',LED)],
]){
 const path=resolve(base,CAN),raw=load(path),ledger=load(ledgerPath)
 const parsed=parseSemanticKindLedger(ledger,raw,raw.landscapeId,CAN)
 const actual=[...parsed.semanticKindByGoalId.values()].filter(kind=>kind==='curricularAtomic').length
 assert.equal(actual,ledger.counts.curricularAtomic)
 const bad=structuredClone(ledger);bad.decisions[0].decisionBasis='free-unreviewed-value'
 assert.throws(()=>parseSemanticKindLedger(bad,raw,raw.landscapeId,CAN),/closed JSON Schema/)
 const stale=structuredClone(ledger);stale.decisions[0].sourceFingerprint='sha256:'+'0'.repeat(64)
 assert.throws(()=>parseSemanticKindLedger(stale,raw,raw.landscapeId,CAN),/stale semantic-kind decision/)
 result.push({label,canonicalPath:path,canonicalSha256:sha(path),ledgerPath,ledgerSha256:sha(ledgerPath),goals:raw.goals.length,curricularAtomic:actual,same5743Kind:parsed.semanticKindByGoalId.get('5743b8f9-86cb-4e24-8859-351708d070ab'),strictParserPassed:true,unknownBasisRejected:true,staleFingerprintRejected:true})
}
writeFileSync(resolve(H,'actual-ledger-parser-results.json'),JSON.stringify({status:'ACTUAL_INPUT_CANDIDATES_CHECKED_WITH_PROPOSED_CLOSED_SCHEMA_NO_ROOT_WRITE',schemaSha256:sha(resolve(H,'code-r1/contracts/curriculum-package/v1/curriculum-ontology-profile.schema.json')),results:result},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result.map(x=>({label:x.label,goals:x.goals,curricularAtomic:x.curricularAtomic,same5743Kind:x.same5743Kind}))))
