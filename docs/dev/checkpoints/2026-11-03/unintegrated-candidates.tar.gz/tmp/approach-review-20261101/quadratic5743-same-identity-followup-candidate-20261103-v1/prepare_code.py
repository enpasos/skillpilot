from pathlib import Path
import json, hashlib

ROOT=Path('/home/enpasos/projects/skillpilot')
HERE=Path(__file__).resolve().parent
OUT=HERE/'code-r1'
assert not OUT.exists()
OUT.mkdir()
changed=[]
def put(path,text):
    src=ROOT/path; dst=OUT/path
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_text(text)
    changed.append({'path':path,'beforeSha256':hashlib.sha256(src.read_bytes()).hexdigest() if src.exists() else None,'candidatePath':str(dst.relative_to(ROOT)),'candidateSha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
def edit(path,fn):
    old=(ROOT/path).read_text(); new=fn(old)
    assert old!=new,path
    put(path,new)

edit('app/scripts/goalBookModel.ts',lambda s:s.replace('const parseSemanticKindLedger = (','export const parseSemanticKindLedger = (',1))
put('app/scripts/lib/curricularReviewPopulation.ts', '''import { existsSync, readdirSync, readFileSync } from 'node:fs'
import { relative, resolve } from 'node:path'
import type { LearningGoal, SkillLandscape } from '../../src/landscapeTypes'
import { parseSemanticKindLedger } from '../goalBookModel'

/** Execution form does not replace the authoritative curricular classification. */
export function isAuthoritativeCurricularReviewGoal(goal: LearningGoal): boolean | undefined {
  return goal.semanticKind === undefined ? undefined : goal.semanticKind === 'curricularAtomic'
}

/** Use the existing strict ledger/schema/fingerprint validator, never unchecked tags. */
export function bindCurricularReviewLandscape(
  landscape: SkillLandscape, ledger: unknown, landscapePath: string,
): SkillLandscape {
  const { semanticKindByGoalId } = parseSemanticKindLedger(
    ledger, landscape, landscape.landscapeId, landscapePath,
  )
  return { ...landscape, goals: landscape.goals.map(goal => ({
    ...goal, semanticKind: semanticKindByGoalId.get(goal.id) as LearningGoal['semanticKind'],
  })) }
}

export function loadCurricularReviewLandscape(
  landscape: SkillLandscape, absolutePath: string, repoRoot: string,
): SkillLandscape {
  const directory = resolve(repoRoot, 'curricula/DE/Gymnasium/quality/release-model')
  if (!existsSync(directory)) return landscape
  const matches = readdirSync(directory).filter(name => name.endsWith('.semantic-kinds.json'))
    .map(name => JSON.parse(readFileSync(resolve(directory, name), 'utf8')))
    .filter(ledger => ledger.sourceLandscapeId === landscape.landscapeId)
  if (!matches.length) return landscape // Existing legacy landscapes without a ledger.
  if (matches.length !== 1) throw new Error('Ambiguous authoritative semantic-kind ledger')
  return bindCurricularReviewLandscape(landscape, matches[0], relative(repoRoot, absolutePath).replaceAll('\\\\', '/'))
}
''')
selectorfiles={
 'app/scripts/semanticAtomicityReview.ts':['isSemanticAtomicityRelevantGoal'],
 'app/scripts/memoryCardReview.ts':['isReviewRelevantGoal'],
 'app/scripts/reportMemoryCardReviewRollout.ts':['isReviewRelevantGoal'],
 'app/scripts/reportMemoryCardPilotDossier.ts':['isReviewRelevantGoal'],
 'app/scripts/generateCurriculumQualityStatus.ts':['isSemanticAtomicityRelevantGoal','isCurriculumSourceCoverageGoal'],
 'app/scripts/generateCurriculumSourceCoverageAudit.ts':['isCurriculumSourceCoverageGoal'],
}
for path,functions in selectorfiles.items():
 def change(s):
  s="import { isAuthoritativeCurricularReviewGoal, loadCurricularReviewLandscape } from './lib/curricularReviewPopulation'\n"+s
  for name in functions:
   needle=f'function {name}(goal: LearningGoal'+(' | undefined' if name=='isCurriculumSourceCoverageGoal' else '')+')'
   start=s.index(needle); opening=s.index('{',start)+1
   if name=='isCurriculumSourceCoverageGoal':
    pos=s.index('  if (!goal) return false',opening)+len('  if (!goal) return false')
   else:pos=opening
   s=s[:pos]+"\n  const authoritative = isAuthoritativeCurricularReviewGoal(goal)\n  if (authoritative !== undefined) return authoritative"+s[pos:]
  # Every actual raw landscape read in these scripts goes through the strict binding.
  import re
  s=re.sub(r'(loadJson|readJson)<SkillLandscape>\(([^\n]+)\)',r'loadCurricularReviewLandscape(\1<SkillLandscape>(\2), \2, repoRoot)',s)
  if path.endswith('generateCurriculumSourceCoverageAudit.ts'):
   s=s.replace("return JSON.parse(readFileSync(absolutePath, 'utf8')) as SkillLandscape","return loadCurricularReviewLandscape(JSON.parse(readFileSync(absolutePath, 'utf8')) as SkillLandscape, absolutePath, repoRoot)")
  # Report utilities read relative repository locators.
  if path.endswith('reportMemoryCardReviewRollout.ts') or path.endswith('reportMemoryCardPilotDossier.ts'):
   s=s.replace('), curriculum.path, repoRoot)', '), resolve(repoRoot, curriculum.path), repoRoot)')
  return s
 edit(path,change)
for path in ['scripts/compile_curriculum_release_model.py','scripts/validate_curriculum_release_model.py']:
 def change(s):
  needle='def is_review_relevant_leaf(goal: Mapping[str, Any]) -> bool:'
  pos=s.index('    tags = goal.get("tags")',s.index(needle))
  return s[:pos]+'''    # Compiled goals already carry the fingerprint-validated ledger decision.
    if goal.get("semanticKind") is not None:
        return goal["semanticKind"] == "curricularAtomic"
'''+s[pos:]
 edit(path,change)

def routes(s):
 s=s.replace('  contains?: string[]\n}', '  contains?: string[]\n  nodeKind?: string\n  examData?: unknown\n}',1)
 s=s.replace('  terminalGoalClusterIds: string[]','  terminalGoalClusterIds: string[]\n  /** Include genuine in-scope assessment forms outside the legacy exam folders. */\n  terminalGoalSelector?: (goal: TGoal) => boolean',1)
 pos=s.index('const hasPathToTarget = (')
 s=s[:pos]+'''/** Mirrors the runtime protection role; semantic membership stays independent. */
export const hasHardRouteAssessmentRole = (
  goal: HardRouteGoal, kind: HardRouteSemanticKind | undefined,
): boolean => kind === 'practiceAssessment' || goal.nodeKind?.toLowerCase() === 'exam'
  || goal.examData !== undefined && goal.examData !== null

'''+s[pos:]
 s=s.replace('const terminalIds = Array.from(new Set(profile.terminalGoalClusterIds.flatMap((clusterId) => {','const terminalIds = Array.from(new Set([...profile.terminalGoalClusterIds.flatMap((clusterId) => {')
 s=s.replace('    return collectAtomicDescendants(clusterId, goalById)\n  })))','    return collectAtomicDescendants(clusterId, goalById)\n  }), ...goals.filter(goal => profile.terminalGoalSelector?.(goal)\n    && (profile.routeGoalSelector?.(goal) ?? true)\n    && hasHardRouteAssessmentRole(goal, semanticKindByGoalId.get(goal.id))).map(goal => goal.id)]))')
 s=s.replace("semanticKindByGoalId.get(terminalId) !== 'practiceAssessment'","!hasHardRouteAssessmentRole(terminal, semanticKindByGoalId.get(terminalId))")
 s=s.replace('atomic semanticKind=practiceAssessment goal','atomic assessment (semanticKind=practiceAssessment or actual assessment execution form) goal')
 s=s.replace(".filter((goal) => isAtomic(goal) && semanticKindByGoalId.get(goal.id) === 'curricularAtomic')",".filter((goal) => isAtomic(goal) && semanticKindByGoalId.get(goal.id) === 'curricularAtomic'\n      && !hasHardRouteAssessmentRole(goal, semanticKindByGoalId.get(goal.id)))")
 s=s.replace('if (ROUTE_ORDER[requiredKind] <= ROUTE_ORDER[goalKind]) continue',"const goalOrder = hasHardRouteAssessmentRole(goal, goalKind) ? 2 : ROUTE_ORDER[goalKind]\n      const requiredOrder = hasHardRouteAssessmentRole(goalById.get(requiredId)!, requiredKind) ? 2 : ROUTE_ORDER[requiredKind]\n      if (requiredOrder <= goalOrder) continue")
 return s
edit('app/scripts/lib/hardLearningRouteValidation.ts',routes)
edit('app/scripts/validateGraph.ts',lambda s:s.replace('  validateHardDirectAtomicRoutes,','  validateHardDirectAtomicRoutes,\n  hasHardRouteAssessmentRole,',1).replace('    terminalGoalClusterIds: CANONICAL_GYM_MATH_SEK1_EXAM_FOLDER_IDS,','    terminalGoalClusterIds: CANONICAL_GYM_MATH_SEK1_EXAM_FOLDER_IDS,\n    terminalGoalSelector: (goal) => hasHardRouteAssessmentRole(goal, canonicalMathSemanticKindByGoalId.get(goal.id)),',1).replace('    terminalGoalClusterIds: CANONICAL_GYM_MATH_SEK2_PRACTICE_CLUSTER_IDS,','    terminalGoalClusterIds: CANONICAL_GYM_MATH_SEK2_PRACTICE_CLUSTER_IDS,\n    terminalGoalSelector: (goal) => hasHardRouteAssessmentRole(goal, canonicalMathSemanticKindByGoalId.get(goal.id)),',1))
(HERE/'code-r1-files.json').write_text(json.dumps(changed,indent=2)+'\n')
print('Prepared',len(changed),'private code files')
