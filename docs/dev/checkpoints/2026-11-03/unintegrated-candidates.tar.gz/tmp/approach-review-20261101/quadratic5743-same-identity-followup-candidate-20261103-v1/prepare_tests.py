from pathlib import Path
import json,hashlib,os
ROOT=Path('/home/enpasos/projects/skillpilot');HERE=Path(__file__).resolve().parent;OUT=HERE/'code-r1'
path='app/scripts/testHardLearningRouteValidation.ts';s=(ROOT/path).read_text()
s="import { readFileSync } from 'node:fs'\nimport { bindCurricularReviewLandscape, isAuthoritativeCurricularReviewGoal } from './lib/curricularReviewPopulation'\nimport { fingerprintSemanticKindSourceGoal } from './goalBookModel'\n"+s
s+='''
// An assessment execution form can assess the same authoritative curricular atom.
const curricularExam = { id: 'curricular-exam', nodeKind: 'exam', contains: [], requires: ['understand-b'],
  examData: { taskContent: '1. Solve.', solutionContent: 'Complete solution.', reviewStatus: 'released',
    scoring: { maxPoints: 2, passingPoints: 1, steps: [{ id: 'a', points: 2, description: 'Solve.' }] } } }
const sameIdentityGoals = [...goals.filter(g => !g.id.startsWith('exam-')), curricularExam]
const sameIdentityKinds = new Map(kinds).set('curricular-exam', 'curricularAtomic')
const sameIdentityProfile = { ...profile, terminalGoalClusterIds: [],
  goalSelector: (g: HardRouteGoal) => ['understand-a', 'understand-b', 'curricular-exam'].includes(g.id),
  terminalGoalSelector: (g: HardRouteGoal) => g.nodeKind === 'exam' || g.examData != null }
assert.deepEqual(validateHardDirectAtomicRoutes(sameIdentityGoals, sameIdentityKinds, sameIdentityProfile), [])
assert.ok(validateHardDirectAtomicRoutes(sameIdentityGoals.map(g => g.id === curricularExam.id
  ? { ...g, nodeKind: undefined, examData: undefined, title: 'Exam in the title' } : g), sameIdentityKinds, sameIdentityProfile)
  .some(f => f.message.includes('No atomic terminal')), 'an ordinary endpoint/title is not a terminal')
assert.ok(validateHardDirectAtomicRoutes(sameIdentityGoals, sameIdentityKinds, { ...sameIdentityProfile,
  routeGoalSelector: g => g.id !== curricularExam.id }).some(f => f.message.includes('terminal')),
  'an out-of-scope assessment cannot close this scope')
assert.ok(validateHardDirectAtomicRoutes(sameIdentityGoals.filter(g => !g.id.startsWith('understand-'))
  .map(g => g.id === curricularExam.id ? { ...g, requires: ['orientation-seki'] } : g), sameIdentityKinds,
  { ...sameIdentityProfile, goalSelector: g => g.id === curricularExam.id })
  .some(f => f.message.includes('ordinary curricular')), 'zero-length self-reach is not ordinary preparation')
assert.ok(validateHardDirectAtomicRoutes(sameIdentityGoals.map(g => g.id === 'understand-a'
  ? { ...g, requires: [] } : g), sameIdentityKinds, sameIdentityProfile)
  .some(f => f.message.includes('motivation')), 'motivation remains necessary')
assert.ok(validateHardDirectAtomicRoutes(sameIdentityGoals.map(g => g.id === 'understand-b'
  ? { ...g, requires: [curricularExam.id] } : g), sameIdentityKinds, sameIdentityProfile)
  .some(f => f.message.includes('Route order is reversed')), 'curricular membership does not lower the assessment execution role')

// Test the existing strict schema+fingerprint ledger parser on whole real input,
// with transient copies only. No stale evidence or changed counts are accepted.
const canonicalPath = 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
const raw = JSON.parse(readFileSync(new URL('../../'+canonicalPath, import.meta.url), 'utf8'))
const ledger = JSON.parse(readFileSync(new URL('../../curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json', import.meta.url), 'utf8'))
const targetId = '5743b8f9-86cb-4e24-8859-351708d070ab'
const edited = structuredClone(raw)
const goal = edited.goals.find((g: {id: string}) => g.id === targetId)
Object.assign(goal, { nodeKind: 'exam', examData: curricularExam.examData })
const freshLedger = structuredClone(ledger)
freshLedger.decisions.find((d: {goalId: string}) => d.goalId === targetId).sourceFingerprint = fingerprintSemanticKindSourceGoal(goal)
const bound = bindCurricularReviewLandscape(edited, freshLedger, canonicalPath)
assert.equal(isAuthoritativeCurricularReviewGoal(bound.goals.find(g => g.id === targetId)!), true)
assert.equal(bound.goals.filter(g => isAuthoritativeCurricularReviewGoal(g)).length, ledger.counts.curricularAtomic,
  'the complete curricular denominator is preserved exactly')
assert.throws(() => bindCurricularReviewLandscape(edited, ledger, canonicalPath), /stale semantic-kind decision/)
assert.throws(() => bindCurricularReviewLandscape(edited, { ...freshLedger, counts: { ...freshLedger.counts, curricularAtomic: 0 } }, canonicalPath), /count/)
assert.equal(isAuthoritativeCurricularReviewGoal({ ...goal, semanticKind: 'practiceAssessment' }), false)
assert.equal(isAuthoritativeCurricularReviewGoal({ ...goal, semanticKind: 'orientation' }), false)
assert.equal(isAuthoritativeCurricularReviewGoal({ ...goal, semanticKind: 'memory' }), false)
assert.equal(isAuthoritativeCurricularReviewGoal({ ...goal, semanticKind: undefined }), undefined,
  'the existing legacy selector remains in charge without an authoritative decision')
console.log('Same-identity curricular assessment route and population regressions passed.')
'''
# The script is located in app/scripts; repository root is ../.. .
s=s.replace("new URL('../../'+canonicalPath", "new URL('../../'+canonicalPath")
p=OUT/path;p.write_text(s)
files=json.loads((HERE/'code-r1-files.json').read_text());files.append({'path':path,'beforeSha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest(),'candidatePath':str(p.relative_to(ROOT)),'candidateSha256':hashlib.sha256(p.read_bytes()).hexdigest()});(HERE/'code-r1-files.json').write_text(json.dumps(files,indent=2)+'\n')
# Thin read-only dependency leaves; every writable path has physical parents.
for rel in ['app/scripts','app/scripts/lib']:
 for source in (ROOT/rel).iterdir():
  if source.is_file():
   target=OUT/rel/source.name
   if not target.exists():target.symlink_to(source)
for rel in ['app/src','app/node_modules','contracts','curricula']:
 p=OUT/rel;p.parent.mkdir(parents=True,exist_ok=True);p.symlink_to(ROOT/rel,target_is_directory=True)
