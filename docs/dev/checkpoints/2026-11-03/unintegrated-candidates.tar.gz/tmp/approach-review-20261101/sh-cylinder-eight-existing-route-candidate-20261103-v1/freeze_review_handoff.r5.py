from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path('/home/enpasos/projects/skillpilot')
HERE = Path(__file__).resolve().parent
CANDIDATE = HERE / 'candidate-r5'
HOST = HERE / 'producer-host-r5'
CAN = 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
TASK = '3045f00d-a5b9-547c-b568-593aeac9ffa3'
VIEW_PREFIX = 'curricula/DE/Gymnasium/composition-views/mathematik'
AREA = '491e0858-e977-516e-a339-1cc2f9e9690f'
UNITS = '57fbbf31-9b8c-5408-9af5-fbc73acd12bb'
CONTAINER = 'reviewed-stage-additions-de-sh'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pin(path):
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(path),
            'bytes': path.stat().st_size}


spec = importlib.util.spec_from_file_location(
    'existing_finite_host_method', HERE / 'prepare_producer_host.r5.py')
method = importlib.util.module_from_spec(spec)
spec.loader.exec_module(method)
method.guard()
request = read(CANDIDATE / 'materialization-review-request.json')
payload = request['approvedImportFilesNotYetApprovedByIndependentMaterializationReview']
assert len(payload) == 12
for entry in payload:
    private, live = CANDIDATE / entry['path'], ROOT / entry['path']
    assert sha(private) == entry['candidateSha256']
    assert private.is_file() and not private.is_symlink() and private.stat().st_nlink == 1
    assert (sha(live) if live.exists() else None) == entry['beforeSha256'], entry['path']
manifest4 = read(HERE / 'producer-host-r4-input-manifest.json')['files']
manifest5 = read(HERE / 'producer-host-r5-input-manifest.json')['files']
assert set(manifest4) == set(manifest5)
changed = [rel for rel in sorted(manifest5) if manifest4[rel] != manifest5[rel]]
assert len(changed) == 9
assert all('/composition-views/' in rel or rel.startswith('app/scripts/config/')
           or rel.endswith('/author-source-and-exact-operations.json') for rel in changed)
for rel, digest in manifest5.items():
    assert sha(HOST / rel) == digest, ('host drift', rel)
before = {g['id']: g for g in read(ROOT / CAN)['goals']}
after = {g['id']: g for g in read(CANDIDATE / CAN)['goals']}
assert len(before) == len(after) == 1265 and set(before) == set(after)
assert [gid for gid in before if before[gid] != after[gid]] == [TASK]
assert {k: v for k, v in before[TASK].items() if k != 'applicability'} == {
    k: v for k, v in after[TASK].items() if k != 'applicability'}
assert len([g for g in before.values() if 'examData' in g]) == 176
assert all(before[gid].get('examData') == after[gid].get('examData') for gid in before)
assert sha(CANDIDATE / CAN) == sha(HERE / 'candidate-r4' / CAN)
assert not (CANDIDATE / request['stageReceipt']['path']).exists()
assert not (HOST / request['stageReceipt']['path']).exists()
normal = read(HERE / 'normal-fixpoint-r5-terminal.json')
assert normal['allTwoCommandsExecutedExitZero'] and normal['all101NormalOutputsWholeBytesEqual']
assert len(normal['sevenViewsOutsideNormal101']) == 7
assert all(v['wholeBytesEqualRoot'] for v in normal['sevenViewsOutsideNormal101'])


def find(nodes, identifier):
    for node in nodes:
        if node.get('id') == identifier:
            return node
        nested = find(node.get('children', []), identifier)
        if nested is not None:
            return nested
    return None


def direct_entry_members(node):
    assert node is not None
    entries = node.get('children', [])
    assert all(n['kind'] == 'goalEntry' for n in entries)
    return sorted(n['goalId'] for n in entries)


focus = []
for duration in ['g8', 'g9']:
    rel = f'{VIEW_PREFIX}/de-sh-seki-{duration}.view.json'
    old_node = find(read(ROOT / rel)['rootNodes'], CONTAINER)
    new_node = find(read(CANDIDATE / rel)['rootNodes'], CONTAINER)
    old_members, new_members = direct_entry_members(old_node), direct_entry_members(new_node)
    assert len(old_members) == 24 and len(new_members) == 22
    assert set(old_members) - set(new_members) == {AREA, UNITS}
    assert set(new_members) <= set(old_members)
    focus.append({'viewPath': rel, 'storedFocusId': CONTAINER,
                  'rootView': pin(ROOT / rel), 'candidateView': pin(CANDIDATE / rel),
                  'wholePriorMemberGoalIds': old_members, 'wholeAfterMemberGoalIds': new_members,
                  'removedFromThisSurvivingContainerOnly': [AREA, UNITS],
                  'staticAuthoredEntryFactNotAResolvedRuntimeOrPublicReadProbe': True})

method.guard()
report = {
    'status': 'PRIVATE_SH_R5_DATA_SOURCE_AND_NORMAL_PREVIEW_HANDOFF_REVIEW_REQUIRED',
    'candidateRoot': str(CANDIDATE.relative_to(ROOT)),
    'producerHost': str(HOST.relative_to(ROOT)),
    'candidateRequest': pin(CANDIDATE / 'materialization-review-request.json'),
    'exact12PayloadFiles': payload,
    'rootInputMap': pin(method.INPUTS), 'rootClassMap': pin(method.CLASSES),
    'rootActualCounts': {'inputs': 9550, 'mainClasses': 947, 'testClasses': 428},
    'physicalHostManifest': pin(HERE / 'producer-host-r5-input-manifest.json'),
    'finiteHostPreparationSource': pin(HERE / 'prepare_producer_host.r5.py'),
    'normalPreviewRunner': pin(HERE / 'run_normal_fixpoint.r5.py'),
    'actualNormalPreviewTerminal': pin(HERE / 'normal-fixpoint-r5-terminal.json'),
    'all101NormalOutputsWholeBytesEqual': True,
    'all108InputViewHashesBound': True,
    'allSevenOutsideNormal101WholeRootEqual': True,
    'sixNormalOutputsAdoptionWholeSemanticVerification': pin(
        CANDIDATE / 'normal-output-adoption-verification.json'),
    'retainedR4WholeSource21AndSourceCoverageExecution': pin(
        HERE / 'source-and-previews-r4-terminal.json'),
    'retainedR4Source21Archive': pin(HERE / 'fresh-sh-source21-r4.json.gz'),
    'retainedR4FullSource21Facts': pin(HERE / 'fresh-sh-source21-r4-facts.json'),
    'sourceEvidenceCarryforward': {
        'actualR4CommandsExitCodes': [0, 0, 0, 0],
        'r4ToR5WholeHostPathsAddedOrRemoved': [],
        'r4ToR5ExactChangedWholeHostPaths': changed,
        'allCanonRegistryMappingCompilerAndSourceArtifactBytesEqual': True,
        'notClaimedAsNewR5CompilerExecution': True,
        'legacyCopiedRequestFieldClarification':
            'cachedTaskApplicability15To16StoredButFullCompilerComparisonPending is an inherited R4 '
            'construction-time field; the later actual full21 R4 execution proves the exact cache '
            'comparison. This handoff binds that execution without rewriting old request bytes.'},
    'wholeCanonDelta': {'onlyChangedGoalId': TASK, 'onlyChangedField': 'applicability',
                       'jurisdictionCountBefore': 15, 'jurisdictionCountAfter': 16,
                       'addedJurisdictionOnly': 'DE-SH',
                       'all1265GoalIdsStable': True,
                       'all176WholeExamDataAndAllRequiresCoverageTagsCoreUnchanged': True,
                       'semanticLedgerUnchanged': request['semanticLedgerBytesUnchanged']},
    'fullTaskScopePredictionNotNative': request['exactSelectedTaskPcPrediction'],
    'full161PredictedSetsAnd44PreparationAtoms': request['scopeWholeFacts'],
    'bothOpenFocusCases': {
        'survivingAuthoredStageContainer': focus,
        'oldRemovedCanonicalJ8FocusId': '5fb3ee61-059c-47f4-8c6f-7285d7982a41',
        'replacementAuthoredStructureId':
            'reviewed-stage-split-5fb3ee61-059c-47f4-8c6f-7285d7982a41',
        'requiredFutureActualProbe': 'Real Overview/PersonalizationPlanner committed SH state, '
            'the complete candidate canonical cache and views, positive eight offers / negative69, '
            'whole resolved focus members, stored IDs, already active ordinary and strict recall '
            'continuation, explicit reselection and no widening or mastery side writes.',
        'noActualNativeOrPublicReadPassClaimed': True},
    'historicalFailuresPreserved': {
        'r2R3BadCompileApi': pin(HERE / 'data-freeze-r4.json'),
        'r3DurationDuplicateFailure': pin(HERE / 'source-and-previews-terminal.json'),
        'r4SixNormalRepresentationDifferences': pin(HERE / 'source-and-previews-r4-terminal.json'),
        'r5UsesWholeNormalOutputsRatherThanExpectedHashRelaxation': True},
    'stageReceipt': request['stageReceipt'],
    'all12OwnedPayloadLeavesRegularSingleLink': True,
    'rootInputsClassesHostAndCandidateActuallyVerifiedBeforeAfter': True,
    'noJvmRootSourceDataClassGitLearnerOrProductionMutation': True,
    'holds': ['Independent materialization/source/producer review pending.',
              'Limited actual native scope and both public-focus probes pending.',
              'A genuine Stage receipt is reserved and absent; no import authorization claimed.'],
    'source': pin(Path(__file__).resolve()),
}
target = HERE / 'review-handoff-r5.json'
assert not target.exists()
target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'handoff': pin(target), 'request': report['candidateRequest'],
                  'all101Equal': True, 'payloadFiles': 12, 'stageOrNativePass': False}))
