from pathlib import Path
import hashlib, json, os, shutil, stat, tempfile, time

R = Path('/home/enpasos/projects/skillpilot')
H = Path(__file__).resolve().parent
C, HOST = H/'candidate-r4', H/'producer-host-r4'
INPUTS = R/'tmp/approach-review-20261101/assessment-start-root-import-a0z2l_5w/current-input-hashes.json'
CLASSES = R/'tmp/approach-review-20261101/assessment-start-actual-root-20261103/actual-root/current-class-hashes.json'
DISCOVERY = R/'tmp/approach-review-20261101/he5-cuboid48-probability-two-edge-source-ref-v29-candidate-20261103-v1/final-producer-host-input-manifest.json'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def pin(p):
    return {'path':str(p.relative_to(R)), 'sha256':sha(p), 'bytes':p.stat().st_size}

def private_parent(path):
    assert HOST.is_dir() and not HOST.is_symlink()
    assert path.is_relative_to(HOST)
    current = HOST
    for name in path.relative_to(HOST).parts[:-1]:
        current = current/name
        if current.exists() or current.is_symlink():
            info = current.lstat()
            assert stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode), current
        assert current.resolve().is_relative_to(HOST), current

def sync_leaf(src, dst):
    private_parent(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    private_parent(dst)
    fd, name = tempfile.mkstemp(prefix='.owned-',dir=dst.parent)
    try:
        with os.fdopen(fd, 'wb') as out: out.write(src.read_bytes())
        assert sha(Path(name)) == sha(src)
        private_parent(dst)
        os.replace(name, dst)
        assert dst.is_file() and not dst.is_symlink() and dst.stat().st_nlink == 1
    finally:
        if Path(name).exists(): Path(name).unlink()

def guard():
    inputs, classes = read(INPUTS), read(CLASSES)
    assert len(inputs) == 9550
    assert len(classes) == 1375
    for rel, digest in inputs.items(): assert sha(R/rel) == digest, ('Root input drift', rel)
    actual = {str(p.relative_to(R)):sha(p) for kind in ['main','test'] for p in (R/('backend/build/classes/java/'+kind)).rglob('*.class')}
    assert actual == classes, 'Root class drift'
    return inputs, classes

if __name__ == '__main__':
    assert not HOST.exists()
    inputs, classes = guard()
    frozen = read(C/'materialization-review-request.json')
    payload = frozen['approvedImportFilesNotYetApprovedByIndependentMaterializationReview']
    assert len(payload) == 12
    assert sha(INPUTS) == 'f28a62364912c4205623d8f11579ccef4222c27c9d701b52c5a552eb00b26fa5'
    assert sha(CLASSES) == 'f44a526c16051fc38bd2e0f9aeaadd8f4510006d652e77db8a101e87a67ca4ad'
    assert sha(DISCOVERY) == '73fc4e4bd8c65068f92b2c612a620c2e1ca6629a249b7238b8e63f53cd3fe698'
    assert len(read(DISCOVERY)['files']) == 10579
    for f in payload: assert sha(C/f['path']) == f['candidateSha256']
    HOST.mkdir()
    # Reuse the already reviewed finite discovery inventory. Do not recurse
    # through Root/curricula private experiment aliases or the entire repository.
    paths = {p for p in set(read(DISCOVERY)['files']) | set(inputs) if not p.startswith('app/src/')}
    paths.update('app/scripts/'+p.name for p in (R/'app/scripts').glob('*.ts'))
    paths.update(str(p.relative_to(R)) for p in (R/'app/scripts/config').rglob('*') if p.is_file())
    deps = read(R/'tmp/approach-review-20261101/geometry-two-goal-materialization-on-reviewed-stats-v27-20261102-v1/explicit-producer-dependencies.json')
    paths.update(d['path'] for d in deps)
    copies, links = 0, 0
    for rel in sorted(paths):
        src, dst = R/rel, HOST/rel
        assert src.is_file(), src
        private_parent(dst); dst.parent.mkdir(parents=True, exist_ok=True); private_parent(dst)
        # Non-runtime documents are independent regular snapshots, so later
        # status edits cannot change this source/producer host via a hardlink.
        if rel.startswith('docs/'):
            shutil.copyfile(src,dst); copies += 1
        else:
            os.link(src.resolve(),dst); links += 1
    (HOST/'app/src').symlink_to(R/'app/src', target_is_directory=True)
    (HOST/'app/node_modules').symlink_to(R/'app/node_modules', target_is_directory=True)
    for f in payload: sync_leaf(C/f['path'], HOST/f['path'])
    # These standard check/report destinations are private COW leaves even if
    # a future CLI accidentally attempts to write while checking.
    cow = ['curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json',
           'docs/qa-ci/status/curriculum-source-coverage-audit.json',
           'docs/qa-ci/status/curriculum-source-coverage-audit.md']
    for rel in cow: sync_leaf(R/rel, HOST/rel)
    assert not (HOST/frozen['stageReceipt']['path']).exists()
    guard()
    files = {str(p.relative_to(HOST)):sha(p) for p in HOST.rglob('*') if p.is_file() and not p.is_symlink()}
    assert all(not p.is_symlink() for p in (HOST/'curricula').rglob('*'))
    result = {'status':'PRIVATE_FINITE_PHYSICAL_HOST_NO_COMMANDS_RUN', 'hostRoot':str(HOST.relative_to(R)),
        'rootInputs':pin(INPUTS),'rootClassMap':pin(CLASSES),'rootCounts':{'inputs':9550,'mainClasses':947,'testClasses':428},
        'discoveryInventory':pin(DISCOVERY),'files':files,'fileCount':len(files),
        'sharedReadonlyHardlinkLeaves':links,'nonRuntimeDocumentCopies':copies,
        'ownedOverlayLeafCount':len(payload),'additionalOwnedCowLeafPaths':cow,'allWritableLeavesOwnRegularSingleLink':True,
        'noWritableDirectoryAlias':True,'onlyReadonlyDirectoryAliases':['app/src','app/node_modules'],
        'receiptReservedAndAbsent':not (HOST/frozen['stageReceipt']['path']).exists(),'guardSource':pin(Path(__file__).resolve()),
        'noRootJvmGitOrMasteryMutation':True}
    (H/'producer-host-r4-input-manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'manifest':pin(H/'producer-host-r4-input-manifest.json'),'files':len(files),'owned':len(payload)}))
