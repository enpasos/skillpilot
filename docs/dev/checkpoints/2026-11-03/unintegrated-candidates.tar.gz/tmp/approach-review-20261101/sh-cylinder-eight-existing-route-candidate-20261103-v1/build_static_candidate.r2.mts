import { readFileSync, writeFileSync, mkdirSync, existsSync, lstatSync, realpathSync, readdirSync } from 'node:fs'
import { resolve, dirname, relative, join } from 'node:path'
import { createHash } from 'node:crypto'
import { gzipSync } from 'node:zlib'
import assert from 'node:assert/strict'
import { fileURLToPath } from 'node:url'
import { collectCompositionProjectionRoleGoalIds, compileCompositionView } from '/home/enpasos/projects/skillpilot/app/src/utils/authoring/compositionViewAuthoring.ts'
import { normalizeCanonicalLandscape } from '/home/enpasos/projects/skillpilot/app/src/utils/authoring/canonicalAuthoring.ts'
import { applyMathAssessmentScopeOperations, collectMathAtomicSupportContext } from '/home/enpasos/projects/skillpilot/app/scripts/mathStageScopePolicy.ts'
import { fingerprintSemanticKindSourceGoal } from '/home/enpasos/projects/skillpilot/app/scripts/goalBookModel.ts'

const REPO = '/home/enpasos/projects/skillpilot'
const HERE = dirname(fileURLToPath(import.meta.url))
const arg = (name: string) => process.argv[process.argv.indexOf(name) + 1]
assert(process.argv.includes('--base-root') && process.argv.includes('--output-root'), 'explicit private base/output required')
const BASE = realpathSync(resolve(arg('--base-root')))
const OUT = resolve(arg('--output-root'))
assert(OUT.startsWith(HERE + '/') && !existsSync(OUT), 'new output below this private author directory required')
const TASK = '3045f00d-a5b9-547c-b568-593aeac9ffa3'
const AREA = '491e0858-e977-516e-a339-1cc2f9e9690f'
const UNITS = '57fbbf31-9b8c-5408-9af5-fbc73acd12bb'
const LOCUS = 'cf8c5677-f3c5-5563-8f0a-68443fbab7bf'
const CIRCLE = '21342eb9-9cfd-4fbf-b28e-60aa2b48f702'
const TANGENTS = '797c4b05-96c4-59a7-85b2-f2690e22918f'
const MATH = '68a8ac50-f5f5-4e24-8aa9-5e408ca01ced'
const CAN = 'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'
const LED = 'curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json'
const REG = 'curricula/DE/Gymnasium/provenance/canonical-goal-applicability-override-registry.json'
const POL = 'app/scripts/config/math-country-seki-stage-policy.json'
const LAY = 'app/scripts/config/math-duration-split-spanning-tree-policy.json'
const VIEWS = 'curricula/DE/Gymnasium/composition-views/mathematik'
const QUALITY = 'curricula/DE/Gymnasium/quality/source-scope-review/mathematik/2026-11-03/sh-cylinder-eight-existing-route'
const DECISION = `${QUALITY}/independent-sh-cylinder-scope-decision.json`
const AUTHOR = `${QUALITY}/author-source-and-exact-operations.json`
const RECEIPT = 'curricula/DE/Gymnasium/quality/source-scope-review/mathematik/2026-11-03/stage-scope-implementation-sh-cylinder-eight.review.json'
const h = (b: string | Buffer) => createHash('sha256').update(b).digest('hex')
const json = (v: unknown) => JSON.stringify(v, null, 2) + '\n'
const same = (a: unknown, b: unknown, reason: string) => assert.deepEqual(a, b, reason)
const sorted = (s: Iterable<string>) => [...s].sort()
const inputs: Record<string, string> = {}
const beforeBytes = new Map<string, Buffer>()
const read = (path: string) => {
  const bytes = readFileSync(resolve(BASE, path)); inputs[path] = h(bytes); beforeBytes.set(path, bytes)
  return JSON.parse(bytes.toString('utf8'))
}
const rootPin = (path: string) => { const b = readFileSync(resolve(BASE, path)); inputs[path] = h(b); return { path, sha256: h(b), bytes: b.length } }
const filePin = (path: string) => { const b = readFileSync(path); return { path: relative(REPO, path), sha256: h(b), bytes: b.length } }
const smallWrite = (path: string, bytes: string | Buffer) => {
  const target = resolve(OUT, path)
  assert(target.startsWith(OUT + '/'), 'private containment')
  mkdirSync(dirname(target), { recursive: true })
  for (let parent = dirname(target); parent !== dirname(OUT); parent = dirname(parent)) {
    assert(!lstatSync(parent).isSymbolicLink() && realpathSync(parent) === parent, 'all write parents must be physical')
    if (parent === OUT) break
  }
  assert(!existsSync(target), 'never overwrite any prior leaf')
  writeFileSync(target, bytes, { flag: 'wx' })
  assert(lstatSync(target).isFile() && lstatSync(target).nlink === 1, 'own regular output leaf')
}
const decisionPath = `${REPO}/tmp/approach-review-20261101/astra-next-existing-three-routes-scope-review-20261103-v1/sh-cylinder-scope-decision.json`
const decisionBytes = readFileSync(decisionPath)
assert.equal(h(decisionBytes), '76c2cef65acdf33df060dffe738b93953e0ea09f309aba342e03e62ac8d387ac')
const decision = JSON.parse(decisionBytes.toString('utf8'))
const triageDir = `${REPO}/tmp/approach-review-20261101/next-existing-route-triage-v30-20261103-v1`
const whole = JSON.parse(readFileSync(`${triageDir}/3045f00d-whole-contract-and-161-contexts.json`, 'utf8'))
const priorScopesBytes = readFileSync(`${triageDir}/v30-compact-native-scope-facts.json`)
const priorScopes = JSON.parse(priorScopesBytes.toString('utf8'))
assert.equal(h(priorScopesBytes), '8bba77e313f372a5cedb8da4e9b4a1a973976eb30a1a15c705a44061638095b3')
assert.equal(priorScopes.length, 161)
const positiveScopes = new Set<string>(decision.pairs.filter((p: any) => p.decision.startsWith('AUTHOR_APPROVED')).map((p: any) => p.scope))
assert.equal(positiveScopes.size, 8)
assert.equal(decision.pairs.filter((p: any) => p.decision.startsWith('EXISTING_SELECTION')).length, 84)
assert.equal(decision.pairs.length - positiveScopes.size - 84, 69)

const beforeCanon = read(CAN), canon = structuredClone(beforeCanon), ledger = read(LED)
assert.equal(h(beforeBytes.get(CAN)!), '5f23d314ed1b31caae2e5994921c5fa2599ca7e7f718a5b9fc9d61334713bf37', 'actual V30 curriculum before')
const goals = new Map<string, any>(canon.goals.map((g: any) => [g.id, g]))
same(goals.get(TASK), whole.wholeTask, 'entire current task equals reviewed object before applicability cache change')
const fingerprints = new Map(ledger.decisions.map((d: any) => [d.goalId, d.sourceFingerprint]))
for (const goal of beforeCanon.goals) assert.equal(fingerprintSemanticKindSourceGoal(goal), fingerprints.get(goal.id), `actual baseline fingerprint ${goal.id}`)
const allGoals = new Map<string, any>()
for (const file of readdirSync(resolve(BASE, 'curricula/DE/Gymnasium/canonical')).filter(f => f.endsWith('.de.json')).sort()) {
  const landscape = read(`curricula/DE/Gymnasium/canonical/${file}`)
  for (const g of landscape.goals) { assert(!allGoals.has(g.id), 'complete universe has unique IDs'); allGoals.set(g.id, g) }
}
const support = collectMathAtomicSupportContext([TASK], allGoals)
assert.equal(support.supportUnionGoalIds.length, 44)
same(support.supportUnionGoalIds, whole.transitivePreparationSupport, 'fresh full-universe preparation equals all44 reviewed contracts')
same(support.tasks[0].effectiveDirectPrerequisiteIds, sorted(whole.rawDirectRequires), 'no extra inherited direct demand')

const registry = read(REG)
assert(!registry.landscapes.some((l: any) => l.goalApplicabilityOverrides?.[TASK]), 'no prior task override to overwrite')
let mathEntry = registry.landscapes.find((l: any) => l.landscapeId === MATH)
if (!mathEntry) { mathEntry = { landscapeId: MATH, goalApplicabilityOverrides: {} }; registry.landscapes.push(mathEntry) }
mathEntry.goalApplicabilityOverrides[TASK] = { jurisdiction: ['DE-SH'] }
const oldTask = beforeCanon.goals.find((g: any) => g.id === TASK)
assert.equal(oldTask.applicability.jurisdiction.length, 15)
assert(!oldTask.applicability.jurisdiction.includes('DE-SH'))
goals.get(TASK).applicability.jurisdiction = sorted([...oldTask.applicability.jurisdiction, 'DE-SH'])
for (const goal of canon.goals) {
  const before = beforeCanon.goals.find((g: any) => g.id === goal.id)
  if (goal.id !== TASK) same(goal, before, `whole unchanged old goal ${goal.id}`)
  else { const strip = (g: any) => { const c = structuredClone(g); delete c.applicability; return c }; same(strip(goal), strip(before), 'only task applicability cache changes') }
  assert.equal(fingerprintSemanticKindSourceGoal(goal), fingerprints.get(goal.id), `no semantic ledger change for ${goal.id}`)
}
const policy = read(POL), layout = read(LAY)
const oldLayoutCounts = structuredClone(layout.counts)
const operations: any[] = [], placementChanges: any[] = []
const newViews = new Map<string, any>(), viewFacts: any[] = []
const allBeforeViews = new Map<string, any>()
for (const name of readdirSync(resolve(BASE, VIEWS)).filter(f => f.endsWith('.view.json')).sort()) allBeforeViews.set(name, read(`${VIEWS}/${name}`))
assert.equal(allBeforeViews.size, 108)
const oldHostManifest = JSON.parse(readFileSync(`${REPO}/tmp/approach-review-20261101/he5-cuboid48-probability-two-edge-source-ref-v29-candidate-20261103-v1/final-producer-host-input-manifest.json`, 'utf8'))
for (const [name] of allBeforeViews) assert.equal(inputs[`${VIEWS}/${name}`], oldHostManifest.all108ViewHashes[`${VIEWS}/${name}`] ?? oldHostManifest.all108ViewHashes[name], `actual whole view unchanged from V30 target evidence ${name}`)
const nodes = (roots: any[], id: string): any[] => roots.flatMap(n => n.kind === 'structure' ? [...(n.id === id ? [n] : []), ...nodes(n.children, id)] : [])
const dropDirect = (roots: any[], ids: Set<string>): any[] => roots.flatMap(n => n.kind === 'structure' ? [{ ...n, children: dropDirect(n.children, ids) }] : n.kind === 'goalEntry' && n.projectionRole !== 'prerequisiteOnly' && ids.has(n.goalId) ? [] : [n])
const labelTangents = (roots: any[]): void => { for (const n of roots) { if (n.kind === 'structure') labelTangents(n.children); else if (n.goalId === TANGENTS && n.projectionRole !== 'prerequisiteOnly') n.displayLabel = 'Zusätzliche Anwendung (SkillPilot): Tangenten an Kreise konstruieren' } }
const ordinaryReplacements = (duration: string) => [
  { goalId: UNITS, parent: `sh-jg5-6-${duration}-kompetenzen`, id: `sh-cylinder-volume-units-basis-${duration}`, label: 'Volumeneinheiten als Größenbasis' },
  { goalId: AREA, parent: `sh-jg5-6-${duration}-kompetenzen`, id: `sh-cylinder-area-formula-basis-${duration}`, label: 'Flächenformeln durch Zerlegen und Ergänzen begründen' },
  { goalId: LOCUS, parent: `sh-jg7-9-${duration}-kompetenzen`, id: `sh-locus-own-extension-${duration}`, label: 'Zusätzliche Anwendung (SkillPilot): Ortslinien für Konstruktionen auswählen' },
  { goalId: CIRCLE, parent: `sh-jg7-9-${duration}-kompetenzen`, id: `sh-circle-basis-and-own-extension-${duration}`, label: 'Kreisbeziehungen: Basis und Zusatzanwendungen (Umfangswinkel: fakultativ)' },
]
for (const duration of ['g8', 'g9']) {
  const template = layout.sek1Templates.find((t: any) => t.fileName === `de-sh-seki-${duration}.view.json`)
  assert(template, 'actual SH layout template')
  const s25 = template.placements.filter((p: any) => p.replacementNode.goalId === TANGENTS)
  assert.equal(s25.length, 1)
  s25[0].replacementNode.displayLabel = 'Zusätzliche Anwendung (SkillPilot): Tangenten an Kreise konstruieren'
  for (const replacement of ordinaryReplacements(duration)) {
    assert(!template.placements.some((p: any) => p.splitCode === replacement.id), 'fresh local layout decision')
    const placement = { parentStructureId: replacement.parent, splitCode: replacement.id, oldClusterGoalId: replacement.goalId,
      renderKind: 'structure', removeAtomicGoalIds: [replacement.goalId], replacementNode: { kind: 'structure', id: replacement.id, label: replacement.label, children: [{ kind: 'goalEntry', goalId: replacement.goalId }] } }
    template.placements.push(placement); placementChanges.push({ template: template.fileName, placement })
  }
  template.placementCount = template.placements.length
  // This authored mask prevents automatic re-enrolment through the old generic J8 folder.
  // The separately bound normal include-target operations below select exactly the reviewed band slot.
  assert(!(template.prerequisiteOnlyOverrideGoalIds ?? []).includes(TASK), 'no old task mask to reinterpret')
  template.prerequisiteOnlyOverrideGoalIds = [...(template.prerequisiteOnlyOverrideGoalIds ?? []), TASK]
  for (const name of [`de-sh-seki-${duration}.view.json`, `de-sh-gk-${duration}.view.json`, `de-sh-lk-${duration}.view.json`]) {
    const before = allBeforeViews.get(name); assert(before, name)
    let view = structuredClone(before)
    view.rootNodes = dropDirect(view.rootNodes, new Set([AREA, UNITS, LOCUS, CIRCLE]))
    labelTangents(view.rootNodes)
    for (const replacement of ordinaryReplacements(duration)) {
      const parent = nodes(view.rootNodes, replacement.parent); assert.equal(parent.length, 1, `exact current program anchor ${replacement.parent}`)
      parent[0].children.push({ kind: 'structure', id: replacement.id, label: replacement.label, children: [{ kind: 'goalEntry', goalId: replacement.goalId }] })
    }
    const sortIds = new Map<string, string>(template.placements.filter((p: any) => p.replacementNode.kind === 'structure').map((p: any) => [p.replacementNode.id, p.oldClusterGoalId]))
    for (const parentId of new Set(ordinaryReplacements(duration).map(r => r.parent))) {
      const parent = nodes(view.rootNodes, parentId)[0]
      const key = (n: any) => n.kind === 'structure' ? sortIds.get(n.id) ?? n.id : n.goalId ?? n.landscapeId
      parent.children.sort((a: any, b: any) => (goals.get(key(a))?.title ?? key(a)).localeCompare(goals.get(key(b))?.title ?? key(b), 'de', { numeric: true, sensitivity: 'base' }) || key(a).localeCompare(key(b)))
    }
    const band = duration === 'g8' ? '6/7/8' : '7/8/9'
    const operation = { id: `sh-cylinder-existing-${view.viewId}`, viewId: view.viewId, goalIds: [TASK], action: 'include-target',
      anchorStructureId: `sh-jg7-9-${duration}-kompetenzen`, label: `Eigene Prüfung: Zylinder und Kreistangenten (Zusatzanwendung; SH-Jahrgangsband ${band})`, sourceDecision: `${AUTHOR}#exactEightScopes` }
    operations.push(operation)
    view = applyMathAssessmentScopeOperations(view, goals, [operation])
    same(applyMathAssessmentScopeOperations(view, goals, [operation]), view, 'real include-target replay is idempotent')
    const beforeRoles = collectCompositionProjectionRoleGoalIds(before.rootNodes, goals)
    const afterRoles = collectCompositionProjectionRoleGoalIds(view.rootNodes, goals)
    same(sorted([...afterRoles.targetGoalIds].filter(id => !beforeRoles.targetGoalIds.has(id))), [TASK], 'only exact task becomes selected')
    same(sorted([...beforeRoles.targetGoalIds].filter(id => !afterRoles.targetGoalIds.has(id))), [], 'no old target removal')
    same(sorted([...beforeRoles.prerequisiteOnlyGoalIds].filter(id => !afterRoles.prerequisiteOnlyGoalIds.has(id))), [TASK], 'only this task changes from POnly to target')
    same(sorted([...afterRoles.prerequisiteOnlyGoalIds].filter(id => !beforeRoles.prerequisiteOnlyGoalIds.has(id))), [], 'no added ordinary POnly')
    for (const id of support.supportUnionGoalIds) assert(afterRoles.targetGoalIds.has(id), `all44 preparation already targets ${name}/${id}`)
    const preview = compileCompositionView(view, new Map([[MATH, normalizeCanonicalLandscape(canon)]]))
    const fatal = preview.findings.filter((d: any) => ['CPV-004','CPV-005','CPV-006','CPV-007','CPV-009'].includes(d.code))
    same(fatal, [], 'productive static view compilation has no fatal structural diagnostics')
    newViews.set(name, view)
    viewFacts.push({ path: `${VIEWS}/${name}`, beforeWholeTargets: sorted(beforeRoles.targetGoalIds), afterWholeTargets: sorted(afterRoles.targetGoalIds),
      beforeWholePrerequisiteOnly: sorted(beforeRoles.prerequisiteOnlyGoalIds), afterWholePrerequisiteOnly: sorted(afterRoles.prerequisiteOnlyGoalIds),
      wholeTaskPreparationBefore: support.supportUnionGoalIds, wholeTaskPreparationAfter: support.supportUnionGoalIds, operation,
      acquisition: { stageOrientation: 1, earlierBand5And6Before: 33, earlierBand5And6After: 35, middleBandBeforeAndAfter: 8, formerlyStageWideNowEarlier: [AREA, UNITS], taskAfterTheMiddleBandCompetencies: true } })
  }
}
assert.equal(operations.length, 6)
layout.counts.splitPlacementCount = layout.sek1Templates.reduce((n: number, t: any) => n + t.placements.length, 0)
assert.equal(layout.counts.splitPlacementCount - oldLayoutCounts.splitPlacementCount, 8)
layout.policy.sourceOfLayoutTruth = layout.policy.sourceOfLayoutTruth.replace(`${oldLayoutCounts.splitPlacementCount} split placements`, `${layout.counts.splitPlacementCount} split placements`)
const scopeFacts = priorScopes.map((row: any) => {
  const beforeT = new Set<string>(row.targets), afterT = new Set(beforeT), positive = positiveScopes.has(row.scope)
  if (positive) { assert(!beforeT.has(TASK), 'approved positive is missing before'); afterT.add(TASK) }
  const disposition = decision.pairs.find((p: any) => p.scope === row.scope); assert(disposition, 'exact real161 scope inventory')
  if (disposition.decision.startsWith('EXISTING_SELECTION')) assert(beforeT.has(TASK), 'all84 prior selected occurrences retained')
  else if (!positive) assert(!afterT.has(TASK), 'all69 negative rows remain unselected')
  return { scope: row.scope, compositionViewIds: row.compositionViewIds, decision: disposition.decision,
    beforeWholeTargetGoalIds: sorted(beforeT), afterWholeTargetGoalIdsStaticPrediction: sorted(afterT),
    wholeTaskGlobalPreparationBefore: support.supportUnionGoalIds, wholeTaskGlobalPreparationAfter: support.supportUnionGoalIds,
    all44PreparationTargetsInNewPositive: positive ? support.supportUnionGoalIds.every(id => beforeT.has(id)) : null }
})
assert.equal(scopeFacts.filter((r: any) => r.afterWholeTargetGoalIdsStaticPrediction.includes(TASK)).length, 92)
const supportGoalHashes = Object.fromEntries([TASK, ...support.supportUnionGoalIds].map(id => [id, h(JSON.stringify(allGoals.get(id)))]))
const author = { status: 'PRIVATE_AUTHOR_MATERIALIZATION_FOR_INDEPENDENT_REVIEW_NOT_NATIVE_OR_STAGE_PASS',
  taskGoalId: TASK, exactEightScopes: sorted(positiveScopes), existing84AndNegative69: decision.pairs.filter((p: any) => !positiveScopes.has(p.scope)),
  independentScopeDecision: { path: DECISION, sha256: h(decisionBytes) },
  sourceTruth: decision.sourceDecision, requiredActions: decision.requiredAuthoringActions, exactAssessmentScopeOperations: operations,
  ordinaryLayoutPlacements: placementChanges, changedExistingLayoutLabel: { goalId: TANGENTS, label: 'Zusätzliche Anwendung (SkillPilot): Tangenten an Kreise konstruieren' },
  wholeEffectivePreparation: support, whole45BeforeObjectHashes: supportGoalHashes,
  taskScoringUnchanged: { maxPoints: 7, passingPoints: 4, steps: 4, wholeExamDataSha256: h(JSON.stringify(oldTask.examData)) },
  applicabilityAuthoring: { registry: REG, entry: { landscapeId: MATH, goalApplicabilityOverrides: { [TASK]: { jurisdiction: ['DE-SH'] } } },
    cachedTaskJurisdictionsBefore: oldTask.applicability.jurisdiction, cachedTaskJurisdictionsAfter: goals.get(TASK).applicability.jurisdiction,
    basis: 'Normal compiler additive override rule; existing fifteen computed jurisdictions plus one explicit SH own-extension authorization. Full fresh applicability compilation remains pending.', newOfficialSourceCoverageClaim: false },
  historicalLayoutFileAndOutputPinsUnchanged: true,
  oldFocusMembershipChangesMustBeReported: { stageWideAdditionalContainerLoses: [AREA, UNITS], band5And6Gains: [AREA, UNITS], middleBandGainsOnlyThisTask: TASK,
    canonicalAtomicReferencesRetained: [AREA, UNITS, LOCUS, CIRCLE], tangentsCanonicalReferenceRetained: TANGENTS, nativeSavedFocusAndMergedProfileResolutionPending: true },
  holds: ['No actual native eligibility/needed/focus proof yet.', 'No normal101 producer fixpoint or Source21/SourceCoverage run in this small preparation.', 'Cache union is stored from the explicit normal override rule; full normal compiler comparison still required.', 'No Stage receipt is present or fabricated.'],
  noTaskRubricRequiresCoverageGlobalMasteryCoreTagOrRuntimeChange: true }

const payload = new Map<string, Buffer>([[CAN, Buffer.from(json(canon))], [REG, Buffer.from(json(registry))], [DECISION, decisionBytes], [AUTHOR, Buffer.from(json(author))]])
for (const [name, view] of newViews) payload.set(`${VIEWS}/${name}`, Buffer.from(json(view)))
layout.inputs.canonical.sha256 = h(payload.get(CAN)!)
layout.inputs.sourceScopeDecisions.push({ path: AUTHOR, sha256: h(payload.get(AUTHOR)!) })
payload.set(LAY, Buffer.from(json(layout)))
policy.assessmentScopeOperations.push(...operations)
policy.stageDecisionBindings.push({ path: AUTHOR, sha256: h(payload.get(AUTHOR)!) }, { path: DECISION, sha256: h(decisionBytes) })
for (const path of [REG]) {
  assert(!policy.sourceBindings.some((b: any) => b.path === path), 'new finite normal compiler input binding')
  policy.sourceBindings.push({ path, sha256: h(payload.get(path)!) })
}
policy.reviewReceiptPath = RECEIPT
const policyPinUpdates: any[] = []
const updateActivePins = (value: any, pointer = '') => {
  if (!value || typeof value !== 'object') return
  if (!Array.isArray(value) && typeof value.path === 'string' && payload.has(value.path) && typeof value.sha256 === 'string') {
    const after = h(payload.get(value.path)!)
    if (value.sha256 !== after) { policyPinUpdates.push({ pointer: `${pointer}/sha256`, path: value.path, before: value.sha256, after }); value.sha256 = after }
  }
  for (const [key, child] of Object.entries(value)) updateActivePins(child, `${pointer}/${key}`)
}
updateActivePins(policy)
payload.set(POL, Buffer.from(json(policy)))
assert(!existsSync(resolve(BASE, RECEIPT)), 'new receipt path remains reserved and absent')
const files = [...payload].map(([path, bytes]) => ({ path, beforeSha256: beforeBytes.has(path) ? h(beforeBytes.get(path)!) : null, candidateSha256: h(bytes), bytes: bytes.length }))
for (const [path, expected] of Object.entries(inputs)) assert.equal(h(readFileSync(resolve(BASE, path))), expected, `finite actual Root input remained unchanged ${path}`)
mkdirSync(OUT)
for (const [path, bytes] of payload) smallWrite(path, bytes)
smallWrite('scope-and-whole-view-facts.json.gz', gzipSync(json({ kind: 'AUTHOR_STATIC_TARGET_PREDICTION_NOT_A_NEW_NATIVE_REPORT', all161Scopes: scopeFacts, allSixWholeViewRoleSets: viewFacts, freshFullUniverseTaskPreparation: support }), { level: 9 }))
const request = { status: 'PRIVATE_STATIC_SH_CYLINDER_EIGHT_MATERIALIZATION_REQUIRES_INDEPENDENT_REVIEW', candidateRoot: relative(REPO, OUT),
  approvedImportFilesNotYetApprovedByIndependentMaterializationReview: files, fileCount: files.length, finiteRootInputsBeforeAfterExact: inputs,
  sourceDecision: filePin(decisionPath), source: filePin(fileURLToPath(import.meta.url)), ordinaryLayoutCountsBefore: oldLayoutCounts, ordinaryLayoutCountsAfter: layout.counts,
  taskContentRubricRequiresCoverageAndAllOtherGoalObjectsUnchanged: true, allBaselineAndAfterSemanticFingerprintsMatchCurrentLedger: canon.goals.length, semanticLedgerBytesUnchanged: rootPin(LED),
  exactSelectedTaskPcPrediction: { before: 84, added: 8, after: 92, negativePreserved: 69, totalRealOffers: 161, changedPhysicalViews: 6 },
  productiveAssessmentHelperReplays: { applied: 6, idempotency: 6, compiledChangedViews: 6 },
  all108PriorViewFilesBound: allBeforeViews.size, scopeWholeFacts: filePin(resolve(OUT, 'scope-and-whole-view-facts.json.gz')), policyPinUpdates,
  normalApplicabilityRegistryInputAdded: REG, cachedTaskApplicability15To16StoredButFullCompilerComparisonPending: true,
  stageReceipt: { path: RECEIPT, reservedOnly: true, exists: false }, holds: author.holds,
  noJvmOrRootCodeDataClassMasteryGitOrProductionWrite: true, noRuntimeOrProfileFrameworkChange: true,
  rootClassCompilationWasLiveDuringPreparationNoHistoricalFullRootOrClassGuardClaimed: true }
smallWrite('materialization-review-request.json', json(request))
console.log(json({ request: filePin(resolve(OUT, 'materialization-review-request.json')), fileCount: files.length, prediction: request.exactSelectedTaskPcPrediction, holds: author.holds }))
