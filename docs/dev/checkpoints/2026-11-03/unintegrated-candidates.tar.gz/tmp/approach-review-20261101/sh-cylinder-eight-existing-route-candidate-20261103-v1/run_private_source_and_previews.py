from pathlib import Path
import hashlib,json,subprocess,time,importlib.util
R=Path('/home/enpasos/projects/skillpilot');D=Path(__file__).resolve().parent;HOST=D/'producer-host-r3';C=D/'candidate-r3'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size}
spec=importlib.util.spec_from_file_location('existing_finite_host_method',D/'prepare_producer_host.py');method=importlib.util.module_from_spec(spec);spec.loader.exec_module(method)
manifest=read(D/'producer-host-r3-input-manifest.json');request=read(C/'materialization-review-request.json')
def guard():
 method.guard()
 for rel,digest in manifest['files'].items():assert sha(HOST/rel)==digest,('host input drift',rel)
 for f in request['approvedImportFilesNotYetApprovedByIndependentMaterializationReview']:assert sha(C/f['path'])==f['candidateSha256']
 assert not (HOST/request['stageReceipt']['path']).exists()
commands=[('fresh-sh-source21',[str(R/'app/node_modules/.bin/tsx'),str(D/'compile_sh_source21.mts'),str(HOST/'app/scripts/applicabilityCompiler.ts'),str(C/'curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json'),str(D/'fresh-sh-source21-r3.json.gz'),str(D/'fresh-sh-source21-r3-facts.json'),str(R/'tmp/approach-review-20261101/he5-cuboid48-probability-two-edge-source-ref-v29-candidate-20261103-v1/fresh-final-source21.json.gz'),'3045f00d-a5b9-547c-b568-593aeac9ffa3'],R),
('sourceCoverage',[str(R/'app/node_modules/.bin/tsx'),'scripts/generateCurriculumSourceCoverageAudit.ts','--check'],HOST/'app'),
('country83-preview',[str(R/'app/node_modules/.bin/tsx'),'scripts/generateMathCountrySekICompositionViews.ts','--output-dir','tmp/sh-cylinder-country83-r3-preview'],HOST/'app'),
('duration18-preview',[str(R/'app/node_modules/.bin/tsx'),'scripts/generateMathDurationCompositionViews.ts','--output-dir','tmp/sh-cylinder-duration18-r3-preview'],HOST/'app')]
results=[]
for name,argv,cwd in commands:
 guard();start=time.monotonic();out=D/(name+'.stdout.log');err=D/(name+'.stderr.log');assert not out.exists()and not err.exists()
 with out.open('xb')as stdout,err.open('xb')as stderr:
  p=subprocess.Popen(argv,cwd=cwd,stdout=stdout,stderr=stderr);print(json.dumps({'phase':'START','name':name,'pid':p.pid}),flush=True);code=p.wait()
 guard();record={'name':name,'argv':argv,'cwd':str(cwd.relative_to(R))if cwd!=R else str(R),'pid':p.pid,'exitCode':code,'seconds':round(time.monotonic()-start,2),'stdout':pin(out),'stderr':pin(err),'fullRoot9550Class1375HostAndCandidatePinsBeforeAfterExact':True,'materializationWriteOrCheckInvoked':False if name.endswith('preview')else None}
 q=D/(name+'.execution.json');assert not q.exists();q.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');results.append(pin(q));print(json.dumps(record),flush=True)
 if code:break
guard();p=D/'source-and-previews-terminal.json';assert not p.exists();p.write_text(json.dumps({'status':'ACTUAL_PRIVATE_SOURCE_AND_ISOLATED_PREVIEWS_NOT_STAGE_OR_NATIVE_ACCEPTANCE','commands':results,'allRequestedCommandsExecuted':len(results)==len(commands),'allExecutedExitCodesZero':all(read(R/x['path'])['exitCode']==0 for x in results),'hostManifest':pin(D/'producer-host-r3-input-manifest.json'),'dataFreeze':pin(D/'data-freeze-r3.json'),'allRoot9550Class1375HostAndCandidateFinalGuardsExact':True,'noJvmOrRootMutation':True,'stageReceiptReservedAbsent':True},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'terminal':pin(p)}),flush=True)
