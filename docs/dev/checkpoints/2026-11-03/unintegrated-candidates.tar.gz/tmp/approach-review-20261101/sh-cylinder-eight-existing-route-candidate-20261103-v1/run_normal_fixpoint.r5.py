from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import time

ROOT = Path('/home/enpasos/projects/skillpilot')
HERE = Path(__file__).resolve().parent
HOST = HERE / 'producer-host-r5'
CANDIDATE = HERE / 'candidate-r5'
VIEW_PREFIX = 'curricula/DE/Gymnasium/composition-views/mathematik'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pin(path):
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(path),
            'bytes': path.stat().st_size}


spec = importlib.util.spec_from_file_location(
    'existing_finite_host_method', HERE / 'prepare_producer_host.r5.py')
method = importlib.util.module_from_spec(spec)
spec.loader.exec_module(method)
manifest = read(HERE / 'producer-host-r5-input-manifest.json')
request = read(CANDIDATE / 'materialization-review-request.json')
payload = request['approvedImportFilesNotYetApprovedByIndependentMaterializationReview']
all_views = sorted((ROOT / VIEW_PREFIX).glob('*.view.json'))
assert len(all_views) == 108
expected_views = {str(p.relative_to(ROOT)): sha(HOST / p.relative_to(ROOT))
                  for p in all_views}


def guard():
    method.guard()
    for rel, digest in manifest['files'].items():
        assert sha(HOST / rel) == digest, ('host input drift', rel)
    for entry in payload:
        assert sha(CANDIDATE / entry['path']) == entry['candidateSha256']
    for rel, digest in expected_views.items():
        assert sha(HOST / rel) == digest, ('108-view drift', rel)
    assert not (HOST / request['stageReceipt']['path']).exists()


commands = [
    ('country83-r5-preview', [str(ROOT / 'app/node_modules/.bin/tsx'),
     'scripts/generateMathCountrySekICompositionViews.ts', '--output-dir',
     'tmp/sh-cylinder-country83-r5-preview']),
    ('duration18-r5-preview', [str(ROOT / 'app/node_modules/.bin/tsx'),
     'scripts/generateMathDurationCompositionViews.ts', '--output-dir',
     'tmp/sh-cylinder-duration18-r5-preview']),
]
results = []
for name, argv in commands:
    guard()
    start = time.monotonic()
    out, err = HERE / (name + '.stdout.log'), HERE / (name + '.stderr.log')
    assert not out.exists() and not err.exists()
    with out.open('xb') as stdout, err.open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=HOST / 'app', stdout=stdout, stderr=stderr)
        print(json.dumps({'phase': 'START', 'name': name, 'pid': process.pid}), flush=True)
        code = process.wait()
    guard()
    record = {'name': name, 'argv': argv,
              'cwd': str((HOST / 'app').relative_to(ROOT)), 'pid': process.pid,
              'exitCode': code, 'seconds': round(time.monotonic() - start, 2),
              'stdout': pin(out), 'stderr': pin(err),
              'fullRoot9550Class1375HostCandidateAnd108ViewsBeforeAfterExact': True,
              'onlyIsolatedOutputDirectoryPreviewNoStageWriteOrCheck': True}
    path = HERE / (name + '.execution.json')
    assert not path.exists()
    path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    results.append(pin(path))
    print(json.dumps(record), flush=True)
    if code:
        break

comparisons = []
if len(results) == 2 and all(read(ROOT / p['path'])['exitCode'] == 0 for p in results):
    for name, count, directory in [
        ('country83', 83, 'sh-cylinder-country83-r5-preview'),
        ('duration18', 18, 'sh-cylinder-duration18-r5-preview'),
    ]:
        generated = sorted((HOST / 'tmp' / directory / VIEW_PREFIX).glob('*.view.json'))
        assert len(generated) == count, (name, len(generated))
        for path in generated:
            rel = str(path.relative_to(HOST / 'tmp' / directory))
            actual = sha(path)
            comparisons.append({'path': rel, 'producer': name,
                                'generatedSha256': actual,
                                'candidateSha256': expected_views[rel],
                                'wholeBytesEqual': actual == expected_views[rel]})
    assert len(comparisons) == 101
    assert len({x['path'] for x in comparisons}) == 101
    outside = [{ 'path': rel, 'candidateSha256': digest,
                'rootSha256': sha(ROOT / rel),
                'wholeBytesEqualRoot': digest == sha(ROOT / rel)}
               for rel, digest in expected_views.items()
               if rel not in {x['path'] for x in comparisons}]
    assert len(outside) == 7
else:
    outside = []

guard()
report = {
    'status': 'ACTUAL_NORMAL_PREVIEW_FIXPOINT_NOT_STAGE_OR_NATIVE_ACCEPTANCE',
    'commands': results,
    'allTwoCommandsExecutedExitZero': len(results) == 2 and all(
        read(ROOT / p['path'])['exitCode'] == 0 for p in results),
    'whole101OutputComparison': comparisons,
    'all101NormalOutputsWholeBytesEqual': len(comparisons) == 101 and all(
        p['wholeBytesEqual'] for p in comparisons),
    'sevenViewsOutsideNormal101': outside,
    'all108VisibleInputViewHashes': expected_views,
    'hostManifest': pin(HERE / 'producer-host-r5-input-manifest.json'),
    'candidateRequest': pin(CANDIDATE / 'materialization-review-request.json'),
    'priorActualSource21AndSourceCoverage': pin(HERE / 'source-and-previews-r4-terminal.json'),
    'sourceCarryforwardBoundary': 'R5 changes six view bytes and their author/policy pins only. '
        'Canonical, override registry, mappings and all source/compiler code are byte equal to R4. '
        'The full R4 source run is retained; it is not relabeled as a new R5 execution.',
    'allRoot9550Class1375HostCandidateAnd108ViewsFinalGuardsExact': True,
    'receiptReservedAbsent': True,
    'noJvmOrRootMutation': True,
    'holds': ['Actual eight positive / 69 negative scope and stored-focus public probes pending.',
              'Independent materialization review and genuine Stage receipt pending.'],
}
path = HERE / 'normal-fixpoint-r5-terminal.json'
assert not path.exists()
path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'terminal': pin(path), 'all101Equal': report['all101NormalOutputsWholeBytesEqual']}), flush=True)
if not report['allTwoCommandsExecutedExitZero'] or not report['all101NormalOutputsWholeBytesEqual']:
    raise SystemExit(1)
