import { readFileSync, writeFileSync, mkdirSync, existsSync, lstatSync } from 'node:fs'
import { resolve, dirname, relative } from 'node:path'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import assert from 'node:assert/strict'
import { collectCompositionProjectionRoleGoalIds, compileCompositionView } from '/home/enpasos/projects/skillpilot/app/src/utils/authoring/compositionViewAuthoring.ts'
import { normalizeCanonicalLandscape } from '/home/enpasos/projects/skillpilot/app/src/utils/authoring/canonicalAuthoring.ts'
const R='/home/enpasos/projects/skillpilot',D=dirname(fileURLToPath(import.meta.url)),C=resolve(D,'candidate-r4'),N=resolve(D,'candidate-r5'),HOST=resolve(D,'producer-host-r4')
assert(!existsSync(N),'fresh private successor only')
const hash=(b:string|Buffer)=>createHash('sha256').update(b).digest('hex'),read=(p:string)=>JSON.parse(readFileSync(p,'utf8')),enc=(x:any)=>JSON.stringify(x,null,2)+'\n',sorted=(x:Iterable<string>)=>[...x].sort()
const pin=(p:string)=>{const b=readFileSync(p);return{path:relative(R,p),sha256:hash(b),bytes:b.length}}
const req=read(resolve(C,'materialization-review-request.json')),vp='curricula/DE/Gymnasium/composition-views/mathematik',can='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json',POL='app/scripts/config/math-country-seki-stage-policy.json',LAY='app/scripts/config/math-duration-split-spanning-tree-policy.json'
const AUTHOR='curricula/DE/Gymnasium/quality/source-scope-review/mathematik/2026-11-03/sh-cylinder-eight-existing-route/author-source-and-exact-operations.json'
const canon=read(resolve(C,can)),normalized=normalizeCanonicalLandscape(canon),goals=new Map<string,any>(canon.goals.map((g:any)=>[g.id,g])),TASK='3045f00d-a5b9-547c-b568-593aeac9ffa3'
const rows:any[]=[],newViews=new Map<string,Buffer>()
const semantics=(roots:any[])=>{
 const records:any[]=[]
 const visit=(nodes:any[],parents:string[])=>{for(const n of nodes){const key=n.kind==='goal'?`goal:${n.sourceGoalId}`:n.runtimeId;const members=(list:any[]):string[]=>list.flatMap(c=>[...(c.sourceGoalId?[c.sourceGoalId]:[]),...members(c.children??[])]);records.push({key,label:n.label,parentChain:parents,memberGoalIds:sorted(members([n])),childKeysSorted:sorted(n.children.map((c:any)=>c.kind==='goal'?`goal:${c.sourceGoalId}`:c.runtimeId)),orderedChildKeys:n.children.map((c:any)=>c.kind==='goal'?`goal:${c.sourceGoalId}`:c.runtimeId)});visit(n.children,[...parents,key])}}
 visit(roots,[]);return records.sort((a,b)=>a.key.localeCompare(b.key))
}
for(const f of req.approvedImportFilesNotYetApprovedByIndependentMaterializationReview){assert.equal(hash(readFileSync(resolve(C,f.path))),f.candidateSha256);if(!f.path.startsWith(vp+'/'))continue
 const generated=resolve(HOST,'tmp/sh-cylinder-duration18-r4-preview',f.path),a=read(resolve(C,f.path)),b=read(generated)
 const ar=collectCompositionProjectionRoleGoalIds(a.rootNodes,goals),br=collectCompositionProjectionRoleGoalIds(b.rootNodes,goals)
 assert.deepEqual(sorted(ar.targetGoalIds),sorted(br.targetGoalIds),'whole target roles identical');assert.deepEqual(sorted(ar.prerequisiteOnlyGoalIds),sorted(br.prerequisiteOnlyGoalIds),'whole POnly roles identical')
 const previews=[a,b].map(v=>compileCompositionView(v,normalized))
 for(const p of previews){assert(p.compiledRootNodes.length);assert.deepEqual(p.findings.filter((e:any)=>e.severity==='error'||['CPV-004','CPV-005','CPV-006','CPV-007','CPV-009'].includes(e.code)),[])}
 const s=previews.map(p=>semantics(p.compiledRootNodes)),strip=(records:any[])=>records.map(({orderedChildKeys,...rest})=>rest)
 assert.deepEqual(strip(s[0]),strip(s[1]),'every visible semantic parent,label,and full membership preserved between authored and normal output')
 assert.equal(s[1].filter((n:any)=>n.key===`goal:${TASK}`).length,1,'one real visible task')
 const orderChanges=s[0].flatMap((n:any)=>{const after=s[1].find((b:any)=>b.key===n.key)!;return JSON.stringify(n.orderedChildKeys)===JSON.stringify(after.orderedChildKeys)?[]:[{nodeKey:n.key,before:n.orderedChildKeys,after:after.orderedChildKeys}]})
 const authoredRoleNodes=(v:any)=>{const out:any[]=[];const visit=(nodes:any[],parents:string[])=>{for(const n of nodes){if(n.kind==='structure')visit(n.children,[...parents,n.id]);else if(n.goalId)out.push({goalId:n.goalId,kind:n.kind,role:n.projectionRole??'target',parents})}};visit(v.rootNodes,[]);return out}
 const raw=[a,b].map(authoredRoleNodes),roleRepr=raw[0].filter((n:any)=>n.kind==='goalEntry'&&n.role==='prerequisiteOnly'&&!raw[1].some((b:any)=>JSON.stringify(b)===JSON.stringify(n)))
 assert.equal(roleRepr.length,7,'exact seven existing hidden task marker representations change')
 for(const n of roleRepr){assert(br.prerequisiteOnlyGoalIds.has(n.goalId));assert(raw[1].some((b:any)=>b.goalId===n.goalId&&b.kind==='canonicalSubtree'&&b.role==='prerequisiteOnly'))}
 rows.push({path:f.path,authored:pin(resolve(C,f.path)),normal:pin(generated),wholeTargets:sorted(br.targetGoalIds),wholePrerequisiteOnly:sorted(br.prerequisiteOnlyGoalIds),visibleNodeCount:s[1].length,allVisibleSemanticParentChainsLabelsAndMemberSetsEqual:true,exactSiblingOrderChanges:orderChanges,sevenHiddenMarkerRepresentations:roleRepr,notAResolvedCvsOrStoredFocusProbe:true})
 newViews.set(f.path,readFileSync(generated))
}
assert.equal(rows.length,6)
const payload=new Map<string,Buffer>(req.approvedImportFilesNotYetApprovedByIndependentMaterializationReview.map((f:any)=>[f.path,readFileSync(resolve(C,f.path))]))
for(const [p,b]of newViews)payload.set(p,b)
const author=read(resolve(C,AUTHOR));author.normalProducerRepresentationAdoption={source:pin(fileURLToPath(import.meta.url)),actualDurationExecution:pin(resolve(D,'duration18-r4-preview.execution.json')),sixWholeTreeComparisons:rows,scopeTargetOrSupportSetChanged:false,newTaskContentOrRuntimeChange:false,rawRoleSpecificityRepresentationChangeExplicitlyRecorded:true};payload.set(AUTHOR,Buffer.from(enc(author)))
const pol=read(resolve(C,POL)),lay=read(resolve(C,LAY)),pinUpdates:any[]=[]
const update=(v:any,ptr='')=>{if(!v||typeof v!=='object')return;if(!Array.isArray(v)&&typeof v.path==='string'&&typeof v.sha256==='string'&&payload.has(v.path)){const next=hash(payload.get(v.path)!);if(next!==v.sha256){pinUpdates.push({pointer:ptr+'/sha256',path:v.path,before:v.sha256,after:next});v.sha256=next}}for(const[k,x]of Object.entries(v))update(x,ptr+'/'+k)}
update(pol);update(lay);payload.set(POL,Buffer.from(enc(pol)));payload.set(LAY,Buffer.from(enc(lay)))
mkdirSync(N)
const write=(path:string,b:string|Buffer)=>{const p=resolve(N,path);assert(p.startsWith(N+'/'));mkdirSync(dirname(p),{recursive:true});writeFileSync(p,b,{flag:'wx'});assert(lstatSync(p).isFile()&&!lstatSync(p).isSymbolicLink()&&lstatSync(p).nlink===1)}
for(const[p,b]of payload)write(p,b)
write('scope-and-whole-view-facts.json.gz',readFileSync(resolve(C,'scope-and-whole-view-facts.json.gz')))
const files=[...payload].map(([path,b])=>{const before=req.approvedImportFilesNotYetApprovedByIndependentMaterializationReview.find((f:any)=>f.path===path);return{path,beforeSha256:before.beforeSha256,candidateSha256:hash(b),bytes:b.length}})
const report={status:'EXACT_SIX_NORMAL_OUTPUT_ADOPTION_WITH_WHOLE_VISIBLE_TREE_ROLE_AND_MEMBERSHIP_CHECK_NOT_NATIVE_OR_STAGE_PASS',retainedR4Request:pin(resolve(C,'materialization-review-request.json')),normalDurationExecution:pin(resolve(D,'duration18-r4-preview.execution.json')),normalCountryExecution:pin(resolve(D,'country83-r4-preview.execution.json')),source21Execution:pin(resolve(D,'fresh-sh-source21-r4.execution.json')),sourceCoverageExecution:pin(resolve(D,'sourceCoverage-r4.execution.json')),rows,activePinUpdates:pinUpdates,exactTaskSelectionPrediction:{old84Retained:84,newAllowed:8,negative69Retained:69},oldCanonicalJ8AndSurvivingStageContainerFocusBothStillRequireActualPublicProbe:true,source:pin(fileURLToPath(import.meta.url))}
write('normal-output-adoption-verification.json',enc(report))
const request={...req,status:'PRIVATE_SH_R5_CANONICAL_NORMAL_OUTPUT_SUCCESSOR_REQUIRES_INDEPENDENT_REVIEW',candidateRoot:relative(R,N),approvedImportFilesNotYetApprovedByIndependentMaterializationReview:files,normalOutputAdoption:pin(resolve(N,'normal-output-adoption-verification.json')),source:pin(fileURLToPath(import.meta.url)),scopeWholeFacts:pin(resolve(N,'scope-and-whole-view-facts.json.gz')),holds:['Whole source/compiler facts on R4 remain bound; no compiler-source,canonical,registry ormappinginput changed by this normal-view representation successor.','Second normal83/18 replay against the adopted R5 input/pins remains pending.','Actual native eight positive/69 negative and both focus cases remain pending.','No Stage receipt is fabricated.']}
write('materialization-review-request.json',enc(request));console.log(enc({request:pin(resolve(N,'materialization-review-request.json')),adoption:pin(resolve(N,'normal-output-adoption-verification.json')),files:files.length}))
