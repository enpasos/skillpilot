import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {gzipSync,gunzipSync} from 'node:zlib'
import {pathToFileURL} from 'node:url'
import assert from 'node:assert/strict'

const [compilerPath,canonicalPath,archivePath,factsPath,baselineArchivePath,taskGoalId]=process.argv.slice(2)
assert(compilerPath&&canonicalPath&&archivePath&&factsPath&&baselineArchivePath&&taskGoalId)
const hash=(bytes:Buffer)=>createHash('sha256').update(bytes).digest('hex')
const compiler=await import(pathToFileURL(compilerPath).href)
const result=compiler.buildApplicabilityCompilation()
const raw=Buffer.from(JSON.stringify(result,null,2)+'\n'),archive=gzipSync(raw,{level:6})
writeFileSync(archivePath,archive,{flag:'wx'})
const metadata={status:'FRESH_FULL21_SOURCE_COMPILER_NOT_NATIVE_OR_STAGE',compilerPath,compilerSha256:hash(readFileSync(compilerPath)),
 rawSha256:hash(raw),rawBytes:raw.length,gzipSha256:hash(archive),gzipBytes:archive.length,reports:result.reports.length,errors:result.summary.errors}
writeFileSync(archivePath+'.metadata.json',JSON.stringify(metadata,null,2)+'\n',{flag:'wx'})
assert.equal(result.reports.length,21);assert.equal(result.summary.errors,0)
const previous=JSON.parse(gunzipSync(readFileSync(baselineArchivePath)).toString('utf8'))
const key=(r:any,g:any)=>r.landscapeId+'/'+g.goalId
const old=new Map<string,any>(previous.reports.flatMap((r:any)=>r.goals.map((g:any)=>[key(r,g),g])))
const all=result.reports.flatMap((r:any)=>r.goals.map((g:any)=>({key:key(r,g),goal:g})))
const appChanges=all.flatMap(({key,goal}:any)=>{const before=old.get(key);return before&&JSON.stringify(before.compiledApplicability)===JSON.stringify(goal.compiledApplicability)?[]:[{key,goalId:goal.goalId,before:before?.compiledApplicability??null,after:goal.compiledApplicability}]})
const canonical=JSON.parse(readFileSync(canonicalPath,'utf8'))
const ids=[taskGoalId,'491e0858-e977-516e-a339-1cc2f9e9690f','57fbbf31-9b8c-5408-9af5-fbc73acd12bb','cf8c5677-f3c5-5563-8f0a-68443fbab7bf','570d5931-f126-5bb4-8b7f-db236d6b727f','743e5470-ff39-551e-9aba-529656418c66','21342eb9-9cfd-4fbf-b28e-60aa2b48f702']
const facts=ids.map(goalId=>{const goal=canonical.goals.find((g:any)=>g.id===goalId),matches=all.filter((x:any)=>x.goal.goalId===goalId);assert(goal&&matches.length===1);return{goalId,storedApplicability:goal.applicability??null,compiledApplicability:matches[0].goal.compiledApplicability,wholeCompilerGoalReport:matches[0].goal}})
const wholeExistingReportGoalChanges=all.filter(({key,goal}:any)=>old.has(key)&&JSON.stringify(old.get(key))!==JSON.stringify(goal)).map(({key,goal}:any)=>({key,goalId:goal.goalId}))
const out={...metadata,baselineArchivePath,baselineArchiveSha256:hash(readFileSync(baselineArchivePath)),
 compiledApplicabilityChangesAgainstFrozenV30SourceBase:appChanges,wholeExistingCompilerGoalReportChangedIds:wholeExistingReportGoalChanges,
 exactWatchedCacheFacts:facts,changedTaskCacheStoredAndFreshlyVerified:true,
 noOfficialSourceCoverageOrScopeSelectionDerivedFromCache:true}
writeFileSync(factsPath,JSON.stringify(out,null,2)+'\n',{flag:'wx'})
for(const fact of facts)assert.deepEqual(fact.storedApplicability,fact.compiledApplicability,'Changed existing goal cache '+fact.goalId)
console.log(JSON.stringify({...metadata,changedCompiledApplicabilities:appChanges.length,freshCylinderApplicability:facts.find((x:any)=>x.goalId===taskGoalId)?.compiledApplicability}))

assert.equal(appChanges.length,1,'only explicit cylinder applicability changes');assert.equal(appChanges[0].goalId,taskGoalId);assert.equal(appChanges[0].before.jurisdiction.length,15);assert.equal(appChanges[0].after.jurisdiction.length,16);assert(appChanges[0].after.jurisdiction.includes('DE-SH'));
