from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path('/home/enpasos/projects/skillpilot')
HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text())


def pin(path):
    return {'path': str(path.relative_to(ROOT)),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'bytes': path.stat().st_size}


spec = importlib.util.spec_from_file_location(
    'existing_finite_host_method', HERE / 'prepare_producer_host.r5.py')
method = importlib.util.module_from_spec(spec)
spec.loader.exec_module(method)
method.guard()
report = read(HERE / 'review-handoff-r5.json')
source = read(HERE / 'source-r5-terminal.json')
assert source['allRequestedCommandsExecuted'] and source['allExecutedExitCodesZero']
assert len(source['commands']) == 2
facts = read(HERE / 'fresh-sh-source21-r5-facts.json')
assert facts['reports'] == 21 and facts['errors'] == 0
assert len(facts['compiledApplicabilityChangesAgainstFrozenV30SourceBase']) == 1
change = facts['compiledApplicabilityChangesAgainstFrozenV30SourceBase'][0]
assert change['goalId'] == '3045f00d-a5b9-547c-b568-593aeac9ffa3'
assert set(change['after']['jurisdiction']) - set(change['before']['jurisdiction']) == {'DE-SH'}
assert set(change['before']['jurisdiction']) <= set(change['after']['jurisdiction'])
assert facts['gzipSha256'] == pin(HERE / 'fresh-sh-source21-r5.json.gz')['sha256']
for item in report['exact12PayloadFiles']:
    assert pin(HERE / 'candidate-r5' / item['path'])['sha256'] == item['candidateSha256']
manifest = read(HERE / 'producer-host-r5-input-manifest.json')
for rel, digest in manifest['files'].items():
    assert pin(HERE / 'producer-host-r5' / rel)['sha256'] == digest, rel

# The earlier handoff used an overbroad carryforward field name, despite
# explicitly listing the changed author JSON. Preserve it as history and bind
# the actual fresh R5 executions instead; no carryforward inference is needed.
report.pop('sourceEvidenceCarryforward')
report['retainedEarlierR5Handoff'] = pin(HERE / 'review-handoff-r5.json')
report['earlierHandoffClaimClarification'] = (
    'The earlier field allCanonRegistryMappingCompilerAndSourceArtifactBytesEqual '
    'was too broad: the author JSON did change, as its exact nine-path list states. '
    'The final proof uses two actual fresh R5 source commands, not that inference. '
    'Its input/payload bytes and the six genuine normal outputs are unchanged.')
report['actualFreshR5FullSourceAndSourceCoverage'] = pin(HERE / 'source-r5-terminal.json')
report['actualFreshR5FullSourceFacts'] = pin(HERE / 'fresh-sh-source21-r5-facts.json')
report['actualFreshR5FullSourceArchive'] = pin(HERE / 'fresh-sh-source21-r5.json.gz')
report['sourceRunner'] = pin(HERE / 'run_fresh_source.r5.py')
report['fullSource21Errors'] = 0
report['actualFourR5CommandExitCodes'] = [0, 0, 0, 0]
report['constructionTimePendingCacheFieldSupersededByActualR5Run'] = True
report['holds'][0] = 'Independent materialization/source/producer review pending; actual four R5 commands are terminal0.'
report['source'] = pin(Path(__file__).resolve())
method.guard()
target = HERE / 'terminal-review-handoff-r5.json'
assert not target.exists()
target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'handoff': pin(target), 'request': report['candidateRequest'],
                  'actualFourExitCodes': [0, 0, 0, 0], 'stageOrNativePass': False}))
