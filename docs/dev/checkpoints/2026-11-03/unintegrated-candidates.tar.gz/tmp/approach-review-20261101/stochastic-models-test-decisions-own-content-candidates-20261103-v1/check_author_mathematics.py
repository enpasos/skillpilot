"""Independent finite arithmetic checks for own candidate givens; no learner grading or release claim."""
from pathlib import Path
import hashlib,json,math
from scipy.stats import binom,norm
H=Path(__file__).resolve().parent
result={"status":"ACTUAL_AUTHOR_ARITHMETIC_CHECKS_NOT_RESPONSE_GRADING", "power":[]}
for label,n,k in [('A',80,14),('B',160,24),('C',160,22)]:
 row={'label':label,'n':n,'k':k}
 for key,p in [('alpha',.1),('power',.2)]:
  direct=math.fsum(math.comb(n,x)*p**x*(1-p)**(n-x) for x in range(k,n+1))
  scipy=float(binom.sf(k-1,n,p))
  assert abs(direct-scipy)<2e-14
  row[key]=direct
 row['beta']=1-row['power'];row['satisfiesBoth']=row['alpha']<=.05 and row['beta']<=.1
 result['power'].append(row)
assert [r['label'] for r in result['power'] if r['satisfiesBoth']]==['B']
observations=[x for x,c in zip(range(96,105),[1,3,5,7,8,7,5,3,1]) for _ in range(c)]
mean=math.fsum(observations)/len(observations);ss=math.fsum((x-mean)**2 for x in observations)
variance=ss/len(observations);sd=math.sqrt(variance)
assert (len(observations),mean,ss,variance)==(40,100.,140.,3.5)
cdf=lambda z:.5*(1+math.erf(z/math.sqrt(2)))
interval=cdf(2.5/sd)-cdf(-2.5/sd);tail=1-cdf(4/sd)
assert abs(interval-(norm.cdf(102.5,mean,sd)-norm.cdf(97.5,mean,sd)))<1e-14
assert abs(tail-norm.sf(104,mean,sd))<1e-14
empirical=sum(97.5<=x<=102.5 for x in observations)/40
assert empirical==.8
result['model']={'count':40,'mean':mean,'squaredDeviationSum':ss,'varianceDivisorM':variance,'sd':sd,'interval':interval,'upperTail':tail,'empiricalInterval':empirical,'alternateMMinusOneVariance':ss/39,'alternateMMinusOneInterval':cdf(2.5/math.sqrt(ss/39))-cdf(-2.5/math.sqrt(ss/39))}
# Formula-derived derivatives are AUTHOR checks only: the student may use the known normal properties.
f=lambda x:math.exp(-(x-10)**2/8)/(2*math.sqrt(2*math.pi))
fprime=lambda x:-(x-10)/4*f(x)
fsecond=lambda x:((x-10)**2/16-.25)*f(x)
assert fprime(10)==0 and fprime(9)>0 and fprime(11)<0
assert fsecond(8)==0 and fsecond(12)==0 and fsecond(9)<0 and fsecond(7)>0 and fsecond(13)>0
assert abs(f(10)-norm.pdf(10,10,2))<1e-15
assert abs(norm.pdf(10,10,1)/f(10)-2)<1e-14
result['density']={'mu':10,'sigma':2,'variance':4,'maximumX':10,'inflectionXs':[8,12],'maximumDensity':f(10),'inflectionDensity':f(8),'B':{'mu':14,'sigma':2},'C':{'mu':10,'sigma':1},'noDifferentiationRequirementAdded':True}
result['scores']={}
for folder in ['power-graph-ae348','normal-model-5dbf','normal-density-7d9c']:
 j=json.loads((H/folder/'whole-content-draft.json').read_text());sc=j['examData']['scoring']
 assert sum(s['points'] for s in sc['steps'])==sc['maxPoints']
 assert j['examData']['taskContent']==(H/folder/'task.de.md').read_text()
 assert j['examData']['solutionContent']==(H/folder/'solution-and-rubric.de.md').read_text()
 assert j['examData']['taskContentEn']==(H/folder/'task.en.md').read_text()
 assert j['examData']['solutionContentEn']==(H/folder/'solution-and-rubric.en.md').read_text()
 result['scores'][folder]={'max':sc['maxPoints'],'passing':sc['passingPoints'],'rows':len(sc['steps'])}
media=json.loads((H/'task-media-manifest.json').read_text())
for row in media['media']:
 for ext in ['png','svg']:
  p=H/row[ext]['path'];data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==row[ext]['sha256'] and len(data)==row[ext]['bytes']
  assert row[ext]['sha256'] in p.name
result['twelveActualMediaHashesAndNamesCorrect']=True
result['noSourceScopeOrMasteryApproval']=True
out=H/'author-mathematics-checks.json'
with out.open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(result,ensure_ascii=False))
