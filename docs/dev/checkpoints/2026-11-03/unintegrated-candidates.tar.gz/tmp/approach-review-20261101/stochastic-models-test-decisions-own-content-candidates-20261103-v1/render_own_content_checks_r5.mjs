import {createRequire} from 'node:module';
import {pathToFileURL, fileURLToPath} from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
import http from 'node:http';
import crypto from 'node:crypto';
const here=path.dirname(fileURLToPath(import.meta.url));
const repo=path.resolve(here,'../../..');
const req=createRequire(path.join(repo,'app/package.json'));
const moduleOf=async name=>import(pathToFileURL(req.resolve(name)).href);
const React=req('react');
const {renderToStaticMarkup}=req('react-dom/server');
const Markdown=(await moduleOf('react-markdown')).default;
const remarkGfm=(await moduleOf('remark-gfm')).default;
const remarkMath=(await moduleOf('remark-math')).default;
const rehypeKatex=(await moduleOf('rehype-katex')).default;
const {unified}=await moduleOf('unified');
const remarkParse=(await moduleOf('remark-parse')).default;
const katex=req('katex');
const {chromium}=req('playwright');
const manifest=JSON.parse(fs.readFileSync(path.join(here,'task-media-manifest.json'),'utf8'));
const katexDir=path.dirname(req.resolve('katex/package.json'));
const css=fs.readFileSync(path.join(katexDir,'dist/katex.min.css'),'utf8').replaceAll('url(fonts/', 'url(/fonts/');
const folderNames=['power-graph-ae348','normal-model-5dbf','normal-density-7d9c','test-comparison-033-draft-by-sol-child'];
const parser=unified().use(remarkParse).use(remarkMath);
const pages=new Map();let formulaCount=0;
for(const folder of folderNames) for(const lang of ['de','en']) {
 const filenames=[`task.${lang}.md`,`solution-and-rubric.${lang}.md`];
 const sections=[];
 for(const filename of filenames){
  const markdown=fs.readFileSync(path.join(here,folder,filename),'utf8');
  const walk=node=>{if(node.type==='math'||node.type==='inlineMath'){katex.renderToString(node.value,{throwOnError:true,strict:'error',displayMode:node.type==='math'});formulaCount++;}for(const child of node.children??[])walk(child);};walk(parser.parse(markdown));
  sections.push(React.createElement('section',{key:filename},React.createElement('h2',null,filename),React.createElement(Markdown,{remarkPlugins:[remarkGfm,remarkMath],rehypePlugins:[[rehypeKatex,{throwOnError:true,strict:'error'}]],components:{table:({children})=>React.createElement('div',{className:'table-scroll'},React.createElement('table',null,children))}},markdown)));
 }
 const content=renderToStaticMarkup(React.createElement('main',null,React.createElement('h1',null,`${folder} / ${lang}: private author preview`),...sections));
 pages.set(`/${folder}/${lang}`,`<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}\nbody{overflow-wrap:anywhere;font:17px/1.55 system-ui,sans-serif;color:#142238;background:#fff;margin:0}main{max-width:1050px;margin:24px auto;padding:0 18px}h1{font-size:1.4rem;overflow-wrap:anywhere}section{margin:30px 0}img{display:block;max-width:100%;height:auto}.table-scroll{max-width:100%;overflow:auto}table{border-collapse:collapse;margin:1rem 0}th,td{border:1px solid #b7c0cd;padding:8px 12px;white-space:nowrap}.katex{position:relative;max-width:100%;display:inline-block;overflow-x:auto;overflow-y:hidden;vertical-align:middle}.katex-display>.katex{display:block}.katex-display{overflow-x:auto;overflow-y:hidden;padding:4px 0}</style></head><body>${content}</body></html>`);
}
const routes=new Map();
for(const row of manifest.media)for(const ext of ['png','svg'])routes.set(row[ext].proposedRuntimePath,path.join(here,row[ext].path));
const server=http.createServer((request,response)=>{
 const route=new URL(request.url,'http://127.0.0.1').pathname;
 if(pages.has(route)){response.setHeader('Content-Type','text/html;charset=utf-8');response.end(pages.get(route));return;}
 let file=routes.get(route);
 if(!file&&/^\/fonts\/[\w.-]+\.(?:woff2?|ttf)$/.test(route))file=path.join(katexDir,'dist',route.slice(1));
 if(file&&fs.existsSync(file)){response.setHeader('Content-Type',file.endsWith('.png')?'image/png':file.endsWith('.svg')?'image/svg+xml':'font/woff2');response.end(fs.readFileSync(file));return;}
 response.writeHead(404);response.end('Unknown author preview route');
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({headless:true});
const out=path.join(here,'render-checks-r5');fs.mkdirSync(out,{recursive:true});
const checks=[];
try{
 for(const [route] of pages)for(const width of [1365,390]){
  const page=await browser.newPage({viewport:{width,height:1000},deviceScaleFactor:1});const errors=[];const httpErrors=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)httpErrors.push(`${r.status()} ${r.url()}`);});
  await page.goto(`http://127.0.0.1:${server.address().port}${route}`,{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);
  const observed=await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,katexErrors:document.querySelectorAll('.katex-error').length,tables:document.querySelectorAll('table').length,images:Array.from(document.images,img=>({src:new URL(img.src).pathname,alt:img.alt,complete:img.complete,width:img.naturalWidth,height:img.naturalHeight})),mathNodes:document.querySelectorAll('.katex').length}));
  if(errors.length||httpErrors.length||observed.katexErrors||observed.scrollWidth>width+1||observed.images.length!==(route.startsWith('/test-comparison-033')?0:1)||observed.images.some(i=>!i.complete||!i.width||!i.alt))throw Error(JSON.stringify({route,width,errors,httpErrors,observed}));
  const name=`${route.slice(1).replaceAll('/','-')}-${width}.png`;await page.screenshot({path:path.join(out,name),fullPage:true});
  checks.push({route,width,observed,pageErrors:errors,httpErrors,screenshot:{path:`render-checks-r5/${name}`,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(out,name))).digest('hex')}});await page.close();
 }
 const result={status:'ACTUAL_LOCAL_KATEX_GFM_TABLE_PNG_BROWSER_AUTHOR_CHECKS_NOT_HOST_ACCEPTANCE',formulaCount,pageChecks:checks.length,checks};
 fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({formulaCount,pageChecks:checks.length,allPassed:true}));
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
