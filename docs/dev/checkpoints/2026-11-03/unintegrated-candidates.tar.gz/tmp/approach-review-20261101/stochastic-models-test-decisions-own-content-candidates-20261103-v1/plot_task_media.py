"""Own task givens, deterministic content-addressed PNG/SVG; no teaching images edited."""
from pathlib import Path
import hashlib
import json
import math
import os
os.environ.setdefault('MPLBACKEND', 'Agg')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import binom, norm

HERE = Path(__file__).resolve().parent
OUT = HERE / 'task-media' / 'app' / 'public' / 'assets' / 'assessment-materials' / 'mathematik'
matplotlib.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11,
    'svg.hashsalt': 'skillpilot-stochastic-own-task-v1', 'svg.fonttype': 'none',
    'axes.spines.top': False, 'axes.spines.right': False})
COLORS = ['#1460aa', '#be5c13', '#208653']
STYLES = ['-', '--', ':']
MEDIA = []

def save(fig, goal_id, key, lang, alt):
    folder = OUT / goal_id
    folder.mkdir(parents=True, exist_ok=True)
    row = {'goalId': goal_id, 'key': key, 'language': lang, 'altText': alt}
    for extension in ['png', 'svg']:
        temporary = folder / (key + '.' + lang + '.working.' + extension)
        metadata = {'Date': None, 'Creator': 'SkillPilot own task plotting script'} if extension == 'svg' else {'Software': 'SkillPilot own task plotting script'}
        fig.savefig(temporary, format=extension, dpi=200, metadata=metadata,
                    bbox_inches='tight', facecolor='white')
        digest = hashlib.sha256(temporary.read_bytes()).hexdigest()
        final = folder / f'{key}.{lang}.{digest}.{extension}'
        if final.exists():
            assert final.read_bytes() == temporary.read_bytes()
            temporary.unlink()
        else:
            temporary.replace(final)
        row[extension] = {'path': str(final.relative_to(HERE)), 'sha256': digest,
            'bytes': final.stat().st_size,
            'proposedRuntimePath': '/assets/assessment-materials/mathematik/' + goal_id + '/' + final.name}
    MEDIA.append(row)
    plt.close(fig)

RULES = [('A', 80, 14), ('B', 160, 24), ('C', 160, 22)]
for lang in ['de', 'en']:
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), gridspec_kw={'width_ratios': [1.45, 1]}, layout='constrained')
    for ax, interval in zip(axes, [(0.02, 0.32), (0.07, 0.13)]):
        p = np.linspace(*interval, 1401)
        for (label, n, k), color, style in zip(RULES, COLORS, STYLES):
            ax.plot(p, binom.sf(k-1, n, p), label=f'{label}: n = {n}, k = {k}', color=color, linestyle=style, linewidth=2.3)
            for point in [.1, .2]:
                if interval[0] <= point <= interval[1]:
                    ax.plot(point, binom.sf(k-1, n, point), 'o', color=color, markersize=4)
        ax.set_xlabel('wahrer Anteil p' if lang == 'de' else 'true proportion p')
        ax.set_ylabel('G(p)')
        ax.grid(True, color='#d8dee6', linewidth=.6)
        ax.set_xlim(*interval)
        ax.axvline(.1, color='#6b7280', linewidth=.9, linestyle='-.')
        ax.axhline(.05, color='#6b7280', linewidth=.9, linestyle='-.')
    axes[0].axvline(.2, color='#6b7280', linewidth=.9, linestyle='-.')
    axes[0].axhline(.9, color='#6b7280', linewidth=.9, linestyle='-.')
    axes[0].set_ylim(0, 1.02)
    axes[0].set_xticks([.05, .10, .15, .20, .25, .30])
    axes[0].set_yticks(np.arange(0, 1.01, .1))
    axes[0].legend(loc='lower right', framealpha=1)
    axes[0].set_title('Gütefunktionen' if lang == 'de' else 'Power functions')
    axes[1].set_ylim(0, .13)
    axes[1].set_xticks(np.arange(.07, .131, .01))
    axes[1].set_yticks(np.arange(0, .131, .01))
    axes[1].set_title('Vergrößerter Ausschnitt' if lang == 'de' else 'Enlarged detail')
    save(fig, 'ae3483e3-4712-56a1-a881-2e1f8a1a8df9', 'power-function-choices', lang,
         'Zwei Diagramme derselben drei steigenden Gütefunktionen A, B und C. Links die Gesamtansicht mit p von 0,02 bis 0,32 und G(p) von 0 bis 1; rechts der vergrößerte Bereich um p=0,10. Legende: A n=80 k=14, B n=160 k=24, C n=160 k=22. Gitter und Hilfslinien erlauben das Ablesen an p=0,10 und p=0,20.' if lang == 'de' else
         'Two plots of the same three increasing power functions A, B and C. The left plot shows p from 0.02 to 0.32 and G(p) from 0 to 1; the right plot enlarges the region around p=0.10. Legend: A n=80 k=14, B n=160 k=24, C n=160 k=22. Grid and guide lines support readings at p=0.10 and p=0.20.')

    fig, ax = plt.subplots(figsize=(10, 4.8), layout='constrained')
    xs = np.linspace(2, 22, 2001)
    for label, mu, sigma, color, style in zip(['A', 'B', 'C'], [10, 14, 10], [2, 2, 1], COLORS, STYLES):
        ax.plot(xs, norm.pdf(xs, mu, sigma), label=label, color=color, linestyle=style, linewidth=2.4)
    ax.set(xlim=(2, 22), ylim=(0, .45), xlabel='x (mm)',
           ylabel='Dichte (1/mm)' if lang == 'de' else 'density (1/mm)',
           title='Drei Normaldichten' if lang == 'de' else 'Three normal densities')
    ax.set_xticks(np.arange(2, 23, 2))
    ax.set_yticks(np.arange(0, .451, .05))
    ax.grid(True, color='#d8dee6', linewidth=.6)
    ax.legend(title='Graph', loc='upper right', framealpha=1)
    save(fig, '7d9c565c-8df1-40ca-b3c6-2d4ec51e9140', 'normal-density-comparison', lang,
         'Drei Glockenkurven A, B und C mit lesbarer x-Achse in Millimetern und Dichteachse in 1/mm. A ist blau durchgezogen, B orange gestrichelt und C grün gepunktet. Es sind keine Hoch- oder Wendepunkte markiert; Gitter und Skalen gehören zur Aufgabeninformation.' if lang == 'de' else
         'Three bell curves A, B and C with a readable x-axis in millimetres and density axis in 1/mm. A is solid blue, B dashed orange and C dotted green. No maxima or inflection points are marked; the grid and scales are task givens.')

    values = np.arange(96, 105)
    frequencies = np.array([1, 3, 5, 7, 8, 7, 5, 3, 1])
    fig, ax = plt.subplots(figsize=(9, 4.3), layout='constrained')
    ax.bar(values, frequencies, width=.88, color='#4d7fac', edgecolor='#183b56')
    ax.set(xlabel='auf ganze ml gerundete Füllmenge' if lang == 'de' else 'fill volume rounded to whole ml',
           ylabel='Anzahl' if lang == 'de' else 'count', ylim=(0, 9),
           title='Messreihe: 40 Füllmengen' if lang == 'de' else 'Measurement series: 40 fill volumes')
    ax.set_xticks(values); ax.set_yticks(np.arange(0, 10))
    ax.grid(axis='y', color='#d8dee6', linewidth=.6);ax.set_axisbelow(True)
    save(fig, '5dbf149c-d335-552c-a918-768a12e09201', 'fill-volume-observations', lang,
         'Säulendiagramm der in der Aufgaben-Tabelle exakt angegebenen 40 gerundeten Füllmengen. Waagerecht stehen die Messwerte 96 bis 104 ml, senkrecht ihre Häufigkeiten. Keine angepasste Normaldichte und keine Modellparameter sind eingezeichnet.' if lang == 'de' else
         'Bar chart of the 40 rounded fill volumes stated exactly in the task table. The horizontal axis shows 96 to 104 ml and the vertical axis their frequencies. No fitted normal density or model parameters are shown.')

manifest = {'status': 'ACTUAL_OWN_TASK_MEDIA_NOT_TEACHING_IMAGES_NOT_PUBLISHED',
    'plotSource': 'plot_task_media.py', 'matplotlibVersion': matplotlib.__version__,
    'powerDefinitions': [{'label': label, 'n': n, 'rejectWhenXAtLeast': k,
                         'alphaAtP0': float(binom.sf(k-1,n,.1)),
                         'powerAtP1': float(binom.sf(k-1,n,.2))} for label,n,k in RULES],
    'densityParametersAuthorOnly': {'A': {'mu': 10, 'sigma': 2}, 'B': {'mu': 14, 'sigma': 2}, 'C': {'mu': 10, 'sigma': 1}},
    'empiricalData': {'valuesMl': values.tolist(), 'frequencies': frequencies.tolist(), 'count': int(frequencies.sum()),
                      'construction': 'Own synthetic examination dataset in a realistic filling context; no claim of an external measurement study.'},
    'media': MEDIA, 'runtimePathsAreProposalsOnlyRootAssetsRemainUntouched': True}
manifest_bytes=(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n').encode()
manifest_path=HERE/'task-media-manifest.json'
if manifest_path.exists():
    assert manifest_path.read_bytes()==manifest_bytes, 'A differing existing media manifest must be retained as its own revision.'
else:
    with manifest_path.open('xb') as output: output.write(manifest_bytes)
print(json.dumps({'mediaPairs': len(MEDIA), 'files': len(MEDIA)*2, 'powerChecks': manifest['powerDefinitions']}))
