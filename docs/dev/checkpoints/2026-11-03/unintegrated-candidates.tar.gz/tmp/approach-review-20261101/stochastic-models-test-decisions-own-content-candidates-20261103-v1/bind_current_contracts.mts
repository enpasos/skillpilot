import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFileSync,readdirSync,writeFileSync} from 'node:fs'
import {resolve,dirname,relative} from 'node:path'
import {fileURLToPath} from 'node:url'
import {collectMathAtomicSupportContext} from '../../../app/scripts/mathStageScopePolicy'
const R='/home/enpasos/projects/skillpilot',H=dirname(fileURLToPath(import.meta.url))
const CAN='curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json',LED='curricula/DE/Gymnasium/quality/release-model/mathematik.semantic-kinds.json'
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex'),load=(p:string)=>JSON.parse(readFileSync(p,'utf8'))
const canon=load(resolve(R,CAN)),ledger=load(resolve(R,LED)),goals=new Map<string,any>(),bindings:any[]=[]
assert.equal(hash(resolve(R,CAN)),'5f23d314ed1b31caae2e5994921c5fa2599ca7e7f718a5b9fc9d61334713bf37')
assert.equal(ledger.counts.curricularAtomic,807)
for(const filename of readdirSync(resolve(R,'curricula/DE/Gymnasium/canonical')).filter(x=>x.endsWith('.json')).sort()){
 const path='curricula/DE/Gymnasium/canonical/'+filename;bindings.push({path,sha256:hash(resolve(R,path))});for(const goal of load(resolve(R,path)).goals){assert(!goals.has(goal.id));goals.set(goal.id,goal)}
}
const targets=['03357e70-2280-532f-b629-5dfa31dc44eb','ae3483e3-4712-56a1-a881-2e1f8a1a8df9','5dbf149c-d335-552c-a918-768a12e09201','7d9c565c-8df1-40ca-b3c6-2d4ec51e9140']
for(const id of targets)assert.equal(ledger.decisions.find((x:any)=>x.goalId===id).semanticKind,'curricularAtomic')
const context=collectMathAtomicSupportContext(targets,goals),wholeIds=new Set([...targets,...context.supportUnionGoalIds])
const oldTasks=['9cf020ee-4f6b-554e-97d6-eca3e2aabe99','99e45593-8509-5f51-832e-39ed2a9c10d9','14e40ac8-9666-5bf5-a011-870d62b8e597','6eb917e6-a204-5150-833f-a4455c8a05b0']
const priority='tmp/approach-review-20261101/astra-remaining-math-three-groups-priority-20261103-v1/priority-decision.json';assert.equal(hash(resolve(R,priority)),'a720d1ca3ff341563c663db28c4080cdd9c96baea5297f6f8b9aaa205529c659')
const ancestors=new Set<string>();let pending=[...wholeIds];while(pending.length){const child=pending.pop()!;for(const [id,g]of goals)if((g.contains??[]).includes(child)&&!ancestors.has(id)){ancestors.add(id);pending.push(id)}}
const snapshot={status:'READ_ONLY_AUTHORING_BASE_NOT_NATIVE_OR_SCOPE_REVIEW',targetGoalIds:targets,canonicalBindings:bindings,ledgerBinding:{path:LED,sha256:hash(resolve(R,LED)),curricularAtomicCount:807},priorityDecision:{path:priority,sha256:hash(resolve(R,priority))},wholeTargetsAndAtomicPreparation:Object.fromEntries([...wholeIds].sort().map(id=>[id,goals.get(id)])),wholeAncestorContracts:Object.fromEntries([...ancestors].sort().map(id=>[id,goals.get(id)])),productiveAuthoringSupportContext:context,wholeExistingOverlapTasks:Object.fromEntries(oldTasks.map(id=>[id,goals.get(id)])),noRequiresOrGraphOrScopeWrite:true}
writeFileSync(resolve(H,'whole-current-contracts-and-preparation.json'),JSON.stringify(snapshot,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({wholeAtoms:wholeIds.size,ancestors:ancestors.size,perGoal:context.tasks.map(x=>({id:x.taskGoalId,supportCount:x.supportGoalIds.length})),rootCanon:hash(resolve(R,CAN))}))
