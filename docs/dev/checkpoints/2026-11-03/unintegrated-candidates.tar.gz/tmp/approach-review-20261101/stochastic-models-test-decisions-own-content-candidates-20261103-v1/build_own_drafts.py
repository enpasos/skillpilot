"""Finite own content drafts. No canonical, graph, source-policy or learner mutation."""
from pathlib import Path
import json

H = Path(__file__).resolve().parent
MEDIA = json.loads((H/'task-media-manifest.json').read_text())['media']

COMMON_DE = r"""
**Gewöhnliche Gesamtbewertung:** Die Teilpunkte ergeben genau einen Gesamtwert. Vergleiche diesen nach der unten genannten gewöhnlichen Kappung mit der einen Bestehensschwelle. Es gibt keine Teil-PASS-Felder oder zusätzliche Voraussetzungsevidenz.

Fachlich passende Leistungen zählen überall in der Abgabe, auch in Tabellen, Skizzen, Rechenschritten oder knappen Kommentaren. Es ist keine wortgleiche Musterlösung und keine doppelte Begründung in mehreren Teilaufgaben nötig. Gleichwertige mathematische Verfahren sind zulässig. Lokale Rechen-, Ablese-, Vorzeichen- oder Übertragungsfehler werden gezielt und nur einmal abgezogen; richtig ausgeführte Folgearbeit erhält ihre Punkte. Ein einzelner falscher Wert bedeutet nicht, dass eine ganze Kernhandlung fehlt. Nicht gezeigte Arbeit darf nicht unterstellt werden. Die Rubrik bewertet nur diesen neuen Aufgabenauftrag; sie ändert weder die Graphregeln noch bereits bestehende Mastery.
"""
COMMON_EN = r"""
**Ordinary overall grading:** Partial credit yields exactly one total score. After the ordinary cap stated below, compare it with the single passing threshold. There are no part-pass fields or additional prerequisite-evidence requirements.

Credit relevant work wherever it appears in the submission, including tables, sketches, calculations and concise comments. Wording matching the reference and duplicate explanations in separate parts are unnecessary. Mathematically equivalent methods are accepted. Deduct for a local arithmetic, graph-reading, sign or copying error specifically and only once; award correctly executed follow-through. One incorrect value does not mean an entire core action is absent. Do not assume work not shown. This rubric grades only the new task; it changes neither graph rules nor existing mastery.
"""

def media(goal, lang):
    return next(x for x in MEDIA if x['goalId']==goal and x['language']==lang)

def write_form(key, goal, title, title_en, task_de, task_en, solution_de, solution_en,
               maximum, passing, cap, rows, cap_de, cap_en, demand):
    folder = H/key
    folder.mkdir(exist_ok=True)
    md = media(goal, 'de'); me = media(goal, 'en')
    task_de=task_de.replace('__PNG__',md['png']['proposedRuntimePath'])
    task_en=task_en.replace('__PNG__',me['png']['proposedRuntimePath'])
    solution_de += '\n\n'+COMMON_DE+f'\nDer Rohwert liegt zwischen 0 und {maximum}; die eine Bestehensschwelle ist {passing}. '+cap_de+'\n'
    solution_en += '\n\n'+COMMON_EN+f'\nThe raw total ranges from 0 to {maximum}; the single passing threshold is {passing}. '+cap_en+'\n'
    assert sum(x[1] for x in rows)==maximum
    draft={'candidateKey':key,'status':'PRIVATE_WHOLE_CONTENT_DRAFT_PENDING_INDEPENDENT_CONTENT_REVIEW_NO_SCOPE_OR_MATERIALIZATION_PASS',
        'existingGoalId':goal,'title':title,'titleEn':title_en,
        'proposedSameIdentityExecutionForm':{'semanticKindRemains':'curricularAtomic','nodeKindIfLaterApproved':'exam',
            'noNewGoalOrMasteryIdentity':True,'curricularQaPopulationRemains':807,
            'requires':'All current requires retained for this content draft; no new edge or dependency claim.'},
        'examData':{'reviewStatus':'draft','coveredGoalIds':[goal],'coveredStrands':['L4','L5'],'demandLevels':demand,
            'taskContent':task_de,'taskContentEn':task_en,'solutionContent':solution_de,'solutionContentEn':solution_en,
            'scoring':{'maxPoints':maximum,'passingPoints':passing,'steps':[{'id':r[0],'points':r[1],'description':r[2],'descriptionEn':r[3]} for r in rows]}},
        'ordinaryCap':{'maximumIfCoreActionEntirelyMissing':cap,'explanationDe':cap_de,'explanationEn':cap_en,
                       'notASeparateResultOrPrerequisiteQualification':True},
        'actualTaskMedia':[md,me],
        'sourceAndScope':'Own competence-faithful task, no official task-coverage claim. Content approval would not approve any placement or broaden current target sets.'}
    for name, content in [('task.de.md',task_de),('task.en.md',task_en),('solution-and-rubric.de.md',solution_de),('solution-and-rubric.en.md',solution_en)]:
        (folder/name).write_text(content.strip()+'\n')
    (folder/'whole-content-draft.json').write_text(json.dumps(draft,ensure_ascii=False,indent=2)+'\n')


write_form('power-graph-ae348','ae3483e3-4712-56a1-a881-2e1f8a1a8df9',
    'Eine Qualitätskontrolle anhand ihrer Gütegraphen auswählen',
    'Select a quality-control test from its power graphs',
    r"""Eine Qualitätskontrolle soll einen erhöhten Anteil fehlerhafter Bauteile erkennen. Für jede unabhängig und zufällig gezogene Stichprobe sei $X$ die Anzahl fehlerhafter Teile und $X\sim B(n,p)$. Es wird $H_0:p\le0{,}10$ gegen $H_1:p>0{,}10$ geprüft. Alle drei Kandidaten verwerfen $H_0$, wenn $X\ge k$ gilt:

| Kandidat | Stichprobenumfang $n$ | Verwerfungsbeginn $k$ |
|---|---:|---:|
| A | 80 | 14 |
| B | 160 | 24 |
| C | 160 | 22 |

Die Grafik zeigt die **Gütefunktion** $G(p)=P_p(X\ge k)$ jedes Kandidaten. Rechts ist derselbe kleine Ausschnitt vergrößert; es sind keine weiteren Tests.

![Gütefunktionen A, B und C mit vergrößertem Ausschnitt](__PNG__)

Die Kontrolle soll beide Anforderungen erfüllen:

- Bei $p=0{,}10$ soll $H_0$ mit Wahrscheinlichkeit höchstens $0{,}05$ verworfen werden.
- Bei $p=0{,}20$ soll die Wahrscheinlichkeit des Nichtverwerfens höchstens $0{,}10$ betragen.

**1 · Bedeutung der Kurven (2 BE)**

Erkläre, welches Ereignis eine Höhe $G(p)$ beschreibt und was die Höhe an $p=0{,}10$ in dieser Kontrolle bedeutet.

**2 · Die Graphen auswerten (6 BE)**

Lies für A, B und C jeweils $G(0{,}10)$ und $G(0{,}20)$ ungefähr ab. Zwei Dezimalstellen beziehungsweise hinreichend genaue graphisch belegte Schranken genügen. Eine rechnerische Kontrolle ist erlaubt; ordne deine Werte oder Schranken den konkreten Kurven zu.

**3 · Anforderungen übersetzen und entscheiden (6 BE)**

Drücke beide Anforderungen durch $G$ aus. Wähle einen passenden Kandidaten und begründe anhand der Graphen beziehungsweise ihrer zugeordneten Werte, warum er beide Anforderungen erfüllt und warum die anderen ausscheiden. Formuliere die gewählte Entscheidungsregel mit $n$ und $k$. Du sollst aus den gegebenen Kandidaten auswählen, keine neue Testregel entwickeln.
""",
    r"""A quality-control test should detect an increased proportion of defective components. For each independent random sample, let $X$ be the number of defective items, with $X\sim B(n,p)$. Test $H_0:p\le0.10$ against $H_1:p>0.10$. Each candidate rejects $H_0$ when $X\ge k$:

| Candidate | Sample size $n$ | Rejection threshold $k$ |
|---|---:|---:|
| A | 80 | 14 |
| B | 160 | 24 |
| C | 160 | 22 |

The figure shows each candidate's **power function** $G(p)=P_p(X\ge k)$. The right-hand plot enlarges the same small region; it does not show additional tests.

![Power functions A, B and C with an enlarged detail](__PNG__)

The control must satisfy both requirements:

- At $p=0.10$, the probability of rejecting $H_0$ must be at most $0.05$.
- At $p=0.20$, the probability of not rejecting $H_0$ must be at most $0.10$.

**1 · Meaning of the curves (2 points)**

Explain the event described by a height $G(p)$ and the meaning of the height at $p=0.10$ in this control procedure.

**2 · Evaluate the graphs (6 points)**

For A, B and C, read approximate values of $G(0.10)$ and $G(0.20)$. Two decimal places or sufficiently precise graph-supported bounds suffice. Numerical checking is allowed; associate your values or bounds with the actual curves.

**3 · Translate the requirements and decide (6 points)**

Express both requirements in terms of $G$. Select a suitable candidate and use the graphs or their associated values to justify why it satisfies both requirements and why the others fail. State the selected decision rule using $n$ and $k$. Select from the given candidates; do not design a new test rule.
""",
    r"""**1.** $G(p)$ ist die Wahrscheinlichkeit, die Nullhypothese zu verwerfen, wenn der wahre Fehleranteil $p$ beträgt. Da die Verwerfungswahrscheinlichkeit dieser rechtsseitigen Binomialregeln mit $p$ wächst, ist $G(0{,}10)$ das größte Fehler-1-Risiko unter der angegebenen Nullhypothese: Ein tatsächlich bei $10\%$ liegender Fehleranteil wird als erhöht eingestuft.

**2.** Aus der Grafik sind etwa folgende Werte lesbar:

| Kandidat | $G(0{,}10)$ | $G(0{,}20)$ | $1-G(0{,}20)$ |
|---|---:|---:|---:|
| A | 0,03 | 0,75 | 0,25 |
| B | 0,03 | 0,96 | 0,04 |
| C | 0,08 | 0,98 | 0,02 |

Die letzte Spalte ist eine ergänzende Darstellung derselben Information, keine zusätzliche gegebene Datenreihe. Als rechnerische Kontrolle liefert die Binomialverteilung genauer $(0{,}0267488;0{,}7529855)$ für A, $(0{,}0291257;0{,}9575071)$ für B und $(0{,}0781078;0{,}9844063)$ für C. Solche Genauigkeit wird nicht verlangt. Ableseabweichungen von ungefähr $0{,}01$ sind akzeptabel, sofern die maßgeblichen Seiten der Grenzlinien richtig erkannt werden.

**3.** Gefordert sind
$$G(0{,}10)\le0{,}05,\qquad 1-G(0{,}20)\le0{,}10,$$
also gleichwertig $G(0{,}20)\ge0{,}90$. Nur **B** erfüllt beides. A hält zwar die Fehlergrenze bei $p=0{,}10$ ein, seine Teststärke bei $p=0{,}20$ liegt aber nur bei etwa $0{,}75$. C erkennt den erhöhten Anteil sehr häufig, verwirft bei $p=0{,}10$ jedoch zu häufig. Die Regel lautet: $160$ Teile zufällig prüfen und $H_0$ bei mindestens $24$ fehlerhaften Teilen verwerfen. Die verbleibende Nichtverwerfungswahrscheinlichkeit bei $p=0{,}20$ beträgt etwa $4\%$.

**Teilpunkte:** je 1 BE für Verwerfungswahrscheinlichkeit und Fehler-1-Deutung; je 1 BE für die sechs korrekt zugeordneten Werte. Eine korrekte graphische Schranke, die nur die erforderliche Seite der Grenzlinie belegt, erhält je 0,5 BE statt des vollständigen Zahlenpunkts. Je 1 BE für jede übersetzte Anforderung; 1 BE für B samt $n,k$, je 1 BE für die begründete Ablehnung von A und C, 1 BE für die begründete gemeinsame Erfüllung durch B. Korrekte Schranken und Begründungen dürfen vollständig in einer Tabelle stehen.
""",
    r"""**1.** $G(p)$ is the probability of rejecting the null hypothesis when the true defect proportion is $p$. Because the rejection probability of these right-sided binomial rules increases with $p$, $G(0.10)$ is the maximum type-I error probability under the stated null: a defect proportion actually equal to $10\%$ is classified as elevated.

**2.** Approximate graph readings are:

| Candidate | $G(0.10)$ | $G(0.20)$ | $1-G(0.20)$ |
|---|---:|---:|---:|
| A | 0.03 | 0.75 | 0.25 |
| B | 0.03 | 0.96 | 0.04 |
| C | 0.08 | 0.98 | 0.02 |

The last column is an additional presentation of the same information, not another given dataset. A binomial calculation gives the more precise pairs $(0.0267488;0.7529855)$ for A, $(0.0291257;0.9575071)$ for B and $(0.0781078;0.9844063)$ for C. This precision is not required. Reading deviations of about $0.01$ are acceptable provided the correct sides of the relevant boundary lines are identified.

**3.** The requirements are
$$G(0.10)\le0.05,\qquad 1-G(0.20)\le0.10,$$
equivalently $G(0.20)\ge0.90$. Only **B** meets both. A satisfies the error limit at $p=0.10$, but its power at $p=0.20$ is only about $0.75$. C frequently detects the increased proportion, but rejects too frequently at $p=0.10$. The selected rule is to sample $160$ items randomly and reject $H_0$ when at least $24$ are defective. Its remaining probability of not rejecting at $p=0.20$ is about $4\%$.

**Partial credit:** 1 point each for rejection probability and type-I interpretation; 1 point for each of the six correctly associated values. A correct graph-based bound establishing only the required side of a boundary receives 0.5 instead of the full numerical point. Award 1 point for each translated requirement; 1 for B with $n,k$, 1 each for rejecting A and C with reasons, and 1 for explaining that B satisfies both requirements. Correct bounds and reasons may appear entirely in a table.
""",
    14,11,10,
    [('meaning',2,'G(p) als Verwerfungswahrscheinlichkeit und G(0,10) als Fehler erster Art im Kontext erklärt.','Explains G(p) as rejection probability and G(0.10) as the contextual type-I error.'),
     ('p0-readings',3,'Die drei Kurvenwerte bei p=0,10 korrekt zugeordnet; geeignete Schranken erhalten Teilpunkte.','Correctly associates the three curve values at p=0.10; suitable bounds receive partial credit.'),
     ('p1-readings',3,'Die drei Kurvenwerte bei p=0,20 korrekt zugeordnet; geeignete Schranken erhalten Teilpunkte.','Correctly associates the three curve values at p=0.20; suitable bounds receive partial credit.'),
     ('requirements',2,'Beide Anforderungen als G(0,10)≤0,05 und G(0,20)≥0,90 oder gleichwertig übersetzt.','Translates both requirements as G(0.10)≤0.05 and G(0.20)≥0.90 or equivalently.'),
     ('choice',4,'B mit n=160,k=24 begründet ausgewählt; beide anderen Kandidaten anhand ihrer verletzten Anforderung ausgeschlossen.','Selects B with n=160,k=24 with reasons and excludes the other candidates using their violated requirement.')],
    'Kappe den Gesamtwert vor dem Schwellenvergleich auf höchstens 10, wenn über die gesamte Abgabe entweder jede erkennbare fachliche Auswertung der konkret gegebenen Kurven fehlt oder eine der beiden Anforderungen überhaupt nicht berücksichtigt wird oder keine begründete Kandidatenwahl erkennbar ist. Auch ausgerechnete und den konkreten Kurven zugeordnete Werte, passende Schranken, Komplementwahrscheinlichkeiten und knappe Tabellenbegründungen zählen als Auswertung. Kein Cap allein wegen fehlender Dezimalzahlen, eines einzelnen falsch gelesenen Werts oder einer anders platzierten Begründung.',
    'Before comparing with the threshold, cap the total at 10 if the entire submission contains no identifiable mathematical interpretation of the actual given curves, entirely ignores either requirement, or contains no reasoned candidate selection. Calculated values associated with the actual curves, suitable bounds, complementary probabilities and concise table explanations all count. Missing decimal values, one reading error or an explanation placed elsewhere do not by themselves trigger the cap.',
    ['AB2','AB3'])


write_form('normal-model-5dbf','5dbf149c-d335-552c-a918-768a12e09201',
    'Aus einer Messreihe ein Normalmodell begründen', 'Build and assess a normal model from measurements',
    r"""Eine Abfüllanlage soll ungefähr $100\,\mathrm{ml}$ je Behälter liefern. Eine zufällig entnommene Messreihe umfasst $m=40$ Füllungen. Die Messwerte sind auf ganze Milliliter gerundet. Für diese eigene Aufgabe wurde folgender plausibler Datensatz konstruiert; er ist keine veröffentlichte Messstudie.

| Messwert in ml | 96 | 97 | 98 | 99 | 100 | 101 | 102 | 103 | 104 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Häufigkeit | 1 | 3 | 5 | 7 | 8 | 7 | 5 | 3 | 1 |

![Häufigkeiten der 40 gerundeten Füllmengen](__PNG__)

Wir wollen die noch nicht gerundete Füllmenge einer weiteren Füllung durch eine stetige Zufallsgröße $X$ modellieren. Ein Normalmodell ist zu prüfen, nicht als exakt wahr vorauszusetzen. Für die empirische Varianz verwende hier den Divisor $m$:
$$s^2=\frac1m\sum_{i=1}^{m}(x_i-\bar x)^2.$$
Digitale Rechenwerkzeuge sind erlaubt. Schreibe bei $N(\mu,\sigma^2)$ den zweiten Parameter als Varianz.

**1 · Parameter aus den Daten (5 BE)**

Berechne $\bar x$, $s^2$ und $s$. Zeige einen nachvollziehbaren Ansatz, der die Häufigkeiten berücksichtigt.

**2 · Ein Modell aufstellen (4 BE)**

Formuliere ein an die Messreihe angepasstes Normalmodell. Begründe anhand der Datenform, warum es ein sinnvoller erster Ansatz sein kann. Unterscheide die aus dieser Stichprobe geschätzten Parameter von den unbekannten wahren Prozessparametern.

**3 · Bereiche berechnen und deuten (5 BE)**

Bestimme mit deinem Modell $P(97{,}5\le X\le102{,}5)$ und $P(X>104)$ ungefähr. Gib die Wahrscheinlichkeitsansätze und eine kurze Deutung für weitere Füllungen an. Hier ist $X$ bereits die stetig modellierte Füllmenge; es geht nicht um eine Normalapproximation einer Binomialverteilung.

**4 · Das Modell prüfen (6 BE)**

Welcher Anteil der 40 beobachteten Werte liegt zwischen $97{,}5$ und $102{,}5\,\mathrm{ml}$? Vergleiche mit deiner Modellwahrscheinlichkeit und diskutiere, was dieser Vergleich für die Angemessenheit des Modells zeigt und was nicht. Nenne mindestens eine konkrete Grenze der Modellierung in dieser Messsituation. Ein formaler Anpassungstest ist nicht verlangt.
""",
    r"""A filling machine should deliver about $100\,\mathrm{ml}$ per container. A random measurement series contains $m=40$ fills. Measurements are rounded to whole millilitres. The following plausible dataset was constructed for this own task; it is not a published measurement study.

| Measurement in ml | 96 | 97 | 98 | 99 | 100 | 101 | 102 | 103 | 104 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Frequency | 1 | 3 | 5 | 7 | 8 | 7 | 5 | 3 | 1 |

![Frequencies of the 40 rounded fill volumes](__PNG__)

We want to model the unrounded volume of a further fill as a continuous random variable $X$. A normal model is to be assessed, not assumed exactly true. Here use divisor $m$ for the empirical variance:
$$s^2=\frac1m\sum_{i=1}^{m}(x_i-\bar x)^2.$$
Digital calculation tools are allowed. In $N(\mu,\sigma^2)$, write the second parameter as the variance.

**1 · Obtain parameters from the data (5 points)**

Calculate $\bar x$, $s^2$ and $s$. Show an understandable approach incorporating the frequencies.

**2 · Form a model (4 points)**

State a normal model fitted to the measurement series. Use the shape of the data to explain why it can be a reasonable starting point. Distinguish the estimates from this sample from the unknown true process parameters.

**3 · Calculate and interpret ranges (5 points)**

Use your model to estimate $P(97.5\le X\le102.5)$ and $P(X>104)$. State the probability expressions and briefly interpret them for further fills. Here $X$ is already the continuously modelled volume; this is not a normal approximation to a binomial distribution.

**4 · Assess the model (6 points)**

What proportion of the 40 observed values lies between $97.5$ and $102.5\,\mathrm{ml}$? Compare it with the model probability and discuss what this comparison does and does not show about the appropriateness of the model. Give at least one specific limitation in this measurement setting. A formal goodness-of-fit test is not required.
""",
    r"""**1.** Die Häufigkeiten summieren sich zu $40$. Wegen der Symmetrie beziehungsweise durch die gewichtete Summe folgt $\bar x=100\,\mathrm{ml}$. Die gewichtete Quadratsumme der Abweichungen ist
$$2\bigl(1\cdot4^2+3\cdot3^2+5\cdot2^2+7\cdot1^2\bigr)=140\,\mathrm{ml}^2.$$
Somit sind $s^2=140/40=3{,}5\,\mathrm{ml}^2$ und $s=\sqrt{3{,}5}\approx1{,}8708\,\mathrm{ml}$. Die Häufigkeiten müssen berücksichtigt werden; die neun verschiedenen Messwerte sind nicht neun gleich gewichtete Beobachtungen.

**2.** Ein erster angepasster Ansatz ist
$$X\sim N(100;3{,}5)$$
mit geschätztem Mittelwert $100\,\mathrm{ml}$ und geschätzter Standardabweichung etwa $1{,}87\,\mathrm{ml}$. Die Daten sind annähernd glockenförmig, symmetrisch und eingipflig. Das spricht für einen ersten Versuch, beweist aber keine Normalverteilung. Stichprobenmittelwert und empirische Standardabweichung sind hier Parameterschätzungen, nicht die sicher bekannten Prozessparameter.

**3.** Mit $Z\sim N(0;1)$ ist
$$P(97{,}5\le X\le102{,}5)=\Phi\!\left(\frac{2{,}5}{\sqrt{3{,}5}}\right)-\Phi\!\left(\frac{-2{,}5}{\sqrt{3{,}5}}\right)\approx0{,}81855.$$
Das Modell ordnet dem Bereich also ungefähr $81{,}9\%$ der weiteren Füllungen zu. Außerdem
$$P(X>104)=1-\Phi\!\left(\frac4{\sqrt{3{,}5}}\right)\approx0{,}01625,$$
also etwa $1{,}63\%$ oberhalb $104\,\mathrm{ml}$. Die Zahlen sind Modellprognosen unter der Annahme eines weiterhin vergleichbaren Abfüllprozesses. Eine Stetigkeitskorrektur ist hier nicht nötig: Die Bereichsfrage ist für das stetige $X$ formuliert, keine Binomialapproximation und keine Frage nach gerundeten Kategorien.

**4.** Im Bereich liegen $5+7+8+7+5=32$ beobachtete Werte, also $32/40=0{,}80$. Das liegt nahe bei der Modellprognose $0{,}81855$ und ist in einer Stichprobe von 40 Werten kein offensichtlicher Widerspruch. Die Nähe eines einzigen Anteils belegt jedoch weder die gesamte Verteilungsform noch genaue Randwahrscheinlichkeiten. Geeignete konkrete Grenzen sind beispielsweise: begrenzter Stichprobenumfang und unsichere Parameterschätzung; Rundung der Messwerte; mögliche Drift oder Abhängigkeit der Füllungen; dünn belegte Randbereiche; die mathematisch unbeschränkte Normalverteilung gegenüber physisch nicht negativen Füllmengen. Eine einzige passende Grenze mit Erklärung genügt. Der extrem ferne negative Modellbereich wäre bei diesen Parametern praktisch unerheblich; das macht ihn nicht zu einem formalen Verteilungsbeweis.

**Teilpunkte:** 2 BE für den gewichteten Mittelwert; 2 BE für die passende gewichtete Varianzrechnung und 1 BE für die Standardabweichung. 2 BE für ein eindeutiges angepasstes Modell, 1 BE für die Datenform, 1 BE für den Schätzcharakter. 2 BE für Ansatz und Ergebnis der Intervallwahrscheinlichkeit plus 1 BE für die Deutung; 1 BE für Ansatz/Ergebnis des oberen Bereichs plus 1 BE für dessen Deutung. 2 BE für $32/40$, 2 BE für einen sachgerechten Vergleich ohne Verteilungsbeweis, 2 BE für eine konkret erläuterte Grenze. Ein konsequent verwendeter Divisor $m-1$ ist eine vom Auftrag abweichende Konvention: höchstens 1 BE bei der Varianzkonvention abziehen, passende Folgearbeit und ein sinnvoll damit angepasstes Modell weiter werten. In diesem Fall ändern sich die erwarteten numerischen Wahrscheinlichkeiten entsprechend.
""",
    r"""**1.** The frequencies total $40$. Symmetry, or the weighted sum, gives $\bar x=100\,\mathrm{ml}$. The weighted sum of squared deviations is
$$2\bigl(1\cdot4^2+3\cdot3^2+5\cdot2^2+7\cdot1^2\bigr)=140\,\mathrm{ml}^2.$$
Thus $s^2=140/40=3.5\,\mathrm{ml}^2$ and $s=\sqrt{3.5}\approx1.8708\,\mathrm{ml}$. Frequencies matter; the nine distinct measurement values are not nine equally weighted observations.

**2.** A first fitted model is
$$X\sim N(100;3.5),$$
with estimated mean $100\,\mathrm{ml}$ and estimated standard deviation about $1.87\,\mathrm{ml}$. The data are approximately bell-shaped, symmetric and unimodal. This supports trying the model, not proving normality. The sample mean and empirical standard deviation are parameter estimates, not exactly known process parameters.

**3.** With $Z\sim N(0;1)$,
$$P(97.5\le X\le102.5)=\Phi\!\left(\frac{2.5}{\sqrt{3.5}}\right)-\Phi\!\left(\frac{-2.5}{\sqrt{3.5}}\right)\approx0.81855.$$
The model therefore assigns about $81.9\%$ of further fills to this range. Also,
$$P(X>104)=1-\Phi\!\left(\frac4{\sqrt{3.5}}\right)\approx0.01625,$$
or about $1.63\%$ above $104\,\mathrm{ml}$. These are model predictions assuming a still-comparable filling process. No continuity correction is required: the range is stated for continuous $X$, not a binomial approximation or rounded categories.

**4.** The interval contains $5+7+8+7+5=32$ observations, giving $32/40=0.80$. This is close to the predicted $0.81855$ and is not an obvious contradiction in a sample of 40. Closeness of one proportion nevertheless establishes neither the entire distributional shape nor accurate tail probabilities. Suitable specific limitations include finite sample size and uncertain parameter estimates; rounding; possible drift or dependence between fills; sparsely observed tails; or the unbounded mathematical normal distribution versus physically non-negative volumes. One explained relevant limitation suffices. With these parameters the extremely distant negative tail would be practically negligible; that is not a proof of the distributional assumption.

**Partial credit:** 2 points for the weighted mean; 2 for the weighted variance calculation and 1 for standard deviation. Award 2 for an unambiguous fitted model, 1 for data shape and 1 for recognising estimation. Award 2 for the interval expression/result and 1 for its interpretation; 1 for the upper-tail expression/result and 1 for its interpretation. Award 2 for $32/40$, 2 for a sound comparison without claiming proof of normality and 2 for an explained specific limitation. Consistent use of divisor $m-1$ differs from the stated convention: deduct at most 1 point for the variance convention, then credit correct follow-through and a sensible model fitted using that convention. Its expected numerical probabilities change accordingly.
""",
    20,15,14,
    [('sample-mean',2,'Empirischen Mittelwert mit Häufigkeiten korrekt bestimmt.','Correctly computes the empirical mean using frequencies.'),
     ('sample-variance',2,'Gewichtete Quadratsumme und empirische Varianz nachvollziehbar bestimmt.','Shows the weighted squared deviations and empirical variance.'),
     ('sample-sd',1,'Standardabweichung passend aus der Varianz bestimmt.','Obtains standard deviation from the variance.'),
     ('fit-model',2,'An die eigenen Datenkennwerte angepasstes Normalmodell eindeutig angegeben.','States an unambiguous normal model fitted to the data summaries.'),
     ('shape',1,'Glockenform/Symmetrie/Eingipfligkeit konkret an der Messreihe begründet.','Uses the observed bell shape, symmetry or unimodality as a concrete reason.'),
     ('estimate',1,'Stichprobenschätzungen von unbekannten Prozessparametern unterschieden.','Distinguishes sample estimates from unknown process parameters.'),
     ('range',2,'Bereichswahrscheinlichkeit mit eigenem Modell nachvollziehbar berechnet.','Calculates the interval probability using the fitted model.'),
     ('range-context',1,'Intervallwahrscheinlichkeit im Füllkontext gedeutet.','Interprets the interval probability in context.'),
     ('tail',1,'Oberen Bereich mit eigenem Modell nachvollziehbar berechnet.','Calculates the upper-tail probability using the fitted model.'),
     ('tail-context',1,'Oberen Bereich im Füllkontext gedeutet.','Interprets the upper-tail probability in context.'),
     ('empirical-check',2,'Beobachteten Intervallanteil 32/40 bestimmt.','Computes the observed interval fraction 32/40.'),
     ('comparison',2,'Beobachtung und Modell sachgerecht verglichen, ohne einen Normalitätsbeweis zu behaupten.','Compares observations and model without claiming a proof of normality.'),
     ('limitation',2,'Mindestens eine konkrete Modellgrenze verständlich erläutert.','Explains at least one specific model limitation.')],
    'Kappe den Gesamtwert auf höchstens 14, wenn über die gesamte Abgabe jede tatsächliche datengestützte Parameteranpassung fehlt oder keine Bereichswahrscheinlichkeit mit einem Normalmodell erkennbar bearbeitet wurde oder keine sachbezogene begründete Aussage zur begrenzten Aussagekraft des Vergleichs oder zu einer konkreten Modellgrenze erkennbar ist. Ein bloß falsch ausgerechnetes s trotz richtigen Datenansatzes löst keinen Cap aus. Eine knappe richtige Kritik oder eine bereits im Vergleich erläuterte konkrete Grenze zählt; keine feste Unsicherheitsformel und kein formaler Test sind erforderlich.',
    'Cap the total at 14 if the entire submission lacks actual data-based parameter fitting, contains no identifiable work on a range probability using a normal model, or contains no contextual, reasoned statement about the limited evidential value of the comparison or a specific model limitation. A wrongly calculated s following a correct data-based setup does not trigger the cap. A concise valid critique or a limitation already explained in the comparison counts; no fixed uncertainty formula or formal test is required.',
    ['AB1','AB2','AB3'])


write_form('normal-density-7d9c','7d9c565c-8df1-40ca-b3c6-2d4ec51e9140',
    'Normaldichten an Parametern und Graphen untersuchen', 'Investigate normal densities through parameters and graphs',
    r"""Die Grafik zeigt drei Normaldichten A, B und C. Die waagerechte Variable $x$ wird in Millimetern angegeben; die senkrechte Achse zeigt Dichte in $1/\mathrm{mm}$. Zu genau einem Graphen gehört
$$f(x)=\frac1{2\sqrt{2\pi}}\exp\!\left(-\frac{(x-10)^2}{8}\right).$$

![Drei Normaldichten A, B und C](__PNG__)

**1 · Parameter und Zuordnung (5 BE)**

Bestimme Erwartungswert $\mu$ und Standardabweichung $\sigma$ der Dichte $f$ aus Term oder Graph. Ordne $f$ einem der drei Graphen zu und begründe deine Zuordnung anhand von Lage und Streuung. Nenne auch die Varianz.

**2 · Hoch- und Wendepunkte (5 BE)**

Gib die $x$-Lage des Hochpunkts und die $x$-Lagen beider Wendepunkte von $f$ an. Ordne diese Stellen an der passenden Glockenkurve ein, zum Beispiel durch eine kleine markierte Skizze oder eine eindeutige Beschreibung. Bekannte Eigenschaften der Normaldichte dürfen verwendet werden; Ableitungen und exakte Dichtehöhen sind nicht verlangt.

**3 · Parameter ändern (6 BE)**

Welche Parameter passen zu den beiden anderen Graphen? Erkläre getrennt, wie sich gegenüber $f$ eine Änderung von $\mu$ bei gleichem $\sigma$ und eine Änderung von $\sigma$ bei gleichem $\mu$ auswirken. Beziehe Lage, Breite und Höhe ein. Es genügt eine kurze mathematisch klare Erklärung; eine neue Wahrscheinlichkeitsrechnung ist nicht nötig.
""",
    r"""The figure shows three normal densities A, B and C. The horizontal variable $x$ is measured in millimetres; the vertical axis shows density in $1/\mathrm{mm}$. Exactly one graph represents
$$f(x)=\frac1{2\sqrt{2\pi}}\exp\!\left(-\frac{(x-10)^2}{8}\right).$$

![Three normal densities A, B and C](__PNG__)

**1 · Parameters and matching (5 points)**

Determine the expected value $\mu$ and standard deviation $\sigma$ of $f$ from the expression or graph. Match $f$ to one of the three graphs and justify the match using location and spread. Also state the variance.

**2 · Maximum and inflection points (5 points)**

State the $x$-location of the maximum and the $x$-locations of both inflection points of $f$. Identify these locations on the relevant bell curve, for example with a small annotated sketch or an unambiguous description. Known properties of the normal density may be used; derivatives and exact density heights are not required.

**3 · Change the parameters (6 points)**

Which parameters fit the other two graphs? Explain separately how changing $\mu$ with $\sigma$ fixed and changing $\sigma$ with $\mu$ fixed affect the graph relative to $f$. Include location, width and height. A concise mathematically clear explanation suffices; no further probability calculation is needed.
""",
    r"""**1.** Im allgemeinen Dichteterm $\frac1{\sigma\sqrt{2\pi}}\exp(-(x-\mu)^2/(2\sigma^2))$ entsprechen hier $\mu=10\,\mathrm{mm}$ und $\sigma=2\,\mathrm{mm}$; die Varianz ist $4\,\mathrm{mm}^2$. $f$ gehört zu **A**: Symmetriezentrum und Gipfel liegen bei $10$, und A ist breiter und niedriger als C mit demselben Zentrum. Die Parameter können ebenso durch sachgerechtes Auswerten der Glockenkurve erschlossen werden.

**2.** Eine Normaldichte hat ihren Hochpunkt bei $x=\mu$ und ihre Wendestellen bei $x=\mu-\sigma$ und $x=\mu+\sigma$. Somit liegt der Gipfel von A bei $x=10$; links und rechts davon liegen die Wendestellen bei $x=8$ und $x=12$. Dort wechselt die Glockenkurve die Krümmungsrichtung. Die $y$-Werte sind nicht verlangt; ergänzend wären sie am Gipfel ungefähr $0{,}1995\,\mathrm{mm}^{-1}$ und an beiden Wendepunkten ungefähr $0{,}1210\,\mathrm{mm}^{-1}$. Ein freiwilliger korrekter Ableitungsweg ist gleichwertig, aber keine Voraussetzung.

**3.** B hat $\mu=14\,\mathrm{mm}$ und $\sigma=2\,\mathrm{mm}$. Bei gleicher Standardabweichung wird A um $4\,\mathrm{mm}$ nach rechts verschoben; Breite und Gipfelhöhe bleiben gleich. C hat $\mu=10\,\mathrm{mm}$ und $\sigma=1\,\mathrm{mm}$. Das Zentrum bleibt; die Kurve ist horizontal halb so breit und ihr Gipfel doppelt so hoch. Allgemein macht größeres $\sigma$ die Glockenkurve bei gleichem Zentrum breiter und niedriger; kleineres $\sigma$ macht sie schmaler und höher. Die Gesamtfläche bleibt $1$. Die Höhe ist eine Dichte, keine Punktwahrscheinlichkeit; eine solche zusätzliche Erläuterung ist richtig, aber keine neue Teilpflicht dieser Aufgabe.

**Teilpunkte:** 1 BE je für $\mu$ und $\sigma$, 1 BE für die Varianz, 1 BE für A, 1 BE für die begründete Lage-/Streuungszuordnung. In Teil 2: 1 BE für den Gipfel, je 1 BE für beide Wendestellen, 2 BE für ihre sachgerechte Einordnung/Begründung an A (je 1 BE für Symmetrie/Gipfel und den beidseitigen Krümmungswechsel beziehungsweise die verwendete Normaldichte-Eigenschaft). In Teil 3: je 1 BE für die passenden Parameter von B und C; 2 BE für die reine Verschiebung bei gleicher Form/Höhe; 2 BE für geänderte Breite und Höhe bei festem Zentrum. Eine allgemeine richtige Aussage, die die konkreten Änderungen eindeutig umfasst, ist gleichwertig.
""",
    r"""**1.** Comparing with the general density $\frac1{\sigma\sqrt{2\pi}}\exp(-(x-\mu)^2/(2\sigma^2))$ gives $\mu=10\,\mathrm{mm}$ and $\sigma=2\,\mathrm{mm}$; the variance is $4\,\mathrm{mm}^2$. The function is **A**: its centre and maximum are at $10$, and A is wider and lower than C with the same centre. Correct interpretation of the bell curve is an equally valid way to obtain the parameters.

**2.** A normal density has its maximum at $x=\mu$ and inflection points at $x=\mu-\sigma$ and $x=\mu+\sigma$. Thus A peaks at $x=10$, with inflection locations $x=8$ and $x=12$ on either side. The curve changes curvature there. No $y$-values are required; optionally, the height is about $0.1995\,\mathrm{mm}^{-1}$ at the maximum and $0.1210\,\mathrm{mm}^{-1}$ at either inflection. A voluntarily supplied valid differentiation method is equivalent, but is not a prerequisite.

**3.** B has $\mu=14\,\mathrm{mm}$ and $\sigma=2\,\mathrm{mm}$. With standard deviation unchanged, A shifts $4\,\mathrm{mm}$ to the right while width and peak height stay the same. C has $\mu=10\,\mathrm{mm}$ and $\sigma=1\,\mathrm{mm}$. The centre stays fixed, the curve is horizontally half as wide and the peak twice as high. In general, increasing $\sigma$ at fixed centre makes the bell curve wider and lower; decreasing it makes the curve narrower and higher. Total area stays $1$. Height is a density, not a point probability; this additional correct observation is not a new required subskill of this task.

**Partial credit:** 1 point each for $\mu$ and $\sigma$, 1 for variance, 1 for A and 1 for the location/spread justification. In part 2, award 1 for the maximum, 1 for each inflection location and 2 for identifying/justifying their positions on A (1 for symmetry/maximum and 1 for the two-sided change of curvature or the normal-density property used). In part 3, award 1 each for B's and C's parameter pairs, 2 for pure translation with unchanged shape/height and 2 for changing width and height at fixed centre. A correct general statement unambiguously covering the concrete changes is equivalent.
""",
    16,12,11,
    [('mu',1,'Erwartungswert von f richtig aus Term oder Graph entnommen.','Reads the mean of f correctly from expression or graph.'),
     ('sigma',1,'Standardabweichung von f richtig entnommen.','Reads the standard deviation of f correctly.'),
     ('variance',1,'Varianz von Standardabweichung unterschieden.','Distinguishes variance from standard deviation.'),
     ('match',1,'f dem Graphen A zugeordnet.','Matches f to graph A.'),
     ('match-reason',1,'Zuordnung mit Lage und Streuung begründet.','Justifies the match using location and spread.'),
     ('maximum',1,'Gipfel bei x=10 lokalisiert.','Locates the maximum at x=10.'),
     ('left-inflection',1,'Linke Wendestelle bei x=8 lokalisiert.','Locates the left inflection at x=8.'),
     ('right-inflection',1,'Rechte Wendestelle bei x=12 lokalisiert.','Locates the right inflection at x=12.'),
     ('point-meaning',2,'Gipfel und Wendestellen an der Glockenkurve sachgerecht eingeordnet oder mit der Normaldichte-Eigenschaft begründet.','Identifies the maximum and inflections on the bell curve or justifies them with the normal-density property.'),
     ('B-parameters',1,'Parameter von B passend bestimmt.','Determines the parameters of B.'),
     ('C-parameters',1,'Parameter von C passend bestimmt.','Determines the parameters of C.'),
     ('mu-effect',2,'Mu-Änderung als Verschiebung bei gleicher Breite und Höhe erläutert.','Explains changing mu as translation at unchanged width and height.'),
     ('sigma-effect',2,'Sigma-Änderung bei festem Zentrum mit Breiten- und Höhenänderung erläutert.','Explains how changing sigma at fixed centre changes width and height.')],
    'Kappe den Gesamtwert auf höchstens 11, wenn in der gesamten Abgabe jede sinnvolle Behandlung des Erwartungswerts oder der Standardabweichung fehlt, keinerlei Hochpunktlokalisierung oder keinerlei sinnvolle Wendepunktlokalisierung erkennbar ist oder der Einfluss eines der beiden Parameter vollständig unbehandelt bleibt. Eine einzelne fehlende/falsche Wendestelle führt nur zum entsprechenden Punktabzug, sofern eine echte Lokalisierung vorhanden ist. Eine knappe richtige allgemeine Parametererklärung zählt ebenso wie eine konkrete Skizze; exakte Höhen oder Ableitungen sind kein zusätzlicher Teil-PASS.',
    'Cap the total at 11 if the entire submission has no meaningful treatment of the mean or the standard deviation, no identifiable maximum localisation or no meaningful inflection localisation, or entirely omits the effect of either parameter. One missing or incorrect inflection receives the relevant partial deduction only when genuine localisation is present. A concise valid general explanation counts just like a concrete sketch; exact heights and differentiation are not an additional part-pass.',
    ['AB1','AB2'])

print('Three complete same-identity DE/EN content drafts written; no canonical or placement materialized.')
