Die drei größten fachlich sinnvoll abgrenzbaren nächsten Arbeitspakete sind stochastische Modelle und Testentscheidungen, parametrische Raumgeometrie sowie Integralrechnung. Das sind Autorenpakete mit getrennten Aufgabenformen, keine drei Sammelprüfungen.

| Priorität | Paket | Ganze vorhandene Ziele | Aktuelle Endpunkt-PC-Paare | Ungedeckte PC-Paare dieser Ziele |
|---|---|---:|---:|---:|
| 1 | Verteilungsmodelle und Testentscheidungen | 17 | 746 | 834 |
| 2 | Bewegungen, Geraden und Ebenen im Raum | 22 | 676 | 721 |
| 3 | Integralverfahren, Bestandsmodelle und Parameter | 16 | 594 | 594 |

Zusammen sind das **55 disjunkte Ziel-IDs und 2.016 von 5.051 gewöhnlichen Endpunktpaaren**. Die Zahlen beschreiben den Arbeitsvorrat, keine zugesagte Schließung. Die vollständigen IDs, einzelnen Paarzahlen und eng begrenzten Folgeaufträge stehen in `priority-decision.json`. Auf dieser fachlichen Granularität folgt als weiteres großes Paket die geometrische Matrixabbildung mit 350 Endpunktpaaren; sie wurde hier nicht mit Raumgeometrie zusammengezählt. Jahrescontainer wie J10 sind keine Kompetenzgruppe.

Die Grundlage ist unverändert Root-V30: Canon 5f23d314, metadaten-normalisiertes Ledger 1a4cdb4d, 161 PCs, 385 ungedeckte IDs, 216 gewöhnliche Endpunkt-IDs und 9.818 ungedeckte Paare. Der bestehende Native-Gzip 1be4a70b wurde ohne neue JVM oder Rohdatei im Stream gegen sämtliche 161 kompakten Target-/Uncovered-/Endpoint-Mengen geprüft. Die drei Gruppen sind eine nachvollziehbare fachliche Bündelung, kein behauptetes mathematisch eindeutiges Clustering.

**1. Stochastik: neue echte Aufgabenformen, dazu ein begrenzter Platzierungsblock.**

Die größten einzelnen Lücken sind Testvergleich 03357e70, weitere stetige Verteilungen 455ef29a, relative Binomialstreuung 5b54f272, Normalmodellierung an Messdaten 5dbf149c und Dichtegraph-Eigenschaften 7d9c565c mit jeweils 92 Endpunktpaaren. Hinzu kommen Entscheidungsregel 613871f6 und inverse Gütegraph-Auswahl ae3483e3 mit je 80 sowie Stichprobenvariation ae483d98 mit 52. Die schon existierenden Tasks 9cf020ee,99e45593 und 14e40ac8 verlangen diese ganzen Leistungen nicht: bekannte Binomial-/Normalparameter, ein fester Test oder eine Quantile ersetzen weder Modellanpassung noch Testvergleich, Gütegraph-Auswahl oder Hoch-/Wendepunktlokalisierung.

Der erste Autorenauftrag lautet deshalb: zwei konkrete Formen für den ganzen Testvergleich 03357e70 und die inverse Gütegraph-Auswahl ae3483e3 erstellen. Die freie komplexe Regel 613871f6 nicht bloß durch die Wahl eines vorgegebenen Kandidaten behaupten. Als zweiter Inhalt folgt ein Messdaten-/Normalmodell-Entwurf; Grapheneigenschaften 7d9c565c nur bei tatsächlich vollständiger Abfrage mitprüfen. Variationskoeffizient und anderes stetiges Modell erhalten eigene kurze Formen. Dabei ist die direkte Vorbereitung 455ef29a→44dba16e fachlich zu korrigieren: Normalapproximation einer Binomialverteilung ist keine notwendige Voraussetzung für ein Exponential-Wartezeitmodell. Der Ersatz muss zur tatsächlichen neuen Form passen; bestehende diskret/stetig-, Exponential- und Integralziele nutzen, keine neue Grundkompetenz-ID erfinden.

Ein enger bestehender Weg ist 3c8c4a64: Konfidenzintervallinterpretation und Stichprobenplanung sind bereits vollständig enthalten. Genau zwölf BY/SH-SekII-/CrossStage-LK-/Union-Kontexte besitzen die ganze Vorbereitung. Sie sind der nächste Quellen-/Platzierungsblock, noch keine Freigabe.

Quellengrenze: Das tatsächlich gelesene HE-KC trennt verbindliche Q3.1/2 von zusätzlichen Q3.4/5 sowie der nicht verbindlichen Q4.2-Auswahl. Die weiteren stetigen Verteilungen stehen auf Druck-S. 49, die inverse Gütegraph-Aufgabe aufS. 52. Alte Locator 48/51 nicht fortschreiben. Eigene Vertiefungen bleiben möglich, müssen aber ehrlich so bezeichnet werden. Vier BW-SekI-Paare betreffen nur Binomialmodell/Histogrammvergleich; keine LK-Normalprüfung dorthin ausrollen.

**2. Raumgeometrie: Bewegungsform zuerst, vorhandene Schnittaufgaben gezielt prüfen.**

Die großen Endziele sind 492463cf geradlinige Bewegung (114 Paare),a9fde754 Spurpunkte (108),edaf0bb4 Geradenscharen und fd4b7145 Ebenenscharen (je92) sowie 6481fc23 strukturbezogene LGS-Methodenwahl (50). Eine eigenständige ganze Bewegungsform zur bestehenden492-Identität ist der erste inhaltliche Auftrag: Anfangsort, physikalische Zeit-/Längeneinheiten, Geschwindigkeitsvektor, Modelluntersuchung und Kontextdeutung. Der vorhandene BW-Task ea664a30 enthält zusätzlich Geradenlagen und Kegelvolumen mit Pyramiden-Grenzfall; seine ganze gemischte Aufgabe ist keine generische Bewegungsprüfung für 114 andere Kontexte.

Für Spurpunkte ist dagegen bereits eine reale vollständige Aufgabe vorhanden: bc244d82 prüft alle drei Koordinatenebenen samt Proben und Deutung, davor aber auch den allgemeinen Gerade-Ebene-Schnitt. Bei 108 Kandidaten liegt dieser zweite ganze geprüfte Vertrag baf7276f außerhalbT; 104 besitzen ihn im Kontext, 4 nicht. Das ist der konkrete nächste Scopeentscheid: ganze Quelle und Erwerbsfolge des allgemeinen Schnittvertrags prüfen. POnly ist weder automatisch ein Verbot noch ein Freibrief. Wo die Zusatzpflicht nicht begründet ist, eine echte kleinere Spurpunktform erstellen, nicht den vorhandenen Task heimlich beschneiden.

Analog 8d314e15: seine drei Ebenenlagen und der Methodenvergleich sind echt, aber bei 50 Kandidaten liegt der ganze Ebenenlagenvertrag außerhalbT; 44 fehlen genau diesem Kontextziel, zwei HE-SekI-Kontexte deutlich mehr Raumvorbereitung. Eine allgemeine LGS-Lücke verlangt nicht automatisch die gesamte Oberstufen-Ebenenaufgabe. edaf0bb4/fd4b7145 haben keinen direkten Verbraucher; feste Geraden aus 2f8a3a90 oder 002dae37 sind keine Scharuntersuchung. Dafür sind zwei begrenzte Scharformen der nächste Inhaltsauftrag.

HE-S. 42/43 trennt Grundniveau von LK-Scharen, weiteren Abständen und Parabelbahnen. Die 15 genauen SekI-Endpunktpaare sind im JSON separat ausgewiesen und brauchen ihren tatsächlichen frühen bzw. eigenen Zusatzkorridor.

**3. Integralrechnung: vorhandene ganze Aufgaben bewahren, fehlende Ausführungsformen ergänzen.**

Die großen Lücken betreffen 0e8417d7 verknüpfte Exp-/Polynomintegrale (100),bfc2bf06 unendliche Flächen (94),3bf1ce9e Logarithmus-Stammfunktion (92),ece68088 Bestandsrekonstruktion (84),f4935b24 uneigentliche Integrale einschließlich Singularitäten (62) und 23589682 transformierte Exp-/Trig-Funktionen (44).

Der erste Platzierungsauftrag ist endlich: Wirkstofftask 5d3fd2c4 für NI/G9, NW/G9, SL/G9, SN/G8 und ST/G8 jeweils SekII/CrossStage und LK/GK+LK, also 20 PCs. Dort ist die ganze Vorbereitung bereits im tatsächlichen Kontext; dennoch müssen die ganze Aufgabe mit Extrema/Wendepunkt/uneigentlicher AUC und der jeweilige Quellen-/Erwerbskorridor passen. Kein GK-Ausrollen und keine neue Coveragebehauptung aus der alten leeren Coverageliste.

Beim Bestands-Task 0f18f4e2 besteht dagegen in allen 84 Kandidaten eine konkrete Inhaltslücke: die zusätzlich geprüfte ganze Mittelwertkompetenz c1c80b80 fehlt im Kontext. Entweder diese fachlich und quellengetreu als offizielle/eigene Zusatzkompetenz platzieren oder eine echte Bestandsrekonstruktionsform für die vorhandeneece-Identität erstellen. Die bestehende starke 26/28-Aufgabe mit Mittelwerten und unbekanntem Anfangsbestand bleibt ganz.

Als nächste kleine Inhalte passen die Logarithmus-Stammfunktion 3bf1ce9e und eine eigene GK-Form zu den drei transformierten Exp-/Trig-Funktionen 23589682. Der bestehende 60418ab7 verlangt zusätzlich rationale Exponenten und f′·exp(f); 44 GK-Kontexte besitzen gerade diese ganze Zusatzkompetenz nicht. Bei bfc2bf06/f4935b24 vor dem Authoring die unterschiedlichen ganzen Verträge beachten: unendliche Flächen sind nicht identisch mit Integralen an inneren Singularitäten. Keine künstliche R-Kette zwischen ihnen. Die innere Singularität ist durch den HE-S. 37-Bullet allein nicht belegt; dafür zusätzliche Quelle oder ehrliche eigene Vertiefung. Auch 1969d4dc enthält echte Ortskurven-/Scharpflichten und ist kein reines Integralblatt.

Die bereits entschiedenen Vector-36-, Poisson-12- und SH-Zylinder-8-Fälle bleiben **geplant**, einschließlich ihrer konkreten Vorbereitungs-/Platzierungsbedingungen. Das vorbereitete Same-ID-Quadratikpaket bleibt getrennt. Keine erneute Quellenfreigabe und keine alte statische Schließungsprognose übernommen.

Bei einer Aufgabenform für genau eine vorhandene ganze Kompetenz bleibt deren ID, curricularAtomic-Klassifikation und alte Mastery erhalten. Ein weiterer Prüfungsknoten ist nicht allein wegen einer Aufgabenalternative gerechtfertigt. Alle beschriebenen Folgeaufträge brauchen echte Aufgaben/Rubriken oder konkrete Scopeentscheidungen; dieser Bericht verändert weder Root noch Daten, Klassen oder Mastery und behauptet keinen M7-, CI-, Stage- oder Runtime-PASS.
