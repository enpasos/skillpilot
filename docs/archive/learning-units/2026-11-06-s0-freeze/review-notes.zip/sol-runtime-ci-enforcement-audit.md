# Runtime-, Test- und CI-Durchsetzung: Soll vom 6. November 2026

Lesender Audit am 6. November 2026. Maßstab sind der neue Mathematik-/Physikplan
§2 und die angeglichenen Konzepte, keine Behauptung einer schon erfolgten S1-
Migration. Es wurden ausschließlich Quellen und Testkörper gelesen; kein
Backend-Testlauf, keine Remote-CI-Abfrage, Datenbankänderung oder Auslieferung.

**Ergebnis:** Mehrere bestehende Backendtests sichern ausdrücklich die alte
Restbedarfs- und Cut-Semantik. Ein grüner Backendjob wäre deshalb kein Nachweis
der neuen globalen Prüfungsanerkennung. Binäre normale Writes, explizite
Ereignisrechnung, mehrere Fokusregeln und SRS-Eingabevalidierung haben dagegen
konkrete bestehende Durchsetzung. Die neue C(q)- und rekursive Einheitssemantik
ist noch nicht als Runtimevertrag implementiert.

## CI-Kette und Leseschlüssel

Alle Dateipfade sind relativ zum Repository. Zeilen beziehen sich auf den
aktuell gelesenen lokalen Stand.

- **B**: `.github/workflows/ci.yml:715`, Job `backend-ci`; Aufruf bei `:773`:
  `python3 -B ../scripts/run_backend_ci.py --manifest "${BACKEND_FAILURE_MANIFEST}"`.
  `scripts/run_backend_ci.py:184` startet gegebenenfalls einen früheren
  Fehlerselektor mit `./gradlew test --fail-fast`; bei dessen Fehler wird bei
  `:190` beendet. Erst danach folgt bei `:198` der ungefilterte Pflichtaufruf
  **`./gradlew check`**, nicht `test build`. `backend/build.gradle.kts:76`
  konfiguriert `tasks.test` mit `useJUnitPlatform()`. Die gelesene Testkonfiguration
  hat keine Ausschlussliste für die unten genannten JUnitklassen. B bedeutet
  *im ungefilterten Backendtestbestand enthalten*, keinen aktuellen grünen Lauf.
- **F**: Job `frontend-ci`, `.github/workflows/ci.yml:347`. Bei `:440` läuft
  `npm run test:learner-learning-plans`; `app/package.json:47` nennt die konkreten
  API-/History-/UI-Tests. Dies ist kein automatischer Aufruf aller npm-Testskripte.
- **AC**: `.github/workflows/assessment-completion.yml:52`, Job `authoring-and-ui`, führt `test:level-completion` bei :99 und Browser bei :108 aus. PR-/main-Pfadfilter stehen bei :10–42; reine neue Konzept-/LaTeX-Dateien sind darin nicht allgemein erfasst. Der zweite Job `backend-and-postgres` startet bei :196 eine explizit gefilterte Testsuite und prüft bei :286–297 echte XML-Ausführung ohne Skips.
- Testkurzpfade in Tabellen: `service/X.java` bedeutet
  `backend/src/test/java/com/skillpilot/backend/service/X.java`;
  `completion/X.java` entsprechend unter `.../backend/completion/`;
  `claude/X.java` unter `.../backend/connectors/claude/v1/mcp/`.
- Runtimekurzpfade **LS**, **LP**, **CE**, **CP**, **CA**, **LPP** bedeuten
  `backend/src/main/java/com/skillpilot/backend/` plus
  `service/LearnerService.java`, `service/LearnerLearningPlanService.java`,
  `completion/CompletionEvaluator.java`, `completion/CompletionProfileCompiler.java`,
  `completion/CompletionApplicationService.java`,
  `completion/LearningPlanCompletionProjection.java`.
  Weitere Runtimeangaben wie `domain/…`, `openai/…`, `connectors/…` und
  `landscape/…` stehen unter demselben `backend/src/main/java/com/skillpilot/backend/`-Präfix.
- **durchgesetzt** bezeichnet die genannte enge Bedingung; **teilweise** nennt
  ihre Grenze; **Widerspruch** heißt aktive Altsemantik; **S1 offen** heißt kein
  entsprechender neuer Runtime-/CI-Vertrag. Ein Testname allein wird nicht als
  inhaltlicher Beweis benutzt.

## A. Persistenz und binäre explizite Ergebnisse

| ID | Eigenständige Bedingung | Runtime und konkreter Test | CI / Bewertung |
| --- | --- | --- | --- |
| M1 | Neue normale Mastery-Writes sind endlich und genau 0/1. | LS:3265 weist null/NaN/Inf/außerhalb 0–1 ab, :3273 zusätzlich Bruchteile. `service/LearnerGoalCompletionIntegrationTest.java:89` `fractionalWritesCannotCreateMasteryOrCompletionCredit` prüft die Ablehnung. | B; **durchgesetzt im normalen Servicewrite**. |
| M2 | Nicht jeder DB-Wert muss physisch ein Bool sein; Legacy-Grenze ausdrücklich erhalten. | `domain/Mastery.java:34` speichert `double`, Konstruktor :43 und Setter :61 erzwingen kein Bool. `db/changelog/changes/001-initial-schema.yaml:103` verwendet DOUBLE ohne 0/1-Check. | B prüft Serviceverhalten, **kein universeller DB-Binärconstraint**. Das ist eine wichtige Vertragsgrenze, kein Nachweis neuer Teil-Mastery. |
| M3 | Legacy-Lesen verwendet eine klare, endliche Schwelle. | `domain/Mastery.java:19` definiert 0.9, :21 prüft finite Werte. CA:203 verwendet dieselbe Funktion. `completion/CompletionApplicationServiceTest.java:69` `legacyThresholdUsesCurrentProjectedOutcomeAndNeverCreatesPartialMastery` prüft .9/.899/NaN/+Inf. | B; **durchgesetzt**, sagt nichts über C(q). |
| M4 | Signierte Wiederherstellung erhält alte explizite Werte und Zeitpunkte, statt sie still zu neuen Belegen zu machen. | LS:12808 schreibt `entryData.value()` und stellt bei :12819 den alten Timestamp wieder her; normaler Binärwrite wird dabei nicht aufgerufen. `service/LearnerServiceTest.java:529` `importLearnerPreservesCurriculumAndMasteryWhileDiscardingFocusFromIncompletePersonalization`; `service/LearnerGoalCompletionIntegrationTest.java:123` `importingMasteryOrCopyingLearnerNeverImportsCompletionCredit`. | B; **Kompatibilitätsweg vorhanden**. Kein Beweis, dass Import automatisch den strengeren neuen Q-Vertrag qualifiziert. |
| M5 | Ein normaler Coachwrite betrifft das aktive einzelne Ziel; Korrektur kann vorhandene Mastery senken. | LS:3313 lässt ausdrückliche Korrektur außerhalb der Frontier zu, :3351 speichert nur das aufgelöste Ziel. `service/LearnerServiceMasteryCorrectionTest.java:92` `setMastery_allowsExplicitDowngradeOutsideFrontier`; `claude/ClaudeV1MasteryContractTest.java:217` `completionWritesOnlyTheActiveGoalAndLeavesProgressionToTheCanonicalBackend`. | B; **durchgesetzt**, keine globale Rückwärtsschreibung auf Voraussetzungen. |

## B. Voraussetzungen, Projektion und Fokus

| ID | Eigenständige Bedingung | Runtime und konkreter Test | CI / Bewertung |
| --- | --- | --- | --- |
| P1 | Contains-Vererbung wird vor der Fokusauswertung auf dem strukturellen Graphen aufgelöst. | LS:7193, `computeEffectiveRequires` bei :12118 sammelt alle Contains-Eltern (:12137, :12174). `service/ProjectionRoleLearnerServiceTest.java:485` `normalFocusRetainsAnInternalRequirementInheritedFromAnOutsideAncestor`. | B; **durchgesetzt für aufgelöste strukturelle Eingaben**, keine vollständige R⁺-Prüfung daraus ableiten. |
| P2 | Vollständige transitive Hülle vor Fokus schneiden; Rückkehr in F bleibt berücksichtigt. | LS:7231 überspringt eine Anforderung außerhalb F einschließlich ihrer ganzen Kette. `service/ProjectionRoleLearnerServiceTest.java:472` `normalFocusCutsAnOutsideIntermediateBeforeFollowingItsReentryIntoTheFocus` erwartet bei :479 ausdrücklich das zu frühe Angebot des abhängigen Ziels. | B; **Widerspruch zum neuen Soll**. Der Test sichert die alte Cut-Semantik. |
| P3 | Ein direkt gemeisterter Zwischenknoten darf Q→B→A nicht bei B abschneiden. | CE:41 bricht bei `mastered[prerequisite]` ab. `completion/AutomaticCompletionTest.java:20` `masteredIntermediateStopsDemandFromAnOpenAssessment` erwartet :25 fälschlich Erlass von A. LS:7237 beschreibt dieselbe alte Vorbereitungsidee für normale Verfügbarkeit. | B; **Widerspruch**. `completion/CompletionCoreTest.java:160` prüft zwar den Nicht-Cut im separaten Reviewed-Pfad, ersetzt den aktiven Automatic-Pfad nicht. |
| P4 | Normalmodus lässt gültige echte Außenanforderungen unblocking, ohne Mastery zu erfinden. | LS:7190 wählt target∩F; :7231 überspringt Außenanforderungen. `service/ProjectionRoleLearnerServiceTest.java:446` `normalFocusUnionIgnoresValidOutsideRequirementsButPreservesInternalOrderAndMastery` prüft :465–468 keine zusätzlichen Writes. | B; **enge Außenfreigabe durchgesetzt**, jedoch P2/P3 verletzen die vollständige vorgeschaltete Hülle. |
| P5 | Strict behält globale Voraussetzungen. | LS:7190 setzt `prerequisiteScope=null`. `service/ProjectionRoleLearnerServiceTest.java:422` `strictSelectedTargetPrerequisiteOutsideFocusBlocksUntilStoredMasteryReleasesIt`; `service/ExamLearningScopeIntegrationTest.java:149` `strictExamFocusKeepsOutsidePrerequisitesAndAllNineTopicsAndThreeTasks`. | B; **teilweise**: direkte Außenanforderungen getestet; der reguläre Check LS:7206 iteriert eigene/geerbte direkte Requires, nicht allgemein R⁺. P3 bleibt. |
| P6 | Ungültige direkte Referenzen dürfen nicht durch Fokus optimistisch verschwinden. | LS:7212 blockiert fehlende direkte Composition-Referenzen; :7219 blockiert nicht als target/prerequisiteOnly deklarierte direkte Referenzen. `service/ProjectionRoleLearnerServiceTest.java:404` `unknownDirectPrerequisiteBlocksBothFrontiersInEitherMode`. | B; **durchgesetzt für direkte Composition-Referenzen**. LS:7216/7225 toleriert bestimmte alte geerbte Anforderungen; kein universeller Fail-closed-Graphvalidator. |
| P7 | prerequisiteOnly ist strukturelle Unterstützung, kein Progress-/Frontierziel. | LS:7190 verwendet targetGoalIds; `service/ProjectionRoleLearnerServiceTest.java:88` `missingRoleDefaultsToTargetAndPrerequisiteOnlyIsNotTargetOrTransitivelyInferred`, :105 `externalPrerequisiteOnlyGoalEntryHydratesExactlyOneStructuralGoal`. | B; **Rollenunterscheidung vorhanden**; daraus folgt weder Beherrschung noch offizielles Quellenmapping. |
| P8 | Clusteranforderungen berücksichtigen die relevante atomare Basis. | `service/ProjectionRoleLearnerServiceTest.java:500` `normalClusterRequirementAggregatesOnlyItsTargetChildrenInsideTheFocus`; :542 `normalClusterBasisTraversesOutsideClustersToTheirExplicitTargetDescendants`. LS:7710 aggregiert Kinder nach unten ohne Mastery-Writes. | B; **scopebezogene Aggregation getestet**. Vollständige neue atomare Hülle und bestehende Core-Kompatibilitätszweige sind gesondert zu migrieren; kein Beweis der gesamten neuen Graphreferenz. |
| P9 | Leere Frontier allein darf Fokus nicht verbreitern. | LS:8366 verlangt nichtleeren, tatsächlich erledigten Fokus; :8478 verlangt `scopeCompleted`. `service/LearnerServiceTest.java:2638` `blockedIncompleteFocusDoesNotTriggerAutomaticFocusWidening` prüft leere Frontier ohne setScope-Angebot. | B; **Guard durchgesetzt**, aber der Completion-Eingang verwendet noch alte Waivers. |
| P10 | Verbreiterung ist striktes Target-Superset mit mindestens einer offenen Ergänzung, nächster geeigneter Vorfahr zuerst. | LS:9229 prüft Superset, :9233 neue unmastered Ziele. `service/LearnerServiceReproTest.java:408` `getLearnerState_shouldOfferNearestAncestorWhenScopeCompleted`; :494 `completedFocusSkipsAncestorThatAddsOnlyAlreadyMasteredTargets`. | B; **Struktur-/Auswahlregel durchgesetzt**, globales neues C(q) noch nicht berücksichtigt. |
| P11 | Mehrere Wurzeln behalten den unabhängigen Zweig. | LS:9246 publiziert das ganze geordnete Replacement. `service/LearnerServiceTest.java:2759` `multiRootFocusWideningPreservesTheUntouchedPhysicsFocus`. | B; **durchgesetzt für den bestehenden Ablauf**. |
| P12 | Ein Angebot verbreitert nicht ohne ausdrücklichen Auswahlwrite. | LS:9110 veröffentlicht nur `setScope`/goalOptions; LS:9498/9514 ersetzt den Fokus erst im Schreibaufruf. `service/LearnerServiceReproTest.java:408` prüft das read-only Angebot, `service/LearnerServiceTest.java:2759` führt danach ausdrücklich setScope aus. | B; **Backend trennt Lesen und Auswählen**. Das beweist keine reale menschliche Zustimmung in einem Host; diese ist keine deterministische CI-Aussage. |

## C. Prüfungen, Beweisscope und historische Bedeutung

| ID | Eigenständige Bedingung | Runtime und konkreter Test | CI / Bewertung |
| --- | --- | --- | --- |
| Q1 | Ein normales Exam-Passurteil; unter passingPoints kein Masterywrite. | `openai/mcp/de/v1/OpenAiDeV1McpContractAdapter.java:2193`, `connectors/claude/v1/mcp/ClaudeV1McpContractAdapter.java:2077`, `connectors/gemini/v1/mcp/GeminiV1McpContractAdapter.java:1665` prüfen die Gesamtpunktgrenze. `claude/ClaudeV1MasteryContractTest.java:382` `failedExamAttemptDoesNotWriteAndSameExamCanBeEvaluatedAgain`; :444 `passedExamWritesMasteryAndReturnsFeedbackBeforeContinuationInstruction`. | B; **vorhanden**. Kein verstecktes zweites C(q)-Urteil implementiert. Der Backendservice allein nimmt kein earnedPoints-Feld an; Adaptervertrag und allgemeiner Write sind unterschiedliche Grenzen. |
| Q2 | Evaluation-Capability bindet Session, Ziel und Revision. | `claude/ClaudeV1ExamContractTest.java:121` `theEvaluationCapabilityIsBoundToSessionGoalAndRevision`, :132 `anEvaluationCapabilityFromAnotherSessionCannotSaveMastery`, :141 falsches Ziel, :149 Recall-Capability als Exam unzulässig. | B; **durchgesetzt auf diesem Adapterpfad**, keine unveränderliche historische Q-Bedeutung daraus ableiten. |
| Q3 | Freigegebene Rubrik ist formal vollständig und ihre Punkte passen zur Passgrenze. | Claude-Adapter:2434 validiert eindeutige Kriterien/finite positive Punkte/Text; :2450 verlangt Summe ≥ passingPoints und ≤ maxPoints. `claude/ClaudeV1ExamContractTest.java:163` `releasedExamEvaluationRequiresAUsableCriterionRubric`, :190 `releasedRubricMustSupportThePassMarkWithoutExceedingMaxPoints`. | B; **formale Rubrikvalidität vorhanden**; sie beweist nicht, dass fehlendes Kernverständnis rechnerisch nicht kompensierbar ist. |
| Q4 | Wesentliche Fehlvorstellung fällt regulär durch; beiläufiger Rechenfehler kann bestehen. | Die genannten Adapter prüfen Gesamtpunkte und Rubrikstruktur. Kein gelesener Runtime-/Fachtest verbindet alle erlaubten Bestehenswege mit vollständiger gewöhnlicher Zielbedeutung. | **S1/Fachpakete offen**; nicht durch `released` oder Q3 erfüllt. Fachliche Qualifikation bleibt zusätzlich erforderlich. |
| Q5 | C(q) ist ausschließlich qualifizierte unveränderliche gewöhnliche Atomabdeckung; ungeklärtes C(q)=∅. | Suche nach `getCoveredGoalIds()` im Produktionsbackend findet nur `landscape/ExamData.java:38` und Kopien in `ai/CoachStateProjection.java:259`, `ai/LearnerAiController.java:598`, `landscape/LandscapeService.java:669`. CE:54/60 leitet stattdessen aus `no_remaining_demand` ab; CP:51 kompiliert ohne qualifizierte Coverage. | **S1 offen; aktiver Ersatz widerspricht**. Keine CI-Durchsetzung der neuen Qualified-Coverage-Regel. |
| Q6 | Q1 beweist A sofort, obwohl Q2 A braucht und offen bleibt. | `completion/AutomaticCompletionTest.java:59` `sharedPreparationRemainsNecessaryUntilEveryActiveConsumerIsDone` erwartet :61 bei nur Q1 **keinen** Erlass. | B; **direkter Widerspruch**, nicht fehlender Randfall. Neuer unionsbasierter Nachweis fehlt. |
| Q7 | Direkte gewöhnliche Beherrschung, leere Nachfrage, Karten oder Orientierung erzeugen keinen neuen Prüfungsbeweis. | CE:60 erkennt jeden nicht benötigten Knoten an. `completion/AutomaticCompletionTest.java:38` erwartet Karten/Orientierung/ordinary implizit; :50 erwartet eine komplett prüfungsfreie, unbesuchte Scope als fertig. | B; **direkter Widerspruch**. :94 `implicitReasonsNeverInventAssessmentEvidenceForOrdinaryMastery` prüft nur das alte Reason-Format, macht die Anerkennung nicht zulässig. |
| Q8 | Unter gleicher Q-ID darf kein stärkerer/unklarer Anspruch alte binäre Ergebnisse aufwerten. | `domain/Mastery.java:26`/`:34` speichert Zielkey/Wert, keine damalige Q-Vertragsversion. Capability-Revisionsschutz Q2 verhindert nur aktuelle Replayfehler. Kein historischer All-variants-Nachweis oder New-Q-ID-Gate im gelesenen Completion-/Writepfad. | **S1 offen**. Ein heutiger Contenthash oder grüne Capability-Tests erfüllen diesen Quantor nicht. |
| Q9 | C(q)⊆Reach_R⁺(q), ohne Pfad→Coverage-Rückschluss oder dynamische Clustererweiterung. | Der alte CP kompiliert Requires/Contains, liest aber keine Qualified-Coverage. Der neue S0-Minimalitätsauditor prüft §7.3, nicht C(q). | **S1 offen**; keine Runtime-/CI-Abdeckung dieser neuen gerichteten Konsistenz. |

## D. Karten und rekursive Einheiten

| ID | Eigenständige Bedingung | Runtime und konkreter Test | CI / Bewertung |
| --- | --- | --- | --- |
| K1 | Jede erforderliche Karte braucht echten Verified-Recall-Pass. | LS:1401 prüft alle Karten, :1426 verlangt passed plus nichtleeres passedAt. `app/src/hooks/useSrsMastery.ts:185` benutzt alle verifizierten Karten. `service/LearnerServiceTest.java:3283` `verifiedRecallForSekOneFlashcardsStartsAndControlsSrsMastery`; :258 `publicPracticeSyncCannotCreateVerifiedRecall`. | B; **Verifikationsbedingung vorhanden**. Ein Practice-Sync kann sie nicht erfinden. |
| K2 | Aktueller veröffentlichter Node-Type-Vertrag fordert zusätzlich keine fälligen Karten. | `docs/concept/skill-graph/node-types.md:164` verlangt bei :165 keine fälligen Karten. LS:1401–1417 prüft nur Verified-Status, nicht nextReview. Hook:164 zählt due separat und benutzt ihn bei :185 nicht für Mastery. | **offener dokumentierter Widerspruch**. Bestehende Verified-Tests beweisen die No-due-Bedingung nicht. Vor Implementierungsbehauptung fachlich entscheiden/angleichen. |
| K3 | Fehlende/kaputte erforderliche Decks sind unavailable, nicht leere vollständige Mengen. | LS:1246/1256/1263/1272/1277 wirft im strikten Pfad. `service/AssessmentCompletionSrsIntegrationTest.java:99`, :103, :107 prüfen missing/unreadable/empty; :131 prüft valide Decks ohne alten Zustand als unmastered. | B; **strikter Completion-Input fail-closed**. Normalüberlagerung darf beschädigte Einzelziele auslassen und vorhandenen gespeicherten Wert behalten (LS:1385); das ist kein neuer positiver Nachweis. |
| K4 | Kein K-Abschluss durch eine gewöhnliche/Prüfungs-Waiverregel. | CP:48 beschreibt ausdrücklich nur Assessmentschutz; `completion/AutomaticCompletionTest.java:38`/`:46` erlässt cards. SRS-Inputschutz verhindert diesen späteren Waiver nicht. | B; **Widerspruch im Automatic-Pfad**, trotz K1/K3. |
| U1 | Eindeutiger Erwerbsowner, aufgelöste Pflichtvarianten und RequiredOwnQ-Abdeckung jedes eigenen gewöhnlichen Ziels. | `completion/CompletionScopeDefinition.java:6` beschreibt alte Programmscope, nicht rekursive LearningUnit. CE/CP haben keine Own-/RequiredOwnQ-/C(q)-Invariante. | **S1 offen**, kein entsprechender Runtime-/CI-Vertrag. Der neue mathematische Referenzchecker ist keine Produkttestabdeckung. |
| U2 | Rekursiver Abschluss = eigene effektive Ziele und alle Pflichtkinder, ohne neue Unit-Mastery. | CE:74/142 prüft flache Target-/Assessmentmengen; kein Child-Unit-Abschluss. | **S1 offen**; aktuelle Clusteranzeigen sind kein Ersatz für den neuen Einheitsvertrag. |
| U3 | Eltern-/Fremd-Q kann gewöhnliche Kompetenz belegen, ohne eigene Kind-Q/K zu bestehen. | CE:71 übernimmt nur explizite Assessments in passedAssessments; `completion/AutomaticCompletionTest.java:67` schützt eine Kontextprüfung. Aber C(q)-basierte Eltern-/Fremdanerkennung fehlt, und K4 verletzt die Kartenhälfte. | **teilweise alte Q-Sicherheit**, **neue Gesamtregel S1 offen**. |

## E. Globaler IST, Ereignisse, Doppelzählung und Cache

| ID | Eigenständige Bedingung | Runtime und konkreter Test | CI / Bewertung |
| --- | --- | --- | --- |
| G1 | M_eff ist die globale Union qualifizierter explizit bestandener Q und bleibt über Fokus-/Curriculumwechsel verfügbar. | LS:6785 berechnet Waivers aus dem aktuellen vollständigen Personal Curriculum; :6801 delegiert an den alten Evaluator. LPP:31 wählt alten Automatic/Reviewed-Evaluator. Kein historischer globaler C(q)-Registry-/Unionpfad gefunden. | **S1 offen**. Vollständige aktuelle Personal-Curriculum-Nachfrage ist nicht dauerhafte globale Beweisunion. |
| G2 | Gesamt-IST verwendet Vereinigungscredit, ohne explizit und implizit doppelt zu zählen. | LP:2579 zählt einen Set-Eintrag bei explicit **oder** waived. `service/LearningPlanAssessmentCreditTest.java:106` `inclusiveAndExplicitCountingShareOneFixedScheduleAndRealEvents`, :240 `laterExplicitCompletionDoesNotDoubleCountAndRevokedAssessmentReopensRemainingWork`. | B; **Zählmechanik vorhanden**, Quelle waived noch alt; der genannte Test akzeptiert teilweise alte Wiederöffnungssemantik. Keine neue C(q)-Abnahme. |
| G3 | Tages-/Wochenleistung zählt echte datierte explizite Transitions, keine neuen impliziten/Importereignisse. | LS:3353/2123 schreibt echte Transitions; `service/LearnerGoalCompletionService.java:42` prüft Threshold-Crossing, :62/68 liest nur observedTransition. LP:2582 filtert Datum/Plan/explizite aktuelle Mastery. `service/LearningPlanDailyProgressTest.java:47`, :109; `service/LearnerGoalCompletionIntegrationTest.java:123`. | B; **durchgesetzt für bestehende Ereignisrechnung**; Import übernimmt keinen Periodencredit. |
| G4 | Wiederholung ist History, keine zweite Tagescompletion. | `service/LearnerGoalCompletionService.java:43` unterscheidet Practice von Crossing; :55 bindet nur Practice-Evidenz. `service/LearnerGoalCompletionPracticeTest.java:17` `repeatedPracticalCompletionIsEvidenceButNeverDailyProgressCredit`, :38 erster Zeitpunkt unverändert. | B; **durchgesetzt**, gespeicherte Praxisgeschichte ist kein zusätzlicher Mastery-/Qualifikationsstatus. |
| G5 | Überschneidende Blöcke/Platzierungen zählen jedes Atom einmal. | LP:2557 nimmt Set von Plan-IDs; `service/LearningPlanDailyProgressTest.java:92` `overlappingBlocksCountEachGoalOnlyOnce`. `app/src/utils/treeCompletionProgress.ts:49` verwendet Atom-Map, :66 explicit vor implicit; Test `treeCompletionProgress.test.ts:25` enthält mehrfach platzierte shared-Atome. | Backend B **durchgesetzt**. Frontend-Test läuft tatsächlich zusätzlich in `.github/workflows/assessment-completion.yml:99` (`test:level-completion`), Browser bei :108. Der Workflow gilt für seine PR-/main-Pfadfilter (:10–42) und manuellen Start, nicht für jede reine Konzeptänderung; F:440 ist ein anderer Befehl. Die frühere auf ci.yml beschränkte Suche war als CI-Gesamtbewertung unvollständig. |
| G6 | Planmenge, Due-Dates und Periode müssen dieselbe Basis bilden. | LP:2564 weist Mengen-/Datumsfehler ab. `service/LearningPlanDailyProgressTest.java:102` `inconsistentPlanGoalAndScheduleBasisIsRejected`. | B; **durchgesetzt**, unabhängig von neuer Nachweisquelle. |
| G7 | Nur statische Compilation cachen, keine Lernendenergebnisse oder scopefremde Reuse. | CA:203 baut jede aktuelle Mastery-Menge neu; Cachekeys :260 enthalten Revision/Generation/Basis/Semantik. `completion/CompletionApplicationServiceTest.java:16` liest false→true→false und falsche Scope; :30 getrennte kanonische Basen. | B; **statische Cachegrenze getestet**. Die gespeicherte Revision ist noch kein historischer Q-ID-Garant. |
| G8 | Wiederholtes Lesen ändert keine Outcomes und zählt keinen Credit doppelt. | `completion/AutomaticLearningPlanCompletionProjectionTest.java:69` `repeatedReadsNeverCacheLearnerResultsOrDoubleCountExplicitMastery` liest mehrere Mastery-Snapshots. | B; **Caching/Dedup-Aspekt vorhanden**; :73 erwartet bei nur Q1 erneut keine Waiver und ist damit zugleich **Altsemantik-Widerspruch zu Q6**. |

## Was aus einem grünen CI-Lauf folgt und was fehlt

Die Tabellen enthalten 41 getrennte Prädikate mit konkreten Einschränkungen.
Nicht jede als durchgesetzt markierte Einzelbedingung macht ihren gesamten
Ablauf normkonform: Besonders Q1/Capabilityschutz und K1/SRS-Validierung koexistieren
mit dem falschen Automatic-Waiverpfad. Auch die korrekte explizite Ereignisrechnung
kann einen aus falscher Quelle erhöhten Gesamt-IST nicht legitimieren.

S1 braucht neue Gegenbeispiele an den tatsächlichen Service-/Adapter- und
Projektionseinstiegen für C(q), nicht nur Ersatzformeln im isolierten
Referenzchecker. Die ausdrücklich widersprechenden bestehenden Tests müssen
inhaltlich ersetzt werden. Historische ID-Stabilität, vollständige eigene
Prüfungspflichten und die globale Nachweisunion haben derzeit keinen harten
Produkt-CI-Vertrag. Ein manueller Markdown-/PNG-/PDF-Abgleich erfüllt diese
Lücke nicht. Das ist ein erwarteter offener Implementierungsstand, keine hier
vorgenommene Umstellung oder Freigabe.
