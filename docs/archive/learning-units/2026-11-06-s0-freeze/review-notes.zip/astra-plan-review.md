# Review des neuen Umsetzungsplans

Geprüft am 6. November 2026:
`docs/dev/mathematics-physics-learning-units-plan.md`, erster vollständiger
Entwurf vor den angekündigten Nachbesserungen.

Das Konzept ist als abgegrenzte Grundlage tragfähig. Ein vollständiger
Nachweis pro Q, mehrteilige Q für Experiment+Auswertung, eine qualifizierte
Abdeckungsliste und unveränderliche historische Prüfungsbedeutung bilden
eine einfache zusammenpassende Ausgangsentscheidung. Keine zusätzlichen
Lernendenbelege oder Freistellungsprofile sind nötig. S0 verankert ausdrücklich
eine neue Sollregel; der Plan behauptet keine bereits angepasste Runtime.

## Noch einzuarbeiten

1. **Abschluss muss Anwendung des ganzen eigenen Versprechens garantieren.**
   Für jede freigegebene Erwerbseinheit und aufgelöste Prüfungsvariante gilt
   `Own(U)∩O ⊆ union C(q), q∈RequiredOwnQ(U)`. Sonst kann direktes Verständnis
   M(a) plus eine andere Q die Einheit schließen, ohne Anwendung von a.
   Fremde Nachweise dürfen global anerkennen, eigene Q/K bleiben erforderlich.
2. **Formalität:** A ist Grundmenge; nur O/Q/K sind disjunkte Teilmengen, nicht
   A und alle drei Mengen paarweise.
3. **Historientest präzisieren:** Neue Aufgaben unter derselben Q-ID sind
   nicht pauschal verboten. Nachweislich bedeutungsgleiche Varianten dürfen
   bleiben; stärkere oder unbekannte Bedeutung darf alte M(q) nicht aufwerten.
4. **Konservative Aktivierung:** Ungeprüfte Q haben C(q)=∅; bestehendes
   `reviewStatus=released` ist nicht automatisch diese neue Qualifikation.
   S1 muss die bisherige Restbedarfsanzeige und Auswirkungen anderer Fächer
   vor Aktivierung ausdrücklich prüfen.
5. **Target-Rollen:** `prerequisiteOnly` ist kein Erwerbsowner/Progressziel;
   sein echter globaler Nachweis darf später als Target zählen. Die Angebots-
   Matrix muss beide Rollen und jede Variantenpflicht korrekt auflösen.
6. **Bewertung sichtbar abnehmen:** Negativfall ohne Kernverständnis bei
   maximalen übrigen Punkten fällt regulär durch; Positivfall mit gutem
   Verständnis und beiläufigem Rechenfehler kann regulär bestehen. Detaillierte
   Rubriken/Lösungen bleiben bis zur Evaluation geschützt. Eventuelle neue
   Kernminima sind gemeinsame normale Grading-Semantik, kein Coach-only-Test.

Punkte 1 und 4 sind die wesentlichen konzeptionellen Vollständigkeits- bzw.
Migrationsrisiken. Nach Einbau dieser Präzisierungen keine weiteren
konzeptionellen Blocker gegen Goal-Erstellung und Umsetzung ab S0.

## Abschließender Konsistenzpass

Die aktualisierte Planfassung wurde anschließend erneut geprüft. Die sechs
Findings sind eingearbeitet. Zusätzlich hält sie nach atomarer Normalisierung
`C(q) ⊆ Reach_R⁺({q})` als gerichtete Graphkonsistenz fest: Ein fehlender Pfad
ist ein fachlicher Befund; weder automatische Kanten noch zusätzliche direkte
Kanten oder eine umgekehrte Ableitung von Nachweisen werden eingeführt.

**Ergebnis:** Keine verbleibenden konzeptionellen Blocker gegen Goal-Erstellung
und S0. Die neue Nachweisregel, obligatorische eigene Anwendung, frühe globale
Anerkennung, historische Identität und konservative Migration sind konsistent.
Diese Planfreigabe ersetzt weder den S0-Abgleich aller normativen Dokumente
noch Daten-, Aufgaben-, Runtime- oder Hostabnahmen. S0 bleibt zunächst Inventur
und konsistenter Dokumentationsabgleich ohne Produktmigration.

Keine Produktdateien, Curricula oder Gitstände geändert.
