# S0: Konzeptreview nach Übertragung

Stand: 6. November 2026. Read-only-Review des Arbeitsstands nach Übertragung
der neuen Anerkennungsregel. Geprüft wurden die maßgeblichen Markdowntexte,
Graph Definition, TeX-Kapitel zu Kern, Anerkennung, Lerneinheiten und Anhang,
die Modell-/Bildgeneratorskripte sowie die tatsächlichen PNGs 08/09/10/15/16.
Kein eigener PDF-Build, keine Behauptung von Runtime-, Quellen- oder Hostabnahme.

## Ergebnis

Keine weiteren grundlegenden Konzeptwidersprüche gefunden. Die globale
Vereinigung qualifizierter C(q), ausdrückliches Q/K, erforderliche eigene
Abdeckung je Variante, Eltern-/Fremdnachweis, historische Q-Identität,
gerichtete Voraussetzungskonsistenz und konservative Behandlung ungeprüfter
Prüfungen stimmen zusammen. Die Texte markieren die neue Regel als Sollvertrag
mit ausstehender Implementierung. Die geänderten Bilder zeigen den frühen
Nachweis bei offener Folgeprüfung und gewöhnliche Elternanerkennung ohne
Bestehen der Kindprüfungen korrekt.

Zwei eng begrenzte Abgleichpunkte wurden an Root gemeldet und zur Korrektur
übernommen:

1. `latex/graph-learning-units.tex`: Ableitungen im P13-Beispiel nur dann als
   Vorwissen verlangen, wenn die gewählte Methode sie tatsächlich benutzt;
   das Markdown formuliert dies bereits konditional.
2. `latex/generate-completion-diagrams.py`, Bild 10: Der geprüfte Fixture
   enthält `k → a`, die Abbildung zeichnet diese Kante bislang nicht. Pfeil
   ergänzen oder Fixture/Bild identisch halten. Die Ergänzung zeigt besonders
   gut, dass eine offene abhängige Karte gültige Anerkennung nicht zurückhält.

## Ergänzung zur maschinellen transitiven Minimalität

Root hat unabhängig festgestellt: Der aktuelle Produktionsvalidator besitzt
noch kein entsprechendes hartes GVR-Gate; das mathematische Referenzskript
prüft kleine Modellgraphen und beweist keine Minimalität der Curricula.
Diese Lücke darf weder durch den Dokumentbuild noch alte M7-Evidenz verdeckt
werden. `graph-validation-rules.md` und der Umsetzungsplan müssen den neuen
Pflichtcheck einschließlich seiner tatsächlichen Aktivierungsgrenze benennen.

Empfohlener begrenzter Rollout: reproduzierbarer Vollbestandsbericht früh;
hartes Release-Gate für jede neu freizugebende Mathematik-/Physikeinheit über
ihren vollständigen fachlichen Wirkbereich mit geerbten, versteckten,
transitiven und fachübergreifenden Voraussetzungen. Ein Altfehler in diesem
Wirkbereich blockiert die neue Freigabe. Beim Fachabschluss muss der ganze
Fachumfang einschließlich Support bestehen. Befunde außerhalb dieses neuen
Freigabebereichs bleiben sichtbar unerfüllt und führen nicht zu ungeplanten
Reparaturen anderer Fächer. Keine Allowlist, akzeptierte Warnung oder Baseline
darf einen fehlgeschlagenen Minimalitätsnachweis in einen Pass umwandeln.
Vorhandene QA-Evidenz bleibt datierter Nachweis des damaligen Regelstands.

Nach den zwei kleinen Abgleichen und Aufnahme des offen benannten GVR-Gates
keine konzeptionellen Einwände gegen Fortsetzung von S0. Das ist keine
Vorwegnahme der dort noch ausstehenden Inventar-/Build-/Validierungsabnahme.

Nur diese temporäre Reviewnotiz wurde geschrieben; keine Produktdatei und
kein Gitstand geändert.
