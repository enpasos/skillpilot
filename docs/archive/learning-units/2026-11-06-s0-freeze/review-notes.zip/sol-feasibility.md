# Technische Vorbereitung: Mathematik und Physik nach Vorschlag 2

Stand: 6. November 2026. Ausschließlich lesende Bestandsaufnahme mit diesen beiden
neuen Ausgaben unter `tmp/aa_input/implementation-preparation-20261106/`.
Keine Änderung an Produktcode, Curriculum, Dokumentation, Branches oder Commits.
Zählungen bezeichnen Bestände, keine Qualität, Freigabe oder Abnahme.

## Ergebnis und unmittelbar nötige Entscheidungen

Die Umsetzung ist technisch gut anschlussfähig, aber keine reine Umbenennung
des alten Katalogs. Drei getrennte Modelle sind auseinanderzuhalten:

1. Der laufende Neustartstand implementiert noch die frühere, kontextabhängige
   Erledigung ohne verbleibenden Bedarf. Diese ist ausdrücklich keine globale
   Beherrschung und kann ohne bestandene Prüfung entstehen.
2. Der archivierte Ausbau leitet globale Anerkennung aus lokalen
   Einheitsverträgen ab, trägt dabei aber den transitiven Bedarf aller offenen
   lokalen Prüfungs-/Kartenpflichten weiter.
3. Vorschlag 2 §8 schlägt einen gültigen, versionsgebundenen Nachweis **je
   Prüfung** vor. Eine frühe bestandene Prüfung soll ihren geprüften Umfang
   sofort global anerkennen, obwohl spätere Prüfungen offen sind.

Diese dritte Variante ist nicht durch das unveränderte Übernehmen des alten
`LearningUnitEvaluator` umgesetzt. Der fachliche Konzeptentscheid muss die
Anwendung von Nachweisverträgen, verbleibendem Erwerbsbedarf, Einheitspflichten
und global wirksamer Beherrschung festlegen. Die alten technischen Bindungen
und Prüfungen bleiben wertvolle einzelne Bausteine.

## Basis und geschützte Dateien

- Aktueller Branch: `docs/learning-units-restart-20261106`.
- HEAD: `93a4b273cd8a068b8fe878eaca2a22158e92061a`.
- Produkt-/Curriculumbasis: `0ce5a8d791eeb9783a919195fd8590bfb79f3595`.
- Für `app`, `backend`, `curricula` und `scripts` zeigt der Vergleich von Basis
  zu HEAD keine Änderungen.
- Bereits vor dieser Arbeit geändert und nicht angefasst:
  `docs/concept/skill-graph/learning-unit-design-and-examples.md` und
  `docs/dev/learning-units-restart-2026-11-06.md`.
- Archiv nur über `git show`/`git ls-tree` gelesen:
  `e66fb62c45fd15cde295b09cd9f4a12f13ef4cc9`. Kein Checkout oder Worktree.
  Das Archiv nennt PR #82 als bisherige Linie und PR #79 als ältere
  Bausteinquelle. Weder alte Testergebnisse noch der verworfene Zuschnitt
  wurden als aktuelle Abnahme verwendet.

## Eingaben: genaue Identität und Grenzen

`input-inventory.json` enthält Hashes, Detailzählungen, konkrete Pilot-IDs und
sämtliche aufgelösten Deckreferenzen.

**Vorschlag 2:** SHA-256
`60b24c99a0f3129ead0101d98bca16c7d479ac59f88238640541b0cdd4c77104`.
Er benennt M01–M61 und P01–P51. Die bereits vorhandene Auditnotiz erklärt ihre
begrenzte Prüfung nachvollziehbar; insbesondere wurde dort keine vollständige
V2-Eigentümerzuordnung geprüft.

**Aktuell gelesene CSV:** 1.422.900 Bytes; SHA-256
`db9b1b969d1926c6a80ff21d4d10fb61cd4ec8822b9837301c855d200585f7e2`.
Die vorhandene Sicherung `source-versions/2026-11-06-input-snapshot-01` enthält
eine andere CSV: 1.410.532 Bytes; SHA-256
`d86f4b5a5830db3ba8ff42a9a6e58de58ff4a78ce2c6c64646c6d7eb1485c1d5`.
179 CSV-Datensätze unterscheiden sich semantisch bei gleicher Gesamtzahl.
Eine spätere Umsetzung muss ihre gewählte Eingaberevision ausdrücklich binden.
Diese Vorbereitung hat keine der beiden Eingaben überschrieben.

Die aktuellen kanonischen JSON-Dateien sind bytegleich zur Main-Basis:

| Datei unter `curricula/DE/Gymnasium/canonical/` | IDs | SHA-256 |
| --- | ---: | --- |
| `DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json` | 1.252 | `e0ff0cafccf0f638c4cb36d5a252480ccc7062750619ef0452a447775bf96fe1` |
| `DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json` | 766 | `e1719316bdacf2a874b23ee06ed77192ce71831781309991ddc26ba0e49faf1d` |

Alle 2.018 IDs sind über beide Dateien eindeutig. Mit der offengelegten
Inventarregel des bisherigen Audits ergeben sich 1.285 gewöhnliche Atome,
319 Prüfungsatome, elf Kartenatome und 403 Struktur-/Orientierungsknoten.

Die privaten Library-Links auf PDF, XLSX und V2-ZIP wurden nicht als Inhalte
gelesen. Unter `tmp/aa_input` liegt keine dieser drei Dateien vor. Ihre
vermeintlichen Detaildaten sind deshalb keine Umsetzungsgrundlage. Die
aktuelle CSV kann diese Lücke nicht als V2-Zuordnung schließen.

## CSV unabhängig am aktuellen kanonischen Bestand geprüft

| `variant_id` | Zeilen / eindeutige IDs | assigned | structure | outside_scope | external_support | Einheiten |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `DE_GYM_CANONICAL_V1` | 2.018 / 2.018 | 1.619 | 399 | 0 | 0 | 85 |
| `DE_GYM_GK_V1` | 2.018 / 2.018 | 1.361 | 362 | 156 | 139 | 83 |
| `DE_BY_G9_V1` | 2.018 / 2.018 | 1.616 | 398 | 4 | 0 | 85 |
| `DE_HE_GYM_G9_V1` | 2.018 / 2.018 | 1.604 | 393 | 11 | 10 | 85 |

Pro Variante: keine unbekannte, fehlende oder doppelte Original-ID; jede
`assigned`-Zeile hat eine Einheit und keine andere Disposition hat eine Einheit.
Zusammen sind es 8.072 Zeilen, 2.018 Original-IDs und 85 unterschiedliche
`U_MATH_*`-/`U_PHYS_*`-Kennungen. Keine Zeile verweist auf M01–M61 oder P01–P51.

Die kanonische CSV-Variante ordnet alle 1.285 gewöhnlichen Ziele, alle 319 Q,
alle elf K und vier Orientierungsziele zu. Sie hat keine offene Zuordnung.
Vorschlag 2 nennt dagegen 1.603 zugeordnete Ziele, 403 Struktur-/Orientierungs-
knoten und zwölf offene Fälle. Das ist ein inhaltlich anderes Zuordnungsmodell;
die Übereinstimmung des ID-Universums macht die CSV nicht zu V2.

Die vier genannten Varianten sind externe Bezeichner, keine hier nachgewiesenen
nativen Angebotsdefinitionen. Die Tabellenprüfung beweist weder deren Scope
noch fachlich richtige Eigentümer. Dafür müssen die echten Composition Views,
Angebote und Applicabilityregeln herangezogen werden. Ebenso fehlt hier eine
prüfbare M/P-Eigentümerliste für den behaupteten V2-Einheiten-DAG.

## Decks: Inhalte sind im Repository vorhanden

Alle elf kanonischen K-Ziele wurden über `extendedData.vocabularySource` und
`vocabularySourceEn` aufgelöst: **18 von 18 referenzierten Dateien existieren**
unter `curricula/DE/Gymnasium/memory-decks/`. Ein unbekannter DE-/EN-Deckpfad
trat nicht auf.

| Deckfamilie | Deutsche Karten | EN vorhanden | explizite `goal:`-Tags |
| --- | ---: | --- | --- |
| Mathematik Sek I | 14 | ja | keine |
| Mathematik Funktionen | 8 | ja | keine |
| Mathematik Analysis | 14 | ja | keine |
| Mathematik Lineare Algebra | 8 | ja | keine |
| Mathematik Stochastik | 12 | ja | keine |
| Mathematik Komplexe Zahlen/Parameter | 8 | ja | keine |
| Physik E-Phase | 87 | ja | je Karte |
| Physik Q1 / Q2 / Q3 / Q4 | 14 / 16 / 15 / 14 | nein | je Karte |

Das beseitigt die externe Materiallücke für eine folgende inhaltliche Sichtung.
Es entscheidet noch keine Eigentümerschaft. Besonders das Mathematik-Sek-I-Deck
enthält beispielsweise Steigungsformel, Parabeln und Logarithmen und ist keine
belegte Kartenpflicht von M01. Karteninhalt, Umfang, Teilung, stabile Karten-IDs
und gespeicherter Recall müssen vor einer Veränderung zusammen geprüft werden.

## Bestehende technische Anschlussstellen

| Zweck | Konkrete aktuelle Pfade | Konsequenz |
| --- | --- | --- |
| Ziele, Aufgaben, Lösungen, normale Bewertung | `curricula/DE/Gymnasium/canonical/*.de.json`; `backend/src/main/java/com/skillpilot/backend/landscape/ExamData.java`; `app/src/landscapeTypes.ts` | `coveredGoalIds`, Aufgaben-/Lösungstext und `scoring.maxPoints/passingPoints/steps` existieren. Einträge alleine sind kein validierter Nachweis. |
| Lernansichten und Scope | `curricula/DE/Gymnasium/composition-views/{mathematik,physik}/`; `app/src/utils/compositionViewRuntime.ts`; `app/src/utils/authoring/compositionViewAuthoring.ts` | `target` und `prerequisiteOnly` sowie spezifischere Referenzen verwenden; vier CSV-Namen nicht als Ersatzscope erfinden. |
| Reale Aufgabenquellen | `curricula/DE/Gymnasium/assessments/{mathematik,physik}/` | Einzelne Aufgaben-/Rubrikbausteine an voller Zielbedeutung und normalem Bestehen prüfen. |
| Bestehende Completion | `backend/src/main/java/com/skillpilot/backend/completion/{CompletionProfileCompiler,CompletionEvaluator,AutomaticCompletionApplicationService}.java` | Der automatische Evaluator startet bei offenen Prüfungen, stoppt Bedarf an explizit beherrschten Zwischenzielen und erzeugt `no_remaining_demand`; keine neue globale Nachweislogik. |
| Aktueller Plan und Frontier | `backend/src/main/java/com/skillpilot/backend/service/{LearnerService,LearnerLearningPlanService}.java` | Effektive Beherrschung muss an allen lesenden Stellen konsistent wirken; reine UI-Annotation genügt nicht. |
| Persistierte Ergebnisse | `backend/src/main/java/com/skillpilot/backend/domain/{Mastery,MasteryId}.java` | Persistiert sind Lernender, goalKey, value und Zeitpunkt; das Modell bindet keine unveränderliche Aufgaben-/Rubrikrevision. Historische Q-Bedeutung daher nicht unter derselben ID verstärken. |
| Prüfung und reguläre Bestehensgrenze | `backend/src/main/java/com/skillpilot/backend/{ai/CoachToolFacade,ai/visiblesession/VisibleSessionService,connectors/claude/v1/mcp/ClaudeV1McpContractAdapter,openai/mcp/de/v1/OpenAiDeV1McpContractAdapter}.java` | Die Adapter speichern nach `passingPoints`. Kein verstecktes zweites Bestehen ergänzen. |
| Planabdeckung | `app/src/utils/{coursePlanTopicSelection,coursePlanExamPreparation}.ts` | Explizite Coverage ist getrennt von `requires`; versteckte kanonische Coveragecluster werden nur auf sichtbare zulässige Ziele aufgelöst. |
| Sichtbare Completion/Navigation | `app/src/utils/{levelCompletionApi,treeCompletionProgress}.ts`; `app/src/components/learningUnitMap/` | Aktuelle implizite Anzeigen bedeuten kontextabhängige Erledigung. Darstellung und Coachtext müssen mit dem neuen Ergebnisvertrag zusammen migrieren. |

Die aktuellen Claude- und OpenAI-Anweisungen sagen ausdrücklich, dass implizite
Erledigung keine Beherrschung bescheinigt; Beispiele stehen in
`ClaudeV1CompletionChoices.java`, `ClaudeV1McpContractAdapter.java` und
`OpenAiDeV1McpContractAdapter.java`. Der Wechsel muss daher Backendprojektion,
Adaptervertrag und Lernendenanzeige gemeinsam abdecken.

## Archiv gezielt nachnutzen

Alle folgenden Pfade beziehen sich **nur** auf Archivcommit `e66fb62c45…`:

- `backend/src/main/java/com/skillpilot/backend/completion/learningunit/`:
  `LearningUnitDefinition`, `LearningUnitCompiler`, `LearningUnitPrerequisiteGraph`
  bieten Own/Children/Q/K, eindeutige Erwerbseigentümer, explizite Quellenbindung
  und Prüfungen auf atomare und projizierte Abhängigkeiten. Fachliche Grenzen
  und die §8-Nachweisregel bleiben separat zu prüfen.
- `LearningUnitCatalog`, `LearningUnitSourceBindings`,
  `LearningUnitAssessmentVariants`, `LearningUnitRecallBindings`:
  unveränderliche Quellen, Bedeutungsdigests, Aufgaben-/Rubrikbindung, endliche
  Übersetzungsvarianten und echte Deck-/Recallbindung. Diese Fähigkeiten können
  neue Verträge absichern, ohne den alten Zuschnitt zu übernehmen.
- `LearningUnitResultAliasTest`: unterscheidet eingefrorene gleichbedeutende
  Ergebnisse von aktuellen allgemeinen Mappings. Geänderte historische Aufgabe,
  geänderter Nachweisumfang und Verständnis→Prüfung werden abgewiesen. Das ist
  für neue M01-/P13-Prüfungen direkt relevant.
- `LearningUnitEvaluator` und `LearningUnitRecognitionCache`: reine Berechnung
  und inkrementeller Cache sind technische Vorbilder; der alte lokale offene
  Q/K-Bedarf ist keine bestätigte Umsetzung des V2-Zwischenprüfungswunsches.
- `app/src/utils/learningUnitsApi*`, `learnerUnitMapProjection.ts`,
  `LearningUnitsCoachProjection.java` und die entsprechenden Integrationstests
  sind anschlussfähige Transport-/Darstellungsbausteine nach neuem Vertrag.
- `scripts/test_learning_unit_{package,semantic_inputs,offer_package,package_conformance_plan}.py`
  und Roundtrip-/Export-Erweiterungen erst bei tatsächlicher Paketaufnahme
  selektiv übernehmen; keine vollständige alte Curriculumkopie importieren.

Alte `curricula/DE/Gymnasium/learning-units/catalog.json`, Angebote und
Generatorausgaben bleiben historische Kandidaten. Ihre alten Besitzverhältnisse
oder Quellenprüfungen bestätigen keinen neu gewählten Lernversprechensschnitt.

## Zwei erste vollständige kleine Schritte

Die folgenden Schritte sind eine technische Reihenfolge für nach dem
Konzeptentscheid. Sie beschränken den Gesamtauftrag Mathematik und Physik nicht.
Der inzwischen angelegte Plan
`docs/dev/mathematics-physics-learning-units-plan.md` wurde technisch gelesen.
Sein vorgeschaltetes **S0** ist erforderlich: zuerst die Nachweisregel in den
maßgeblichen Konzepten konsistent verankern und native Angebote vollständig
inventarisieren, dann **S1 M01**, anschließend **S2 M02/P13/P14**. Die vier
externen CSV-Varianten erfüllen das Angebotsinventar von S0 ausdrücklich nicht.

Der Plan ist technisch tragfähig. Zwei konkrete S0-/Compiler-Abnahmepunkte:

- Native Varianten reproduzierbar aus tatsächlichen Angebotsdefinitionen und
  `composition-views` auflösen; äquivalente Auflösungen nur mit belegter
  Gleichheit bündeln. Diese Vorbereitung hat keine vollständige Enumeration
  dieser Angebote durchgeführt.
- Vorhandene `coveredGoalIds` können Clusterwurzeln enthalten. Für einen
  freigegebenen Nachweis muss die daraus bestimmte atomare Bedeutung genau
  einer eingefrorenen Revision folgen. Spätere `contains`-Änderungen dürfen
  historische Ergebnisse nicht nachträglich verbreitern. Eine gepflegte
  Abdeckungsliste und daraus abgeleitete, gebundene Compilerartefakte sind
  miteinander vereinbar.

**M01 vollständig vom Lernversprechen bis zur Anzeige:** Die fünf konkreten
gewöhnlichen IDs sind im JSON unter `pilots.M01` mit voller Beschreibung
aufgelistet. Sie umfassen Zahlendarstellung, Stellenwertvergleich, Ordnung,
Runden und Nachfolgerprinzip. Eigentümerzuordnung und eine native Scopebindung
zuerst ausdrücklich festlegen. Die vorhandene J5-Prüfung
`311ab2f2-3364-5166-ac22-3ef01419fee4` hat max. 6 / Bestehen 3 BE; der Rechenteil
allein reicht. Sie darf nicht allein durch neue Coverage eine Vollzertifizierung
aller fünf Ziele erhalten. Eine geeignete neue Prüfung mit neuem Q und fairer
normaler Rubrik entwerfen, unabhängig gegen typische wesentliche Fehlvorstellungen
prüfen, Aufgaben/Rubrik/Nachweisumfang unveränderlich binden und historische
Ergebnisse unangetastet lassen. Pass, Fail, erneuter unabhängiger Versuch,
direkt vorhandene Beherrschung sowie eine später noch offene Aufbauprüfung
werden in derselben Ende-zu-Ende-Strecke geprüft. Keine pauschale M01-Kartenpflicht
aus dem breiten Sek-I-Deck ableiten.

**P13 vollständig mit echter Modell- und Experimentgrenze:** Vier sichere
Kernkandidaten stehen unter `pilots.P13`: gleichförmige Bewegung,
gleichmäßige Beschleunigung, experimenteller freier Fall, Straßenverkehr.
Das ist ausdrücklich noch keine vollständige V2-P13-Eigentümerliste. Den
kanonischen Kinematikbestand und die fehlende M/P-Zuordnung vollständig prüfen,
senkrechten Wurf fachlich ergänzen/zuordnen und P14/P17 klar abgrenzen.
Vorzeichen, Einheiten, Graphen und konkret benötigte Mathematik separat benennen;
keine ganze Integralrechnungseinheit als technischen Vorlauf erzwingen.
Die vorhandene Wurfprüfung `4ab1cf6d-b808-5b86-9291-85df0b9f2496` hat max. 36 /
Bestehen 22 BE; ohne ganze Scheitelpunktaufgabe und alle Diagramme bleiben 24.
Eine stärkere nachträgliche Bedeutung derselben Q-ID wäre daher unbelegt.
Experimentelles Handeln im Freifallziel nicht durch bloße schriftliche
Datenauswertung ersetzen. Normales Bestehen, modellbezogene Begründung,
Diagramme und angemessene experimentelle Evidenz müssen gemeinsam zum
beanspruchten vollen Ziel passen. Recallkarten aus dem E-Phasen-Deck einzeln
nach tatsächlichem Inhalt prüfen.

Für jeden Schritt: Paket/Vertrag deaktiviert vorbereiten, fokussierte Prüfungen,
native Angebotsprüfung, sichtbarer lokaler Smoke-Test mit gespeichertem Fortschritt
und Sessionfortsetzung. Eine lokale Browserprüfung beweist keine Claude-/ChatGPT-
Hostabnahme. Deployment, Veröffentlichung oder Git-Schreibzugriffe sind keine
Bestandteile dieser Vorbereitung.

## Passende Tests für die folgende Umsetzung

Keine Testsuite wurde als Teil dieser unveränderten Bestandsaufnahme ausgeführt.
Die vorhandenen Dateien wurden nachgewiesen; folgende Auswahl dient der Planung:

- Kernberechnung: `AutomaticCompletionTest`, `AutomaticCompletionApplicationServiceTest`
  als Altverhaltensregression; nach selektiver Aufnahme `LearningUnitCoreTest`,
  `LearningUnitPrerequisiteGraphTest`, `LearningUnitRecursiveCatalogTest`.
- Verbindliche neue Gegenbeispiele: frühe gültige Zwischenprüfung trotz später
  offenem Q; niemals implizites Q/K; kein Nachweis nur durch `requires` oder
  `coveredGoalIds`; eigener direkter Eigentümer; transitive Bedarfsminimalität;
  Ziel-/Aufgaben-/Rubrikänderung verleiht alten Ergebnissen keine stärkere Bedeutung.
- Quellen/Ergebnisgeschichte aus Archiv: `LearningUnitCatalogTest`,
  `LearningUnitSourceBindingsTest`, `LearningUnitAssessmentVariantsTest`,
  `LearningUnitAssessmentVariantAliasesTest`, `LearningUnitResultAliasTest`,
  `LearningUnitRecallBindingsTest`. Die Tests müssen den neuen Vertrag prüfen.
- Backendfluss: vorhandene `AssessmentCompletionIntegrationTest`,
  `AssessmentCompletionRestartIntegrationTest`, `AssessmentCompletionSrsIntegrationTest`,
  `AutomaticCompletionFrontierTest`, `LearningPlanAssessmentCreditTest`;
  archivierte `LearningUnitRecognitionIntegrationTest`, `LearningUnitEntryScopeTest`
  nur selektiv und konzeptangepasst.
- Adapterbewertung: vorhandene `ClaudeV1ExamContractTest`,
  `ClaudeV1CanonicalExamIntegrationTest`, `ClaudeV1MasteryBackendIntegrationTest`
  und die entsprechenden OpenAI-Vertragstests nach betroffenem Pfad.
- Sichtbare Projektion: `npm run test:level-completion`,
  `npm run test:composition-projection-roles`,
  `npx tsx src/utils/coursePlanTopicSelection.test.ts`,
  `npx tsx src/utils/coursePlanExamPreparation.test.ts` im `app`-Verzeichnis;
  anschließend geeigneter vorhandener Browser-/Backend-Smoke.
- Bei geänderten Daten: `npm run validate:graph`,
  `npm run validate:composition-views` und
  `npm run check:assessment-completion-profiles` sowie unveränderte fachliche
  M7-/Quellen-/Bildprüfungen des jeweils wirklich betroffenen Umfangs.

Die auditierte Bestandsabdeckung bleibt 282 Mathematik- plus 72 Physikziele ohne
direkten Eintrag in der Vereinigungsmenge aller `examData.coveredGoalIds`.
Diese 354 sind fehlende explizite Deklarationen, keine gezählten fachlichen
Fehler und kein Fertigstellungsmaß.
