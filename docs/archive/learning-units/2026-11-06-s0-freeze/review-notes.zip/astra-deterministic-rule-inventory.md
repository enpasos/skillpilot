# Deterministisches Regelverzeichnis — konzeptioneller Quellenbefund

Stand: 6. November 2026. Astra, READONLY-Audit; ausschließlich diese temporäre
Notiz wird geschrieben. **Dies ist das normative Inventar, noch kein Nachweis
einer CI-Durchsetzung.** Eine Erwähnung in einem Validator-Katalog, ein vorhandener
Test oder ein bestandenes Formalbeispiel belegt für sich kein verpflichtendes
Produktions-CI-Gate. Root/Sol ordnen die tatsächlichen Aufrufketten und Gates zu.

## Korpus und Leseregel

Vollständiger unmittelbarer Markdown-Korpus: alle 21 Dateien direkt unter
`docs/concept/skill-graph/`. Ergänzt wurden die formalen Graph-TeX-Kapitel,
relevante Graph/Mastery/QA/Plan-Regeln aus `AGENTS.md` und die unten bezeichneten
normativen Querverweise. Lokale Quellenstellen unten verwenden Dateikürzel plus
Abschnitt oder Zeile. Gleichlautende MD/TeX-/AGENTS-Wiederholungen ergeben keine
zusätzliche Regel. Unabhängig verletzbare Prädikate erhalten getrennte IDs.

| Kürzel | Lokale Quelle |
|---|---|
| G | `docs/concept/skill-graph/graph-definition.md` |
| A | `docs/concept/skill-graph/assessment-gated-completion.md` |
| U | `docs/concept/skill-graph/learning-units.md` |
| UP | `docs/concept/skill-graph/learning-unit-progression.md` |
| UD | `docs/concept/skill-graph/learning-unit-design-and-examples.md` |
| N | `docs/concept/skill-graph/node-types.md` |
| V | `docs/concept/skill-graph/view-projection-and-goal-placement.md` |
| GS | `docs/concept/skill-graph/general-goal-system-and-migration.md` |
| CR | `docs/concept/skill-graph/canonical-gymnasium-rollout.md` |
| SR | `docs/concept/skill-graph/source-and-resource-links.md` |
| CI | `docs/concept/skill-graph/content-integration.md` |
| IM | `docs/concept/skill-graph/atomic-goal-visualizations.md` |
| BK | `docs/concept/skill-graph/learning-goal-book-and-evidence-review-pipeline.md` |
| PK | `docs/concept/skill-graph/dual-curriculum-package-releases.md` |
| HR | `docs/concept/skill-graph/human-readable-source-rationales.md` |
| MEM | `docs/concept/skill-graph/mem-fwu-roundtrip-plan.md` |
| TP | `docs/concept/skill-graph/teacher-goal-book-time-planning.md` |
| AG | `AGENTS.md` |
| PS | `docs/concept/levels-of-personalization.md` |
| LS | `docs/concept/didactic/unified-learning-plan-status.md` |
| TA | `docs/concept/didactic/curriculum-time-axis-and-pacing.md` |
| HQ | `docs/concept/curriculum-quality-and-human-trial.md` |
| GV | `docs/qa-ci/graph-validation-rules.md` |
| QM | `docs/qa-ci/curriculum-quality-maturity-and-routes.md` |
| TEX | `docs/concept/skill-graph/latex/graph-{core,assessment,learning-units,context,planning,appendix}.tex` und Hauptkompendium; tatsächliche Pfade unten im Dateimanifest |

Weitere unmittelbar betrachtete Dateien: `completion-semantics-clarification-2026-11-04.md`
ist datierte, vom 6. November abgelöste Historie; `curriculum-levels.md` und
`curriculum-level-gates.md` sind Kompatibilitätsverweise; `index.md` ist Navigation.
Sie erzeugen keine eigenständigen aktuellen Regeln. Historische lokale
Restbedarfsanerkennung wird nicht zusätzlich zum neuen globalen Beweisgesetz
gefordert. Insbesondere sind `CoverageEvent`, manuelle Attestierung und
`AssessmentResultEvent` aus TA §§4–18 laut TA:5–25 kein aktueller Auftrags- oder
Abnahmevertrag. Aktive, davon unabhängige Planungsvorgaben bleiben erfasst.

**Arten:** S = statischer Daten-/Graph-/Artefaktvertrag; R = Laufzeit-/Zustandsvertrag;
E = deterministisch prüfbarer Evidenz-/Qualitätsvertrag. E prüft beispielsweise
aktuelle vollständige Reviewbelege, nicht die Wahrheit eines fachlichen Urteils.
**Profile:** Basis = allgemein im betreffenden Modell; Ziel = ausdrücklich
beschlossener Sollvertrag, nicht automatisch bereits implementiert; Bedingt =
nur bei aktiviertem/genutztem Profil; Teilmenge benennt eine konkrete Landschaft,
Ausgabe oder Reifestufe. Empfehlungsprosa allein wird nicht zu einem harten Gate.

Nicht im Auftrag: universeller Audit sämtlicher OAuth-, Portal-, Deployment-,
Marktplatz-, Security- oder Betriebsvorgaben. Fachlich-didaktische Güte,
Lernwirksamkeit und echte unabhängige menschliche Urteile sind keine vollständig
deterministischen Prädikate. Ihre formal vorgeschriebenen Evidenzhüllen dagegen
werden erfasst. Weitere, nur verlinkte Repository-Dokumente sind kein stillschweigend
vollständig auditiertes Korpus; die Code-/CI-Zuordnung kann zusätzliche technische
Regeln entdecken und gesondert kenntlich machen.

## 1. Identität, Typen und Graphrelationen

| ID | Unabhängige harte Regel | Art / Profil | Stelle |
|---|---|---|---|
| G01 | Jeder Goal hat gültige kanonische ID; IDs sind im aufgelösten Graph eindeutig. | S / Basis | G §§2.1–2.3 |
| G02 | Attributwerte erfüllen ihre deklarierten Domänen, insbesondere positives Gewicht. | S / Basis | G §§2.1–2.2 |
| G03 | Optionaler ShortKey ist pro logischer Landschaft eindeutig; gleiche Goal-ID darf sprachübergreifend denselben Key tragen, verschiedene IDs nicht. | S / ShortKey | G §2.3.1; GV GVR010 |
| G04 | Atomar genau dann, wenn `contains` leer ist; explizite Atom-/Clustermetadaten müssen damit übereinstimmen. | S / Basis | G §2.4; GV GVR009 |
| G05 | Sämtliche `contains`-/`requires`-Endpunkte existieren im aufgelösten Graph, einschließlich fachübergreifender Referenzen. | S / Basis | G §3; §10 |
| G06 | `contains` ist azyklisch. Mehrere Eltern sind im allgemeinen Graph erlaubt. | S / Basis | G §4.2 |
| G07 | `requires` ist azyklisch. | S / Basis | G §5.3 |
| G08 | `requires` bedeutet Konjunktion aller Anforderungen; Pfeilrichtung Verbraucher → Voraussetzung. | R / Basis | G §5.1 |
| G09 | Inverse Lernflussdarstellung ist als solche bezeichnet und keine unabhängig gepflegte zweite Relation. | S / entsprechende Darstellung | G §5.1 |
| G10 | Effektive Voraussetzungen sind direkte plus Voraussetzungen sämtlicher `contains`-Vorfahren; doppelte Forderungen werden vereinigt. | R / Basis | G §6.1 |
| G11 | Vererbung ist nicht bereits transitive Hülle; beide Operationen dürfen nicht verwechselt werden. | R / Basis | G §§6.1–6.4 |
| G12 | Clusteranforderungen werden in atomaren Bedarf expandiert, bevor dessen transitive Hülle berechnet wird. | R / Basis | G §6.4 |
| G13 | Auch Voraussetzungen der durch Clusterexpansion erreichten Atome werden weiter verfolgt. | R / Basis | G §6.4 |
| G14 | Effektive/atomar normalisierte Voraussetzungshülle ist unabhängig vom aktuellen Mastery-Zustand. | R / Basis | G §6.4; A:107–131 |
| G15 | Effektive Voraussetzungen bleiben azyklisch; insbesondere keine geerbte Selbstanforderung. | S / Basis | G §7.1 |
| G16 | Lokale Minimalität: keine direkte Anforderung, die schon aus einem `contains`-Vorfahren geerbt wird. | S / Basis | G §7.2 |
| G17 | Transitive Minimalität: entferne die betrachtete Autorenkante, berechne vollständige effektive atomare Relation erneut; eine alternative Erreichbarkeit verbietet die redundante Kante. | S / Basis, explizit Ziel 6.11. | G §7.3; AG §2.4; GV neuer Minimalitätsabschnitt |
| G18 | Ein als Baum/Wald deklarierter Graph erlaubt höchstens einen `contains`-Elternknoten. Nicht auf die allgemeine Polyhierarchie übertragen. | S / Bedingt Baumprofil | G §8.3 |
| G19 | Keine eigene Voraussetzung entlang der Vorfahrenlinie. Nur dort hart, wo entsprechendes GVR-Profil es festlegt. | S / GV-Profil | G §8.2; GV GVR001/003 |
| G20 | Keine Voraussetzung eines eigenen Kindes/Nachfahren. Allgemeine G-Empfehlung wird erst im ausgewiesenen GV-Profil hart. | S / GV-Profil | G §8.1; GV GVR006 |
| G21 | Kanonischer direkter atomarer Sequenzgraph trägt den nachgewiesenen Einstieg-/Abschlussweg jedes curricularen Atoms. | S / ausgewiesene Reife-/Mathprofile | G §8.5; GV GVR011/012; QM CQR101/102 |
| G22 | Ein direkter didaktischer Weg nutzt ausschließlich zugelassene Knotenarten und den jeweils geprüften Stage-Scope. | S / Math-SekI/SekII | G §8.5; GV GVR012 |
| G23 | Jeder geprüfte kanonische Mathematik-Knoten hat eine vollständige, eindeutige semantische Stage-/Kind-Zuordnung. | S / Math-SekI/SekII | G §8.5; GV GVR012 |
| G24 | Auf einem Abschlussweg kommt mindestens ein normales curriculares Atom vor; Prüfungen dürfen den Erwerbsweg nicht ersetzen. | S / Math-SekI/SekII | G §8.5; GV GVR012 |
| G25 | Merk-/Abrufziele liegen auf diesem Weg nach normalem Erwerb; Orientierung bleibt reine Orientierung. | S / Math-SekI/SekII | G §8.5; GV GVR012 |
| G26 | Geprüfte direkte kanonische Anforderungen jedes sichtbaren Zielatoms sind in der Projektion als `target` oder `prerequisiteOnly` vorhanden. | S / aufgelöste Kompositionssicht | G §8.5; V Projektionsvertrag |
| G27 | Fehlende explizite Level-2-Referenzen sind Konfigurationsfehler, keine Optimismus-Ausnahme und kein erfolgreicher leerer Graph. | R / aufgelöste Kompositionssicht | G §8.5; AG §2.3 |
| G28 | Im ausgewiesenen atomaren Reifeprofil existieren keine lokalen Cluster-`requires` als Sequenzabkürzung. | S / QM CQR103 bzw. GV GVR013 | G §8.4; GV GVR013; QM |
| G29 | Clusterabhängigkeitsdarstellungen werden aus atomaren Routen abgeleitet und erzeugen keine zusätzlichen Autorenkanten. | S / abgeleitete Darstellung | G §8.6 |

## 2. Scope, Platzierung und Projektion

| ID | Unabhängige harte Regel | Art / Profil | Stelle |
|---|---|---|---|
| V01 | Kanonische Kompetenzidentität bleibt unabhängig von Jahr, Semester, Stage, Kurs oder Kalenderplan. | S / Basis | GS Ziel-/Programmlayer; AG §2.3 |
| V02 | Struktur-/Programmknoten werden nicht durch Titel-, ID-, Phasen- oder Zeichenfolgenheuristiken erfunden. | S / Basis | V:133–161 |
| V03 | Jede sichtbare Baumkante hat eine ausdrücklich zugelassene Autorenquelle (`contains`, Placement, Programmeltern, Achsenref oder Komposition). | S / Basis | V:149–161 |
| V04 | Eine Ansicht verwendet eine eindeutige primäre Strukturfamilie; geprüfte Komposition hat Vorrang vor Placement-Fallback. | R / Basis | V:163–185 |
| V05 | Jeder sichtbare Goal erscheint in einer aufgelösten Standardsicht höchstens einmal. | S / Basis | V:186–217; G §11.2 |
| V06 | Jeder sichtbare Goal hat dort höchstens einen sichtbaren primären Elternknoten. | S / Basis | V:186–217 |
| V07 | Sekundäre/assessed Placements sind Overlays, keine zusätzlichen Goal-Bauminstanzen. | S / Placements | V:186–217; :428–474 |
| V08 | Kompositionssichten enthalten Struktur und kanonische Referenzen, keine eingebetteten neu verfassten atomaren Goals. | S / Komposition | V:219–243 |
| V09 | Kompositionssichten verfassen keine eigene didaktische `requires`-Relation. | S / Komposition | V:219–243 |
| V10 | Jede referenzierte kanonische Teilbaumwurzel existiert; überlappende Referenzen erfordern ausdrücklich geprüfte Auflösung. | S / Komposition | V:219–243; GV CPV002/004 |
| V11 | Rollen sind nur `target`/`prerequisiteOnly`; fehlende Rolle bedeutet `target`. | S / Komposition | V:265 ff.; GV CPV008 |
| V12 | Rollenpräzedenz: direktes `goalEntry` vor Teilbaum; tiefster passender Teilbaum vor breiterem; nur bei gleicher Spezifität gewinnt `target`. | R / Komposition | V:265 ff.; AG §2.3 |
| V13 | Projektionrolle wird niemals automatisch aus `requires`, Jahr, Stage oder Phase abgeleitet. | S / Komposition | V:265 ff. |
| V14 | Nur `target` gehört in normalen Baum, Frontier, Fortschritt und Abschlussnenner. | R / Basis | V Rollenvertrag; AG §2.3 |
| V15 | `prerequisiteOnly` behält kanonische ID und globale Mastery und ist für entsprechende Voraussetzungsprüfung verfügbar. | R / Basis | V Rollenvertrag; AG §2.3 |
| V16 | Projektion verändert weder kanonische IDs noch Mastery noch fachliche Kanten. | R / Basis | V Kompilierungsvertrag |
| V17 | `curricularArea` darf kein direktes `goalEntry` vortäuschen. | S / Komposition | G §11.2; GV CPV009 |
| V18 | Kanonische Content-Sicht folgt ausschließlich `contains`; Wurzeln sind explizit bzw. elternlos, Mehrfachelternauflösung deterministisch. | R / Content-Sicht | V:392–427 |
| V19 | Geschwisterreihenfolge folgt autorisiertem Strukturvertrag; Filterung verbirgt und hängt Knoten nicht still um. | R / Content-Sicht | V:392–427 |
| V20 | Programmsicht folgt `parentUnitId`/expliziter Ordnung; synthetischer Strukturknoten steht genau für eine Programmeinheit. | S / Programmsicht | V:428–474 |
| V21 | Höchstens ein primäres Placement je sichtbarer Einordnung; Mehrdeutigkeit benötigt explizite geprüfte Auflösung, fehlendes primäres Placement keine erfundene Zuordnung. | S / Programmsicht | V:428–474 |
| V22 | Kompetenzachsen sind eigener Katalog/eigene Sicht und werden nicht als Content-Eltern umgedeutet. | S / Achsensicht | V:513–526 |
| V23 | Applicability filtert Mitgliedschaft, nicht Elternbeziehung oder kanonische Identität. | R / Basis | V:527 ff.; G §11.1 |
| V24 | Fehlende Applicability-Dimension bedeutet unbeschränkt, vorhandene leere Menge bedeutet keine Werte. | S/R / Basis | G §11.1 |
| V25 | Query-Sentinel `ALL` wird nicht als verfasster Applicability-Wert serialisiert. | S / Basis | G §11.1; V:475–512 |
| V26 | Applicability-Override bleibt deklarierte Ausnahme/Ergänzung; keine eigenständige Filterdimension oder Quellenabdeckungsbehauptung. | S / Overrides | G §11.1.1; QM CQR003 |
| V27 | `applicabilityMappingInheritance=boundary` unterbricht breite Vorfahren-Quellenvererbung; direkte Evidenz und Kindvereinigung bleiben wirksam. | R / verwendete Supplementgrenzen | AG §2.3 |
| V28 | `applicabilityFromRequires=true` ist auf zulässige Praxis-/Prüfungsendpunkte begrenzt und erzeugt nur Applicability-, keine Quellenbelege. | S/R / verwendetes Profil | AG §2.3 |
| V29 | Vollständige globale atomare Hülle wird vor Scope-Einschränkung berechnet; außerhalb liegende Zwischenknoten kürzen Pfade nicht. | R / Basis | G §§11.2–11.4 |
| V30 | Kompilierte und gespeicherte Projektion dürfen nicht unbemerkt auseinanderlaufen; Drift ist gesondert ausweisbar, nicht still kanonisch. | E / kompiliertes Profil | GV APV203 |
| V31 | Projektion hat gültige Metadaten, keine leeren unzulässigen Strukturknoten und keine internen SourceExtraction-Titel im Lernbaum. | S / entsprechende CPV-Regeln | GV CPV001/007/216 |
| V32 | Sichtbare Voraussetzungen müssen im zulässigen Ziel-/Supportscope auflösbar sein; projizierte Ziele bleiben von Scope-Wurzeln erreichbar. | S / Projektionsprofil | GV APV102/103 |

## 3. Mastery, Frontier und Levels

| ID | Unabhängige harte Regel | Art / Profil | Stelle |
|---|---|---|---|
| R01 | Gespeicherte explizite atomare Mastery ist binär; keine zweite gespeicherte implizite Mastery oder Unit-Mastery. | R / Ziel 6.11. | G §9; A:17–52 |
| R02 | Clusterzufriedenheit ist ausschließlich abgeleitet; Clusterabschluss schreibt keine Kinder-Mastery. | R / Basis | G §9; AG §2.2 |
| R03 | Atomare/Cluster-Zufriedenheit verwendet die effektive Mastery, bei Clustern eindeutige atomare Nachfahren. | R / Ziel 6.11. | G §9 |
| R04 | Ein leerer oder ungültiger Ziel-/Supportscope ist nicht automatisch vollständig bestanden. | R / Basis | G §9; A:107–131 |
| R05 | Gewichteter Fortschritt zählt jedes atomare Ziel genau einmal, auch bei mehreren Eltern. | R / Basis | AG §3 `weight`; G §9 |
| R06 | Im Hessischen Mathematik-GO-Profil haben Atome Gewicht 1 und Cluster Gewicht der eindeutigen atomaren Nachfahren. | S / HE Math GO | AG §3 `weight` |
| R07 | Normale Frontier enthält nur unbeherrschte zulässige atomare Ziele, deren relevante Voraussetzungen erfüllt sind. | R / Basis | G §9.1 |
| R08 | Normaler Fokus ist Vereinigung gewählter Wurzeln und Nachfahren, geschnitten mit Personal-Curriculum-Zielen. | R / Basis | G §11.2; AG §2.3 |
| R09 | Normalmodus prüft nur effektive Anforderungen im Fokus; externe Anforderungen blockieren nicht und werden dadurch nicht gemeistert. | R / Basis | G §11.3 |
| R10 | Scope-relative Clusteranforderung verwendet nur zugehörige relevante Atome; leerer externer Support erzeugt weder Blockade noch Mastery. | R / Normalmodus | G §11.3 |
| R11 | Strict-Modus prüft vollständige globale Anforderungen einschließlich Support; Strict-Frontier ist Teilmenge optimistischer Frontier. | R / Strict | G §11.4 |
| R12 | Relaxed-Prerequisite-Scope ist eigenes ausdrücklich gewähltes Profil; seine Semantik darf nicht still den Strict-Modus ersetzen. | R / Bedingt | G §11.6 |
| R13 | Diagnostik fehlender Ziele/fehlender Atome verwendet dieselbe Normalisierung/Hülle, dedupliziert und schreibt keine Kanten. | R / Diagnostik | G §11.5 |
| R14 | Level-2-Konfiguration enthält explizite Stage; Kursprofil LK impliziert keine Stage, fehlende Stage bleibt unaufgelöst. | R / Personal Curriculum | PS:54 ff.; AG §2.3 |
| R15 | Level-2-Änderung revalidiert Fokus/aktives Goal, erhält stabile IDs und globale Mastery. | R / Personal Curriculum | PS:73 ff. |
| R16 | Level-2-Bearbeitung nutzt autorisierten First-party-Ablauf und gemeinsame Backendvalidierung; OpenAI-Coach editiert diese Konfiguration nicht. | R / Coachprofil | PS:79 ff. |
| R17 | Aktives Lernziel ist genau ein Atom; Fokus und aktive atomare Wahl sind getrennte Zustände. | R / Basis | PS:94 ff. |
| R18 | Fokusweitung erst nach tatsächlichem aktuellem Fokusabschluss, nicht allein bei leerer Frontier. | R / Basis | PS:105 ff. |
| R19 | Backend-Weitungsoption ist strikte Obermenge und fügt mindestens ein unbeherrschtes Ziel hinzu; nächster geeigneter Vorfahr zuerst. | R / Basis | PS:105 ff. |
| R20 | Mehrwurzel-Weitung ersetzt nur betroffenen Zweig; vollständige geordnete Optionspayload erhält unabhängige Wurzeln. | R / Mehrwurzelfokus | PS:105 ff. |
| R21 | Coach verwendet veröffentlichte frische Weitungsoption unverändert; Speicherung erst nach Lernendenzustimmung. | R / Coach | PS:105 ff. |
| R22 | Ein global wirksam anerkannter gewöhnlicher Goal darf durch Fokuswechsel/-weitung nicht als Pflichtarbeit wieder geöffnet werden. | R / Ziel 6.11. | AG §2.3; A:17–52 |
| R23 | Curriculum-Manifest enthält nur tatsächlich auswählbare Wurzeln, keine enthaltenen Module; referenzierte IDs existieren und Rootmenge entspricht berechneter Auswahl. | S / Curriculumkatalog | PS:30 ff.; GV Manifest-Prüfung |
| R24 | Bayern-Math GK umfasst gesamten Pflichtkurs, LK zusätzlich alle fünf Vertiefungsmodule; Fokus auf drei verkleinert Level-2-Zielnenner nicht. | R/S / BY Math Übergangsprofil | AG §2.3 |
| R25 | Chemie-Themen sind im beschlossenen Übergangsprofil vollständig Zielscope; optionale offizielle Themen werden dadurch weder universal verpflichtend noch als persönlich gewählt behauptet. | S/R / Chemistry Übergangsprofil | AG §2.3 |

## 4. Globale Prüfungsanerkennung und Lerneinheiten

| ID | Unabhängige harte Regel | Art / Profil | Stelle |
|---|---|---|---|
| U01 | Atomare Mengen gewöhnlicher Goals O, Prüfungen Q und Abrufziele K sind disjunkt; Struktur-/Orientierungsziele werden nicht still gewöhnliche Kompetenz. | S / Ziel 6.11. | A:17–52; G §12.2 |
| U02 | Implizite Anerkennung ist exakt Vereinigung qualifizierter Coverage explizit bestandener Q minus M; effektive Mastery ist M vereinigt mit dieser Menge. | R / Ziel 6.11. | G §12.2; A:17–52 |
| U03 | Nur explizit bestandene Q speisen Coverage; kein rekursiver Beweis aus implizit anerkannten Goals und kein Fixed-point-Erweitern. | R / Ziel 6.11. | A:17–52 |
| U04 | Coverage enthält ausschließlich gewöhnliche atomare Goals, keine Q, K, Cluster oder Orientierung. | S / Ziel 6.11. | A:133–153; G §12.2 |
| U05 | `examData.coveredGoalIds` ist einzige verfasste Quelle der Coverage; `requires` allein ist niemals Beweis. | S/R / Ziel 6.11. | A:133–153 |
| U06 | Ungeprüfte, unbekannte oder nicht qualifizierte Coverage ist leer; `released` allein qualifiziert keinen Beweis. | S/R / Ziel 6.11. | A:133–153 |
| U07 | Qualifizierte Coverage ist feste Liste atomarer IDs; kein später wachsender Cluster-/Nachfahren-Platzhalter. | S / Ziel 6.11. | A:133–153 |
| U08 | Jede gedeckte Kompetenz liegt in der vollständigen atomaren Voraussetzungserreichbarkeit des Q. Fehlender Pfad ist Graphfehler, kein automatisch generierter Beweis-/Sequenzgraph. | S / Ziel 6.11. | G §12.2; A:107–131 |
| U09 | Gleiches Q-ID bedeutet unveränderliche Beweisbedeutung für alle historisch zugelassenen bestandenen Varianten. | E/S / Ziel 6.11. | A:133–153 |
| U10 | Stärkere oder historisch nicht belegbare Beweisbedeutung benötigt neue Q-ID; neuer Fingerprint verstärkt alte Resultate nicht. | R/E / Ziel 6.11. | A:133–153 |
| U11 | Historische Prüfungsversionen und ihre damalige Beweisbedeutung bleiben nachvollziehbar; alte lokale Anzeige ist kein neuer Coverage-Beleg. | E / Migration | A:233–262 |
| U12 | Jede gewöhnliche gedeckte Kompetenz muss in jeder zulässigen Bestehensroute vollständig durch Aufgabe plus normale Rubrik nachgewiesen werden. | E / Ziel 6.11.; fachliche Bewertung nicht rein maschinell | A:155–184 |
| U13 | Bestehen hat einen gewöhnlichen gemeinsamen Bewertungsvertrag; keine versteckte Coach-Minimalregel und kein zweites gespeichertes Qualifikationsergebnis. | R/S / Ziel 6.11. | A:155–184; UD Bewertungsvertrag |
| U14 | Praktische und schriftliche Facetten dürfen durch eine mehrteilige reguläre Q mit einem binären Resultat nachgewiesen werden; getrennte unvollständige Teil-Q werden nicht automatisch zum Vollnachweis kombiniert. | R / gewählter Default | A:155–184 |
| U15 | Ein bereits gemeistertes gewöhnliches Goal darf nicht unter gleicher ID zur Prüfung umtypisiert werden und dadurch Prüfungsresultat erzeugen. | R/S / Migration | A:155–184 |
| U16 | Direkte Erwerbsownership ist je aufgelöster Hierarchie/Revision eindeutig; Vorfahren aggregieren, teilen aber nicht die direkte Ownership. | S / LearningUnit | G §12.1; A:54–105 |
| U17 | Unit-Kindrelation ist endlich und azyklisch; verpflichtender Zielumfang ist nicht leer. | S / LearningUnit | G §12.1 |
| U18 | Ownership/Kindrollen werden aus autorisierten Placements oder geprüfter Komposition für einen aufgelösten Scope bestimmt. | S / LearningUnit | U Ownership; G §12.1 |
| U19 | Versteckte Voraussetzungen werden fachlich berücksichtigt, vergrößern aber nicht still den sichtbaren Erwerbs-/Abschlussnenner. | R / LearningUnit | G §12.1; A:54–105 |
| U20 | Für jede erlaubte Required-own-Q-Alternative deckt deren qualifizierte Coverage sämtliche eigenen gewöhnlichen Ziele. | S/E / freigegebene Erwerbsunit | G §12.2; A:54–105 |
| U21 | Erforderliche eigene Q liegen wirklich unter den eigenen Q; unbenutzte Alternativprüfungen werden nicht pauschal Pflicht. | S / freigegebene Erwerbsunit | G §12.2 |
| U22 | Parent-/fremde qualifizierte Q dürfen gewöhnliche Kompetenz global sofort belegen, auch bei noch offenen lokalen Q/K. | R / Ziel 6.11. | A:17–52; :54–105 |
| U23 | Fremder/Eltern-Beweis ersetzt keine verpflichtenden eigenen/Kind-Q oder K; diese erfordern explizite Resultate. | R / LearningUnit | G §§12.2–12.3 |
| U24 | Unitabschluss genau aus wirksamen eigenen Ergebnissen und sämtlichen erforderlichen Kindabschlüssen; kein separat gespeichertes Unit-Ergebnis. | R / LearningUnit | G §12.3; A:186–213 |
| U25 | Aggregation zählt gemeinsame atomare Ziele einmal; eine pauschale Nachfahrenvereinigung liefert keinen Prüfungsbeweis. | R / LearningUnit | G §§12.1–12.3 |
| U26 | Eine atomare fremde Voraussetzung fordert nicht automatisch Abschluss der gesamten fremden Unit. | R / LearningUnit | UP; AG §2.4 |
| U27 | Behauptete ungeteilte Whole-unit-Reihenfolge benötigt zusätzlich azyklischen projizierten Blockgraphen an allen relevanten Grenzen. | S / Bedingt Whole-unit-Claim | G §12.4; UP |
| U28 | Blockprüfung enthält geerbte, indirekte, Cluster-, versteckte und fachübergreifende Anforderungen. | S / Whole-unit-Claim | G §12.4; AG §2.4 |
| U29 | Aktueller Unitvertrag führt keine neue Zugriffssperre ein: direkte Prüfungsversuche bleiben bei gültigem Zugriff/Session/Aufgabe verfügbar. | R / Ziel 6.11. | A:215–231; UP |
| U30 | Prüfungsentdeckung ist vollständig paginierbar und ohne Fortschrittsmutation. | R / Assessmentdiscovery | A:215–231 |
| U31 | Freiwillige Wiederholung bleibt verfügbar und widerruft nicht bloß durch Start vorhandene Kompetenz. | R / Basis | A:215–231 |
| U32 | Widerruf, Korrektur oder entfernte explizite Q berechnet globale effektive Anerkennung neu; alternative weiterhin gültige Beweise bleiben wirksam. | R / Integrität | A:233–262; LS:278 ff. |
| U33 | Änderung von Q/Coverage/Graph/Scope muss abhängige Ableitungen und Cachegültigkeit korrekt binden; kein gemischter alter Beweis/neuer Graph. | R / Ziel 6.11. | A Historie/Integrität; LS Konsistenzvertrag |
| U34 | Migration behauptet ohne qualifizierten Nachweis keine rückwirkenden Fortschrittsgewinne und ändert nicht pauschal andere Fächer. | R/E / Einführung 6.11. | A:233–262 |

## 5. Orientierung, Prüfungsbewertung und Abruflernen

| ID | Unabhängige harte Regel | Art / Profil | Stelle |
|---|---|---|---|
| N01 | Semantische Art und struktureller Atom-/Clustertyp sind getrennte Dimensionen. | S / Basis | N:15 ff. |
| N02 | Orientierung ist reines Blatt ohne prerequisites, examData, memoryData oder Übungen; autorisierte Kind-Zuordnung hat Vorrang vor Heuristik. | S / Orientierung | N:73 ff.; GV GVR014 |
| N03 | Orientierung erhält keine normale bewertete Aufgaben-/Prüfungsoberfläche. | R / Orientierung | N:73 ff. |
| N04 | Orientierungsabschluss braucht Auswahl, passende Folgeinteraktion, Abschlussangebot und gesonderte Zustimmung; bloßes Label genügt nicht. | R / Orientierung | N:84 ff. |
| N05 | Nullfortschritts-Einstieg wählt nur offene passende Orientierungen; bestehender Lernstand wird nicht zurückgesetzt. | R / Orientierung | N:104 ff. |
| N06 | Training und Verifikation sind getrennte Abläufe; Training setzt keine Verifikations-Mastery. | R / SRS | N:120 ff.; :184 ff. |
| N07 | Verifikation kann auf ausdrücklichen Wunsch vor Fälligkeit beginnen. | R / SRS | N:120 ff. |
| N08 | SM2-Erfolg q≥3 erhöht Wiederholungen und verwendet Intervalle 1, 6, anschließend gerundet altes Intervall × EF. | R / implementiertes SM2-Profil | N:153 ff. |
| N09 | EF-Formel hat Mindestwert 1.3; Fehler q<3 setzt Wiederholungen/Intervall zurück, verändert EF nach dem beschriebenen Vertrag nicht. | R / SM2-Profil | N:153 ff. |
| N10 | Fälligkeit wird aus Zeitstempel bzw. fehlendem Zustand ermittelt, nicht aus einem erfundenen Learner-Outcome. | R / SRS | N:160 ff. |
| N11 | **Normkonflikt zur Klärung:** N verlangt für K-Mastery keine fälligen Karten UND alle verifiziert, nennt zugleich Runtime nur verified; A trennt Fälligkeit von fehlgeschlagenem Abruf. Keine stillschweigende Auflösung im Audit. | R / SRS, normativ unklar | N:160–182; A:47–49 |
| N12 | Antwortfreigabe folgt erst auf gestellte Frage/zulässigen Ablauf; fehlgeschlagener Retest entfernt zugehörige Verifikation. | R / SRS | N:184 ff. |
| N13 | Kartenselbstbewertung 1/4 ändert Planung, nicht unmittelbar globale Goal-Mastery. | R / SRS | N:184 ff. |
| N14 | Trainingscharge ist sitzungsbezogen gemischt und höchstens 20 Karten groß. | R / Training | N:204 ff. |
| N15 | Verifikationscharge, Anzahl, Reihenfolge und Capability werden serverseitig festgelegt; Modell kürzt/zerlegt sie nicht. | R / Verifikation | AG Abruf-Batchvertrag um :891 |
| N16 | Verifikationsresultate entsprechen exakt geordneter vollständiger Charge; atomare Speicherung statt Teilkartenfortschritt. | R / Verifikation | AG Abruf-Batchvertrag |
| N17 | Session-/Versionsprüfung und Idempotenz sichern Verifikationsschreiben; Feedback allein ist noch keine Speicherung. | R / Verifikation | AG Abruf-Batchvertrag |
| N18 | Beim vereinbarten Verifikationsablauf ist Zustimmung zur atomaren Speicherung nach Feedback erforderlich; Folgeablauf bleibt servergeführt. | R / Verifikation | AG Abruf-Batchvertrag |
| N19 | Prüfungsgoal enthält Task, Lösung, Scoring, maxPoints/passThreshold und vollständig identifizierte Bewertungsschritte mit Punkten/Beschreibung. | S / Exam | N:218 ff.; QM CQR201 ff. |
| N20 | Lokalisierungsfallback erhält zusammenpassendes Aufgaben-/Lösungs-/Rubrikpaar; keine Mischung verschiedener Prüfungsvarianten. | R/S / mehrsprachige Exam | N:218 ff.; A Bewertungsvertrag |
| N21 | Prüfungsversuch ist unabhängig von vorbereitender Frontier verfügbar; Remediation nutzt dennoch vollständigen normalisierten Bedarf. | R / Exam | N:279 ff. |
| N22 | Gesamtpunkte sind min(Summe Schritt-Punkte, Maximum); bestanden genau ab passThreshold. | R / normales Exam-Grading | N:324 ff. |
| N23 | Bestandene Prüfung schreibt genau das binäre Prüfungsresultat; kein gesonderter verborgener Qualifikationsstatus. | R / Exam | N:324 ff.; A |
| N24 | Fehlgeschlagene Prüfung schreibt nach aktuellem Vertrag keine Mastery und keinen persistierten Fehlversuch-/Punktestand; Wiederholung bleibt möglich. | R / Exam | N:324 ff. |
| N25 | Fehlgeschlagenes Backendschreiben darf nicht als erfolgreich gespeicherte Mastery gemeldet werden. | R / Exam | N:324 ff. |
| N26 | Prüfungsaufgabe wird unverändert und ohne lösungsgebende Hinweise präsentiert; vollständige Abgabe vor Auswertung. | R / Exam-Coach, semantischer Teil nicht vollständig deterministisch | N:344 ff. |
| N27 | Nach Ergebnis kein neues Lernziel ohne den vorgesehenen Zustimmungs-/Handoffablauf. | R / Coach | N:344 ff. |

