# Konzeptempfehlung zu Vorschlag 2

Stand: 6. November 2026. Read-only-Analyse der bestehenden Konzepte und des
Vorschlags; dieses Dokument ist keine Produktänderung oder Abnahme.

## 1. Empfohlene Entscheidung

Abschnitt 8 wird **bewusst als neue Anerkennungsregel** angenommen. Die bisherige
lokale Restbedarfsformel wird nicht lediglich anders implementiert. Der Beweis
einer gewöhnlichen Kompetenz ist von der Erwerbszuständigkeit einer Einheit
zu trennen:

```text
O = gewöhnliche fachliche atomare Ziele
Q = Prüfungsziele, K = Kartenziele
M = explizit bestandene atomare Ziele (einziger binärer Lernendenstatus)
C(q) = vollständig validierte gewöhnliche Ziele einer unveränderlichen Q-Bedeutung
I(M) = (union C(q) für q in M ∩ Q) \ M
M_eff = M ∪ I(M)
```

`C(q)` ist keine Auswertung der `requires`-Pfade. Maßgebliche Autorenliste bleibt
`examData.coveredGoalIds`, qualifiziert durch Aufgabe, normale Rubrik und
unabhängige Prüfung. `reviewStatus=released` allein belegt diese strengere
Qualifikation nicht. Vorhandene Deklarationen bleiben zunächst Behauptungen;
ohne gültige Qualifikation gilt konservativ `C(q)=∅`.

Eine Zwischenprüfung Q1 kann a unmittelbar anerkennen, obwohl Q2 a ebenfalls
benötigt und offen bleibt. Eine Eltern- oder Fremdfachprüfung darf a nur bei
vollständigem echtem Nachweis anerkennen. Sie besteht niemals die Q/K des Kindes.
Die direkte Erwerbszuständigkeit bleibt je aufgelöstem Lernweg eindeutig und
steuert Struktur, Verantwortung und vollständige Pflichten, nicht ein exklusives
Monopol auf jeden später möglichen fachlichen Nachweis.

Kein zweiter Lernendenstatus, keine manuell gepflegten Freistellungsprofile,
keine automatische Anerkennung aus Quellenmapping, Fokusbesuch, `requires`,
Einheitenzuordnung oder einem leeren Restbedarf. Eine geprüfte Nachweisbeziehung
ist ebenfalls kein Beleg offizieller Lehrplanabdeckung.

## 2. Komposition, historische Bedeutung und Bewertung

**Ein vollständiger Nachweis pro Q ist der Default.** Ein experimentelles und
ein schriftliches Teilstück bilden eine mehrteilige reguläre Prüfung mit einer
vollständigen Abgabe, einer Rubrik und einem binären Endergebnis. Kein neuer
Kombinationsformalismus ist für den Start nötig. Bereits getrennt bestandene
Teilprüfungen belegen ein umfassenderes Ziel bis zu einer gültigen gemeinsamen
Prüfung nicht vollständig. Ein Experiment darf dabei nicht durch Auswertung
bereitgestellter Daten als tatsächlich ausgeführt ausgegeben werden. Aufgaben
und vorhandener Prüfungsablauf müssen geeignete eigene Mess-/Versuchsevidenz
ermöglichen. Eine reale Notwendigkeit zeitversetzter separater Nachweise wäre
ein konkreter späterer Konzeptbefund, kein Anlass für eine vorsorgliche DSL.

**Q-ID bindet Prüfungsbedeutung.** Ein gespeichertes `M(q)=1` enthält keine
Vertragsversion. Deshalb müssen alle jemals unter derselben ID zulässigen
Bestehenswege den freigegebenen Umfang tragen. Ein neuer Hash der heutigen
Rubrik löst dieses historische Problem nicht. Bei stärkerem oder unklarem
Anspruch neue Q-ID; altes explizites Ergebnis bleibt erhalten und unverändert.
Neue Varianten dürfen dieselbe ID nur bei nachgewiesener Gleichwertigkeit
behalten. Auch Änderungen an `coveredGoalIds`, erlaubten Hilfen und Bewertung
gehören zur Bedeutungsprüfung. Ein bloß anderer Titel ist keine neue Bedeutung.
Bereits gültige Verträge müssen über Curriculum-/Fokuswechsel verfügbar bleiben.

**Ein einziges normales Bestehensurteil.** Zuerst Aufgaben, Kriterien, Gewichte
und Bestehensgrenze so entwerfen, dass die bestehende Gesamtpunktewertung das
Lernversprechen trägt. Für jedes wesentliche Kriterium e ist konkret zu prüfen:

```text
maximal erreichbare Gesamtpunkte bei fehlendem e < Bestehensgrenze
```

Dabei muss wenigstens ein realistischer Fall mit sicherem Verständnis und
einem beiläufigen Rechenfehler regulär bestehen. Dieses Paar aus Negativ- und
Positivbeispiel verhindert sowohl kompensierbare Kernlücken als auch eine
unbeabsichtigte Fehlerlosigkeitspflicht. Den rechnerischen Test trägt eine
fachliche Rubrik, nicht bloß das Löschen einiger Aufgabenpunkte.

Falls der aktuelle Punktevertrag diese Unterscheidung nicht leisten kann, ist
eine ausdrückliche gemeinsame Änderung der normalen Bewertungsregel nötig,
einschließlich aller verwendeten Adapter. Coach-seitige Zusatzminima wären ein
unzulässiger versteckter zweiter Pass. Aktuell prüfen die Adapter nur
`earnedPoints >= passingPoints`, z.B. `OpenAiDeV1McpContractAdapter.java:2193`.
Die sichtbare Beschreibung kann die verlangten Fähigkeiten erklären; Lösungen
und Detailrubrik bleiben bis zur Evaluation wie bisher geschützt.

## 3. Einheit, Karten und Lernweg

Der fachliche Default M01/M02 und P13/P14 ist gut begründet. Senkrechter Wurf
und freier Fall bleiben P13, Komponenten und gemeinsame Zeit P14; Kreisbewegung
folgt P17 mit Dynamik. M02 muss den tatsächlichen ganzen Zahlbereich samt
Vorzeichen und zulässiger Division bewahren. Keine Zielquote entscheidet Größe.
Werkstätten brauchen einen konkreten Erwerbsort oder werden als Anwendungssichten
ausgewiesen; Prüfungsbereiche sind keine Pflicht zum Bestehen aller Varianten.

Die abgeschlossene Einheit ergibt sich weiter rekursiv aus allen eigenen
Pflichten und erforderlichen Kindern. Q und K brauchen stets ihre expliziten
Ergebnisse. Bereits gültige gewöhnliche Anerkennung bleibt trotz offener K,
Elternprüfung oder späterer Prüfung bestehen. Direkte Prüfung bleibt möglich;
keine neuen Zugangssperren werden eingeführt. Die geplante Reihenfolge vermittelt
die tatsächlich benötigte Grundlage rechtzeitig.

**Notwendige Abschlussinvariante:** Für jede Erwerbseinheit und jede aufgelöste
Prüfungsvariante müssen die tatsächlich erforderlichen eigenen Q alle direkt
eigenen gewöhnlichen Kompetenzen unabhängig nachweisen:

```text
Own(U) ∩ O ⊆ union C(q) für q ∈ RequiredOwnQ(U)
```

Andernfalls könnten gewöhnliches direktes M(a) (= Verständnis) und eine andere
bestandene Q, die a gar nicht prüft, die Einheit vollständig schließen, obwohl
die versprochene selbstständige Anwendung von a fehlt. Globale Anerkennung
durch Fremd-/Eltern-Q ist erlaubt, ersetzt aber nicht diese obligatorischen
eigenen Q. Die Invariante ist statische Inhaltsqualität; sie führt keine neue
Restbedarfsableitung oder zweite Lernendenqualifikation ein.

Alle elf vorhandenen Decks müssen inhaltlich geprüft werden. Ein breites K darf
nicht nur zum Schließen kleiner Muster an den Elternknoten verschoben werden.
Bei notwendiger Aufteilung: genaue Kartenauswahl, stabile Kartenidentitäten,
neue K-Bedeutung und nachvollziehbare Behandlung vorhandener echter Recall-
Evidenz. Kein Kopieren alter Gruppen-Mastery oder Erfinden historischer Events.
Ist ein Deck nicht verfügbar, ist die betroffene Einheit noch nicht vollständig
freigegeben; die unabhängig prüfbaren anderen Arbeitspakete laufen weiter.

## 4. Vollständigkeit ohne neue Lehrplanexpansion

Zwei explizite Mengen werden getrennt geführt:

1. Vollständiger heutiger kanonischer Pool: alle 2.018 Original-IDs erhalten eine
   nachvollziehbare Rolle, einschließlich 403 Struktur-/Orientierungsknoten,
   319 Prüfungen, elf K und aller 1.285 gewöhnlichen Ziele. Orientierung darf
   nicht wegen der gemeinsamen Zählkategorie zur bloßen Überschrift werden.
2. Tatsächlich angebotene aufgelöste Fachansichten: revisionsgebundene Matrix
   der vorhandenen Länder-, Dauer-, Stufen- und Fachprofilkombinationen aus dem
   echten Katalog. Nur deren `target` zählt zu Fortschritt/Abschluss; versteckte
   `prerequisiteOnly`-Unterstützung bleibt fachlich und graphisch überprüft.

Einheitenkatalog und ID-Verantwortung müssen den ganzen Pool behandeln. Jede
angebotene Ansicht braucht vollständige passende Ziel-, Q/K- und Varianten-
Pflichten sowie ihre einschlägigen Quellen-/QA-Gates. Dormante Inhalte werden
nicht stillschweigend zu neu angebotenen Lehrplänen oder neuen Quellenaudits
ausgeweitet. Keine globale GK/LK-Prüfungsliste als Ersatz für echte Auflösung.
Die vorhandene erste CSV mit 8.072 Zeilen/U-Kennungen ist keine V2-Zuordnung.
Fehlt das V2-Paket, ist die neue überprüfbare Zuordnung aus dem lokalen Bestand
ein eigener Liefergegenstand, keine behauptete Übernahme.

## 5. Unverzichtbare Gegenbeispiele und Invarianten

- Q1 belegt a, Q2 benötigt a und bleibt offen: a global wirksam; Q2 offen.
- Q bestanden ohne qualifiziertes C(q): kein zusätzlicher Kompetenzgewinn.
- Q setzt a voraus, prüft es jedoch nicht vollständig: a bleibt unanerkannt.
- Eltern-/Fremd-Q belegt gewöhnliches a vollständig: a gilt; Kinder-Q/K offen.
- Zwei isolierte Teil-Q decken zusammen Experiment und Theorie: ohne gültige
  vollständige Q kein implizites Gesamtziel; explizite Teil-Q-Erfolge bleiben.
- Q → b → a, b direkt beherrscht, a unbewiesen: vollständiger transitiver
  Bedarf bleibt sichtbar. Keine Shortcuts durch beherrschte Zwischenknoten.
- Redundante direkte Kante Q → a entfernt: gleiche wirksame Voraussetzungen,
  gleiche Anerkennung. `requires` beeinflusst C(q) niemals automatisch.
- Fokus/Land/Fachprofil wechseln: gültiges a bleibt; nur der Zähler im neuen
  Target-Set ändert sich. Keine Scope-Auswahl als Anerkennungsereignis.
- Neue stärkere Q-Rubrik oder Coverage unter alter ID: Validator verweigert
  neue Anerkennung alter Ergebnisse; neue ID erzeugt keinen alten Pass.
- Selber kanonischer Atom unter mehreren Platzierungen: einmal Fortschritt,
  je aufgelöstem Lernweg ein Erwerbsowner; Elternunion ohne Doppelzählung.
- Atomare Kette a → b → c, Einheit {a,c} und Einheit {b}: atomarer DAG gültig,
  Blockreihenfolge widersprüchlich. Grenze prüfen oder Verzahnung ehrlich zeigen.
- Grundfehlvorstellung kompensiert vs. korrekter Ansatz mit Rechenversehen:
  erste Abgabe fällt regulär durch, zweite kann regulär bestehen.
- Alle gewöhnlichen Ziele direkt erreicht und alle erforderlichen eigenen Q
  bestanden, aber eine eigene Kompetenz wird von keiner dieser Q belegt:
  fehlerhafter Einheitsvertrag; nicht als vollständige Anwendung freigeben.
- Auswahl einer passenden Prüfungsvariante: alle erforderlichen Pflichten
  bleiben; alternative Prüfungen werden nicht alle Pflicht und nicht versteckt.
- Unvollständige Membership/Decks/Nachweisverträge: Status nicht berechenbar
  bzw. nicht freigegeben, niemals leere Menge = vollständige Einheit.
- Explizite Eventhistorie bleibt explizit; I erzeugt weder Ausführungsdatum
  noch gespeicherte Punktzahl, Lernzeit oder fingierte Tagesleistung.

## 6. Kleine Lieferungen und unabhängige Fachmeilensteine

1. Inventar, eingefrorene Eingangsrevision, vollständige Scope-Matrix und neue
   Anerkennungsentscheidung konkret festhalten. Die vier Muster samt Karten-
   und historischen Q-Fragen zuerst vollständig auflösen.
2. Einen dünnen gemeinsamen Laufzeitpfad aus Q-Vertrag → M_eff → Voraussetzungen,
   Fortschritt und Einheitenabschluss liefern; alle betroffenen Coach-Texte
   konsistent machen. Sichtbares M01 und sichtbares P13 mit echten Aufgaben,
   nicht nur JSON-Skeletten. M02/P14 zeigen unmittelbar die Anschlüsse.
3. Mathe in fachlich begründeten endlichen Paketen vollständig erweitern;
   Physik parallel in eigenen Paketen. Pro Paket IDs, Grenzen, Quellen,
   Prüfungen/Rubrik, Karten, Projektionen und Graphdiagnostik liefern und
   unabhängig reviewen. Jeder Abschluss ist ein überprüfbarer Commit/Stand,
   keine grobe Prozentbehauptung oder zweitägiger ungesicherter Zwischenstand.
4. Gesamte Mathematik separat abnehmen und separat ausliefern können, sobald
   deren aktuelle Scope-Matrix vollständig besteht. Analog Physik. Cross-subject
   Voraussetzungen jedes Pakets früh prüfen, nicht erst am Schluss.
5. Zum Abschluss gemeinsamer Revisionsstand, vollständige Bestandsbilanz,
   Quellen-/strikte M7-Nachweise und tatsächlich getestete Benutzerwege.
   Machine-QA, fachliche Abnahme, echte Hosts und empirische Wirksamkeit klar
   unterscheiden. Lokale Vorbereitung ist keine Produktionsauslieferung.

**Migrationsrisiko:** Die heutige Runtime enthält noch Restbedarfs-/Discharge-
Sprache, z.B. `ClaudeV1CompletionChoices.java:168–169`: bestandene Prüfung sei
für impliziten Abschluss nicht nötig, ein beherrschter Zwischenknoten verlange
keine eigenen Voraussetzungen mehr. Neue Mathe-/Physik-Verträge brauchen daher
eine ausdrückliche gemeinsame Semantikmigration. Alte lokale Anzeigen sind
nicht automatisch gültige globale Kompetenz. Explizite Daten bleiben erhalten;
ungeprüfte andere Fächer dürfen weder unbemerkt neue Anerkennung erhalten noch
als vollständig auf neue Einheiten umgestellt gelten. Die konkrete Aktivierung
und die erwartbaren Anzeigeänderungen gehören in den ersten Technikmeilenstein.

## Prüfgrundlagen

`tmp/aa_input/vorschlag2.md`,
`tmp/aa_input/review-vorschlag2-20261106/README.md`,
`docs/concept/skill-graph/{learning-units,assessment-gated-completion,learning-unit-design-and-examples,learning-unit-progression}.md`
sowie gezielte Prüfung der bestehenden Bewertungs- und Coach-Semantik im Code.
Keine Produktdateien, Curricula, Gitstände oder Goals wurden verändert.
