# SkillPilot: Lerneinheiten fachlich entwerfen

Dieses Paket ist für eine unabhängige fachliche Analyse durch KI oder Menschen
gedacht. Es verbindet unser aktuelles Konzept mit unveränderten kanonischen
Curriculumdaten aus `main`. Es enthält noch keine empfohlene Gesamteinteilung.

## So verwenden

ZIP entpacken beziehungsweise durch das KI-Werkzeug öffnen lassen. Für den
Auftrag benötigt das Modell zunächst `KONZEPT.md`, `AUFGABE.md` und die beiden
JSON-Dateien unter `curricula/`. Die Dateien unter `inventare/` helfen beim
gezielten Lesen; die Originaldaten enthalten zusätzliche Angaben und Aufgaben.
Nicht sämtliche Dateien als einen langen Chattext einfügen, wenn das Werkzeug
Dateien durchsuchen und gezielt lesen kann.

Die folgende Nachricht kannst du direkt verwenden:

> Bitte bearbeite die Aufgabe aus AUFGABE.md auf Grundlage von KONZEPT.md und
> den beigefügten kanonischen Curricula. Fachumfang: **Mathematik und Physik**.
> Entwickle und vergleiche fachlich sinnvolle Lerneinheiten. Beginne mit konkreten
> Beispielen, liefere anschließend die vollständige Gliederung und überprüfbare
> Zielzuordnung. Prüfe unsere Annahmen kritisch und halte offene Fragen sichtbar.
> Bearbeite große Umfänge in nachvollziehbaren Teilen, ohne Ziele still auszulassen.
> Bestätige zuerst kurz, welche Dateien du tatsächlich lesen kannst.

Für einen Einzelauftrag ersetze den Fachumfang durch **Mathematik** oder
**Physik**. Bei Physik sollte die Mathematikdatei als Voraussetzungskontext
mitgegeben werden. Ohne Fächerwahl gilt der Gesamtauftrag für beide Fächer.
Kann ein Werkzeug keine ZIPs lesen, die benötigten Dateien einzeln hochladen.
Alternativ können die gleichnamigen `.txt`-Dateien unter `curricula/` hochgeladen werden; sie enthalten bytegenau denselben Inhalt wie die JSON-Dateien.

## Inhalt

| Datei / Verzeichnis | Zweck |
| --- | --- |
| [KONZEPT.md](KONZEPT.md) | Kompakte Vereinbarungen, Kriterien, Beispiele und offene Fragen. |
| [AUFGABE.md](AUFGABE.md) | Arbeitsauftrag, Ergebnisformat und Selbstprüfung. |
| `curricula/` | Vollständige Originaldateien Mathematik und Physik, einschließlich vorhandener Aufgaben und Metadaten. |
| `inventare/*-LERNZIELE.md` | Alle Original-IDs, Titel, Beschreibungen, Relationen und vorhandenen Typkennzeichnungen. |
| [inventare/REFERENZEN.md](inventare/REFERENZEN.md) | Begrenzte Referenzprüfung und fachübergreifende Verknüpfungen. |
| [manifest.json](manifest.json) | Herkunft, Commit, Dateigrößen und SHA-256-Prüfsummen. |
| [HERKUNFT-UND-LIZENZEN.md](HERKUNFT-UND-LIZENZEN.md) | Quellen, Lizenzzuordnung und Bedingungen fremder Inhalte. |

## Eindeutiger Datenstand

- Repository: [enpasos/skillpilot](https://github.com/enpasos/skillpilot)
- `origin/main`, am **6. November 2026 frisch abgerufen**:
  [`0ce5a8d791eeb9783a919195fd8590bfb79f3595`](https://github.com/enpasos/skillpilot/commit/0ce5a8d791eeb9783a919195fd8590bfb79f3595)
- Mathematik: **1.252 Knoten** — 978 als `atomic`, 274 als `cluster` gekennzeichnet.
- Physik: **766 Knoten** — 641 als `atomic`, 125 als `cluster` gekennzeichnet.
- Physik enthält 162 direkte `requires`-Verweise auf 54 verschiedene Mathematikziele.
  Die geprüften Zielreferenzen sind innerhalb der beiden Dateien vollständig auflösbar.

Beide JSONs sind bytegenaue Exporte dieses Commits. Das Konzeptpapier und der
Arbeitsauftrag wurden für dieses Paket neu geschrieben und spiegeln auch die
aktuelle Diskussion wider; sie sind keine Dateien dieses `main`-Commits.
Alte PR-Einheitenschnitte wurden nicht hinzugefügt.

Die Referenzprüfung beweist weder didaktische Richtigkeit noch vollständige
offizielle Lehrplanabdeckung. Nicht enthalten sind zusätzliche Länderansichten,
extern verknüpfte Medien/Kartendecks, das Metzler-PDF und Lernendendaten.
Vorhandene Links und Hinweise bleiben in den JSONs erhalten. Genaue Kursansichten
und Prüfungsfreigaben dürfen aus diesem begrenzten Paket nicht erfunden werden.
