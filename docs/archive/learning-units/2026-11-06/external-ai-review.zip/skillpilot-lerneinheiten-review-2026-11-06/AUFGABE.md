# Auftrag an die prüfende KI: Mathematik und/oder Physik in Lerneinheiten gliedern

Du erhältst `KONZEPT.md`, zwei kanonische SkillPilot-Curricula aus einem in
`manifest.json` benannten Git-Commit sowie lesbare Lernziellisten als Arbeitshilfe.
Lies zuerst das Konzept, dann die Originaldaten. Arbeite auf Deutsch.

**Ziel:** Entwickle eine fachlich und didaktisch überzeugende Gliederung in
Lerneinheiten. Ihre Prüfungen müssen solide selbstständige Anwendung sichern,
bevor darauf aufgebaut wird. Prüfe unseren Ansatz kritisch. Eine begründete
Alternative oder ein präziser Konzeptwiderspruch ist wertvoller als eine glatte,
aber fachlich schwache Einteilung. Dies ist ein Entwurfsauftrag, keine Freigabe
für Änderungen am Produkt oder eine fertige Produktionsmigration.

## 1. Arbeitsumfang offenlegen

Bearbeite das vom Auftraggeber gewählte Fach: **Mathematik**, **Physik** oder
**beide**. Ohne weitere Auswahl bearbeite **beide Fächer vollständig**. Beginne
mit Mathematik Klasse 5 und dem Einstieg in die Oberstufenkinematik, um die
Kriterien an konkreten Beispielen zu prüfen; diese Beispiele begrenzen den
Gesamtauftrag nicht. Entwickle daraus die Architektur und vollständige Zuordnung.

Die kanonischen Dateien bündeln Ziele verschiedener Bildungsabschnitte und
gegebenenfalls Länder/Kursprofile. Sie sind **nicht automatisch ein einzelner
verbindlicher Schülerlehrplan**. Benenne den untersuchten Umfang, Annahmen und
Varianten. Nutze vorhandene Metadaten; erfinde keine verbindliche Länder-, Jahres-
oder Kurszuordnung. Für eine exakte solche Sicht können zusätzliche
Kompositions-/Quelldaten fehlen: kennzeichne dies als Grenze des Pakets.

Ziel ist eine nachvollziehbare Gesamteinteilung des gewählten Umfangs. Liefere
zuerst belastbare Beispiele und die Gesamtarchitektur. Wenn eine einzige Antwort
für die vollständige Zuordnung nicht reicht, arbeite in benannten Teilmengen
weiter und führe eine Liste aller noch unbehandelten Ziele. Keine unbemerkten
Auslassungen und keine behauptete Vollständigkeit einer bloßen Stichprobe.

## 2. Bestand fachlich lesen

- Verwende Original-IDs und vollständige Zielbedeutungen einschließlich der
  Beschreibungen. Unterscheide vorhandene Cluster, Fachziele, Prüfungen,
  Orientierung und Lernkarten anhand der tatsächlichen Daten; unklare Rollen
  sind Befunde. Die Inventare ersetzen die vollständigen JSON-Dateien nicht.
- Untersuche direkte, transitive, geerbte und über Cluster ausgedrückte
  Voraussetzungen. `A.requires = [B]` heißt: erst B als Grundlage, dann A.
  Fehlende Referenzen oder Voraussetzungen in anderen Fächern ausdrücklich nennen.
- Prüfe die fachliche Plausibilität. Vorhandene Kanten sind weder unfehlbar noch
  frei veränderbare Hilfsmittel für einen gewünschten Schnitt. Trenne den
  Bestandsgraphen von vorgeschlagenen Korrekturen.
- Prüfe vorhandene Aufgaben, Bewertungen und Karten, soweit enthalten. Ein
  `requires`-Pfad beweist keine tatsächliche Prüfungsabdeckung. Verknüpfte, nicht
  beigefügte Medien oder externe Inhalte gelten nicht als von dir geprüft.

## 3. Sinnvolle Einheiten entwickeln

Suche zusammenhängende neue Vorstellungen, Modelle oder Anwendungsfähigkeiten.
Vergleiche für die ersten Beispiele mindestens zwei ernsthafte Zuschnitte,
beispielsweise kleinere selbstständige Einheit gegen größere thematische Einheit
mit Zwischenprüfung. Entscheide anhand des Lernversprechens und der Tragfähigkeit
für anschließendes Lernen. **Keine automatische Einheit je Prüfungsziel; keine
optimierte Zielanzahl und keine Kapitelkopie.**

Beschreibe jeden empfohlenen Kandidaten so knapp wie möglich, aber mit:

1. Titel, motivierender Leitfrage und verständlichem Lernversprechen.
2. Direkt zugeordneten Originalziel-IDs und gegebenenfalls echten Untereinheiten.
   Eltern übernehmen Kindziele nur aggregiert. Gemeinsame Grundlagen werden in
   einer konkret gewählten Sicht einmal erworben und später referenziert.
3. Konkreten Eingangskompetenzen, innerem Lernzusammenhang und begründeter Grenze.
   Einzelne atomare Abhängigkeiten und bewusst gewollte ganze Einheitsvoraussetzungen
   getrennt ausweisen; erforderliches Ineinandergreifen offenlegen.
4. Einer oder mehreren Prüfungsskizzen mit wesentlichen Beurteilungskriterien:
   Welche selbstständige Anwendung belegt welches behauptete Können? Welche
   Fehlvorstellung darf nicht unbemerkt zum Bestehen führen? Wie werden isolierte
   Fehler fair behandelt? Welche gezielte Rückmeldung und erneute Prüfung folgen?
5. Einordnung bestehender Prüfungen/Karten: passend, nur teilweise passend,
   unzureichend oder mangels Inhalt ungeprüft. Neue Aufgaben nur als Vorschläge
   markieren; keine neuen produktiven UUIDs oder angeblich bereits gültigen Nachweise.

Jede Erwerbseinheit braucht einen nachvollziehbaren Anwendungsnachweis. Ein reines
Aggregat benötigt keine zusätzliche künstliche Prüfung. Eine Synthese kann einen
eigenen Abschluss rechtfertigen, ersetzt aber keine erforderlichen Kindprüfungen
oder Lernkarten. Ein umfassendes Kartenziel darf nicht stillschweigend zu einem
übergeordneten Knoten verschoben werden, um Kinder ohne ihre wirklichen Pflichten
abschließen zu können. Nötige Zielteilungen sind separate Änderungsvorschläge.

Wenn zwei mögliche Kursvarianten eine Kompetenz verschieden platzieren, zeige
beide Varianten getrennt; erzeuge keine doppelten kanonischen Kompetenzen.
Zielanzahl und `weight` sind keine belastbare Lernzeitmessung. Vermeide frei
erfundene Stundenangaben; begründete Schätzungen brauchen Annahmen und Unsicherheit.

## 4. Gegenprüfen, bevor du die Einteilung empfiehlst

- **Lücken:** Ist jeder Knoten des gewählten Umfangs berücksichtigt — als direktes
  Ziel, struktureller Knoten, äußerer Unterstützer, begründet ausgeschlossene
  Variante oder ausdrücklich noch offener Befund? Kein Fachziel verschwindet.
- **Kein doppelter Erwerb:** Hat jedes zugeordnete atomare Erwerbsziel innerhalb
  einer aufgelösten Variante genau eine direkt verantwortliche Einheit?
- **Reihenfolge:** Ist der atomare Graph azyklisch und transitiv minimal? Entstehen
  durch Gruppierung Blockzyklen? Bestehen fachlich sinnvolle parallele Wege?
  Bestehende Fehler berichten, nicht heimlich durch Weglassen beheben.
- **Nachweis:** Könnte man eine vorgeschlagene Prüfung bestehen, ohne eine von
  ihr beanspruchte wesentliche Kompetenz zu haben? Benenne Gegenbeispiele.
- **Fachübergreifend:** Sind die konkret verwendeten Mathematikmethoden vor der
  abhängigen Physikaktivität verfügbar? Keine implizite Integralrechnung im
  beschriebenen Kinematikeinstieg. Falls Verfügbarkeit unbekannt: Annahme nennen.
- **Konzeptspannung:** Bearbeite die offene Frage aus `KONZEPT.md` zur frühen
  Zwischenprüfung, späterem Bedarf und globaler impliziter Kompetenz ausdrücklich.
  Verbiege die fachliche Einteilung nicht, um eine bisherige Ableitungsformel zu retten.

Wenn du diese Prüfungen programmatisch ausführen kannst, liefere Ergebnisse
und verwendeten Umfang. Falls nicht, kennzeichne die Prüfung als manuell oder
offen. Ein vorgeschlagenes Aufgaben-/Bewertungskonzept ist noch keine unabhängig
begutachtete Prüfung und kein Nachweis von Unterrichtswirksamkeit.

## 5. Erwartetes Ergebnis

Bitte liefere:

- Eine kurze Empfehlung einschließlich der wichtigsten offenen Entscheidungen.
- Eine übersichtliche Einheitentabelle und einen Graphen des **Lernflusses**
  (Voraussetzung → aufbauende Einheit); optional getrennte Sicht für Verschachtelung.
- Ausführliche, konkrete Beispiele vor einer schematischen Vollzuordnung.
- Eine prüfbare Zuordnung aller behandelten Original-IDs, vorzugsweise als Datei
  `zuordnung.csv` mit `variant_id, goal_id, disposition, direct_unit_id, reason`.
  Benutze für `disposition` eindeutige Werte wie `assigned`, `structure`,
  `external_support`, `outside_scope`, `unresolved`. Referenzen auf geteilte
  Grundlagen sind keine weitere `assigned`-Zeile derselben Kursvariante.
- Eine separate Liste vorgeschlagener Graph-/Ziel-/Prüfungskorrekturen mit
  Original-IDs, Gründen und Risiken; außerdem offene/noch unbehandelte Ziele.
- Eine abschließende Selbstkritik: Wo ist der Entwurf am schwächsten, welche
  Alternative ist plausibel, und welche fachliche Prüfung würde entscheiden?

Nutze Lehrwerke oder didaktische Literatur als begründete Orientierung, wenn
du darauf zugreifen kannst. Zitiere die tatsächlich geprüften Quellen und
unterscheide Inhaltsverzeichnis, Lehrtext, Aufgaben und eigene Schlussfolgerungen.
Keine kopierten Aufgaben oder Kapitelgliederungen; Buchreihenfolge ist kein
Voraussetzungsnachweis. Wenn zusätzliche Informationen fehlen, liefere dennoch
die belastbare Teilanalyse und benenne genau, was zur Entscheidung fehlt.
