# Referenzinventar

Geprüfter Quellenstand: `0ce5a8d791eeb9783a919195fd8590bfb79f3595`.
Die Original-IDs werden nur in den beiden exportierten Dateien gesucht, nicht umgeschrieben.
Prüfumfang: `requires`, `contains`, `examData.coveredGoalIds` und `goalPlacements[].goalId`.
Bewertungsschritt-IDs sind keine Lernziel-IDs. Andere Metadaten, Ressourcen,
Programm-/Taxonomie-Referenzen und Links sind nicht Teil dieses begrenzten Audits.

| Fach / Feld | Vorkommen | Im Fach aufgelöst | Im anderen exportierten Fach aufgelöst | Unaufgelöst |
| --- | ---: | ---: | ---: | ---: |
| Mathematik / `requires` | 2460 | 2460 | 0 | 0 |
| Mathematik / `contains` | 1387 | 1387 | 0 | 0 |
| Mathematik / `examData.coveredGoalIds` | 567 | 567 | 0 | 0 |
| Mathematik / `goalPlacements.goalId` | 303 | 303 | 0 | 0 |
| Physik / `requires` | 1686 | 1524 | 162 | 0 |
| Physik / `contains` | 785 | 785 | 0 | 0 |
| Physik / `examData.coveredGoalIds` | 738 | 738 | 0 | 0 |
| Physik / `goalPlacements.goalId` | 19 | 19 | 0 | 0 |

Es gibt in diesen Feldern keine unaufgelösten Ziel-IDs und in den beiden
Dateien keine fehlenden oder doppelten Ziel-IDs. Physik verwendet 162
`requires`-Verweise auf 54 verschiedene Mathematikziele. Das belegt die
vorhandene Verknüpfung, nicht ihre fachliche Notwendigkeit oder die zeitliche
Verfügbarkeit der Mathematik im konkreten Unterricht. Die Auflösung erzeugt
weder Kompetenzanerkennung noch eine neue vollständige Einheitsvoraussetzung.

## Fachübergreifend referenzierte Mathematikziele

Alle Vorkommen mit Quellziel und Feld stehen in [referenzaufloesung.json](referenzaufloesung.json).

| Original-ID | Originaltitel | Verweisvorkommen aus Physik |
| --- | --- | ---: |
| `0a154cbd-1218-4553-835c-a754e9901bba` | Formeln mit Brüchen nach Variablen auflösen | 1 |
| `0a6dab2e-1bbb-5587-adb0-456d3991c327` | Terme mit rationalen Zahlen strukturiert auswerten | 1 |
| `15505229-efec-4d01-8e71-acf15f9c2424` | Arithmetisches Mittel bestimmen und deuten | 2 |
| `19f170e4-b88f-4c06-b72a-ce6923748bb4` | Vektoren im räumlichen Koordinatensystem als Tupel angeben und deuten | 1 |
| `2331caf2-ccb2-5492-9fc6-48763b848bae` | Winkelzeichnungen und Gradmaße ineinander überführen | 1 |
| `25593605-5e13-55cc-9a05-8f3d737e15e9` | Punktlagen und daraus bestimmte lineare Objekte im Koordinatensystem darstellen | 5 |
| `26f668a0-6425-5466-9cf7-6295dd189005` | Potenzen mit rationalen Basen und negativen Exponenten deuten und berechnen | 1 |
| `27b63e2e-6a34-483e-8e5a-fe0f49670d1d` | Wachstums- und Abklingvorgänge exponentiell modellieren und Ergebnisse im Kontext bewerten | 2 |
| `2ac2e902-a6ad-53c9-b139-d1c63d823023` | Skalarprodukt von Vektoren definieren | 1 |
| `2c4830e6-a8d5-48d0-9202-3b7d18a419c2` | Terme im Bereich rationaler Zahlen äquivalent umformen | 2 |
| `2f3d24e7-2450-55d8-97c2-3e106d2854c6` | Achsenspiegelungen konstruieren | 1 |
| `34604a97-0c64-5b06-81e2-6ac818732d60` | Integralterme interpretieren und begründen | 1 |
| `3bf1ce9e-f4d3-502e-9d6e-94f7b7f697d4` | Die natürliche Logarithmusfunktion als Stammfunktion von 1/x nutzen (LK) | 1 |
| `3c1d6ce7-099e-4267-9ff2-3d1526209a89` | Logarithmus definieren und einfache Werte bestimmen | 2 |
| `46bdcc16-418f-417a-89cf-033d7ae6c8cc` | Trigonometrische Graphen und Periodizität deuten | 1 |
| `4b67bed9-06da-40b2-a306-24e9e7dfd390` | Ganze Zahlen addieren | 1 |
| `4d78bbcc-89b8-47f0-aa45-516199e4da5d` | Satz des Pythagoras anwenden | 2 |
| `4eeab7d5-eeb3-579b-845e-1c52ffe9e89f` | Rationale Zahlen addieren und subtrahieren | 13 |
| `54148506-c23f-41b8-959b-068dd194cf15` | Einfache multiplikative Gleichungen unter Bereichsbedingungen lösen | 1 |
| `54541d08-61cc-5a6d-b6d9-d0270a7d1949` | Vektorprodukt definieren (LK) | 1 |
| `571793bd-34f1-539e-969c-dfcc2dfa96b3` | Vektoren mit Skalaren multiplizieren und geometrisch deuten | 3 |
| `58d2f963-4fb9-550d-a832-f5ac60808900` | Transformierte Sinus- und Kosinusfunktionen mit der Kettenregel ableiten | 4 |
| `596345cd-679e-5c7b-955f-e8cb1ec81e96` | Einfache proportionale Sachaufgaben mit Dreisatz lösen | 1 |
| `5d17ebb4-4e27-4f9c-8d0b-3520f34b2e11` | Sinus- und Kosinusfunktionen als periodische Funktionen beschreiben | 1 |
| `6596405a-9728-41df-9163-53670ec2a937` | Potenzgesetze mit ganzzahligen Exponenten anwenden | 3 |
| `71a483ba-9680-4654-bb5e-5ab5427f0919` | Trigonometrie am rechtwinkligen Dreieck anwenden | 4 |
| `71d43fcc-d787-4874-ae4a-2336364e9c0a` | Grundaufgaben der Prozentrechnung lösen | 3 |
| `76478e47-5ff9-5de1-b601-5e6e436ad855` | Bruchterme multiplizieren und dividieren | 1 |
| `7c978529-ce62-5adc-897f-24ea80babbc8` | Volumina von Quadern und Würfeln bestimmen | 1 |
| `7f11ffe0-7c43-4507-9101-50374a60b0e8` | Periodische Realsituationen mit Sinus- und Kosinusfunktionen modellieren und Modelle variieren | 1 |
| `80c232f1-8f72-5829-9dbe-5a610ccab3be` | Achsen, Skalen und Einheiten lesen | 10 |
| `87c55be5-06a9-41e2-a0d4-c60f7c8b8078` | Flächeninhalte ebener Figuren berechnen | 1 |
| `88abc886-cce8-55cf-b86c-eb4ba45a92d7` | Potenzen mit rationalen Exponenten als Wurzel- und Bruchausdrücke deuten | 1 |
| `8d30d241-0247-48ac-83d3-4e0de61584d3` | Bogenmass am Einheitskreis veranschaulichen und sicher zwischen Grad- und Bogenmass wechseln | 3 |
| `91571d3f-3651-4477-ba21-320fc4077453` | Absolute und relative Häufigkeiten bestimmen und darstellen | 1 |
| `9db266a2-1889-5792-82b0-a7463f0832f1` | Exponentialfunktionen in e-Schreibweise umformen | 1 |
| `9f2fc0d1-e1e7-4051-ba70-87ba1dd8dd1c` | Grundlegende Ableitungsregeln auf elementare Funktionsterme anwenden | 1 |
| `a6469c01-6ca3-5eb2-a82c-94f3d0560b32` | Termwerte durch Einsetzen berechnen | 17 |
| `ae20183e-92b5-5521-b8e0-9a8662cf51f5` | Mittlere Änderungsrate berechnen und deuten | 4 |
| `ae5010cc-ea8d-5b14-aa4a-b0f2b5846a75` | Kettenregel beim Ableiten anwenden (LK) | 2 |
| `af3d6bff-c5fb-4ec6-a9f0-c0be09fc9186` | Lineare Funktionen beschreiben | 5 |
| `b1dcc191-d046-50de-984a-ee5c17157628` | Ableitung als Steigung im Punkt deuten | 1 |
| `b9bbd2a8-1379-5ffb-817f-41467d48abef` | Hauptsatz der Differential- und Integralrechnung nutzen | 1 |
| `bbef7cf2-90fa-59fa-a115-8b651aab9231` | Sinus- und Kosinusfunktionen verstehen | 2 |
| `c1f50bcc-7848-4e49-b9de-0ec030cc6bca` | Proportionale Zusammenhänge mit Quotientengleichheit prüfen | 2 |
| `c63bbffd-8d1c-5fe2-a428-db194e6fe592` | Vektoren komponentenweise addieren und subtrahieren | 6 |
| `c8818eae-0c4d-4fa1-9085-04a9c95a668b` | Sinus- und Kosinuswerte am Einheitskreis im Bogenmass deuten und Winkel bestimmen | 2 |
| `ca623958-c204-5d1b-bdd0-3f76765674cb` | Mit Größen einheitengerecht rechnen und Ergebnisse deuten | 1 |
| `cf48c918-f6c1-5429-8da6-14df43f2f550` | Produktregel beim Ableiten anwenden (LK) | 1 |
| `ee48e811-4c9c-5080-9836-8403fc9f0810` | Rationale Zahlen multiplizieren und dividieren | 15 |
| `f08d06dc-139d-5fd2-892c-8cc919b1e4fc` | Terme mit Variablen lesen und deuten | 5 |
| `f2e42af5-67a6-477e-82ea-e65b09cc6cb3` | Größen und Einheiten vergleichen und umrechnen | 4 |
| `f6b13b8e-1ecd-5420-905d-21290aa996a6` | Rationale Zahlen an der Zahlengeraden darstellen und ordnen | 5 |
| `f8704a7b-e93d-4e32-b0f9-1b171545fe28` | Quadratwurzeln definieren und schätzen | 8 |

Die vollständigen Lernzielbedeutungen stehen im Mathematikinventar und im
maßgeblichen JSON. `examData.coveredGoalIds` wird getrennt geprüft; es ist
nicht mit Voraussetzungen gleichzusetzen. Ein technisch auflösbarer Graph
belegt weder Aufgabenqualität noch einen gültigen Anerkennungsvertrag.
