# Lernzielinventar Physik

Quelle: SkillPilot, Commit `0ce5a8d791eeb9783a919195fd8590bfb79f3595`.
Maßgebliche vollständige Datei: [`DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json`](../curricula/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json).
Dieses Inventar enthält alle 766 Ziele in ihrer Originalreihenfolge.
Es gibt die deutschen Titel/Beschreibungen, ursprünglichen `requires`/`contains`,
vorhandene Typkennzeichnungen und vorhandene Einordnungsfelder wieder.
Keine Normalisierung, neue Zieltypzuordnung oder Lerneinheitengrenze wird abgeleitet.
Fehlende Kennzeichnungen werden nicht ergänzt. Weitere Inhalte, insbesondere
`examData`, Aufgaben, Lösungen, Ressourcen, Platzierungen und Herkunft, bleiben
vollständig in der JSON-Datei erhalten. Deren Felder sind für die Prüfung mitzulesen.
`requires` bezeichnet Voraussetzungen und ist kein Beleg für Prüfungsabdeckung.
Die Markierung `Assessment` in `tags` oder ein vorhandener anderer Marker wird
hier nur zitiert; daraus entsteht keine neu vereinheitlichte Typklassifikation.
Die Relationslisten behalten ihre Original-IDs und Reihenfolge; Auflösung siehe
[Referenzinventar](REFERENZEN.md).

Eigenes SkillPilot-Wissensmaterial und dieses abgeleitete Inventar: CC-BY-4.0;
gelieferte Fremdhinweise bleiben maßgeblich. Siehe [Herkunft/Lizenzen](../HERKUNFT-UND-LIZENZEN.md).

## 1. Prüfungsaufgabe: Besetzte Zustände und elektrische Leitfähigkeit

- ID: `71e8936b-fa8a-50dc-8c47-fca015b85ac5`
- Beschreibung: Die lernende Person kann vorgegebene Bändermodelle anhand der Fermienergie und temperaturabhängigen Zustandsbesetzung selbstständig auswerten und daraus begrenzte Aussagen zur elektrischen Leitfähigkeit begründen.
- `requires`: `["658cf33d-a0c2-5d47-801a-3dbcd5cac074"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_fermi_occupation_conductivity","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q4","area":"Klausurtraining"}}`

## 2. Physik

- ID: `bf980fff-b62b-4ea4-a20d-31681a7ad785`
- Beschreibung: Gemeinsame Wurzel für Physik am Gymnasium in Deutschland. Die aktuelle Baseline übernimmt die hessische Oberstufe vollständig und behält die bereits eingeführten expliziten Mathematik-Voraussetzungen im Mechanik-Korridor.
- `requires`: `[]`
- `contains`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f","f08d171d-ac31-59b6-834e-a6a2493b974e","9645f0d8-43a3-5f29-873c-daa5ace638db","051cedc5-d380-4716-9751-b18f2e67a912","2d3d42ae-492b-4795-a22f-eeca03aaed38","84096c02-0767-4725-8956-37ce7e4b9bbf","48fb4a0b-62a0-4c8f-9792-3aeef6316885","41fd5575-b1a6-40e7-8ea2-66b75a597a79","84b1bc70-dadf-449b-a8d4-8bcee1da1fea","4924d83e-5e4b-4819-9d70-86cda3496195","bbabac7c-9613-4c7e-877e-d7dc3df5300f","8917c71a-bfcb-4003-971c-188a69446b60","21ab0854-4d67-5233-9495-ae208e152a3c","942de15b-32f1-5713-80e5-e7aeb8749fc4","0735269d-703d-57ab-8861-6f7e1c5e2b8a","fcefb129-ad4c-50a2-9762-a910caa1af16","5d960c58-f363-5dc1-b012-e6363b4b31cf","5482bc19-3836-51a5-ba98-fbf5e265b908","61684ca7-b725-534f-944b-c7645cea1792","79028c45-90ae-57eb-8016-f5a96af18fa2","a658b54c-94ac-4e9c-93e3-defe1f2508a1","3df08a2c-0dfb-40e5-9605-8baa6259a08e","8eaa4e45-39fc-50e9-b59f-8a1752f6bebe","052a4cc8-2ccd-5cef-b022-55b554417c4a","47dc2c52-b776-5694-9715-ae98c7c23f85"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","root","canonical","subject:physics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_module","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_FELDER","LI_WELLEN","LI_MATERIE","LI_TECHNIK","LI_KOSMOS"],"phase":"GLOBAL"}}`

## 3. Einfache Stossvorgaenge mit Impuls- und Energieerhaltung analysieren

- ID: `2eecd0e2-a7ca-4568-9b12-3d47706c65fb`
- Beschreibung: Die lernende Person kann einfache Stossvorgaenge quantitativ untersuchen, dabei Impuls- und Energieerhaltung fachlich nutzen und die Rolle von Erhaltungssaetzen in der Mechanik erklaeren.
- `requires`: `["839ecc8f-3a60-418b-bc92-64bfeef33824","91c49019-ea51-4ce5-a919-c91c45b25e83","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_simple_collision_processes","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2","PK3"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"phase":"E","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.E2.COLLISIONS.0"}}`

## 4. Mechanische Grundlagen (Sek I)

- ID: `9645f0d8-43a3-5f29-873c-daa5ace638db`
- Beschreibung: Brückencluster für die mechanischen Grundlagen aus der gymnasialen Sekundarstufe I: Volumen, Masse und Dichte, Bewegungsdarstellungen, Kräfte und Trägheit, Kräfteigenschaften, Reibung sowie erste qualitative Arbeit-und-Energie-Vorstellungen.
- `requires`: `[]`
- `contains`: `["e41356c1-968b-435a-af25-b663f080ae5a","ae67bcf1-f3ee-50d6-9a12-25a159dff659","5ea765ac-c279-551a-8a94-a07da2381e5b","10bb8262-fb0f-40cf-94ef-408420ec7cf2","581c0766-b84b-54cb-b8b6-375310329a41","cd4fe3f9-a04d-4dcc-9c0b-db214daa72ba","9c328f68-41ed-55dd-9e02-34414a6246f2"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_mechanics_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS"}}`

## 5. Lichtausbreitung und Reflexion (Sek I)

- ID: `051cedc5-d380-4716-9751-b18f2e67a912`
- Beschreibung: Brückencluster für optische Sek-I-Grundlagen zu Licht, Schatten, Strahlenmodell und Reflexion.
- `requires`: `[]`
- `contains`: `["dd7cdcea-0950-461b-96ac-ce49989fca47","79cb1695-f985-443a-b93e-27b57ab474b7","cca06d84-28fe-4b80-9bcd-968dda026e0e","1fede37b-6554-5dd3-93d9-08ed1fd09c91","9a9e2085-5ab6-534f-b622-83774d51f36b"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_light_reflection_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.LIGHT"}}`

## 6. Wärmelehre und Teilchenmodell (Sek I)

- ID: `2d3d42ae-492b-4795-a22f-eeca03aaed38`
- Beschreibung: Brückencluster für Temperatur, Wärme, Ausdehnung, Teilchenmodell und Wärmeausbreitung in der gymnasialen Sekundarstufe I.
- `requires`: `[]`
- `contains`: `["940978fa-1f2d-4e54-9c28-081a6df9b76f","d27c8860-12a4-4d7d-9849-ccd8b7caca48","9ac4973a-21d5-48a5-90b4-eb90e10391ae","fbe0faae-7fba-482b-888e-341f926770f3","5a3716dd-ec67-5c48-ba3d-1a29f05ba2ce","5be98160-5189-58aa-8183-1df1c400cc8c","873c6371-4ffb-582b-8d8d-3f45f968ba08"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_heat_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.HEAT"}}`

## 7. Temperatur und Wärme unterscheiden

- ID: `940978fa-1f2d-4e54-9c28-081a6df9b76f`
- Beschreibung: Die lernende Person kann Temperatur als messbare Zustandsgröße von Wärme als Energieübertragung aufgrund eines Temperaturunterschieds und vom subjektiven Wärmeempfinden unterscheiden.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_temperature_heat","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.HEAT.TEMPERATURE"}}`

## 8. Temperaturmessung und thermische Ausdehnung

- ID: `d27c8860-12a4-4d7d-9849-ccd8b7caca48`
- Beschreibung: Cluster für die fachlich getrennten Lernziele zur Temperaturmessung und zur thermischen Ausdehnung von Stoffen.
- `requires`: `[]`
- `contains`: `["51de4fd9-6827-5b3d-b2ca-5e27ba961a7f","b60f63b6-e70b-5557-9f54-86d42fa80325"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_temperature_expansion","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.HEAT.EXPANSION"}}`

## 9. Temperatur mit einem geeigneten Thermometer messen

- ID: `51de4fd9-6827-5b3d-b2ca-5e27ba961a7f`
- Beschreibung: Die lernende Person kann für einen gegebenen Messbereich und die benötigte Auflösung ein geeignetes Thermometer auswählen, es in guten thermischen Kontakt mit dem Messobjekt bringen und einen stabilen Temperaturwert mit Einheit fachgerecht ablesen.
- `requires`: `["940978fa-1f2d-4e54-9c28-081a6df9b76f","f6b13b8e-1ecd-5420-905d-21290aa996a6"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_measure_temperature","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.HEAT.TEMPERATURE_MEASUREMENT"}}`

## 10. Thermische Ausdehnung fester, flüssiger und gasförmiger Stoffe deuten

- ID: `b60f63b6-e70b-5557-9f54-86d42fa80325`
- Beschreibung: Die lernende Person kann aus vergleichenden Beobachtungen erklären, dass sich Länge oder Volumen fester, flüssiger und gasförmiger Stoffe beim Erwärmen meist vergrößern und beim Abkühlen verkleinern, sofern eine Ausdehnung nicht durch starre Begrenzung verhindert wird, und Unterschiede qualitativ deuten.
- `requires`: `["940978fa-1f2d-4e54-9c28-081a6df9b76f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_thermal_expansion","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.HEAT.THERMAL_EXPANSION"}}`

## 11. Teilchenmodell für Temperaturänderungen nutzen

- ID: `9ac4973a-21d5-48a5-90b4-eb90e10391ae`
- Beschreibung: Die lernende Person kann im einfachen Teilchenmodell Temperaturänderungen qualitativ mit Veränderungen der mittleren ungeordneten Teilchenbewegung erklären und das Modell auf einfache Wärmeübertragungsvorgänge innerhalb oder zwischen Stoffen anwenden.
- `requires`: `["940978fa-1f2d-4e54-9c28-081a6df9b76f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_particle_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.HEAT.PARTICLE_MODEL"}}`

## 12. Wärmeleitung, Konvektion und Wärmestrahlung unterscheiden

- ID: `fbe0faae-7fba-482b-888e-341f926770f3`
- Beschreibung: Die lernende Person kann Wärmeleitung als Energieübertragung ohne makroskopischen Stofftransport, Konvektion als Übertragung durch strömende Flüssigkeiten oder Gase und Wärmestrahlung als elektromagnetische Übertragung auch ohne Materie unterscheiden und Alltagsbeispiele begründet zuordnen.
- `requires`: `["9ac4973a-21d5-48a5-90b4-eb90e10391ae"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_heat_transfer","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.HEAT.TRANSFER"}}`

## 13. Druck und Auftrieb (Sek I)

- ID: `84096c02-0767-4725-8956-37ce7e4b9bbf`
- Beschreibung: Brückencluster für fakultative Druck- und Auftriebsgrundlagen der gymnasialen Sekundarstufe I: Druck in Flüssigkeiten und Gasen, qualitative Druck-Temperatur-Zusammenhänge, das Archimedische Prinzip sowie erste Deutungen von Auftrieb an Tragflächen und Luftwiderstand.
- `requires`: `[]`
- `contains`: `["5308de76-79f0-44f4-8cb7-fc9de4772217","310b4f62-e261-46be-bb1b-1f125fc1699a","e11b2ee9-e528-4857-9ecd-59bd460fba81","24b4686a-e8a6-4583-8952-33e6f653c2a3"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_pressure_buoyancy_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Druck und Auftrieb","topicCode":"CANONICAL.PHYSICS.SEK1.FLUIDS"}}`

## 14. Druck in Flüssigkeiten und Gasen qualitativ beschreiben

- ID: `5308de76-79f0-44f4-8cb7-fc9de4772217`
- Beschreibung: Die lernende Person kann Druck als Kraft pro Fläche qualitativ beschreiben und Beispiele für Druck in Flüssigkeiten und Gasen fachlich zuordnen.
- `requires`: `["5ea765ac-c279-551a-8a94-a07da2381e5b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_pressure_fluids_gases","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Druck und Auftrieb","topicCode":"CANONICAL.PHYSICS.SEK1.FLUIDS.PRESSURE"}}`

## 15. Druck-Temperatur-Zusammenhang bei konstantem Volumen qualitativ erklären

- ID: `310b4f62-e261-46be-bb1b-1f125fc1699a`
- Beschreibung: Die lernende Person kann für eine eingeschlossene Gasmenge bei konstantem Volumen mithilfe des Teilchenmodells qualitativ erklären, warum der Druck bei steigender Temperatur zunimmt und bei sinkender Temperatur abnimmt.
- `requires`: `["5308de76-79f0-44f4-8cb7-fc9de4772217","940978fa-1f2d-4e54-9c28-081a6df9b76f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_pressure_temperature","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"GLOBAL","area":"Druck und Auftrieb","topicCode":"CANONICAL.PHYSICS.SEK1.FLUIDS.PRESSURE_TEMPERATURE"}}`

## 16. Auftrieb mit dem archimedischen Prinzip erklären

- ID: `e11b2ee9-e528-4857-9ecd-59bd460fba81`
- Beschreibung: Die lernende Person kann Auftrieb in Wasser und Luft mithilfe des archimedischen Prinzips qualitativ erklären.
- `requires`: `["5308de76-79f0-44f4-8cb7-fc9de4772217","f92b5b8a-327f-50d2-8313-6a142399ebf0","c2d6bdf1-8077-50fb-a8b5-2f0b7e3493f0"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_buoyancy_archimedes","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_MATERIE"],"phase":"GLOBAL","area":"Druck und Auftrieb","topicCode":"CANONICAL.PHYSICS.SEK1.FLUIDS.BUOYANCY"}}`

## 17. Auftrieb an Tragflächen und Luftwiderstand qualitativ einordnen

- ID: `24b4686a-e8a6-4583-8952-33e6f653c2a3`
- Beschreibung: Die lernende Person kann Auftrieb an Tragflächen und Luftwiderstand qualitativ beschreiben und in einfachen Anwendungssituationen einordnen.
- `requires`: `["e11b2ee9-e528-4857-9ecd-59bd460fba81"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_flight_air_resistance","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"GLOBAL","area":"Druck und Auftrieb","topicCode":"CANONICAL.PHYSICS.SEK1.FLUIDS.FLIGHT"}}`

## 18. Magnetismus und einfache Stromkreise (Sek I)

- ID: `4924d83e-5e4b-4819-9d70-86cda3496195`
- Beschreibung: Brückencluster für magnetische Grundphänomene, einfache Stromkreise, qualitative Stromwirkungen und erste Stromstärkemessungen.
- `requires`: `[]`
- `contains`: `["f778a659-1467-4aa7-97b2-bed78c530634","75bdf5ca-cda4-4658-9ec7-84c77b3759db","a5f652cc-e091-4c90-bec2-c357ae54fcf1","f1a078ae-6262-4444-a4bc-a5ab275621cf"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_magnetism_electricity_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY"}}`

## 19. Spannung, Schaltungen und Sicherheit (Sek I)

- ID: `bbabac7c-9613-4c7e-877e-d7dc3df5300f`
- Beschreibung: Brückencluster für statische Elektrizität, Spannung, Strom-Spannungs-Zusammenhänge, Schaltungen mit Widerständen und Sicherheitsbewertungen.
- `requires`: `[]`
- `contains`: `["32111497-d5ca-453e-906d-d352f885b126","53196a71-9dbd-4835-b2f9-ff21b8a8962c","01bebdfc-5819-4610-a03e-ea5e794fc954","8a84de16-2fde-58ec-827a-f803e2ce8564","267170bd-f880-56a7-9719-ffb9751872c5","8f833b36-4126-52db-b210-79fb0023c7d9","1911920e-b099-4310-82f2-b47f51a78b33","baa2bf3c-798a-5ec3-a667-031bf062d96c","59d1145e-ac54-5917-880a-21b4b80526d3","ec5cac7b-ad31-590c-8ab0-5b3ef24d2bca","50431e92-eec9-54d6-b437-ea7a51b6f474","0dd1e39c-8557-5a4e-b467-caae964fff67"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_voltage_safety_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.VOLTAGE"}}`

## 20. Farben und Farbmischung (Sek I)

- ID: `48fb4a0b-62a0-4c8f-9792-3aeef6316885`
- Beschreibung: Brückencluster für fakultative farbbezogene Grundlagen der gymnasialen Sekundarstufe I: Entstehung von Farben, additive und subtraktive Farbmischung, einfache Farbwahrnehmung sowie technische Anwendungen.
- `requires`: `[]`
- `contains`: `["a4681378-ade4-4f20-bf77-fb020469510f","cdab9fd1-5054-4a7e-8c9a-4474062ddd23","1c8dd14c-0fbf-44a5-85a3-25c8e3bd0075","cc9eea77-2a7f-4f35-ac22-6c230c0d6fa5"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_colors_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Farben","topicCode":"CANONICAL.PHYSICS.SEK1.COLORS"}}`

## 21. Entstehung und Zerlegung von Farben erklären

- ID: `a4681378-ade4-4f20-bf77-fb020469510f`
- Beschreibung: Die lernende Person kann den Unterschied zwischen der räumlichen Aufspaltung weißen Lichts in Spektralfarben durch unterschiedlich starke Brechung im Prisma und der zeitlichen Integration rasch wechselnder Farbeindrücke zu einem annähernd weißen Gesamteindruck bei einem schnell rotierenden Farbkreis erklären.
- `requires`: `["dd7cdcea-0950-461b-96ac-ce49989fca47"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_color_origin","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"GLOBAL","area":"Farben","topicCode":"CANONICAL.PHYSICS.SEK1.COLORS.ORIGIN"}}`

## 22. Additive und subtraktive Farbmischung unterscheiden

- ID: `cdab9fd1-5054-4a7e-8c9a-4474062ddd23`
- Beschreibung: Die lernende Person kann additive Farbmischung durch Überlagerung von Licht und subtraktive Farbmischung durch selektive Absorption von Licht unterscheiden und beide an einfachen Beispielen anwenden.
- `requires`: `["a4681378-ade4-4f20-bf77-fb020469510f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_color_mixing","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Farben","topicCode":"CANONICAL.PHYSICS.SEK1.COLORS.MIXING"}}`

## 23. Einfache Farbwahrnehmung beschreiben

- ID: `1c8dd14c-0fbf-44a5-85a3-25c8e3bd0075`
- Beschreibung: Die lernende Person kann Alltagserfahrungen zur Farbwahrnehmung fachlich beschreiben, indem sie erläutert, wie Beleuchtung und Oberfläche das ins Auge gelangende Licht und damit den Farbeindruck bestimmen.
- `requires`: `["cdab9fd1-5054-4a7e-8c9a-4474062ddd23"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_color_perception","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"GLOBAL","area":"Farben","topicCode":"CANONICAL.PHYSICS.SEK1.COLORS.PERCEPTION"}}`

## 24. Farben in technischen Anwendungen erklären

- ID: `cc9eea77-2a7f-4f35-ac22-6c230c0d6fa5`
- Beschreibung: Die lernende Person kann fachlich erklären, wie Farben auf Bildschirmen durch additive und im Farbdruck durch subtraktive Farbmischung entstehen.
- `requires`: `["cdab9fd1-5054-4a7e-8c9a-4474062ddd23"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_colors_in_technology","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Farben","topicCode":"CANONICAL.PHYSICS.SEK1.COLORS.TECH"}}`

## 25. Akustische Grundlagen (Sek I)

- ID: `41fd5575-b1a6-40e7-8ea2-66b75a597a79`
- Beschreibung: Brückencluster für fakultative akustische Grundlagen der gymnasialen Sekundarstufe I: Schallquellen, Schallausbreitung, Tonhöhe und Lautstärke, Hören und Lärm sowie erste Musik- und Klangphänomene.
- `requires`: `[]`
- `contains`: `["c1006f55-0406-48cc-92d4-0d8345897cf4","3c82510a-1f12-4eaa-81c2-8599437a5b85","a24c41ce-68c5-56a7-8235-ef9a7dba7042","10aad90e-a1db-42b6-8d1e-1d856e14b47d","3e33813d-db75-4571-8345-3845b02b956d","e62e48bc-2387-4b2b-8d6f-7a06c8e7580e"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_acoustics_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK","LI_MATERIE"],"phase":"GLOBAL","area":"Akustik","topicCode":"CANONICAL.PHYSICS.SEK1.ACOUSTICS"}}`

## 26. Schallquellen und Schallempfänger beschreiben

- ID: `c1006f55-0406-48cc-92d4-0d8345897cf4`
- Beschreibung: Die lernende Person kann Schallquellen und Schallempfänger an Beispielen nach ihrer Funktion unterscheiden und erklären, wie eine schwingende Quelle Schall erzeugt und ankommender Schall am Empfänger eine mechanische Reaktion oder ein weiterverarbeitbares Signal hervorruft.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_sound_sources_receivers","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"GLOBAL","area":"Akustik","topicCode":"CANONICAL.PHYSICS.SEK1.ACOUSTICS.SOURCES"}}`

## 27. Schallausbreitung im Teilchenmodell erklären

- ID: `3c82510a-1f12-4eaa-81c2-8599437a5b85`
- Beschreibung: Die lernende Person kann Schallausbreitung im Teilchen- beziehungsweise Medienelementmodell als Weitergabe einer lokalen Druck- oder Verformungsstörung und von Energie erklären, die Bewegung von Teilchen beziehungsweise kleinen Medienelementen um einen Gleichgewichtszustand deuten und begründen, warum im betrachteten idealisierten Wellenmodell kein dauerhafter Nettostofftransport mit dem Schall durch das Medium erfolgt.
- `requires`: `["c1006f55-0406-48cc-92d4-0d8345897cf4","9ac4973a-21d5-48a5-90b4-eb90e10391ae"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_sound_propagation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"GLOBAL","area":"Akustik","topicCode":"CANONICAL.PHYSICS.SEK1.ACOUSTICS.PROPAGATION"}}`

## 28. Schallgeschwindigkeiten in verschiedenen Medien vergleichen und begründen

- ID: `a24c41ce-68c5-56a7-8235-ef9a7dba7042`
- Beschreibung: Die lernende Person kann Schallgeschwindigkeiten in verschiedenen Medien anhand von Daten vergleichen, Unterschiede mit elastischer Kopplung und Trägheit im Teilchenmodell begründen und eine vorschnelle Rangfolge allein nach Aggregatzuständen prüfen.
- `requires`: `["3c82510a-1f12-4eaa-81c2-8599437a5b85","f6b13b8e-1ecd-5420-905d-21290aa996a6"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_sound_speed_media","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"GLOBAL","area":"Akustik","topicCode":"CANONICAL.PHYSICS.SEK1.ACOUSTICS.SPEED_MEDIA"}}`

## 29. Tonhöhe, Lautstärke und Geräusche unterscheiden

- ID: `10aad90e-a1db-42b6-8d1e-1d856e14b47d`
- Beschreibung: Die lernende Person kann Töne von Geräuschen anhand einfacher Schwingungsdarstellungen unterscheiden sowie Tonhöhe und Lautstärke als verschiedene Merkmale beschreiben und mit Frequenz beziehungsweise – unter vergleichbaren Bedingungen – Amplitude in Beziehung setzen.
- `requires`: `["3c82510a-1f12-4eaa-81c2-8599437a5b85","80c232f1-8f72-5829-9dbe-5a610ccab3be"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_sound_characterization","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"GLOBAL","area":"Akustik","topicCode":"CANONICAL.PHYSICS.SEK1.ACOUSTICS.CHARACTERIZE"}}`

## 30. Hören, Ohr und Lärmbelastung einordnen

- ID: `3e33813d-db75-4571-8345-3845b02b956d`
- Beschreibung: Die lernende Person kann den Aufbau des Ohrs qualitativ erläutern und Auswirkungen von Lärm fachlich beurteilen.
- `requires`: `[]`
- `contains`: `["2a6ad2c6-3e1b-57a9-82a1-e6620a532f5c","da0837c7-95a7-5a6a-81db-f33cb7f42d85"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_hearing_noise","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Akustik","topicCode":"CANONICAL.PHYSICS.SEK1.ACOUSTICS.HEARING"}}`

## 31. Hörvorgang im Ohr qualitativ erklären

- ID: `2a6ad2c6-3e1b-57a9-82a1-e6620a532f5c`
- Beschreibung: Die lernende Person kann qualitativ erklären, wie das Außenohr Schall zum Trommelfell leitet, Trommelfell und Gehörknöchelchen die mechanische Schwingung auf das Innenohr übertragen und Sinneszellen in der Cochlea die mechanische Anregung in Nervensignale umwandeln.
- `requires`: `["3c82510a-1f12-4eaa-81c2-8599437a5b85"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_explain_hearing_process_in_ear","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"GLOBAL","area":"Akustik","topicCode":"CANONICAL.PHYSICS.SEK1.ACOUSTICS.HEARING.PROCESS"}}`

## 32. Lärmbelastung des Gehörs beurteilen

- ID: `da0837c7-95a7-5a6a-81db-f33cb7f42d85`
- Beschreibung: Die lernende Person kann in konkreten Lärmsituationen die Gefährdung des Gehörs aus dem Zusammenwirken von Schallpegel und Einwirkdauer beurteilen sowie die Wirksamkeit von Schutzmaßnahmen und mögliche Folgen begründen.
- `requires`: `["10aad90e-a1db-42b6-8d1e-1d856e14b47d","2a6ad2c6-3e1b-57a9-82a1-e6620a532f5c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assess_hearing_noise_exposure","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Akustik","topicCode":"CANONICAL.PHYSICS.SEK1.ACOUSTICS.HEARING.NOISE_EXPOSURE"}}`

## 33. Schallphänomene an Musikinstrumenten beschreiben

- ID: `e62e48bc-2387-4b2b-8d6f-7a06c8e7580e`
- Beschreibung: Die lernende Person kann an einfachen Bauprinzipien von Musikinstrumenten erklären, wie schwingende Saiten, Membranen oder Luftsäulen Schall erzeugen und wie Änderungen am schwingenden System, an der Anregung oder an einem Resonanzkörper Tonhöhe, Lautstärke oder Klangfarbe beeinflussen.
- `requires`: `["10aad90e-a1db-42b6-8d1e-1d856e14b47d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_sound_music","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Akustik","topicCode":"CANONICAL.PHYSICS.SEK1.ACOUSTICS.MUSIC"}}`

## 34. Optische Grundlagen (Sek I)

- ID: `84b1bc70-dadf-449b-a8d4-8bcee1da1fea`
- Beschreibung: Brückencluster für optische Sek-I-Grundlagen: Linsenabbildung, Sehvorgang und einfache optische Instrumente.
- `requires`: `[]`
- `contains`: `["078ce4d2-3193-4cd0-ae59-4fb8ab16e9e5","90e1e6cf-4092-41d6-81f7-5206f9d68f84","6367d45e-919e-4c19-bcd9-7770a2d51139","6a4c6042-052b-502b-a39a-0ed8941247ac","1ab5f599-0927-579d-94cc-feecdf3b5603","71b51afd-c71b-506f-8128-d6de36b509d1"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_optics_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS"}}`

## 35. Atomaufbau und Radioaktivität (Sek I)

- ID: `8917c71a-bfcb-4003-971c-188a69446b60`
- Beschreibung: Brückencluster für atomare Grundvorstellungen, radioaktive Strahlung und erste Anwendungen bzw. Bewertungen in der gymnasialen Sekundarstufe I.
- `requires`: `[]`
- `contains`: `["2a6703e0-2a6f-4ebf-a5c6-7aa05a4b86eb","f74c691b-0b76-54e0-8fd6-a22211994e0a","f6f646db-3544-49ed-8f55-67bc684e80ce","979e0d0d-8933-4ace-814f-f28060ad280f","cb0426b0-a973-5660-b6fe-79407934730f","50877233-7abf-54df-b347-6d3224678fc9"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_radioactivity_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR"}}`

## 36. Nuklidschreibweise deuten und Isotope unterscheiden

- ID: `f74c691b-0b76-54e0-8fd6-a22211994e0a`
- Beschreibung: Die lernende Person kann aus der Nuklidschreibweise mit Massenzahl A und Protonenzahl Z die Protonen- und Neutronenzahl eines Atomkerns bestimmen und Isotope als Kerne desselben Elements mit gleicher Protonen-, aber unterschiedlicher Neutronenzahl begründet unterscheiden.
- `requires`: `["2a6703e0-2a6f-4ebf-a5c6-7aa05a4b86eb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_interpret_nuclide_notation_and_isotopes","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.NUCLIDE_NOTATION_ISOTOPES"}}`

## 37. Kern und Hülle des Atoms qualitativ beschreiben

- ID: `2a6703e0-2a6f-4ebf-a5c6-7aa05a4b86eb`
- Beschreibung: Die lernende Person kann Kern und Elektronenhülle als Bestandteile eines Atommodells beschreiben und die Größenordnungen von Atom- und Kerndurchmesser vergleichen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f","6596405a-9728-41df-9163-53670ec2a937"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_atomic_structure","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.ATOM"}}`

## 38. Nachweis und biologische Wirkungen ionisierender Strahlung

- ID: `f6f646db-3544-49ed-8f55-67bc684e80ce`
- Beschreibung: Bündelt den kontrollierten Nachweis ionisierender Strahlung mit geeigneten Detektoren und die physikalisch begründete Einordnung ihrer biologischen Wirkungen und grundlegender Schutzmaßnahmen bei äußerer Exposition.
- `requires`: `[]`
- `contains`: `["25d91cc0-d84c-5522-86b5-fdff73264f08","861ba00a-e89c-5b3d-8c76-8ff0bcb0f1cd"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_radioactivity_detection","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.RADIATION"}}`

## 39. Ionisierende Strahlung mit geeigneten Detektoren nachweisen

- ID: `25d91cc0-d84c-5522-86b5-fdff73264f08`
- Beschreibung: Die lernende Person kann das Nachweisprinzip eines geeigneten Detektors erklären, das beobachtete Signal von der daraus erschlossenen ionisierenden Strahlung unterscheiden und den Nachweis mit einer Hintergrund- oder Kontrollmessung absichern.
- `requires`: `["2a6703e0-2a6f-4ebf-a5c6-7aa05a4b86eb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_detect_ionising_radiation_with_detectors","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.RADIATION.DETECTION"}}`

## 40. Biologische Wirkungen ionisierender Strahlung einordnen

- ID: `861ba00a-e89c-5b3d-8c76-8ff0bcb0f1cd`
- Beschreibung: Die lernende Person kann die mögliche Schädigung biologischen Gewebes durch ionisierende Strahlung über Ionisation erklären und bei äußerer Exposition grundlegende Schutzmaßnahmen anhand von Expositionszeit, Abstand und Abschirmung begründen.
- `requires`: `["2a6703e0-2a6f-4ebf-a5c6-7aa05a4b86eb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_classify_biological_effects_ionising_radiation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.RADIATION.BIOLOGICAL_EFFECTS"}}`

## 41. Anwendungen und Risiken radioaktiver Strahlung beurteilen

- ID: `979e0d0d-8933-4ace-814f-f28060ad280f`
- Beschreibung: Die lernende Person kann bei einem konkreten Einsatz ionisierender Strahlung oder radioaktiver Stoffe in Medizin, Materialprüfung oder Kerntechnik Nutzen, Strahlenrisiken und Schutzmaßnahmen anhand physikalischer Wirkungen, Einsatzbedingungen und benannter Bewertungskriterien qualitativ abwägen.
- `requires`: `["861ba00a-e89c-5b3d-8c76-8ff0bcb0f1cd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_radioactivity_applications","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK","LI_ENERGIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.APPLICATIONS"}}`

## 42. Licht, Schatten und geradlinige Ausbreitung beschreiben

- ID: `dd7cdcea-0950-461b-96ac-ce49989fca47`
- Beschreibung: Die lernende Person kann Beobachtungen zu Licht und Schatten mit der geradlinigen Ausbreitung von Licht in einem homogenen transparenten Medium und der Geometrie von Lichtquelle, Objekt und Schirm fachlich beschreiben.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_light_shadow_propagation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.PROPAGATION"}}`

## 43. Lichtwege mit dem Strahlenmodell darstellen und vorhersagen

- ID: `79cb1695-f985-443a-b93e-27b57ab474b7`
- Beschreibung: Die lernende Person kann Lichtwege in einfachen optischen Anordnungen als gerichtete Linien des Strahlenmodells darstellen und aus den für die Anordnung geltenden Ausbreitungsregeln weitere Wegabschnitte vorhersagen.
- `requires`: `["dd7cdcea-0950-461b-96ac-ce49989fca47","2f3d24e7-2450-55d8-97c2-3e106d2854c6"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_ray_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.RAYS"}}`

## 44. Reflexion untersuchen und Spiegelbilder deuten

- ID: `cca06d84-28fe-4b80-9bcd-968dda026e0e`
- Beschreibung: Die lernende Person kann Reflexion an glatten Flächen untersuchen, das Reflexionsgesetz anwenden und Spiegelbilder deuten.
- `requires`: `[]`
- `contains`: `["3c8e5510-a12d-5770-8a01-e5fe741b259c","b57427c9-1af5-5daa-8c65-b84a4cc20785"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_reflection","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.REFLECTION"}}`

## 45. Reflexionsgesetz experimentell prüfen

- ID: `3c8e5510-a12d-5770-8a01-e5fe741b259c`
- Beschreibung: Die lernende Person kann bei der Reflexion an einer ebenen glatten Fläche Einfalls- und Reflexionswinkel jeweils zum Lot messen, die Messwerte samt Ablese- und Ausrichtungsunsicherheiten vergleichen, daraus das Reflexionsgesetz formulieren und beurteilen, ob Abweichungen mit diesen Unsicherheiten vereinbar sind.
- `requires`: `["79cb1695-f985-443a-b93e-27b57ab474b7","2331caf2-ccb2-5492-9fc6-48763b848bae"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_test_law_of_reflection_experimentally","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.REFLECTION.LAW_EXPERIMENT"}}`

## 46. Spiegelbilder am ebenen Spiegel mit dem Strahlenmodell erklären

- ID: `b57427c9-1af5-5daa-8c65-b84a4cc20785`
- Beschreibung: Die lernende Person kann reflektierte Lichtwege rückwärts verlängern, damit Lage und Größe des virtuellen Bildes am ebenen Spiegel konstruieren und erklären, warum das Bild hinter dem Spiegel erscheint und nicht auf einem Schirm aufgefangen werden kann.
- `requires`: `["3c8e5510-a12d-5770-8a01-e5fe741b259c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_model_plane_mirror_image_with_rays","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.REFLECTION.PLANE_MIRROR_IMAGE"}}`

## 47. Statische Elektrizität, Spannung und Kondensatoren

- ID: `32111497-d5ca-453e-906d-d352f885b126`
- Beschreibung: Bündelt Kompetenzen zur elektrostatischen Ladungstrennung, zur Spannungsmessung in einfachen Stromkreisen und zur Deutung des Kondensators als System getrennter Gegenladungen.
- `requires`: `[]`
- `contains`: `["dc7dd287-6eac-574d-818d-65cfb23a2d94","28237994-9c24-5a06-82fe-be1f494768ba","80dd0a2b-1422-5b00-89ff-ec4d0faa047e"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_static_electricity_voltage","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.VOLTAGE.STATIC"}}`

## 48. Elektrostatische Aufladung durch Ladungsumverteilung erklären

- ID: `dc7dd287-6eac-574d-818d-65cfb23a2d94`
- Beschreibung: Die lernende Person kann in einfachen elektrostatischen Situationen mit einem Ladungsmodell erklären, wie positive und negative Ladungen getrennt oder ausgeglichen werden, ohne dass elektrische Gesamtladung erzeugt oder vernichtet wird.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_explain_electrostatic_charge_separation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_MATERIE"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.ELECTROSTATICS.CHARGE_SEPARATION"}}`

## 49. Spannung in einfachen Stromkreisen messen

- ID: `28237994-9c24-5a06-82fe-be1f494768ba`
- Beschreibung: Die lernende Person kann ein Voltmeter parallel zwischen zwei Punkten eines einfachen Kleinspannungsstromkreises mit geeignetem Messbereich anschließen, die Spannung mit Einheit messen und erläutern, auf welches Punktepaar sich der Messwert bezieht.
- `requires`: `["69f8f59c-b0c3-5b0b-82db-834a0e655736","f6b13b8e-1ecd-5420-905d-21290aa996a6"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_measure_voltage_in_simple_circuits","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.VOLTAGE.MEASUREMENT"}}`

## 50. Einen Kondensator als System getrennter Ladungen deuten

- ID: `80dd0a2b-1422-5b00-89ff-ec4d0faa047e`
- Beschreibung: Die lernende Person kann einen geladenen Kondensator als zwei voneinander isolierte Leiter mit getrennten entgegengesetzten Ladungen deuten und bei vertauschter Polung die veränderte Ladungsverteilung vorhersagen.
- `requires`: `["dc7dd287-6eac-574d-818d-65cfb23a2d94"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_interpret_capacitor_charge_separation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.CAPACITOR.CHARGE_SEPARATION"}}`

## 51. Zusammenhang von Spannung und Stromstärke qualitativ erläutern

- ID: `53196a71-9dbd-4835-b2f9-ff21b8a8962c`
- Beschreibung: Die lernende Person kann die Stromstärke durch und die Spannung an einem einfachen Bauteil messen und anhand zusammengehöriger Messwertpaare bei unveränderten Bedingungen ihren qualitativen Zusammenhang erläutern.
- `requires`: `["f1a078ae-6262-4444-a4bc-a5ab275621cf","28237994-9c24-5a06-82fe-be1f494768ba","25593605-5e13-55cc-9a05-8f3d737e15e9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_voltage_current_relation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.VOLTAGE.RELATION"}}`

## 52. Reihen- und Parallelschaltungen für eine Funktion planen

- ID: `01bebdfc-5819-4610-a03e-ea5e794fc954`
- Beschreibung: Die lernende Person kann für eine vorgegebene Funktion einen Schaltplan als Reihen- oder Parallelschaltung entwerfen und die Wahl anhand der benötigten Stromwege begründen.
- `requires`: `["53196a71-9dbd-4835-b2f9-ff21b8a8962c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_resistor_circuits","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.CIRCUITS.PLAN"}}`

## 53. Strombilanzen an Knoten mit Ladungserhaltung begründen

- ID: `8a84de16-2fde-58ec-827a-f803e2ce8564`
- Beschreibung: Die lernende Person kann an Knoten einfacher Schaltungen im stationären Zustand Stromrichtungen festlegen, Strombilanzen aufstellen, unbekannte Stromstärken bestimmen oder prüfen und die Knotenregel mit der Ladungserhaltung begründen, wenn sich am Knoten keine Ladung ansammelt.
- `requires`: `["01bebdfc-5819-4610-a03e-ea5e794fc954","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_junction_current_balance","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.CIRCUITS.CURRENT_BALANCE"}}`

## 54. Spannungsbilanzen in Maschen mit Energieerhaltung begründen

- ID: `267170bd-f880-56a7-9719-ffb9751872c5`
- Beschreibung: Die lernende Person kann in Maschen einfacher Schaltungen im stationären Zustand eine Umlaufrichtung festlegen, vorzeichenrichtige Spannungsbilanzen aufstellen, unbekannte Spannungen bestimmen oder prüfen und die Maschenregel damit begründen, dass die zugeführte und an Bauteile übertragene Energie pro Ladung bei einem vollständigen Umlauf bilanziert ist.
- `requires`: `["01bebdfc-5819-4610-a03e-ea5e794fc954","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_loop_voltage_balance","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.CIRCUITS.VOLTAGE_BALANCE"}}`

## 55. Widerstandswirkungen in Reihen- und Parallelschaltungen deuten

- ID: `8f833b36-4126-52db-b210-79fb0023c7d9`
- Beschreibung: Die lernende Person kann bei konstanter Quellenspannung vorhersagen und begründen, wie das Hinzufügen, Entfernen oder Ändern eines Widerstands in einer Reihen- oder Parallelschaltung den Gesamtwiderstand und die Stromstärken beeinflusst, und die Vorhersage an einem Grenzfall prüfen.
- `requires`: `["8a84de16-2fde-58ec-827a-f803e2ce8564","267170bd-f880-56a7-9719-ffb9751872c5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_series_parallel_resistance_effects","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.CIRCUITS.RESISTANCE_EFFECTS"}}`

## 56. Elektrische Anlagen, Gewitter und Haushaltsstromkreise sicher beurteilen

- ID: `1911920e-b099-4310-82f2-b47f51a78b33`
- Beschreibung: Bündelt das Beurteilen von Gefahren elektrischer Anlagen und Haushaltsstromkreise sowie das Erklären elektrischer Vorgänge und sicheren Verhaltens bei Gewittern.
- `requires`: `[]`
- `contains`: `["5ddba212-9e0a-5dd4-8274-239ec51ab6a8","c156d2fb-0fe9-5f13-8baa-3e74d7da151e"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_electrical_safety","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.SAFETY"}}`

## 57. Gefahren elektrischer Anlagen und Haushaltsstromkreise sicher beurteilen

- ID: `5ddba212-9e0a-5dd4-8274-239ec51ab6a8`
- Beschreibung: Die lernende Person kann Gefahren elektrischer Anlagen und Haushaltsstromkreise anhand möglicher Stromwege und der Wirkung von Schutzmaßnahmen erläutern und sichere Handlungen begründet beurteilen.
- `requires`: `["53196a71-9dbd-4835-b2f9-ff21b8a8962c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assess_electrical_system_household_circuit_hazards","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.SAFETY.INSTALLATIONS_HOUSEHOLD"}}`

## 58. Elektrische Vorgänge und sicheres Verhalten bei Gewittern erklären

- ID: `c156d2fb-0fe9-5f13-8baa-3e74d7da151e`
- Beschreibung: Die lernende Person kann elektrische Vorgänge bei Gewittern qualitativ erklären und sichere Verhaltensregeln anhand des Blitzrisikos begründen.
- `requires`: `["dc7dd287-6eac-574d-818d-65cfb23a2d94"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_explain_thunderstorm_electricity_safe_behavior","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.SAFETY.THUNDERSTORMS"}}`

## 59. Magnete, Pole und magnetische Kräfte qualitativ beschreiben

- ID: `f778a659-1467-4aa7-97b2-bed78c530634`
- Beschreibung: Die lernende Person kann Anziehung und Abstoßung zwischen Magnetpolen qualitativ beschreiben und einfache magnetische Phänomene mit dem Modell der Elementarmagnete erklären.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_magnets_fields","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.MAGNETS"}}`

## 60. Leitfähigkeit, Stromkreise und Schaltpläne

- ID: `75bdf5ca-cda4-4658-9ec7-84c77b3759db`
- Beschreibung: Bündelt das Prüfen elektrischer Leitfähigkeit, den Aufbau offener und geschlossener Stromkreise und die Übersetzung zwischen realem Aufbau und Schaltplan.
- `requires`: `[]`
- `contains`: `["7ca44ba0-b77e-52bf-8562-f67b44767172","69f8f59c-b0c3-5b0b-82db-834a0e655736","baa2bf3c-798a-5ec3-a667-031bf062d96c"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_simple_circuits","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.CIRCUITS"}}`

## 61. Offene und geschlossene Stromkreise aufbauen und deuten

- ID: `7ca44ba0-b77e-52bf-8562-f67b44767172`
- Beschreibung: Die lernende Person kann mit einer sicheren Kleinspannungsquelle einfache offene und geschlossene Stromkreise aufbauen und anhand des durchgehenden leitfähigen Weges begründen, ob ein angeschlossener Verbraucher wirken kann.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_build_interpret_open_closed_circuits","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.CIRCUITS.OPEN_CLOSED"}}`

## 62. Zwischen Stromkreis und Schaltplan übersetzen

- ID: `69f8f59c-b0c3-5b0b-82db-834a0e655736`
- Beschreibung: Die lernende Person kann einen einfachen realen Stromkreis mit fachüblichen Schaltsymbolen als Schaltplan darstellen, einen vorgegebenen Schaltplan als Aufbau umsetzen und erklären, dass der Plan elektrische Verbindungen statt räumlicher Anordnung codiert.
- `requires`: `["7ca44ba0-b77e-52bf-8562-f67b44767172"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_translate_circuit_setup_diagram","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.CIRCUITS.DIAGRAM_TRANSLATION"}}`

## 63. Wirkungen des elektrischen Stroms qualitativ beschreiben

- ID: `a5f652cc-e091-4c90-bec2-c357ae54fcf1`
- Beschreibung: Die lernende Person kann magnetische, Licht-, Wärme- und chemische Wirkungen des elektrischen Stroms qualitativ beschreiben.
- `requires`: `["7ca44ba0-b77e-52bf-8562-f67b44767172"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_current_effects","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_ENERGIE","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.EFFECTS"}}`

## 64. Stromstärke in einfachen Stromkreisen messen

- ID: `f1a078ae-6262-4444-a4bc-a5ab275621cf`
- Beschreibung: Die lernende Person kann ein Amperemeter in einem einfachen Stromkreis in Reihe anschließen, einen geeigneten Messbereich wählen und die Stromstärke bestimmen sowie den Messwert mit Einheit angeben.
- `requires`: `["69f8f59c-b0c3-5b0b-82db-834a0e655736","f6b13b8e-1ecd-5420-905d-21290aa996a6"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_current_measurement","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.CURRENT"}}`

## 65. Masse, Volumen und Dichte

- ID: `e41356c1-968b-435a-af25-b663f080ae5a`
- Beschreibung: Cluster für die fachlich getrennten Lernziele zum Messen und Vergleichen von Masse, zum Bestimmen und Vergleichen von Volumen sowie zum Bestimmen und Deuten von Dichte.
- `requires`: `[]`
- `contains`: `["af0e2efb-f634-5f2d-abea-b2e1a67a2894","7c996528-5fae-5353-b8fb-d59382e225c6","c2d6bdf1-8077-50fb-a8b5-2f0b7e3493f0"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_density_mass_volume","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE","LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.DENSITY"}}`

## 66. Masse von Körpern messen und vergleichen

- ID: `af0e2efb-f634-5f2d-abea-b2e1a67a2894`
- Beschreibung: Die lernende Person kann für Messbereich und benötigte Auflösung eine geeignete Waage auswählen, ihren Nullpunkt kontrollieren, die Masse eines Körpers messen und mit Einheit und angemessener Genauigkeit angeben sowie Massen vergleichen, ohne Form oder Volumen eines Körpers mit seiner Masse gleichzusetzen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f","f6b13b8e-1ecd-5420-905d-21290aa996a6"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_measure_compare_mass","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.MASS"}}`

## 67. Volumen von Körpern bestimmen und vergleichen

- ID: `7c996528-5fae-5353-b8fb-d59382e225c6`
- Beschreibung: Die lernende Person kann das Volumen regelmäßiger Körper aus Abmessungen und das Volumen unregelmäßiger Körper durch Flüssigkeitsverdrängung bestimmen, Messwerte mit Einheit angeben und vergleichen.
- `requires`: `[]`
- `contains`: `["f827b00f-af7f-52de-84aa-2a2bbaa035bd","f92b5b8a-327f-50d2-8313-6a142399ebf0"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_determine_compare_volume","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.VOLUME"}}`

## 68. Volumen regelmäßiger Körper geometrisch bestimmen

- ID: `f827b00f-af7f-52de-84aa-2a2bbaa035bd`
- Beschreibung: Die lernende Person kann die benötigten Abmessungen eines einfachen regelmäßigen Körpers messen, daraus sein Volumen mit einer passenden geometrischen Beziehung bestimmen und Ergebnis sowie Volumeneinheit auf Plausibilität prüfen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f","7c978529-ce62-5adc-897f-24ea80babbc8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_determine_regular_body_volume_geometrically","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.VOLUME.GEOMETRIC"}}`

## 69. Volumen unregelmäßiger Körper durch Flüssigkeitsverdrängung bestimmen

- ID: `f92b5b8a-327f-50d2-8313-6a142399ebf0`
- Beschreibung: Die lernende Person kann das Volumen eines vollständig eintauchbaren unregelmäßigen festen Körpers aus dem Flüssigkeitsstand vor und nach dem Eintauchen bestimmen, die Differenz mit passender Volumeneinheit angeben und Ablese- oder Luftblasenfehler beurteilen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_determine_irregular_body_volume_by_displacement","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.VOLUME.DISPLACEMENT"}}`

## 70. Dichte aus Masse und Volumen bestimmen und deuten

- ID: `c2d6bdf1-8077-50fb-a8b5-2f0b7e3493f0`
- Beschreibung: Die lernende Person kann Dichte als Quotient aus Masse und Volumen bestimmen, passende Einheiten verwenden und Dichtewerte nutzen, um Stoffe oder gleich große beziehungsweise gleich schwere Körper zu vergleichen.
- `requires`: `["af0e2efb-f634-5f2d-abea-b2e1a67a2894","f827b00f-af7f-52de-84aa-2a2bbaa035bd","f92b5b8a-327f-50d2-8313-6a142399ebf0","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_derive_interpret_density","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.DENSITY"}}`

## 71. Linsenabbildungen qualitativ beschreiben und konstruieren

- ID: `078ce4d2-3193-4cd0-ae59-4fb8ab16e9e5`
- Beschreibung: Die lernende Person kann im vereinfachten Strahlenmodell die Wirkung von Konvex- und Konkavlinsen mithilfe von Brennpunkten und Brennweite beschreiben, einfache Bildkonstruktionen durchführen und daraus Bildlage, Bildorientierung, Bildgröße und die reelle oder virtuelle Bildart qualitativ deuten.
- `requires`: `["79cb1695-f985-443a-b93e-27b57ab474b7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_lens_imaging","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.LENSES"}}`

## 72. Sehvorgang und Fehlsichtigkeiten qualitativ erklären

- ID: `90e1e6cf-4092-41d6-81f7-5206f9d68f84`
- Beschreibung: Die lernende Person kann mit einem qualitativen Linsenmodell erklären, wie im Auge ein scharfes Bild auf der Netzhaut entsteht und wie eine unpassende Brechkraft oder Augenlänge bei Kurz- und Weitsichtigkeit die Bildlage relativ zur Netzhaut verändert.
- `requires`: `["078ce4d2-3193-4cd0-ae59-4fb8ab16e9e5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_vision","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.VISION"}}`

## 73. Einfache optische Instrumente beschreiben

- ID: `6367d45e-919e-4c19-bcd9-7770a2d51139`
- Beschreibung: Die lernende Person kann bei einem einfachen Fernrohr oder Mikroskop den Strahlenverlauf durch Objektiv und Okular im jeweiligen Modell deuten und erklären, wie der Aufbau die Beobachtung ermöglicht.
- `requires`: `["90e1e6cf-4092-41d6-81f7-5206f9d68f84"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_optical_instruments","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.INSTRUMENTS"}}`

## 74. Bewegungen mit Weg-Zeit-Diagrammen beschreiben

- ID: `ae67bcf1-f3ee-50d6-9a12-25a159dff659`
- Beschreibung: Die lernende Person kann in Weg-Zeit-Diagrammen Ruhe, gleichförmige Bewegung und qualitative Geschwindigkeitsänderungen anhand des Verlaufs und seiner Steigung unterscheiden und passende Bewegungen beschreiben.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f","80c232f1-8f72-5829-9dbe-5a610ccab3be"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_motion_diagrams","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.MOTION"}}`

## 75. Kräfte und Trägheit qualitativ erklären

- ID: `5ea765ac-c279-551a-8a94-a07da2381e5b`
- Beschreibung: Die lernende Person kann Bewegungsänderungen auf eine resultierende Kraft zurückführen und mit dem Trägheitsprinzip erklären, warum ein Körper bei verschwindender resultierender Kraft seinen Bewegungszustand beibehält.
- `requires`: `["ae67bcf1-f3ee-50d6-9a12-25a159dff659"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_forces_inertia","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.FORCES"}}`

## 76. Kräfteigenschaften untersuchen

- ID: `10bb8262-fb0f-40cf-94ef-408420ec7cf2`
- Beschreibung: Cluster für die fachlich getrennten Lernziele zur vektoriellen Zusammensetzung von Kräften, zur Bedeutung von Angriffspunkt, Wirkungslinie und Schwerpunkt sowie zum experimentellen Zusammenhang zwischen Kraft und elastischer Verformung.
- `requires`: `[]`
- `contains`: `["41d35667-0296-5f84-bc12-202ffc440be0","67ffd0f0-a5ab-518f-8c45-4c0e7eb18390","45bbdf6b-6372-5b6a-b7e4-be15a0eb4b83"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_force_properties","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.FORCE_PROPERTIES"}}`

## 77. Kräfte vektoriell zusammensetzen und Resultierende bestimmen

- ID: `41d35667-0296-5f84-bc12-202ffc440be0`
- Beschreibung: Die lernende Person kann mehrere an einem Körper angreifende Kräfte maßstäblich als Vektoren darstellen, grafisch zu einer resultierenden Kraft zusammensetzen und deren Betrag und Richtung im Kontext deuten.
- `requires`: `["5ea765ac-c279-551a-8a94-a07da2381e5b","596345cd-679e-5c7b-955f-e8cb1ec81e96"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_force_composition_resultant","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.FORCE_RESULTANT"}}`

## 78. Angriffspunkt, Wirkungslinie und Schwerpunkt deuten

- ID: `67ffd0f0-a5ab-518f-8c45-4c0e7eb18390`
- Beschreibung: Die lernende Person kann an starren Körpern Angriffspunkt und Wirkungslinie einer Kraft kennzeichnen, in einem näherungsweise homogenen Gravitationsfeld die Gewichtskraft als am Schwerpunkt angreifend modellieren und daraus qualitative Folgen für Gleichgewicht oder Drehwirkung ableiten.
- `requires`: `["5ea765ac-c279-551a-8a94-a07da2381e5b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_force_line_of_action_center_of_gravity","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.FORCE_LINE_OF_ACTION"}}`

## 79. Reibung als Kontaktkraft deuten

- ID: `581c0766-b84b-54cb-b8b6-375310329a41`
- Beschreibung: Die lernende Person kann Reibung als Kontaktkraft deuten, die einer relativen oder drohenden Bewegung zwischen Kontaktflächen entgegenwirkt, und erklären, wie sie etwa beim Gehen die Fortbewegung ermöglicht oder eine Relativbewegung abbremst.
- `requires`: `["5ea765ac-c279-551a-8a94-a07da2381e5b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_friction","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.FRICTION"}}`

## 80. Arbeit und Energie qualitativ deuten

- ID: `cd4fe3f9-a04d-4dcc-9c0b-db214daa72ba`
- Beschreibung: Brückencluster für qualitative Sek-I-Vorstellungen zu Arbeit, einfachen Maschinen, mechanischen und elektrischen Energieformen sowie Wärmeübertragung und Energiebilanzen.
- `requires`: `[]`
- `contains`: `["327302e3-5b36-46f8-9c16-73f24583b0eb","722857cf-f327-5740-8151-64eb92195ec8","eeba6bf8-a2b9-4d7d-a1d6-67286c923cef","cbb26ed2-6979-46f6-a4ae-128f5c5d9d76","30a936ec-e427-57fe-bf3e-4abd64b1f0c1","201d353a-dfe7-521b-b0f6-eccb4d42945b","46e42b07-c098-5d65-8ef5-8472b7c4d8e2"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_work_energy_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.WORK_ENERGY"}}`

## 81. Arbeit und einfache Maschinen qualitativ deuten

- ID: `327302e3-5b36-46f8-9c16-73f24583b0eb`
- Beschreibung: Die lernende Person kann einfache Maschinen wie Hebel, Rollen und Räder als Kraftwandler beschreiben und erklären, warum eine kleinere Kraft idealerweise mit einem längeren Weg verbunden ist, ohne mechanische Arbeit einzusparen.
- `requires`: `["41d35667-0296-5f84-bc12-202ffc440be0","67ffd0f0-a5ab-518f-8c45-4c0e7eb18390","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_work_simple_machines","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.WORK"}}`

## 82. Mechanische Energieformen qualitativ unterscheiden

- ID: `722857cf-f327-5740-8151-64eb92195ec8`
- Beschreibung: Die lernende Person kann mechanische Energieformen wie Bewegungs-, Lage- und Spannenergie anhand des Zustands eines Systems unterscheiden und bei einfachen Vorgängen qualitativ beschreiben, welche Energieform ab- und welche zunimmt.
- `requires`: `["5ea765ac-c279-551a-8a94-a07da2381e5b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_energy_forms","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.ENERGY"}}`

## 83. Wärmeübertragung und Energiebilanzen qualitativ erklären

- ID: `eeba6bf8-a2b9-4d7d-a1d6-67286c923cef`
- Beschreibung: Die lernende Person kann Wärme als Energieübertragung aufgrund eines Temperaturunterschieds von gespeicherter innerer Energie und mechanischer Arbeit unterscheiden, ein betrachtetes System abgrenzen und einfache Energiebilanzen qualitativ erläutern.
- `requires`: `["722857cf-f327-5740-8151-64eb92195ec8","940978fa-1f2d-4e54-9c28-081a6df9b76f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_heat_energy","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.HEAT"}}`

## 84. Elektrische Energieumwandlungen qualitativ beschreiben

- ID: `cbb26ed2-6979-46f6-a4ae-128f5c5d9d76`
- Beschreibung: Die lernende Person kann elektrische Energieumwandlungen beschreiben und einfache Anwendungen qualitativ bewerten.
- `requires`: `["722857cf-f327-5740-8151-64eb92195ec8","53196a71-9dbd-4835-b2f9-ff21b8a8962c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_electrical_energy","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.ELECTRICAL_ENERGY"}}`

## 85. Freier Fall experimentell untersuchen

- ID: `230345f3-c360-4963-b390-ab94e3e2c864`
- Beschreibung: Cluster zur experimentellen Untersuchung des freien Falls.
- `requires`: `[]`
- `contains`: `["e4b38061-1f28-43ad-8371-a3e7c0e81856","09029573-864f-40ca-bf8a-cee7bf6dcb73"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_free_fall","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 86. Newtons 3. Axiom (Wechselwirkungsprinzip)

- ID: `5a1b3cb2-c0e6-4372-9c57-f33675cffc9b`
- Beschreibung: Cluster zur Formulierung und Anwendung des Wechselwirkungsprinzips.
- `requires`: `[]`
- `contains`: `["ad984bb6-e225-432a-952d-d83cda40b7f8","a0aaedcb-41f8-4891-af77-a69a76b8c10d"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_third_law","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 87. Warum Physik? – Weltverständnis & Zukunft

- ID: `5c44b9ba-9b05-4774-95d5-073230d3fc4f`
- Beschreibung: Der 'Big Picture'-Einstieg: Warum das Smartphone funktioniert, wie Ärzte ohne Skalpell in den Körper schauen (MRT), warum Sterne leuchten und wie wir die Energiekrise lösen. Überblick über die Relevanz der Themenfelder von der Mechanik bis zur Quantenphysik für dein Leben. Hier geht es um Orientierung und Interesse; fachliches Detailwissen wird weder vorausgesetzt noch geprüft.
- `requires`: `[]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticKind":"orientation","tags":["GK","LK","Motivation","Orientation","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_why","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE","LI_TECHNIK","LI_KOSMOS"],"basicConcepts":["KONZEPT_SYSTEM","KONZEPT_ENERGIE"],"phase":"E"}}`

## 88. Methode: Messunsicherheit und Fehleranalyse

- ID: `0dd6d3f9-a92f-564c-a730-6772619c7bf8`
- Beschreibung: Cluster der Basiskompetenzen zur Fehleranalyse: Fehlerarten unterscheiden, Unsicherheiten angeben, signifikante Stellen anwenden und Messreihen auswerten.
- `requires`: `[]`
- `contains`: `["8aff7aac-321b-5172-ac55-877876bfd2cd","f6b1d812-ce8b-5852-b417-e6c29b533c7a","b615830a-e8b0-5754-81e0-99da98343a8d","f23fdfa9-38b6-5157-8301-ed302476c456"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_MATERIE"],"phase":"E"}}`

## 89. Messabweichungen und Fehlerarten unterscheiden

- ID: `8aff7aac-321b-5172-ac55-877876bfd2cd`
- Beschreibung: Die lernende Person kann Messabweichungen systematisch erfassen und systematische von zufälligen Fehlern unterscheiden.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_MATERIE"],"phase":"E"}}`

## 90. Messunsicherheiten angeben

- ID: `f6b1d812-ce8b-5852-b417-e6c29b533c7a`
- Beschreibung: Die lernende Person kann Messwerte mit geeigneten Unsicherheiten angeben und die Angabe fachgerecht notieren.
- `requires`: `["8aff7aac-321b-5172-ac55-877876bfd2cd","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_MATERIE"],"phase":"E"}}`

## 91. Signifikante Stellen korrekt verwenden

- ID: `b615830a-e8b0-5754-81e0-99da98343a8d`
- Beschreibung: Die lernende Person kann Rechenergebnisse passend zur angegebenen Genauigkeit beziehungsweise Unsicherheit der Eingangsdaten auf eine sinnvolle Zahl signifikanter Stellen runden, Zwischenwerte mit ausreichender Genauigkeit weiterführen und Scheingenauigkeit vermeiden.
- `requires`: `["f6b1d812-ce8b-5852-b417-e6c29b533c7a","0a6dab2e-1bbb-5587-adb0-456d3991c327"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_MATERIE"],"phase":"E"}}`

## 92. Mittelwert und Streuung aus Messreihen bestimmen

- ID: `f23fdfa9-38b6-5157-8301-ed302476c456`
- Beschreibung: Die lernende Person kann aus einer Messreihe Mittelwerte bestimmen und die Streuung zur qualitativen Unsicherheitsbewertung nutzen.
- `requires`: `["f6b1d812-ce8b-5852-b417-e6c29b533c7a","15505229-efec-4d01-8e71-acf15f9c2424"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_MATERIE"],"phase":"E"}}`

## 93. Methode: Linearisierung von Messkurven

- ID: `264dc31c-ec92-5e39-a8b8-16f1d74366d4`
- Beschreibung: Die lernende Person kann nichtlineare Messdaten durch geeignete Transformationen linearisieren, Geraden anpassen und Parameter deuten (z. B. $s\sim t^2$, Einstein-Gerade).
- `requires`: `["f6b1d812-ce8b-5852-b417-e6c29b533c7a","f23fdfa9-38b6-5157-8301-ed302476c456","54148506-c23f-41b8-959b-068dd194cf15","a6469c01-6ca3-5eb2-a82c-94f3d0560b32","af3d6bff-c5fb-4ec6-a9f0-c0be09fc9186","f8704a7b-e93d-4e32-b0f9-1b171545fe28"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_MATERIE"],"phase":"E"}}`

## 94. Methode: Digitale Messwerterfassung & Analyse

- ID: `e452baa3-c9fc-5b62-893c-f91fe8d53715`
- Beschreibung: Cluster zur digitalen Messpraxis: Verfahren vergleichen, Messdaten erfassen und inklusive Unsicherheiten auswerten.
- `requires`: `[]`
- `contains`: `["75b9ca4c-178e-5df2-adc4-f7f78e9d28e5","691c11d0-fa6a-5d2e-a19c-086e89c3c233","72effc66-87f4-5f5e-8d36-1547677365fb"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","Method","Measurement"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 95. Digitale und analoge Messverfahren vergleichen

- ID: `75b9ca4c-178e-5df2-adc4-f7f78e9d28e5`
- Beschreibung: Die lernende Person kann digitale und analoge Messverfahren in Bezug auf Einsatzbereich, Auflösung und typische Fehlerquellen vergleichen.
- `requires`: `["8aff7aac-321b-5172-ac55-877876bfd2cd","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method","Measurement"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 96. Digitale Messdaten mit Sensoren erfassen

- ID: `691c11d0-fa6a-5d2e-a19c-086e89c3c233`
- Beschreibung: Die lernende Person kann mit digitalen Sensoren Messdaten strukturiert erfassen und für die Auswertung bereitstellen.
- `requires`: `["75b9ca4c-178e-5df2-adc4-f7f78e9d28e5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method","Measurement"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 97. Digitale Messdaten auswerten und Unsicherheiten berücksichtigen

- ID: `72effc66-87f4-5f5e-8d36-1547677365fb`
- Beschreibung: Die lernende Person kann digitale Messdaten auswerten, zufällige Streuung von systematischen Abweichungen unterscheiden und begründen, wie beide die Aussagekraft des Ergebnisses begrenzen.
- `requires`: `["691c11d0-fa6a-5d2e-a19c-086e89c3c233","8aff7aac-321b-5172-ac55-877876bfd2cd","f6b1d812-ce8b-5852-b417-e6c29b533c7a","f23fdfa9-38b6-5157-8301-ed302476c456"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method","Measurement"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 98. Methoden in der E-Phase

- ID: `1e9ec823-384b-5e5f-974c-4ce224d05c19`
- Beschreibung: Bündelt die methodischen Kompetenzen der Einführungsphase: Messen, Auswerten, Modellieren und Analysieren von Daten.
- `requires`: `[]`
- `contains`: `["0dd6d3f9-a92f-564c-a730-6772619c7bf8","264dc31c-ec92-5e39-a8b8-16f1d74366d4","e452baa3-c9fc-5b62-893c-f91fe8d53715","d67502e3-5e0a-595b-a24b-65b1c40de36e","ac25ffe3-fd42-592d-a937-79cc13460313"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_MATERIE"],"phase":"E"}}`

## 99. Einführungsphase: Mechanik, Gravitation, Thermodynamik und Drehbewegungen

- ID: `942de15b-32f1-5713-80e5-e7aeb8749fc4`
- Beschreibung: Grundlagen der E-Phase entlang der KC-Themenfelder E.1 bis E.7: von Bewegungsanalyse und Newton-Mechanik über Gravitation bis zu Thermodynamik und Drehbewegungen.
- `requires`: `[]`
- `contains`: `["65ddd780-0323-45d1-8f94-5e31bf28da23","9340e894-bb0d-45a4-91f2-b90a63ad50a8","287739a3-6143-55d0-abe7-1a08889e9b49","04d1d2df-a94b-5db4-8d07-cbb512c2e0b9","0ade0d10-8b32-5a95-a1a9-8ac64e2a8089","df11eb33-4900-52bf-93b3-eb82ff0f9a28","9743baad-9371-52b6-98ee-72bc6dc68701","1e9ec823-384b-5e5f-974c-4ce224d05c19","9f2f5ab8-0ae4-5792-b831-82a05af5895c","424b07df-bf66-5d7f-99f5-f28b32ad1f22"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"basicConcepts":["KONZEPT_ERHALTUNG_GLEICHGEWICHT","KONZEPT_MATHEMATISIEREN"],"phase":"E"}}`

## 100. Lernkarten - E-Phase

- ID: `9f2f5ab8-0ae4-5792-b831-82a05af5895c`
- Beschreibung: Die lernende Person kann zentrale Fachbegriffe und Definitionen der E-Phase mithilfe von Lernkarten sicher abrufen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","nodeKind":"memory","tags":["GK","LK","srs-deck:de_gymnasium_physics_mechanics_ephase","memorization"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"phase":"E"}}`

## 101. Übungen E-Phase

- ID: `424b07df-bf66-5d7f-99f5-f28b32ad1f22`
- Beschreibung: Bündelt materialgebundene Übungsaufgaben auf Abitur-Niveau zur selbstständigen Bearbeitung für die Themen der Einführungsphase Mechanik; GK ist abiturorientiert auf AB2, LK abiturorientiert auf AB3 angelegt.
- `requires`: `[]`
- `contains`: `["a9562b05-c54d-5635-9244-3f7dd24a8642","22561c66-3957-5d55-b07a-25de1f359930","72649cf5-893c-5f03-88bd-a2497171d434","5773ccbe-cd20-5ba0-99a5-7ccd5f42be51","2b9e565f-d9b4-5e23-b5b7-b7977cecff06","8320bb17-e6ab-50ea-a965-aa331bfd33e1","1b432223-3d59-5586-86a9-2214b4844101","879491c0-7153-570b-91f4-c61d9fe8a143","0432a422-401b-5134-bf08-05cfd8c7a366","dd99528a-bae5-5b78-89e6-c6092c927f8d","7c0b94b9-2af7-59d4-bfae-278a3418f6a8","be6d4895-65ab-545b-8df9-84e5a308a5e3","7e0308d8-a239-5c0f-b2c0-724f21e4da60","8a1d4093-9832-5010-b1ca-9d32d8c05afa","6ba2e47f-7e88-5d30-8f1a-3f4b4f785ca1","6d25344c-35d7-5853-925d-2bccbaf50630","7f83e25c-38f7-5ac2-8f9c-ec54eeef1026","4ab1cf6d-b808-5b86-9291-85df0b9f2496","6ea3fb3c-abdc-568f-ab13-97c36dc274e4"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_MATERIE","LI_TECHNIK","LI_KOSMOS"],"phase":"E"}}`

## 102. Bewegungsanalyse und freier Fall

- ID: `a9562b05-c54d-5635-9244-3f7dd24a8642`
- Beschreibung: E.1 Bewegungen und freier Fall, 25 BE.
- `requires`: `["ce431132-dfc4-42c2-aff6-bd72035190f8","e4b38061-1f28-43ad-8371-a3e7c0e81856","09029573-864f-40ca-bf8a-cee7bf6dcb73","4a2bf015-052b-4af0-aed7-324259fa1a8a","ac25ffe3-fd42-592d-a937-79cc13460313","230345f3-c360-4963-b390-ab94e3e2c864"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"E"}}`

## 103. Newtonsche Axiome und Kräftebilanz

- ID: `22561c66-3957-5d55-b07a-25de1f359930`
- Beschreibung: E.2 Kräfte, Reibung und Dynamik, 25 BE.
- `requires`: `["5f289cdc-fda1-4058-b44f-041ba1398e79","5fd45dbc-0eb1-591b-99a9-7386336f1456","a0aaedcb-41f8-4891-af77-a69a76b8c10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"phase":"E"}}`

## 104. Energie, Impuls und Stöße

- ID: `72649cf5-893c-5f03-88bd-a2497171d434`
- Beschreibung: E.2 Erhaltungssätze in mechanischen Kontexten, 25 BE.
- `requires`: `["7eeff2de-6015-49a6-a96e-a488d886dc9f","839ecc8f-3a60-418b-bc92-64bfeef33824","0da13365-02c2-44f1-8a81-d524ca0ac3ae","d30fd37b-1f05-44e3-a40a-4c5a88fa28c2","e790de73-f8e5-4027-bc05-9f12a0e8c9cb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_TECHNIK"],"phase":"E"}}`

## 105. Kreisbewegung, Gravitation und Gasmodell

- ID: `5773ccbe-cd20-5ba0-99a5-7ccd5f42be51`
- Beschreibung: E.3/E.4/E.5 vernetzte Aufgaben, 25 BE.
- `requires`: `["accb1d9e-cd48-5983-bcef-9b9bca4a9114","e2da5eec-45de-5527-9ad7-16f41cacbe58","eb0ffdea-c12d-56df-b7e8-c0297d2f8aff","60211ac1-cbe1-5182-87ef-673a068c5b0a","cd1903a5-d70a-5320-9124-b6b24917ba14","fb73c94b-6a23-5351-8fef-db2c2533e361"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_KOSMOS"],"phase":"E"}}`

## 106. Mehrphasenbewegung und Modellprüfung

- ID: `2b9e565f-d9b4-5e23-b5b7-b7977cecff06`
- Beschreibung: E.1/E.2 datenbasierte Modellierung, 30 BE.
- `requires`: `["ce431132-dfc4-42c2-aff6-bd72035190f8","e4b38061-1f28-43ad-8371-a3e7c0e81856","68c90ba6-c438-463c-9a53-cf61062d416a","89a8cf15-7ba4-46c1-b1dc-fd161b20d9c2","f6b1d812-ce8b-5852-b417-e6c29b533c7a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"E"}}`

## 107. Überhöhte Kurve und Grenzgeschwindigkeiten

- ID: `8320bb17-e6ab-50ea-a965-aa331bfd33e1`
- Beschreibung: E.3 vertiefte Modellierung von Kurvenfahrten auf der Rennstrecke, 30 BE.
- `requires`: `["5f289cdc-fda1-4058-b44f-041ba1398e79","5fd45dbc-0eb1-591b-99a9-7386336f1456","e918b31f-6f39-5dee-ade6-3617080fb24f","accb1d9e-cd48-5983-bcef-9b9bca4a9114","e2da5eec-45de-5527-9ad7-16f41cacbe58"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"phase":"E"}}`

## 108. Orbitaldynamik und Energiebilanz

- ID: `1b432223-3d59-5586-86a9-2214b4844101`
- Beschreibung: E.4 Gravitation mit erweiterten Rechnungen, 30 BE.
- `requires`: `["ec7a0a68-730b-5c94-ac72-a937508f8303","accb1d9e-cd48-5983-bcef-9b9bca4a9114","eb0ffdea-c12d-56df-b7e8-c0297d2f8aff","a42f91a4-0d21-5aa9-ae11-f48be6f2e431","60211ac1-cbe1-5182-87ef-673a068c5b0a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_KOSMOS"],"phase":"E"}}`

## 109. Thermodynamik und Rotationssystem

- ID: `879491c0-7153-570b-91f4-c61d9fe8a143`
- Beschreibung: E.5/E.6 gekoppelte Energiebetrachtungen, 30 BE.
- `requires`: `["5f17e992-fd07-56ee-80a0-567f45bbd10c","18058384-a1bc-5ba2-8f5d-1fe9498acbf0","642aebd7-66cd-5a50-b543-73c4b207525d","cd1903a5-d70a-5320-9124-b6b24917ba14","fb73c94b-6a23-5351-8fef-db2c2533e361","7982cd8e-2151-59e7-858d-c1361c5d249e","93ece389-78c5-5141-9ef1-c68bd558306e","23c5382a-4b0f-5715-84b5-cf87b8323152","73b5af24-7750-520a-bb16-43136ce19a5c","5a951a0b-fd6c-51a1-9ffb-2a34ed6d3931","c2c3cdc5-3e87-47c4-89fd-4eb2c5c2f2ea"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_BEWEGUNG","LI_TECHNIK"],"phase":"E"}}`

## 110. E.1 Bewegungen und ihre Beschreibung

- ID: `65ddd780-0323-45d1-8f94-5e31bf28da23`
- Beschreibung: Cluster für grundlegende Bewegungsarten: Untersuchung von Bewegungen mit t-s-, t-v- und t-a-Diagrammen, gleichförmige und gleichmäßig beschleunigte Bewegungen sowie freier Fall und Modellbildung.
- `requires`: `[]`
- `contains`: `["ce431132-dfc4-42c2-aff6-bd72035190f8","971beafa-6ba5-4c82-ac8b-7ebf66eec3dd","bf8517a9-142b-5789-826a-767f3b277998","e4b38061-1f28-43ad-8371-a3e7c0e81856","09029573-864f-40ca-bf8a-cee7bf6dcb73","d6dc0e02-831d-4894-a61a-852bcc74f147","4a2bf015-052b-4af0-aed7-324259fa1a8a","230345f3-c360-4963-b390-ab94e3e2c864"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","area:Mechanik","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_motion_corridor","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 111. Sportphysik: Bewegungsoptimierung

- ID: `56c629b5-d0d9-5309-aeae-808dc60f8dbb`
- Beschreibung: Cluster zur Sportphysik: Bewegungsanalyse und physikalisch begründete Optimierung in Alltagssport-Kontexten.
- `requires`: `[]`
- `contains`: `["7ead007f-e85a-5cb5-b52d-76aae626119a","e39c83b0-cb4f-5454-a143-b9a159c99cba"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 112. Bewegungsabläufe im Sport qualitativ analysieren

- ID: `7ead007f-e85a-5cb5-b52d-76aae626119a`
- Beschreibung: Die lernende Person kann Bewegungsabläufe in Sportsituationen qualitativ beschreiben und relevante Einflussgrößen benennen.
- `requires`: `["d6dc0e02-831d-4894-a61a-852bcc74f147"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 113. Optimierungen in Sportsituationen physikalisch begründen

- ID: `e39c83b0-cb4f-5454-a143-b9a159c99cba`
- Beschreibung: Die lernende Person kann Optimierungsvorschläge für Sportsituationen fachlich begründen und auf einfache Modelle stützen.
- `requires`: `["7ead007f-e85a-5cb5-b52d-76aae626119a","91c49019-ea51-4ce5-a919-c91c45b25e83"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 114. Physik im Straßenverkehr: Sicherheitsabstände bewerten

- ID: `4a2bf015-052b-4af0-aed7-324259fa1a8a`
- Beschreibung: Die lernende Person kann Reaktions- und Bremswege qualitativ und mithilfe einfacher Modelle beurteilen und daraus Sicherheitsabstände in Alltagssituationen bewerten.
- `requires`: `["e4b38061-1f28-43ad-8371-a3e7c0e81856","71d43fcc-d787-4874-ae4a-2336364e9c0a","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context","canonical","context:traffic","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_traffic_safety","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 115. Bewegungen mit Videoanalyse untersuchen

- ID: `d67502e3-5e0a-595b-a24b-65b1c40de36e`
- Beschreibung: Die lernende Person kann ein Bewegungsvideo räumlich und zeitlich kalibrieren, daraus Orts-Zeit-Daten sowie s(t)- und v(t)-Diagramme gewinnen und Modelle einer gleichförmigen oder geworfenen Bewegung unter Berücksichtigung der Messunsicherheit prüfen.
- `requires`: `["75b9ca4c-178e-5df2-adc4-f7f78e9d28e5","691c11d0-fa6a-5d2e-a19c-086e89c3c233","f6b1d812-ce8b-5852-b417-e6c29b533c7a","f23fdfa9-38b6-5157-8301-ed302476c456","25593605-5e13-55cc-9a05-8f3d737e15e9","ae20183e-92b5-5521-b8e0-9a8662cf51f5","af3d6bff-c5fb-4ec6-a9f0-c0be09fc9186"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 116. Bewegungen mit Diagrammen untersuchen

- ID: `ce431132-dfc4-42c2-aff6-bd72035190f8`
- Beschreibung: Die lernende Person kann einfache Bewegungen experimentell erfassen und in t-s-, t-v- und t-a-Diagrammen darstellen und interpretieren.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f","ae67bcf1-f3ee-50d6-9a12-25a159dff659","87c55be5-06a9-41e2-a0d4-c60f7c8b8078","ae20183e-92b5-5521-b8e0-9a8662cf51f5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_motion_diagrams","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 117. Gleichförmige Bewegung und Geschwindigkeit

- ID: `971beafa-6ba5-4c82-ac8b-7ebf66eec3dd`
- Beschreibung: Die lernende Person kann gleichförmige Bewegungen im Diagramm erkennen, die Geschwindigkeit definieren und den Geschwindigkeitsbetrag experimentell bestimmen.
- `requires`: `["ce431132-dfc4-42c2-aff6-bd72035190f8","af3d6bff-c5fb-4ec6-a9f0-c0be09fc9186"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_uniform_motion","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 118. Durchschnitts- und Momentangeschwindigkeit unterscheiden

- ID: `bf8517a9-142b-5789-826a-767f3b277998`
- Beschreibung: Die lernende Person kann Durchschnittsgeschwindigkeit für ein endliches Zeitintervall und Momentangeschwindigkeit für einen Zeitpunkt bestimmen, vergleichen und im t-s-Diagramm als Sekanten- beziehungsweise Tangentensteigung deuten.
- `requires`: `["971beafa-6ba5-4c82-ac8b-7ebf66eec3dd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_e_average_instantaneous_velocity","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.E.MOTION.AVERAGE_INSTANTANEOUS_VELOCITY"}}`

## 119. Gleichmäßig beschleunigte Bewegung und Beschleunigung

- ID: `e4b38061-1f28-43ad-8371-a3e7c0e81856`
- Beschreibung: Die lernende Person kann das Modell der gleichmäßig beschleunigten Bewegung mit konstanter Beschleunigung erläutern und in t-s-, t-v- und t-a-Darstellungen beschreiben.
- `requires`: `["bf8517a9-142b-5789-826a-767f3b277998"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_accelerated_motion","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 120. Freier Fall experimentell untersuchen

- ID: `09029573-864f-40ca-bf8a-cee7bf6dcb73`
- Beschreibung: Die lernende Person kann den freien Fall nahe der Erdoberfläche experimentell untersuchen, Messdaten grafisch auswerten, daraus im Modell ohne Luftwiderstand die Gravitationsbeschleunigung bestimmen und unter Angabe der Anfangsbedingungen ein Zeit-Ort-Gesetz formulieren.
- `requires`: `["e4b38061-1f28-43ad-8371-a3e7c0e81856","ce431132-dfc4-42c2-aff6-bd72035190f8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_determine_free_fall_acceleration","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 121. Modellierung und Idealisierung von Bewegungen

- ID: `d6dc0e02-831d-4894-a61a-852bcc74f147`
- Beschreibung: Die lernende Person kann Bewegungen mit Zeit-Ort- und Zeit-Geschwindigkeits-Gesetzen modellieren, die verwendeten Idealisierungen wie Massepunkt und Reibungsfreiheit begründen und die Grenzen der Modellvorhersagen angeben.
- `requires`: `["ce431132-dfc4-42c2-aff6-bd72035190f8","e4b38061-1f28-43ad-8371-a3e7c0e81856","f08d06dc-139d-5fd2-892c-8cc919b1e4fc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_motion_modeling","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 122. E.2 Newton'sche Axiome und Erhaltungssätze

- ID: `9340e894-bb0d-45a4-91f2-b90a63ad50a8`
- Beschreibung: Cluster zu Newtonschen Axiomen, Grundgleichung der Mechanik sowie Energie- und Impulserhaltung in einfachen Situationen.
- `requires`: `[]`
- `contains`: `["4dc9a094-66d7-4d4d-9436-134aabe48f39","e9d616d8-685f-4129-a36f-dae7a280bae7"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","area:Mechanik"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_e2_mechanics_corridor","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"basicConcepts":["BC_MATHEMATISIEREN_VORHERSAGEN"],"phase":"E"}}`

## 123. Erhaltungssätze

- ID: `e9d616d8-685f-4129-a36f-dae7a280bae7`
- Beschreibung: Cluster zu Erhaltungssätzen: Energie- und Impulserhaltung sowie Anwendungen in Stoßprozessen.
- `requires`: `[]`
- `contains`: `["feb70838-931c-4b45-b9a9-930605d93efa","912febf0-754a-4409-9f8b-7d66810edc08","d168ae5d-f36f-4ad4-b070-d5931f8d70d1","d30fd37b-1f05-44e3-a40a-4c5a88fa28c2"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","area:Mechanik"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_conservation_laws","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"phase":"E"}}`

## 124. Mechanische Arbeit als Energieänderung

- ID: `c1c71daa-042b-4f4c-8c31-0ac366f5149e`
- Beschreibung: Die lernende Person kann mechanische Arbeit als Energieübertragung über eine festgelegte Systemgrenze deuten, ihr Vorzeichen aus Kraft- und Wegrichtung bestimmen und die am System verrichtete Arbeit konsistent mit dessen Energieänderung bilanzieren.
- `requires`: `["5f289cdc-fda1-4058-b44f-041ba1398e79","71a483ba-9680-4654-bb5e-5ab5427f0919"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_work_as_energy_change","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_ENERGIE","LI_BEWEGUNG"],"basicConcepts":["KONZEPT_ERHALTUNG_GLEICHGEWICHT"],"phase":"E"}}`

## 125. Newtons Axiome und Inertialsysteme

- ID: `4dc9a094-66d7-4d4d-9436-134aabe48f39`
- Beschreibung: Cluster für die drei Newtonschen Axiome sowie Inertialsysteme.
- `requires`: `[]`
- `contains`: `["31a2ef52-114b-4d2c-a720-6ef5a390b6dc","32b896b9-f2f1-4d4e-96ad-e869ac3d3759","a94cfe1c-6f87-47ff-b4f3-31a58d4c6c20","5f289cdc-fda1-4058-b44f-041ba1398e79","ad984bb6-e225-432a-952d-d83cda40b7f8","a0aaedcb-41f8-4891-af77-a69a76b8c10d","00245a43-eb89-47d2-92d7-21799dbec9f3","977e7421-0953-4b40-a966-5668b54ed8c9","5a1b3cb2-c0e6-4372-9c57-f33675cffc9b"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","area:Mechanik","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_newton_axioms_and_frames","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 126. Newtons 1. Axiom (Trägheitsprinzip)

- ID: `31a2ef52-114b-4d2c-a720-6ef5a390b6dc`
- Beschreibung: Die lernende Person kann Newtons erstes Axiom formulieren und einfache Situationen damit deuten: In einem Inertialsystem bleibt ein Körper bei verschwindender resultierender äußerer Kraft in Ruhe oder bewegt sich geradlinig mit konstanter Geschwindigkeit.
- `requires`: `["e4b38061-1f28-43ad-8371-a3e7c0e81856","5ea765ac-c279-551a-8a94-a07da2381e5b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_first_law","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 127. Newtons 1. Axiom anwenden

- ID: `32b896b9-f2f1-4d4e-96ad-e869ac3d3759`
- Beschreibung: Die lernende Person kann das Trägheitsprinzip auf Alltagssituationen in Inertialsystemen anwenden und erklären, dass eine verschwindende resultierende äußere Kraft sowohl mit Ruhe als auch mit gleichförmig-geradliniger Bewegung vereinbar ist.
- `requires`: `["31a2ef52-114b-4d2c-a720-6ef5a390b6dc","971beafa-6ba5-4c82-ac8b-7ebf66eec3dd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_apply_first_law","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 128. Newtons 2. Axiom (Grundgleichung der Mechanik)

- ID: `a94cfe1c-6f87-47ff-b4f3-31a58d4c6c20`
- Beschreibung: Die lernende Person kann den vektoriellen Impuls $\vec p=m\vec v$ einführen, Newtons zweites Axiom in einem Inertialsystem für ein materiell abgeschlossenes System als Zusammenhang zwischen der resultierenden äußeren Kraft und der zeitlichen Änderung des Impulses formulieren und deuten sowie für konstante Masse auf $\sum \vec F_\mathrm{ext}=m\vec a$ zurückführen.
- `requires`: `["31a2ef52-114b-4d2c-a720-6ef5a390b6dc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_second_law","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 129. Newtons 3. Axiom (Wechselwirkungsprinzip)

- ID: `ad984bb6-e225-432a-952d-d83cda40b7f8`
- Beschreibung: Die lernende Person kann Newtons drittes Axiom formulieren und an Beispielen erläutern, dass zwei wechselwirkende Körper gleichzeitig gleich große, entgegengesetzt gerichtete Kräfte aufeinander ausüben.
- `requires`: `["a94cfe1c-6f87-47ff-b4f3-31a58d4c6c20"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_formulate_third_law","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 130. Newtons 3. Axiom anwenden

- ID: `a0aaedcb-41f8-4891-af77-a69a76b8c10d`
- Beschreibung: Die lernende Person kann in Alltagssituationen Wechselwirkungskräfte als gleich große, entgegengesetzt gerichtete Kräfte identifizieren, die gleichzeitig auf zwei verschiedene Körper wirken, und sie von einer Kräftebilanz an einem einzelnen Körper unterscheiden.
- `requires`: `["ad984bb6-e225-432a-952d-d83cda40b7f8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_apply_third_law","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 131. Inertialsysteme und Bezugssysteme

- ID: `00245a43-eb89-47d2-92d7-21799dbec9f3`
- Beschreibung: Die lernende Person kann Inertialsysteme definieren und von nicht-inertialen Bezugssystemen unterscheiden.
- `requires`: `["31a2ef52-114b-4d2c-a720-6ef5a390b6dc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_inertial_frames","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 132. Die drei Newtonschen Axiome benennen und erklären

- ID: `977e7421-0953-4b40-a966-5668b54ed8c9`
- Beschreibung: Cluster zur zusammenfassenden Wiederholung der drei Newtonschen Axiome.
- `requires`: `[]`
- `contains`: `["31a2ef52-114b-4d2c-a720-6ef5a390b6dc","a94cfe1c-6f87-47ff-b4f3-31a58d4c6c20","ad984bb6-e225-432a-952d-d83cda40b7f8","5a1b3cb2-c0e6-4372-9c57-f33675cffc9b"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_name_newton_laws","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 133. Grundgleichung der Mechanik anwenden

- ID: `5f289cdc-fda1-4058-b44f-041ba1398e79`
- Beschreibung: Die lernende Person kann für einfache eindimensionale Bewegungen eines Körpers konstanter Masse in einem Inertialsystem die Beziehung $\sum F_\mathrm{ext}=m\cdot a$ mit einer gewählten Vorzeichenrichtung anwenden und Kräftegleichgewicht ($\sum F_\mathrm{ext}=0$) von beschleunigter Bewegung unterscheiden.
- `requires`: `["a94cfe1c-6f87-47ff-b4f3-31a58d4c6c20","5ea765ac-c279-551a-8a94-a07da2381e5b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","cross-subject:mathematics"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_apply_f_equals_m_a","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 134. Energie

- ID: `feb70838-931c-4b45-b9a9-930605d93efa`
- Beschreibung: Die lernende Person kann kinetische und potenzielle Energie unterscheiden, die Energie eines Körpers berechnen und die Energieerhaltung in energetisch abgeschlossenen Systemen begründen.
- `requires`: `[]`
- `contains`: `["c1c71daa-042b-4f4c-8c31-0ac366f5149e","94784e0a-7ddc-48be-91fb-dc82b78eb322","7eeff2de-6015-49a6-a96e-a488d886dc9f","6affc2ea-ecd2-4fcd-8877-3ffa15b0425b","253a71d2-e751-4c63-acbe-238b71463cd8","91c49019-ea51-4ce5-a919-c91c45b25e83","e359f8bb-6106-44aa-9edf-694528d2d2a9"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","area:Mechanik"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_energy_cluster","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 135. Mechanische Energie

- ID: `94784e0a-7ddc-48be-91fb-dc82b78eb322`
- Beschreibung: Die lernende Person kann die mechanische Energie als Summe aus kinetischer und potenzieller Energie beschreiben und einfache Beispiele deuten.
- `requires`: `["c1c71daa-042b-4f4c-8c31-0ac366f5149e","722857cf-f327-5740-8151-64eb92195ec8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_mechanical_energy","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 136. Kinetische Energie

- ID: `7eeff2de-6015-49a6-a96e-a488d886dc9f`
- Beschreibung: Die lernende Person kann die kinetische Energie $E_\mathrm{k}=\frac{1}{2}mv^2$ berechnen und die Abhängigkeit von Masse und Geschwindigkeit erläutern.
- `requires`: `["971beafa-6ba5-4c82-ac8b-7ebf66eec3dd","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_kinetic_energy","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 137. Potenzielle Energie (Lageenergie)

- ID: `6affc2ea-ecd2-4fcd-8877-3ffa15b0425b`
- Beschreibung: Die lernende Person kann in einfachen Situationen nahe der Erdoberfläche die gravitative potenzielle Energie des Systems Erde–Körper relativ zu einer gewählten Bezugshöhe beschreiben und ohne Feldbegriff berechnen.
- `requires`: `["7eeff2de-6015-49a6-a96e-a488d886dc9f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_potential_energy","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 138. Potenzielle Energie und Potential

- ID: `594f7f21-6b8a-531c-8424-5f1dcbaf0f23`
- Beschreibung: Die lernende Person kann potenzielle Energie über ein Potential beschreiben, einfache Fälle etwa im Gravitationsfeld berechnen und erläutern, wie Lage und gewähltes Nullniveau den Energiewert bestimmen, während Energiedifferenzen vom Nullniveau unabhängig sind.
- `requires`: `["a42f91a4-0d21-5aa9-ae11-f48be6f2e431"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 139. Reibungsenergie

- ID: `253a71d2-e751-4c63-acbe-238b71463cd8`
- Beschreibung: Die lernende Person kann den Begriff Reibungsenergie als Bilanzgröße für den Anteil mechanischer Energie deuten, der bei Reibung in innere Energie der beteiligten Körper umgewandelt wird, und diese Energieumwandlung für ein festgelegtes System qualitativ bilanzieren.
- `requires`: `["91c49019-ea51-4ce5-a919-c91c45b25e83"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_friction_energy","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 140. Energieerhaltung

- ID: `91c49019-ea51-4ce5-a919-c91c45b25e83`
- Beschreibung: Die lernende Person kann für ein System, über dessen Grenze keine Energie übertragen wird, die Energieerhaltung formulieren und einfache Umwandlungen zwischen Energieformen bilanziell beschreiben.
- `requires`: `["94784e0a-7ddc-48be-91fb-dc82b78eb322"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_energy_conservation","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 141. Energieentwertung vs. Energieverbrauch

- ID: `cbdc0b5f-8a48-5ade-be53-ab6aacaa3e73`
- Beschreibung: Die lernende Person kann den alltagssprachlichen „Energieverbrauch“ von der physikalischen Energieerhaltung abgrenzen und erklären, dass bei vollständig bilanziertem System die Energie erhalten bleibt, ihre Nutzbarkeit für einen gewünschten Zweck bei irreversiblen Umwandlungen durch Entropieerzeugung jedoch abnimmt.
- `requires`: `["91c49019-ea51-4ce5-a919-c91c45b25e83","f7f2c254-1663-5861-bed7-a32c00495b19"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_ENERGIE"],"phase":"E"}}`

## 142. Impulserhaltung

- ID: `839ecc8f-3a60-418b-bc92-64bfeef33824`
- Beschreibung: Die lernende Person kann in einem abgegrenzten System ohne resultierenden äußeren Kraftstoß den Gesamtimpuls als vektorielle Erhaltungsgröße nutzen und einfache Rückstoßsituationen damit qualitativ begründen.
- `requires`: `["5f289cdc-fda1-4058-b44f-041ba1398e79","a0aaedcb-41f8-4891-af77-a69a76b8c10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_momentum_conservation","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 143. Impuls

- ID: `912febf0-754a-4409-9f8b-7d66810edc08`
- Beschreibung: Cluster zum Impuls: Impulserhaltung, Kraftstoß und inelastische Stöße.
- `requires`: `[]`
- `contains`: `["839ecc8f-3a60-418b-bc92-64bfeef33824","f524f05c-4456-4fc3-a1f7-f40741fc1f16","e790de73-f8e5-4027-bc05-9f12a0e8c9cb","0da13365-02c2-44f1-8a81-d524ca0ac3ae","1232febe-868a-4dac-b4c2-e35789434601","2eecd0e2-a7ca-4568-9b12-3d47706c65fb"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","area:Mechanik"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_momentum_cluster","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 144. Elastische Stöße

- ID: `d168ae5d-f36f-4ad4-b070-d5931f8d70d1`
- Beschreibung: Die lernende Person kann elastische Stöße in einer Dimension mithilfe von Impuls- und kinetischer Energieerhaltung analysieren und sie fachlich von inelastischen Stößen abgrenzen.
- `requires`: `["839ecc8f-3a60-418b-bc92-64bfeef33824","7eeff2de-6015-49a6-a96e-a488d886dc9f","91c49019-ea51-4ce5-a919-c91c45b25e83"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_elastic_collisions","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 145. Elastische Stöße im Schwerpunktsystem analysieren

- ID: `d30fd37b-1f05-44e3-a40a-4c5a88fa28c2`
- Beschreibung: Die lernende Person kann elastische Stöße im Schwerpunktsystem analysieren, Relativgeschwindigkeiten vor und nach dem Stoß verknüpfen und Ergebnisse ins Laborsystem zurücktransformieren.
- `requires`: `["d168ae5d-f36f-4ad4-b070-d5931f8d70d1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","course:advanced"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_com_frame_collisions","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 146. Kraftstoß

- ID: `e790de73-f8e5-4027-bc05-9f12a0e8c9cb`
- Beschreibung: Die lernende Person kann den Kraftstoß als über die Einwirkdauer aufsummierte Wirkung der resultierenden äußeren Kraft beschreiben, ihn in einer gewählten Richtung als vorzeichenbehaftete Fläche unter einem Kraft-Zeit-Diagramm und bei konstanter Kraft als Produkt aus Kraft und Einwirkdauer bestimmen sowie mit der Impulsänderung verknüpfen.
- `requires`: `["839ecc8f-3a60-418b-bc92-64bfeef33824"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_force_impulse","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 147. Unfallphysik: Kraftstoß und Knautschzone

- ID: `1232febe-868a-4dac-b4c2-e35789434601`
- Beschreibung: Die lernende Person kann bei gleicher Impulsänderung mit der verlängerten Stoßdauer erklären, wie eine Knautschzone den Betrag der mittleren Kraft bei einem Verkehrsunfall verringert.
- `requires`: `["e790de73-f8e5-4027-bc05-9f12a0e8c9cb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context","canonical","context:traffic_safety"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_crash_impulse_context","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"E"}}`

## 148. Inelastische Stöße

- ID: `0da13365-02c2-44f1-8a81-d524ca0ac3ae`
- Beschreibung: Die lernende Person kann inelastische Stöße in einer Dimension mithilfe der Impulserhaltung analysieren und Energieumwandlungen qualitativ beschreiben.
- `requires`: `["839ecc8f-3a60-418b-bc92-64bfeef33824","91c49019-ea51-4ce5-a919-c91c45b25e83"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_inelastic_collisions","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 149. Erhaltung der mechanischen Energie tiefer verstehen (LK)

- ID: `e359f8bb-6106-44aa-9edf-694528d2d2a9`
- Beschreibung: Die lernende Person kann für ein System konstanter Masse, auf das nur konservative Kräfte mit zeitunabhängigem Potenzial wirken, aus dem zweiten Newtonschen Axiom und F = −∇U die Erhaltung der mechanischen Energie herleiten und die Gültigkeitsbedingungen erläutern.
- `requires`: `["a94cfe1c-6f87-47ff-b4f3-31a58d4c6c20","00245a43-eb89-47d2-92d7-21799dbec9f3","594f7f21-6b8a-531c-8424-5f1dcbaf0f23","6affc2ea-ecd2-4fcd-8877-3ffa15b0425b","91c49019-ea51-4ce5-a919-c91c45b25e83","2ac2e902-a6ad-53c9-b139-d1c63d823023","2c4830e6-a8d5-48d0-9202-3b7d18a419c2","ae5010cc-ea8d-5b14-aa4a-b0f2b5846a75"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","canonical","course:advanced"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_derive_energy_conservation","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE"],"phase":"E"}}`

## 150. Impulserhaltung aus Newtonschen Axiomen (LK)

- ID: `f524f05c-4456-4fc3-a1f7-f40741fc1f16`
- Beschreibung: Die lernende Person kann in einem Inertialsystem für ein materiell abgeschlossenes System aus Newtons zweitem und drittem Axiom herleiten, dass der Gesamtimpuls bei verschwindendem resultierendem äußerem Kraftstoß an den Intervallgrenzen gleich ist, und die Voraussetzungen für seine fortlaufende Erhaltung diskutieren.
- `requires`: `["5f289cdc-fda1-4058-b44f-041ba1398e79","a0aaedcb-41f8-4891-af77-a69a76b8c10d","34604a97-0c64-5b06-81e2-6ac818732d60","c63bbffd-8d1c-5fe2-a428-db194e6fe592"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","canonical","course:advanced"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_derive_momentum_conservation","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 151. Waagerechter Wurf und Kreisbewegung

- ID: `287739a3-6143-55d0-abe7-1a08889e9b49`
- Beschreibung: Themenfeld E.3 mit Bezugssystemen, Superpositionsprinzip, waagerechtem Wurf sowie Bahn- und Winkelgeschwindigkeit, Zentripetalkraft und Scheinkräften bei Kreisbewegungen.
- `requires`: `[]`
- `contains`: `["82b5df3d-b1a7-4c6f-bd62-18fbbbe097a3","db0aff75-7c88-52b0-a989-535b411c141e"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 152. Waagerechter Wurf und Superposition

- ID: `82b5df3d-b1a7-4c6f-bd62-18fbbbe097a3`
- Beschreibung: Untersuchung zusammengesetzter Bewegungen: Unabhängigkeitsprinzip, Flugbahnen und Geschwindigkeiten.
- `requires`: `[]`
- `contains`: `["68c90ba6-c438-463c-9a53-cf61062d416a","89a8cf15-7ba4-46c1-b1dc-fd161b20d9c2"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","area:Mechanik","topic:e3"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_e3_horizontal_throw","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 153. Kreisbewegungen und Zentripetalkraft

- ID: `db0aff75-7c88-52b0-a989-535b411c141e`
- Beschreibung: Dynamik von Kreisbewegungen, Zentripetalkraft und Kurvenfahrten.
- `requires`: `[]`
- `contains`: `["ec7a0a68-730b-5c94-ac72-a937508f8303","e918b31f-6f39-5dee-ade6-3617080fb24f","accb1d9e-cd48-5983-bcef-9b9bca4a9114","e2da5eec-45de-5527-9ad7-16f41cacbe58","39b2a0c4-eecf-5049-b58f-e790790a3bf2"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 154. Bezugssysteme und Geschwindigkeitsüberlagerung

- ID: `68c90ba6-c438-463c-9a53-cf61062d416a`
- Beschreibung: Die lernende Person kann für eine Bewegung ein geeignetes Bezugssystem wählen und Relativgeschwindigkeiten vektoriell überlagern, um die resultierende Bewegung zu bestimmen und zu erklären.
- `requires`: `["971beafa-6ba5-4c82-ac8b-7ebf66eec3dd","4d78bbcc-89b8-47f0-aa45-516199e4da5d","c63bbffd-8d1c-5fe2-a428-db194e6fe592"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_reference_frames_superposition","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 155. Waagerechter Wurf analysieren

- ID: `89a8cf15-7ba4-46c1-b1dc-fd161b20d9c2`
- Beschreibung: Die lernende Person kann den waagerechten Wurf experimentell untersuchen, bei vernachlässigbarem Luftwiderstand und konstanter Fallbeschleunigung als Überlagerung gleichförmiger horizontaler und gleichmäßig beschleunigter vertikaler Bewegung deuten und die Flugbahn im x-y-Diagramm darstellen.
- `requires`: `["68c90ba6-c438-463c-9a53-cf61062d416a","d6dc0e02-831d-4894-a61a-852bcc74f147"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_horizontal_throw","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 156. Bahn- und Winkelgeschwindigkeit

- ID: `ec7a0a68-730b-5c94-ac72-a937508f8303`
- Beschreibung: Die lernende Person kann bei Kreisbewegungen Bahn- und Winkelgeschwindigkeit definieren, berechnen und ihren Zusammenhang v = ωr erklären.
- `requires`: `["971beafa-6ba5-4c82-ac8b-7ebf66eec3dd","8d30d241-0247-48ac-83d3-4e0de61584d3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 157. Zentripetalkraft als Resultierende herleiten

- ID: `e918b31f-6f39-5dee-ade6-3617080fb24f`
- Beschreibung: Die lernende Person kann für eine gleichförmige Kreisbewegung herleiten, dass die zum Mittelpunkt gerichtete resultierende Kraft den Betrag F_z = mv²/r hat, und bei jeweils konstanten übrigen Größen erklären, wie dieser von Masse, Geschwindigkeit und Radius abhängt.
- `requires`: `["ec7a0a68-730b-5c94-ac72-a937508f8303","5f289cdc-fda1-4058-b44f-041ba1398e79"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 158. Kreisbewegung mit Zentripetalkraft anwenden

- ID: `accb1d9e-cd48-5983-bcef-9b9bca4a9114`
- Beschreibung: Die lernende Person kann gleichförmige Kreisbewegungen mithilfe der Zentripetalkraft beschreiben und quantitativ analysieren.
- `requires`: `["e918b31f-6f39-5dee-ade6-3617080fb24f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 159. Kurvenfahrten mit Haftreibung analysieren

- ID: `e2da5eec-45de-5527-9ad7-16f41cacbe58`
- Beschreibung: Die lernende Person kann einfache Situationen wie Kurvenfahrten mit Haftreibung mithilfe der Zentripetalkraft quantitativ analysieren.
- `requires`: `["accb1d9e-cd48-5983-bcef-9b9bca4a9114","5fd45dbc-0eb1-591b-99a9-7386336f1456"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 160. Scheinkräfte in nicht-inertialen Systemen

- ID: `39b2a0c4-eecf-5049-b58f-e790790a3bf2`
- Beschreibung: Die lernende Person kann Scheinkräfte in beschleunigten Bezugssystemen qualitativ erklären und typische Beispiele wie Kreisbewegungen in rotierenden Systemen deuten.
- `requires`: `["accb1d9e-cd48-5983-bcef-9b9bca4a9114"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 161. Weitere Bewegungen

- ID: `04d1d2df-a94b-5db4-8d07-cbb512c2e0b9`
- Beschreibung: Cluster zu Bewegungen mit Reibung sowie numerischer Modellierung von Bewegungen mit Differenzenquotienten.
- `requires`: `[]`
- `contains`: `["56c629b5-d0d9-5309-aeae-808dc60f8dbb","fbecbd60-5db3-51e8-94be-d66b066ffa06","5fd45dbc-0eb1-591b-99a9-7386336f1456","30ddb2d7-b991-55fe-9e74-37ffe1048f9f","12260012-cf04-5409-b57d-f5b3a46d9126","761a0879-fc15-5d0c-a2b7-2b439efecd5b","76fd0ab2-079a-516e-a33b-170355336d40"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"phase":"E"}}`

## 162. Schiefen Wurf beschreiben

- ID: `fbecbd60-5db3-51e8-94be-d66b066ffa06`
- Beschreibung: Die lernende Person kann den schiefen Wurf ohne Luftwiderstand als Überlagerung einer gleichförmigen horizontalen und einer durch die Schwerkraft gleichmäßig beschleunigten vertikalen Bewegung beschreiben und typische Flugbahnen qualitativ skizzieren.
- `requires`: `["89a8cf15-7ba4-46c1-b1dc-fd161b20d9c2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 163. Reibungskräfte qualitativ verstehen

- ID: `5fd45dbc-0eb1-591b-99a9-7386336f1456`
- Beschreibung: Die lernende Person kann Haft- und Gleitreibung anhand der drohenden beziehungsweise bestehenden Relativbewegung an der Kontaktfläche unterscheiden, die Reibungskraft jeweils entgegen dieser Relativbewegung oder Relativbewegungstendenz einzeichnen und ihre Wirkung auf die Bewegung erläutern.
- `requires`: `["5f289cdc-fda1-4058-b44f-041ba1398e79"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 164. Geradlinige Bewegung mit Reibung modellieren

- ID: `30ddb2d7-b991-55fe-9e74-37ffe1048f9f`
- Beschreibung: Die lernende Person kann geradlinige Bewegungen mit Reibung unter klar benannten einfachen Modellannahmen modellieren, indem sie die wirkenden Kräfte mit einer konsistent gewählten positiven Richtung bilanziert, aus der resultierenden Kraft die Beschleunigung bestimmt und den Bewegungsverlauf mit passenden einfachen Bewegungsgleichungen beschreibt und qualitativ vorhersagt.
- `requires`: `["5fd45dbc-0eb1-591b-99a9-7386336f1456","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 165. Fallbewegung mit Luftwiderstand und Grenzgeschwindigkeit

- ID: `12260012-cf04-5409-b57d-f5b3a46d9126`
- Beschreibung: Die lernende Person kann eine Fallbewegung mit Luftwiderstand mithilfe einfacher Modelle qualitativ beschreiben und bei vernachlässigbarem Auftrieb die Grenzgeschwindigkeit aus dem Gleichgewicht von Gewichtskraft und Luftwiderstand erklären.
- `requires`: `["09029573-864f-40ca-bf8a-cee7bf6dcb73","5f289cdc-fda1-4058-b44f-041ba1398e79"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 166. Methode: Modellbildung mit Tabellenkalkulation

- ID: `ac25ffe3-fd42-592d-a937-79cc13460313`
- Beschreibung: Die lernende Person kann ein Bewegungsmodell mit Anfangsbedingungen und endlichen Zeitschritten als Differenzenverfahren in einer Tabellenkalkulation umsetzen, Parameter systematisch variieren und Simulationsergebnisse im Hinblick auf den Bewegungsverlauf, die Modellannahmen und die Zeitschrittweite interpretieren.
- `requires`: `["30ddb2d7-b991-55fe-9e74-37ffe1048f9f","f08d06dc-139d-5fd2-892c-8cc919b1e4fc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 167. Numerische Simulation von Bewegungen

- ID: `761a0879-fc15-5d0c-a2b7-2b439efecd5b`
- Beschreibung: Die lernende Person kann Bewegungen mit Reibung durch Differenzenquotienten modellieren und mithilfe einer Tabellenkalkulation oder ähnlicher Werkzeuge numerisch simulieren.
- `requires`: `["12260012-cf04-5409-b57d-f5b3a46d9126","ac25ffe3-fd42-592d-a937-79cc13460313"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 168. Grenzen der Vorhersagbarkeit (Chaos)

- ID: `76fd0ab2-079a-516e-a33b-170355336d40`
- Beschreibung: Die lernende Person kann an mechanischen Systemen erklären, dass bei deterministischem Chaos geringfügig verschiedene Anfangsbedingungen mit der Zeit zu stark auseinanderlaufenden Bewegungsverläufen führen und dadurch langfristige Vorhersagen begrenzt sind.
- `requires`: `["5f289cdc-fda1-4058-b44f-041ba1398e79"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"basicConcepts":["KONZEPT_ZUFALL_DETERMINIERTHEIT"],"phase":"E"}}`

## 169. Gravitation

- ID: `0ade0d10-8b32-5a95-a1a9-8ac64e2a8089`
- Beschreibung: Cluster zur Gravitation: Massenanziehung, Gravitationsfeld, Gravitationsgesetz und Gewichtskraft, Planetenbewegungen, Kepler-Gesetze sowie Entwicklung des astronomischen Weltbilds.
- `requires`: `[]`
- `contains`: `["92d8f398-0c9f-523c-88d7-44165b6b4768","156edddc-ce8d-580d-8d17-d9376d59e60e","eb0ffdea-c12d-56df-b7e8-c0297d2f8aff","a42f91a4-0d21-5aa9-ae11-f48be6f2e431","594f7f21-6b8a-531c-8424-5f1dcbaf0f23","60211ac1-cbe1-5182-87ef-673a068c5b0a","497f1311-17d6-56ff-afb1-422a738e5c16","16caf92e-2800-57d1-946c-5b92ce848a96","89cadf81-143b-5f6b-82bd-29ba20d92a1b","eb31f0a7-f6c0-5737-b09a-90ce3eff41b3","423e21b9-0d0c-5709-899d-7ab738b55e36","6d18104b-5704-5c45-b39a-2c84565b1796"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_KOSMOS"],"phase":"E"}}`

## 170. Massenanziehung qualitativ beschreiben

- ID: `92d8f398-0c9f-523c-88d7-44165b6b4768`
- Beschreibung: Die lernende Person kann die gegenseitige gravitative Anziehung zweier Massen in Alltagssituationen beschreiben und qualitativ erläutern, dass die Gravitationskraft bei sonst gleichen Bedingungen mit jeder der beiden Massen zunimmt und mit wachsendem Abstand ihrer Mittelpunkte abnimmt.
- `requires`: `["09029573-864f-40ca-bf8a-cee7bf6dcb73","230345f3-c360-4963-b390-ab94e3e2c864"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 171. Gravitationsfeld als Feldgröße einführen

- ID: `156edddc-ce8d-580d-8d17-d9376d59e60e`
- Beschreibung: Die lernende Person kann das Gravitationsfeld als ortsabhängige Vektorgröße erklären, die der Gravitationskraft auf einen Probekörper pro Masse dieses Probekörpers entspricht, und das radialsymmetrische Feld einer zentralen Masse durch nach innen gerichtete Feldlinien darstellen.
- `requires`: `["92d8f398-0c9f-523c-88d7-44165b6b4768","571793bd-34f1-539e-969c-dfcc2dfa96b3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 172. Gravitationsgesetz und Gewichtskraft anwenden

- ID: `eb0ffdea-c12d-56df-b7e8-c0297d2f8aff`
- Beschreibung: Die lernende Person kann das Gravitationsgesetz formulieren, die Gewichtskraft aus der Feldstärke herleiten und einfache Aufgaben zu Gravitationskräften lösen.
- `requires`: `["9c328f68-41ed-55dd-9e02-34414a6246f2","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 173. Gravitationskraft und Gravitationspotential

- ID: `a42f91a4-0d21-5aa9-ae11-f48be6f2e431`
- Beschreibung: Der Lernende versteht die Gravitationskraft als konservative Kraft, die aus einem Potential abgeleitet ist. Das wird im Rahmen der mathematischen Möglichkeiten der Oberstufe erklärt.
- `requires`: `["eb0ffdea-c12d-56df-b7e8-c0297d2f8aff"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 174. Planetenbewegungen deuten

- ID: `60211ac1-cbe1-5182-87ef-673a068c5b0a`
- Beschreibung: Die lernende Person kann Planetenbewegungen im Gravitationsfeld qualitativ beschreiben und erläutern, wie die Gravitation den Geschwindigkeitsvektor verändert und auf Kreisbahnen die Zentripetalkraft liefert.
- `requires`: `["accb1d9e-cd48-5983-bcef-9b9bca4a9114","eb0ffdea-c12d-56df-b7e8-c0297d2f8aff"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 175. Kepler-Gesetze anwenden

- ID: `497f1311-17d6-56ff-afb1-422a738e5c16`
- Beschreibung: Die lernende Person kann die drei Kepler’schen Gesetze formulieren und einfache Schlussfolgerungen zu Umlaufzeiten und Bahnradien ziehen.
- `requires`: `["60211ac1-cbe1-5182-87ef-673a068c5b0a","88abc886-cce8-55cf-b86c-eb4ba45a92d7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 176. 2. Kepler-Gesetz aus Drehimpulserhaltung herleiten (LK)

- ID: `16caf92e-2800-57d1-946c-5b92ce848a96`
- Beschreibung: Die lernende Person kann das zweite Kepler-Gesetz aus der Bewegungsgleichung im Zentralfeld herleiten, eine konstante Flächengeschwindigkeit begründen und den Zusammenhang zur Drehimpulserhaltung erläutern.
- `requires`: `["497f1311-17d6-56ff-afb1-422a738e5c16","5f289cdc-fda1-4058-b44f-041ba1398e79","54541d08-61cc-5a6d-b6d9-d0270a7d1949","b1dcc191-d046-50de-984a-ee5c17157628","cf48c918-f6c1-5429-8da6-14df43f2f550"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_KOSMOS"],"phase":"E"}}`

## 177. 3. Kepler-Gesetz per Skalierungsargument herleiten (LK)

- ID: `89cadf81-143b-5f6b-82bd-29ba20d92a1b`
- Beschreibung: Die lernende Person kann aus der Skalierung der Bewegungsgleichung im Newtonschen Gravitationsfeld bei gleicher Zentralmasse und geometrisch ähnlichen Bahnen ohne explizite Bahnrechnung den Zusammenhang $T^2 \propto a^3$ zwischen Umlaufzeit $T$ und großer Halbachse $a$ herleiten.
- `requires`: `["16caf92e-2800-57d1-946c-5b92ce848a96","eb0ffdea-c12d-56df-b7e8-c0297d2f8aff"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_KOSMOS"],"phase":"E"}}`

## 178. Astronomische Weltbilder vergleichen (GK)

- ID: `eb31f0a7-f6c0-5737-b09a-90ce3eff41b3`
- Beschreibung: Cluster zum historischen Vergleich astronomischer Weltbilder im Grundkurs.
- `requires`: `[]`
- `contains`: `["15b56a1e-3eec-52ca-82fa-b4df9ce88415","25edd154-b1d8-546c-94a5-88502b6725cd","d873ffa2-04b3-5978-a955-89563802a348"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 179. Astronomische Weltbilder zeitlich einordnen (GK)

- ID: `15b56a1e-3eec-52ca-82fa-b4df9ce88415`
- Beschreibung: Die lernende Person kann die ptolemäischen, kopernikanischen und newtonschen astronomischen Weltbilder in eine grobe chronologische Reihenfolge bringen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 180. Geozentrisches und heliozentrisches Weltbild vergleichen (GK)

- ID: `25edd154-b1d8-546c-94a5-88502b6725cd`
- Beschreibung: Die lernende Person kann das geozentrische und das heliozentrische Weltbild vergleichen, indem sie Mittelpunkt, Stellung und zugeschriebene Bewegungen von Erde, Sonne und Planeten gegenüberstellt.
- `requires`: `["15b56a1e-3eec-52ca-82fa-b4df9ce88415"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 181. Newtons Beitrag zur Erklärung von Planetenbewegungen erläutern (GK)

- ID: `d873ffa2-04b3-5978-a955-89563802a348`
- Beschreibung: Die lernende Person kann erläutern, warum Newtons Gravitationsphysik ein vertieftes Verständnis der Planetenbewegung ermöglicht.
- `requires`: `["25edd154-b1d8-546c-94a5-88502b6725cd","eb0ffdea-c12d-56df-b7e8-c0297d2f8aff"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 182. Astronomische Weltbilder vergleichen (LK)

- ID: `423e21b9-0d0c-5709-899d-7ab738b55e36`
- Beschreibung: Cluster zur vertieften historischen und fachlichen Einordnung astronomischer Weltbilder im Leistungskurs.
- `requires`: `[]`
- `contains`: `["481ffd56-d585-56fe-b525-ed423e30eed3","1b833656-cd16-5b21-973a-9810960dcfd2","c968d263-8be4-5cf9-b320-e95398fe648f"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 183. Entwicklung astronomischer Weltbilder rekonstruieren (LK)

- ID: `481ffd56-d585-56fe-b525-ed423e30eed3`
- Beschreibung: Die lernende Person kann die Entwicklung astronomischer Weltbilder von Ptolemäus über Kopernikus und Kepler bis Newton chronologisch rekonstruieren, den Stationen zentrale Modellannahmen oder Neuerungen zuordnen und die Übergänge anhand dieser Veränderungen begründen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 184. Keplers Beschreibung und Newtons Erklärung unterscheiden (LK)

- ID: `1b833656-cd16-5b21-973a-9810960dcfd2`
- Beschreibung: Die lernende Person kann den Unterschied zwischen Keplers kinematischer Beschreibung und Newtons dynamischer Erklärung fachlich darstellen.
- `requires`: `["481ffd56-d585-56fe-b525-ed423e30eed3","497f1311-17d6-56ff-afb1-422a738e5c16"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 185. Übergang von geometrischen zu dynamischen Modellen darstellen (LK)

- ID: `c968d263-8be4-5cf9-b320-e95398fe648f`
- Beschreibung: Die lernende Person kann den Übergang von geometrischen Weltmodellen zu einer physikalisch begründeten dynamischen Beschreibung erläutern.
- `requires`: `["1b833656-cd16-5b21-973a-9810960dcfd2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 186. Grundlagen der Thermodynamik

- ID: `df11eb33-4900-52bf-93b3-eb82ff0f9a28`
- Beschreibung: Cluster zu Grundlagen der Thermodynamik: Wärmeenergie als innere Energie, reversible und irreversible Prozesse, erster und zweiter Hauptsatz als getrennte Grundlagenziele sowie konkrete Anwendungen zu Entropie, Wirkungsgrad und Energieentwertung.
- `requires`: `[]`
- `contains`: `["88d07c80-5d7d-5c70-b385-b22769381e44","37b33812-d428-5953-852e-57a53a4347fe","2088ccf0-48f4-51d4-be5f-67affd0fb099","5f17e992-fd07-56ee-80a0-567f45bbd10c","912a5489-abcc-55f9-8f1a-9ee1e2d7fd9d","84f0c3e9-09fe-55c4-8040-6d740ada0426","e9e6d534-dac3-5389-959e-3b2030edcd68","91b20476-12cf-50d6-880a-ea509ffe8a9a","cbdc0b5f-8a48-5ade-be53-ab6aacaa3e73","18058384-a1bc-5ba2-8f5d-1fe9498acbf0","5e7c8fdb-8027-5a54-9e43-e1100da6fbdb"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 187. Wärmeenergie als innere Energie deuten

- ID: `88d07c80-5d7d-5c70-b385-b22769381e44`
- Beschreibung: Die lernende Person kann den Ausdruck „Wärmeenergie“ im historischen Zusammenhang als Bezeichnung für die innere Energie eines betrachteten Systems einordnen und erklären, warum „innere Energie“ die im System gespeicherte Energie begrifflich präziser bezeichnet.
- `requires`: `["c1c71daa-042b-4f4c-8c31-0ac366f5149e","94784e0a-7ddc-48be-91fb-dc82b78eb322"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 188. Kinetische Gastheorie & Temperatur

- ID: `37b33812-d428-5953-852e-57a53a4347fe`
- Beschreibung: Die lernende Person kann im klassischen Modell eines idealen Gases erklären, wie die absolute Temperatur mit der mittleren kinetischen Energie der ungeordneten Translationsbewegung der Teilchen zusammenhängt.
- `requires`: `["88d07c80-5d7d-5c70-b385-b22769381e44"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"E"}}`

## 189. Reversible und irreversible Vorgänge unterscheiden

- ID: `2088ccf0-48f4-51d4-be5f-67affd0fb099`
- Beschreibung: Die lernende Person kann reversible und irreversible thermodynamische Vorgänge an Beispielen unterscheiden und Konsequenzen für die Energieumwandlung beschreiben.
- `requires`: `["88d07c80-5d7d-5c70-b385-b22769381e44"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 190. Ersten Hauptsatz verstehen und mit Formel angeben

- ID: `5f17e992-fd07-56ee-80a0-567f45bbd10c`
- Beschreibung: Die lernende Person kann den ersten Hauptsatz $\Delta U = Q + W$ als Energiebilanz eines geschlossenen Systems erklären und formulieren: $Q$ ist die zugeführte Wärme und $W$ die am System verrichtete Arbeit, jeweils mit Vorzeichen.
- `requires`: `["2088ccf0-48f4-51d4-be5f-67affd0fb099"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 191. Zweiten Hauptsatz verstehen und mit Entropie-Formulierung angeben

- ID: `912a5489-abcc-55f9-8f1a-9ee1e2d7fd9d`
- Beschreibung: Die lernende Person kann den zweiten Hauptsatz für ein isoliertes Gesamtsystem als $\Delta S_{\mathrm{ges}} \ge 0$ formulieren, reversible und irreversible Prozesse durch $\Delta S_{\mathrm{ges}} = 0$ beziehungsweise $\Delta S_{\mathrm{ges}} > 0$ unterscheiden und daraus die Richtung spontaner Abläufe begründen.
- `requires`: `["2088ccf0-48f4-51d4-be5f-67affd0fb099"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 192. Entropie vertieft verstehen

- ID: `84f0c3e9-09fe-55c4-8040-6d740ada0426`
- Beschreibung: Cluster zur vertieften Entropiekompetenz: makroskopische Definition, Bilanzierung, Clausius-Ungleichung, mikroskopische Deutung über Mikrozustände sowie Wärmekraftmaschinen und Zeitpfeil.
- `requires`: `[]`
- `contains`: `["36c4590c-6032-5a37-b660-f15951dee076","0de2ca8c-7272-59ed-9c89-0971d6ce2f47","239aac49-1137-5df5-b197-49e72292e40c","e713dc34-beeb-5807-8a90-f872e049aa4e","6e79ef4a-2666-5f7a-885c-b175954506f8","741e7056-69e4-59be-a159-0e2583d748d1","eaef821b-4dbe-52a4-a0e2-574e5ce2040d","14099861-897c-53f4-8c6c-48d088ee9f01","be921c3b-7db9-50b5-a110-92f31673fc62","81a45dec-37be-529b-89ce-2f3101237293","616ac6cf-901b-509a-8cbb-bd422ddecf05","b61d233a-1902-526b-a9b5-6b3d553f4013","b6dfd3e6-2dd3-5983-9a27-7e7db70e8db8","77604656-7ffe-516c-8af3-7cbe7de2f2a4","d0cebf18-8b2a-52d6-857d-ef18cd64541c","161502b8-e52d-58d0-8f01-9f777b56d392"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE","LI_TECHNIK"],"phase":"E"}}`

## 193. Entropie E01: Zustandsgrößen vs. Prozessgrößen

- ID: `36c4590c-6032-5a37-b660-f15951dee076`
- Beschreibung: Die lernende Person unterscheidet Zustandsgrößen ($p, V, T, U, S$) von Prozessgrößen ($Q, W$) und erklärt, warum $Q$ und $W$ vom Weg abhängen, $\Delta U$ und $\Delta S$ aber nicht.
- `requires`: `["cd1903a5-d70a-5320-9124-b6b24917ba14"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 194. Entropie E02: Reversibel, irreversibel, quasistatisch

- ID: `0de2ca8c-7272-59ed-9c89-0971d6ce2f47`
- Beschreibung: Die lernende Person kann reversible, irreversible und quasistatische Prozesse an Reibung, Wärmeübertragung bei endlicher Temperaturdifferenz und freier Expansion unterscheiden und erklären, warum quasistatischer Ablauf allein keine Reversibilität garantiert und Reversibilität ein idealer Grenzfall ist.
- `requires`: `["2088ccf0-48f4-51d4-be5f-67affd0fb099","36c4590c-6032-5a37-b660-f15951dee076"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_ENERGIE"],"phase":"E"}}`

## 195. Entropie E03: Warum Entropie überhaupt?

- ID: `239aac49-1137-5df5-b197-49e72292e40c`
- Beschreibung: Die lernende Person begründet, warum Energieerhaltung allein die Richtung realer Prozesse nicht festlegt, und formuliert die Leitfrage: Warum läuft Wärme spontan von heiß nach kalt?
- `requires`: `["5f17e992-fd07-56ee-80a0-567f45bbd10c","0de2ca8c-7272-59ed-9c89-0971d6ce2f47"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE"],"phase":"E"}}`

## 196. Entropie E04: Makroskopische Definition (Clausius)

- ID: `e713dc34-beeb-5807-8a90-f872e049aa4e`
- Beschreibung: Die lernende Person nutzt die Definition $dS = \frac{\delta Q_{\mathrm{rev}}}{T}$ und erklärt, warum zur Berechnung von $\Delta S$ ein reversibler Ersatzweg verwendet werden darf (weil $S$ eine Zustandsgröße ist).
- `requires`: `["912a5489-abcc-55f9-8f1a-9ee1e2d7fd9d","239aac49-1137-5df5-b197-49e72292e40c","3bf1ce9e-f4d3-502e-9d6e-94f7b7f697d4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 197. Entropie E05: Einheiten und Bedeutung von S

- ID: `6e79ef4a-2666-5f7a-885c-b175954506f8`
- Beschreibung: Die lernende Person kann die Einheit $\mathrm{J/K}$ der Entropie anhand von $\Delta S = Q_{\mathrm{rev}}/T$ deuten und erklären, warum dieselbe reversibel zugeführte Wärmemenge bei niedrigerer konstanter absoluter Temperatur eine größere Entropiezunahme bewirkt.
- `requires`: `["e713dc34-beeb-5807-8a90-f872e049aa4e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE"],"phase":"E"}}`

## 198. Entropie E06: Standardfälle sicher rechnen

- ID: `741e7056-69e4-59be-a159-0e2583d748d1`
- Beschreibung: Die lernende Person kann die Entropieänderung eines Wärmereservoirs mit $\Delta S = Q/T$ und bei einem reversiblen Phasenübergang mit $\Delta S = L/T$ berechnen und deuten; $T$ ist die konstante absolute Temperatur, $Q$ beziehungsweise $L$ die vorzeichenbehaftete aufgenommene Wärmemenge in Joule.
- `requires`: `["6e79ef4a-2666-5f7a-885c-b175954506f8","93ece389-78c5-5141-9ef1-c68bd558306e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 199. Entropie E07: Entropieänderung idealer Gase

- ID: `eaef821b-4dbe-52a4-a0e2-574e5ce2040d`
- Beschreibung: Die lernende Person kann Entropieänderungen einer festen Menge idealen Gases bei einfachen Zustandsänderungen berechnen und physikalisch deuten, insbesondere isotherm mit $\Delta S = nR\ln(V_2/V_1)$, und die Größen $n$, $R$, $V$ und $T$ sowie die Gültigkeitsbedingungen zuordnen.
- `requires`: `["e713dc34-beeb-5807-8a90-f872e049aa4e","fb73c94b-6a23-5351-8fef-db2c2533e361","3c1d6ce7-099e-4267-9ff2-3d1526209a89"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 200. Entropie E08: Entropiebilanz für System + Umgebung

- ID: `14099861-897c-53f4-8c6c-48d088ee9f01`
- Beschreibung: Die lernende Person kann die Entropieänderungen von System und Umgebung zu $\Delta S_{\mathrm{ges}}$ addieren und für Wärmeübertragung zwischen zwei sonst isolierten Reservoiren bei konstanten absoluten Temperaturen $T_h > T_c$ rechnerisch begründen, warum Wärmefluss von heiß nach kalt die Gesamtentropie erhöht.
- `requires`: `["741e7056-69e4-59be-a159-0e2583d748d1","eaef821b-4dbe-52a4-a0e2-574e5ce2040d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 201. Entropie E09: Der 2. Hauptsatz als Entscheidungsregel

- ID: `be921c3b-7db9-50b5-a110-92f31673fc62`
- Beschreibung: Die lernende Person kann für ein als isoliert betrachtetes Gesamtsystem aus System und Umgebung $\Delta S_{\mathrm{ges}} \ge 0$ als Kriterium für eine nach dem zweiten Hauptsatz mögliche Prozessrichtung anwenden und den reversiblen Grenzfall $\Delta S_{\mathrm{ges}} = 0$ von irreversiblen Prozessen mit $\Delta S_{\mathrm{ges}} > 0$ unterscheiden.
- `requires`: `["14099861-897c-53f4-8c6c-48d088ee9f01"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE"],"phase":"E"}}`

## 202. Entropie E10: Clausius-Ungleichung (Kreisprozess)

- ID: `81a45dec-37be-529b-89ce-2f3101237293`
- Beschreibung: Die lernende Person kann die Clausius-Ungleichung $\oint \frac{\delta Q}{T} \le 0$ für Kreisprozesse mit Wärme positiv zum System und $T$ als absoluter Temperatur des jeweiligen Wärmereservoirs deuten und daraus begründen, warum die vollständige Umwandlung von Wärme aus einem einzigen Reservoir in Arbeit als einzige Wirkung unmöglich ist.
- `requires`: `["be921c3b-7db9-50b5-a110-92f31673fc62"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"E"}}`

## 203. Entropie E11: Entropieproduktion und Irreversibilität

- ID: `616ac6cf-901b-509a-8cbb-bd422ddecf05`
- Beschreibung: Die lernende Person kann Reibung, Mischung beziehungsweise Diffusion, Wärmeaustausch bei endlicher Temperaturdifferenz und freie Expansion als Ursachen von Entropieproduktion erklären und begründen, warum sie sich nicht ohne bleibende Änderungen in System und Umgebung vollständig umkehren lassen.
- `requires`: `["be921c3b-7db9-50b5-a110-92f31673fc62","0de2ca8c-7272-59ed-9c89-0971d6ce2f47"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 204. Entropie E12: Makrozustand und Mikrozustände

- ID: `b61d233a-1902-526b-a9b5-6b3d553f4013`
- Beschreibung: Die lernende Person kann Makrozustände (z. B. beschrieben durch $p, V, T$) von Mikrozuständen (Teilchenzuständen) unterscheiden und an einem Teilchenmodell erklären, wie verschiedene Mikrozustände demselben Makrozustand entsprechen können.
- `requires`: `["37b33812-d428-5953-852e-57a53a4347fe","239aac49-1137-5df5-b197-49e72292e40c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"E"}}`

## 205. Entropie E13: Boltzmann-Formel und Zählmodelle

- ID: `b6dfd3e6-2dd3-5983-9a27-7e7db70e8db8`
- Beschreibung: Die lernende Person kann mit $S = k_B\ln\Omega$ und einfachen Zählmodellen, etwa $\Omega=\binom{N}{n}$ für gleich wahrscheinliche Links-rechts-Zuordnungen, die Entropien verschiedener Makrozustände vergleichen und erklären, warum bei großer Teilchenzahl annähernd gleichmäßige Verteilungen gegenüber stark ungleichmäßigen überwiegen.
- `requires`: `["b61d233a-1902-526b-a9b5-6b3d553f4013","3c1d6ce7-099e-4267-9ff2-3d1526209a89"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"E"}}`

## 206. Entropie E14: Brücke Makro ↔ Mikro

- ID: `77604656-7ffe-516c-8af3-7cbe7de2f2a4`
- Beschreibung: Die lernende Person kann für eine feste Teilchenzahl $N$ eines klassischen idealen Gases bei unveränderter Temperatur den Zusammenhang $\Omega_2/\Omega_1 = (V_2/V_1)^N$ im Teilchenmodell begründen und daraus $\Delta S = Nk_B\ln(V_2/V_1) = nR\ln(V_2/V_1)$ als Verbindung von mikroskopischer und makroskopischer Entropiebeschreibung herleiten.
- `requires`: `["b6dfd3e6-2dd3-5983-9a27-7e7db70e8db8","eaef821b-4dbe-52a4-a0e2-574e5ce2040d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"E"}}`

## 207. Entropie E15: Wärmekraftmaschinen und Carnot-Grenze

- ID: `d0cebf18-8b2a-52d6-857d-ef18cd64541c`
- Beschreibung: Die lernende Person kann für eine zyklisch arbeitende Wärmekraftmaschine zwischen zwei Reservoiren mit konstanten absoluten Temperaturen die Carnot-Grenze aus Energie- und Entropiebilanzen begründen und erklären, warum Irreversibilität den erreichbaren Wirkungsgrad bei denselben Reservoirtemperaturen verringert.
- `requires`: `["81a45dec-37be-529b-89ce-2f3101237293","77604656-7ffe-516c-8af3-7cbe7de2f2a4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"E"}}`

## 208. Entropieaussagen mit Systemgrenzen und Mikrozuständen prüfen

- ID: `161502b8-e52d-58d0-8f01-9f777b56d392`
- Beschreibung: Die lernende Person kann Aussagen über eine lokale Entropieabnahme anhand klarer Systemgrenzen und zugehöriger Mikrozustände beurteilen und begründen, warum sie dem zweiten Hauptsatz für das isolierte Gesamtsystem nicht widersprechen muss; eine bloß optisch geordnete Anordnung genügt nicht als Entropiemaß.
- `requires`: `["616ac6cf-901b-509a-8cbb-bd422ddecf05","77604656-7ffe-516c-8af3-7cbe7de2f2a4","14099861-897c-53f4-8c6c-48d088ee9f01"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE","LI_TECHNIK"],"phase":"E"}}`

## 209. Zweiten Hauptsatz auf Entropieerzeugung und Zeitpfeil anwenden

- ID: `91b20476-12cf-50d6-880a-ea509ffe8a9a`
- Beschreibung: Die lernende Person kann bei einfachen irreversiblen Prozessen eines isolierten Gesamtsystems die Entropieerzeugung mit $\Delta S_{\mathrm{ges}}>0$ begründen und die damit ausgezeichnete Richtung makroskopischer Abläufe als thermodynamischen Zeitpfeil erklären.
- `requires`: `["be921c3b-7db9-50b5-a110-92f31673fc62","616ac6cf-901b-509a-8cbb-bd422ddecf05"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 210. Zweiten Hauptsatz auf Wärmekraftmaschinen anwenden

- ID: `18058384-a1bc-5ba2-8f5d-1fe9498acbf0`
- Beschreibung: Die lernende Person kann mit dem zweiten Hauptsatz erklären, warum eine zyklische Wärmekraftmaschine zwischen einem heißen und einem kalten Reservoir mit jeweils konstanter Temperatur Abwärme abgeben muss, und die Carnot-Grenze als maximal möglichen Wirkungsgrad bei diesen Temperaturen im reversiblen Grenzfall qualitativ deuten.
- `requires`: `["d0cebf18-8b2a-52d6-857d-ef18cd64541c","81a45dec-37be-529b-89ce-2f3101237293"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 211. Bewertung von Energiesparmaßnahmen und Klimawandel

- ID: `5e7c8fdb-8027-5a54-9e43-e1100da6fbdb`
- Beschreibung: Cluster zur fachlichen Bewertung von Energieeffizienzmaßnahmen und deren klimapolitischer Einordnung.
- `requires`: `[]`
- `contains`: `["aed9161b-ddc4-559c-be8f-baeeddf224f3","f322c268-dc16-5d50-82dd-209834f20208"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 212. Energiesparmaßnahmen physikalisch bewerten

- ID: `aed9161b-ddc4-559c-be8f-baeeddf224f3`
- Beschreibung: Die lernende Person kann Energiesparmaßnahmen mit Wirkungsgraden, Energieumwandlungen und Verlustmechanismen physikalisch bewerten.
- `requires`: `["f7f2c254-1663-5861-bed7-a32c00495b19","cbb26ed2-6979-46f6-a4ae-128f5c5d9d76"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 213. Klimawirkungen von Energieentscheidungen fachlich diskutieren

- ID: `f322c268-dc16-5d50-82dd-209834f20208`
- Beschreibung: Die lernende Person kann die Klimawirkungen vorgegebener Energieentscheidungen anhand physikalischer Bewertungsdaten fachlich begründet diskutieren, indem sie Bezugsgröße und Bilanzgrenze offenlegt und erklärt, wie Annahmen und Unsicherheiten den Vergleich beeinflussen.
- `requires`: `["aed9161b-ddc4-559c-be8f-baeeddf224f3","cbdc0b5f-8a48-5ade-be53-ab6aacaa3e73"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 214. Thermodynamische Prozessrechnung

- ID: `e9e6d534-dac3-5389-959e-3b2030edcd68`
- Beschreibung: Cluster zur quantitativen Thermodynamik in der E-Phase: Zustandsgleichung, Zustandsänderungen, Prozessarbeit, Wärmemengen, Energiebilanz und Wirkungsgradvergleich.
- `requires`: `[]`
- `contains`: `["cd1903a5-d70a-5320-9124-b6b24917ba14","fb73c94b-6a23-5351-8fef-db2c2533e361","7fe3022f-fad0-5f41-af1c-d55ff214ebc6","7982cd8e-2151-59e7-858d-c1361c5d249e","93ece389-78c5-5141-9ef1-c68bd558306e","23c5382a-4b0f-5715-84b5-cf87b8323152","73b5af24-7750-520a-bb16-43136ce19a5c"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 215. Zustandsgrößen und ideales Gasgesetz anwenden

- ID: `cd1903a5-d70a-5320-9124-b6b24917ba14`
- Beschreibung: Die lernende Person kann für ein ideales Gas Druck p, Volumen V, absolute Temperatur T und Stoffmenge n in SI-Einheiten verwenden, ihren Zusammenhang pV = nRT erklären, eine fehlende Zustandsgröße bestimmen und das Ergebnis anhand der Einheit und der erwarteten Größenordnung auf Plausibilität prüfen.
- `requires`: `["88d07c80-5d7d-5c70-b385-b22769381e44"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 216. Isochore, isobare und isotherme Zustandsänderungen berechnen

- ID: `fb73c94b-6a23-5351-8fef-db2c2533e361`
- Beschreibung: Die lernende Person kann isochore (V konstant), isobare (p konstant) und isotherme (T konstant) Zustandsänderungen einer festen Stoffmenge eines idealen Gases anhand der jeweils konstanten Zustandsgröße unterscheiden, den passenden Zusammenhang der übrigen Größen begründen und damit fehlende Größen bestimmen.
- `requires`: `["cd1903a5-d70a-5320-9124-b6b24917ba14"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 217. Adiabatische Zustandsänderungen

- ID: `7fe3022f-fad0-5f41-af1c-d55ff214ebc6`
- Beschreibung: Die lernende Person kann adiabatische Zustandsänderungen eines idealen Gases als Prozesse ohne Wärmeaustausch über die Systemgrenze beschreiben, qualitativ erklären, wie Arbeit bei Kompression oder Expansion die innere Energie und Temperatur verändert, sowie idealisierte quasistatische Verläufe im p-V-Diagramm skizzieren und von isothermen Zustandsänderungen abgrenzen.
- `requires`: `["fb73c94b-6a23-5351-8fef-db2c2533e361"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_ENERGIE"],"phase":"E"}}`

## 218. Prozessarbeit bei Volumenänderungen bestimmen

- ID: `7982cd8e-2151-59e7-858d-c1361c5d249e`
- Beschreibung: Die lernende Person kann die Prozessarbeit bei Volumenänderungen in einfachen Fällen, insbesondere bei isobaren Prozessen, mit einer ausgewiesenen Vorzeichenkonvention berechnen, im p-V-Diagramm als vorzeichenbehaftete Fläche unter dem Prozessweg deuten und das Vorzeichen aus der Prozessrichtung begründen.
- `requires`: `["fb73c94b-6a23-5351-8fef-db2c2533e361","c1c71daa-042b-4f4c-8c31-0ac366f5149e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE"],"phase":"E"}}`

## 219. Wärmemengen mit C_V und C_P berechnen

- ID: `93ece389-78c5-5141-9ef1-c68bd558306e`
- Beschreibung: Die lernende Person kann bei isochoren beziehungsweise isobaren Prozessen die übertragene Wärmemenge mit Q = n·C_V·ΔT beziehungsweise Q = n·C_P·ΔT unter der Annahme näherungsweise konstanter molarer Wärmekapazitäten berechnen und erklären, warum die passende Wärmekapazität von der Prozessbedingung abhängt.
- `requires`: `["fb73c94b-6a23-5351-8fef-db2c2533e361"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"E"}}`

## 220. Ersten Hauptsatz in Prozessen quantitativ bilanzieren

- ID: `23c5382a-4b0f-5715-84b5-cf87b8323152`
- Beschreibung: Die lernende Person kann für einfache Gasprozesse Energiegrößen konsistent bilanzieren (Q, W, ΔU) und den ersten Hauptsatz rechnerisch anwenden.
- `requires`: `["7982cd8e-2151-59e7-858d-c1361c5d249e","93ece389-78c5-5141-9ef1-c68bd558306e","5f17e992-fd07-56ee-80a0-567f45bbd10c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE"],"phase":"E"}}`

## 221. Wirkungsgrad und Carnot-Grenze quantitativ vergleichen

- ID: `73b5af24-7750-520a-bb16-43136ce19a5c`
- Beschreibung: Die lernende Person kann den Wirkungsgrad einer realen zyklischen Wärmekraftmaschine aus Messdaten bestimmen, mit der Carnot-Grenze für dieselben heißen und kalten Reservoirtemperaturen vergleichen und Abweichungen unter Berücksichtigung von Irreversibilitäten und Messunsicherheiten physikalisch beurteilen.
- `requires`: `["23c5382a-4b0f-5715-84b5-cf87b8323152","18058384-a1bc-5ba2-8f5d-1fe9498acbf0"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"E"}}`

## 222. Drehbewegungen

- ID: `9743baad-9371-52b6-98ee-72bc6dc68701`
- Beschreibung: Cluster zu Drehbewegungen: Drehmoment, Drehimpuls als Erhaltungsgröße, Trägheitsmoment, Präzession und anwendungsbezogene Beispiele.
- `requires`: `[]`
- `contains`: `["cf570e66-2ce2-5923-9033-c97d74119553","37f17e7e-9fcf-5dca-ac10-e94cb8420be5","642aebd7-66cd-5a50-b543-73c4b207525d","5a951a0b-fd6c-51a1-9ffb-2a34ed6d3931","c2c3cdc5-3e87-47c4-89fd-4eb2c5c2f2ea","b49e0f6b-df2a-5643-b3ce-a9dfdf25f3bc","7c33dae8-f57a-51a1-a1b4-75ee6d5b200e"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 223. Drehmoment beschreiben

- ID: `cf570e66-2ce2-5923-9033-c97d74119553`
- Beschreibung: Die lernende Person kann das Drehmoment als Maß für die Drehwirkung einer Kraft definieren, berechnen und an einfachen Hebel- und Alltagsbeispielen anwenden.
- `requires`: `["accb1d9e-cd48-5983-bcef-9b9bca4a9114"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 224. Drehimpuls als Erhaltungsgröße

- ID: `37f17e7e-9fcf-5dca-ac10-e94cb8420be5`
- Beschreibung: Die lernende Person kann den Drehimpuls definieren, seine Erhaltung bei drehmomentfreien Vorgängen erläutern und einfache Beispiele (z. B. Pirouette) qualitativ deuten.
- `requires`: `["cf570e66-2ce2-5923-9033-c97d74119553","839ecc8f-3a60-418b-bc92-64bfeef33824"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 225. Trägheitsmoment und Rotationsenergie

- ID: `642aebd7-66cd-5a50-b543-73c4b207525d`
- Beschreibung: Die lernende Person kann den Begriff des Trägheitsmoments qualitativ erklären, einfache Beispiele vergleichen und den Zusammenhang mit Rotationsenergie herstellen.
- `requires`: `["37f17e7e-9fcf-5dca-ac10-e94cb8420be5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 226. Rotationsenergie bestimmen

- ID: `5a951a0b-fd6c-51a1-9ffb-2a34ed6d3931`
- Beschreibung: Die lernende Person kann aus Trägheitsmoment und Winkelgeschwindigkeit die Rotationsenergie bestimmen.
- `requires`: `["642aebd7-66cd-5a50-b543-73c4b207525d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"phase":"E"}}`

## 227. Mittleres Beschleunigungsmoment bestimmen

- ID: `c2c3cdc5-3e87-47c4-89fd-4eb2c5c2f2ea`
- Beschreibung: Die lernende Person kann bei konstantem Trägheitsmoment aus einer vorgegebenen mittleren Winkelbeschleunigung das mittlere resultierende Drehmoment bestimmen und seine beschleunigende oder bremsende Wirkung deuten.
- `requires`: `["642aebd7-66cd-5a50-b543-73c4b207525d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E"}}`

## 228. Präzessionsbewegungen erklären

- ID: `b49e0f6b-df2a-5643-b3ce-a9dfdf25f3bc`
- Beschreibung: Die lernende Person kann die Präzession von Kreiseln oder Gyroskopen qualitativ als Änderung der Drehimpulsrichtung durch ein äußeres Drehmoment erklären und von der Drehimpulserhaltung ohne äußeres Drehmoment abgrenzen.
- `requires`: `["642aebd7-66cd-5a50-b543-73c4b207525d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 229. Anwendungsbeispiele für Drehbewegungen deuten

- ID: `7c33dae8-f57a-51a1-a1b4-75ee6d5b200e`
- Beschreibung: Cluster zu kontextspezifischen Deutungen von Drehbewegungen in Sport und Technik.
- `requires`: `[]`
- `contains`: `["21c0a5f2-4152-549a-aa9c-e02ab772f589","8daaf751-93fe-56d9-8697-ac30237061bd","07f298b2-2f5e-5b16-8150-bc603fa78ecd"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 230. Pirouetten mit Drehimpuls deuten

- ID: `21c0a5f2-4152-549a-aa9c-e02ab772f589`
- Beschreibung: Die lernende Person kann Pirouetten durch Erhaltung des Drehimpulses und Änderungen des Trägheitsmoments qualitativ erklären.
- `requires`: `["37f17e7e-9fcf-5dca-ac10-e94cb8420be5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 231. Fahrraddynamik mit Kreiselwirkung erklären

- ID: `8daaf751-93fe-56d9-8697-ac30237061bd`
- Beschreibung: Die lernende Person kann Stabilität und Lenkverhalten von Fahrrädern mit Drehmomenten und Kreiselwirkung qualitativ deuten.
- `requires`: `["b49e0f6b-df2a-5643-b3ce-a9dfdf25f3bc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 232. Kreiselstabilisierung technisch begründen

- ID: `07f298b2-2f5e-5b16-8150-bc603fa78ecd`
- Beschreibung: Die lernende Person kann Kreiselstabilisierung in technischen Anwendungen mithilfe von Drehimpuls- und Drehmomentargumenten begründen.
- `requires`: `["8daaf751-93fe-56d9-8697-ac30237061bd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"E"}}`

## 233. Q1 Elektrisches und magnetisches Feld

- ID: `0735269d-703d-57ab-8861-6f7e1c5e2b8a`
- Beschreibung: Grundlagen des elektrischen und magnetischen Feldbegriffs inklusive Feldstärken, Energiespeichern und Ladungsbewegungen.
- `requires`: `[]`
- `contains`: `["d7bc20e0-5ee9-593a-a7a9-d7cbb88392e6","13e882bd-2fc6-59c6-a2a8-32eb1fbf1751","69f0038a-6e2b-55b5-8ff0-d2ea8852e793","549a427d-f10a-5537-990e-6fdd7466848b"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"basicConcepts":["KONZEPT_SUPERPOSITION","KONZEPT_ERHALTUNG_GLEICHGEWICHT"],"phase":"Q1"}}`

## 234. Lernkarten - Q1

- ID: `69f0038a-6e2b-55b5-8ff0-d2ea8852e793`
- Beschreibung: Die lernende Person kann zentrale Fachbegriffe und Definitionen aus Q1 (elektrische und magnetische Felder) mithilfe von Lernkarten sicher abrufen.
- `requires`: `["8da5c981-8216-5fcd-a393-19f392ae2006","8c9394cb-f54a-508d-9750-4c49e31b3fa9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","nodeKind":"memory","tags":["GK","LK","srs-deck:de_gymnasium_physics_fields_q1","memorization"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 235. Elektrisches Feld

- ID: `d7bc20e0-5ee9-593a-a7a9-d7cbb88392e6`
- Beschreibung: Cluster zum elektrischen Feld: radialsymmetrische und homogene Felder, Superposition, Kondensator als Energiespeicher sowie Kräfte auf geladene Teilchen.
- `requires`: `[]`
- `contains`: `["7df599e8-21ac-5be4-89f9-9b2a6f2e4465","0895074d-c4af-56ea-88dd-ae0fdae443ed","43eb9b9e-cfdf-5cf1-88db-87391c7ba595"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 236. Grundlagen des elektrischen Feldes

- ID: `7df599e8-21ac-5be4-89f9-9b2a6f2e4465`
- Beschreibung: Cluster zu Ladung, elektrischer Kraft und Vektorfeld: vom Ladungsphänomen über das Coulomb'sche Gesetz bis zur Superposition elektrischer Felder.
- `requires`: `[]`
- `contains`: `["a6e48b88-51ed-5942-bdb8-8d2192652e0d","25998fed-ea4d-4c3e-b606-e965b5d7f290","bbee4c52-4e95-5529-990f-706aa99316a3","8da5c981-8216-5fcd-a393-19f392ae2006","98e42cda-9e5d-5910-b2c0-3e631fd20c78","f3de5922-dd45-4fb6-87c1-525d1952dd89","9fb1dd85-11b7-4a5a-b124-27fea8d1788e","4ca83b3f-3605-5c0d-abc4-9f24b9e29bbe","455c65ca-814a-56ad-918a-013155883c52"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 237. Potenzial und Kondensator

- ID: `0895074d-c4af-56ea-88dd-ae0fdae443ed`
- Beschreibung: Cluster zur Energetik des elektrischen Feldes: Arbeit, Spannung und Potenzial als Grundlage für Kapazität, Feldenergie sowie Auf- und Entladevorgänge.
- `requires`: `[]`
- `contains`: `["1730c01d-8c85-57df-b031-c11e2a0511b1","2622bef1-bdbc-504e-b468-b600b2ca3ed8","8fca14c7-3251-5526-adde-2567ea6816b2","fd9fd8ad-c4a1-5552-9ea0-1878e0636f20"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 238. Ladungen in Feldern

- ID: `43eb9b9e-cfdf-5cf1-88db-87391c7ba595`
- Beschreibung: Cluster zu Anwendungen elektrischer Felder auf bewegte Ladungen: vom Millikan-Versuch bis zur Modellierung technischer Beschleuniger- und Ablenksysteme.
- `requires`: `[]`
- `contains`: `["0f803c37-8191-5a07-9b31-9603ded98fe2","47f76c5c-05d1-59eb-876d-cafb98a66c5b"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"Q1"}}`

## 239. Ladungsphänomene und Reibungselektrizität

- ID: `a6e48b88-51ed-5942-bdb8-8d2192652e0d`
- Beschreibung: Die lernende Person kann Anziehung und Abstoßung elektrisch geladener Körper sowie Ladungstrennung durch Reibung phänomenologisch untersuchen und die beobachteten Wechselwirkungen mit einem qualitativen Kraftbegriff beschreiben.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Phenomenon"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 240. Elektrische Stromstärke als Ladungsrate deuten

- ID: `bbee4c52-4e95-5529-990f-706aa99316a3`
- Beschreibung: Die lernende Person kann die mittlere elektrische Stromstärke als durch einen Querschnitt transportierte Ladung pro Zeitintervall mit I = ΔQ/Δt deuten, Berechnungen durchführen und den Einheitenzusammenhang 1 A = 1 C/s erklären.
- `requires`: `["a6e48b88-51ed-5942-bdb8-8d2192652e0d","ae20183e-92b5-5521-b8e0-9a8662cf51f5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 241. Coulomb'sches Gesetz

- ID: `8da5c981-8216-5fcd-a393-19f392ae2006`
- Beschreibung: Die lernende Person kann die elektrische Kraft zwischen Punktladungen quantitativ mit dem Coulomb'schen Gesetz berechnen und den Zusammenhang zur Feldstärke begründen.
- `requires`: `["bbee4c52-4e95-5529-990f-706aa99316a3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 242. Radialsymmetrische elektrische Felder beschreiben

- ID: `98e42cda-9e5d-5910-b2c0-3e631fd20c78`
- Beschreibung: Die lernende Person kann das elektrische Feld einer Punktladung beziehungsweise den Außenraum einer kugelsymmetrischen Ladungsverteilung durch radiale Feldrichtung und Feldliniendichte beschreiben und die Abnahme der Feldstärke mit E ∝ 1/r² qualitativ begründen.
- `requires`: `["8da5c981-8216-5fcd-a393-19f392ae2006"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q1"}}`

## 243. Superposition elektrischer Felder

- ID: `4ca83b3f-3605-5c0d-abc4-9f24b9e29bbe`
- Beschreibung: Die lernende Person kann elektrische Felder durch grafische Addition von Feldstärkevektoren überlagern und einfache Superpositionssituationen qualitativ auswerten.
- `requires`: `["98e42cda-9e5d-5910-b2c0-3e631fd20c78","c63bbffd-8d1c-5fe2-a428-db194e6fe592"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q1"}}`

## 244. Arbeit, Spannung und Potenzial im E-Feld

- ID: `1730c01d-8c85-57df-b031-c11e2a0511b1`
- Beschreibung: Die lernende Person kann die Spannung zwischen zwei Punkten als Potenzialdifferenz und – bei offengelegter Vorzeichenkonvention – über Arbeit beziehungsweise Änderung der potenziellen Energie pro Ladung deuten und im homogenen elektrischen Feld für einen Abstand parallel zu den Feldlinien den Betragszusammenhang |U| = E·d anwenden.
- `requires`: `["bbee4c52-4e95-5529-990f-706aa99316a3","c1c71daa-042b-4f4c-8c31-0ac366f5149e","f08d06dc-139d-5fd2-892c-8cc919b1e4fc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 245. Kondensator

- ID: `8fca14c7-3251-5526-adde-2567ea6816b2`
- Beschreibung: Cluster zum Kondensator: Feld und Kapazität des Plattenkondensators, Polarisation und Dielektrika, Auf- und Entladevorgänge sowie die Modellierung über die Differentialgleichung des RC-Kreises.
- `requires`: `[]`
- `contains`: `["9f59a088-3939-59e9-821d-167fadfda782","e3bce51c-cfeb-4706-b95e-a22b76e7dd73","38e0ff49-f132-44c8-b17a-73dada5344db","0b4f2020-8486-5372-9cb9-6e59f698ac2d","73b309ed-1aab-5778-8494-d9b65f5a352b","330808f6-789a-583d-86df-e271a7683d8b","09f2cdbd-64e0-55d2-ada7-1190f4fd50df"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 246. Kondensator und Feld im Plattenkondensator

- ID: `9f59a088-3939-59e9-821d-167fadfda782`
- Beschreibung: Die lernende Person kann das Feld eines idealisierten Plattenkondensators fern von Randeffekten als homogen beschreiben, seine Feldstärke bestimmen und bei vollständiger Füllung mit einem homogenen Dielektrikum die Kapazität mit $C=\varepsilon_0\varepsilon_r\frac{A}{d}$ berechnen sowie ihre Abhängigkeit von Geometrie und Dielektrikum erläutern.
- `requires`: `["1730c01d-8c85-57df-b031-c11e2a0511b1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q1"}}`

## 247. Auf- und Entladen eines Kondensators

- ID: `0b4f2020-8486-5372-9cb9-6e59f698ac2d`
- Beschreibung: Die lernende Person kann elektrische Stromstärke als durch einen Leiterquerschnitt transportierte Ladung pro Zeitintervall deuten, Richtung und zeitlichen Verlauf des Stroms beim Auf- und Entladen eines Kondensators qualitativ erklären und vorhersagen, wie bei gleicher Anfangsspannung ein größerer Widerstand den Betrag des Anfangsstroms verringert und wie das Produkt aus Widerstand und Kapazität die charakteristische Lade- beziehungsweise Entladezeit festlegt.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q1"}}`

## 248. Energie des elektrischen Feldes

- ID: `fd9fd8ad-c4a1-5552-9ea0-1878e0636f20`
- Beschreibung: Die lernende Person kann die im elektrischen Feld eines Kondensators gespeicherte Energie mithilfe von Ladung, Spannung und Kapazität berechnen und an Anwendungen erläutern, wie beim Laden Energie in das Feld übertragen und beim Entladen an angeschlossene Systeme abgegeben wird.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q1"}}`

## 249. Millikan-Versuch und Elementarladung

- ID: `0f803c37-8191-5a07-9b31-9603ded98fe2`
- Beschreibung: Die lernende Person kann den Millikan-Versuch im Schwebefall erläutern und damit die Quantelung elektrischer Ladung über die Elementarladung e begründen.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Experiment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER","LI_MATERIE"],"phase":"Q1"}}`

## 250. Bewegung geladener Teilchen im elektrischen Feld

- ID: `47f76c5c-05d1-59eb-876d-cafb98a66c5b`
- Beschreibung: Die lernende Person kann Kräfte auf geladene Teilchen in homogenen elektrischen Feldern berechnen, Bahnformen qualitativ beschreiben und Experimente wie den Millikan-Versuch deuten.
- `requires`: `[]`
- `contains`: `["741774ef-15fc-4bcf-a370-e2c5cf4257d0","5fda8623-69e0-5503-9c6d-86d054a8cf91","74a74132-fa39-541c-8d3c-696cf228452d","8d34228c-da38-5c1e-97cc-571f3eafb9f4"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q1"}}`

## 251. Geladene Teilchen in homogenen elektrischen Feldern untersuchen

- ID: `741774ef-15fc-4bcf-a370-e2c5cf4257d0`
- Beschreibung: Die lernende Person kann die Bewegung geladener Teilchen in homogenen elektrischen Feldern untersuchen, die Richtung der Feldkraft aus Feldrichtung und Ladungsvorzeichen bestimmen, Änderungen der elektrischen potenziellen und kinetischen Energie miteinander verknüpfen und einfache Bahnformen aus Anfangsbewegung, Ladungsvorzeichen und Feldrichtung qualitativ deuten.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782","5f289cdc-fda1-4058-b44f-041ba1398e79"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 252. Braunsche Röhre (Oszilloskop)

- ID: `5fda8623-69e0-5503-9c6d-86d054a8cf91`
- Beschreibung: Die lernende Person kann erklären, wie in der Braunschen Röhre das von einer Ablenkspannung erzeugte elektrische Feld die vertikale Lage des Elektronenstrahls auf dem Leuchtschirm bestimmt und eine Zeitbasis den Strahl horizontal führt, sodass ein Oszilloskop den zeitlichen Spannungsverlauf darstellt; eine magnetische Ablenkung kann sie davon qualitativ unterscheiden.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782","5f289cdc-fda1-4058-b44f-041ba1398e79"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"Q1"}}`

## 253. Magnetisches Feld

- ID: `13e882bd-2fc6-59c6-a2a8-32eb1fbf1751`
- Beschreibung: Cluster zum magnetischen Feld: Feldlinienbilder, magnetische Flussdichte, Kräfte auf Körper und Ladungen im Feld sowie technische Anwendungen.
- `requires`: `[]`
- `contains`: `["ed6cfd98-38fa-59c3-af0d-0f9f61d52d25","6a955b34-1b90-5193-8f7e-ebb777f7b7bd","c0634f78-efb9-51cb-ad4f-0e0e4d18bad0"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 254. Grundlagen und Entstehung des Magnetfeldes

- ID: `ed6cfd98-38fa-59c3-af0d-0f9f61d52d25`
- Beschreibung: Cluster zu den Grundlagen des magnetischen Feldes: Feldlinienbilder, Definition der Flussdichte über die Kraft auf Leiterstücke, Entstehung von Magnetfeldern durch Ströme (Leiter/Spule) und vereinfachte Oberstufenmodelle für Permanentmagnete.
- `requires`: `[]`
- `contains`: `["0f6b798b-594e-5480-8c5f-95e2486a4d85","c6355a22-24cf-5d8b-88af-ea11711460fb","106417ed-80db-5490-a1ee-bb4160d3f2b4","0924162b-46d0-5c56-93bc-33e1f5ac6886"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 255. Gaußsches Verfahren anwenden

- ID: `58db62d4-458f-5e2d-9ca0-968e09f4944b`
- Beschreibung: Die lernende Person kann das Messverfahren von Gauß (Ablenkungsmethode in Hauptlage und Schwingungsmethode) zur Bestimmung der Horizontalintensität des Erdmagnetfeldes beschreiben und anwenden.
- `requires`: `["d02438ba-0cc9-5993-831e-5e44d35e32c4","76478e47-5ff9-5de1-b601-5e6e436ad855","f8704a7b-e93d-4e32-b0f9-1b171545fe28"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method","Measurement"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 256. Drehmoment auf Magnetnadeln und Dipole

- ID: `d02438ba-0cc9-5993-831e-5e44d35e32c4`
- Beschreibung: Die lernende Person kann das Drehmoment auf Magnetnadeln und magnetische Dipole im homogenen Feld mit M = mu * B * sin(alpha) berechnen und die Ausrichtung im Feld fachlich begründen.
- `requires`: `["c6355a22-24cf-5d8b-88af-ea11711460fb","cf570e66-2ce2-5923-9033-c97d74119553"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 257. Mikroskopische und makroskopische Wirkung magnetischer Felder

- ID: `6a955b34-1b90-5193-8f7e-ebb777f7b7bd`
- Beschreibung: Cluster zur Wirkung magnetischer Felder: Lorentzkraft auf freie Ladungen, quantitative Bahnformen und Drehmoment auf Magnetnadeln/Dipole.
- `requires`: `[]`
- `contains`: `["9854589c-5feb-4942-b90f-311ddf36eb78","8c9394cb-f54a-508d-9750-4c49e31b3fa9","3b866aea-3e4d-5f23-91de-759148382710","d02438ba-0cc9-5993-831e-5e44d35e32c4","7fe6f8a1-5580-4e37-bf8e-9772964a6b0a"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_BEWEGUNG"],"phase":"Q1"}}`

## 258. Geladene Teilchen in homogenen magnetischen Feldern untersuchen

- ID: `9854589c-5feb-4942-b90f-311ddf36eb78`
- Beschreibung: Die lernende Person kann vorgegebene oder simulierte Bahnen geladener Teilchen in homogenen Magnetfeldern mithilfe der Lorentzkraft vergleichen, aus Feldrichtung und Umlaufsinn das Ladungsvorzeichen erschließen und für Bewegungen senkrecht zur Feldrichtung unter sonst gleichen Bedingungen aus Krümmungsvergleichen qualitative Auswirkungen von Änderungen der Masse, Geschwindigkeit oder Feldstärke ableiten.
- `requires`: `["8c9394cb-f54a-508d-9750-4c49e31b3fa9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 259. Magnetische Felder und Feldlinienbilder

- ID: `0f6b798b-594e-5480-8c5f-95e2486a4d85`
- Beschreibung: Die lernende Person kann typische magnetische Felder von Permanentmagneten, geraden stromdurchflossenen Leitern und langen Spulen durch Feldlinienbilder darstellen und diese als Modellbilder deuten, in denen die Tangentenrichtung die Feldrichtung und die Liniendichte innerhalb einer Darstellung die relative Feldstärke codiert.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q1"}}`

## 260. Magnetfeldmodelle für geraden Leiter und lange Spule auswählen und anwenden

- ID: `106417ed-80db-5490-a1ee-bb4160d3f2b4`
- Beschreibung: Die lernende Person kann für einen idealisierten langen geraden stromdurchflossenen Leiter in Luft und für das Innere einer idealisierten langen Spule mit homogenem linearem Kern das passende Magnetfeldmodell auswählen, den Betrag mit B = μ₀ · I/(2πr) beziehungsweise B ≈ μ₀ · μᵣ · (N/ℓ) · I bestimmen, die Richtung mit der Rechte-Hand-Regel angeben und die unterschiedlichen Gültigkeitsgrenzen begründen.
- `requires`: `["0f6b798b-594e-5480-8c5f-95e2486a4d85","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q1"}}`

## 261. Kraft auf stromdurchflossene Leiter

- ID: `c6355a22-24cf-5d8b-88af-ea11711460fb`
- Beschreibung: Die lernende Person kann Betrag und Richtung der Kraft auf ein gerades stromdurchflossenes Leiterstück im homogenen Magnetfeld mit F = B · I · ℓ · sin(α) bestimmen, wobei α der Winkel zwischen Strom- und Feldrichtung ist, und bei senkrechter Anordnung B aus einer Kraftmessung mit B = F/(I · ℓ) ermitteln.
- `requires`: `["0f6b798b-594e-5480-8c5f-95e2486a4d85","71a483ba-9680-4654-bb5e-5ab5427f0919","af3d6bff-c5fb-4ec6-a9f0-c0be09fc9186"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q1"}}`

## 262. Lorentzkraft auf freie Ladungen

- ID: `8c9394cb-f54a-508d-9750-4c49e31b3fa9`
- Beschreibung: Die lernende Person kann den Betrag der magnetischen Lorentzkraft auf frei bewegte Ladungen mit $F_L=|q|vB\sin(\alpha)$ berechnen, ihre Richtung aus $\vec v\times\vec B$ unter Beachtung des Ladungsvorzeichens bestimmen und unter Vernachlässigung anderer Kräfte für die Grenzfälle eines parallelen oder senkrechten Eintritts in ein homogenes Magnetfeld die geradlinige beziehungsweise kreisförmige Bahn qualitativ deuten.
- `requires`: `["0f6b798b-594e-5480-8c5f-95e2486a4d85","71a483ba-9680-4654-bb5e-5ab5427f0919","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q1"}}`

## 263. Technische Anwendungen magnetischer Felder

- ID: `c0634f78-efb9-51cb-ad4f-0e0e4d18bad0`
- Beschreibung: Cluster zur Synthese: Gauß-Verfahren zur Magnetfeldmessung, Hall-Effekt (LK), Fadenstrahlrohr als Elektronen-Messverfahren, Teilchenbeschleuniger (Zyklotron/Synchrotron, LK) und Kernspintomografie (MRT).
- `requires`: `[]`
- `contains`: `["58db62d4-458f-5e2d-9ca0-968e09f4944b","b39ae8fb-4358-5866-8adf-3d5365368eeb","966782e5-690d-4fae-bbab-fa3fa30525c3","2d62b444-796e-548d-aeee-cfd9c6665ddc","52bdabb2-d9a1-56e6-bccf-ff58f299c739","3f17d0d2-562d-4c1c-9ebc-1a1a43f28f9c","eb30189c-27c6-510b-b235-6543afa18b90","af1094c1-511a-5aae-9e0a-3e9196a82d9a"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"Q1"}}`

## 264. Kernspintomografie (MRT)

- ID: `52bdabb2-d9a1-56e6-bccf-ff58f299c739`
- Beschreibung: Die lernende Person kann qualitativ erklären, wie ein statisches Magnetfeld eine Netto-Kernspinmagnetisierung ausrichtet, eine resonante Hochfrequenzanregung sie auslenkt und Magnetfeldgradienten die bei der Relaxation gemessenen Signale räumlich für ein MRT-Bild codieren.
- `requires`: `["0924162b-46d0-5c56-93bc-33e1f5ac6886"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"Q1"}}`

## 265. Übungen Q1

- ID: `549a427d-f10a-5537-990e-6fdd7466848b`
- Beschreibung: Buendelt materialgestuetzte Q1-Klausuraufgaben mit normalem Klausurcharakter zu elektrischen und magnetischen Feldern. Abiturvorschlaege bleiben davon getrennt modelliert.
- `requires`: `[]`
- `contains`: `["841edfdb-5e12-5a37-ab12-552a1d8e92ca","783c1ffe-d983-5c5a-8897-2c88fc64147c","5e64eacd-5204-5028-af23-02a43377c56e","db5f4121-d4b1-5006-b2da-6e76aac72bf5","72ee642f-7574-517e-abd6-17d699b05af6","ba29e928-a287-5de7-b3fe-5c8c3731363b","d8442d03-8b7e-54b7-9d9a-dc31ce541daa","d441ee2f-9230-5751-832b-5b0b5cf14605"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_TECHNIK","LI_MATERIE"],"phase":"Q1"}}`

## 266. Elektrostatik und Potenzial

- ID: `841edfdb-5e12-5a37-ab12-552a1d8e92ca`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q1-Klausuraufgabe zu Coulomb-Kraft, Feldlinien, Superposition, Spannung und elektrischem Potenzial selbstaendig bearbeiten und fachlich auswerten.
- `requires`: `["455c65ca-814a-56ad-918a-013155883c52","1730c01d-8c85-57df-b031-c11e2a0511b1","2622bef1-bdbc-504e-b468-b600b2ca3ed8","25998fed-ea4d-4c3e-b606-e965b5d7f290","f3de5922-dd45-4fb6-87c1-525d1952dd89","9fb1dd85-11b7-4a5a-b124-27fea8d1788e","e3bce51c-cfeb-4706-b95e-a22b76e7dd73"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q1","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 267. Kondensator, Feldenergie und Millikan-Versuch

- ID: `783c1ffe-d983-5c5a-8897-2c88fc64147c`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q1-Klausuraufgabe zu Plattenkondensator, Auf- und Entladung, Feldenergie und dem Millikan-Versuch selbstaendig bearbeiten.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782","0b4f2020-8486-5372-9cb9-6e59f698ac2d","fd9fd8ad-c4a1-5552-9ea0-1878e0636f20","0f803c37-8191-5a07-9b31-9603ded98fe2","e3bce51c-cfeb-4706-b95e-a22b76e7dd73","38e0ff49-f132-44c8-b17a-73dada5344db"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q1","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_MATERIE"],"phase":"Q1"}}`

## 268. RC-Kreis und Dielektrika modellieren

- ID: `5e64eacd-5204-5028-af23-02a43377c56e`
- Beschreibung: Die lernende Person kann eine LK-orientierte Q1-Klausuraufgabe zu Dielektrika, Modellannahmen und der Differentialgleichung des RC-Kreises selbstaendig bearbeiten.
- `requires`: `["73b309ed-1aab-5778-8494-d9b65f5a352b","09f2cdbd-64e0-55d2-ada7-1190f4fd50df","330808f6-789a-583d-86df-e271a7683d8b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q1","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 269. Elektronenablenkung im elektrischen Feld

- ID: `db5f4121-d4b1-5006-b2da-6e76aac72bf5`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q1-Klausuraufgabe zur Elektronenablenkung, zum Oszilloskop und zur Deutung von Teilchenbahnen im elektrischen Feld selbstaendig bearbeiten.
- `requires`: `["5fda8623-69e0-5503-9c6d-86d054a8cf91","0f803c37-8191-5a07-9b31-9603ded98fe2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q1","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"Q1"}}`

## 270. Linearbeschleuniger und Relativitaetsgrenze

- ID: `72ee642f-7574-517e-abd6-17d699b05af6`
- Beschreibung: Die lernende Person kann eine LK-orientierte Q1-Klausuraufgabe zum Linearbeschleuniger, zur Energieübertragung an geladene Teilchen und zur relativistischen Modellgrenze selbstaendig bearbeiten.
- `requires`: `["74a74132-fa39-541c-8d3c-696cf228452d","8d34228c-da38-5c1e-97cc-571f3eafb9f4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q1","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK","LI_ENERGIE"],"phase":"Q1"}}`

## 271. Magnetfeld, Leiterkraft und Lorentzkraft

- ID: `ba29e928-a287-5de7-b3fe-5c8c3731363b`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q1-Klausuraufgabe zu Magnetfeldern, Leiterkraft, magnetischer Flussdichte und Lorentzkraft selbstaendig bearbeiten.
- `requires`: `["c6355a22-24cf-5d8b-88af-ea11711460fb","8c9394cb-f54a-508d-9750-4c49e31b3fa9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q1","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_BEWEGUNG"],"phase":"Q1"}}`

## 272. Magnetische Messverfahren und Technik

- ID: `d8442d03-8b7e-54b7-9d9a-dc31ce541daa`
- Beschreibung: Die lernende Person kann eine LK-orientierte Q1-Klausuraufgabe zu Drehmoment auf Dipole, Gauß-Verfahren, Hall-Effekt und MRT selbstaendig bearbeiten und beurteilen.
- `requires`: `["d02438ba-0cc9-5993-831e-5e44d35e32c4","58db62d4-458f-5e2d-9ca0-968e09f4944b","b39ae8fb-4358-5866-8adf-3d5365368eeb","52bdabb2-d9a1-56e6-bccf-ff58f299c739"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q1","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK","LI_MATERIE"],"phase":"Q1"}}`

## 273. Q2 Schwingungen, Induktion und mechanische Wellen

- ID: `fcefb129-ad4c-50a2-9762-a910caa1af16`
- Beschreibung: Cluster für Schwingungen, Induktion und mechanische Wellen als Grundlage moderner Kommunikationstechnologien.
- `requires`: `[]`
- `contains`: `["aee9676f-7cd6-50f0-a504-fd88ef67b59e","b2b74d0a-575c-5c6b-8e24-b0b0f32c1126","dc38c943-11f6-5f4f-945b-67e330814727","0ceb4400-3e8f-586c-a669-a8877906bd8d","9dd7c596-a751-523c-acba-916f73e900a5"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_ENERGIE"],"basicConcepts":["KONZEPT_SUPERPOSITION","KONZEPT_MATHEMATISIEREN"],"phase":"Q2"}}`

## 274. Lernkarten - Q2

- ID: `0ceb4400-3e8f-586c-a669-a8877906bd8d`
- Beschreibung: Die lernende Person kann zentrale Fachbegriffe und Definitionen aus Q2 (Schwingungen, Induktion, Wellen) mithilfe von Lernkarten sicher abrufen.
- `requires`: `["fcf8580c-ecfd-58ea-bbf5-a1b29c9ecf8e","eb1ea150-ec6c-5000-bce3-f46c820dccf8","cb0ced6d-b7c1-5b7d-9922-8c394f6030e8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","nodeKind":"memory","tags":["GK","LK","srs-deck:de_gymnasium_physics_waves_q2","memorization"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_WELLEN","LI_ENERGIE"],"phase":"Q2"}}`

## 275. Mechanische Schwingungen

- ID: `aee9676f-7cd6-50f0-a504-fd88ef67b59e`
- Beschreibung: Cluster zu mechanischen Schwingungen: harmonische Schwingung, charakteristische Größen, Energieaspekte sowie gedämpfte und erzwungene Schwingungen mit Resonanz.
- `requires`: `[]`
- `contains`: `["d03f1cb6-c224-53db-ad91-76cc7827978d","fcf8580c-ecfd-58ea-bbf5-a1b29c9ecf8e","05af2893-0201-4d7f-985b-272d7b88e26e","78cf6eff-b3bc-5444-9ef8-5d39dae8d17d","e6895bc3-fcbd-59ad-baef-a78c97a13e11","3efa0cda-f55b-5534-8fac-ffe1d312aed1","b2fb9a25-4d26-5cf2-a917-823909dcb6bd","18c1f954-487e-5121-bb18-6c64a82f573d","c0205f47-185c-5e27-b89c-c3ff8809b1d1","4888444f-4520-437a-9ba7-e74e8f8ed129"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_ENERGIE"],"phase":"Q2"}}`

## 276. Harmonische Schwingung verstehen

- ID: `d03f1cb6-c224-53db-ad91-76cc7827978d`
- Beschreibung: Die lernende Person kann eine harmonische Schwingung als sinusförmiges periodisches Modell beschreiben und anhand eines t-s-Diagramms experimentell untersuchen, inwieweit die Bewegung eines Federpendels im linearen Bereich oder eines Fadenpendels bei kleinen Winkelauslenkungen diesem Modell entspricht.
- `requires`: `["e4b38061-1f28-43ad-8371-a3e7c0e81856","46bdcc16-418f-417a-89cf-033d7ae6c8cc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 277. Charakteristische Schwingungsgrößen

- ID: `fcf8580c-ecfd-58ea-bbf5-a1b29c9ecf8e`
- Beschreibung: Die lernende Person kann Auslenkung, Amplitude, Periodendauer und Frequenz einer harmonischen Schwingung definieren, den Zusammenhang $f = 1/T$ erläutern und eine Gleichung für die Auslenkung in Abhängigkeit von der Zeit mithilfe dieser Größen qualitativ deuten.
- `requires`: `["d03f1cb6-c224-53db-ad91-76cc7827978d","5d17ebb4-4e27-4f9c-8d0b-3520f34b2e11"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 278. Lineare Rückstellkraft bei harmonischen Schwingungen beschreiben

- ID: `05af2893-0201-4d7f-985b-272d7b88e26e`
- Beschreibung: Die lernende Person kann die lineare Rückstellkraft als Voraussetzung harmonischer mechanischer Schwingungen beschreiben und das Hooke'sche Gesetz fachlich deuten.
- `requires`: `["45bbdf6b-6372-5b6a-b7e4-be15a0eb4b83","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 279. Energie und Energieerhaltung in Schwingungen

- ID: `78cf6eff-b3bc-5444-9ef8-5d39dae8d17d`
- Beschreibung: Die lernende Person kann bei reibungsfrei idealisierten Schwingungen den Energieaustausch zwischen potenzieller und kinetischer Energie qualitativ und in einfachen Fällen quantitativ beschreiben.
- `requires`: `["fcf8580c-ecfd-58ea-bbf5-a1b29c9ecf8e","7eeff2de-6015-49a6-a96e-a488d886dc9f","6affc2ea-ecd2-4fcd-8877-3ffa15b0425b","f8704a7b-e93d-4e32-b0f9-1b171545fe28"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 280. Gedämpfte Schwingungen beschreiben

- ID: `e6895bc3-fcbd-59ad-baef-a78c97a13e11`
- Beschreibung: Die lernende Person kann gedämpfte mechanische Schwingungen qualitativ beschreiben, den Einfluss der Dämpfung auf die Amplitude erläutern und die Dämpfung als Erweiterung der reibungsfreien Idealisierung einordnen.
- `requires`: `["78cf6eff-b3bc-5444-9ef8-5d39dae8d17d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 281. Erzwungene Schwingungen und Resonanz

- ID: `3efa0cda-f55b-5534-8fac-ffe1d312aed1`
- Beschreibung: Die lernende Person kann erzwungene Schwingungen als Antwort auf eine periodische Anregung beschreiben, Resonanz über das Verhältnis von Anregungs- und Eigenfrequenz erklären und Resonanzkurven für unterschiedliche Dämpfungen qualitativ deuten.
- `requires`: `["e6895bc3-fcbd-59ad-baef-a78c97a13e11"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 282. Induktion und elektromagnetische Schwingungen

- ID: `b2b74d0a-575c-5c6b-8e24-b0b0f32c1126`
- Beschreibung: Cluster zu Induktion und elektromagnetischen Schwingungen: magnetischer Fluss, Induktionsgesetz, Schwingkreis und energetischer Vergleich mechanischer und elektromagnetischer Schwingungen.
- `requires`: `[]`
- `contains`: `["a522c8c0-f3a4-5568-acae-3010ed9feb87","1a037489-3c95-540b-8cae-0acd360358ee","eb1ea150-ec6c-5000-bce3-f46c820dccf8","ac4ba260-6086-5fcc-bea2-c06f1425a1cc","a844895e-2cdc-4665-aad2-a49c62f11759","f36a5946-f2a8-59b8-b3bd-a2f246defa4f","a7255b83-336c-4d42-ba5c-bc2f6248ea36","37f28bc4-def2-57cf-a06b-191dfd228205","fdcd5faf-f9bf-4fa9-87f4-4e22d8d3387c","ffbbf243-c2eb-4330-b050-837de994c130","d18d4190-ddc1-5181-b1b6-e79947b737c2","692db5b6-8be1-5c7b-8307-3a02afb21ea0","a1389d4e-dc97-5557-babe-a31a2bd57217","e5c33afc-a233-50ff-a17f-63c085dfb89c","5f97952e-5ac9-5749-94d0-d1dc50dda358","ef0f2391-fd8e-5ae3-ae86-7adcdd833c7a","e413a352-33c4-53ae-b54a-30e52c3e65ae"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q2"}}`

## 283. Wirbelströme und Waltenhofen-Pendel

- ID: `e5c33afc-a233-50ff-a17f-63c085dfb89c`
- Beschreibung: Die lernende Person kann die Entstehung von Wirbelströmen in massiven Leitern mit Induktionsgesetz und Lenz’scher Regel erklären sowie ihre bremsende Wirkung am Waltenhofen-Pendel und ihre Verringerung durch Blechpakete in Transformatorenkernen begründen.
- `requires`: `["eb1ea150-ec6c-5000-bce3-f46c820dccf8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q2"}}`

## 284. Bewegungsinduktion und Ladungstrennung

- ID: `a522c8c0-f3a4-5568-acae-3010ed9feb87`
- Beschreibung: Die lernende Person kann die Entstehung einer elektrischen Spannung an einem im Magnetfeld bewegten Leiterstück als Folge der Lorentzkraft auf die Leitungselektronen qualitativ erklären.
- `requires`: `["8c9394cb-f54a-508d-9750-4c49e31b3fa9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Phenomenon"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q2"}}`

## 285. Induktion durch Änderung des magnetischen Flusses

- ID: `1a037489-3c95-540b-8cae-0acd360358ee`
- Beschreibung: Die lernende Person kann für ein homogenes Magnetfeld den magnetischen Fluss Φ = B · A · cos(α) durch die von einer Leiterschleife aufgespannte Fläche beschreiben, wobei α der Winkel zwischen Feldrichtung und Flächennormale ist, und qualitativ erklären, dass eine zeitliche Änderung dieses Flusses eine Induktionsspannung hervorruft.
- `requires`: `["a522c8c0-f3a4-5568-acae-3010ed9feb87","80c232f1-8f72-5829-9dbe-5a610ccab3be"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 286. Induktionsgesetz und Lenz’sche Regel

- ID: `eb1ea150-ec6c-5000-bce3-f46c820dccf8`
- Beschreibung: Die lernende Person kann für eine Spule mit N gleichartigen Windungen die mittlere Induktionsspannung mit U_ind = −N · ΔΦ/Δt bestimmen und für einen geschlossenen Stromkreis die Richtung des Induktionsstroms mit der Lenz’schen Regel als Wirkung gegen die Flussänderung begründen.
- `requires`: `["1a037489-3c95-540b-8cae-0acd360358ee","ae20183e-92b5-5521-b8e0-9a8662cf51f5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 287. Elektromagnetischen Schwingkreis analysieren

- ID: `ac4ba260-6086-5fcc-bea2-c06f1425a1cc`
- Beschreibung: Die lernende Person kann einen einfachen LC-Schwingkreis beschreiben, charakteristische Größen wie Periodendauer, Frequenz und Amplituden angeben und die periodische Energieumwandlung qualitativ erklären.
- `requires`: `["37f28bc4-def2-57cf-a06b-191dfd228205","78cf6eff-b3bc-5444-9ef8-5d39dae8d17d","9f59a088-3939-59e9-821d-167fadfda782"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 288. Mechanische und elektromagnetische Schwingungen vergleichen

- ID: `a844895e-2cdc-4665-aad2-a49c62f11759`
- Beschreibung: Die lernende Person kann mechanische und elektromagnetische Schwingungen anhand von Rückstellwirkung, charakteristischen Größen und periodischer Energieumwandlung vergleichen und zentrale Analogien fachlich benennen.
- `requires`: `["78cf6eff-b3bc-5444-9ef8-5d39dae8d17d","ac4ba260-6086-5fcc-bea2-c06f1425a1cc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_WELLEN","LI_ENERGIE"],"phase":"Q2"}}`

## 289. Thomson’sche Schwingungsgleichung nutzen

- ID: `f36a5946-f2a8-59b8-b3bd-a2f246defa4f`
- Beschreibung: Die lernende Person kann mithilfe der Thomson’schen Gleichung die Eigenfrequenz eines idealisierten LC-Schwingkreises berechnen und Größenabhängigkeiten qualitativ deuten.
- `requires`: `["ac4ba260-6086-5fcc-bea2-c06f1425a1cc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 290. Differentialgleichung des elektromagnetischen Schwingkreises mit Ansatz lösen

- ID: `a7255b83-336c-4d42-ba5c-bc2f6248ea36`
- Beschreibung: Die lernende Person kann die Differentialgleichung eines idealisierten elektromagnetischen Schwingkreises mit einem geeigneten Ansatz lösen und die Lösungen im Hinblick auf Periodendauer, Frequenz und Energieumlagerung deuten.
- `requires`: `["ac4ba260-6086-5fcc-bea2-c06f1425a1cc","b2fb9a25-4d26-5cf2-a917-823909dcb6bd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q2"}}`

## 291. Selbstinduktion und Induktivität

- ID: `37f28bc4-def2-57cf-a06b-191dfd228205`
- Beschreibung: Die lernende Person kann phänomenologisch erklären, wie eine Spule bei Ein- und Ausschaltvorgängen durch eine der Stromänderung entgegenwirkende Selbstinduktionsspannung reagiert, und die Induktivität als Maß für die Stärke dieses Zusammenhangs deuten.
- `requires`: `["eb1ea150-ec6c-5000-bce3-f46c820dccf8","106417ed-80db-5490-a1ee-bb4160d3f2b4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 292. Technische Anwendungen des Induktionsgesetzes qualitativ erklären

- ID: `fdcd5faf-f9bf-4fa9-87f4-4e22d8d3387c`
- Beschreibung: Die lernende Person kann für eine vorgegebene technische Anwendung – etwa Generator, Transformator, Induktionsladegerät oder Induktionskochplatte – qualitativ erklären, wodurch sich der magnetische Fluss ändert, welche Spannung und bei geschlossenem Stromkreis welche Ströme induziert werden und welchem technischen Zweck dies dient.
- `requires`: `["1a037489-3c95-540b-8cae-0acd360358ee"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"Q2"}}`

## 293. Elektromagnetische Felder im Maxwell-Überblick beschreiben

- ID: `ffbbf243-c2eb-4330-b050-837de994c130`
- Beschreibung: Die lernende Person kann die vier Maxwell-Gleichungen qualitativ als Aussagen über elektrische Ladungen als Quellen elektrischer Felder, die Quellenfreiheit des Magnetfelds, Wirbel elektrischer Felder durch zeitlich veränderliche Magnetfelder sowie Wirbel magnetischer Felder durch Ströme und zeitlich veränderliche elektrische Felder einordnen und ihr Zusammenwirken beschreiben, ohne sie formal herzuleiten.
- `requires`: `["fdcd5faf-f9bf-4fa9-87f4-4e22d8d3387c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_WELLEN"],"phase":"Q2"}}`

## 294. Mechanische Wellen

- ID: `dc38c943-11f6-5f4f-945b-67e330814727`
- Beschreibung: Cluster zu mechanischen Wellen: harmonische Wellen, typische Wellenphänomene, Überlagerung und stehende Wellen als Grundlage für spätere Quantenmodelle.
- `requires`: `[]`
- `contains`: `["cb0ced6d-b7c1-5b7d-9922-8c394f6030e8","bf559969-a05c-58b5-82c5-3d719d96555d","158e1c19-7ccb-4c8c-931c-b685951ab161","68020906-e615-462e-a56f-dd1ccc14b8d7","9dba2826-b179-59f0-8d91-5916079e5abe","d716a35e-e422-5aba-b39a-f2e22f1e1e74","224243cd-5a53-5d6e-bed5-564cca167a80","f47a7fa0-b929-5264-b038-b83fd682967f","e7131fe3-1da6-5555-80ec-fb6bdf8fcc29","d5772db3-120c-5c37-ab46-2336d02236b0","0d2a4690-d891-503b-96f4-42c2de48fd8b","e160acb4-5b88-509e-8055-2653df420c65","215f5558-562c-5686-b649-931f324c7983","1c430e0a-b63e-5729-8715-a96a5a68740f"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q2"}}`

## 295. Harmonische Wellen über ihre Kenngrößen beschreiben

- ID: `cb0ced6d-b7c1-5b7d-9922-8c394f6030e8`
- Beschreibung: Die lernende Person kann bei einer fortschreitenden harmonischen Welle Frequenz und Wellenlänge als zeitliche beziehungsweise räumliche Periodizität deuten, die Phasengeschwindigkeit von der lokalen Schwingungsbewegung unterscheiden und den Zusammenhang $v = \lambda \cdot f$ begründen und nutzen.
- `requires`: `["fcf8580c-ecfd-58ea-bbf5-a1b29c9ecf8e","3c82510a-1f12-4eaa-81c2-8599437a5b85"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 296. Erzeugung und Ausbreitung harmonischer mechanischer Wellen erklären

- ID: `bf559969-a05c-58b5-82c5-3d719d96555d`
- Beschreibung: Die lernende Person kann erklären, wie eine harmonische Anregung in einem gekoppelten, näherungsweise linearen Medium eine harmonische mechanische Welle erzeugt und wie sich dabei Störung und Energie ausbreiten, obwohl die Medienelemente nur lokal schwingen.
- `requires`: `["fcf8580c-ecfd-58ea-bbf5-a1b29c9ecf8e","3c82510a-1f12-4eaa-81c2-8599437a5b85"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek2_harmonic_mechanical_wave_generation_and_propagation","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 297. Fortschreitende ebene Transversalwellen und Momentanbilder beschreiben

- ID: `158e1c19-7ccb-4c8c-931c-b685951ab161`
- Beschreibung: Die lernende Person kann eine fortschreitende ebene Transversalwelle beschreiben und s(x,t) sowohl als zeitlichen Verlauf der Auslenkung an einem festen Ort als auch als räumliches Momentanbild zu einem festen Zeitpunkt deuten.
- `requires`: `["bf559969-a05c-58b5-82c5-3d719d96555d","cb0ced6d-b7c1-5b7d-9922-8c394f6030e8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q2"}}`

## 298. Huygens'sches Prinzip und Elementarwellen

- ID: `9dba2826-b179-59f0-8d91-5916079e5abe`
- Beschreibung: Die lernende Person kann die Ausbreitung von ebenen und kreisförmigen Wellenfronten mithilfe des Modells der Elementarwellen (Huygens'sches Prinzip) erklären.
- `requires`: `["bf559969-a05c-58b5-82c5-3d719d96555d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q2"}}`

## 299. Wellenphänomene: Brechung, Reflexion, Beugung

- ID: `d716a35e-e422-5aba-b39a-f2e22f1e1e74`
- Beschreibung: Die lernende Person kann Reflexion, Brechung und Beugung anhand von Wellenfronten voneinander unterscheiden und ihre charakteristischen Veränderungen mithilfe des Huygens’schen Prinzips unter den jeweiligen Randbedingungen qualitativ erklären.
- `requires`: `["9dba2826-b179-59f0-8d91-5916079e5abe"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 300. Überlagerung und Interferenz von Wellen

- ID: `224243cd-5a53-5d6e-bed5-564cca167a80`
- Beschreibung: Die lernende Person kann die Superposition von Wellen qualitativ beschreiben, Verstärkung und Auslöschung erklären und den Einfluss des Gangunterschiedes auf Orte von Maxima und Minima diskutieren.
- `requires`: `[]`
- `contains`: `["85157cf0-7f68-5aea-b375-0f9797008cc9"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 301. Interferenz in der Technik (ANC)

- ID: `85157cf0-7f68-5aea-b375-0f9797008cc9`
- Beschreibung: Die lernende Person kann Active Noise Cancellation als gezielt erzeugte destruktive Interferenz erklären und seine Eignung als Lärmschutzmaßnahme anhand der physikalischen Wirkungsweise, Wirksamkeit und Grenzen bewerten.
- `requires`: `["d716a35e-e422-5aba-b39a-f2e22f1e1e74"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q2"}}`

## 302. Ultraschall in Medizin und Technik

- ID: `f47a7fa0-b929-5264-b038-b83fd682967f`
- Beschreibung: Die lernende Person kann erklären, wie Ultraschallortung und -bildgebung Reflexionen und Laufzeiten mechanischer Wellen nutzen, und die erreichbare räumliche Auflösung qualitativ einordnen.
- `requires`: `["d716a35e-e422-5aba-b39a-f2e22f1e1e74"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_WELLEN"],"phase":"Q2"}}`

## 303. Doppler-Effekt in der Medizin

- ID: `e7131fe3-1da6-5555-80ec-fb6bdf8fcc29`
- Beschreibung: Die lernende Person kann erklären, wie die Frequenzverschiebung von an bewegten Blutbestandteilen gestreutem Ultraschall von deren Geschwindigkeitskomponente in Strahlrichtung abhängt, und daraus bei bekanntem Einschallwinkel die Strömungsgeschwindigkeit bestimmen.
- `requires`: `["cb0ced6d-b7c1-5b7d-9922-8c394f6030e8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"Q2"}}`

## 304. Stehende Wellen und Wellenlängenbestimmung

- ID: `d5772db3-120c-5c37-ab46-2336d02236b0`
- Beschreibung: Die lernende Person kann stehende Wellen im eindimensionalen Fall beschreiben und mithilfe von Reflexionsexperimenten Wellenlängen bestimmen, ohne Phasensprünge im Detail zu behandeln.
- `requires`: `["85157cf0-7f68-5aea-b375-0f9797008cc9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q2"}}`

## 305. Physik der Musikinstrumente

- ID: `0d2a4690-d891-503b-96f4-42c2de48fd8b`
- Beschreibung: Die lernende Person kann erklären, wie die Randbedingungen die möglichen stehenden Wellenmoden in Saiten und Luftsäulen festlegen und dadurch die möglichen Töne bestimmen, und den Zusammenhang zwischen Instrumentenlänge, möglichen Wellenlängen und Frequenzen qualitativ ableiten.
- `requires`: `["d5772db3-120c-5c37-ab46-2336d02236b0"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q2"}}`

## 306. Übungen Q2

- ID: `9dd7c596-a751-523c-acba-916f73e900a5`
- Beschreibung: Buendelt materialgestuetzte Q2-Klausuraufgaben mit normalem Klausurcharakter zu Schwingungen, Induktion und mechanischen Wellen. Abiturvorschlaege bleiben davon getrennt modelliert.
- `requires`: `[]`
- `contains`: `["1659e056-c7ac-553d-b4d6-467cc5688dd1","d350cfa7-c606-501e-abf7-1c9e546b266b","82feb329-c3bc-58ba-a5b0-6ccdf226dbeb","acf192a8-c398-51dc-a03b-672ab55df957","b15f3e47-6051-5382-aa86-1e4f09e245d5","eecb0af8-a45a-51fc-8987-2acb6292ca7f","ab2b9c0f-db98-5d20-adee-e46eafe037b4","50328a4f-91e8-5c8b-8d61-8f9c98a5cddf"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_ENERGIE","LI_FELDER","LI_TECHNIK"],"phase":"Q2"}}`

## 307. Schwingungsanalyse und Energiebilanz

- ID: `1659e056-c7ac-553d-b4d6-467cc5688dd1`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q2-Klausuraufgabe zu harmonischen Schwingungen, charakteristischen Größen und Energieerhaltung selbstaendig bearbeiten.
- `requires`: `["fcf8580c-ecfd-58ea-bbf5-a1b29c9ecf8e","78cf6eff-b3bc-5444-9ef8-5d39dae8d17d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_ENERGIE"],"phase":"Q2"}}`

## 308. Resonanz, Daempfung und Schwingungsgleichung

- ID: `d350cfa7-c606-501e-abf7-1c9e546b266b`
- Beschreibung: Die lernende Person kann eine LK-orientierte Q2-Klausuraufgabe zu gedaempften und erzwungenen Schwingungen, Resonanzkurven und zur Schwingungsgleichung selbstaendig bearbeiten.
- `requires`: `["3efa0cda-f55b-5534-8fac-ffe1d312aed1","18c1f954-487e-5121-bb18-6c64a82f573d","c0205f47-185c-5e27-b89c-c3ff8809b1d1","b2fb9a25-4d26-5cf2-a917-823909dcb6bd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_ENERGIE"],"phase":"Q2"}}`

## 309. Induktionsgesetz und Wirbelstrombremse

- ID: `82feb329-c3bc-58ba-a5b0-6ccdf226dbeb`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q2-Klausuraufgabe zu Bewegungsinduktion, magnetischem Fluss, Lenz-Regel und Wirbelstrombremsen selbstaendig bearbeiten.
- `requires`: `["eb1ea150-ec6c-5000-bce3-f46c820dccf8","e5c33afc-a233-50ff-a17f-63c085dfb89c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q2","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q2"}}`

## 310. Selbstinduktion, Einschaltvorgaenge und Feldenergie

- ID: `acf192a8-c398-51dc-a03b-672ab55df957`
- Beschreibung: Die lernende Person kann eine LK-orientierte Q2-Klausuraufgabe zu Selbstinduktion, Ein- und Ausschaltvorgaengen, Induktionsgleichungen und gespeicherter Magnetfeldenergie selbstaendig bearbeiten.
- `requires`: `["37f28bc4-def2-57cf-a06b-191dfd228205","d18d4190-ddc1-5181-b1b6-e79947b737c2","692db5b6-8be1-5c7b-8307-3a02afb21ea0","a1389d4e-dc97-5557-babe-a31a2bd57217"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q2"}}`

## 311. LC-Schwingkreis und Thomson-Gleichung

- ID: `b15f3e47-6051-5382-aa86-1e4f09e245d5`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q2-Klausuraufgabe zum elektromagnetischen Schwingkreis und zur Thomson-Gleichung selbstaendig bearbeiten.
- `requires`: `["ac4ba260-6086-5fcc-bea2-c06f1425a1cc","f36a5946-f2a8-59b8-b3bd-a2f246defa4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q2","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q2"}}`

## 312. Wellenphaenomene, Ultraschall und Wellengleichung

- ID: `eecb0af8-a45a-51fc-8987-2acb6292ca7f`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q2-Klausuraufgabe zu Wellenphaenomenen, Ultraschall, Doppler-Effekt und zur mathematischen Beschreibung harmonischer Wellen selbstaendig bearbeiten.
- `requires`: `["f47a7fa0-b929-5264-b038-b83fd682967f","e7131fe3-1da6-5555-80ec-fb6bdf8fcc29","e160acb4-5b88-509e-8055-2653df420c65","68020906-e615-462e-a56f-dd1ccc14b8d7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q2","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"Q2"}}`

## 313. Interferenz, stehende Wellen und Musikinstrumente

- ID: `ab2b9c0f-db98-5d20-adee-e46eafe037b4`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q2-Klausuraufgabe zu Interferenz, stehenden Wellen, Phasenspruengen, Wellenpaketen und zur Physik von Musikinstrumenten selbstaendig bearbeiten.
- `requires`: `["d5772db3-120c-5c37-ab46-2336d02236b0","0d2a4690-d891-503b-96f4-42c2de48fd8b","215f5558-562c-5686-b649-931f324c7983","1c430e0a-b63e-5729-8715-a96a5a68740f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q2","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"Q2"}}`

## 314. Q3 Elektromagnetische Wellen und Quantenphysik

- ID: `5d960c58-f363-5dc1-b012-e6363b4b31cf`
- Beschreibung: Vom elektromagnetischen Spektrum zum Welle-Teilchen-Dualismus und atomaren Modellen.
- `requires`: `[]`
- `contains`: `["c1563745-2722-503d-819f-95d336937e2b","9fd26b99-b790-5efd-8858-c7e6c20b005e","dd5a8efd-5d11-5388-aa2a-5147dec4348f","341ec911-6624-529c-8799-b5a5113ee907","b47a2a23-b56d-5433-9036-075d6bb7c782"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"basicConcepts":["KONZEPT_SUPERPOSITION","KONZEPT_ZUFALL_DETERMINIERTHEIT"],"phase":"Q3"}}`

## 315. Lernkarten - Q3

- ID: `341ec911-6624-529c-8799-b5a5113ee907`
- Beschreibung: Die lernende Person kann zentrale Fachbegriffe und Definitionen aus Q3 (elektromagnetische Wellen, Quantenphysik) mithilfe von Lernkarten sicher abrufen.
- `requires`: `["4a7cbe83-b694-57d3-85ce-1eeca418daaf","cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f","d7244ce4-5409-58d1-a1b4-bfae35f391e1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","nodeKind":"memory","tags":["GK","LK","srs-deck:de_gymnasium_physics_quantum_q3","memorization"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"Q3"}}`

## 316. Elektromagnetische Wellen

- ID: `c1563745-2722-503d-819f-95d336937e2b`
- Beschreibung: Cluster zu elektromagnetischen Wellen: Spektrum, typische Wellenphänomene, Polarisation, Interferenz und stehende Wellen.
- `requires`: `[]`
- `contains`: `["4a7cbe83-b694-57d3-85ce-1eeca418daaf","5da7d4d0-878e-44fd-b398-1b1de8b636a4","91f1838c-80fc-55f5-ac30-e7d1498fccee","122e83ac-c9cf-50c1-8a73-a1e3db347f21","5b90066f-b5b3-4e82-8d31-7b95ff0a0451","8ad305d2-bde0-4223-9477-517b2943148b","c71315c1-f329-4289-a145-d99819da7bad","2c6af966-7703-4176-a117-5ddb8295bedf","c64820e1-c0ee-4342-9225-f981650f0c52","31ed4e95-3ed4-4cfb-9b11-9f3c1341f2d4","c2b6acd8-b298-4e4e-aa7a-553a8a65f913","549269d3-1aef-5c55-9640-ee2a8e2ee9a1","58fc7852-722c-5a67-be6a-bfd1be0b527e","6270e558-d657-5363-a6b2-e49a032a453b","91683676-01cf-5003-80fa-a04d043b4e61","4c919da9-157a-5a14-a725-f7343975c9ab","f6a3a602-1e45-5018-b0ff-3d49933cf634","709e688c-eb07-5f83-a506-82c9bfe0d89f","d1e26b52-78a7-5f3b-ac9f-97f3e62d7db1","0693f68f-1bd4-50a9-ba2b-af95b1c949ee","3d3e5917-d367-535d-a6ad-b9d87259e6ce","ea17b0af-3d53-5a10-acda-7fd9348537ce"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3"}}`

## 317. Spektrum elektromagnetischer Wellen

- ID: `4a7cbe83-b694-57d3-85ce-1eeca418daaf`
- Beschreibung: Die lernende Person kann das elektromagnetische Spektrum nach Frequenz und Wellenlänge geordnet darstellen, typische Bereiche einordnen, technische Anwendungen passenden Spektralbereichen zuordnen und die Zuordnung anhand relevanter Welleneigenschaften begründen.
- `requires`: `["cb0ced6d-b7c1-5b7d-9922-8c394f6030e8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 318. Hertz'schen Dipol als Grenzfall des Schwingkreises deuten

- ID: `5da7d4d0-878e-44fd-b398-1b1de8b636a4`
- Beschreibung: Die lernende Person kann den Hertz'schen Dipol als Grenzfall eines elektromagnetischen Schwingkreises beschreiben und die Abstrahlung elektromagnetischer Wellen in Grundzügen deuten.
- `requires`: `["ac4ba260-6086-5fcc-bea2-c06f1425a1cc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER","LI_WELLEN"],"phase":"Q3"}}`

## 319. Kohaerentes Licht als elektromagnetische Welle beschreiben

- ID: `5b90066f-b5b3-4e82-8d31-7b95ff0a0451`
- Beschreibung: Die lernende Person kann kohaerentes Licht als elektromagnetische Welle beschreiben und die Lichtgeschwindigkeit als charakteristische Ausbreitungsgroesse fachlich einordnen.
- `requires`: `["5da7d4d0-878e-44fd-b398-1b1de8b636a4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3"}}`

## 320. Strahlenmodell und Wellenmodell des Lichts vergleichen

- ID: `8ad305d2-bde0-4223-9477-517b2943148b`
- Beschreibung: Die lernende Person kann Strahlenmodell und Wellenmodell des Lichts vergleichen und den Gueltigkeitsbereich des Strahlenmodells bei Beugung an einer Blende und bei Dispersion fachlich begrenzen.
- `requires`: `["79cb1695-f985-443a-b93e-27b57ab474b7","5b90066f-b5b3-4e82-8d31-7b95ff0a0451"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3"}}`

## 321. Interferenzphaenomene an Einzelspalt, Doppelspalt und Gitter experimentell untersuchen

- ID: `c71315c1-f329-4289-a145-d99819da7bad`
- Beschreibung: Die lernende Person kann Interferenzphaenomene an Einzelspalt, Doppelspalt und Gitter experimentell untersuchen und die beobachteten Muster fachsprachlich dokumentieren.
- `requires`: `["8ad305d2-bde0-4223-9477-517b2943148b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Experiment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3"}}`

## 322. Interferenzmuster und Intensitaetsverteilungen bei Einzelspalt, Doppelspalt und Gitter beschreiben

- ID: `2c6af966-7703-4176-a117-5ddb8295bedf`
- Beschreibung: Die lernende Person kann die Struktur von Interferenzmustern und Intensitaetsverteilungen bei Beugung an Einzelspalt, Doppelspalt und Gitter beschreiben und idealisierte von realen Spalten endlicher Breite unterscheiden.
- `requires`: `["c71315c1-f329-4289-a145-d99819da7bad"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3"}}`

## 323. Interferenzminima am Doppelspalt begründen und lokalisieren

- ID: `c64820e1-c0ee-4342-9225-f981650f0c52`
- Beschreibung: Die lernende Person kann beim idealisierten Doppelspalt mit gleich starken kohärenten Beiträgen die dunklen Stellen aus destruktiver Interferenz begründen, ihre Winkel und Schirmpositionen bestimmen und die Minima gegenüber den Maxima sowie gegenüber einer unzulässigen Kleinwinkelnäherung abgrenzen.
- `requires`: `["6270e558-d657-5363-a6b2-e49a032a453b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3"}}`

## 324. Interferenzphaenomene im Alltag physikalisch beschreiben

- ID: `31ed4e95-3ed4-4cfb-9b11-9f3c1341f2d4`
- Beschreibung: Die lernende Person kann Interferenzphaenomene im Alltag physikalisch beschreiben, zum Beispiel an duennen Schichten, an Gitterstrukturen oder als Laser-Speckle.
- `requires`: `["2c6af966-7703-4176-a117-5ddb8295bedf"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"Q3"}}`

## 325. Geschichtliche Entwicklung von Modellvorstellungen des Lichts beschreiben

- ID: `c2b6acd8-b298-4e4e-aa7a-553a8a65f913`
- Beschreibung: Die lernende Person kann die geschichtliche Entwicklung von Modellvorstellungen des Lichts von Lichtstrahlen ueber Lichtteilchen und Lichtwellen bis zu elektromagnetischen Wellen und Photonen beschreiben.
- `requires`: `["8ad305d2-bde0-4223-9477-517b2943148b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3"}}`

## 326. Polarisation und Schwingungsebene

- ID: `549269d3-1aef-5c55-9640-ee2a8e2ee9a1`
- Beschreibung: Die lernende Person kann lineare Polarisation von Licht anhand der festen Schwingungsrichtung des elektrischen Feldes beschreiben, die zugehörige Schwingungsebene kennzeichnen und einfache Anwendungen polarisierender Elemente erläutern.
- `requires`: `["cb0ced6d-b7c1-5b7d-9922-8c394f6030e8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 327. Totalreflexion und Glasfasern

- ID: `58fc7852-722c-5a67-be6a-bfd1be0b527e`
- Beschreibung: Die lernende Person kann das Phänomen der Totalreflexion qualitativ erklären und einfache Anwendungen wie Lichtleitung in Glasfasern deuten.
- `requires`: `["6a4c6042-052b-502b-a39a-0ed8941247ac"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 328. Interferenz am Doppelspalt

- ID: `6270e558-d657-5363-a6b2-e49a032a453b`
- Beschreibung: Die lernende Person kann das Interferenzmuster eines idealisierten Doppelspalts aus dem Gangunterschied kohärenter Lichtwellen erklären, die Maximabedingung und ihre Kleinwinkelnäherung begründen und damit Wellenlängen aus Schirmmessungen bestimmen sowie die Lage der Farben bei polychromatischem Licht deuten.
- `requires`: `["9dba2826-b179-59f0-8d91-5916079e5abe","5b90066f-b5b3-4e82-8d31-7b95ff0a0451","8d30d241-0247-48ac-83d3-4e0de61584d3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 329. Spektren mit Beugungsgitter deuten

- ID: `91683676-01cf-5003-80fa-a04d043b4e61`
- Beschreibung: Die lernende Person kann die Hauptmaxima eines optischen Gitters aus der kohärenten Überlagerung regelmäßig angeordneter Spalte begründen und das Modell nutzen, um polychromatische Spektren nach Wellenlänge und Beugungsordnung zu deuten sowie Wellenlängen aus gemessenen Winkeln oder Schirmpositionen zu bestimmen.
- `requires`: `["6270e558-d657-5363-a6b2-e49a032a453b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 330. Stehende elektromagnetische Wellen

- ID: `4c919da9-157a-5a14-a725-f7343975c9ab`
- Beschreibung: Die lernende Person kann eindimensionale stehende elektromagnetische Wellen als Überlagerung gegenläufiger Wellen mit festen Knoten und Bäuchen erklären und Resonatorbeispiele über ihre Randbedingungen einordnen.
- `requires`: `["d5772db3-120c-5c37-ab46-2336d02236b0","bbef7cf2-90fa-59fa-a115-8b651aab9231"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 331. Welle-Teilchen-Dualismus

- ID: `9fd26b99-b790-5efd-8858-c7e6c20b005e`
- Beschreibung: Cluster zum Welle-Teilchen-Dualismus: Energie- und Impulsbeziehung von Photonen, Fotoeffekt, De-Broglie-Wellen und Compton-Effekt.
- `requires`: `[]`
- `contains`: `["f75c494c-5723-5cd8-8ec9-dc3d8ec7eca6","d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec","cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f","28f6a324-5f5e-5771-91d2-c007f6c275aa","dfa53498-34f5-5326-9d94-87e7b528caf3","2aa2ef4b-8204-59b9-ad53-71c994cd6180","5476480f-7ff2-529f-aade-968198c782a9","c5413852-abae-566b-b435-f9939209ca63"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"Q3"}}`

## 332. Wie funktionieren Solarzellen und Lichtsensoren?

- ID: `f75c494c-5723-5cd8-8ec9-dc3d8ec7eca6`
- Beschreibung: Einstieg in die Quantenphysik über Alltagsanwendungen: Die lernende Person kann die Funktionsidee von Solarzellen und Lichtsensoren beschreiben und offene Fragen formulieren.
- `requires`: `["cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"Q3"}}`

## 333. Energie und Impuls von Photonen

- ID: `d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec`
- Beschreibung: Die lernende Person kann Zusammenhänge zwischen Energie, Impuls, Frequenz und Wellenlänge von Photonen darstellen und fachlich deuten.
- `requires`: `["4a7cbe83-b694-57d3-85ce-1eeca418daaf"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 334. Fotoeffekt und Einstein-Deutung

- ID: `cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f`
- Beschreibung: Die lernende Person kann den Fotoeffekt beschreiben, die Einstein’sche Deutung erläutern und die Widersprüche zur klassischen Wellentheorie herausarbeiten.
- `requires`: `["d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 335. Methode: Naturkonstanten bestimmen (Linearisierung)

- ID: `28f6a324-5f5e-5771-91d2-c007f6c275aa`
- Beschreibung: Die lernende Person kann das Plancksche Wirkungsquantum h aus Fotoeffekt-Messdaten durch eine lineare Auswertung der Einstein-Gleichung für die maximale kinetische Energie bestimmen und den Zusammenhang zwischen Geradensteigung und h physikalisch deuten.
- `requires`: `["264dc31c-ec92-5e39-a8b8-16f1d74366d4","cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Method","Measurement"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q3"}}`

## 336. De-Broglie-Wellen

- ID: `dfa53498-34f5-5326-9d94-87e7b528caf3`
- Beschreibung: Die lernende Person kann die De-Broglie-Hypothese formulieren, die De-Broglie-Wellenlänge berechnen und die Wellen-Natur von Teilchen qualitativ begründen.
- `requires`: `["d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 337. Compton-Effekt

- ID: `2aa2ef4b-8204-59b9-ad53-71c994cd6180`
- Beschreibung: Die lernende Person kann den Compton-Effekt qualitativ beschreiben und seine Bedeutung für den Teilchencharakter von Strahlung erläutern.
- `requires`: `["dfa53498-34f5-5326-9d94-87e7b528caf3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 338. Atomvorstellungen

- ID: `dd5a8efd-5d11-5388-aa2a-5147dec4348f`
- Beschreibung: Cluster zu Atomvorstellungen: Bohr-Modell, Quantisierung von Energieniveaus, Orbitale als Nachweiswahrscheinlichkeiten, Franck-Hertz-Versuch, Emissions- und Absorptionsspektren, spektroskopische Modellindizien, charakteristische Röntgenspektren, Modellgrenzen sowie Rydberg-Formel.
- `requires`: `[]`
- `contains`: `["ce89fa04-bbd8-53b2-be01-812e3b3044ed","d7244ce4-5409-58d1-a1b4-bfae35f391e1","b1f00a6d-1a03-496c-b1bd-c1f2259f59a8","cf340ce4-8d91-5d22-a1d9-53bf408abdb3","904670af-8e4c-543e-bc9b-e6248d87a10d","c14857d3-634f-4a59-9a3f-8d0638fc5784","7e9e814c-fe12-42a9-8d80-e09e7fb52964","8ea46612-7f0d-4ef4-a732-9428e640ae92","974a2d1c-2225-519d-965f-7744fe8aafd5","bacae732-2016-5a83-bc61-d0f94ed5a0e4","48e77690-17f7-5ebe-a8f7-87b2ee9820da","81c0d811-e6de-5489-8415-3b257c734a2e","ea2d5085-4ec1-5e33-87e0-15edcad635bf","0172ca41-cc42-51d6-94ad-f0f4680059e4","badb0ef3-233d-560e-bc2a-9df99f09fe7d"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q3"}}`

## 339. Bohr’sche Postulate und Quantisierung

- ID: `ce89fa04-bbd8-53b2-be01-812e3b3044ed`
- Beschreibung: Die lernende Person kann die Bohr’schen Postulate formulieren und das Konzept der Quantisierung der Bahnen und Energieniveaus qualitativ erklären.
- `requires`: `["dfa53498-34f5-5326-9d94-87e7b528caf3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 340. Energieniveaus des Wasserstoffatoms

- ID: `d7244ce4-5409-58d1-a1b4-bfae35f391e1`
- Beschreibung: Die lernende Person kann Energieniveaus des Wasserstoffatoms mithilfe einer einfachen Formel angeben und Übergänge zwischen Niveaus mit der Energie abgegebener oder aufgenommener Photonen verknüpfen.
- `requires`: `["ce89fa04-bbd8-53b2-be01-812e3b3044ed"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 341. Orbitale des Wasserstoffatoms als Nachweiswahrscheinlichkeiten interpretieren

- ID: `b1f00a6d-1a03-496c-b1bd-c1f2259f59a8`
- Beschreibung: Die lernende Person kann Orbitale des Wasserstoffatoms als Veranschaulichung der Nachweiswahrscheinlichkeiten fuer das Elektron interpretieren.
- `requires`: `["d7244ce4-5409-58d1-a1b4-bfae35f391e1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 342. Franck-Hertz-Versuch

- ID: `cf340ce4-8d91-5d22-a1d9-53bf408abdb3`
- Beschreibung: Die lernende Person kann den Franck-Hertz-Versuch beschreiben und zeigen, wie Stoßanregung und Spannungsabhängigkeit Hinweise auf diskrete Energieniveaus liefern.
- `requires`: `["d7244ce4-5409-58d1-a1b4-bfae35f391e1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 343. Emission, Absorption und Linienspektren

- ID: `904670af-8e4c-543e-bc9b-e6248d87a10d`
- Beschreibung: Die lernende Person kann Emission und Absorption von Photonen im Energieniveauschema darstellen und den Zusammenhang zwischen diskreten Spektrallinien und Energieniveaudifferenzen erklären.
- `requires`: `["d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 344. Bedeutung von Flammenfärbung, Linienspektren und Spektralanalyse für Modelle diskreter Energiezustände interpretieren

- ID: `c14857d3-634f-4a59-9a3f-8d0638fc5784`
- Beschreibung: Die lernende Person kann die Bedeutung von Flammenfärbung, Linienspektren und Spektralanalyse für die Entwicklung von Modellen diskreter Energiezustände der Elektronen in der Atomhülle fachlich interpretieren.
- `requires`: `["904670af-8e4c-543e-bc9b-e6248d87a10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 345. Charakteristisches Röntgenspektrum mit Energieniveaus der Atomhülle erklären

- ID: `7e9e814c-fe12-42a9-8d80-e09e7fb52964`
- Beschreibung: Die lernende Person kann das charakteristische Röntgenspektrum mithilfe von Energieniveaus der Atomhülle erklären.
- `requires`: `["904670af-8e4c-543e-bc9b-e6248d87a10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 346. Historische Entwicklung der Atommodelle und Modellgrenzen fachlich einordnen

- ID: `8ea46612-7f0d-4ef4-a732-9428e640ae92`
- Beschreibung: Die lernende Person kann an der historischen Entwicklung der Atommodelle spezifische Eigenschaften und Grenzen naturwissenschaftlicher Modelle fachlich herausarbeiten.
- `requires`: `["c14857d3-634f-4a59-9a3f-8d0638fc5784","7e9e814c-fe12-42a9-8d80-e09e7fb52964","b1f00a6d-1a03-496c-b1bd-c1f2259f59a8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 347. Rydberg-Formel anwenden

- ID: `974a2d1c-2225-519d-965f-7744fe8aafd5`
- Beschreibung: Die lernende Person kann mithilfe der Rydberg-Formel Wellenlängen von Spektrallinien bestimmen und den Bezug zu Energieniveaus verdeutlichen.
- `requires`: `["904670af-8e4c-543e-bc9b-e6248d87a10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 348. Übungen Q3

- ID: `b47a2a23-b56d-5433-9036-075d6bb7c782`
- Beschreibung: Buendelt materialgestuetzte Q3-Klausuraufgaben mit normalem Klausurcharakter zu elektromagnetischen Wellen und Quantenphysik. Abiturvorschlaege bleiben davon getrennt modelliert.
- `requires`: `[]`
- `contains`: `["7e2017d0-e76e-559c-bace-d5d7809a241f","36d5b915-1cb8-5a05-b64a-5f9497a33d1f","22bdd29e-00d3-5d43-97d6-8b442b8bfc8c","2c3f9ee1-fe78-5583-8eb1-fa6369b95905","d0eb16e9-9a52-5237-baca-ad5a14a4c59b","23530be9-66b6-57d7-9ff8-0c55dd5b1295","a94f9b05-ecb1-5a13-8364-44c1c98be8e4","caf8fc1e-83d5-5aaf-8863-0f7d4948ace5","45b3a745-16ec-57b0-8f54-dd36292f4958","90f8f0dc-d919-54a2-a487-93547706e40e","e1abfda1-f1c4-5b32-a6bd-da605698bf73"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE","LI_TECHNIK","LI_ENERGIE"],"phase":"Q3"}}`

## 349. Spektrum, Polarisation und Glasfaseroptik

- ID: `7e2017d0-e76e-559c-bace-d5d7809a241f`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q3-Klausuraufgabe zu elektromagnetischem Spektrum, Polarisation und Totalreflexion in Glasfasern selbstaendig bearbeiten.
- `requires`: `["4a7cbe83-b694-57d3-85ce-1eeca418daaf","549269d3-1aef-5c55-9640-ee2a8e2ee9a1","58fc7852-722c-5a67-be6a-bfd1be0b527e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q3","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"Q3"}}`

## 350. Interferenz, Beugung und optische Instrumente

- ID: `36d5b915-1cb8-5a05-b64a-5f9497a33d1f`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q3-Klausuraufgabe zu Doppelspalt, Beugung, Interferometern, stehenden elektromagnetischen Wellen und optischer Auflösung selbstaendig bearbeiten.
- `requires`: `["6270e558-d657-5363-a6b2-e49a032a453b","91683676-01cf-5003-80fa-a04d043b4e61","4c919da9-157a-5a14-a725-f7343975c9ab","f6a3a602-1e45-5018-b0ff-3d49933cf634","709e688c-eb07-5f83-a506-82c9bfe0d89f","d1e26b52-78a7-5f3b-ac9f-97f3e62d7db1","0693f68f-1bd4-50a9-ba2b-af95b1c949ee"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q3","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"Q3"}}`

## 351. Photonenmodell und Fotoeffekt

- ID: `22bdd29e-00d3-5d43-97d6-8b442b8bfc8c`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q3-Klausuraufgabe zu Energie und Impuls von Photonen, Fotoeffekt, Solarzellen und der Bestimmung des Planckschen Wirkungsquantums selbstaendig bearbeiten.
- `requires`: `["d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec","cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f","f75c494c-5723-5cd8-8ec9-dc3d8ec7eca6","28f6a324-5f5e-5771-91d2-c007f6c275aa","5476480f-7ff2-529f-aade-968198c782a9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q3","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE","LI_ENERGIE"],"phase":"Q3"}}`

## 352. Materiewellen und Quantencharakter

- ID: `2c3f9ee1-fe78-5583-8eb1-fa6369b95905`
- Beschreibung: Die lernende Person kann eine LK-orientierte Q3-Klausuraufgabe zu De-Broglie-Wellen, Compton-Effekt und Einzelphotonen-Interferenz selbstaendig bearbeiten.
- `requires`: `["dfa53498-34f5-5326-9d94-87e7b528caf3","2aa2ef4b-8204-59b9-ad53-71c994cd6180","c5413852-abae-566b-b435-f9939209ca63"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"Q3"}}`

## 353. Absorptionsspektren und Fluoreszenz deuten

- ID: `d0eb16e9-9a52-5237-baca-ad5a14a4c59b`
- Beschreibung: Die lernende Person kann eine materialgestützte Q3-Klausuraufgabe zu Energieniveaus, Absorption, Emission und Fluoreszenz selbständig bearbeiten.
- `requires`: `["ce89fa04-bbd8-53b2-be01-812e3b3044ed","d7244ce4-5409-58d1-a1b4-bfae35f391e1","904670af-8e4c-543e-bc9b-e6248d87a10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q3","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q3"}}`

## 354. Erweiterte Spektralanalyse und Laser

- ID: `23530be9-66b6-57d7-9ff8-0c55dd5b1295`
- Beschreibung: Die lernende Person kann eine LK-orientierte Q3-Klausuraufgabe zu wasserstoffähnlichen Atomen, Roentgenspektren, Bragg-Bedingung, Spektrallinien und Laserprinzip selbstaendig bearbeiten.
- `requires`: `["bacae732-2016-5a83-bc61-d0f94ed5a0e4","48e77690-17f7-5ebe-a8f7-87b2ee9820da","81c0d811-e6de-5489-8415-3b257c734a2e","ea2d5085-4ec1-5e33-87e0-15edcad635bf","0172ca41-cc42-51d6-94ad-f0f4680059e4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q3"}}`

## 355. Q4 Struktur von Materie, Raum und Zeit

- ID: `5482bc19-3836-51a5-ba98-fbf5e265b908`
- Beschreibung: Vertiefung moderner Physik von Quantenobjekten über Relativität bis hin zur Astrophysik.
- `requires`: `[]`
- `contains`: `["ab636b78-6031-5a5b-afa2-9ffefbdd5dda","2f4190c6-7803-5f9e-b5cd-864970aa5bec","e5c08365-a0d3-592c-ad8e-d2c2c6e2b717","72c2bf5d-c62b-5744-9971-4c117f2a432d","7add799b-2d76-58db-81e5-d54393718f50","157c404a-e14b-598a-9389-6924f8f9262e","620d4320-6b93-500b-8a62-86d02b1ed1f0","b59cb1ef-05c2-5b09-abb3-8b6903ca0fd6","266b6cf8-d49d-5197-862c-9998fcf179a5","85bbad98-2f48-5d64-85c4-ab6cf67f24c2","25e5f469-58b7-546f-8894-ac12e601d6ae"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"basicConcepts":["KONZEPT_ZUFALL_DETERMINIERTHEIT"],"phase":"Q4"}}`

## 356. Lernkarten - Q4

- ID: `266b6cf8-d49d-5197-862c-9998fcf179a5`
- Beschreibung: Die lernende Person kann zentrale Fachbegriffe und Definitionen aus Q4 (Struktur der Materie, Raum und Zeit) mithilfe von Lernkarten sicher abrufen.
- `requires`: `["51bc5513-6879-548f-b19a-9746b667f1a3","e5c08365-a0d3-592c-ad8e-d2c2c6e2b717","a684bec1-ba59-59d0-98d2-4ca37236f64c","7badac4d-2874-5b3a-87e8-bf8f4440b2a6"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","nodeKind":"memory","tags":["GK","LK","srs-deck:de_gymnasium_physics_structure_q4","memorization"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q4"}}`

## 357. Quantenobjekte

- ID: `ab636b78-6031-5a5b-afa2-9ffefbdd5dda`
- Beschreibung: Cluster zu Quantenobjekten: einfaches quantenmechanisches Atommodell, stehende De-Broglie-Wellen im Potenzialtopf, Wellenfunktion, Unbestimmtheitsrelation und Komplementarität.
- `requires`: `[]`
- `contains`: `["a359c859-eee0-40ef-a9d1-88db2e6c55b2","defe44d2-c3d3-456b-a786-fad2cef13fe8","4245c54f-d609-41bc-9eff-e9ceeff4902f","5c57dbc7-d258-4aad-a84c-e773f3c493ae","d5bff282-741f-4cc5-9622-b77584fdcc5a","1a1c09f0-96b7-4c33-a623-0e8101537876","6031bed0-9baa-4f45-b2a5-57ffb00d39cc","f6e5929f-d52a-42a4-a5d2-ff498ee7083f","cc2d5e8e-4599-54ac-b8de-87c8cfd39ea7","51bc5513-6879-548f-b19a-9746b667f1a3","ad021f2e-6b94-5e6e-a264-3d1110094b87","9e881b3b-68cd-5f52-819f-c2e33b5ba631","b05da028-65e4-5cd1-a13c-6c1a95b6dfdf","8c97c234-a932-5e84-aed5-237b4e2a8336","aef1e312-6a0c-5323-9202-c22ae84086f2","48e3d6c2-00bf-5afd-8846-ba3dbd01e96d","727d0946-7019-50ed-8fc6-85db12508733","b9fcbad4-a855-54b7-8017-4caac1e2ffb7","e296aba6-f407-5944-a2bd-e5296e4c9f06","52b6722a-b3b2-5d2d-a507-0215532b0422","43adaa0b-1f37-5d55-a496-6900555274a1"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE"],"basicConcepts":["BC_ZUFALL_DETERMINIERTHEIT"],"phase":"Q4"}}`

## 358. Photonen und Elektronen als Quantenobjekte beschreiben

- ID: `a359c859-eee0-40ef-a9d1-88db2e6c55b2`
- Beschreibung: Die lernende Person kann Photonen und Elektronen als Quantenobjekte beschreiben und ihre Wellen- und Teilcheneigenschaften zur Deutung einfacher quantenphysikalischer Experimente nutzen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 359. Die Bedeutung von Modellen an Photon und Elektron reflektieren

- ID: `defe44d2-c3d3-456b-a786-fad2cef13fe8`
- Beschreibung: Die lernende Person kann am Beispiel von Photon und Elektron die Bedeutung physikalischer Modelle als Erkenntniswerkzeuge reflektieren und die Reichweite solcher Modelle fachlich einordnen.
- `requires`: `["a359c859-eee0-40ef-a9d1-88db2e6c55b2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 360. Klassische Wellen, klassische Teilchen und Quantenobjekte am Doppelspalt vergleichen

- ID: `4245c54f-d609-41bc-9eff-e9ceeff4902f`
- Beschreibung: Die lernende Person kann am Doppelspalt klassische Wellen, klassische Teilchen und Quantenobjekte vergleichen und unterschiedliche Vorhersagen fuer Musterbildung und Einzelereignisse fachlich unterscheiden.
- `requires`: `["c71315c1-f329-4289-a145-d99819da7bad"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"Q4"}}`

## 361. Wahrscheinlichkeitsaussagen statt klassischem Determinismus erlaeutern

- ID: `5c57dbc7-d258-4aad-a84c-e773f3c493ae`
- Beschreibung: Die lernende Person kann erlaeutern, warum Quantenobjekte nicht durch klassische Bahnaussagen beschrieben werden, sondern durch Wahrscheinlichkeitsaussagen ueber moegliche Messergebnisse.
- `requires`: `["4245c54f-d609-41bc-9eff-e9ceeff4902f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 362. Interferenz einzelner Quantenobjekte mit Wahrscheinlichkeitsaussagen beschreiben

- ID: `1a1c09f0-96b7-4c33-a623-0e8101537876`
- Beschreibung: Die lernende Person kann die Interferenz einzelner Quantenobjekte mithilfe von Wahrscheinlichkeitsaussagen beschreiben und den Aufbau eines Interferenzmusters aus vielen Einzelereignissen qualitativ deuten.
- `requires`: `["5c57dbc7-d258-4aad-a84c-e773f3c493ae"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"Q4"}}`

## 363. Komplementaritaet durch Interferenzfaehigkeit und Welcher-Weg-Information erlaeutern

- ID: `6031bed0-9baa-4f45-b2a5-57ffb00d39cc`
- Beschreibung: Die lernende Person kann Komplementaritaet erlaeutern, indem sie die Sichtbarkeit von Interferenz mit verfuegbarer Welcher-Weg-Information in Beziehung setzt.
- `requires`: `["1a1c09f0-96b7-4c33-a623-0e8101537876"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"Q4"}}`

## 364. Orts-Impuls-Unbestimmtheit und Grenzen des Bahnbegriffs begruenden

- ID: `f6e5929f-d52a-42a4-a5d2-ff498ee7083f`
- Beschreibung: Die lernende Person kann die Orts-Impuls-Unbestimmtheit qualitativ begruenden und daraus Grenzen des klassischen Bahnbegriffs fuer Quantenobjekte ableiten.
- `requires`: `["6031bed0-9baa-4f45-b2a5-57ffb00d39cc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Concept"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 365. Quantenmechanisches Atommodell im Potenzialtopf

- ID: `cc2d5e8e-4599-54ac-b8de-87c8cfd39ea7`
- Beschreibung: Die lernende Person kann ein einfaches quantenmechanisches Atommodell qualitativ beschreiben und ein gebundenes Elektron als stehende De-Broglie-Welle in einem eindimensionalen Potenzialtopf deuten.
- `requires`: `[]`
- `contains`: `["ef6d5067-96b0-5388-87dd-5ac4e6a3e313"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":[],"phase":"Q4"}}`

## 366. Grenzen des Potentialtopf-Modells

- ID: `ef6d5067-96b0-5388-87dd-5ac4e6a3e313`
- Beschreibung: Die lernende Person kann das idealisierte unendliche Kastenpotential mit dem atomaren Coulomb-Potential vergleichen und daraus Aussagegrenzen des Kastenmodells für Atome erläutern.
- `requires`: `["51bc5513-6879-548f-b19a-9746b667f1a3","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 367. Wellenfunktion und Wahrscheinlichkeitsdeutung

- ID: `51bc5513-6879-548f-b19a-9746b667f1a3`
- Beschreibung: Die lernende Person kann qualitativ erläutern, wie das Betragsquadrat der quantenmechanischen Wellenfunktion eine Wahrscheinlichkeitsdichte angibt und daraus die Wahrscheinlichkeit für den Nachweis eines Quantenobjekts in einem Raumbereich folgt.
- `requires`: `["d7244ce4-5409-58d1-a1b4-bfae35f391e1","f08d06dc-139d-5fd2-892c-8cc919b1e4fc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 368. Unendlicher Potenzialtopf: Energien und Intervallwahrscheinlichkeiten

- ID: `ad021f2e-6b94-5e6e-a264-3d1110094b87`
- Beschreibung: Dieser fachliche Cluster bündelt das Berechnen diskreter Energiewerte und normierter Intervallwahrscheinlichkeiten für ein Elektron im eindimensionalen Potenzialtopf mit unendlich hohen Wänden.
- `requires`: `[]`
- `contains`: `["d05a146f-7fcd-56ae-b9b9-b54203328579","f2538793-8b0a-5c3b-b216-5d329a4e87bd"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 369. Orts-Impuls-Unbestimmtheit

- ID: `9e881b3b-68cd-5f52-819f-c2e33b5ba631`
- Beschreibung: Die lernende Person kann die Orts-Impuls-Unbestimmtheit qualitativ formulieren und erläutern, warum Zustände mit gleichzeitig exakt bestimmtem Ort und Impuls nicht präpariert werden können.
- `requires`: `["51bc5513-6879-548f-b19a-9746b667f1a3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 370. Das Messproblem in der Quantenphysik

- ID: `b05da028-65e4-5cd1-a13c-6c1a95b6dfdf`
- Beschreibung: Die lernende Person kann die mögliche Zustandspräparation oder -änderung durch eine Quantenmessung erläutern, den sogenannten Kollaps der Wellenfunktion als modellabhängige Beschreibung einordnen und dies von klassischer Messunsicherheit unterscheiden.
- `requires`: `["9e881b3b-68cd-5f52-819f-c2e33b5ba631","72effc66-87f4-5f5e-8d36-1547677365fb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Concept","Measurement"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE"],"basicConcepts":["KONZEPT_ZUFALL_DETERMINIERTHEIT"],"phase":"Q4"}}`

## 371. Delayed-Choice-Experimente messkontextbezogen deuten

- ID: `8c97c234-a932-5e84-aed5-237b4e2a8336`
- Beschreibung: Die lernende Person kann an einem Delayed-Choice-Experiment erklären, wie die gewählte Messanordnung entweder Interferenzstatistik oder Weginformation zugänglich macht, und diesen experimentellen Befund von retrokausalen oder klassisch-ontologischen Deutungen unterscheiden.
- `requires`: `["6031bed0-9baa-4f45-b2a5-57ffb00d39cc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 372. Koinzidenznachweis einzelner Photonen

- ID: `aef1e312-6a0c-5323-9202-c22ae84086f2`
- Beschreibung: Die lernende Person kann Koinzidenzmessungen zum Nachweis einzelner Photonen qualitativ erklären und begründen, wie unterdrückte gleichzeitige Nachweise an den beiden Ausgängen eines Strahlteilers bei geeigneter Einzelphotonenpräparation die Unteilbarkeit eines Photons beim Nachweis stützen.
- `requires`: `["9e881b3b-68cd-5f52-819f-c2e33b5ba631"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 373. Antimaterie und Paarvernichtung

- ID: `48e3d6c2-00bf-5afd-8846-ba3dbd01e96d`
- Beschreibung: Die lernende Person kann das Positron als Antiteilchen des Elektrons beschreiben und erklären, wie bei der Vernichtung eines annähernd ruhenden Elektron-Positron-Paares unter Energie- und Impulserhaltung zwei nahezu entgegengesetzt ausgesandte Photonen entstehen, die in der PET als Messsignal genutzt werden.
- `requires`: `["d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec","c63bbffd-8d1c-5fe2-a428-db194e6fe592"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 374. Technische Anwendungen der Quantenphysik

- ID: `2f4190c6-7803-5f9e-b5cd-864970aa5bec`
- Beschreibung: Cluster zu technischen Anwendungen der Quantenphysik: Laser, Tunneleffekt und Rastertunnelmikroskop.
- `requires`: `[]`
- `contains`: `["75f7139f-0f07-5cec-bcea-4f139502b528","2ec48368-ac5b-55f9-a396-5a5fe4e1e874"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_TECHNIK","LI_ENERGIE"],"phase":"Q4"}}`

## 375. Laserprinzip und Anwendungen

- ID: `75f7139f-0f07-5cec-bcea-4f139502b528`
- Beschreibung: Die lernende Person kann metastabile Niveaus, Besetzungsinversion und stimulierte Emission beschreiben sowie Aufbau, Funktionsprinzip und Anwendungen von Lasern erläutern.
- `requires`: `["904670af-8e4c-543e-bc9b-e6248d87a10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 376. Tunneleffekt und Rastertunnelmikroskop

- ID: `2ec48368-ac5b-55f9-a396-5a5fe4e1e874`
- Beschreibung: Die lernende Person kann den Tunneleffekt qualitativ beschreiben und Aufbau, Funktionsprinzip sowie Anwendungen eines Rastertunnelmikroskops erläutern.
- `requires`: `["ef6d5067-96b0-5388-87dd-5ac4e6a3e313"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 377. Kernphysik

- ID: `72c2bf5d-c62b-5744-9971-4c117f2a432d`
- Beschreibung: Cluster zur Kernphysik: radioaktive Strahlung, Zerfallsgesetze, Bindungsenergie, Kernreaktionen und kernphysikalische Anwendungen.
- `requires`: `[]`
- `contains`: `["a12fddce-0215-58d9-bd91-21be8a960d25","cde9b548-2cf4-59ad-b5d4-a71872afbe56","49872cc0-401f-5464-9235-4763df4db5cf","3b50255a-6b01-578b-8f5c-4383536a3221","6e7c35e0-7a38-5996-a42e-005038eff0db","76bcbdcb-3003-5e6a-952e-aa36eb8f97ee","e6a50c74-c922-508c-aa27-07bac2566955","5492f0e0-cbae-574e-a853-182616205ed3","23fd87f3-9e79-5e0e-b9d1-7c15f3d119e0","b1ad9493-acca-5366-9ecd-4b7bf7edaf4a","64b30d2e-cbe1-55d8-915a-a050d736b96e"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE","LI_TECHNIK"],"phase":"Q4"}}`

## 378. Anwendungen ionisierender Strahlung qualitativ beurteilen

- ID: `e5c08365-a0d3-592c-ad8e-d2c2c6e2b717`
- Beschreibung: Die lernende Person kann bei einer konkreten Anwendung ionisierender Strahlung deren Funktion über Strahlungsart, Wechselwirkung und Nachweisprinzip erklären und Nutzen sowie Gefährdung unter Berücksichtigung von Expositionsweg, Reichweite und Abschirmung qualitativ beurteilen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f","1593d95c-2aac-504c-8527-37cb61877da9","25d91cc0-d84c-5522-86b5-fdff73264f08","861ba00a-e89c-5b3d-8c76-8ff0bcb0f1cd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 379. Zerfallsgesetze anwenden

- ID: `a12fddce-0215-58d9-bd91-21be8a960d25`
- Beschreibung: Die lernende Person kann mit einem einfachen exponentiellen Zerfallsgesetz die zeitliche Abnahme einer radioaktiven Substanz oder ihrer Aktivität bestimmen und die Halbwertszeit im Sachkontext interpretieren.
- `requires`: `["16b94a12-ecc5-5b5c-85b6-87b4290bebf8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 380. Bindungsenergie und Massendefekt

- ID: `cde9b548-2cf4-59ad-b5d4-a71872afbe56`
- Beschreibung: Die lernende Person kann Bindungsenergie pro Nukleon und Massendefekt qualitativ erklären und in einfachen Fällen die bei Kernreaktionen freigesetzte Energie berechnen.
- `requires`: `["a12fddce-0215-58d9-bd91-21be8a960d25","d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 381. Kernreaktionen: Prozesse, Energie und Sicherheit

- ID: `49872cc0-401f-5464-9235-4763df4db5cf`
- Beschreibung: Dieser fachliche Cluster bündelt den qualitativen Vergleich von Kernspaltung und Kernfusion, die Erklärung der Energiefreisetzung aus Ruhemassendifferenzen, die Funktionsdeutung eines thermischen Kernreaktors sowie die Beurteilung von Strahlungsrisiken und die begründete Bewertung von Kernenergieoptionen.
- `requires`: `[]`
- `contains`: `["50877233-7abf-54df-b347-6d3224678fc9","7d78da7f-6af5-440a-9d6b-6cab4bee8dd2","bb5c5eab-2fc1-5336-b8cf-14d147695487","7e719cc2-0866-5267-a252-e7e7ac0d03f1","68034218-8f3e-5f7f-ae4e-ed057dd4e44e"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":[],"phase":"Q4"}}`

## 382. Spezielle Relativitätstheorie

- ID: `157c404a-e14b-598a-9389-6924f8f9262e`
- Beschreibung: Cluster zur speziellen Relativitätstheorie: Relativitätspostulate, Zeitdilatation, Längenkontraktion und Minkowski-Diagramme.
- `requires`: `[]`
- `contains`: `["a684bec1-ba59-59d0-98d2-4ca37236f64c","512f81af-1480-56a8-ae52-af3aa1a6a859","a08e33db-d821-457b-86dd-870e7648c5f4","19aef2ed-eb46-55b1-9486-ee83f7520bb6","0c305cf9-3923-51cf-a9ae-5849edc99c9f","a9169a74-de19-54a9-a8ac-a2ce43c7342e","6ebb6182-f221-5f4c-b112-4ac72b104321","57ec031c-9a91-5331-81a7-6ef900f7c63e","2239cb67-82cb-585f-ab82-e1f2510eb4f7","79da5c34-86b2-5c10-9726-9de886ccef7d","bfea7a23-1ce1-4a42-badd-1fc9bf30124a"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_KOSMOS"],"phase":"Q4"}}`

## 383. Relativitätspostulate formulieren und erläutern

- ID: `a684bec1-ba59-59d0-98d2-4ca37236f64c`
- Beschreibung: Die lernende Person kann das Relativitätsprinzip und die Invarianz der Lichtgeschwindigkeit als Postulate der speziellen Relativitätstheorie formulieren und ihre Bedeutung für physikalische Beschreibungen in Inertialsystemen erläutern.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 384. Michelson-Morley-Nullbefund historisch einordnen

- ID: `512f81af-1480-56a8-ae52-af3aa1a6a859`
- Beschreibung: Die lernende Person kann den Nullbefund des Michelson-Morley-Versuchs historisch einordnen und erläutern, weshalb er gegen den erwarteten Nachweis eines Ätherwinds sprach, ohne ihn als alleinigen Beweis der Relativitätspostulate zu deuten.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek2_michelson_morley_null_result_historical_evidence","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 385. Zeitdilatation erläutern

- ID: `19aef2ed-eb46-55b1-9486-ee83f7520bb6`
- Beschreibung: Die lernende Person kann Zeitdilatation mithilfe einfacher Beispiele und Gedankenexperimente erläutern und zugehörige experimentelle Nachweise qualitativ diskutieren.
- `requires`: `["a684bec1-ba59-59d0-98d2-4ca37236f64c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 386. Längenkontraktion erläutern

- ID: `0c305cf9-3923-51cf-a9ae-5849edc99c9f`
- Beschreibung: Die lernende Person kann Längenkontraktion mithilfe einfacher Beispiele und Gedankenexperimente erläutern und zugehörige experimentelle Nachweise qualitativ diskutieren.
- `requires`: `["a684bec1-ba59-59d0-98d2-4ca37236f64c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek2_length_contraction_explain_experimental_evidence","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 387. GPS und Relativitätstheorie

- ID: `a9169a74-de19-54a9-a8ac-a2ce43c7342e`
- Beschreibung: Die lernende Person kann qualitativ erklären, wie Bewegung und Gravitation den Gang von GPS-Satellitenuhren gegenüber einer erdgebundenen Zeitreferenz beeinflussen und warum relativistische Zeitkorrekturen für eine präzise Positionsbestimmung erforderlich sind.
- `requires`: `["19aef2ed-eb46-55b1-9486-ee83f7520bb6"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_TECHNIK","LI_KOSMOS"],"phase":"Q4"}}`

## 388. Minkowski-Diagramme nutzen

- ID: `6ebb6182-f221-5f4c-b112-4ac72b104321`
- Beschreibung: Die lernende Person kann Minkowski-Diagramme zur Veranschaulichung relativistischer Effekte einsetzen und einfache Aussagen über Gleichzeitigkeit und Weltlinien treffen.
- `requires`: `["19aef2ed-eb46-55b1-9486-ee83f7520bb6","25593605-5e13-55cc-9a05-8f3d737e15e9","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 389. Festkörperphysik

- ID: `620d4320-6b93-500b-8a62-86d02b1ed1f0`
- Beschreibung: Cluster zur Festkörperphysik: Leiter, Nichtleiter, Halbleiter, Bändermodell, Dotierung, Dioden, Transistoren und Supraleitung.
- `requires`: `[]`
- `contains`: `["70b358bf-da6d-53ba-8393-51d5c2365b04","7badac4d-2874-5b3a-87e8-bf8f4440b2a6","df010b2b-b182-5f7e-bbe4-49b72e48c27a","7f0798cb-5966-5dcb-beb3-84f637ab6139","d36727cc-ce42-51a3-9425-41afb0b9acdd","853dbe54-85b0-59ab-8f3a-000c2b7746ec","658cf33d-a0c2-5d47-801a-3dbcd5cac074"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q4"}}`

## 390. Vom Sand zum Smartphone: Die digitale Revolution

- ID: `70b358bf-da6d-53ba-8393-51d5c2365b04`
- Beschreibung: Ein anschaulicher Einstieg in die Festkörperphysik: Aus siliziumdioxidhaltigem Rohstoff wird hochreines Silizium, dessen gezielt veränderbare elektrische Eigenschaften Mikrochips, Sensoren und Kommunikation ermöglichen. Die lernende Person erkundet diese Verbindung; hier geht es um Orientierung und Interesse, fachliches Detailwissen wird weder vorausgesetzt noch geprüft.
- `requires`: `[]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticKind":"orientation","tags":["GK","LK","Motivation","Orientation","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q4"}}`

## 391. Leiter, Nichtleiter und Halbleiter

- ID: `7badac4d-2874-5b3a-87e8-bf8f4440b2a6`
- Beschreibung: Die lernende Person kann Leiter, Nichtleiter und Halbleiter anhand ihrer typischen elektrischen Leitfähigkeit unter vergleichbaren Bedingungen unterscheiden und Beispiele aus Technik und Alltag begründet zuordnen.
- `requires`: `["70b358bf-da6d-53ba-8393-51d5c2365b04","5c44b9ba-9b05-4774-95d5-073230d3fc4f","26f668a0-6425-5466-9cf7-6295dd189005"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 392. Bändermodell und Dotierung

- ID: `df010b2b-b182-5f7e-bbe4-49b72e48c27a`
- Beschreibung: Die lernende Person kann das qualitative Bändermodell für Leiter und Halbleiter beschreiben und erklären, wie Dotierung die Leitfähigkeit beeinflusst.
- `requires`: `["7badac4d-2874-5b3a-87e8-bf8f4440b2a6"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 393. p-n-Übergang und Diode

- ID: `7f0798cb-5966-5dcb-beb3-84f637ab6139`
- Beschreibung: Dieses Cluster bündelt das Ladungsträgermodell des p-n-Übergangs, die experimentelle Diodenkennlinie und die Funktionsdeutung einfacher Gleichrichterschaltungen als drei getrennt prüfbare Kompetenzen.
- `requires`: `[]`
- `contains`: `["2084b7d4-300d-5fa0-8b8d-c480c40f853e","3857891b-d328-585b-9936-85c7aff122ee","3b586f2a-60e2-5019-aa08-6a47616a1f1f"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 394. Sperrschicht und Polung am p-n-Übergang erklären

- ID: `2084b7d4-300d-5fa0-8b8d-c480c40f853e`
- Beschreibung: Die lernende Person kann mit einem einfachen Ladungsträgermodell die Entstehung der Sperrschicht am p-n-Übergang und ihre Veränderung bei Durchlass- und Sperrpolung erklären.
- `requires`: `["df010b2b-b182-5f7e-bbe4-49b72e48c27a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_pn_depletion_bias","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_TECHNIK","LI_MATERIE"],"phase":"GLOBAL","area":"Elektronik","topicCode":"CANONICAL_PHYSICS_MODEL"}}`

## 395. Die Strom-Spannungs-Kennlinie einer Diode experimentell bestimmen

- ID: `3857891b-d328-585b-9936-85c7aff122ee`
- Beschreibung: Die lernende Person kann in einem beaufsichtigten, strombegrenzten Kleinspannungsversuch die Strom-Spannungs-Kennlinie einer Diode in Durchlass- und Sperrpolung aufnehmen und aus den Messwerten ihr richtungsabhängiges Leitverhalten begründen.
- `requires`: `["2084b7d4-300d-5fa0-8b8d-c480c40f853e","28237994-9c24-5a06-82fe-be1f494768ba","f1a078ae-6262-4444-a4bc-a5ab275621cf","80c232f1-8f72-5829-9dbe-5a610ccab3be"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_diode_iv_experiment","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN"],"guidingIdeas":["LI_TECHNIK","LI_MATERIE"],"phase":"GLOBAL","area":"Elektronik","topicCode":"CANONICAL_PHYSICS_EXPERIMENT"}}`

## 396. Die Gleichrichterfunktion einer Diodenschaltung erklären

- ID: `3b586f2a-60e2-5019-aa08-6a47616a1f1f`
- Beschreibung: Die lernende Person kann an einer vorgegebenen einfachen Gleichrichterschaltung aus der Polung der Dioden die Stromwege und den zeitlichen Verlauf der Spannung am Verbraucher erklären.
- `requires`: `["2084b7d4-300d-5fa0-8b8d-c480c40f853e","80c232f1-8f72-5829-9dbe-5a610ccab3be"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_diode_rectifier_function","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_TECHNIK","LI_MATERIE"],"phase":"GLOBAL","area":"Elektronik","topicCode":"CANONICAL_PHYSICS_RECTIFIER"}}`

## 397. Warum eine Diode beim Umpolen sperrt

- ID: `c61b2a69-b5cd-5785-bb04-5d6bca53b218`
- Beschreibung: Die lernende Person kann die Entstehung und Polungsabhängigkeit einer p-n-Sperrschicht an einem neuen Modellfall begründen.
- `requires`: `["2084b7d4-300d-5fa0-8b8d-c480c40f853e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_diode_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Elektronik","topicCode":"CANONICAL_PHYSICS_DIODE_ASSESSMENT_MODEL"}}`

## 398. Eine echte Diodenkennlinie aufnehmen und prüfen

- ID: `4ac5a07c-fff0-5eae-890d-89e13eaf69c3`
- Beschreibung: Die lernende Person kann die selbst gemessene Kennlinie einer Diode sicher und unsicherheitsbewusst auswerten und eine geänderte Messbedingung prüfen.
- `requires`: `["3857891b-d328-585b-9936-85c7aff122ee"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_diode_experiment","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Elektronik","topicCode":"CANONICAL_PHYSICS_DIODE_ASSESSMENT_EXPERIMENT"}}`

## 399. Stromwege eines Einweggleichrichters begründen

- ID: `18fb1470-5a03-5277-9486-ae74c63c8a8c`
- Beschreibung: Die lernende Person kann Stromwege und Ausgangsspannung eines vorgegebenen Gleichrichters bestimmen und einen Polungswechsel begründen.
- `requires`: `["3b586f2a-60e2-5019-aa08-6a47616a1f1f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_diode_rectifier","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Elektronik","topicCode":"CANONICAL_PHYSICS_DIODE_ASSESSMENT_RECTIFIER"}}`

## 400. Bipolartransistor: Schalter, Verstärker und Flipflop

- ID: `d36727cc-ce42-51a3-9425-41afb0b9acdd`
- Beschreibung: Dieser fachliche Cluster bündelt die qualitative Grund- und Schaltfunktion eines bipolaren Transistors, die Analyse von Verstärkerschaltungen und die Deutung einer bistabilen Flipflop-Schaltung.
- `requires`: `[]`
- `contains`: `["7d4d6a39-0c78-5fb0-b7bf-182ed00972f7","af50bb9a-fd7b-50f5-9698-48c4efe99032","c2af45aa-e3fc-5119-9159-c5a260b4135a"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 401. Supraleitung qualitativ verstehen

- ID: `853dbe54-85b0-59ab-8f3a-000c2b7746ec`
- Beschreibung: Die lernende Person kann das Verschwinden des elektrischen Gleichstromwiderstands unterhalb einer kritischen Temperatur und die Verdrängung eines Magnetfelds im Meißner-Zustand qualitativ beschreiben und damit einfache Anwendungen und Beobachtungen der Supraleitung erläutern.
- `requires`: `["df010b2b-b182-5f7e-bbe4-49b72e48c27a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 402. Astrophysik

- ID: `b59cb1ef-05c2-5b09-abb3-8b6903ca0fd6`
- Beschreibung: Cluster zur Astrophysik: Struktur des Sonnensystems, Kosmologie, größere Strukturen, Rotverschiebung, Urknall, dunkle Materie und Energie sowie Sternentwicklung.
- `requires`: `[]`
- `contains`: `["c9405043-bdc0-5995-8b4d-5bb56d97d05d","e5b3d86c-0a74-5fa7-b9c4-7964bcb5ebc9","5db07785-8cca-50d5-81a9-e0264d344af9","9b47a758-1b5d-5906-84c9-8621050d5aa5","4c5c7cb1-f238-52c8-b82c-159c6c299c0e","6f896466-e0ec-5f8d-82ad-2890433c82ba","aa0fa5fb-7bfb-5f9f-a606-3f7187cfb745","db6b8de4-21e0-58e8-a347-2ae39f538f92","14d99a65-8d58-5647-88ab-02137b96d55b","2b700858-bc2e-5ddf-a791-b14d44160480","7c986fca-1129-5eff-a17e-0a04bb7346ee","ba16948b-5e07-54af-b77b-776e677c6906","da3169ae-c72a-5782-ad95-408167a5c6da","5b8eaf71-96fe-50eb-b9ea-a8fa392df086","e28381b4-50ef-5cac-bfa4-b7c8e03aef82","2bc068de-5d2b-5f94-bd51-755982befb6f","0a172021-dfd9-5926-b92c-c01a9dfe9aa8","5cf160e5-e0c2-5552-b2cf-0f04871c5e7e","982df2f3-e040-5f4b-b668-0fe05d994b29","94a3a80e-f1de-51a2-b834-1e3431c5d3ca","4e823349-b60c-5d2a-b96f-d3f23ae50e3a","a7bec355-48c5-5107-bfab-d6956f9c9205","a5031dfc-6d25-5a04-850a-5c7d8a254c21","e07f36de-2819-59f8-a707-fa25b4633ed3","f67550ac-df22-5a3e-8172-f04642efca64","7df923a0-6470-595e-8cea-53126fad9506","7c8f1e34-d81a-51a2-8aa0-a6ee8e1b03a4","e2014db8-c97f-5ce1-82c5-2a42741f4a61","826af579-3e51-5ac9-bc2a-208d8a2fc99e","f203a552-fcf0-560c-baa2-47d4eb2379c8","61e84097-57b9-5434-9909-8ed8368a7823","6ae54ff9-dc3b-563b-b2ee-09a0f0d00162"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"Q4"}}`

## 403. Allgemeine Relativitätstheorie (Qualitativ)

- ID: `14d99a65-8d58-5647-88ab-02137b96d55b`
- Beschreibung: Die lernende Person kann Gravitation qualitativ als Wirkung der durch Masse geprägten Raumzeitgeometrie erläutern und Schwarze Löcher mithilfe des Begriffs Ereignishorizont in diese Beschreibung einordnen.
- `requires`: `["eb0ffdea-c12d-56df-b7e8-c0297d2f8aff","a42f91a4-0d21-5aa9-ae11-f48be6f2e431","594f7f21-6b8a-531c-8424-5f1dcbaf0f23"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4"}}`

## 404. Sonnensystem und Kepler-Gesetze

- ID: `c9405043-bdc0-5995-8b4d-5bb56d97d05d`
- Beschreibung: Die lernende Person kann Aufbau und Dynamik des Sonnensystems beschreiben, Kepler’sche Gesetze anwenden und Gezeiten qualitativ erklären.
- `requires`: `[]`
- `contains`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93","497f1311-17d6-56ff-afb1-422a738e5c16","37013646-f13a-5faf-954c-940f2fd7502f"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 405. Kosmologie und Urknall

- ID: `e5b3d86c-0a74-5fa7-b9c4-7964bcb5ebc9`
- Beschreibung: Die lernende Person kann grundlegende Aspekte der Kosmologie wie Rotverschiebung, Urknallmodell, Hintergrundstrahlung sowie dunkle Materie und dunkle Energie qualitativ beschreiben.
- `requires`: `[]`
- `contains`: `["c52d55c3-b687-586c-b0f9-8ffcd1069424","3d466956-04fb-58d7-9008-ad8090f8706d","b4772b06-b10c-52dd-841b-a96ffb7c7e28"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 406. Struktur und Alter des Universums

- ID: `5db07785-8cca-50d5-81a9-e0264d344af9`
- Beschreibung: Die lernende Person kann größere Strukturen wie Galaxien beschreiben und qualitative Aussagen zu Größe und Alter des Universums machen.
- `requires`: `[]`
- `contains`: `["1b060e79-dc2d-5e4e-abb5-42eca39f9cc7","db0394ca-297c-5892-b414-525ec186f928"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 407. Sternentstehung und Sternentwicklung

- ID: `9b47a758-1b5d-5906-84c9-8621050d5aa5`
- Beschreibung: Die lernende Person kann grundlegende Stadien der Sternentwicklung, unterschiedliche Sterntypen und den Energiehaushalt von Sternen qualitativ beschreiben.
- `requires`: `[]`
- `contains`: `["206fe51d-cc78-5422-b139-32cc97eb1c37"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 408. Hertzsprung-Russell-Diagramm (HRD)

- ID: `206fe51d-cc78-5422-b139-32cc97eb1c37`
- Beschreibung: Die lernende Person kann Sterne anhand ihrer Leuchtkraft und Oberflächentemperatur im Hertzsprung-Russell-Diagramm einordnen und die Bereiche Hauptreihe, Rote Riesen und Weiße Zwerge im Zusammenhang mit der Sternentwicklung deuten.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93","80c232f1-8f72-5829-9dbe-5a610ccab3be"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4"}}`

## 409. Quantitative Superposition elektrischer Felder

- ID: `455c65ca-814a-56ad-918a-013155883c52`
- Beschreibung: Die lernende Person kann elektrische Feldstärken vektoriell addieren und Fälle mit parallelen oder orthogonalen Feldern berechnen.
- `requires`: `["4ca83b3f-3605-5c0d-abc4-9f24b9e29bbe","4d78bbcc-89b8-47f0-aa45-516199e4da5d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 410. Polarisation und Dielektrika deuten

- ID: `73b309ed-1aab-5778-8494-d9b65f5a352b`
- Beschreibung: Die lernende Person kann Polarisation in Nichtleitern erklären und materialabhängige Permittivität in Berechnungen nutzen.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 411. Elektrisches Potenzial berechnen

- ID: `2622bef1-bdbc-504e-b468-b600b2ca3ed8`
- Beschreibung: Die lernende Person kann in vorgegebenen elektrischen Feldern bei festgelegtem Potenzialnullpunkt Potenziale an Punkten bestimmen, Spannungen als Potenzialdifferenzen berechnen sowie Äquipotentiallinien konstruieren und zur Darstellung und Auswertung der Felder deuten.
- `requires`: `["1730c01d-8c85-57df-b031-c11e2a0511b1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 412. Differenzialgleichung des RC-Kreises lösen

- ID: `330808f6-789a-583d-86df-e271a7683d8b`
- Beschreibung: Die lernende Person kann für die Entladung eines Kondensators aus einer konsistenten Strom- und Spannungskonvention sowie den Beziehungen U_R = RI und Q = CU die Differenzialgleichung aufstellen, sie mit der Anfangsbedingung lösen und die exponentielle Lösung einschließlich der Zeitkonstante RC physikalisch deuten.
- `requires`: `["0b4f2020-8486-5372-9cb9-6e59f698ac2d","09f2cdbd-64e0-55d2-ada7-1190f4fd50df"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 413. Methode: Lösungsansatz für DGL (Exponentialfunktion)

- ID: `09f2cdbd-64e0-55d2-ada7-1190f4fd50df`
- Beschreibung: Die lernende Person kann bei einfachen physikalischen Differenzialgleichungen, in denen die Änderungsrate proportional zur Zustandsgröße ist (z. B. bei der RC-Entladung), einen passenden Exponentialansatz wählen und durch Ableiten prüfen, ob er die Differenzialgleichung und die Anfangsbedingung erfüllt.
- `requires`: `["0b4f2020-8486-5372-9cb9-6e59f698ac2d","ae5010cc-ea8d-5b14-aa4a-b0f2b5846a75"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Method"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 414. Linearbeschleuniger modellieren

- ID: `74a74132-fa39-541c-8d3c-696cf228452d`
- Beschreibung: Die lernende Person kann lineare Beschleunigerstufen über die Energiezunahme einer Ladung im elektrischen Feld klassisch modellieren und begründen, warum bei Geschwindigkeiten, die nicht mehr klein gegenüber der Lichtgeschwindigkeit sind, relativistische Beziehungen für Energie und Impuls erforderlich werden.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782","5f289cdc-fda1-4058-b44f-041ba1398e79","f8704a7b-e93d-4e32-b0f9-1b171545fe28"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 415. Exkurs: Relativistische Energie und Impuls im Linearbeschleuniger

- ID: `8d34228c-da38-5c1e-97cc-571f3eafb9f4`
- Beschreibung: Die lernende Person kann am Beispiel eines Linearbeschleunigers erläutern, warum klassische Energie- und Impulsbeziehungen für Geschwindigkeiten nahe der Lichtgeschwindigkeit versagen, und die historische Bezeichnung „relativistische Massenzunahme“ so einordnen, dass die Ruhemasse invariant bleibt und die Zunahme von Energie und Impuls relativistisch beschrieben wird.
- `requires`: `["74a74132-fa39-541c-8d3c-696cf228452d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_BEWEGUNG"],"phase":"Q1"}}`

## 416. Kreisbahnen geladener Teilchen quantitativ bestimmen

- ID: `3b866aea-3e4d-5f23-91de-759148382710`
- Beschreibung: Die lernende Person kann im nichtrelativistischen Modell für ein geladenes Teilchen mit zur Feldrichtung senkrechter Geschwindigkeit in einem homogenen Magnetfeld Bahnradius und Umlaufzeit aus Lorentz- und Zentripetalkraft bestimmen.
- `requires`: `["8c9394cb-f54a-508d-9750-4c49e31b3fa9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 417. Hall-Effekt anwenden

- ID: `b39ae8fb-4358-5866-8adf-3d5365368eeb`
- Beschreibung: Die lernende Person kann die Hall-Spannung in einem stromdurchflossenen Leiter im Magnetfeld bestimmen und aus ihrem Betrag beziehungsweise Vorzeichen erklären, wie der Hall-Effekt zur Messung von Magnetfeldern oder zur Bestimmung des Ladungsträgertyps genutzt wird.
- `requires`: `["8c9394cb-f54a-508d-9750-4c49e31b3fa9","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 418. Magnetisierung und Permanentmagnete

- ID: `0924162b-46d0-5c56-93bc-33e1f5ac6886`
- Beschreibung: Die lernende Person kann in einem oberstufengerechten Modell erklären, wie die Vorzugsorientierung mikroskopischer magnetischer Momente Magnetisierung und eine makroskopische Feldwirkung hervorruft und wie eine bleibende Vorzugsorientierung dieser Momente Permanentmagnetismus erklärt.
- `requires`: `["0f6b798b-594e-5480-8c5f-95e2486a4d85"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 419. Fadenstrahlrohr als Elektronen-Messverfahren einordnen

- ID: `966782e5-690d-4fae-bbab-fa3fa30525c3`
- Beschreibung: Die lernende Person kann das Fadenstrahlrohr als indirektes Messverfahren einordnen, die eingestellten und gemessenen Größen benennen und erläutern, wie daraus der Betrag der spezifischen Elektronenladung $|e|/m_e$ bestimmt wird und – bei unabhängig bekanntem $|e|$ – die Elektronenmasse folgt.
- `requires`: `["8c9394cb-f54a-508d-9750-4c49e31b3fa9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Experiment","Measurement"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"Q1"}}`

## 420. Zyklotron und Synchrotron als Kreisbeschleuniger vergleichen

- ID: `2d62b444-796e-548d-aeee-cfd9c6665ddc`
- Beschreibung: Die lernende Person kann Zyklotron und Synchrotron anhand der gemeinsamen Rollen elektrischer Felder beim Beschleunigen und magnetischer Felder bei der Bahnführung vergleichen, die feste Hochfrequenztaktung mit wachsendem Bahnradius beim idealisierten nichtrelativistischen Zyklotron von der angepassten Beschleunigungsphase und Magnetfeldstärke bei näherungsweise konstantem Synchrotronradius unterscheiden und daraus wesentliche Modell- und Betriebsgrenzen begründen.
- `requires`: `["741774ef-15fc-4bcf-a370-e2c5cf4257d0","3b866aea-3e4d-5f23-91de-759148382710"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q1"}}`

## 421. Schwingungsgleichung lösen

- ID: `b2fb9a25-4d26-5cf2-a917-823909dcb6bd`
- Beschreibung: Die lernende Person kann die lineare Differenzialgleichung einer ungedämpften harmonischen Schwingung für gegebene Anfangsbedingungen lösen und die Lösung anhand von Amplitude, Kreisfrequenz und Phase physikalisch deuten.
- `requires`: `["d03f1cb6-c224-53db-ad91-76cc7827978d","09f2cdbd-64e0-55d2-ada7-1190f4fd50df","58d2f963-4fb9-550d-a832-f5ac60808900"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_ENERGIE"],"phase":"Q2"}}`

## 422. Dämpfungsverhalten klassifizieren

- ID: `18c1f954-487e-5121-bb18-6c64a82f573d`
- Beschreibung: Die lernende Person kann gedämpfte Schwingungen mit Exponentialansätzen beschreiben und Parameter deuten.
- `requires`: `["e6895bc3-fcbd-59ad-baef-a78c97a13e11","9db266a2-1889-5792-82b0-a7463f0832f1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_ENERGIE"],"phase":"Q2"}}`

## 423. Resonanzkurven analysieren

- ID: `c0205f47-185c-5e27-b89c-c3ff8809b1d1`
- Beschreibung: Die lernende Person kann Resonanzkurven für unterschiedliche Dämpfungen qualitativ und quantitativ diskutieren.
- `requires`: `["3efa0cda-f55b-5534-8fac-ffe1d312aed1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_ENERGIE"],"phase":"Q2"}}`

## 424. Überlagerungen unabhängiger Schwingungen qualitativ beschreiben

- ID: `4888444f-4520-437a-9ba7-e74e8f8ed129`
- Beschreibung: Die lernende Person kann Überlagerungen unabhängiger Schwingungen qualitativ beschreiben und dabei Verstärkung, Abschwächung und Schwebungen fachlich einordnen.
- `requires`: `["b2fb9a25-4d26-5cf2-a917-823909dcb6bd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN","LI_ENERGIE"],"phase":"Q2"}}`

## 425. Induktionsgesetz in Ableitungsform anwenden

- ID: `d18d4190-ddc1-5181-b1b6-e79947b737c2`
- Beschreibung: Die lernende Person kann bei einem differenzierbaren zeitabhängigen magnetischen Fluss die momentane Induktionsspannung einer Spule mit N gleichartigen Windungen mit U_ind(t) = −N · dΦ(t)/dt bestimmen und den zeitlichen Spannungsverlauf physikalisch deuten.
- `requires`: `["eb1ea150-ec6c-5000-bce3-f46c820dccf8","58d2f963-4fb9-550d-a832-f5ac60808900"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q2"}}`

## 426. Ein- und Ausschaltvorgänge analysieren

- ID: `692db5b6-8be1-5c7b-8307-3a02afb21ea0`
- Beschreibung: Die lernende Person kann Strom- und Spannungsverläufe beim Ein- und Ausschalten eines idealisierten RL-Stromkreises mit der Zeitkonstante τ = L/R quantitativ analysieren und die Induktivität aus einem solchen Verlauf bestimmen.
- `requires`: `["37f28bc4-def2-57cf-a06b-191dfd228205","27b63e2e-6a34-483e-8e5a-fe0f49670d1d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q2"}}`

## 427. Energie gespeicherter Magnetfelder

- ID: `a1389d4e-dc97-5557-babe-a31a2bd57217`
- Beschreibung: Die lernende Person kann die in einer idealisierten Spule mit konstanter Induktivität gespeicherte magnetische Energie mit W = 1/2 · L · I² bestimmen und Energieaufnahme und -abgabe bei technischen Anwendungen physikalisch begründen.
- `requires`: `["37f28bc4-def2-57cf-a06b-191dfd228205"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"Q2"}}`

## 428. Wellengleichung formulieren

- ID: `e160acb4-5b88-509e-8055-2653df420c65`
- Beschreibung: Die lernende Person kann eine harmonische Wellengleichung aufstellen und Amplitude, Frequenz, Wellenlänge, Phase sowie Ausbreitungsrichtung aus ihren Parametern deuten.
- `requires`: `["cb0ced6d-b7c1-5b7d-9922-8c394f6030e8","7f11ffe0-7c43-4507-9101-50374a60b0e8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q2"}}`

## 429. Phasensprünge bei Reflexion

- ID: `215f5558-562c-5686-b649-931f324c7983`
- Beschreibung: Die lernende Person kann erklären und mathematisch beschreiben, warum eine eindimensionale Auslenkungswelle bei der Reflexion am festen Ende einen Phasensprung von π und am losen Ende keinen Phasensprung erfährt.
- `requires`: `["d5772db3-120c-5c37-ab46-2336d02236b0","58d2f963-4fb9-550d-a832-f5ac60808900"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q2"}}`

## 430. Beugung am Einzelspalt berechnen

- ID: `f6a3a602-1e45-5018-b0ff-3d49933cf634`
- Beschreibung: Die lernende Person kann die Fraunhofer-Intensitätsverteilung eines gleichmäßig beleuchteten Einzelspalts aus der Überlagerung seiner Elementarwellen modellieren, die Minima und die Breite des Zentralmaximums begründen und Nebenmaxima aus dem Modell mit angemessenen Näherungen lokalisieren.
- `requires`: `["9dba2826-b179-59f0-8d91-5916079e5abe","5b90066f-b5b3-4e82-8d31-7b95ff0a0451","571793bd-34f1-539e-969c-dfcc2dfa96b3","c63bbffd-8d1c-5fe2-a428-db194e6fe592","c8818eae-0c4d-4fa1-9085-04a9c95a668b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3"}}`

## 431. Auflösungsvermögen optischer Instrumente

- ID: `709e688c-eb07-5f83-a506-82c9bfe0d89f`
- Beschreibung: Die lernende Person kann mithilfe des Rayleigh-Kriteriums erklären und beurteilen, wie Beugung, Wellenlänge und wirksame Öffnung das Auflösungsvermögen von Mikroskopen, Teleskopen und dem menschlichen Auge begrenzen.
- `requires`: `["f6a3a602-1e45-5018-b0ff-3d49933cf634"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"Q3"}}`

## 432. Interferometer verstehen

- ID: `d1e26b52-78a7-5f3b-ac9f-97f3e62d7db1`
- Beschreibung: Die lernende Person kann die Funktionsweise eines Interferometers über die Aufteilung kohärenten Lichts auf unterschiedliche optische Wege und seine Überlagerung erklären und aus Änderungen des Interferenzsignals optische Weglängenunterschiede bestimmen.
- `requires`: `["6270e558-d657-5363-a6b2-e49a032a453b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3"}}`

## 433. Energien wasserstoffähnlicher Ein-Elektronensysteme

- ID: `bacae732-2016-5a83-bc61-d0f94ed5a0e4`
- Beschreibung: Die lernende Person kann für wasserstoffähnliche Ein-Elektronensysteme Energieniveaus im nichtrelativistischen Coulomb-Modell bei vernachlässigter Kernbewegung mit $E_n\approx-13{,}6\,\mathrm{eV}\,Z^2/n^2$ relativ zur Ionisationsgrenze berechnen und die Abhängigkeit von Kernladungszahl $Z$ und Hauptquantenzahl $n$ physikalisch deuten.
- `requires`: `["d7244ce4-5409-58d1-a1b4-bfae35f391e1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q3"}}`

## 434. Röntgenspektren deuten

- ID: `48e77690-17f7-5ebe-a8f7-87b2ee9820da`
- Beschreibung: Die lernende Person kann Entstehung kontinuierlicher und diskreter Röntgenspektren sowie das Moseley-Gesetz erklären.
- `requires`: `["d7244ce4-5409-58d1-a1b4-bfae35f391e1","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q3"}}`

## 435. Bragg-Bedingung anwenden (LK)

- ID: `81c0d811-e6de-5489-8415-3b257c734a2e`
- Beschreibung: Die lernende Person kann die Bragg-Bedingung $n\cdot\lambda=2d\sin(\theta)$ anwenden, Netzebenenabstände oder Wellenlängen berechnen und Ergebnisse bei Elektronen- oder Röntgenbeugung deuten.
- `requires`: `["dfa53498-34f5-5326-9d94-87e7b528caf3","48e77690-17f7-5ebe-a8f7-87b2ee9820da"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":[],"phase":"Q3"}}`

## 436. Zerfallsreihen analysieren

- ID: `3b50255a-6b01-578b-8f5c-4383536a3221`
- Beschreibung: Die lernende Person kann in einer vorgegebenen Zerfallsreihe die Änderungen von Massenzahl und Kernladungszahl bei den angegebenen Zerfallsarten prüfen und die Konsistenz der aufeinanderfolgenden Nuklide begründen.
- `requires`: `["a12fddce-0215-58d9-bd91-21be8a960d25"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE","LI_TECHNIK"],"phase":"Q4"}}`

## 437. Potenzialtopfmodell für Kerne

- ID: `6e7c35e0-7a38-5996-a42e-005038eff0db`
- Beschreibung: Die lernende Person kann im vereinfachten Potenzialtopfmodell eines Kerns die Bindungsenergie eines Teilchens als Energieabstand seines gebundenen Zustands zur freien Schwelle qualitativ erklären und von der Topftiefe unterscheiden.
- `requires`: `["cde9b548-2cf4-59ad-b5d4-a71872afbe56","51bc5513-6879-548f-b19a-9746b667f1a3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"Q4"}}`

## 438. α-Zerfall durch Tunneleffekt

- ID: `76bcbdcb-3003-5e6a-952e-aa36eb8f97ee`
- Beschreibung: Die lernende Person kann den α-Zerfall mithilfe des Tunneleffekts qualitativ deuten.
- `requires`: `["7d78da7f-6af5-440a-9d6b-6cab4bee8dd2","51bc5513-6879-548f-b19a-9746b667f1a3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"Q4"}}`

## 439. Lorentztransformationen anwenden

- ID: `57ec031c-9a91-5331-81a7-6ef900f7c63e`
- Beschreibung: Die lernende Person kann Raum- und Zeitkoordinaten von Ereignissen zwischen gleichförmig relativ bewegten Inertialsystemen mit Lorentztransformationen umrechnen und die Ergebnisse physikalisch interpretieren.
- `requires`: `["a684bec1-ba59-59d0-98d2-4ca37236f64c","a6469c01-6ca3-5eb2-a82c-94f3d0560b32","f8704a7b-e93d-4e32-b0f9-1b171545fe28"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_KOSMOS"],"phase":"Q4"}}`

## 440. Relativistische Geschwindigkeitsaddition anwenden

- ID: `2239cb67-82cb-585f-ab82-e1f2510eb4f7`
- Beschreibung: Die lernende Person kann Geschwindigkeiten bei kollinearer Bewegung zwischen gleichförmig relativ bewegten Inertialsystemen mit der relativistischen Geschwindigkeitsaddition umrechnen und die Grenzfälle einordnen.
- `requires`: `["a684bec1-ba59-59d0-98d2-4ca37236f64c","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek2_relativistic_velocity_addition_apply","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_KOSMOS"],"phase":"Q4"}}`

## 441. Geschwindigkeitsabhängige „relativistische Masse“ herleiten und einordnen

- ID: `79da5c34-86b2-5c10-9726-9de886ccef7d`
- Beschreibung: Die lernende Person kann für ein massives Teilchen mit fester Ruhemasse $m_0$ die historische geschwindigkeitsabhängige Konvention $m_{\mathrm{rel}}=\gamma m_0=E/c^2$ herleiten, sie von der invarianten Ruhemasse unterscheiden und erklären, dass in moderner Darstellung Energie und Impulsbetrag – nicht die invariante Masse – mit der Geschwindigkeit relativ zu einem Inertialsystem zunehmen.
- `requires`: `["19aef2ed-eb46-55b1-9486-ee83f7520bb6","f08d06dc-139d-5fd2-892c-8cc919b1e4fc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_KOSMOS"],"phase":"Q4"}}`

## 442. Quantenphysikalische Bändermodelle

- ID: `658cf33d-a0c2-5d47-801a-3dbcd5cac074`
- Beschreibung: Die lernende Person kann in einem vorgegebenen quantenphysikalischen Bändermodell die Lage der Fermienergie und die Besetzung erlaubter Elektronenzustände unter angegebenen Temperaturbedingungen zur Erklärung der elektrischen Leitfähigkeit nutzen.
- `requires`: `["df010b2b-b182-5f7e-bbe4-49b72e48c27a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q4"}}`

## 443. Transistorverstärker analysieren

- ID: `af50bb9a-fd7b-50f5-9698-48c4efe99032`
- Beschreibung: Die lernende Person kann an einer vorgegebenen oder selbst aufgebauten bipolaren Verstärkerschaltung mithilfe von Kennlinien und Arbeitspunkt erklären, wie ein kleines Eingangssignal ein größeres Ausgangssignal steuert und welche Grenzen für eine unverzerrte Verstärkung gelten.
- `requires`: `["7d4d6a39-0c78-5fb0-b7bf-182ed00972f7","80c232f1-8f72-5829-9dbe-5a610ccab3be"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q4"}}`

## 444. Energieumwandlung in der Sonne

- ID: `4c5c7cb1-f238-52c8-b82c-159c6c299c0e`
- Beschreibung: Die lernende Person kann die Umwandlung von Wasserstoffkernen zu Helium in der Proton-Proton-Kette der Sonne erläutern und die dabei frei werdende Energie mit der Abnahme der Summe der Ruhemassen der beteiligten Teilchen erklären.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"Q4"}}`

## 445. Sterntypen und Entwicklung

- ID: `6f896466-e0ec-5f8d-82ad-2890433c82ba`
- Beschreibung: Die lernende Person kann typische Entwicklungswege sonnenähnlicher und massereicher Sterne beschreiben und ihre Unterschiede mit der Anfangsmasse in Zusammenhang bringen.
- `requires`: `["206fe51d-cc78-5422-b139-32cc97eb1c37"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"Q4"}}`

## 446. Wellenpakete

- ID: `1c430e0a-b63e-5729-8715-a96a5a68740f`
- Beschreibung: Die lernende Person kann bei einem schmalbandigen Wellenpaket die Gruppengeschwindigkeit als Geschwindigkeit seiner Hüllkurve deuten und erklären, wie frequenzabhängige Ausbreitung (Dispersion) seine Form und Breite verändert.
- `requires`: `["cb0ced6d-b7c1-5b7d-9922-8c394f6030e8","9f2fc0d1-e1e7-4051-ba70-87ba1dd8dd1c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_WELLEN"],"phase":"Q2"}}`

## 447. Dispersion elektromagnetischer Wellen

- ID: `0693f68f-1bd4-50a9-ba2b-af95b1c949ee`
- Beschreibung: Die lernende Person kann Dispersionsrelationen und die Frequenz- beziehungsweise Wellenlängenabhängigkeit der Brechzahl analysieren und daraus erklären, wie ein Medium Phasengeschwindigkeit und Brechung elektromagnetischer Wellen frequenzabhängig verändert.
- `requires`: `["549269d3-1aef-5c55-9640-ee2a8e2ee9a1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_WELLEN"],"phase":"Q3"}}`

## 448. Fotoeffekt-Daten auswerten

- ID: `5476480f-7ff2-529f-aade-968198c782a9`
- Beschreibung: Die lernende Person kann Fotoeffekt-Daten mithilfe der Einstein-Gleichung geeignet linearisieren, das Plancksche Wirkungsquantum aus der Steigung unter Berücksichtigung der gewählten Achsengrößen bestimmen und den materialabhängigen Achsenabschnitt deuten.
- `requires`: `["cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f","264dc31c-ec92-5e39-a8b8-16f1d74366d4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"Q3"}}`

## 449. Einzelphotonen-Interferenz

- ID: `c5413852-abae-566b-b435-f9939209ca63`
- Beschreibung: Die lernende Person kann deuten, wie sich aus vielen einzelnen, lokalisierten Photonennachweisen schrittweise ein relatives Häufigkeitsmuster aufbaut, das eine Interferenz-Wahrscheinlichkeitsverteilung sichtbar macht, ohne den Einzelereignissen klassische Bahnen zuzuschreiben.
- `requires`: `["d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec","91571d3f-3651-4477-ba21-320fc4077453"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"Q3"}}`

## 450. Spektrallinien deuten

- ID: `ea2d5085-4ec1-5e33-87e0-15edcad635bf`
- Beschreibung: Spektrallinien mit Bohr/Schrödinger-Modell begründen.
- `requires`: `["d7244ce4-5409-58d1-a1b4-bfae35f391e1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_MATERIE"],"phase":"Q3"}}`

## 451. Laserprinzip (Vertiefung: Resonator-Moden)

- ID: `0172ca41-cc42-51d6-94ad-f0f4680059e4`
- Beschreibung: Die lernende Person kann das Resonatorprinzip und die Modenbildung im Laser erläutern und deren Bedeutung für die Lichtverstärkung deuten.
- `requires`: `["904670af-8e4c-543e-bc9b-e6248d87a10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"Q3"}}`

## 452. Strahlendosis und Schutz

- ID: `e6a50c74-c922-508c-aa27-07bac2566955`
- Beschreibung: Die lernende Person kann Energiedosis, Äquivalentdosis und effektive Dosis unterscheiden, die zur Fragestellung passende Dosisgröße unter benannten Modellannahmen aus gegebenen Daten bestimmen und die Wirksamkeit einer Abschirmung unter sonst vergleichbaren Expositionsbedingungen anhand der Dosisreduktion beurteilen.
- `requires`: `["a12fddce-0215-58d9-bd91-21be8a960d25","71d43fcc-d787-4874-ae4a-2336364e9c0a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"Q4"}}`

## 453. Kernreaktionen und Q-Werte

- ID: `5492f0e0-cbae-574e-a853-182616205ed3`
- Beschreibung: Die lernende Person kann Kernreaktionsgleichungen unter Erhaltung von Ladungs- und Nukleonenzahl vervollständigen, Q-Werte aus den Massen vor und nach der Reaktion bestimmen und deren Vorzeichen als frei werdende oder erforderliche Energie deuten.
- `requires`: `["50877233-7abf-54df-b347-6d3224678fc9","7d78da7f-6af5-440a-9d6b-6cab4bee8dd2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"Q4"}}`

## 454. Beurteilung von Strahlungsrisiken und Kernenergie

- ID: `23fd87f3-9e79-5e0e-b9d1-7c15f3d119e0`
- Beschreibung: Cluster zur fachlichen Bewertung von Strahlungsrisiken und kernenergetischen Entscheidungen.
- `requires`: `[]`
- `contains`: `["bb5c5eab-2fc1-5336-b8cf-14d147695487","7e719cc2-0866-5267-a252-e7e7ac0d03f1"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE","LI_TECHNIK"],"phase":"Q4"}}`

## 455. Strahlungsrisiken mit physikalischen Größen beurteilen

- ID: `bb5c5eab-2fc1-5336-b8cf-14d147695487`
- Beschreibung: Die lernende Person kann Strahlungsrisiken fachlich beurteilen, indem sie Aktivität als Quellenkenngröße von einer zur Fragestellung passenden Dosisgröße unterscheidet, die Energiedeposition pro Masseneinheit oder eine daraus abgeleitete strahlenschutzbezogene Gewichtung beschreibt, und dabei je nach Expositionssituation Strahlungsart, Expositionsdauer, Geometrie und Abstand, Abschirmung sowie Unsicherheit berücksichtigt.
- `requires`: `["e5c08365-a0d3-592c-ad8e-d2c2c6e2b717"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE","LI_TECHNIK"],"phase":"Q4"}}`

## 456. Kernenergieoptionen mit physikalischen Kriterien bewerten

- ID: `7e719cc2-0866-5267-a252-e7e7ac0d03f1`
- Beschreibung: Die lernende Person kann Optionen der Kernenergienutzung mit physikalischen Kriterien und Unsicherheiten strukturiert bewerten.
- `requires`: `["50877233-7abf-54df-b347-6d3224678fc9","7d78da7f-6af5-440a-9d6b-6cab4bee8dd2","979e0d0d-8933-4ace-814f-f28060ad280f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE","LI_TECHNIK"],"phase":"Q4"}}`

## 457. Elementarteilchen und Standardmodell

- ID: `7add799b-2d76-58db-81e5-d54393718f50`
- Beschreibung: Cluster zur modernen Teilchenphysik: Quarks, Leptonen, fundamentale Wechselwirkungen und aktuelle Forschungsperspektiven.
- `requires`: `[]`
- `contains`: `["b3f3f4f7-b5cc-40e1-b57a-3d93649baa61","4e046c1c-bcc7-5e3c-9f71-f80d69027483","4b8b5f4c-c222-57b5-a2f2-ef2efacc03dd","8eb6456b-d915-50ed-a076-2b23c2e5420c","2fab2e3a-1558-5e67-aed0-15fc51c737cd"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q4"}}`

## 458. Elementare Bestandteile der Materie mit Strukturmodellen ordnen

- ID: `b3f3f4f7-b5cc-40e1-b57a-3d93649baa61`
- Beschreibung: Die lernende Person kann elementare Bestandteile der Materie mit einfachen Strukturmodellen ordnen und Quarks, Leptonen sowie ihre Rolle als Bausteine der Materie qualitativ einordnen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 459. Standardmodell: Teilchenfamilien

- ID: `4e046c1c-bcc7-5e3c-9f71-f80d69027483`
- Beschreibung: Die lernende Person kann das Standardmodell als Ordnungsschema beschreiben und Quarks, Leptonen sowie deren grundlegende Eigenschaften benennen.
- `requires`: `["51bc5513-6879-548f-b19a-9746b667f1a3","9e881b3b-68cd-5f52-819f-c2e33b5ba631"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB1","processCompetencies":[],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 460. Hadronen aus Quarks deuten

- ID: `4b8b5f4c-c222-57b5-a2f2-ef2efacc03dd`
- Beschreibung: Die lernende Person kann Protonen, Neutronen und ausgewählte Mesonen als Quark-Systeme beschreiben und die Bedeutung der Quarkstruktur für Materiemodelle erläutern.
- `requires`: `["4e046c1c-bcc7-5e3c-9f71-f80d69027483"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 461. Fundamentale Wechselwirkungen

- ID: `8eb6456b-d915-50ed-a076-2b23c2e5420c`
- Beschreibung: Die lernende Person kann die vier fundamentalen Wechselwirkungen unterscheiden und deren Rolle bei atomaren, nuklearen und kosmischen Prozessen qualitativ erklären.
- `requires`: `["4b8b5f4c-c222-57b5-a2f2-ef2efacc03dd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"Q4"}}`

## 462. Teilchenphysik in der Forschung (CERN)

- ID: `2fab2e3a-1558-5e67-aed0-15fc51c737cd`
- Beschreibung: Die lernende Person kann Ziele und Methoden aktueller Teilchenphysik (z. B. Beschleunigerexperimente) erläutern und Chancen sowie Grenzen großer Forschungsanlagen bewerten.
- `requires`: `["8eb6456b-d915-50ed-a076-2b23c2e5420c","f8704a7b-e93d-4e32-b0f9-1b171545fe28"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Context"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q4"}}`

## 463. Kosmologie vertieft

- ID: `aa0fa5fb-7bfb-5f9f-a606-3f7187cfb745`
- Beschreibung: Die lernende Person kann kosmologische Rotverschiebungen aus Spektraldaten berechnen, sie mithilfe vorgegebener einfacher Modelle mit der Expansion des Universums verknüpfen und die dabei verwendeten Näherungen erläutern.
- `requires`: `["c52d55c3-b687-586c-b0f9-8ffcd1069424","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4"}}`

## 464. Entfernungsbestimmung

- ID: `db6b8de4-21e0-58e8-a347-2ae39f538f92`
- Beschreibung: Die lernende Person kann aus geeigneten Beobachtungsdaten die Entfernung oder Leuchtkraft eines Himmelskörpers abschätzen und begründen, welche zusätzlichen Größen und Modellannahmen dafür benötigt werden.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93","a6469c01-6ca3-5eb2-a82c-94f3d0560b32","f8704a7b-e93d-4e32-b0f9-1b171545fe28"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4"}}`

## 465. Übungen Q4

- ID: `85bbad98-2f48-5d64-85c4-ab6cf67f24c2`
- Beschreibung: Buendelt materialgestuetzte Q4-Klausuraufgaben mit normalem Klausurcharakter zu Quantenobjekten, Relativitaet, Kernphysik, Festkoerperphysik und Astrophysik. Abiturvorschlaege bleiben davon getrennt modelliert.
- `requires`: `[]`
- `contains`: `["b585ff81-6332-5d11-ae63-ee6a9928c00d","a3e22e70-6629-5c74-a8ae-a8c4f55c72a0","4daef009-6425-526a-8574-4fa75f28f946","5a5bc118-4420-5bb7-94c3-67837f2ce0dd","15cb40f1-e2d3-5754-9e7b-e8888fe78340","f532c772-7b6e-59aa-ad65-e0eeafc3767f","0f5346d6-de1b-5e38-aaba-68db205e594b","335a75b0-f691-5867-8ce3-3c971d541b9f","4a58df57-f791-502f-8b8d-9ba155e46035","2f8d4250-66c5-54e9-abb8-80735dc408d2","51af53cb-8866-52cd-b2ca-af8bd8a836e0","4dbe6eb9-4d77-58a9-a15c-f0b8bb110a65","5902ebe8-2025-5a7c-b95d-13057398d6e6","6da29199-f086-512c-89f2-1b5ca865eef9","6c87a996-9166-5c6e-8cda-01d40720f9c8","74a32716-2b46-5d96-8b57-3f6edb90e088","144007cb-e2bc-5c82-bf9d-dda705b15257","71e8936b-fa8a-50dc-8c47-fca015b85ac5","b34f3e03-bbe7-5ede-941c-3f26c9b07bb8","2874902d-eccd-513e-ab60-98892497911d","c518e9dc-8514-5fde-9811-19caa85cfb1a","c77d28e5-a03e-5518-8c3a-55e9e9a2cea3","b3b365f4-4988-57d5-97cd-5d8446483ef7","04832ee1-648a-5421-a01d-0a15c3536c5f","71af215d-c6d5-59ce-a3f6-4a2e60f1216d","f61c424e-f091-5f9d-9d58-c1bd29733fc8","c61b2a69-b5cd-5785-bb04-5d6bca53b218","4ac5a07c-fff0-5eae-890d-89e13eaf69c3","18fb1470-5a03-5277-9486-ae74c63c8a8c","dfeda6e5-3256-557c-a706-bec0d0c89ff4","092017a7-1ce1-54b7-a14c-1658b72d70a7","027d25fc-b609-5383-ac44-5dd3327ca577"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK","LI_KOSMOS","LI_ENERGIE"],"phase":"Q4"}}`

## 466. Sternradien bei gleicher Leuchtkraft vergleichen

- ID: `dfeda6e5-3256-557c-a706-bec0d0c89ff4`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Sternradien bei gleicher Leuchtkraft vergleichen“ selbstständig bearbeiten und ihre Modellentscheidung anhand des Materials begründen.
- `requires`: `["6a73cacc-e86d-5248-a180-fd3da8454b0f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_h1_final_consolidation","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","area":"Astrophysik","demandLevel":"AB3","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"]}}`

## 467. Eine HRD-Entfernung und ihre Annahmen prüfen

- ID: `092017a7-1ce1-54b7-a14c-1658b72d70a7`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Eine HRD-Entfernung und ihre Annahmen prüfen“ selbstständig bearbeiten und ihre Modellentscheidung anhand des Materials begründen.
- `requires`: `["3a4b2f86-5c59-5429-8fb4-75d9b2589cb5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_h2_final_consolidation","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","area":"Astrophysik","demandLevel":"AB3","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"]}}`

## 468. Eine Hauptreihenzeit mit begrenztem Modell abschätzen

- ID: `027d25fc-b609-5383-ac44-5dd3327ca577`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Eine Hauptreihenzeit mit begrenztem Modell abschätzen“ selbstständig bearbeiten und ihre Modellentscheidung anhand des Materials begründen.
- `requires`: `["946ecf7b-0fcf-5776-9fb6-d397423c2f12"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_h3_final_consolidation","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","area":"Astrophysik","demandLevel":"AB3","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"]}}`

## 469. Quantenobjekte, Unbestimmtheit und Messproblem

- ID: `b585ff81-6332-5d11-ae63-ee6a9928c00d`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q4-Klausuraufgabe zu Quantenobjekten, Wellenfunktion, Unbestimmtheit, Komplementaritaet und quantenphysikalischer Messung selbstaendig bearbeiten.
- `requires`: `["ef6d5067-96b0-5388-87dd-5ac4e6a3e313","d05a146f-7fcd-56ae-b9b9-b54203328579","9e881b3b-68cd-5f52-819f-c2e33b5ba631","b05da028-65e4-5cd1-a13c-6c1a95b6dfdf","8c97c234-a932-5e84-aed5-237b4e2a8336","aef1e312-6a0c-5323-9202-c22ae84086f2","48e3d6c2-00bf-5afd-8846-ba3dbd01e96d","d5bff282-741f-4cc5-9622-b77584fdcc5a","727d0946-7019-50ed-8fc6-85db12508733","b9fcbad4-a855-54b7-8017-4caac1e2ffb7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q4","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 470. Laser, Tunneleffekt und Quantenanwendungen

- ID: `a3e22e70-6629-5c74-a8ae-a8c4f55c72a0`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q4-Klausuraufgabe zu Lasern, Tunneleffekt und technischen Anwendungen der Quantenphysik selbstaendig bearbeiten.
- `requires`: `["75f7139f-0f07-5cec-bcea-4f139502b528","2ec48368-ac5b-55f9-a396-5a5fe4e1e874"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q4"}}`

## 471. Radioaktivitaet, Zerfall und Strahlenschutz

- ID: `4daef009-6425-526a-8574-4fa75f28f946`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q4-Klausuraufgabe zu radioaktiver Strahlung, Zerfall, Strahlenschutz und der Beurteilung von Strahlungsrisiken selbstaendig bearbeiten.
- `requires`: `["e5c08365-a0d3-592c-ad8e-d2c2c6e2b717","a12fddce-0215-58d9-bd91-21be8a960d25","3b50255a-6b01-578b-8f5c-4383536a3221","e6a50c74-c922-508c-aa27-07bac2566955","bb5c5eab-2fc1-5336-b8cf-14d147695487","7e719cc2-0866-5267-a252-e7e7ac0d03f1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q4","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE","LI_TECHNIK"],"phase":"Q4"}}`

## 472. Kernreaktionen und Kernmodelle

- ID: `5a5bc118-4420-5bb7-94c3-67837f2ce0dd`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q4-Klausuraufgabe zu Bindungsenergie, Kernreaktionen, Q-Werten und vereinfachten Kernmodellen selbstaendig bearbeiten.
- `requires`: `["cde9b548-2cf4-59ad-b5d4-a71872afbe56","49872cc0-401f-5464-9235-4763df4db5cf","5492f0e0-cbae-574e-a853-182616205ed3","6e7c35e0-7a38-5996-a42e-005038eff0db","76bcbdcb-3003-5e6a-952e-aa36eb8f97ee"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"Q4"}}`

## 473. Standardmodell und Teilchenphysik

- ID: `15cb40f1-e2d3-5754-9e7b-e8888fe78340`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q4-Klausuraufgabe zu Teilchenfamilien, Quarks, fundamentalen Wechselwirkungen und Teilchenphysik in der Forschung selbstaendig bearbeiten.
- `requires`: `["4e046c1c-bcc7-5e3c-9f71-f80d69027483","4b8b5f4c-c222-57b5-a2f2-ef2efacc03dd","8eb6456b-d915-50ed-a076-2b23c2e5420c","2fab2e3a-1558-5e67-aed0-15fc51c737cd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 474. Relativitaet und Raumzeit

- ID: `f532c772-7b6e-59aa-ad65-e0eeafc3767f`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q4-Klausuraufgabe zu spezieller und allgemeiner Relativitaet, Minkowski-Diagrammen und technischen Anwendungen wie GPS selbstaendig bearbeiten.
- `requires`: `["19aef2ed-eb46-55b1-9486-ee83f7520bb6","a9169a74-de19-54a9-a8ac-a2ce43c7342e","6ebb6182-f221-5f4c-b112-4ac72b104321","57ec031c-9a91-5331-81a7-6ef900f7c63e","79da5c34-86b2-5c10-9726-9de886ccef7d","14d99a65-8d58-5647-88ab-02137b96d55b","a08e33db-d821-457b-86dd-870e7648c5f4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Q4","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_KOSMOS"],"phase":"Q4"}}`

## 475. Festkoerperphysik und Halbleiterelektronik

- ID: `0f5346d6-de1b-5e38-aaba-68db205e594b`
- Beschreibung: Die lernende Person kann eine materialgestuetzte Q4-Klausuraufgabe zu Festkoerperphysik, Halbleitern, Dioden, Transistoren und quantenphysikalischen Festkoerpermodellen selbstaendig bearbeiten.
- `requires`: `["70b358bf-da6d-53ba-8393-51d5c2365b04","df010b2b-b182-5f7e-bbe4-49b72e48c27a","d36727cc-ce42-51a3-9425-41afb0b9acdd","853dbe54-85b0-59ab-8f3a-000c2b7746ec","af50bb9a-fd7b-50f5-9698-48c4efe99032"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"Q4"}}`

## 476. Sternentfernungen und kosmologische Beobachtungen auswerten

- ID: `335a75b0-f691-5867-8ce3-3c971d541b9f`
- Beschreibung: Die lernende Person kann eine materialgestützte Q4-Klausuraufgabe zu Sternentfernung und Leuchtkraft sowie Rotverschiebung und Hintergrundstrahlung selbstständig lösen und die Aussagegrenzen der verwendeten Modelle begründen.
- `requires`: `["db6b8de4-21e0-58e8-a347-2ae39f538f92","c52d55c3-b687-586c-b0f9-8ffcd1069424"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4"}}`

## 477. Abiturprüfung Physik (GK)

- ID: `61684ca7-b725-534f-944b-c7645cea1792`
- Beschreibung: Der Lernende kann die schriftliche Abiturprüfung Physik im Grundkurs auf Abiturniveau bearbeiten. Der Release-Anker bündelt die SkillPilot-Beispielklausuren 2026/1 und 2026/2 mit je vier materialgebundenen Vorschlägen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `["abe032d3-97dd-5eaf-964e-0439cea27ac2","f4eac786-a8e1-5f23-aedf-17bc70fc347f"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"abi_gk_offer_2026","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","phase":"Abitur"}}`

## 478. Abiturprüfung Physik (LK)

- ID: `79028c45-90ae-57eb-8016-f5a96af18fa2`
- Beschreibung: Der Lernende kann die schriftliche Abiturprüfung Physik im Leistungskurs auf Abiturniveau bearbeiten. Der Release-Anker bündelt die SkillPilot-Beispielklausuren 2026/1 und 2026/2 mit je vier materialgebundenen Vorschlägen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `["ed3a6f6b-2ca3-51c2-8f00-58e11eb02401","320732e8-1c44-5fa4-9a47-972243cfc32a"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"abi_lk_offer_2026","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","phase":"Abitur"}}`

## 479. Abiturprüfung Physik (GK) - Vorschläge A bis D

- ID: `abe032d3-97dd-5eaf-964e-0439cea27ac2`
- Beschreibung: Materialgebundene Vorschläge A-D für den Grundkurs. Auswahlregel: 4 angeboten, 3 zu bearbeiten.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782","eb1ea150-ec6c-5000-bce3-f46c820dccf8","cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f"]`
- `contains`: `["26c1e946-e858-57ef-a19b-d6bb295c76f4","d8a08f79-befc-5a29-9b74-6481d40c02c3","706703af-b936-5e64-8fe2-ab1128feaf49","d82ac375-2aa8-578a-893a-025e0a27e60f"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_WELLEN","LI_MATERIE","LI_TECHNIK"],"phase":"Abitur"}}`

## 480. LK Abi-Klausur 1

- ID: `ed3a6f6b-2ca3-51c2-8f00-58e11eb02401`
- Beschreibung: Leistungskurs, Klausurbeispiel 2026/1: Vorschläge A bis D.
- `requires`: `["8c9394cb-f54a-508d-9750-4c49e31b3fa9","ac4ba260-6086-5fcc-bea2-c06f1425a1cc","974a2d1c-2225-519d-965f-7744fe8aafd5"]`
- `contains`: `["86015397-23c4-5ed7-b893-bc619ec961a8","fa333c2f-3150-5831-a649-28615164b2f2","e73de7c5-5f09-5e84-8a95-8d764b422ec3","5733c2c5-be2d-5879-89db-4ed4e5f3eff3"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_WELLEN","LI_MATERIE","LI_TECHNIK"],"phase":"Abitur"}}`

## 481. Vorschlag A (GK) - Felder und Induktion

- ID: `26c1e946-e858-57ef-a19b-d6bb295c76f4`
- Beschreibung: Q1.1/Q1.2/Q1.3, 25 BE.
- `requires`: `["1730c01d-8c85-57df-b031-c11e2a0511b1","c6355a22-24cf-5d8b-88af-ea11711460fb","1a037489-3c95-540b-8cae-0acd360358ee","eb1ea150-ec6c-5000-bce3-f46c820dccf8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_TECHNIK"],"phase":"Abitur"}}`

## 482. Vorschlag B (GK) - Schwingungen und Wellen

- ID: `d8a08f79-befc-5a29-9b74-6481d40c02c3`
- Beschreibung: Q2.1/Q2.2/Q2.3, 25 BE.
- `requires`: `["d03f1cb6-c224-53db-ad91-76cc7827978d","3efa0cda-f55b-5534-8fac-ffe1d312aed1","cb0ced6d-b7c1-5b7d-9922-8c394f6030e8","d716a35e-e422-5aba-b39a-f2e22f1e1e74","d5772db3-120c-5c37-ab46-2336d02236b0"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_BEWEGUNG"],"phase":"Abitur"}}`

## 483. Vorschlag C (GK) - Fotoeffekt und Energiestufen

- ID: `706703af-b936-5e64-8fe2-ab1128feaf49`
- Beschreibung: Q3.1/Q3.2, 25 BE.
- `requires`: `["cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f","cf340ce4-8d91-5d22-a1d9-53bf408abdb3","904670af-8e4c-543e-bc9b-e6248d87a10d","974a2d1c-2225-519d-965f-7744fe8aafd5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"Abitur"}}`

## 484. Vorschlag D (GK) - Franck-Hertz und Energiestufen

- ID: `d82ac375-2aa8-578a-893a-025e0a27e60f`
- Beschreibung: Q3.2/Q3.1, 25 BE.
- `requires`: `["cf340ce4-8d91-5d22-a1d9-53bf408abdb3","904670af-8e4c-543e-bc9b-e6248d87a10d","974a2d1c-2225-519d-965f-7744fe8aafd5","cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"Abitur"}}`

## 485. Vorschlag A (LK) - Adaptive Ladespur (Felder/Induktion)

- ID: `86015397-23c4-5ed7-b893-bc619ec961a8`
- Beschreibung: Q1.1/Q1.2/Q1.3, 30 BE.
- `requires`: `["455c65ca-814a-56ad-918a-013155883c52","3b866aea-3e4d-5f23-91de-759148382710","d18d4190-ddc1-5181-b1b6-e79947b737c2","37f28bc4-def2-57cf-a06b-191dfd228205","692db5b6-8be1-5c7b-8307-3a02afb21ea0","a1389d4e-dc97-5557-babe-a31a2bd57217"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_TECHNIK"],"phase":"Abitur"}}`

## 486. Vorschlag B (LK) - Aktives Schwingungsmanagement

- ID: `fa333c2f-3150-5831-a649-28615164b2f2`
- Beschreibung: Q2.1/Q2.2/Q2.3, 30 BE.
- `requires`: `["b2fb9a25-4d26-5cf2-a917-823909dcb6bd","18c1f954-487e-5121-bb18-6c64a82f573d","e160acb4-5b88-509e-8055-2653df420c65","9dba2826-b179-59f0-8d91-5916079e5abe","d716a35e-e422-5aba-b39a-f2e22f1e1e74"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_BEWEGUNG","LI_TECHNIK"],"phase":"Abitur"}}`

## 487. Vorschlag C (LK) - Quantenanalyse einer Spektrallampe

- ID: `e73de7c5-5f09-5e84-8a95-8d764b422ec3`
- Beschreibung: Q3.1/Q3.2, 30 BE.
- `requires`: `["d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec","cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f","904670af-8e4c-543e-bc9b-e6248d87a10d","974a2d1c-2225-519d-965f-7744fe8aafd5","ea2d5085-4ec1-5e33-87e0-15edcad635bf"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"Abitur"}}`

## 488. Vorschlag D (LK) - Röntgen-CT in der Werkstoffprüfung

- ID: `5733c2c5-be2d-5879-89db-4ed4e5f3eff3`
- Beschreibung: Q3.3/Q3.2, 30 BE.
- `requires`: `["48e77690-17f7-5ebe-a8f7-87b2ee9820da","81c0d811-e6de-5489-8415-3b257c734a2e","709e688c-eb07-5f83-a506-82c9bfe0d89f","f6a3a602-1e45-5018-b0ff-3d49933cf634","d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_FELDER","LI_TECHNIK"],"phase":"Abitur"}}`

## 489. Abiturprüfung Physik (GK, 2026/2) - Vorschläge A bis D

- ID: `f4eac786-a8e1-5f23-aedf-17bc70fc347f`
- Beschreibung: Materialgebundene Vorschläge A-D für den Grundkurs. Auswahlregel: 4 angeboten, 3 zu bearbeiten.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782","eb1ea150-ec6c-5000-bce3-f46c820dccf8","cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f"]`
- `contains`: `["58c4b989-5cd0-5bf2-99d1-a0163fc837a1","7be8cb95-7174-5beb-94c5-c0e7bb9b1836","66100588-17bb-58c6-91dd-2349c880dd87","c3c24489-4907-585f-8b56-2cb069aa6bf2"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_WELLEN","LI_MATERIE","LI_TECHNIK"],"phase":"Abitur"}}`

## 490. LK Abi-Klausur 2

- ID: `320732e8-1c44-5fa4-9a47-972243cfc32a`
- Beschreibung: Leistungskurs, Klausurbeispiel 2026/2: Vorschläge A bis D.
- `requires`: `["8c9394cb-f54a-508d-9750-4c49e31b3fa9","ac4ba260-6086-5fcc-bea2-c06f1425a1cc","974a2d1c-2225-519d-965f-7744fe8aafd5"]`
- `contains`: `["cf892388-6cb4-5981-adf2-7168aeb948b1","99954602-819d-57f3-9c09-737e69f162df","422dcfaa-b082-57f0-a987-eec83a63937e","5c6d2ec8-d692-5ad2-a72a-8a9e5544a6c7"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_WELLEN","LI_MATERIE","LI_TECHNIK"],"phase":"Abitur"}}`

## 491. Vorschlag A (GK) - Felder und Induktion im Sensorprüfstand

- ID: `58c4b989-5cd0-5bf2-99d1-a0163fc837a1`
- Beschreibung: Q1.1/Q1.2/Q1.3, 25 BE.
- `requires`: `["1730c01d-8c85-57df-b031-c11e2a0511b1","c6355a22-24cf-5d8b-88af-ea11711460fb","1a037489-3c95-540b-8cae-0acd360358ee","eb1ea150-ec6c-5000-bce3-f46c820dccf8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_TECHNIK"],"phase":"Abitur"}}`

## 492. Vorschlag B (GK) - Schwingungsmonitoring und Wellenwege

- ID: `7be8cb95-7174-5beb-94c5-c0e7bb9b1836`
- Beschreibung: Q2.1/Q2.2/Q2.3, 25 BE.
- `requires`: `["d03f1cb6-c224-53db-ad91-76cc7827978d","3efa0cda-f55b-5534-8fac-ffe1d312aed1","cb0ced6d-b7c1-5b7d-9922-8c394f6030e8","d716a35e-e422-5aba-b39a-f2e22f1e1e74","d5772db3-120c-5c37-ab46-2336d02236b0"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_BEWEGUNG"],"phase":"Abitur"}}`

## 493. Vorschlag C (GK) - Compton-Effekt und Energiestufenmodell

- ID: `66100588-17bb-58c6-91dd-2349c880dd87`
- Beschreibung: Q3.1/Q3.2, 25 BE.
- `requires`: `["d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec","cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f","904670af-8e4c-543e-bc9b-e6248d87a10d","974a2d1c-2225-519d-965f-7744fe8aafd5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"Abitur"}}`

## 494. Vorschlag D (GK) - Balmer-Auswertung und Teilchenwellen

- ID: `c3c24489-4907-585f-8b56-2cb069aa6bf2`
- Beschreibung: Q3.2/Q3.1, 25 BE.
- `requires`: `["974a2d1c-2225-519d-965f-7744fe8aafd5","904670af-8e4c-543e-bc9b-e6248d87a10d","dfa53498-34f5-5326-9d94-87e7b528caf3","d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"Abitur"}}`

## 495. Vorschlag A (LK) - Feldregelung und Transformatorwirkungsgrad

- ID: `cf892388-6cb4-5981-adf2-7168aeb948b1`
- Beschreibung: Q1.1/Q1.2/Q1.3, 30 BE.
- `requires`: `["455c65ca-814a-56ad-918a-013155883c52","3b866aea-3e4d-5f23-91de-759148382710","d18d4190-ddc1-5181-b1b6-e79947b737c2","37f28bc4-def2-57cf-a06b-191dfd228205","692db5b6-8be1-5c7b-8307-3a02afb21ea0","a1389d4e-dc97-5557-babe-a31a2bd57217"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_TECHNIK"],"phase":"Abitur"}}`

## 496. Vorschlag B (LK) - Schwingungsdiagnostik mit Grenzflächenanalyse

- ID: `99954602-819d-57f3-9c09-737e69f162df`
- Beschreibung: Q2.1/Q2.2/Q2.3, 30 BE.
- `requires`: `["b2fb9a25-4d26-5cf2-a917-823909dcb6bd","18c1f954-487e-5121-bb18-6c64a82f573d","e160acb4-5b88-509e-8055-2653df420c65","9dba2826-b179-59f0-8d91-5916079e5abe","d716a35e-e422-5aba-b39a-f2e22f1e1e74"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_BEWEGUNG","LI_TECHNIK"],"phase":"Abitur"}}`

## 497. Vorschlag C (LK) - Quantenanalyse mit Compton und Moseley

- ID: `422dcfaa-b082-57f0-a987-eec83a63937e`
- Beschreibung: Q3.1/Q3.2, 30 BE.
- `requires`: `["d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec","2aa2ef4b-8204-59b9-ad53-71c994cd6180","48e77690-17f7-5ebe-a8f7-87b2ee9820da","81c0d811-e6de-5489-8415-3b257c734a2e","ea2d5085-4ec1-5e33-87e0-15edcad635bf"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"Abitur"}}`

## 498. Vorschlag D (LK) - Röntgen-Qualitätssicherung in der Batteriezellprüfung

- ID: `5c6d2ec8-d692-5ad2-a72a-8a9e5544a6c7`
- Beschreibung: Q3.3/Q3.2, 30 BE.
- `requires`: `["48e77690-17f7-5ebe-a8f7-87b2ee9820da","81c0d811-e6de-5489-8415-3b257c734a2e","709e688c-eb07-5f83-a506-82c9bfe0d89f","f6a3a602-1e45-5018-b0ff-3d49933cf634","d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"Abitur","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_FELDER","LI_TECHNIK"],"phase":"Abitur"}}`

## 499. Messmethoden und Datenanalyse in Aufgaben anwenden

- ID: `0432a422-401b-5134-bf08-05cfd8c7a366`
- Beschreibung: Die lernende Person kann Messunsicherheiten, digitale Datenerfassung und Auswertemethoden in zusammenhängenden, materialgebundenen Übungsaufgaben selbstständig anwenden.
- `requires`: `["8aff7aac-321b-5172-ac55-877876bfd2cd","f6b1d812-ce8b-5852-b417-e6c29b533c7a","b615830a-e8b0-5754-81e0-99da98343a8d","f23fdfa9-38b6-5157-8301-ed302476c456","264dc31c-ec92-5e39-a8b8-16f1d74366d4","75b9ca4c-178e-5df2-adc4-f7f78e9d28e5","691c11d0-fa6a-5d2e-a19c-086e89c3c233","72effc66-87f4-5f5e-8d36-1547677365fb","d67502e3-5e0a-595b-a24b-65b1c40de36e","ac25ffe3-fd42-592d-a937-79cc13460313"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_MATERIE"],"phase":"E"}}`

## 500. Mehrschrittige Bewegungsmodelle mit Reibung und Chaos analysieren

- ID: `dd99528a-bae5-5b78-89e6-c6092c927f8d`
- Beschreibung: Die lernende Person kann Bewegungen mit Reibung, Wurfmodellen, numerischer Simulation und Grenzen der Vorhersagbarkeit in komplexeren Übungsaufgaben verknüpfen.
- `requires`: `["09029573-864f-40ca-bf8a-cee7bf6dcb73","d6dc0e02-831d-4894-a61a-852bcc74f147","68c90ba6-c438-463c-9a53-cf61062d416a","89a8cf15-7ba4-46c1-b1dc-fd161b20d9c2","fbecbd60-5db3-51e8-94be-d66b066ffa06","30ddb2d7-b991-55fe-9e74-37ffe1048f9f","12260012-cf04-5409-b57d-f5b3a46d9126","761a0879-fc15-5d0c-a2b7-2b439efecd5b","e2da5eec-45de-5527-9ad7-16f41cacbe58","39b2a0c4-eecf-5049-b58f-e790790a3bf2","76fd0ab2-079a-516e-a33b-170355336d40","230345f3-c360-4963-b390-ab94e3e2c864"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"E"}}`

## 501. Kontextaufgaben zu Sport, Verkehr und Sicherheit lösen

- ID: `7c0b94b9-2af7-59d4-bfae-278a3418f6a8`
- Beschreibung: Die lernende Person kann physikalische Modelle in Sport- und Verkehrskontexten anwenden und begründete Sicherheitsbewertungen vornehmen.
- `requires`: `["7ead007f-e85a-5cb5-b52d-76aae626119a","e39c83b0-cb4f-5454-a143-b9a159c99cba","4a2bf015-052b-4af0-aed7-324259fa1a8a","1232febe-868a-4dac-b4c2-e35789434601"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"E"}}`

## 502. Grundlagenaufgaben zu Newton, Energie und Impuls lösen

- ID: `be6d4895-65ab-545b-8df9-84e5a308a5e3`
- Beschreibung: Die lernende Person kann Grundlagen zu Newtonschen Axiomen, Energie- und Impulsbetrachtungen in vernetzten Übungsaufgaben sicher anwenden.
- `requires`: `["32b896b9-f2f1-4d4e-96ad-e869ac3d3759","ad984bb6-e225-432a-952d-d83cda40b7f8","a0aaedcb-41f8-4891-af77-a69a76b8c10d","00245a43-eb89-47d2-92d7-21799dbec9f3","94784e0a-7ddc-48be-91fb-dc82b78eb322","7eeff2de-6015-49a6-a96e-a488d886dc9f","6affc2ea-ecd2-4fcd-8877-3ffa15b0425b","253a71d2-e751-4c63-acbe-238b71463cd8","91c49019-ea51-4ce5-a919-c91c45b25e83","d168ae5d-f36f-4ad4-b070-d5931f8d70d1","d30fd37b-1f05-44e3-a40a-4c5a88fa28c2","e790de73-f8e5-4027-bc05-9f12a0e8c9cb","0da13365-02c2-44f1-8a81-d524ca0ac3ae","5a1b3cb2-c0e6-4372-9c57-f33675cffc9b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"phase":"E"}}`

## 503. Gravitation und Weltbilder in GK-Aufgaben verknüpfen

- ID: `7e0308d8-a239-5c0f-b2c0-724f21e4da60`
- Beschreibung: Die lernende Person kann Gravitationsmodelle und historische Weltbilder im Grundkurs in argumentativen und rechnerischen Aufgaben zusammenführen.
- `requires`: `["92d8f398-0c9f-523c-88d7-44165b6b4768","156edddc-ce8d-580d-8d17-d9376d59e60e","eb0ffdea-c12d-56df-b7e8-c0297d2f8aff","a42f91a4-0d21-5aa9-ae11-f48be6f2e431","594f7f21-6b8a-531c-8424-5f1dcbaf0f23","60211ac1-cbe1-5182-87ef-673a068c5b0a","497f1311-17d6-56ff-afb1-422a738e5c16","15b56a1e-3eec-52ca-82fa-b4df9ce88415","25edd154-b1d8-546c-94a5-88502b6725cd","d873ffa2-04b3-5978-a955-89563802a348"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_KOSMOS"],"phase":"E"}}`

## 504. Gravitation und Weltbilder vertieft herleiten (LK)

- ID: `8a1d4093-9832-5010-b1ca-9d32d8c05afa`
- Beschreibung: Die lernende Person kann im Leistungskurs Kepler-Herleitungen, Zentralfeldargumente und die historische Modellentwicklung in anspruchsvollen Aufgaben selbstständig bearbeiten.
- `requires`: `["481ffd56-d585-56fe-b525-ed423e30eed3","1b833656-cd16-5b21-973a-9810960dcfd2","c968d263-8be4-5cf9-b320-e95398fe648f","16caf92e-2800-57d1-946c-5b92ce848a96","89cadf81-143b-5f6b-82bd-29ba20d92a1b","e359f8bb-6106-44aa-9edf-694528d2d2a9","f524f05c-4456-4fc3-a1f7-f40741fc1f16"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_KOSMOS"],"phase":"E"}}`

## 505. Thermodynamik, Entropie und Klimakontexte bewerten

- ID: `6ba2e47f-7e88-5d30-8f1a-3f4b4f785ca1`
- Beschreibung: Die lernende Person kann thermodynamische Rechnungen, Entropieargumente und gesellschaftliche Energieentscheidungen in Übungsaufgaben fachlich bewerten.
- `requires`: `["7fe3022f-fad0-5f41-af1c-d55ff214ebc6","616ac6cf-901b-509a-8cbb-bd422ddecf05","161502b8-e52d-58d0-8f01-9f777b56d392","91b20476-12cf-50d6-880a-ea509ffe8a9a","cbdc0b5f-8a48-5ade-be53-ab6aacaa3e73","aed9161b-ddc4-559c-be8f-baeeddf224f3","f322c268-dc16-5d50-82dd-209834f20208"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE","LI_TECHNIK"],"phase":"E"}}`

## 506. Drehbewegungen in Sport und Technik anwenden

- ID: `6d25344c-35d7-5853-925d-2bccbaf50630`
- Beschreibung: Die lernende Person kann Drehbewegungen in anwendungsnahen Szenarien modellieren, bewerten und in selbstständigen Übungsaufgaben begründen.
- `requires`: `["b49e0f6b-df2a-5643-b3ce-a9dfdf25f3bc","21c0a5f2-4152-549a-aa9c-e02ab772f589","8daaf751-93fe-56d9-8697-ac30237061bd","07f298b2-2f5e-5b16-8150-bc603fa78ecd","5a951a0b-fd6c-51a1-9ffb-2a34ed6d3931","c2c3cdc5-3e87-47c4-89fd-4eb2c5c2f2ea"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"phase":"E","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"E"}}`

## 507. Ladungsträger in Magnetfeldern bei beliebigem Eintrittswinkel beschreiben

- ID: `7fe6f8a1-5580-4e37-bf8e-9772964a6b0a`
- Beschreibung: Die lernende Person kann die Geschwindigkeit eines geladenen Teilchens beim Eintritt in ein homogenes Magnetfeld in feldparallele und feldsenkrechte Komponenten zerlegen und daraus mithilfe der Lorentzkraft Gerad-, Kreis- oder Schraubenbahnen qualitativ deuten.
- `requires`: `["8c9394cb-f54a-508d-9750-4c49e31b3fa9","19f170e4-b88f-4c06-b72a-ce6923748bb4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_BEWEGUNG"],"phase":"Q1"}}`

## 508. Massenspektrometer als Feldanwendung beschreiben

- ID: `3f17d0d2-562d-4c1c-9ebc-1a1a43f28f9c`
- Beschreibung: Die lernende Person kann das Massenspektrometer als technische Anwendung elektrischer und magnetischer Felder beschreiben und die Trennung geladener Teilchen nach dem Verhältnis von Masse und Ladung qualitativ erläutern.
- `requires`: `["741774ef-15fc-4bcf-a370-e2c5cf4257d0","9854589c-5feb-4942-b90f-311ddf36eb78"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"Q1"}}`

## 509. Masse-Energie-Äquivalenz einordnen

- ID: `bfea7a23-1ce1-4a42-badd-1fc9bf30124a`
- Beschreibung: Die lernende Person kann die Masse-Energie-Äquivalenz E₀ = m₀c² als Beziehung zwischen Ruheenergie und invarianter Masse fachlich einordnen und an qualitativen Beispielen deuten.
- `requires`: `["19aef2ed-eb46-55b1-9486-ee83f7520bb6"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_ENERGIE","LI_BEWEGUNG"],"phase":"Q4"}}`

## 510. Bayern Ph10.4 Masse-Energie-Äquivalenz und Kernreaktionen

- ID: `3df08a2c-0dfb-40e5-9605-8baa6259a08e`
- Beschreibung: Bayern-spezifischer Brückencluster für das Sek-I-Ziel zur Energiefreisetzung bei Alpha-Zerfall und einfachen Kernreaktionen mithilfe der Masse-Energie-Äquivalenz.
- `requires`: `[]`
- `contains`: `["7d78da7f-6af5-440a-9d6b-6cab4bee8dd2"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI","jurisdiction:DE-BY"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_by_sek1_mass_energy_bridge","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"DE-BY.PHYSICS.PH10.4.MASS_ENERGY"}}`

## 511. Energiefreisetzung bei Kernreaktionen mit Masse-Energie-Äquivalenz erklären

- ID: `7d78da7f-6af5-440a-9d6b-6cab4bee8dd2`
- Beschreibung: Die lernende Person kann die Energiefreisetzung beim Alpha-Zerfall und bei einfachen Kernreaktionen qualitativ aus der Differenz der Ruhemassensummen vor und nach dem Prozess mithilfe der Masse-Energie-Äquivalenz erklären.
- `requires`: `["1593d95c-2aac-504c-8527-37cb61877da9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_mass_energy_nuclear_release","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.MASS_ENERGY"}}`

## 512. Strömungsphysik

- ID: `a658b54c-94ac-4e9c-93e3-defe1f2508a1`
- Beschreibung: Cluster zur Strömungsphysik: Strömungsphänomene, Kontinuitätsgleichung, ausgewählte Strömungsgesetze, Reynolds-Zahl und qualitative Anwendungen wie dynamischer Auftrieb.
- `requires`: `[]`
- `contains`: `["24b4686a-e8a6-4583-8952-33e6f653c2a3","333ca92b-a92c-46a9-86be-dea8ddbd43e0"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_TECHNIK","LI_ENERGIE"],"phase":"Q4"}}`

## 513. Strömungsbeispiele mit passenden Modellen erklären

- ID: `333ca92b-a92c-46a9-86be-dea8ddbd43e0`
- Beschreibung: Die lernende Person kann an ausgewählten Strömungsbeispielen die Aussagen und Voraussetzungen der jeweils verwendeten Gesetze oder Kennzahlen qualitativ erläutern, etwa der Kontinuitätsgleichung, der Bernoulli-Gleichung, des Stokes-Gesetzes oder der Reynolds-Zahl.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_TECHNIK","LI_ENERGIE"],"phase":"Q4"}}`

## 514. Übungen Sekundarstufe I Physik

- ID: `21ab0854-4d67-5233-9495-ae208e152a3c`
- Beschreibung: Bündelt prüfungsnahe Abschlussaufgaben für Sekundarstufe I Physik. Diese lokale Übungsschicht ist von globalen Abiturankern getrennt.
- `requires`: `[]`
- `contains`: `["a77138b8-3924-4a17-a22e-d2625ab19bd6","ef2bb474-89e1-5deb-81c4-c6b05d174bbd","44ada28b-8635-5481-8d09-2d91686d352b","899481ae-2917-5fb0-805e-29e7c3c051be","1a0dd12c-f30f-5e62-860b-93e393db9ce8","0b8aff9a-6c77-51b9-82d4-725a21f32a90","d8bad724-03ea-510a-8415-928332ed4979","5353aabf-68c9-5788-8c25-8ed7e3ea42f3","9fe4f83e-2065-53f5-8a35-ef4a3b76c17b","924e1187-a067-5eb6-8d8d-85525ee6c837","def74475-7126-5e55-8517-498951118f26","77257ded-ccf0-521f-8a8c-38c8f85fd3ca","11c964ff-be82-5d02-8cd7-ccb41cda8f4f","77b23e86-c39f-589e-8460-b28883baea51","bbe9a270-9b17-519f-8cd7-92c816ac4e29","6c9d0ef3-c82f-534f-8024-6b0efcb88276","68061652-d617-5e51-8d2a-1c686c3c49df","dfd2628f-b44e-51b3-86e8-99158861be8c","b8c3dfb7-9286-52ac-8b0f-ad0a0ce941ed","a77e53d5-246d-52df-86a2-d14f7a08fb77","e1794352-ceee-5c27-8be4-224592ddbb89","b637582c-a618-5698-817a-8d7bd1fa05f6","b7e366e2-8323-5171-83a1-1f536c2062d8","b1808b4c-5e02-5e1f-831f-47ee126e00ee","ac6c578c-401b-5e4b-801a-6dff8fe8b93a","198bfc8c-25f7-5a02-8618-47650ce36d14","1abfd5ef-1f42-5b71-8c9a-80c0a6b0322e","dbe230d5-31e1-5fca-8e11-2226821952ff","93cdaa49-88e8-5e26-8506-656366d9ce3c","8ff2a728-fba3-538e-83e9-69bdd8e1369e","367b17f8-972a-5f3e-8915-8cfe743132a3","654ec964-d982-593d-8c26-407a381675a6","88f27aab-8724-5a4d-8543-e49ebcb54b8e","8f62ab5e-20fc-562f-8121-63c082313e6e","0cf2a5b0-8660-578d-8316-2b8a50fbdff7","ca13e9cd-6377-540e-88c8-0308cddc8a7e","a3c513d0-8fb9-5bd5-88cc-041527ff097d","de7528cc-8c5d-5cd6-8d08-f8ce7457e666","eb5e147f-a67c-542e-858b-533a00af7af2","0b090935-1e43-581b-84ec-078741f8969e","7cb0e5a0-c4ef-5e24-82b6-d8f85ffded8d","2c195204-2e21-5369-8782-7bf4fc41bf9f","44985d9f-7b49-52e4-86ec-eddc7b70429f","35dd0a33-e5d5-53b9-8438-3d339173db1b","00e2ddfe-18c1-57a4-86ad-ee467a1a3d61","3f477f0d-4f79-5eed-8671-fb2667d60910","0acb10a3-c5e2-5a76-8907-3dfe1b57e767","bb7c5191-3c35-5ba6-85e0-795c7a049744","d304cfd0-f87c-51f7-8dee-f5f405da4b3d","e1d3c599-6964-5094-83ee-7fb1ecd161ce","840a82e3-44aa-5d0f-8b6f-8a067d057d14","7072dfbc-f684-5d4e-8c9a-ee74f7ebeeba","d15764ce-ebea-5178-84ea-9351dd808b8c","449d9732-a869-5126-8879-564da5c3d263","119cb138-b0c4-559d-8f1a-a4ae42db0656","1ee79cae-a7da-53cb-86ff-872e8403f033","5a530302-1303-517f-82cc-9cd457b792a8","5f3bbce4-b0b9-5997-8c41-f58b2a8a8fa6","4996346f-ab5d-4d09-9b9e-b9e559af153d","74a32716-2b46-5d96-8b57-3f6edb90e088","d44eb772-acb3-5449-accc-36a1fb7a25a5","e99d87ac-0024-5f2b-ab47-d4d1cebba027","c61b2a69-b5cd-5785-bb04-5d6bca53b218","4ac5a07c-fff0-5eae-890d-89e13eaf69c3","18fb1470-5a03-5277-9486-ae74c63c8a8c"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"physics_seki_practice","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Sekundarstufe I","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE"}}`

## 515. Prüfungsaufgabe: Eine Temperatur fachgerecht messen

- ID: `ef2bb474-89e1-5deb-81c4-c6b05d174bbd`
- Beschreibung: Die lernende Person kann in einer praktischen Prüfungsaufgabe ein zum Messbereich und zur benötigten Auflösung passendes Thermometer auswählen, fachgerecht einsetzen und aus stabilisierten Messwerten ein begründetes Ergebnis mit Einheit angeben.
- `requires`: `["51de4fd9-6827-5b3d-b2ca-5e27ba961a7f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_thermometer_measurement","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.THERMOMETER_MEASUREMENT"}}`

## 516. Prüfungsaufgabe: Thermische Ausdehnung aus Beobachtungen deuten

- ID: `44ada28b-8635-5481-8d09-2d91686d352b`
- Beschreibung: Die lernende Person kann in einer vergleichenden Prüfungsaufgabe beobachtete Längen- und Volumenänderungen beim Erwärmen und Abkühlen qualitativ erklären, Stoffzustände unterscheiden und die Wirkung starrer Begrenzungen beurteilen.
- `requires`: `["b60f63b6-e70b-5557-9f54-86d42fa80325"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_thermal_expansion","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.THERMAL_EXPANSION"}}`

## 517. Prüfungsaufgabe: Reflexionsgesetz und ebenes Spiegelbild untersuchen

- ID: `899481ae-2917-5fb0-805e-29e7c3c051be`
- Beschreibung: Die lernende Person kann in einer zusammenhängenden praktischen Prüfungsaufgabe Einfalls- und Reflexionswinkel selbst messen, zugehörige Ablese- und Ausrichtungsunsicherheiten begründet abschätzen, damit das Reflexionsgesetz prüfen und anschließend Lage, Größe und Virtualität eines ebenen Spiegelbilds konstruieren und erklären.
- `requires`: `["3c8e5510-a12d-5770-8a01-e5fe741b259c","b57427c9-1af5-5daa-8c65-b84a4cc20785"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_reflection_and_plane_mirror","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.REFLECTION_AND_PLANE_MIRROR"}}`

## 518. Prüfungsaufgabe: Mondphasen und Finsternisse räumlich erklären

- ID: `1a0dd12c-f30f-5e62-860b-93e393db9ce8`
- Beschreibung: Die lernende Person kann in einer räumlichen Modellaufgabe Mondphasen aus Beleuchtung und Blickrichtung ableiten, sie von Erdschatten unterscheiden und Sonnen- sowie Mondfinsternisse mit Kern- und Halbschatten erklären.
- `requires`: `["33e3417c-e062-5f4a-8df9-3195dca50089","f0046ae8-cbfc-526b-8414-04e3595b6075"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_moon_phases_and_eclipses","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_KOSMOS"],"phase":"GLOBAL","area":"Optik und Astronomie","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.MOON_PHASES_AND_ECLIPSES"}}`

## 519. Prüfungsaufgabe: Leistung und Wirkungsgrad eines Hebezeugs vergleichen

- ID: `0b8aff9a-6c77-51b9-82d4-725a21f32a90`
- Beschreibung: Die lernende Person kann in einer materialgebundenen Prüfungsaufgabe Energieumsatz, Leistung und Wirkungsgrad zweier Hebezeuge berechnen, die Kennwerte sachgerecht vergleichen und Energieverluste sowie Grenzen des Vergleichs physikalisch erklären.
- `requires`: `["b92827a7-5d62-5fdb-a6f5-ac44461f4a7b","f7f2c254-1663-5861-bed7-a32c00495b19"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_power_and_efficiency","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik und Energie","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.POWER_AND_EFFICIENCY"}}`

## 520. Prüfungsaufgabe: Kräfte experimentell und grafisch untersuchen

- ID: `d8bad724-03ea-510a-8415-928332ed4979`
- Beschreibung: Die lernende Person kann in einer praktischen Prüfungsaufgabe Kraft und elastische Verformung experimentell untersuchen, Masse und Gewichtskraft begrifflich trennen und mehrere Kräfte maßstäblich zu einer Resultierenden zusammensetzen.
- `requires`: `["45bbdf6b-6372-5b6a-b7e4-be15a0eb4b83","41d35667-0296-5f84-bc12-202ffc440be0","9c328f68-41ed-55dd-9e02-34414a6246f2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bavaria_mechanics_lab","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BAVARIA.MECHANICS_LAB"}}`

## 521. Prüfungsaufgabe: Brechung erklären und optische Risiken beurteilen

- ID: `5353aabf-68c9-5788-8c25-8ed7e3ea42f3`
- Beschreibung: Die lernende Person kann Brechung und optische Hebung mithilfe eines Strahlenmodells erklären und den Einsatz von Linsen, Lichtquellen und Lasern anhand konkreter Sicherheitsregeln fachlich beurteilen.
- `requires`: `["6a4c6042-052b-502b-a39a-0ed8941247ac","71b51afd-c71b-506f-8128-d6de36b509d1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bavaria_optics_safety","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BAVARIA.OPTICS_SAFETY"}}`

## 522. Prüfungsaufgabe: Ein thermisches Energiesystem modellieren und bewerten

- ID: `9fe4f83e-2065-53f5-8a35-ef4a3b76c17b`
- Beschreibung: Die lernende Person kann Druckänderungen und Aggregatzustandsänderungen im Teilchenmodell erklären und Energieversorgungsvarianten anhand physikalischer, ökologischer, ökonomischer und gesellschaftlicher Kriterien abgewogen beurteilen.
- `requires`: `["310b4f62-e261-46be-bb1b-1f125fc1699a","873c6371-4ffb-582b-8d8d-3f45f968ba08","5be98160-5189-58aa-8183-1df1c400cc8c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bavaria_thermal_energy_system","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Wärmelehre und Energieversorgung","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BAVARIA.THERMAL_ENERGY_SYSTEM"}}`

## 523. Prüfungsaufgabe: Leitfähigkeit, Kennlinien und Widerstandsnetze untersuchen

- ID: `924e1187-a067-5eb6-8d8d-85525ee6c837`
- Beschreibung: Die lernende Person kann mit sicheren Kleinspannungsversuchen Leitfähigkeit und Kennlinien untersuchen sowie Widerstandsänderungen in Reihen- und Parallelschaltungen vorhersagen, begründen und an Grenzfällen prüfen.
- `requires`: `["baa2bf3c-798a-5ec3-a667-031bf062d96c","66256e22-44a3-5939-8862-821e29d6711d","af7855a3-6aea-5e05-8505-248bc9a8c219","8f833b36-4126-52db-b210-79fb0023c7d9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bavaria_circuit_investigation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizitätslehre","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BAVARIA.CIRCUIT_INVESTIGATION"}}`

## 524. Prüfungsaufgabe: Solarmodule experimentell verschalten und nutzen

- ID: `def74475-7126-5e55-8517-498951118f26`
- Beschreibung: Die lernende Person kann Solarmodule experimentell in Reihen- und Parallelschaltung untersuchen, Einfallswinkel und Beschattung variieren, elektrische Leistung und Wirkungsgrad bilanzieren und die beobachteten Energieumwandlungen für eine geeignete Nutzung deuten.
- `requires`: `["0dd1e39c-8557-5a4e-b467-caae964fff67","cbb26ed2-6979-46f6-a4ae-128f5c5d9d76","46e42b07-c098-5d65-8ef5-8472b7c4d8e2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bavaria_solar_energy_lab","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrische Energie","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BAVARIA.SOLAR_ENERGY_LAB"}}`

## 525. Prüfungsaufgabe: Elektrische Sicherheit fachsprachlich vermitteln

- ID: `77257ded-ccf0-521f-8a8c-38c8f85fd3ca`
- Beschreibung: Die lernende Person kann Gefahren in elektrischen Anlagen und Haushaltsstromkreisen fachlich beurteilen und die begründeten Schutzentscheidungen adressatengerecht und fachsprachlich präsentieren.
- `requires`: `["5ddba212-9e0a-5dd4-8274-239ec51ab6a8","ad62f563-4fee-5399-8d9c-03a214658aa9","6d323d54-0aee-55d0-a9e1-ef2efdea0346"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bavaria_electrical_safety_briefing","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrische Sicherheit und Kommunikation","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BAVARIA.ELECTRICAL_SAFETY_BRIEFING"}}`

## 526. Prüfungsaufgabe: Motor und Transformator untersuchen

- ID: `11c964ff-be82-5d02-8cd7-ccb41cda8f4f`
- Beschreibung: Die lernende Person kann einen einfachen Kleinspannungsmotor aufbauen und gezielt variieren sowie Aufbau, Induktionsprinzip, Spannungs- und Stromübersetzung eines idealen Transformators mit Energieerhaltung erklären.
- `requires`: `["eb30189c-27c6-510b-b235-6543afa18b90","af1094c1-511a-5aae-9e0a-3e9196a82d9a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bavaria_motor_transformer_lab","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektromagnetismus","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BAVARIA.MOTOR_TRANSFORMER_LAB"}}`

## 527. Prüfungsaufgabe: Anwendungen radioaktiver Strahlung abwägen

- ID: `77b23e86-c39f-589e-8460-b28883baea51`
- Beschreibung: Die lernende Person kann Nutzen und Risiken radioaktiver Strahlung in Medizin und Technik anhand gegebener Dosis-, Expositions- und Alternativdaten qualitativ beurteilen und Unsicherheiten des Vergleichs offenlegen.
- `requires`: `["979e0d0d-8933-4ace-814f-f28060ad280f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bavaria_radiation_risk","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Radioaktivität","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BAVARIA.RADIATION_RISK"}}`

## 528. Prüfungsaufgabe: Nuklidschreibweise und Isotope begründen

- ID: `bbe9a270-9b17-519f-8cd7-92c816ac4e29`
- Beschreibung: Die lernende Person kann Nuklidsymbole deuten, Protonen- und Neutronenzahlen bestimmen und Isotopenbeziehungen anhand gleicher Protonen- und unterschiedlicher Neutronenzahlen begründen.
- `requires`: `["f74c691b-0b76-54e0-8fd6-a22211994e0a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_nuclide_notation_isotopes","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.NUCLIDE_NOTATION_ISOTOPES"}}`

## 529. Prüfungsaufgabe: Strahlungsnachweis und Halbwertszeit untersuchen

- ID: `6c9d0ef3-c82f-534f-8024-6b0efcb88276`
- Beschreibung: Die lernende Person kann kontrollierte Detektormessungen fachlich deuten, Alpha-, Beta- und Gammastrahlung anhand von Abschirmdaten und Kernmodellen unterscheiden sowie die Halbwertszeit als statistische Ensemblegröße aus Messdaten bestimmen und erklären.
- `requires`: `["25d91cc0-d84c-5522-86b5-fdff73264f08","1593d95c-2aac-504c-8527-37cb61877da9","16b94a12-ecc5-5b5c-85b6-87b4290bebf8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_radiation_detection_types_half_life","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Radioaktivität","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.RADIATION.DETECTION_TYPES_HALF_LIFE"}}`

## 530. Prüfungsaufgabe: Trägheit, Kraftstoß und Stoßvorgang untersuchen

- ID: `68061652-d617-5e51-8d2a-1c686c3c49df`
- Beschreibung: Die lernende Person kann Trägheit und Kräftegleichgewicht unterscheiden, einen Kraftstoß mit einer Impulsänderung verknüpfen und einen einfachen Stoß mit Impuls- und Energieerhaltung quantitativ untersuchen.
- `requires`: `["2eecd0e2-a7ca-4568-9b12-3d47706c65fb","e790de73-f8e5-4027-bc05-9f12a0e8c9cb","32b896b9-f2f1-4d4e-96ad-e869ac3d3759"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_by_collision_inertia","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW_BY.COLLISION_INERTIA"}}`

## 531. Prüfungsaufgabe: Wurf- und Bremsbewegungen modellieren

- ID: `dfd2628f-b44e-51b3-86e8-99158861be8c`
- Beschreibung: Die lernende Person kann einen waagerechten Wurf als Bewegungsüberlagerung untersuchen und Reaktions- sowie Bremswegmodelle zur Bewertung eines Sicherheitsabstands nutzen.
- `requires`: `["89a8cf15-7ba4-46c1-b1dc-fd161b20d9c2","4a2bf015-052b-4af0-aed7-324259fa1a8a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_by_motion_models","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik und Verkehr","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW_BY.MOTION_MODELS"}}`

## 532. Prüfungsaufgabe: Materiestruktur und radioaktiven Zerfall ordnen

- ID: `b8c3dfb7-9286-52ac-8b0f-ad0a0ce941ed`
- Beschreibung: Die lernende Person kann Quarks und Leptonen in einem einfachen Strukturmodell der Materie einordnen sowie Aktivität, Halbwertszeit und eine Zerfallsfolge aus Daten deuten.
- `requires`: `["b3f3f4f7-b5cc-40e1-b57a-3d93649baa61","a12fddce-0215-58d9-bd91-21be8a960d25"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_by_nuclear_structure_decay","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"GLOBAL","area":"Kern- und Teilchenphysik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW_BY.NUCLEAR_STRUCTURE_DECAY"}}`

## 533. Prüfungsaufgabe: Kernreaktionen und Energieoptionen bewerten

- ID: `a77e53d5-246d-52df-86a2-d14f7a08fb77`
- Beschreibung: Die lernende Person kann Spaltung und Fusion qualitativ unterscheiden und eine Kernenergieoption anhand physikalischer Kriterien, Sicherheitsaspekten und ausgewiesenen Unsicherheiten bewerten.
- `requires`: `["50877233-7abf-54df-b347-6d3224678fc9","7d78da7f-6af5-440a-9d6b-6cab4bee8dd2","7e719cc2-0866-5267-a252-e7e7ac0d03f1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_by_nuclear_reactions_options","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Kernphysik und Energie","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW_BY.NUCLEAR_REACTIONS_OPTIONS"}}`

## 534. Prüfungsaufgabe: Temperatur mit dem Teilchenmodell erklären

- ID: `e1794352-ceee-5c27-8be4-224592ddbb89`
- Beschreibung: Die lernende Person kann absolute Temperatur mit mittlerer kinetischer Teilchenenergie verknüpfen und makroskopische Beobachtungen mithilfe der kinetischen Gastheorie erklären.
- `requires`: `["37b33812-d428-5953-852e-57a53a4347fe"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_by_gas_theory","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW_BY.GAS_THEORY"}}`

## 535. Prüfungsaufgabe: Einen inelastischen Stoß bilanzieren

- ID: `b637582c-a618-5698-817a-8d7bd1fa05f6`
- Beschreibung: Die lernende Person kann einen eindimensionalen inelastischen Stoß mit Impulserhaltung berechnen und die dabei auftretende Energieumwandlung qualitativ deuten.
- `requires`: `["0da13365-02c2-44f1-8a81-d524ca0ac3ae"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_inelastic_collision","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.INELASTIC_COLLISION"}}`

## 536. Prüfungsaufgabe: Einen Fall mit Luftwiderstand modellieren

- ID: `b7e366e2-8323-5171-83a1-1f536c2062d8`
- Beschreibung: Die lernende Person kann einen Fall mit Luftwiderstand aus Geschwindigkeitsdaten modellieren und das Entstehen einer Grenzgeschwindigkeit über das Kräftegleichgewicht erklären.
- `requires`: `["12260012-cf04-5409-b57d-f5b3a46d9126"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_falling_with_drag","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.FALLING_WITH_DRAG"}}`

## 537. Prüfungsaufgabe: Eine Kurvenfahrt mit Zentripetalkraft analysieren

- ID: `b1808b4c-5e02-5e1f-831f-47ee126e00ee`
- Beschreibung: Die lernende Person kann eine gleichförmige Kreisbewegung mit Zentripetalbeschleunigung und Zentripetalkraft quantitativ analysieren und das Modell auf eine Kurvenfahrt anwenden.
- `requires`: `["accb1d9e-cd48-5983-bcef-9b9bca4a9114"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_circular_motion","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.CIRCULAR_MOTION"}}`

## 538. Prüfungsaufgabe: Gravitations- und Rückstellkräfte modellieren

- ID: `ac6c578c-401b-5e4b-801a-6dff8fe8b93a`
- Beschreibung: Die lernende Person kann Gravitations- und Gewichtskräfte berechnen sowie aus Federdaten eine lineare Rückstellkraft als Bedingung einer harmonischen Schwingung deuten.
- `requires`: `["eb0ffdea-c12d-56df-b7e8-c0297d2f8aff","05af2893-0201-4d7f-985b-272d7b88e26e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_gravitation_restoring_force","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_FELDER"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.GRAVITATION_RESTORING_FORCE"}}`

## 539. Prüfungsaufgabe: Energieumwandlungen und Klimawirkungen beurteilen

- ID: `198bfc8c-25f7-5a02-8618-47650ce36d14`
- Beschreibung: Die lernende Person kann reversible und irreversible Vorgänge unterscheiden und eine Energieentscheidung anhand physikalischer Klima- und Umwandlungsdaten fachlich diskutieren.
- `requires`: `["2088ccf0-48f4-51d4-be5f-67affd0fb099","f322c268-dc16-5d50-82dd-209834f20208"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_irreversibility_climate","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Wärmelehre und Energie","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.IRREVERSIBILITY_CLIMATE"}}`

## 540. Prüfungsaufgabe: Halbleiter im Bändermodell deuten

- ID: `1abfd5ef-1f42-5b71-8c9a-80c0a6b0322e`
- Beschreibung: Die lernende Person kann Leiter und Halbleiter im qualitativen Bändermodell unterscheiden und die Wirkung von n- und p-Dotierung auf die Leitfähigkeit erklären.
- `requires`: `["df010b2b-b182-5f7e-bbe4-49b72e48c27a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_band_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Festkörperphysik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.BAND_MODEL"}}`

## 541. Prüfungsaufgabe: Magnetfelder berechnen und Induktion anwenden

- ID: `dbe230d5-31e1-5fca-8e11-2226821952ff`
- Beschreibung: Die lernende Person kann Magnetfelder eines geraden Leiters und einer langen Spule bestimmen und eine technische Induktionsanwendung über die Änderung des magnetischen Flusses erklären.
- `requires`: `["fdcd5faf-f9bf-4fa9-87f4-4e22d8d3387c","106417ed-80db-5490-a1ee-bb4160d3f2b4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_magnet_induction","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektromagnetismus","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.MAGNET_INDUCTION"}}`

## 542. Prüfungsaufgabe: Spektrallinien und Photonen deuten

- ID: `93cdaa49-88e8-5e26-8506-656366d9ce3c`
- Beschreibung: Die lernende Person kann Spektrallinien mit Energieniveaus erklären, Energie und Impuls von Photonen bestimmen und den Quantenobjektcharakter von Licht und Elektronen an Experimenten deuten.
- `requires`: `["904670af-8e4c-543e-bc9b-e6248d87a10d","a359c859-eee0-40ef-a9d1-88db2e6c55b2","d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_by_spectra_photons","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"GLOBAL","area":"Quantenphysik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BY.SPECTRA_PHOTONS"}}`

## 543. Prüfungsaufgabe: Stromstärke und Spannung als Ladungsgrößen deuten

- ID: `8ff2a728-fba3-538e-83e9-69bdd8e1369e`
- Beschreibung: Die lernende Person kann Stromstärke als Ladung pro Zeit und Spannung als Arbeit pro Ladung berechnen und beide Größen im homogenen elektrischen Feld verknüpfen.
- `requires`: `["1730c01d-8c85-57df-b031-c11e2a0511b1","bbee4c52-4e95-5529-990f-706aa99316a3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_by_electric_quantities","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE"],"phase":"GLOBAL","area":"Elektrizitätslehre","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BY.ELECTRIC_QUANTITIES"}}`

## 544. Prüfungsaufgabe: Eine Bewegung digital auswerten

- ID: `367b17f8-972a-5f3e-8915-8cfe743132a3`
- Beschreibung: Die lernende Person kann Ortsdaten aus einem Bewegungsvideo gewinnen, die Bewegung daraus analysieren und zufällige von systematischen Messabweichungen unterscheiden.
- `requires`: `["d67502e3-5e0a-595b-a24b-65b1c40de36e","72effc66-87f4-5f5e-8d36-1547677365fb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_by_digital_video_data","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik und Messmethoden","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BY.DIGITAL_VIDEO_DATA"}}`

## 545. Prüfungsaufgabe: Lichtleitung in einer Glasfaser erklären

- ID: `654ec964-d982-593d-8c26-407a381675a6`
- Beschreibung: Die lernende Person kann Totalreflexion an der Kern-Mantel-Grenze qualitativ erklären und daraus Bedingungen sowie Grenzen der Lichtleitung in einer Glasfaser ableiten.
- `requires`: `["58fc7852-722c-5a67-be6a-bfd1be0b527e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_by_glass_fiber","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BY.GLASS_FIBER"}}`

## 546. Prüfungsaufgabe: Einen Transistor als Schalter deuten

- ID: `88f27aab-8724-5a4d-8543-e49ebcb54b8e`
- Beschreibung: Die lernende Person kann die Schaltfunktion eines vorgegebenen bipolaren Transistoraufbaus materialgestützt begründen und im vorgesehenen Schülerexperiment durch einen tatsächlich hergestellten Aufbau und eigene Beobachtungen nachweisen.
- `requires`: `["7d4d6a39-0c78-5fb0-b7bf-182ed00972f7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_by_transistor","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektronik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BY.TRANSISTOR"}}`

## 547. Prüfungsaufgabe: Kräfte an einer Aufhängung vektoriell bilanzieren

- ID: `8f62ab5e-20fc-562f-8121-63c082313e6e`
- Beschreibung: Die lernende Person kann mehrere Kräfte an einer Aufhängung maßstäblich als Vektoren darstellen, grafisch zur Resultierenden zusammensetzen und die Gleichgewichtsbedingung im Kontext deuten.
- `requires`: `["41d35667-0296-5f84-bc12-202ffc440be0"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_force_vectors","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.FORCE_VECTORS"}}`

## 548. Prüfungsaufgabe: Einen Rettungs- und Materialwagen energetisch bewegen und heben

- ID: `0cf2a5b0-8660-578d-8316-2b8a50fbdff7`
- Beschreibung: Die lernende Person kann kinetische und potenzielle Energie eines Rettungs- und Materialwagens berechnen und einen Flaschenzug als Kraftwandler ohne ideale Arbeitsersparnis deuten.
- `requires`: `["7eeff2de-6015-49a6-a96e-a488d886dc9f","6affc2ea-ecd2-4fcd-8877-3ffa15b0425b","327302e3-5b36-46f8-9c16-73f24583b0eb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_mechanical_energy_machine","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik und Energie","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.MECHANICAL_ENERGY_MACHINE"}}`

## 549. Prüfungsaufgabe: Kernspaltung und Kernfusion einordnen

- ID: `ca13e9cd-6377-540e-88c8-0308cddc8a7e`
- Beschreibung: Die lernende Person kann Kernspaltung und Kernfusion qualitativ unterscheiden und Kernkraftwerk sowie Stern als passende Anwendungs- beziehungsweise Naturbeispiele einordnen.
- `requires`: `["50877233-7abf-54df-b347-6d3224678fc9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_fission_fusion","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"GLOBAL","area":"Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.FISSION_FUSION"}}`

## 550. Prüfungsaufgabe: Stromstärke und Spannung fachgerecht messen

- ID: `a3c513d0-8fb9-5bd5-88cc-041527ff097d`
- Beschreibung: Die lernende Person kann Amperemeter und Voltmeter in einem sicheren Kleinspannungsstromkreis fachgerecht anschließen, geeignete Messbereiche wählen und Messwerte begründet auswerten.
- `requires`: `["f1a078ae-6262-4444-a4bc-a5ab275621cf","28237994-9c24-5a06-82fe-be1f494768ba"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_current_voltage_measurement","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizitätslehre","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.CURRENT_VOLTAGE_MEASUREMENT"}}`

## 551. Prüfungsaufgabe: Eine mobile Energieversorgung elektrisch bilanzieren

- ID: `de7528cc-8c5d-5cd6-8d08-f8ce7457e666`
- Beschreibung: Die lernende Person kann Geräteangaben einer mobilen Energieversorgung einordnen und an deren verzweigtem Stromkreis Knoten- und Maschenbilanzen mit Ladungs- und Energieerhaltung begründen.
- `requires`: `["4a42cddd-7827-5204-87e5-8d9eac7792f1","27b90ce9-b650-5232-85fb-ce2cb69d59a3","267170bd-f880-56a7-9719-ffb9751872c5","8a84de16-2fde-58ec-827a-f803e2ce8564"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_circuit_balances_device_data","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrische Energie und Schaltungen","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.CIRCUIT_BALANCES_DEVICE_DATA"}}`

## 552. Prüfungsaufgabe: Elektrische Gefahren sicher beurteilen

- ID: `eb5e147f-a67c-542e-858b-533a00af7af2`
- Beschreibung: Die lernende Person kann Gefahren an einer elektrischen Anlage, in einem Haushaltsstromkreis und bei Gewitter erkennen und physikalisch begründete Schutzentscheidungen treffen.
- `requires`: `["5ddba212-9e0a-5dd4-8274-239ec51ab6a8","c156d2fb-0fe9-5f13-8baa-3e74d7da151e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_electrical_safety","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrische Sicherheit","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.ELECTRICAL_SAFETY"}}`

## 553. Prüfungsaufgabe: Wärmeübertragung und Treibhauseffekt bilanzieren

- ID: `0b090935-1e43-581b-84ec-078741f8969e`
- Beschreibung: Die lernende Person kann Wärmeleitung, Konvektion und Wärmestrahlung unterscheiden, eine qualitative Energiebilanz abgrenzen und den natürlichen sowie anthropogen verstärkten Treibhauseffekt damit erklären.
- `requires`: `["fbe0faae-7fba-482b-888e-341f926770f3","eeba6bf8-a2b9-4d7d-a1d6-67286c923cef","5a3716dd-ec67-5c48-ba3d-1a29f05ba2ce"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_heat_greenhouse","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Wärmelehre und Klima","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.HEAT_GREENHOUSE"}}`

## 554. Prüfungsaufgabe: Eine kommunale Energieversorgung bewerten

- ID: `7cb0e5a0-c4ef-5e24-82b6-d8f85ffded8d`
- Beschreibung: Die lernende Person kann Energieversorgungssysteme als Übertragungsketten beschreiben und anhand belastbarer Daten sowie offengelegter Kriterien ein abgewogenes Versorgungsurteil formulieren.
- `requires`: `["30a936ec-e427-57fe-bf3e-4abd64b1f0c1","5be98160-5189-58aa-8183-1df1c400cc8c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_energy_supply","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Energieversorgung","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.ENERGY_SUPPLY"}}`

## 555. Prüfungsaufgabe: Farben und Lichtwechselwirkungen in einer Ausstellung erklären

- ID: `2c195204-2e21-5369-8782-7bf4fc41bf9f`
- Beschreibung: Die lernende Person kann Spektralzerlegung, additive und subtraktive Farbmischung sowie Streuung und Absorption an Beobachtungen einer Lichtausstellung unterscheiden und erklären.
- `requires`: `["a4681378-ade4-4f20-bf77-fb020469510f","cdab9fd1-5054-4a7e-8c9a-4474062ddd23","9a9e2085-5ab6-534f-b622-83774d51f36b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_color_light_interactions","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"GLOBAL","area":"Optik und Farben","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.COLOR_LIGHT_INTERACTIONS"}}`

## 556. Prüfungsaufgabe: Brechung und Linsen mit dem Strahlenmodell untersuchen

- ID: `44985d9f-7b49-52e4-86ec-eddc7b70429f`
- Beschreibung: Die lernende Person kann Brechung und Linsenabbildungen mit dem Strahlenmodell beschreiben, konstruieren und die Funktion sowie Grenzen dieses physikalischen Modells erläutern.
- `requires`: `["6a4c6042-052b-502b-a39a-0ed8941247ac","078ce4d2-3193-4cd0-ae59-4fb8ab16e9e5","e5bc2227-d900-585f-8ac0-9d3f1cb40e27"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_refraction_lens_models","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik und Modelle","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.REFRACTION_LENS_MODELS"}}`

## 557. Prüfungsaufgabe: Lochkamera und Auge vergleichen

- ID: `35dd0a33-e5d5-53b9-8438-3d339173db1b`
- Beschreibung: Die lernende Person kann Bildentstehung in der Lochkamera mit geradliniger Lichtausbreitung erklären und den Sehvorgang sowie Kurz- und Weitsichtigkeit am Auge qualitativ deuten.
- `requires`: `["1ab5f599-0927-579d-94cc-feecdf3b5603","90e1e6cf-4092-41d6-81f7-5206f9d68f84"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_pinhole_eye","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"GLOBAL","area":"Optik und Sehen","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.PINHOLE_EYE"}}`

## 558. Prüfungsaufgabe: Schall bei einer Schulveranstaltung untersuchen

- ID: `00e2ddfe-18c1-57a4-86ad-ee467a1a3d61`
- Beschreibung: Die lernende Person kann Schallquelle und -empfänger beschreiben, Tonhöhe, Lautstärke und Geräusch unterscheiden, Schallgeschwindigkeiten datenbasiert vergleichen, den Hörvorgang qualitativ erklären und eine Lärmbelastung für das Ohr beurteilen.
- `requires`: `["c1006f55-0406-48cc-92d4-0d8345897cf4","10aad90e-a1db-42b6-8d1e-1d856e14b47d","a24c41ce-68c5-56a7-8235-ef9a7dba7042","2a6ad2c6-3e1b-57a9-82a1-e6620a532f5c","da0837c7-95a7-5a6a-81db-f33cb7f42d85"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_sound_hearing","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"GLOBAL","area":"Akustik und Hören","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.SOUND_HEARING"}}`

## 559. Prüfungsaufgabe: Ein einfaches Fernrohr im Strahlenmodell deuten

- ID: `3f477f0d-4f79-5eed-8671-fb2667d60910`
- Beschreibung: Die lernende Person kann Aufbau und Bildentstehung eines einfachen Fernrohrs mit Objektiv, Zwischenbild und Okular beschreiben und einen modellhaften Strahlengang deuten.
- `requires`: `["6367d45e-919e-4c19-bcd9-7770a2d51139"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_optical_instrument_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.OPTICAL_INSTRUMENT"}}`

## 560. Prüfungsaufgabe: Klanggestaltung an einer Gitarre untersuchen

- ID: `0acb10a3-c5e2-5a76-8907-3dfe1b57e767`
- Beschreibung: Die lernende Person kann Tonhöhe, Lautstärke und Klang einer Gitarrensaite aus Beobachtungen deuten und die Funktion des Resonanzkörpers erklären.
- `requires`: `["e62e48bc-2387-4b2b-8d6f-7a06c8e7580e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_musical_instrument_sound","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Akustik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.MUSICAL_INSTRUMENT"}}`

## 561. Prüfungsaufgabe: Bildschirm-, Druck- und Körperfarben erklären

- ID: `bb7c5191-3c35-5ba6-85e0-795c7a049744`
- Beschreibung: Die lernende Person kann additive Bildschirmfarben und subtraktive Druckfarben erklären und Farbeindrücke aus Beleuchtung, Oberfläche und dem ins Auge gelangenden Licht ableiten.
- `requires`: `["cc9eea77-2a7f-4f35-ac22-6c230c0d6fa5","1c8dd14c-0fbf-44a5-85a3-25c8e3bd0075"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_color_technology_perception","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Farben","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.COLOR_TECHNOLOGY_PERCEPTION"}}`

## 562. Prüfungsaufgabe: Masse, Volumen und Dichte experimentell bestimmen

- ID: `d304cfd0-f87c-51f7-8dee-f5f405da4b3d`
- Beschreibung: Die lernende Person kann Masse und Volumen regelmäßiger sowie unregelmäßiger Körper fachgerecht messen, daraus Dichten bestimmen und Messwerte samt Einheiten und Fehlerquellen beurteilen.
- `requires`: `["af0e2efb-f634-5f2d-abea-b2e1a67a2894","f827b00f-af7f-52de-84aa-2a2bbaa035bd","f92b5b8a-327f-50d2-8313-6a142399ebf0","c2d6bdf1-8077-50fb-a8b5-2f0b7e3493f0"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_mass_volume_density_lab","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.MASS_VOLUME_DENSITY_LAB"}}`

## 563. Prüfungsaufgabe: Auftrieb in Wasser und Luft erklären

- ID: `e1d3c599-6964-5094-83ee-7fb1ecd161ce`
- Beschreibung: Die lernende Person kann die Auftriebskraft aus Kraftmessungen und verdrängtem Wasser bestimmen und Auftrieb in Wasser und Luft mit dem archimedischen Prinzip sowie Druckunterschieden erklären.
- `requires`: `["e11b2ee9-e528-4857-9ecd-59bd460fba81"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_archimedes_buoyancy","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE","LI_BEWEGUNG"],"phase":"GLOBAL","area":"Druck und Auftrieb","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.ARCHIMEDES_BUOYANCY"}}`

## 564. Prüfungsaufgabe: Auftrieb und Luftwiderstand im Windkanal einordnen

- ID: `840a82e3-44aa-5d0f-8b6f-8a067d057d14`
- Beschreibung: Die lernende Person kann Auftrieb und Luftwiderstand an einer Tragfläche anhand von Kraftmessungen qualitativ beschreiben und einen geeigneten Betriebszustand begründet auswählen.
- `requires`: `["24b4686a-e8a6-4583-8952-33e6f653c2a3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_airfoil_drag","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"GLOBAL","area":"Druck und Auftrieb","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.AIRFOIL_DRAG"}}`

## 565. Prüfungsaufgabe: Reibung beim Ziehen und Gehen deuten

- ID: `7072dfbc-f684-5d4e-8c9a-ee74f7ebeeba`
- Beschreibung: Die lernende Person kann Haft- und Gleitreibung als Kontaktkräfte deuten, ihre Richtung in konkreten Situationen bestimmen und erklären, wie Reibung Bewegung hemmt oder Fortbewegung ermöglicht.
- `requires`: `["581c0766-b84b-54cb-b8b6-375310329a41"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_friction_contact_force","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.FRICTION_CONTACT_FORCE"}}`

## 566. Prüfungsaufgabe: Kraft und Weg an einfachen Maschinen vergleichen

- ID: `d15764ce-ebea-5178-84ea-9351dd808b8c`
- Beschreibung: Die lernende Person kann Flaschenzug und Hebel als Kraftwandler analysieren und über Kraft-Weg-Produkte erklären, warum eine kleinere Kraft ideal keine mechanische Arbeit einspart.
- `requires`: `["327302e3-5b36-46f8-9c16-73f24583b0eb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_simple_machines_force_distance","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.SIMPLE_MACHINES_FORCE_DISTANCE"}}`

## 567. Prüfungsaufgabe: Wirkungslinien und Schwerpunkt an einer Planke deuten

- ID: `449d9732-a869-5126-8879-564da5c3d263`
- Beschreibung: Die lernende Person kann Angriffspunkte und Wirkungslinien an einem starren Körper kennzeichnen, die Gewichtskraft im Schwerpunkt modellieren und Gleichgewicht sowie Drehrichtung aus den Drehwirkungen ableiten.
- `requires`: `["67ffd0f0-a5ab-518f-8c45-4c0e7eb18390"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_force_line_center_of_gravity","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_BEWEGUNG","LI_TECHNIK"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.FORCE_LINE_CENTER_OF_GRAVITY"}}`

## 568. Sek-I-Abschlussaufgaben Physik selbstständig lösen

- ID: `3631c8f7-ff48-57ff-b7ee-8397ff1d166a`
- Beschreibung: Die lernende Person kann eine prüfungsnahe, materialgebundene Physikaufgabe der Sekundarstufe I selbstständig bearbeiten und fachlich begründet auswerten.
- `requires`: `["940978fa-1f2d-4e54-9c28-081a6df9b76f","9ac4973a-21d5-48a5-90b4-eb90e10391ae","fbe0faae-7fba-482b-888e-341f926770f3","5308de76-79f0-44f4-8cb7-fc9de4772217","310b4f62-e261-46be-bb1b-1f125fc1699a","e11b2ee9-e528-4857-9ecd-59bd460fba81","24b4686a-e8a6-4583-8952-33e6f653c2a3","a4681378-ade4-4f20-bf77-fb020469510f","cdab9fd1-5054-4a7e-8c9a-4474062ddd23","1c8dd14c-0fbf-44a5-85a3-25c8e3bd0075","cc9eea77-2a7f-4f35-ac22-6c230c0d6fa5","c1006f55-0406-48cc-92d4-0d8345897cf4","3c82510a-1f12-4eaa-81c2-8599437a5b85","a24c41ce-68c5-56a7-8235-ef9a7dba7042","10aad90e-a1db-42b6-8d1e-1d856e14b47d","e62e48bc-2387-4b2b-8d6f-7a06c8e7580e","2a6703e0-2a6f-4ebf-a5c6-7aa05a4b86eb","25d91cc0-d84c-5522-86b5-fdff73264f08","861ba00a-e89c-5b3d-8c76-8ff0bcb0f1cd","979e0d0d-8933-4ace-814f-f28060ad280f","dd7cdcea-0950-461b-96ac-ce49989fca47","79cb1695-f985-443a-b93e-27b57ab474b7","53196a71-9dbd-4835-b2f9-ff21b8a8962c","01bebdfc-5819-4610-a03e-ea5e794fc954","8a84de16-2fde-58ec-827a-f803e2ce8564","267170bd-f880-56a7-9719-ffb9751872c5","8f833b36-4126-52db-b210-79fb0023c7d9","5ddba212-9e0a-5dd4-8274-239ec51ab6a8","c156d2fb-0fe9-5f13-8baa-3e74d7da151e","f778a659-1467-4aa7-97b2-bed78c530634","a5f652cc-e091-4c90-bec2-c357ae54fcf1","f1a078ae-6262-4444-a4bc-a5ab275621cf","078ce4d2-3193-4cd0-ae59-4fb8ab16e9e5","90e1e6cf-4092-41d6-81f7-5206f9d68f84","6367d45e-919e-4c19-bcd9-7770a2d51139","ae67bcf1-f3ee-50d6-9a12-25a159dff659","5ea765ac-c279-551a-8a94-a07da2381e5b","581c0766-b84b-54cb-b8b6-375310329a41","327302e3-5b36-46f8-9c16-73f24583b0eb","722857cf-f327-5740-8151-64eb92195ec8","eeba6bf8-a2b9-4d7d-a1d6-67286c923cef","cbb26ed2-6979-46f6-a4ae-128f5c5d9d76","5355fee0-0477-5570-a234-561477bf77ba","da26294f-4316-5bd5-a37a-bd89397b3b8b","e5bc2227-d900-585f-8ac0-9d3f1cb40e27","3ed3279e-c524-5230-a277-dda89493df6d","9a9e2085-5ab6-534f-b622-83774d51f36b","6a4c6042-052b-502b-a39a-0ed8941247ac","1ab5f599-0927-579d-94cc-feecdf3b5603","30a936ec-e427-57fe-bf3e-4abd64b1f0c1","baa2bf3c-798a-5ec3-a667-031bf062d96c","66256e22-44a3-5939-8862-821e29d6711d","af7855a3-6aea-5e05-8505-248bc9a8c219","4a42cddd-7827-5204-87e5-8d9eac7792f1","27b90ce9-b650-5232-85fb-ce2cb69d59a3","5a3716dd-ec67-5c48-ba3d-1a29f05ba2ce","5be98160-5189-58aa-8183-1df1c400cc8c","1593d95c-2aac-504c-8527-37cb61877da9","16b94a12-ecc5-5b5c-85b6-87b4290bebf8","50877233-7abf-54df-b347-6d3224678fc9","d3c153b9-e09b-5668-8386-73105546a7c1","ad62f563-4fee-5399-8d9c-03a214658aa9","d2e6f87d-795b-5631-a7cc-0bfb5dc5142e","6d323d54-0aee-55d0-a9e1-ef2efdea0346","b378c8b3-5e83-5abf-8243-b0f345037bfc","0dd1e39c-8557-5a4e-b467-caae964fff67","46e42b07-c098-5d65-8ef5-8472b7c4d8e2","9c328f68-41ed-55dd-9e02-34414a6246f2","45bbdf6b-6372-5b6a-b7e4-be15a0eb4b83","873c6371-4ffb-582b-8d8d-3f45f968ba08","71b51afd-c71b-506f-8128-d6de36b509d1","eb30189c-27c6-510b-b235-6543afa18b90","af1094c1-511a-5aae-9e0a-3e9196a82d9a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_practice_capstone","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Sekundarstufe I","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.CAPSTONE"}}`

## 569. Bayern Ph10.4-Aufgabe zur Energiefreisetzung bei Kernreaktionen lösen

- ID: `a77138b8-3924-4a17-a22e-d2625ab19bd6`
- Beschreibung: Die lernende Person kann eine prüfungsnahe Aufgabe zur Energiefreisetzung beim Alpha-Zerfall und bei einfachen Kernreaktionen mithilfe der Masse-Energie-Äquivalenz selbstständig bearbeiten.
- `requires`: `["7d78da7f-6af5-440a-9d6b-6cab4bee8dd2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI","jurisdiction:DE-BY"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_by_sek1_mass_energy_practice","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE","LI_MATERIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"DE-BY.PHYSICS.PH10.4.MASS_ENERGY.PRACTICE"}}`

## 570. Prüfungsaufgabe: Ladungstrennung und Kondensator im Modell erklären

- ID: `119cb138-b0c4-559d-8f1a-a4ae42db0656`
- Beschreibung: Die lernende Person kann Ladungsumverteilung zwischen zwei anschließend getrennten Leitern erklären, dabei die Erhaltung der Gesamtladung nutzen und das Modell auf einen geladenen Kondensator sowie eine umgekehrte Polung übertragen.
- `requires`: `["dc7dd287-6eac-574d-818d-65cfb23a2d94","80dd0a2b-1422-5b00-89ff-ec4d0faa047e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_charge_separation_and_capacitor_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizitätslehre","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.CHARGE_SEPARATION_AND_CAPACITOR_MODEL"}}`

## 571. Prüfungsaufgabe: Magnetpole und Wirkungen des elektrischen Stroms untersuchen

- ID: `1ee79cae-a7da-53cb-86ff-872e8403f033`
- Beschreibung: Die lernende Person kann Anziehung und Abstoßung von Magnetpolen vorhersagen, Magnetisierung mit dem Elementarmagnetmodell erklären und magnetische, Licht-, Wärme- sowie chemische Wirkungen des elektrischen Stroms unterscheiden.
- `requires`: `["f778a659-1467-4aa7-97b2-bed78c530634","a5f652cc-e091-4c90-bec2-c357ae54fcf1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_magnetic_poles_and_current_effects","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_MATERIE","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Magnetismus und Elektrizitätslehre","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.MAGNETIC_POLES_AND_CURRENT_EFFECTS"}}`

## 572. Prüfungsaufgabe: Kennlinien und Widerstandsnetze untersuchen

- ID: `5a530302-1303-517f-82cc-9cd457b792a8`
- Beschreibung: Die lernende Person kann eine Strom-Spannungs-Kennlinie experimentell untersuchen und begründet vorhersagen, wie Widerstandsänderungen Reihen- und Parallelschaltungen einschließlich geeigneter Grenzfälle beeinflussen.
- `requires`: `["66256e22-44a3-5939-8862-821e29d6711d","8f833b36-4126-52db-b210-79fb0023c7d9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_characteristics_and_resistor_networks","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizitätslehre","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.CHARACTERISTICS_AND_RESISTOR_NETWORKS"}}`

## 573. Prüfungsaufgabe: Strom- und Spannungsbilanzen in einem Versorgungsnetz begründen

- ID: `5f3bbce4-b0b9-5997-8c41-f58b2a8a8fa6`
- Beschreibung: Die lernende Person kann an einem verzweigten Gleichspannungsnetz Strombilanzen mit Ladungserhaltung und Spannungsbilanzen mit der übertragenen Energie pro Ladung aufstellen, prüfen und begründen.
- `requires`: `["8a84de16-2fde-58ec-827a-f803e2ce8564","267170bd-f880-56a7-9719-ffb9751872c5"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_node_and_loop_balances","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrische Energie und Schaltungen","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.NODE_AND_LOOP_BALANCES"}}`

## 574. E-Phase-Klausuraufgaben Physik selbstständig lösen

- ID: `7f83e25c-38f7-5ac2-8f9c-ec54eeef1026`
- Beschreibung: Die lernende Person kann eine prüfungsnahe, materialgebundene Physik-Klausuraufgabe der Phase E selbstständig bearbeiten und fachlich begründet auswerten.
- `requires`: `["2eecd0e2-a7ca-4568-9b12-3d47706c65fb","8aff7aac-321b-5172-ac55-877876bfd2cd","f6b1d812-ce8b-5852-b417-e6c29b533c7a","b615830a-e8b0-5754-81e0-99da98343a8d","f23fdfa9-38b6-5157-8301-ed302476c456","264dc31c-ec92-5e39-a8b8-16f1d74366d4","75b9ca4c-178e-5df2-adc4-f7f78e9d28e5","691c11d0-fa6a-5d2e-a19c-086e89c3c233","72effc66-87f4-5f5e-8d36-1547677365fb","7ead007f-e85a-5cb5-b52d-76aae626119a","e39c83b0-cb4f-5454-a143-b9a159c99cba","4a2bf015-052b-4af0-aed7-324259fa1a8a","d67502e3-5e0a-595b-a24b-65b1c40de36e","ce431132-dfc4-42c2-aff6-bd72035190f8","971beafa-6ba5-4c82-ac8b-7ebf66eec3dd","e4b38061-1f28-43ad-8371-a3e7c0e81856","09029573-864f-40ca-bf8a-cee7bf6dcb73","d6dc0e02-831d-4894-a61a-852bcc74f147","c1c71daa-042b-4f4c-8c31-0ac366f5149e","31a2ef52-114b-4d2c-a720-6ef5a390b6dc","32b896b9-f2f1-4d4e-96ad-e869ac3d3759","a94cfe1c-6f87-47ff-b4f3-31a58d4c6c20","ad984bb6-e225-432a-952d-d83cda40b7f8","a0aaedcb-41f8-4891-af77-a69a76b8c10d","00245a43-eb89-47d2-92d7-21799dbec9f3","5f289cdc-fda1-4058-b44f-041ba1398e79","94784e0a-7ddc-48be-91fb-dc82b78eb322","7eeff2de-6015-49a6-a96e-a488d886dc9f","6affc2ea-ecd2-4fcd-8877-3ffa15b0425b","594f7f21-6b8a-531c-8424-5f1dcbaf0f23","253a71d2-e751-4c63-acbe-238b71463cd8","91c49019-ea51-4ce5-a919-c91c45b25e83","cbdc0b5f-8a48-5ade-be53-ab6aacaa3e73","839ecc8f-3a60-418b-bc92-64bfeef33824","d168ae5d-f36f-4ad4-b070-d5931f8d70d1","d30fd37b-1f05-44e3-a40a-4c5a88fa28c2","e790de73-f8e5-4027-bc05-9f12a0e8c9cb","1232febe-868a-4dac-b4c2-e35789434601","0da13365-02c2-44f1-8a81-d524ca0ac3ae","e359f8bb-6106-44aa-9edf-694528d2d2a9","f524f05c-4456-4fc3-a1f7-f40741fc1f16","68c90ba6-c438-463c-9a53-cf61062d416a","89a8cf15-7ba4-46c1-b1dc-fd161b20d9c2","ec7a0a68-730b-5c94-ac72-a937508f8303","e918b31f-6f39-5dee-ade6-3617080fb24f","accb1d9e-cd48-5983-bcef-9b9bca4a9114","e2da5eec-45de-5527-9ad7-16f41cacbe58","39b2a0c4-eecf-5049-b58f-e790790a3bf2","fbecbd60-5db3-51e8-94be-d66b066ffa06","5fd45dbc-0eb1-591b-99a9-7386336f1456","30ddb2d7-b991-55fe-9e74-37ffe1048f9f","12260012-cf04-5409-b57d-f5b3a46d9126","ac25ffe3-fd42-592d-a937-79cc13460313","761a0879-fc15-5d0c-a2b7-2b439efecd5b","76fd0ab2-079a-516e-a33b-170355336d40","92d8f398-0c9f-523c-88d7-44165b6b4768","156edddc-ce8d-580d-8d17-d9376d59e60e","eb0ffdea-c12d-56df-b7e8-c0297d2f8aff","a42f91a4-0d21-5aa9-ae11-f48be6f2e431","60211ac1-cbe1-5182-87ef-673a068c5b0a","497f1311-17d6-56ff-afb1-422a738e5c16","16caf92e-2800-57d1-946c-5b92ce848a96","89cadf81-143b-5f6b-82bd-29ba20d92a1b","15b56a1e-3eec-52ca-82fa-b4df9ce88415","25edd154-b1d8-546c-94a5-88502b6725cd","d873ffa2-04b3-5978-a955-89563802a348","481ffd56-d585-56fe-b525-ed423e30eed3","1b833656-cd16-5b21-973a-9810960dcfd2","c968d263-8be4-5cf9-b320-e95398fe648f","88d07c80-5d7d-5c70-b385-b22769381e44","37b33812-d428-5953-852e-57a53a4347fe","2088ccf0-48f4-51d4-be5f-67affd0fb099","5f17e992-fd07-56ee-80a0-567f45bbd10c","912a5489-abcc-55f9-8f1a-9ee1e2d7fd9d","36c4590c-6032-5a37-b660-f15951dee076","0de2ca8c-7272-59ed-9c89-0971d6ce2f47","239aac49-1137-5df5-b197-49e72292e40c","e713dc34-beeb-5807-8a90-f872e049aa4e","6e79ef4a-2666-5f7a-885c-b175954506f8","741e7056-69e4-59be-a159-0e2583d748d1","eaef821b-4dbe-52a4-a0e2-574e5ce2040d","14099861-897c-53f4-8c6c-48d088ee9f01","be921c3b-7db9-50b5-a110-92f31673fc62","81a45dec-37be-529b-89ce-2f3101237293","616ac6cf-901b-509a-8cbb-bd422ddecf05","b61d233a-1902-526b-a9b5-6b3d553f4013","b6dfd3e6-2dd3-5983-9a27-7e7db70e8db8","77604656-7ffe-516c-8af3-7cbe7de2f2a4","d0cebf18-8b2a-52d6-857d-ef18cd64541c","161502b8-e52d-58d0-8f01-9f777b56d392","91b20476-12cf-50d6-880a-ea509ffe8a9a","18058384-a1bc-5ba2-8f5d-1fe9498acbf0","aed9161b-ddc4-559c-be8f-baeeddf224f3","f322c268-dc16-5d50-82dd-209834f20208","cd1903a5-d70a-5320-9124-b6b24917ba14","fb73c94b-6a23-5351-8fef-db2c2533e361","7fe3022f-fad0-5f41-af1c-d55ff214ebc6","7982cd8e-2151-59e7-858d-c1361c5d249e","93ece389-78c5-5141-9ef1-c68bd558306e","23c5382a-4b0f-5715-84b5-cf87b8323152","73b5af24-7750-520a-bb16-43136ce19a5c","cf570e66-2ce2-5923-9033-c97d74119553","37f17e7e-9fcf-5dca-ac10-e94cb8420be5","642aebd7-66cd-5a50-b543-73c4b207525d","5a951a0b-fd6c-51a1-9ffb-2a34ed6d3931","c2c3cdc5-3e87-47c4-89fd-4eb2c5c2f2ea","b49e0f6b-df2a-5643-b3ce-a9dfdf25f3bc","21c0a5f2-4152-549a-aa9c-e02ab772f589","8daaf751-93fe-56d9-8697-ac30237061bd","07f298b2-2f5e-5b16-8150-bc603fa78ecd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_e_practice_capstone","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_TECHNIK"],"phase":"E","area":"Klausurtraining","topicCode":"CANONICAL.PHYSICS.E.PRACTICE.CAPSTONE"}}`

## 575. Q1-Klausuraufgaben Physik selbstständig lösen

- ID: `d441ee2f-9230-5751-832b-5b0b5cf14605`
- Beschreibung: Die lernende Person kann eine prüfungsnahe, materialgebundene Physik-Klausuraufgabe der Phase Q1 selbstständig bearbeiten und fachlich begründet auswerten.
- `requires`: `["a6e48b88-51ed-5942-bdb8-8d2192652e0d","bbee4c52-4e95-5529-990f-706aa99316a3","8da5c981-8216-5fcd-a393-19f392ae2006","98e42cda-9e5d-5910-b2c0-3e631fd20c78","4ca83b3f-3605-5c0d-abc4-9f24b9e29bbe","1730c01d-8c85-57df-b031-c11e2a0511b1","9f59a088-3939-59e9-821d-167fadfda782","0b4f2020-8486-5372-9cb9-6e59f698ac2d","fd9fd8ad-c4a1-5552-9ea0-1878e0636f20","0f803c37-8191-5a07-9b31-9603ded98fe2","741774ef-15fc-4bcf-a370-e2c5cf4257d0","5fda8623-69e0-5503-9c6d-86d054a8cf91","58db62d4-458f-5e2d-9ca0-968e09f4944b","d02438ba-0cc9-5993-831e-5e44d35e32c4","9854589c-5feb-4942-b90f-311ddf36eb78","0f6b798b-594e-5480-8c5f-95e2486a4d85","106417ed-80db-5490-a1ee-bb4160d3f2b4","c6355a22-24cf-5d8b-88af-ea11711460fb","8c9394cb-f54a-508d-9750-4c49e31b3fa9","52bdabb2-d9a1-56e6-bccf-ff58f299c739","455c65ca-814a-56ad-918a-013155883c52","73b309ed-1aab-5778-8494-d9b65f5a352b","2622bef1-bdbc-504e-b468-b600b2ca3ed8","330808f6-789a-583d-86df-e271a7683d8b","09f2cdbd-64e0-55d2-ada7-1190f4fd50df","74a74132-fa39-541c-8d3c-696cf228452d","8d34228c-da38-5c1e-97cc-571f3eafb9f4","3b866aea-3e4d-5f23-91de-759148382710","b39ae8fb-4358-5866-8adf-3d5365368eeb","0924162b-46d0-5c56-93bc-33e1f5ac6886","966782e5-690d-4fae-bbab-fa3fa30525c3","2d62b444-796e-548d-aeee-cfd9c6665ddc","7fe6f8a1-5580-4e37-bf8e-9772964a6b0a","3f17d0d2-562d-4c1c-9ebc-1a1a43f28f9c","25998fed-ea4d-4c3e-b606-e965b5d7f290","f3de5922-dd45-4fb6-87c1-525d1952dd89","9fb1dd85-11b7-4a5a-b124-27fea8d1788e","e3bce51c-cfeb-4706-b95e-a22b76e7dd73","38e0ff49-f132-44c8-b17a-73dada5344db"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_q1_practice_capstone","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_TECHNIK"],"phase":"Q1","area":"Klausurtraining","topicCode":"CANONICAL.PHYSICS.Q1.PRACTICE.CAPSTONE"}}`

## 576. Q2-Klausuraufgaben Physik selbstständig lösen

- ID: `50328a4f-91e8-5c8b-8d61-8f9c98a5cddf`
- Beschreibung: Die lernende Person kann eine prüfungsnahe, materialgebundene Physik-Klausuraufgabe der Phase Q2 selbstständig bearbeiten und fachlich begründet auswerten.
- `requires`: `["d03f1cb6-c224-53db-ad91-76cc7827978d","fcf8580c-ecfd-58ea-bbf5-a1b29c9ecf8e","05af2893-0201-4d7f-985b-272d7b88e26e","78cf6eff-b3bc-5444-9ef8-5d39dae8d17d","e6895bc3-fcbd-59ad-baef-a78c97a13e11","3efa0cda-f55b-5534-8fac-ffe1d312aed1","e5c33afc-a233-50ff-a17f-63c085dfb89c","a522c8c0-f3a4-5568-acae-3010ed9feb87","1a037489-3c95-540b-8cae-0acd360358ee","eb1ea150-ec6c-5000-bce3-f46c820dccf8","ac4ba260-6086-5fcc-bea2-c06f1425a1cc","a844895e-2cdc-4665-aad2-a49c62f11759","f36a5946-f2a8-59b8-b3bd-a2f246defa4f","a7255b83-336c-4d42-ba5c-bc2f6248ea36","37f28bc4-def2-57cf-a06b-191dfd228205","fdcd5faf-f9bf-4fa9-87f4-4e22d8d3387c","ffbbf243-c2eb-4330-b050-837de994c130","cb0ced6d-b7c1-5b7d-9922-8c394f6030e8","158e1c19-7ccb-4c8c-931c-b685951ab161","9dba2826-b179-59f0-8d91-5916079e5abe","d716a35e-e422-5aba-b39a-f2e22f1e1e74","85157cf0-7f68-5aea-b375-0f9797008cc9","f47a7fa0-b929-5264-b038-b83fd682967f","e7131fe3-1da6-5555-80ec-fb6bdf8fcc29","d5772db3-120c-5c37-ab46-2336d02236b0","0d2a4690-d891-503b-96f4-42c2de48fd8b","b2fb9a25-4d26-5cf2-a917-823909dcb6bd","18c1f954-487e-5121-bb18-6c64a82f573d","c0205f47-185c-5e27-b89c-c3ff8809b1d1","4888444f-4520-437a-9ba7-e74e8f8ed129","d18d4190-ddc1-5181-b1b6-e79947b737c2","692db5b6-8be1-5c7b-8307-3a02afb21ea0","a1389d4e-dc97-5557-babe-a31a2bd57217","e160acb4-5b88-509e-8055-2653df420c65","215f5558-562c-5686-b649-931f324c7983","1c430e0a-b63e-5729-8715-a96a5a68740f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_q2_practice_capstone","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_TECHNIK"],"phase":"Q2","area":"Klausurtraining","topicCode":"CANONICAL.PHYSICS.Q2.PRACTICE.CAPSTONE"}}`

## 577. Q3-Klausuraufgaben Physik selbstständig lösen

- ID: `a94f9b05-ecb1-5a13-8364-44c1c98be8e4`
- Beschreibung: Die lernende Person kann eine prüfungsnahe, materialgebundene Physik-Klausuraufgabe der Phase Q3 selbstständig bearbeiten und fachlich begründet auswerten.
- `requires`: `["4a7cbe83-b694-57d3-85ce-1eeca418daaf","5da7d4d0-878e-44fd-b398-1b1de8b636a4","5b90066f-b5b3-4e82-8d31-7b95ff0a0451","8ad305d2-bde0-4223-9477-517b2943148b","c71315c1-f329-4289-a145-d99819da7bad","2c6af966-7703-4176-a117-5ddb8295bedf","31ed4e95-3ed4-4cfb-9b11-9f3c1341f2d4","c2b6acd8-b298-4e4e-aa7a-553a8a65f913","549269d3-1aef-5c55-9640-ee2a8e2ee9a1","58fc7852-722c-5a67-be6a-bfd1be0b527e","6270e558-d657-5363-a6b2-e49a032a453b","91683676-01cf-5003-80fa-a04d043b4e61","4c919da9-157a-5a14-a725-f7343975c9ab","f75c494c-5723-5cd8-8ec9-dc3d8ec7eca6","d2860d7f-32ff-5d74-b2f8-b7bfc8d75aec","cb0e05ff-e47d-55e7-bd5b-f8d78f2cb91f","28f6a324-5f5e-5771-91d2-c007f6c275aa","dfa53498-34f5-5326-9d94-87e7b528caf3","2aa2ef4b-8204-59b9-ad53-71c994cd6180","ce89fa04-bbd8-53b2-be01-812e3b3044ed","d7244ce4-5409-58d1-a1b4-bfae35f391e1","b1f00a6d-1a03-496c-b1bd-c1f2259f59a8","cf340ce4-8d91-5d22-a1d9-53bf408abdb3","904670af-8e4c-543e-bc9b-e6248d87a10d","c14857d3-634f-4a59-9a3f-8d0638fc5784","7e9e814c-fe12-42a9-8d80-e09e7fb52964","8ea46612-7f0d-4ef4-a732-9428e640ae92","974a2d1c-2225-519d-965f-7744fe8aafd5","f6a3a602-1e45-5018-b0ff-3d49933cf634","709e688c-eb07-5f83-a506-82c9bfe0d89f","d1e26b52-78a7-5f3b-ac9f-97f3e62d7db1","bacae732-2016-5a83-bc61-d0f94ed5a0e4","48e77690-17f7-5ebe-a8f7-87b2ee9820da","81c0d811-e6de-5489-8415-3b257c734a2e","0693f68f-1bd4-50a9-ba2b-af95b1c949ee","5476480f-7ff2-529f-aade-968198c782a9","c5413852-abae-566b-b435-f9939209ca63","ea2d5085-4ec1-5e33-87e0-15edcad635bf","0172ca41-cc42-51d6-94ad-f0f4680059e4"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_q3_practice_capstone","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_TECHNIK"],"phase":"Q3","area":"Klausurtraining","topicCode":"CANONICAL.PHYSICS.Q3.PRACTICE.CAPSTONE"}}`

## 578. Q4-Klausuraufgaben Physik selbstständig lösen

- ID: `4a58df57-f791-502f-8b8d-9ba155e46035`
- Beschreibung: Die lernende Person kann eine prüfungsnahe, materialgebundene Physik-Klausuraufgabe der Phase Q4 selbstständig bearbeiten und fachlich begründet auswerten.
- `requires`: `["a359c859-eee0-40ef-a9d1-88db2e6c55b2","defe44d2-c3d3-456b-a786-fad2cef13fe8","4245c54f-d609-41bc-9eff-e9ceeff4902f","5c57dbc7-d258-4aad-a84c-e773f3c493ae","1a1c09f0-96b7-4c33-a623-0e8101537876","6031bed0-9baa-4f45-b2a5-57ffb00d39cc","f6e5929f-d52a-42a4-a5d2-ff498ee7083f","ef6d5067-96b0-5388-87dd-5ac4e6a3e313","51bc5513-6879-548f-b19a-9746b667f1a3","ad021f2e-6b94-5e6e-a264-3d1110094b87","9e881b3b-68cd-5f52-819f-c2e33b5ba631","b05da028-65e4-5cd1-a13c-6c1a95b6dfdf","8c97c234-a932-5e84-aed5-237b4e2a8336","aef1e312-6a0c-5323-9202-c22ae84086f2","48e3d6c2-00bf-5afd-8846-ba3dbd01e96d","75f7139f-0f07-5cec-bcea-4f139502b528","2ec48368-ac5b-55f9-a396-5a5fe4e1e874","e5c08365-a0d3-592c-ad8e-d2c2c6e2b717","a12fddce-0215-58d9-bd91-21be8a960d25","cde9b548-2cf4-59ad-b5d4-a71872afbe56","49872cc0-401f-5464-9235-4763df4db5cf","a684bec1-ba59-59d0-98d2-4ca37236f64c","512f81af-1480-56a8-ae52-af3aa1a6a859","19aef2ed-eb46-55b1-9486-ee83f7520bb6","0c305cf9-3923-51cf-a9ae-5849edc99c9f","a9169a74-de19-54a9-a8ac-a2ce43c7342e","6ebb6182-f221-5f4c-b112-4ac72b104321","70b358bf-da6d-53ba-8393-51d5c2365b04","7badac4d-2874-5b3a-87e8-bf8f4440b2a6","df010b2b-b182-5f7e-bbe4-49b72e48c27a","d36727cc-ce42-51a3-9425-41afb0b9acdd","853dbe54-85b0-59ab-8f3a-000c2b7746ec","14d99a65-8d58-5647-88ab-02137b96d55b","206fe51d-cc78-5422-b139-32cc97eb1c37","3b50255a-6b01-578b-8f5c-4383536a3221","6e7c35e0-7a38-5996-a42e-005038eff0db","76bcbdcb-3003-5e6a-952e-aa36eb8f97ee","57ec031c-9a91-5331-81a7-6ef900f7c63e","2239cb67-82cb-585f-ab82-e1f2510eb4f7","79da5c34-86b2-5c10-9726-9de886ccef7d","af50bb9a-fd7b-50f5-9698-48c4efe99032","4c5c7cb1-f238-52c8-b82c-159c6c299c0e","6f896466-e0ec-5f8d-82ad-2890433c82ba","e6a50c74-c922-508c-aa27-07bac2566955","5492f0e0-cbae-574e-a853-182616205ed3","bb5c5eab-2fc1-5336-b8cf-14d147695487","7e719cc2-0866-5267-a252-e7e7ac0d03f1","b3f3f4f7-b5cc-40e1-b57a-3d93649baa61","4e046c1c-bcc7-5e3c-9f71-f80d69027483","4b8b5f4c-c222-57b5-a2f2-ef2efacc03dd","8eb6456b-d915-50ed-a076-2b23c2e5420c","2fab2e3a-1558-5e67-aed0-15fc51c737cd","aa0fa5fb-7bfb-5f9f-a606-3f7187cfb745","db6b8de4-21e0-58e8-a347-2ae39f538f92","bfea7a23-1ce1-4a42-badd-1fc9bf30124a","333ca92b-a92c-46a9-86be-dea8ddbd43e0","d5bff282-741f-4cc5-9622-b77584fdcc5a","a08e33db-d821-457b-86dd-870e7648c5f4","14ec85b9-68f6-5400-ad43-5e8dddfddf44","5c0d5040-92e4-50f6-9695-9d33d889a080"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_q4_practice_capstone","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG","LI_ENERGIE","LI_TECHNIK"],"phase":"Q4","area":"Klausurtraining","topicCode":"CANONICAL.PHYSICS.Q4.PRACTICE.CAPSTONE"}}`

## 579. Ladungserhaltung erläutern

- ID: `25998fed-ea4d-4c3e-b606-e965b5d7f290`
- Beschreibung: Die lernende Person kann elektrische Ladung als Erhaltungsgröße beschreiben und Ladungsumverteilungen in abgeschlossenen Systemen fachlich deuten.
- `requires`: `["a6e48b88-51ed-5942-bdb8-8d2192652e0d","4b67bed9-06da-40b2-a306-24e9e7dfd390"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 580. Feldlinienbilder von Ladungs- und Leiteranordnungen deuten

- ID: `f3de5922-dd45-4fb6-87c1-525d1952dd89`
- Beschreibung: Die lernende Person kann Feldlinienbilder eines elektrischen Dipols sowie von Leitern im elektrostatischen Gleichgewicht anhand von Tangentenrichtung und relativer Liniendichte deuten und daraus Feldfreiheit im Inneren eines Faraday-Käfigs sowie lokale Feldverstärkung an Spitzen qualitativ erklären.
- `requires`: `["4ca83b3f-3605-5c0d-abc4-9f24b9e29bbe"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 581. Influenz bei Leitern untersuchen

- ID: `9fb1dd85-11b7-4a5a-b124-27fea8d1788e`
- Beschreibung: Die lernende Person kann Influenz bei Leitern experimentell beschreiben, die Ladungsverschiebung im äußeren elektrischen Feld erklären und das Ergebnis mit Feldlinienbildern verknüpfen.
- `requires`: `["25998fed-ea4d-4c3e-b606-e965b5d7f290","f3de5922-dd45-4fb6-87c1-525d1952dd89"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 582. Flächenladungsdichte nutzen

- ID: `e3bce51c-cfeb-4706-b95e-a22b76e7dd73`
- Beschreibung: Die lernende Person kann die Flächenladungsdichte als Ladung pro Fläche definieren und sie zur Beschreibung geladener Platten im Kondensatormodell verwenden.
- `requires`: `["9f59a088-3939-59e9-821d-167fadfda782"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 583. Plattenkondensatorfeld über Flächenladungsdichte herleiten

- ID: `38e0ff49-f132-44c8-b17a-73dada5344db`
- Beschreibung: Die lernende Person kann den Zusammenhang zwischen Flächenladungsdichte und elektrischer Feldstärke im Plattenkondensator mathematisch herleiten und die Modellannahmen benennen.
- `requires`: `["e3bce51c-cfeb-4706-b95e-a22b76e7dd73","9f59a088-3939-59e9-821d-167fadfda782","2c4830e6-a8d5-48d0-9202-3b7d18a419c2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB3","processCompetencies":[],"guidingIdeas":["LI_FELDER"],"phase":"Q1"}}`

## 584. Longitudinal- und Transversalwellen unterscheiden

- ID: `68020906-e615-462e-a56f-dd1ccc14b8d7`
- Beschreibung: Die lernende Person kann Longitudinal- und Transversalwellen danach unterscheiden, ob die lokale Schwingungsrichtung parallel beziehungsweise senkrecht zur Ausbreitungsrichtung verläuft, und charakteristische Beispiele anhand dieses Kriteriums begründet zuordnen.
- `requires`: `["bf559969-a05c-58b5-82c5-3d719d96555d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_WELLEN"],"phase":"Q2"}}`

## 585. Zeitentwicklung von Quantenzuständen einordnen

- ID: `d5bff282-741f-4cc5-9622-b77584fdcc5a`
- Beschreibung: Die lernende Person kann erklären, dass die zeitliche Entwicklung eines Quantenzustands im Modell deterministisch beschrieben wird, während Messergebnisse probabilistisch gedeutet werden.
- `requires`: `["5c57dbc7-d258-4aad-a84c-e773f3c493ae","51bc5513-6879-548f-b19a-9746b667f1a3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 586. Einstein-Synchronisation erläutern

- ID: `a08e33db-d821-457b-86dd-870e7648c5f4`
- Beschreibung: Die lernende Person kann erläutern, wie räumlich getrennte, ruhende Uhren in einem Inertialsystem mit Lichtsignalen in Hin- und Rückrichtung nach der Einstein-Konvention synchronisiert werden, und erklären, warum diese Festlegung die Gleichzeitigkeit in diesem Bezugssystem definiert.
- `requires`: `["a684bec1-ba59-59d0-98d2-4ca37236f64c","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 587. Denk- und Arbeitsweisen der Physik (Sek I)

- ID: `f08d171d-ac31-59b6-834e-a6a2493b974e`
- Beschreibung: Brückencluster für allgemeine Sek-I-Arbeitsweisen der Physik: Beobachtung und Erklärung unterscheiden, empirische Überprüfbarkeit verstehen, Modellfunktion erläutern und SI-Einheiten nutzen.
- `requires`: `[]`
- `contains`: `["5355fee0-0477-5570-a234-561477bf77ba","da26294f-4316-5bd5-a37a-bd89397b3b8b","e5bc2227-d900-585f-8ac0-9d3f1cb40e27","3ed3279e-c524-5230-a277-dda89493df6d","d3c153b9-e09b-5668-8386-73105546a7c1","ad62f563-4fee-5399-8d9c-03a214658aa9","d2e6f87d-795b-5631-a7cc-0bfb5dc5142e","6d323d54-0aee-55d0-a9e1-ef2efdea0346","b378c8b3-5e83-5abf-8243-b0f345037bfc"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_methods_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":[],"phase":"GLOBAL","area":"Denk- und Arbeitsweisen","topicCode":"CANONICAL.PHYSICS.SEK1.METHODS"}}`

## 588. Beobachtung und Erklärung unterscheiden

- ID: `5355fee0-0477-5570-a234-561477bf77ba`
- Beschreibung: Die lernende Person kann Beobachtungen, die auf Sinneseindrücken oder Messungen beruhen, von physikalischen Erklärungen mithilfe von Gesetzen und Modellen unterscheiden.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_observation_explanation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":[],"phase":"GLOBAL","area":"Denk- und Arbeitsweisen","topicCode":"CANONICAL.PHYSICS.SEK1.METHODS.OBSERVATION_EXPLANATION"}}`

## 589. Physikalische Aussagen empirisch überprüfen

- ID: `da26294f-4316-5bd5-a37a-bd89397b3b8b`
- Beschreibung: Die lernende Person kann an Beispielen erläutern, dass physikalische Aussagen durch Fragestellung, Hypothese, Experiment und Bestätigung oder Widerlegung überprüfbar sind.
- `requires`: `["5355fee0-0477-5570-a234-561477bf77ba"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_empirical_testability","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":[],"phase":"GLOBAL","area":"Denk- und Arbeitsweisen","topicCode":"CANONICAL.PHYSICS.SEK1.METHODS.EMPIRICAL_TESTABILITY"}}`

## 590. Funktion physikalischer Modelle erläutern

- ID: `e5bc2227-d900-585f-8ac0-9d3f1cb40e27`
- Beschreibung: Die lernende Person kann an Beispielen wie Strahlenmodell, Teilchenmodell, Atommodell oder Elementarmagnetmodell erläutern, wie physikalische Modelle ausgewählte Eigenschaften vereinfacht darstellen und unter ihren Modellannahmen Erklärungen oder Vorhersagen ermöglichen.
- `requires`: `["5355fee0-0477-5570-a234-561477bf77ba"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_model_function","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":[],"phase":"GLOBAL","area":"Denk- und Arbeitsweisen","topicCode":"CANONICAL.PHYSICS.SEK1.METHODS.MODELS"}}`

## 591. SI-Einheiten in physikalischen Beispielen nutzen

- ID: `3ed3279e-c524-5230-a277-dda89493df6d`
- Beschreibung: Die lernende Person kann die Funktion des SI-Einheitensystems erläutern und einfache physikalische Größen mit passenden SI-Einheiten angeben.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f","f2e42af5-67a6-477e-82ea-e65b09cc6cb3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_si_units","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":[],"phase":"GLOBAL","area":"Denk- und Arbeitsweisen","topicCode":"CANONICAL.PHYSICS.SEK1.METHODS.SI_UNITS"}}`

## 592. Mondphasen und Finsternisse mit Licht und Schatten erklären

- ID: `1fede37b-6554-5dd3-93d9-08ed1fd09c91`
- Beschreibung: Die lernende Person kann Mondphasen durch die wechselnde Sicht auf die von der Sonne beleuchtete Mondhälfte und Sonnen- sowie Mondfinsternisse durch die jeweilige Anordnung und die entstehenden Schattenräume von Sonne, Erde und Mond erklären.
- `requires`: `[]`
- `contains`: `["33e3417c-e062-5f4a-8df9-3195dca50089","f0046ae8-cbfc-526b-8414-04e3595b6075"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_celestial_light_shadow","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_KOSMOS"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.CELESTIAL_SHADOWS"}}`

## 593. Mondphasen mit Beleuchtung und Blickrichtung erklären

- ID: `33e3417c-e062-5f4a-8df9-3195dca50089`
- Beschreibung: Die lernende Person kann aus den relativen Positionen von Sonne, Erde und Mond ableiten, welcher Anteil der beleuchteten Mondhälfte von der Erde aus sichtbar ist, damit die Mondphasen erklären und begründen, warum sie nicht durch den Erdschatten entstehen.
- `requires`: `["79cb1695-f985-443a-b93e-27b57ab474b7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_explain_lunar_phases","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_KOSMOS"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.CELESTIAL_SHADOWS.LUNAR_PHASES"}}`

## 594. Sonnen- und Mondfinsternisse mit Schattenräumen erklären

- ID: `f0046ae8-cbfc-526b-8414-04e3595b6075`
- Beschreibung: Die lernende Person kann für Sonnen- und Mondfinsternisse die jeweilige Anordnung von Sonne, Erde und Mond darstellen, Kern- und Halbschatten zuordnen und daraus erklären, welches Himmelsobjekt für Beobachtende ganz oder teilweise verdunkelt erscheint.
- `requires`: `["79cb1695-f985-443a-b93e-27b57ab474b7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_explain_solar_lunar_eclipses","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_KOSMOS"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.CELESTIAL_SHADOWS.ECLIPSES"}}`

## 595. Streuung und Absorption von Licht an Beobachtungen unterscheiden

- ID: `9a9e2085-5ab6-534f-b622-83774d51f36b`
- Beschreibung: Die lernende Person kann an einfachen Alltags- und Experimentbeispielen aus beobachteten Änderungen der Lichtverteilung und Helligkeit begründet schließen, ob Licht überwiegend in verschiedene Richtungen gestreut oder vom Material absorbiert wird, und erläutern, welche Beobachtung die Zuordnung stützt.
- `requires`: `["dd7cdcea-0950-461b-96ac-ce49989fca47"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_scattering_absorption","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_MATERIE"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.SCATTERING_ABSORPTION"}}`

## 596. Brechung und optische Hebung qualitativ beschreiben

- ID: `6a4c6042-052b-502b-a39a-0ed8941247ac`
- Beschreibung: Die lernende Person kann mit dem Strahlenmodell qualitativ erklären, wie sich Lichtwege beim Übergang zwischen zwei Medien an der Grenzfläche ändern und wie daraus Wahrnehmungseffekte wie optische Hebung entstehen.
- `requires`: `["79cb1695-f985-443a-b93e-27b57ab474b7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_refraction","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.REFRACTION"}}`

## 597. Bildentstehung bei der Lochkamera qualitativ beschreiben

- ID: `1ab5f599-0927-579d-94cc-feecdf3b5603`
- Beschreibung: Die lernende Person kann mit dem Strahlenmodell erklären, wie Licht von verschiedenen Gegenstandspunkten geradlinig durch die kleine Öffnung zu entsprechenden Bildpunkten auf dem Schirm gelangt und warum dabei ein umgekehrtes Bild entsteht.
- `requires`: `["dd7cdcea-0950-461b-96ac-ce49989fca47","79cb1695-f985-443a-b93e-27b57ab474b7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_pinhole_camera","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.PINHOLE_CAMERA"}}`

## 598. Energieversorgung mit Energieübertragungsketten beschreiben

- ID: `30a936ec-e427-57fe-bf3e-4abd64b1f0c1`
- Beschreibung: Die lernende Person kann Energieversorgungssysteme wie Wasser-, Wind-, Kohle- oder Solarkraftwerke als Ketten von Energieformen, Energieträgern und Übertragungs- beziehungsweise Umwandlungsschritten bis zur Nutzung einschließlich Energieabgaben an die Umgebung qualitativ beschreiben.
- `requires`: `["722857cf-f327-5740-8151-64eb92195ec8"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_energy_supply_chains","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Energie","topicCode":"CANONICAL.PHYSICS.SEK1.ENERGY.SUPPLY_CHAINS"}}`

## 599. Leistung und Wirkungsgrad

- ID: `201d353a-dfe7-521b-b0f6-eccb4d42945b`
- Beschreibung: Cluster für die fachlich getrennten Lernziele zur Leistung als Energie pro Zeit und zum Wirkungsgrad als Verhältnis nutzbarer zu zugeführter Energie.
- `requires`: `[]`
- `contains`: `["b92827a7-5d62-5fdb-a6f5-ac44461f4a7b","f7f2c254-1663-5861-bed7-a32c00495b19"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_energy_power_efficiency","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Energie","topicCode":"CANONICAL.PHYSICS.SEK1.ENERGY.POWER_EFFICIENCY"}}`

## 600. Leistung als Energie pro Zeit bestimmen und deuten

- ID: `b92827a7-5d62-5fdb-a6f5-ac44461f4a7b`
- Beschreibung: Die lernende Person kann Leistung als übertragene oder umgewandelte Energie pro Zeit bestimmen, passende Einheiten verwenden und bei gleicher Energie erklären, warum eine kürzere Dauer einer größeren Leistung entspricht.
- `requires`: `["722857cf-f327-5740-8151-64eb92195ec8","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_power_energy_per_time","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Energie","topicCode":"CANONICAL.PHYSICS.SEK1.ENERGY.POWER"}}`

## 601. Wirkungsgrad als Verhältnis nutzbarer und zugeführter Energie deuten

- ID: `f7f2c254-1663-5861-bed7-a32c00495b19`
- Beschreibung: Die lernende Person kann den Wirkungsgrad als Verhältnis nutzbarer zu zugeführter Energie bestimmen, Energieanteile in einem einfachen System bilanzieren und begründen, warum ein Wirkungsgrad nicht größer als eins sein kann.
- `requires`: `["722857cf-f327-5740-8151-64eb92195ec8","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f","71d43fcc-d787-4874-ae4a-2336364e9c0a","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_efficiency_useful_input_energy","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Energie","topicCode":"CANONICAL.PHYSICS.SEK1.ENERGY.EFFICIENCY"}}`

## 602. Elektrische Leitfähigkeit von Stoffen untersuchen

- ID: `baa2bf3c-798a-5ec3-a667-031bf062d96c`
- Beschreibung: Die lernende Person kann die elektrische Leitfähigkeit von Stoffen experimentell untersuchen und Leiter von Nichtleitern unterscheiden.
- `requires`: `["7ca44ba0-b77e-52bf-8562-f67b44767172"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_electrical_conductivity","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_MATERIE"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.CONDUCTIVITY"}}`

## 603. Stromstärke und Spannung messen

- ID: `59d1145e-ac54-5917-880a-21b4b80526d3`
- Beschreibung: Bündelt das fachgerechte Messen von Stromstärke und Spannung in einfachen Stromkreisen.
- `requires`: `[]`
- `contains`: `["f1a078ae-6262-4444-a4bc-a5ab275621cf","28237994-9c24-5a06-82fe-be1f494768ba"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_voltage_current_measurement","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.MEASUREMENT"}}`

## 604. Widerstand und Kennlinien einfacher Bauteile untersuchen

- ID: `ec5cac7b-ad31-590c-8ab0-5b3ef24d2bca`
- Beschreibung: Bündelt das experimentelle Untersuchen und Deuten von Strom-Spannungs-Kennlinien sowie das qualitative Beschreiben von Material-, Längen- und Querschnittseinflüssen auf den Leiterwiderstand.
- `requires`: `[]`
- `contains`: `["66256e22-44a3-5939-8862-821e29d6711d","af7855a3-6aea-5e05-8505-248bc9a8c219"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_resistance_characteristics","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_MATERIE"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.RESISTANCE_CHARACTERISTICS"}}`

## 605. Strom-Spannungs-Kennlinien einfacher Bauteile experimentell untersuchen und deuten

- ID: `66256e22-44a3-5939-8862-821e29d6711d`
- Beschreibung: Die lernende Person kann unter sicheren Kleinspannungsbedingungen Stromstärke und Spannung an einfachen Bauteilen systematisch messen, Kennlinien erstellen und den Zusammenhang von Spannung, Stromstärke und Widerstand deuten.
- `requires`: `["53196a71-9dbd-4835-b2f9-ff21b8a8962c","c1f50bcc-7848-4e49-b9de-0ec030cc6bca"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_investigate_interpret_component_iv_characteristics","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_MATERIE"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.RESISTANCE_CHARACTERISTICS.IV_EXPERIMENT"}}`

## 606. Einflüsse auf den Widerstand eines Leiters qualitativ beschreiben

- ID: `af7855a3-6aea-5e05-8505-248bc9a8c219`
- Beschreibung: Die lernende Person kann qualitativ erläutern, wie Material, Länge und Querschnitt den Widerstand eines Leiters bei sonst gleichen Bedingungen beeinflussen, und Widerstandsänderungen vorhersagen.
- `requires`: `["53196a71-9dbd-4835-b2f9-ff21b8a8962c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_describe_conductor_resistance_factors","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_MATERIE"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.RESISTANCE_CHARACTERISTICS.CONDUCTOR_FACTORS"}}`

## 607. Elektrische Energieversorgung und Geräteangaben einordnen

- ID: `50431e92-eec9-54d6-b437-ea7a51b6f474`
- Beschreibung: Bündelt das Einordnen von Gleich- und Wechselspannungsversorgungen sowie das physikalische Deuten elektrischer Geräte- und Akkuangaben.
- `requires`: `[]`
- `contains`: `["4a42cddd-7827-5204-87e5-8d9eac7792f1","27b90ce9-b650-5232-85fb-ce2cb69d59a3"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_electricity_supply_labels","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.SUPPLY_LABELS"}}`

## 608. Gleich- und Wechselspannungsversorgungen einordnen

- ID: `4a42cddd-7827-5204-87e5-8d9eac7792f1`
- Beschreibung: Die lernende Person kann Gleich- und Wechselspannungsversorgungen anhand des zeitlichen Spannungsverlaufs und der Polarität unterscheiden und typische elektrische Versorgungen entsprechend einordnen.
- `requires`: `["53196a71-9dbd-4835-b2f9-ff21b8a8962c"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_classify_direct_alternating_voltage_supplies","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.SUPPLY_LABELS.DIRECT_ALTERNATING_VOLTAGE"}}`

## 609. Elektrische Geräte- und Akkuangaben physikalisch deuten

- ID: `27b90ce9-b650-5232-85fb-ce2cb69d59a3`
- Beschreibung: Die lernende Person kann Angaben zu Spannung, Stromstärke, Leistung und Akkuladung auf Alltagsgeräten und Akkus mit ihren Einheiten physikalisch deuten und für den vorgesehenen Betrieb einordnen.
- `requires`: `["53196a71-9dbd-4835-b2f9-ff21b8a8962c","b92827a7-5d62-5fdb-a6f5-ac44461f4a7b","f2e42af5-67a6-477e-82ea-e65b09cc6cb3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_interpret_device_battery_ratings","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.SUPPLY_LABELS.DEVICE_BATTERY_RATINGS"}}`

## 610. Treibhauseffekt mit Strahlungsbilanz beschreiben

- ID: `5a3716dd-ec67-5c48-ba3d-1a29f05ba2ce`
- Beschreibung: Die lernende Person kann den natürlichen Treibhauseffekt mit der Absorption und Emission langwelliger Wärmestrahlung durch Treibhausgase in der Strahlungsbilanz erklären und den anthropogenen Anteil auf veränderte Treibhausgaskonzentrationen zurückführen.
- `requires`: `["fbe0faae-7fba-482b-888e-341f926770f3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_greenhouse_effect_energy_balance","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_WELLEN"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.HEAT.GREENHOUSE_EFFECT"}}`

## 611. Energieversorgung und Klimawirkungen fachlich bewerten

- ID: `5be98160-5189-58aa-8183-1df1c400cc8c`
- Beschreibung: Die lernende Person kann verschiedene Arten der Energieversorgung anhand fachlich belastbarer Daten und offengelegter Kriterien unter physikalischen, ökologischen, ökonomischen und gesellschaftlichen Aspekten vergleichen, Klimawirkungen fachlich begründet einordnen und daraus ein abgewogenes Urteil formulieren.
- `requires`: `["30a936ec-e427-57fe-bf3e-4abd64b1f0c1","5a3716dd-ec67-5c48-ba3d-1a29f05ba2ce","ee48e811-4c9c-5080-9836-8403fc9f0810","f2e42af5-67a6-477e-82ea-e65b09cc6cb3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_energy_supply_evaluation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK5_BEWERTEN","PK6_ENTSCHEIDEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Energie und Klima","topicCode":"CANONICAL.PHYSICS.SEK1.ENERGY.SUPPLY_EVALUATION"}}`

## 612. Strahlungsarten und Halbwertszeit radioaktiver Stoffe

- ID: `cb0426b0-a973-5660-b6fe-79407934730f`
- Beschreibung: Bündelt das qualitative Unterscheiden von Alpha-, Beta- und Gammastrahlung und das statistische Deuten der Halbwertszeit radioaktiver Stoffe.
- `requires`: `[]`
- `contains`: `["1593d95c-2aac-504c-8527-37cb61877da9","16b94a12-ecc5-5b5c-85b6-87b4290bebf8"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_nuclear_decay_radiation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.DECAY_RADIATION"}}`

## 613. Alpha-, Beta- und Gammastrahlung unterscheiden

- ID: `1593d95c-2aac-504c-8527-37cb61877da9`
- Beschreibung: Die lernende Person kann Alpha-, Beta- und Gammastrahlung anhand der jeweiligen Kernänderung beziehungsweise Kernabregung, der emittierten Teilchen oder Photonen sowie ihres unter vergleichbaren Bedingungen in Materie typischen Ionisations- und Durchdringungsvermögens qualitativ unterscheiden.
- `requires`: `["2a6703e0-2a6f-4ebf-a5c6-7aa05a4b86eb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_distinguish_alpha_beta_gamma_radiation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.DECAY_RADIATION.TYPES"}}`

## 614. Halbwertszeit radioaktiver Stoffe deuten

- ID: `16b94a12-ecc5-5b5c-85b6-87b4290bebf8`
- Beschreibung: Die lernende Person kann die Halbwertszeit als statistische Halbierung der Zahl noch nicht zerfallener Kerne in einem großen Ensemble deuten und erklären, warum der Zerfallszeitpunkt eines einzelnen Kerns nicht vorhergesagt werden kann.
- `requires`: `["1593d95c-2aac-504c-8527-37cb61877da9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_interpret_radioactive_half_life","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.DECAY_RADIATION.HALF_LIFE"}}`

## 615. Kernspaltung und Kernfusion qualitativ beschreiben

- ID: `50877233-7abf-54df-b347-6d3224678fc9`
- Beschreibung: Die lernende Person kann Kernspaltung und Kernfusion anhand der Ausgangskerne, der Reaktionsprodukte und der erforderlichen Bedingungen qualitativ vergleichen sowie heutige Kernkraftwerke der Kernspaltung und Sterne der Kernfusion begründet zuordnen.
- `requires`: `["2a6703e0-2a6f-4ebf-a5c6-7aa05a4b86eb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_nuclear_fission_fusion","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"GLOBAL","area":"Atom- und Kernphysik","topicCode":"CANONICAL.PHYSICS.SEK1.NUCLEAR.FISSION_FUSION"}}`

## 616. Astronomische Beobachtungsmethoden

- ID: `2b700858-bc2e-5ddf-a791-b14d44160480`
- Beschreibung: Die lernende Person kann Astronomie als Beobachtungswissenschaft beschreiben und Teleskope sowie Spektroskopie als zentrale Zugänge zu astronomischen Objekten erläutern.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_observation_methods","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4"}}`

## 617. Astronomische Groessenordnungen und Einheiten

- ID: `7c986fca-1129-5eff-a17e-0a04bb7346ee`
- Beschreibung: Die lernende Person kann astronomische Distanzen, Massen und Leuchtkraefte mit Einheiten wie Astronomischer Einheit, Lichtjahr, Parsec, Sonnenmasse und Sonnenleuchtkraft beschreiben und einordnen.
- `requires`: `["3ed3279e-c524-5230-a277-dda89493df6d","6596405a-9728-41df-9163-53670ec2a937"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_units_scales","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4"}}`

## 618. Gravitationswellen und elektromagnetische Wellen vergleichen

- ID: `ba16948b-5e07-54af-b77b-776e677c6906`
- Beschreibung: Die lernende Person kann Gemeinsamkeiten und Unterschiede elektromagnetischer Wellen und Gravitationswellen qualitativ beschreiben.
- `requires`: `["4a7cbe83-b694-57d3-85ce-1eeca418daaf","14d99a65-8d58-5647-88ab-02137b96d55b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_gravitational_waves_compare","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4"}}`

## 619. Stabilität astronomischer Objekte beurteilen

- ID: `da3169ae-c72a-5782-ad95-408167a5c6da`
- Beschreibung: Die lernende Person kann bei einem astronomischen Objekt Gleichgewicht oder Ungleichgewicht zwischen Gravitation und Druckgradientkräften aus Gas-, Strahlungs- oder Entartungsdruck erklären und die Folgen veränderter Bedingungen für seine Stabilität qualitativ beurteilen.
- `requires`: `["9b47a758-1b5d-5906-84c9-8621050d5aa5","5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_pressure_gravity_stability","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"Q4"}}`

## 620. Exoplaneten-Nachweise erläutern

- ID: `5b8eaf71-96fe-50eb-b9ea-a8fa392df086`
- Beschreibung: Cluster für die qualitative Deutung von Transit- und Sternradialbewegungssignalen bei Exoplanetenkandidaten.
- `requires`: `[]`
- `contains`: `["49bb609a-bfb7-5391-9120-f5fc737efb9a","6dca3b0a-c872-543b-808f-97e855f5fafd"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_exoplanet_detection","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4"}}`

## 621. Exoplanetenkandidaten mit der Transitmethode erklären

- ID: `49bb609a-bfb7-5391-9120-f5fc737efb9a`
- Beschreibung: Die lernende Person kann wiederkehrende Helligkeitsabnahmen eines Sterns mit dem Transit eines möglichen Planeten erklären und begründen, wie die Beobachtungsgeometrie die Nachweismöglichkeit begrenzt.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93","80c232f1-8f72-5829-9dbe-5a610ccab3be"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_exoplanet_transit_evidence","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_EXOPLANET_TRANSIT_EVIDENCE","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"]}}`

## 622. Exoplanetenkandidaten mit Stern-Radialbewegungen erklären

- ID: `6dca3b0a-c872-543b-808f-97e855f5fafd`
- Beschreibung: Die lernende Person kann periodische Dopplerverschiebungen im Spektrum eines Sterns mit seiner Bewegung um den gemeinsamen Schwerpunkt eines möglichen Stern-Planet-Systems erklären und die Aussagekraft dieses indirekten Nachweises begrenzen.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_exoplanet_stellar_radial_motion_evidence","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_EXOPLANET_STELLAR_RADIAL_MOTION_EVIDENCE","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"]}}`

## 623. Planetenatmosphaeren mit Spektren untersuchen

- ID: `e28381b4-50ef-5cac-bfa4-b7c8e03aef82`
- Beschreibung: Die lernende Person kann erlaeutern, wie Spektren zur Untersuchung von Planetenatmosphaeren genutzt werden.
- `requires`: `["c14857d3-634f-4a59-9a3f-8d0638fc5784","ea2d5085-4ec1-5e33-87e0-15edcad635bf"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_planet_atmospheres_spectra","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_MATERIE"],"phase":"Q4"}}`

## 624. Realitaetsbegriff in der Quantenphysik diskutieren

- ID: `727d0946-7019-50ed-8fc6-85db12508733`
- Beschreibung: Die lernende Person kann den Realitaetsbegriff in der Quantenphysik anhand von Messung, Praeparation und Wahrscheinlichkeitsaussagen fachlich diskutieren.
- `requires`: `["5c57dbc7-d258-4aad-a84c-e773f3c493ae","b05da028-65e4-5cd1-a13c-6c1a95b6dfdf"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_quantum_realism_measurement","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 625. Lokalität und Verschränkung einordnen

- ID: `b9fcbad4-a855-54b7-8017-4caac1e2ffb7`
- Beschreibung: Die lernende Person kann Verschränkung als nichtklassische Korrelation zwischen räumlich getrennten Messungen erklären, erläutern, wie entsprechende Experimente lokale realistische Modelle begrenzen, und dies von überlichtschneller Signalübertragung unterscheiden.
- `requires`: `["6031bed0-9baa-4f45-b2a5-57ffb00d39cc","8c97c234-a932-5e84-aed5-237b4e2a8336"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_quantum_locality_entanglement","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK5_BEWERTEN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4"}}`

## 626. Vertiefendes physikalisches Forschungsgebiet

- ID: `25e5f469-58b7-546f-8894-ac12e601d6ae`
- Beschreibung: Cluster fuer die fachliche Vertiefung in einem ausgewaehlten modernen Forschungsgebiet der Physik.
- `requires`: `[]`
- `contains`: `["14ec85b9-68f6-5400-ad43-5e8dddfddf44","5c0d5040-92e4-50f6-9695-9d33d889a080"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_research_field_cluster","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":[],"phase":"Q4"}}`

## 627. Ausgewaehltes Forschungsgebiet beschreiben

- ID: `14ec85b9-68f6-5400-ad43-5e8dddfddf44`
- Beschreibung: Die lernende Person kann Aspekte eines ausgewaehlten aktuellen Forschungsgebiets der Physik und dessen Anwendungen fachlich beschreiben.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_research_field_exploration","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":[],"phase":"Q4"}}`

## 628. Physikalische Methoden im Forschungsgebiet anwenden

- ID: `5c0d5040-92e4-50f6-9695-9d33d889a080`
- Beschreibung: Die lernende Person kann fachliche Konzepte, Modelle und Arbeitsweisen aus der Kursstufe auf ein ausgewaehltes Forschungsgebiet uebertragen.
- `requires`: `["14ec85b9-68f6-5400-ad43-5e8dddfddf44","6596405a-9728-41df-9163-53670ec2a937"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_research_field_methods","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":[],"phase":"Q4"}}`

## 629. Experimente planen und Messdaten auswerten

- ID: `d3c153b9-e09b-5668-8386-73105546a7c1`
- Beschreibung: Die lernende Person kann zu einer physikalischen Fragestellung einen einfachen Versuchsaufbau planen, Messdaten strukturiert erfassen und mit passenden Darstellungen oder einfacher Mathematisierung auswerten.
- `requires`: `["da26294f-4316-5bd5-a37a-bd89397b3b8b","3ed3279e-c524-5230-a277-dda89493df6d","15505229-efec-4d01-8e71-acf15f9c2424","25593605-5e13-55cc-9a05-8f3d737e15e9","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_experiment_planning_data_analysis","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":[],"phase":"GLOBAL","area":"Denk- und Arbeitsweisen","topicCode":"CANONICAL.PHYSICS.SEK1.METHODS.EXPERIMENT_DATA"}}`

## 630. Experimentelle Untersuchungen fachgerecht dokumentieren

- ID: `ad62f563-4fee-5399-8d9c-03a214658aa9`
- Beschreibung: Die lernende Person kann Beobachtungen, Messwerte, Auswertungsschritte und Ergebnisse einer physikalischen Untersuchung in einem strukturierten Protokoll oder einer fachtypischen Darstellung nachvollziehbar dokumentieren.
- `requires`: `["d3c153b9-e09b-5668-8386-73105546a7c1","5355fee0-0477-5570-a234-561477bf77ba"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_experiment_documentation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":[],"phase":"GLOBAL","area":"Denk- und Arbeitsweisen","topicCode":"CANONICAL.PHYSICS.SEK1.METHODS.DOCUMENTATION"}}`

## 631. Physikalische Informationen aus Quellen auswerten

- ID: `d2e6f87d-795b-5631-a7cc-0bfb5dc5142e`
- Beschreibung: Die lernende Person kann Informationen aus vorgegebenen oder selbst recherchierten Quellen entnehmen, nach fachlicher Relevanz ordnen und mit vorhandenen physikalischen Kenntnissen abgleichen.
- `requires`: `["e5bc2227-d900-585f-8ac0-9d3f1cb40e27","3ed3279e-c524-5230-a277-dda89493df6d","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_source_research","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":[],"phase":"GLOBAL","area":"Denk- und Arbeitsweisen","topicCode":"CANONICAL.PHYSICS.SEK1.METHODS.SOURCE_RESEARCH"}}`

## 632. Physikalische Arbeitsergebnisse fachsprachlich präsentieren

- ID: `6d323d54-0aee-55d0-a9e1-ef2efdea0346`
- Beschreibung: Die lernende Person kann physikalische Arbeitsergebnisse sach- und adressatengerecht darstellen, zentrale Fachbegriffe bewusst verwenden und alltagssprachliche Aussagen in fachsprachliche Formulierungen überführen.
- `requires`: `["ad62f563-4fee-5399-8d9c-03a214658aa9","d2e6f87d-795b-5631-a7cc-0bfb5dc5142e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_scientific_presentation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK4_KOMMUNIZIEREN"],"guidingIdeas":[],"phase":"GLOBAL","area":"Denk- und Arbeitsweisen","topicCode":"CANONICAL.PHYSICS.SEK1.METHODS.PRESENTATION"}}`

## 633. Physikalische Bewertungen begründet formulieren

- ID: `b378c8b3-5e83-5abf-8243-b0f345037bfc`
- Beschreibung: Die lernende Person kann zu einfachen physikalisch-technischen Fragestellungen fachliche und außerfachliche Argumente unterscheiden, Nutzen und Risiken abwägen und einen begründeten Standpunkt formulieren.
- `requires`: `["d2e6f87d-795b-5631-a7cc-0bfb5dc5142e","e5bc2227-d900-585f-8ac0-9d3f1cb40e27"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_evidence_based_evaluation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK5_BEWERTEN","PK4_KOMMUNIZIEREN"],"guidingIdeas":[],"phase":"GLOBAL","area":"Denk- und Arbeitsweisen","topicCode":"CANONICAL.PHYSICS.SEK1.METHODS.EVALUATION"}}`

## 634. Solarmodule in Schaltungen experimentell untersuchen

- ID: `0dd1e39c-8557-5a4e-b467-caae964fff67`
- Beschreibung: Die lernende Person kann Stromstärke und Spannung von Solarmodulen in Reihen- und Parallelschaltungen messen, Einflussgrößen wie Neigung oder Beschattung variieren und Schlussfolgerungen für eine geeignete Nutzung ziehen.
- `requires`: `["f1a078ae-6262-4444-a4bc-a5ab275621cf","28237994-9c24-5a06-82fe-be1f494768ba","01bebdfc-5819-4610-a03e-ea5e794fc954","d3c153b9-e09b-5668-8386-73105546a7c1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_solar_modules_circuits","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.SOLAR_MODULES"}}`

## 635. Elektrische Leistung und Wirkungsgrad bilanzieren

- ID: `46e42b07-c098-5d65-8ef5-8472b7c4d8e2`
- Beschreibung: Die lernende Person kann in einfachen elektrischen Schaltungen oder Geräten Spannung, Stromstärke und Leistung verknüpfen, eine Leistungsbilanz erstellen und den Wirkungsgrad einer Energieumwandlung deuten.
- `requires`: `["b92827a7-5d62-5fdb-a6f5-ac44461f4a7b","f7f2c254-1663-5861-bed7-a32c00495b19","f1a078ae-6262-4444-a4bc-a5ab275621cf","28237994-9c24-5a06-82fe-be1f494768ba"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_electric_power_balance","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrizität","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTRICITY.POWER_BALANCE"}}`

## 636. Masse und Gewichtskraft unterscheiden

- ID: `9c328f68-41ed-55dd-9e02-34414a6246f2`
- Beschreibung: Die lernende Person kann Masse als ortsunabhängige Eigenschaft eines Körpers von der Gewichtskraft als vom Gravitationsfeld abhängiger Kraft unterscheiden, beide mit passenden Einheiten angeben und alltagssprachliche Verwechslungen fachlich korrigieren.
- `requires`: `["5ea765ac-c279-551a-8a94-a07da2381e5b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_mass_weight_force","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB1","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.MASS_WEIGHT"}}`

## 637. Kraft und Verformung experimentell untersuchen

- ID: `45bbdf6b-6372-5b6a-b7e4-be15a0eb4b83`
- Beschreibung: Die lernende Person kann den Zusammenhang zwischen Kraft und Verformung eines elastischen Körpers experimentell untersuchen, Messwerte tabellarisch und grafisch auswerten und begründet angeben, in welchem Messbereich Kraft und Verformung proportional sind.
- `requires`: `["5ea765ac-c279-551a-8a94-a07da2381e5b","d3c153b9-e09b-5668-8386-73105546a7c1","c1f50bcc-7848-4e49-b9de-0ec030cc6bca"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_hooke_force_deformation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"GLOBAL","area":"Mechanik","topicCode":"CANONICAL.PHYSICS.SEK1.MECHANICS.HOOKE"}}`

## 638. Aggregatzustandsänderungen im Teilchenmodell deuten

- ID: `873c6371-4ffb-582b-8d8d-3f45f968ba08`
- Beschreibung: Die lernende Person kann Schmelzen, Erstarren, Verdampfen und Kondensieren im Teilchenmodell als Energieaufnahme oder Energieabgabe deuten und dabei Modell- und Realitätsebene unterscheiden.
- `requires`: `["9ac4973a-21d5-48a5-90b4-eb90e10391ae","eeba6bf8-a2b9-4d7d-a1d6-67286c923cef"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_particle_model_phase_changes","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_ENERGIE"],"phase":"GLOBAL","area":"Wärmelehre","topicCode":"CANONICAL.PHYSICS.SEK1.HEAT.PHASE_CHANGES"}}`

## 639. Optische Risiken und Lasersicherheit beurteilen

- ID: `71b51afd-c71b-506f-8128-d6de36b509d1`
- Beschreibung: Die lernende Person kann Risiken beim Umgang mit Linsen, Lichtquellen und Lasern benennen, Sicherheitshinweise fachlich einordnen und einfache Schutzmaßnahmen begründen.
- `requires`: `["078ce4d2-3193-4cd0-ae59-4fb8ab16e9e5","90e1e6cf-4092-41d6-81f7-5206f9d68f84","b378c8b3-5e83-5abf-8243-b0f345037bfc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_laser_optical_safety","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK5_BEWERTEN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Optik","topicCode":"CANONICAL.PHYSICS.SEK1.OPTICS.SAFETY"}}`

## 640. Einfachen Elektromotor bauen und qualitativ erklären

- ID: `eb30189c-27c6-510b-b235-6543afa18b90`
- Beschreibung: Die lernende Person kann einen einfachen Elektromotor aufbauen, seine Funktion mit der Kraft auf stromdurchflossene Leiter im Magnetfeld erklären und Möglichkeiten zur Variation seines Laufs untersuchen.
- `requires`: `["0f6b798b-594e-5480-8c5f-95e2486a4d85","a5f652cc-e091-4c90-bec2-c357ae54fcf1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_simple_electric_motor","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektromagnetismus","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTROMAGNETISM.MOTOR"}}`

## 641. Idealen Transformator quantitativ deuten

- ID: `af1094c1-511a-5aae-9e0a-3e9196a82d9a`
- Beschreibung: Die lernende Person kann Aufbau und Funktionsprinzip eines Transformators mit Induktion erklären, beim idealen Transformator Spannungs- und Stromstärkeübersetzungen berechnen und die gegenläufige Übersetzung mit Energieerhaltung begründen.
- `requires`: `["fdcd5faf-f9bf-4fa9-87f4-4e22d8d3387c","b92827a7-5d62-5fdb-a6f5-ac44461f4a7b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_transformer_ideal_quantitative","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektromagnetismus","topicCode":"CANONICAL.PHYSICS.SEK1.ELECTROMAGNETISM.TRANSFORMER"}}`

## 642. Physik, Gesellschaft und Technik reflektieren

- ID: `8eaa4e45-39fc-50e9-b59f-8a1752f6bebe`
- Beschreibung: Buendelt Ziele zur gesellschaftlichen Einordnung physikalischer Erkenntnisse, zur Verantwortung der Forschung und zur Bewertung technischer Risiken.
- `requires`: `["d2e6f87d-795b-5631-a7cc-0bfb5dc5142e","b378c8b3-5e83-5abf-8243-b0f345037bfc"]`
- `contains`: `["2973da95-2cfc-5817-9c99-3c0c82777369","d81576e9-0320-5a90-8a1d-cd824981f2f6","af1c3116-5b55-55f5-86da-8c2cfe2c550c"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_society_technology_reflection","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Physik und Gesellschaft","topicCode":"CANONICAL.PHYSICS.SOCIETY_TECHNOLOGY"}}`

## 643. Physikalische Erkenntnisse in gesellschaftlich-politischen Kontexten einordnen

- ID: `2973da95-2cfc-5817-9c99-3c0c82777369`
- Beschreibung: Die lernende Person kann an Beispielen erlaeutern, wie gesellschaftliche oder politische Entwicklungen die Wahrnehmung, Akzeptanz und Nutzung physikalischer Erkenntnisse beeinflussen.
- `requires`: `["d2e6f87d-795b-5631-a7cc-0bfb5dc5142e","b378c8b3-5e83-5abf-8243-b0f345037bfc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_societal_political_reception","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Physik und Gesellschaft","topicCode":"CANONICAL_PHYSICS_SOCIETAL_POLITICAL_RECEPTION"}}`

## 644. Verantwortung naturwissenschaftlicher Forschung reflektieren

- ID: `d81576e9-0320-5a90-8a1d-cd824981f2f6`
- Beschreibung: Die lernende Person kann Verantwortung von Forschungsgemeinschaft und einzelnen Forschenden fuer Gesellschaft und Politik anhand physikalisch-technischer Beispiele reflektieren.
- `requires`: `["d2e6f87d-795b-5631-a7cc-0bfb5dc5142e","b378c8b3-5e83-5abf-8243-b0f345037bfc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_scientific_responsibility","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Physik und Gesellschaft","topicCode":"CANONICAL_PHYSICS_SCIENTIFIC_RESPONSIBILITY"}}`

## 645. Gesundheitsrisiken physikalischer Technologien beurteilen

- ID: `af1c3116-5b55-55f5-86da-8c2cfe2c550c`
- Beschreibung: Die lernende Person kann Gesundheitsrisiken und Sicherheitsfragen bei physikalisch-technischen Anwendungen, einschliesslich digitaler Technologien, fachlich begruenden und Handlungsoptionen ableiten.
- `requires`: `["d2e6f87d-795b-5631-a7cc-0bfb5dc5142e","b378c8b3-5e83-5abf-8243-b0f345037bfc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_technology_health_risks","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Physik und Gesellschaft","topicCode":"CANONICAL_PHYSICS_TECHNOLOGY_HEALTH_RISKS"}}`

## 646. Photovoltaik und Solarenergie

- ID: `052a4cc8-2ccd-5cef-b022-55b554417c4a`
- Beschreibung: Buendelt Ziele zur experimentellen Untersuchung von Solarzellen, zur Maximum-Power-Point-Bestimmung und zur technischen Einordnung photovoltaischer Anlagen.
- `requires`: `["0dd1e39c-8557-5a4e-b467-caae964fff67","46e42b07-c098-5d65-8ef5-8472b7c4d8e2"]`
- `contains`: `["02876b2e-7cf0-5de6-ad04-d4ee95b7f80e","92076a27-46cd-5c33-b3d8-aa68329af7c4"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_photovoltaics_solar_energy","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Energie und Technik","topicCode":"CANONICAL.PHYSICS.PHOTOVOLTAICS"}}`

## 647. Photovoltaische Kennlinien und Maximum-Power-Point untersuchen

- ID: `02876b2e-7cf0-5de6-ad04-d4ee95b7f80e`
- Beschreibung: Die lernende Person kann U-I-Kennlinien von Solarzellen bei unterschiedlicher Bestrahlung experimentell aufnehmen, Leistungskurven auswerten und den Maximum-Power-Point bestimmen.
- `requires`: `["0dd1e39c-8557-5a4e-b467-caae964fff67","46e42b07-c098-5d65-8ef5-8472b7c4d8e2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_photovoltaic_characteristic_mpp","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Physik und Gesellschaft","topicCode":"CANONICAL_PHYSICS_PHOTOVOLTAIC_CHARACTERISTIC_MPP"}}`

## 648. Photovoltaikanlagen als technische Systeme erklaeren

- ID: `92076a27-46cd-5c33-b3d8-aa68329af7c4`
- Beschreibung: Die lernende Person kann grundlegende Komponenten photovoltaischer Anlagen und deren Funktion im Energieuebertragungssystem fachlich beschreiben.
- `requires`: `["30a936ec-e427-57fe-bf3e-4abd64b1f0c1","02876b2e-7cf0-5de6-ad04-d4ee95b7f80e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_photovoltaic_system_components","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Physik und Gesellschaft","topicCode":"CANONICAL_PHYSICS_PHOTOVOLTAIC_SYSTEM_COMPONENTS"}}`

## 649. Astronomische Weltbilder historisch und gesellschaftlich reflektieren

- ID: `6d18104b-5704-5c45-b39a-2c84565b1796`
- Beschreibung: Die lernende Person kann bedeutsame Beobachtungen und physikalische Theorien, die astronomische Weltbilder verändert haben, in ihre historischen und gesellschaftlichen Zusammenhänge einordnen und deren Auswirkungen reflektieren.
- `requires`: `["25edd154-b1d8-546c-94a5-88502b6725cd","d873ffa2-04b3-5978-a955-89563802a348"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astronomical_worldviews_context","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Physik und Gesellschaft","topicCode":"CANONICAL_PHYSICS_ASTRONOMICAL_WORLDVIEWS_CONTEXT"}}`

## 650. Biophysik: Auge, Ohr und neuronale Signalleitung

- ID: `47dc2c52-b776-5694-9715-ae98c7c23f85`
- Beschreibung: Buendelt biophysikalische Ziele zu Sinnesorganen, medizinischen Feldanwendungen und neuronaler Signalleitung.
- `requires`: `["84b1bc70-dadf-449b-a8d4-8bcee1da1fea","41fd5575-b1a6-40e7-8ea2-66b75a597a79","0735269d-703d-57ab-8861-6f7e1c5e2b8a"]`
- `contains`: `["84ddb244-e560-592f-9d43-e84c801fe5b4","ce14a7e7-7e2a-517f-a465-78ba3fbe414d","39ef1e8a-9203-5192-8c76-8e0c3322646f","41872413-497e-5b88-ac65-365ed7d9851f","6d882aac-9658-5f0d-bf3d-9338f0143bbc","8fe0ebf1-8256-53d2-9b01-fdb945e57a59","f06c581a-7157-584e-a692-99bcd613cff9","8ac61062-f63e-5935-96ae-84014906c368","9678afc1-44ca-54fb-b280-29336d45a928","bdaa56ad-6257-58a3-a633-8a6339f72f09","09e058e9-f3ed-5046-b0e9-495b694bf2a1","e19fccd7-6a35-5c9e-86e1-dcca76481e9c","d1306bda-35ff-53e9-9458-3cbc128874d8","db47ac91-7bb0-5ba3-b39d-e2d6fc98396e","2825b528-00ee-52d0-870e-686890cb1195","c2e0fc31-27a2-5727-9025-a824db9150d2","8cdef591-6ddb-5151-8c74-a80be0271079","3aaac6ad-948e-502a-9d49-ce40db0f2ca3","8fbae050-c5c9-52b6-9983-2c366e9c8ade","0b08aed8-3c0f-5b38-844c-1bb363abbf68"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_eye_ear_neuron","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL.PHYSICS.BIOPHYSICS"}}`

## 651. Linsenauge mit geometrischer Optik modellieren

- ID: `84ddb244-e560-592f-9d43-e84c801fe5b4`
- Beschreibung: Die lernende Person kann das Linsenauge mit Strahlenkonstruktion, Linsengleichung und Simulationen modellieren, Bedingungen scharfen Sehens quantitativ deuten und Modellgrenzen benennen.
- `requires`: `["078ce4d2-3193-4cd0-ae59-4fb8ab16e9e5","90e1e6cf-4092-41d6-81f7-5206f9d68f84","0a154cbd-1218-4553-835c-a754e9901bba"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_lens_eye_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_LENS_EYE_MODEL"}}`

## 652. Sehschwaechen mit dem Linse-Schirm-Modell untersuchen

- ID: `ce14a7e7-7e2a-517f-a465-78ba3fbe414d`
- Beschreibung: Die lernende Person kann Kurz- und Weitsichtigkeit mit dem Linse-Schirm-Modell experimentell untersuchen und Ergebnisse mit Vorhersagen der Linsengleichung vergleichen.
- `requires`: `["84ddb244-e560-592f-9d43-e84c801fe5b4","d3c153b9-e09b-5668-8386-73105546a7c1","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_visual_impairments_experiment","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_VISUAL_IMPAIRMENTS_EXPERIMENT"}}`

## 653. Farbsehen und additive Farbmischung deuten

- ID: `39ef1e8a-9203-5192-8c76-8e0c3322646f`
- Beschreibung: Die lernende Person kann additive Farbmischung als physiologischen Effekt des Farbsehens erklaeren und graphische Darstellungen empirischer Daten fachlich auswerten.
- `requires`: `["cdab9fd1-5054-4a7e-8c9a-4474062ddd23","d2e6f87d-795b-5631-a7cc-0bfb5dc5142e","80c232f1-8f72-5829-9dbe-5a610ccab3be"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_color_vision_additive_mixing","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_COLOR_VISION_ADDITIVE_MIXING"}}`

## 654. Beugungsbegrenzte Winkelauflösung des Auges abschätzen

- ID: `41872413-497e-5b88-ac65-365ed7d9851f`
- Beschreibung: Die lernende Person kann die Fraunhofer-Beugung an einer Kreisblende nutzen, um aus Wellenlänge und Pupillendurchmesser die beugungsbegrenzte Winkelauflösung des Auges abzuschätzen, und diese ideale optische Grenze von biologischen Einflüssen auf die Sehschärfe unterscheiden.
- `requires`: `["709e688c-eb07-5f83-a506-82c9bfe0d89f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_eye_resolution_diffraction","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_EYE_RESOLUTION_DIFFRACTION"}}`

## 655. Auflösungsvermögen des Auges experimentell bestimmen

- ID: `6d882aac-9658-5f0d-bf3d-9338f0143bbc`
- Beschreibung: Die lernende Person kann das Auflösungsvermögen des eigenen Auges mit einem sicheren Versuch und einem vorab festgelegten Trennkriterium bestimmen, das Ergebnis mit einer beugungsoptischen Abschätzung vergleichen und zufällige sowie systematische Messunsicherheiten diskutieren.
- `requires`: `["41872413-497e-5b88-ac65-365ed7d9851f","f6b1d812-ce8b-5852-b417-e6c29b533c7a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_eye_resolution_measurement","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_EYE_RESOLUTION_MEASUREMENT"}}`

## 656. Linsenaugen im Tierreich physikalisch vergleichen

- ID: `8fe0ebf1-8256-53d2-9b01-fdb945e57a59`
- Beschreibung: Die lernende Person kann Aufbau und Aufloesungsvermoegen unterschiedlicher Linsenaugen recherchieren, Modellgrenzen reflektieren und die Passung biologischer Systeme zu Anforderungen begruenden.
- `requires`: `["84ddb244-e560-592f-9d43-e84c801fe5b4","d2e6f87d-795b-5631-a7cc-0bfb5dc5142e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_lens_eyes_comparison","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_LENS_EYES_COMPARISON"}}`

## 657. Frequenzspektren von Tönen und Klängen analysieren

- ID: `f06c581a-7157-584e-a692-99bcd613cff9`
- Beschreibung: Die lernende Person kann Zeitdiagramme und Frequenzspektren von Tönen und Klängen miteinander verknüpfen, Grund- und Obertöne identifizieren und den Einfluss der Spektralanteile auf die Klangfarbe erklären.
- `requires`: `["e62e48bc-2387-4b2b-8d6f-7a06c8e7580e","25593605-5e13-55cc-9a05-8f3d737e15e9","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_sound_spectra_interference","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_SOUND_SPECTRA_INTERFERENCE"}}`

## 658. Schalldruckpegel und Hoerrisiken quantitativ beurteilen

- ID: `8ac61062-f63e-5935-96ae-84014906c368`
- Beschreibung: Die lernende Person kann Zusammenhaenge zwischen messbaren Schallgroessen und empfundener Lautstaerke mathematisch nutzen und Gesundheitsgefaehrdungen durch hohe Schalldruckpegel begruendet beurteilen.
- `requires`: `["10aad90e-a1db-42b6-8d1e-1d856e14b47d","da0837c7-95a7-5a6a-81db-f33cb7f42d85","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f","ee48e811-4c9c-5080-9836-8403fc9f0810"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_sound_level_health","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_SOUND_LEVEL_HEALTH"}}`

## 659. Richtungshören mit spektralen und binauralen Hinweisen untersuchen

- ID: `9678afc1-44ca-54fb-b280-29336d45a928`
- Beschreibung: Die lernende Person kann erklären, wie richtungsabhängige Filterung durch Ohrmuschel und Gehörgang sowie interaurale Laufzeit- und Pegeldifferenzen zur Schalllokalisation beitragen, Laufzeitdifferenzen für eine gegebene Richtung abschätzen und frequenzabhängige Grenzen der Hinweise beurteilen.
- `requires`: `["f06c581a-7157-584e-a692-99bcd613cff9","71a483ba-9680-4654-bb5e-5ab5427f0919"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_outer_ear_directional_hearing","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_OUTER_EAR_DIRECTIONAL_HEARING"}}`

## 660. Innenohr mit Resonanzmodellen erklären

- ID: `bdaa56ad-6257-58a3-a633-8a6339f72f09`
- Beschreibung: Die lernende Person kann die frequenzabhängige Schwingungsantwort der Basilarmembran mit mechanischen Resonanzmodellen erklären, den Ort des Antwortmaximums der Frequenz und die Schwingungsamplitude der mechanischen Antwortstärke zuordnen und das Modell von der nachfolgenden sensorischen und neuronalen Wahrnehmung abgrenzen.
- `requires`: `["3efa0cda-f55b-5534-8fac-ffe1d312aed1","f06c581a-7157-584e-a692-99bcd613cff9"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_inner_ear_resonance","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_INNER_EAR_RESONANCE"}}`

## 661. Physikalische Prinzipien des Corti-Organs aus Quellen erschließen

- ID: `09e058e9-f3ed-5046-b0e9-495b694bf2a1`
- Beschreibung: Die lernende Person kann aus vorgegebenen, belegten Quellen nachvollziehen, wie die Relativbewegung von Basilar- und Tektorialmembran die Stereozilien der Haarzellen auslenkt und dadurch mechanische Schwingungen in elektrische Rezeptorsignale überführt werden, die Grenzen dieser vereinfachten Wirkungskette kennzeichnen und die Erklärung fachsprachlich strukturiert präsentieren.
- `requires`: `["bdaa56ad-6257-58a3-a633-8a6339f72f09","d2e6f87d-795b-5631-a7cc-0bfb5dc5142e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_corti_organ_principles","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_CORTI_ORGAN_PRINCIPLES"}}`

## 662. Elektrische Dipolfelder mit dem EKG verknüpfen

- ID: `e19fccd7-6a35-5c9e-86e1-dcca76481e9c`
- Beschreibung: Die lernende Person kann elektrische Potenziale und Äquipotentiallinien eines Dipolfeldes experimentell oder in einer Simulation untersuchen und erklären, wie ein zeitlich veränderliches Dipolmodell des Herzens mit den zwischen Oberflächenelektroden gemessenen EKG-Potenzialdifferenzen zusammenhängt und wo die Grenzen dieser Näherung liegen.
- `requires`: `["2622bef1-bdbc-504e-b468-b600b2ca3ed8","f3de5922-dd45-4fb6-87c1-525d1952dd89"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_ekg_dipole_field","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_EKG_DIPOLE_FIELD"}}`

## 663. Zyklotron und Strahlentherapie fachlich bewerten

- ID: `d1306bda-35ff-53e9-9458-3cbc128874d8`
- Beschreibung: Die lernende Person kann das Funktionsprinzip des Zyklotrons auf Strahlentherapien beziehen und Nutzen sowie Risiken medizinischer Anwendungen mit physikalischen Kriterien bewerten.
- `requires`: `["2d62b444-796e-548d-aeee-cfd9c6665ddc","23fd87f3-9e79-5e0e-b9d1-7c15f3d119e0"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_radiation_therapy_cyclotron","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_RADIATION_THERAPY_CYCLOTRON"}}`

## 664. Ruhepotenzial an einer selektiv permeablen Membran modellieren

- ID: `db47ac91-7bb0-5ba3-b39d-e2d6fc98396e`
- Beschreibung: Die lernende Person kann das Ruhepotenzial in einem vereinfachten passiven Membranmodell als Ergebnis des Zusammenspiels von konzentrationsgetriebener Diffusion, elektrischer Gegenwirkung und selektiver Membranpermeabilität modellieren und erläutern, dass aktive Transportprozesse die Konzentrationsgradienten langfristig aufrechterhalten, aber nicht Bestandteil dieses passiven Modells sind.
- `requires`: `["7df599e8-21ac-5be4-89f9-9b2a6f2e4465","ac25ffe3-fd42-592d-a937-79cc13460313"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_resting_potential_diffusion","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_RESTING_POTENTIAL_DIFFUSION"}}`

## 665. Nervenleitungs-Messverfahren physikalisch beurteilen

- ID: `2825b528-00ee-52d0-870e-686890cb1195`
- Beschreibung: Die lernende Person kann die Eignung eines vorgegebenen Verfahrens zur Messung der Signalleitungsgeschwindigkeit in Nervenzellen begründen, indem sie die für dieses Verfahren relevanten elektrischen oder magnetischen Felder abschätzt und gegebenenfalls auftretende Induktionsspannungen aus der zeitlichen Änderung des magnetischen Flusses erklärt.
- `requires`: `["1a037489-3c95-540b-8cae-0acd360358ee","d3c153b9-e09b-5668-8386-73105546a7c1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_neuron_signal_speed_measurement","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_NEURON_SIGNAL_SPEED_MEASUREMENT"}}`

## 666. Axonsegmente als elektrische Ersatzschaltungen modellieren

- ID: `c2e0fc31-27a2-5727-9025-a824db9150d2`
- Beschreibung: Die lernende Person kann ein Axonsegment mit Membrankapazität sowie Membran- und Axialwiderstand als elektrische Ersatzschaltung modellieren, mehrere Segmente verknüpfen und begründen, welche passive Signalausbreitung das Modell erklärt und welche zusätzlichen spannungsabhängigen Elemente für aktive Leitung nötig sind.
- `requires`: `["8f833b36-4126-52db-b210-79fb0023c7d9","8fca14c7-3251-5526-adde-2567ea6816b2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_axon_rc_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_AXON_RC_MODEL"}}`

## 667. Membran- und Axialwiderstand im passiven Axonmodell untersuchen

- ID: `8cdef591-6ddb-5151-8c74-a80be0271079`
- Beschreibung: Die lernende Person kann Potenzialverläufe in einem passiven Widerstandsleitermodell messen und mathematisch beschreiben sowie begründen, warum ein größerer Membranwiderstand die räumliche Abschwächung verringert, ein größerer Axialwiderstand sie dagegen verstärkt.
- `requires`: `["c2e0fc31-27a2-5727-9025-a824db9150d2","28237994-9c24-5a06-82fe-be1f494768ba","27b63e2e-6a34-483e-8e5a-fe0f49670d1d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_resistive_cable_membrane","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_RESISTIVE_CABLE_MEMBRANE"}}`

## 668. Passive Signalleitung mit Kondensator-Ladekurven vergleichen

- ID: `3aaac6ad-948e-502a-9d49-ce40db0f2ca3`
- Beschreibung: Die lernende Person kann den lokalen zeitlichen Signalaufbau eines passiven Axonsegments mit einer Kondensator-Lade- oder Entladekurve vergleichen, durch ein exponentielles RC-Modell mathematisch beschreiben und von der zusätzlichen räumlichen Abschwächung gekoppelter Segmente abgrenzen.
- `requires`: `["c2e0fc31-27a2-5727-9025-a824db9150d2","330808f6-789a-583d-86df-e271a7683d8b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_passive_signal_rc_curve","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_PASSIVE_SIGNAL_RC_CURVE"}}`

## 669. Saltatorische Signalleitung aus aktiver Regeneration und Membraneigenschaften erklären

- ID: `8fbae050-c5c9-52b6-9983-2c366e9c8ade`
- Beschreibung: Die lernende Person kann erklären, wie spannungsabhängige Natriumkanäle die Depolarisation des Aktionspotenzials an Ranvier-Schnürringen regenerieren und Kaliumkanäle zur Repolarisation beitragen, während der erhöhte Membranwiderstand und die verringerte Membrankapazität myelinisierter Internodien eine schnelle passive Ausbreitung mit geringen Leckströmen ermöglichen, und passive Ausbreitung von aktiver Regeneration unterscheiden.
- `requires`: `["3aaac6ad-948e-502a-9d49-ce40db0f2ca3","db47ac91-7bb0-5ba3-b39d-e2d6fc98396e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_active_saltatory_signal","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_ACTIVE_SALTATORY_SIGNAL"}}`

## 670. Biologische und künstliche neuronale Verschaltungen mit einem gemeinsamen Modell vergleichen

- ID: `0b08aed8-3c0f-5b38-844c-1bb363abbf68`
- Beschreibung: Die lernende Person kann in gegebenen Diagrammen erregende und hemmende Verknüpfungen als gewichtete Beiträge zu einer Ausgabe deuten, dieses Verschaltungsmodell auf eine optische Täuschung und ein einfaches künstliches neuronales Netz übertragen und die Grenzen der Analogie benennen.
- `requires`: `["8fbae050-c5c9-52b6-9983-2c366e9c8ade","b378c8b3-5e83-5abf-8243-b0f345037bfc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_biophysics_neural_circuits_ai","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN","LI_FELDER","LI_TECHNIK"],"phase":"GLOBAL","area":"Biophysik","topicCode":"CANONICAL_PHYSICS_BIOPHYSICS_NEURAL_CIRCUITS_AI"}}`

## 671. Sinusfoermige Wechselgroessen mit Zeigerdiagrammen beschreiben

- ID: `5f97952e-5ac9-5749-94d0-d1dc50dda358`
- Beschreibung: Die lernende Person kann sinusfoermige Spannung und Stromstaerke in ohmschen Wechselstromkreisen mit Zeigerdiagrammen darstellen und Phasenbeziehungen fachlich deuten.
- `requires`: `["53196a71-9dbd-4835-b2f9-ff21b8a8962c","ac4ba260-6086-5fcc-bea2-c06f1425a1cc","bbef7cf2-90fa-59fa-a115-8b651aab9231"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_ac_phasor_ohmic_circuit","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Wechselstrom und Schwingkreise","topicCode":"CANONICAL_PHYSICS_AC_PHASOR_OHMIC_CIRCUIT"}}`

## 672. Kondensator und Spule im Wechselstromkreis analysieren

- ID: `ef0f2391-fd8e-5ae3-ae86-7adcdd833c7a`
- Beschreibung: Die lernende Person kann Amplitudenverhaeltnisse und Phasenbeziehungen zwischen Spannung und Stromstaerke fuer Kondensator und Spule im Wechselstromkreis aus differentiellen Zusammenhaengen erschliessen und mit Zeigerdiagrammen beschreiben.
- `requires`: `["5f97952e-5ac9-5749-94d0-d1dc50dda358","8fca14c7-3251-5526-adde-2567ea6816b2","37f28bc4-def2-57cf-a06b-191dfd228205","58d2f963-4fb9-550d-a832-f5ac60808900"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_ac_capacitor_inductor_phase_relations","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Wechselstrom und Schwingkreise","topicCode":"CANONICAL_PHYSICS_AC_CAPACITOR_INDUCTOR_PHASE_RELATIONS"}}`

## 673. Frequenzabhaengige Schaltungen und Filter untersuchen

- ID: `e413a352-33c4-53ae-b54a-30e52c3e65ae`
- Beschreibung: Die lernende Person kann das frequenzabhaengige Verhalten von Hochpass, Tiefpass, Bandpass oder Bandfilter experimentell oder rechnerisch untersuchen und graphisch darstellen.
- `requires`: `["ef0f2391-fd8e-5ae3-ae86-7adcdd833c7a","72effc66-87f4-5f5e-8d36-1547677365fb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_ac_frequency_filters","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_FELDER","LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Wechselstrom und Schwingkreise","topicCode":"CANONICAL_PHYSICS_AC_FREQUENCY_FILTERS"}}`

## 674. Elektronenbeugung als Materiewellenexperiment auswerten

- ID: `e296aba6-f407-5944-a2bd-e5296e4c9f06`
- Beschreibung: Die lernende Person kann Aufbau und Funktion einer Elektronenbeugungsroehre beschreiben, Beugungsbilder deuten und aus Messdaten den Zusammenhang zwischen Impuls und De-Broglie-Wellenlaenge erschliessen.
- `requires`: `["dfa53498-34f5-5326-9d94-87e7b528caf3","c71315c1-f329-4289-a145-d99819da7bad"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_quantum_electron_diffraction_experiment","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"GLOBAL","area":"Quantenphysik","topicCode":"CANONICAL_PHYSICS_QUANTUM_ELECTRON_DIFFRACTION_EXPERIMENT"}}`

## 675. Quanteninterferometer mit Phasen und Weginformation deuten

- ID: `52b6722a-b3b2-5d2d-a507-0215532b0422`
- Beschreibung: Die lernende Person kann Interferenzexperimente mit einzelnen Photonen, etwa im Mach-Zehnder-Interferometer, mit Phasenbeziehungen, Zeigerdiagrammen und Weginformation deuten.
- `requires`: `["c5413852-abae-566b-b435-f9939209ca63","6031bed0-9baa-4f45-b2a5-57ffb00d39cc","571793bd-34f1-539e-969c-dfcc2dfa96b3","c63bbffd-8d1c-5fe2-a428-db194e6fe592","c8818eae-0c4d-4fa1-9085-04a9c95a668b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_quantum_interferometer_phase_paths","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE","LI_WELLEN"],"phase":"GLOBAL","area":"Quantenphysik","topicCode":"CANONICAL_PHYSICS_QUANTUM_INTERFEROMETER_PHASE_PATHS"}}`

## 676. Potentialverlaeufe und Atombindung quantenmechanisch plausibilisieren

- ID: `43adaa0b-1f37-5d55-a496-6900555274a1`
- Beschreibung: Die lernende Person kann einfache Potentialverläufe mithilfe von Simulationen untersuchen, Wellenfunktionen und Energieniveaus qualitativ vergleichen und damit das Zustandekommen von Atombindung plausibel machen.
- `requires`: `["cc2d5e8e-4599-54ac-b8de-87c8cfd39ea7","ef6d5067-96b0-5388-87dd-5ac4e6a3e313"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_quantum_potential_bonding_simulations","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Quantenphysik","topicCode":"CANONICAL_PHYSICS_QUANTUM_POTENTIAL_BONDING_SIMULATIONS"}}`

## 677. Mehrelektronenatome mit Pauli-Prinzip und Energieniveaus deuten

- ID: `badb0ef3-233d-560e-bc2a-9df99f09fe7d`
- Beschreibung: Die lernende Person kann Mehrelektronensysteme qualitativ deuten, indem sie die Besetzung von Energieniveaus nach dem Pauli-Prinzip (kein vollständiger Ein-Elektronenzustand einschließlich Spin ist doppelt besetzt) mit einem Energieniveauschema der Atomhülle verknüpft.
- `requires`: `["d7244ce4-5409-58d1-a1b4-bfae35f391e1","904670af-8e4c-543e-bc9b-e6248d87a10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_atomic_multi_electron_pauli_shells","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Atomphysik","topicCode":"CANONICAL_PHYSICS_ATOMIC_MULTI_ELECTRON_PAULI_SHELLS"}}`

## 678. Geiger-Müller-Zählrohr funktional erklären

- ID: `b1ad9493-acca-5366-9ecd-4b7bf7edaf4a`
- Beschreibung: Die lernende Person kann erklären, wie Primärionisation im Geiger-Müller-Zählrohr eine lawinenartige Gasentladung und dadurch einen Zählimpuls auslöst, und begründen, warum das Gerät Ereignisse zählt, aber keine Energie der einfallenden Strahlung bestimmt.
- `requires`: `["25d91cc0-d84c-5522-86b5-fdff73264f08"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_nuclear_geiger_counter","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Kernphysik","topicCode":"CANONICAL_PHYSICS_NUCLEAR_GEIGER_COUNTER"}}`

## 679. Nuklidkarten und Zerfallsreihen auswerten

- ID: `64b30d2e-cbe1-55d8-915a-a050d736b96e`
- Beschreibung: Die lernende Person kann digitale Nuklidkarten auswerten, Eigenschaften von Nukliden entnehmen und Zerfallsreihen fachlich rekonstruieren.
- `requires`: `["3b50255a-6b01-578b-8f5c-4383536a3221"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_nuclear_nuclide_chart_decay_series","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"GLOBAL","area":"Kernphysik","topicCode":"CANONICAL_PHYSICS_NUCLEAR_NUCLIDE_CHART_DECAY_SERIES"}}`

## 680. Polarisation quantitativ mit dem Malus-Gesetz untersuchen

- ID: `3d3e5917-d367-535d-a6ad-b9d87259e6ce`
- Beschreibung: Die lernende Person kann für linear polarisiertes Licht die Intensität hinter einem Analysator in Abhängigkeit vom Winkel zwischen Polarisations- und Transmissionsrichtung messen, die Daten unter Berücksichtigung der Messunsicherheit mit I = I₀ cos²(α) vergleichen und Abweichungen durch Untergrund oder nichtideale Filter begründen.
- `requires`: `["549269d3-1aef-5c55-9640-ee2a8e2ee9a1"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_em_polarization_malus_law","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"GLOBAL","area":"Elektromagnetische Wellen","topicCode":"CANONICAL_PHYSICS_EM_POLARIZATION_MALUS_LAW"}}`

## 681. Optische Audioübertragung und Multiplexing

- ID: `ea17b0af-3d53-5a10-acda-7fd9348537ce`
- Beschreibung: Dieser fachliche Cluster bündelt das funktionale Umsetzen eines Audio-Licht-Übertragungsversuchs und das Entwickeln eines Modells optischen Multiplexings.
- `requires`: `[]`
- `contains`: `["922f32ba-f214-5a82-be5c-1111aca51d4a","f505f039-3f07-5afe-88b8-f02532e9c2f0"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_em_optical_signal_multiplexing","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektromagnetische Wellen","topicCode":"CANONICAL_PHYSICS_EM_OPTICAL_SIGNAL_MULTIPLEXING"}}`

## 682. Rückkopplungsprinzip elektromagnetischer Schwingungen erklären

- ID: `91f1838c-80fc-55f5-ac30-e7d1498fccee`
- Beschreibung: Die lernende Person kann das Rückkopplungsprinzip zur Aufrechterhaltung elektromagnetischer Schwingungen fachlich erklären und auf einfache Oszillator- oder Senderkontexte beziehen.
- `requires`: `["ac4ba260-6086-5fcc-bea2-c06f1425a1cc"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_em_feedback_principle","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektromagnetische Wellen","topicCode":"CANONICAL_PHYSICS_EM_FEEDBACK_PRINCIPLE"}}`

## 683. Modulation einer Trägerwelle fachlich beschreiben

- ID: `122e83ac-c9cf-50c1-8a73-a1e3db347f21`
- Beschreibung: Die lernende Person kann Modulation einer Trägerwelle als Grundprinzip technischer Informationsübertragung beschreiben und mit elektromagnetischen Wellenanwendungen verbinden.
- `requires`: `["91f1838c-80fc-55f5-ac30-e7d1498fccee","4a7cbe83-b694-57d3-85ce-1eeca418daaf"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_em_carrier_wave_modulation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektromagnetische Wellen","topicCode":"CANONICAL_PHYSICS_EM_CARRIER_WAVE_MODULATION"}}`

## 684. Nachthimmel-Orientierung und Sichtbarkeit astronomischer Objekte erschließen

- ID: `2bc068de-5d2b-5f94-bd51-755982befb6f`
- Beschreibung: Die Teilziele bündeln die Navigation am Nachthimmel, die Klassifikation beobachtbarer Objekte und die Begründung ihrer räumlich-zeitlichen Sichtbarkeit.
- `requires`: `[]`
- `contains`: `["d024aa45-5dbb-51f7-87a6-9ba939858696","e06dd9c7-8c36-5ca4-880b-57b02d837085","0b8a4215-e6ed-56c8-88c3-b3a2a99723c7"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_night_sky_orientation_visibility","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_NIGHT_SKY_ORIENTATION_VISIBILITY"}}`

## 685. Am Nachthimmel mit Sternkarte oder Software navigieren

- ID: `d024aa45-5dbb-51f7-87a6-9ba939858696`
- Beschreibung: Die lernende Person kann für einen vorgegebenen Beobachtungsort und -zeitpunkt eine Sternkarte oder geeignete Software ausrichten und damit markante Sternbilder oder astronomische Objekte am Himmel auffinden.
- `requires`: `["2b700858-bc2e-5ddf-a791-b14d44160480","7c986fca-1129-5eff-a17e-0a04bb7346ee"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_night_sky_navigation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_NIGHT_SKY_NAVIGATION"}}`

## 686. Mit bloßem Auge beobachtbare Himmelsobjekte klassifizieren

- ID: `e06dd9c7-8c36-5ca4-880b-57b02d837085`
- Beschreibung: Die lernende Person kann mit bloßem Auge beobachtbare astronomische Objekte anhand geeigneter beobachtbarer Merkmale begründet Objektklassen zuordnen.
- `requires`: `["2b700858-bc2e-5ddf-a791-b14d44160480"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_observable_object_classification","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_OBSERVABLE_OBJECT_CLASSIFICATION"}}`

## 687. Räumlich-zeitliche Sichtbarkeit astronomischer Objekte begründen

- ID: `0b8a4215-e6ed-56c8-88c3-b3a2a99723c7`
- Beschreibung: Die lernende Person kann unter Berücksichtigung von Beobachtungsort, Uhrzeit und Jahreszeit grundlegende Aussagen darüber treffen und begründen, wann und wo ein astronomisches Objekt sichtbar ist.
- `requires`: `["d024aa45-5dbb-51f7-87a6-9ba939858696"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_spatiotemporal_visibility","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_SPATIOTEMPORAL_VISIBILITY"}}`

## 688. Planetenkonstellationen, Sichtbarkeit und Schleifenbahnen erschließen

- ID: `0a172021-dfd9-5926-b92c-c01a9dfe9aa8`
- Beschreibung: Die Teilziele verbinden die Modellierung von Planetenkonstellationen und Sichtbarkeit mit der physikalischen Erklärung und historischen Einordnung scheinbarer Schleifenbahnen.
- `requires`: `[]`
- `contains`: `["6e1cd027-040b-51d9-8764-3cf3daddb5ec","44766569-6379-5fbc-8976-cd3fc2fd6ec4"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_planet_configurations_visibility","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_PLANET_CONFIGURATIONS_VISIBILITY"}}`

## 689. Planetenkonstellationen und ihre Sichtbarkeit modellieren

- ID: `6e1cd027-040b-51d9-8764-3cf3daddb5ec`
- Beschreibung: Die lernende Person kann Planetenkonstellationen in Zeichnungen oder Simulationen modellieren und daraus ihre Sichtbarkeit am Nachthimmel erklären.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_planetary_configurations_visibility","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_PLANETARY_CONFIGURATIONS_VISIBILITY"}}`

## 690. Schleifenbahnen von Planeten historisch einordnen

- ID: `44766569-6379-5fbc-8976-cd3fc2fd6ec4`
- Beschreibung: Die lernende Person kann scheinbare Schleifenbahnen der Planeten als Folge relativer Bewegung im heliozentrischen Modell erklären und ihre Bedeutung für historische Erweiterungen und Umbrüche von Planetenbahnmodellen sowie deren Auswirkungen auf Weltbilder reflektieren.
- `requires`: `["6e1cd027-040b-51d9-8764-3cf3daddb5ec","6d18104b-5704-5c45-b39a-2c84565b1796"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_planetary_retrograde_loops_worldviews","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_PLANETARY_RETROGRADE_LOOPS_WORLDVIEWS"}}`

## 691. Astronomische Einheit und ihre beobachtungsbasierte Bestimmung erklären

- ID: `5cf160e5-e0c2-5552-b2cf-0f04871c5e7e`
- Beschreibung: Die lernende Person kann die Astronomische Einheit als Entfernungsmaß im Sonnensystem einordnen, dessen Wert in Metern heute exakt definiert ist, und aus Fachtexten sowie Beobachtungsdaten rekonstruieren, wie diese Länge vor der heutigen Definition erschlossen wurde.
- `requires`: `["7c986fca-1129-5eff-a17e-0a04bb7346ee","db6b8de4-21e0-58e8-a347-2ae39f538f92"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_astronomical_unit_measurement","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_ASTRONOMICAL_UNIT_MEASUREMENT"}}`

## 692. Himmelskörper des Sonnensystems physikalisch klassifizieren

- ID: `982df2f3-e040-5f4b-b668-0fe05d994b29`
- Beschreibung: Die lernende Person kann Himmelskörper des Sonnensystems anhand physikalischer Eigenschaften, Bahnparameter und recherchierter Daten klassifizieren und begründete Schlussfolgerungen präsentieren.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93","d2e6f87d-795b-5631-a7cc-0bfb5dc5142e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_solar_system_body_classification","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_SOLAR_SYSTEM_BODY_CLASSIFICATION"}}`

## 693. Solare Zustandsgrößen aus Beobachtungen erschließen

- ID: `94a3a80e-f1de-51a2-b834-1e3431c5d3ca`
- Beschreibung: Die Teilziele bündeln beobachtungs- und modellgestützte Abschätzungen von Sonnenradius, Sonnenmasse, Sonnenleuchtkraft und solarer Rotationsdauer.
- `requires`: `[]`
- `contains`: `["bebc3738-0be6-52cf-83db-f8b948f7cf7b","5e9cd796-3887-5457-8a1f-26863ca7eb28","9851bd02-ca48-5ce4-8e9f-9ec4af1c43b8","23335a89-f8e6-5c22-8705-d71193aeac96"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_solar_observations_state_variables","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_SOLAR_OBSERVATIONS_STATE_VARIABLES"}}`

## 694. Sonnenradius aus Beobachtungsdaten abschätzen

- ID: `bebc3738-0be6-52cf-83db-f8b948f7cf7b`
- Beschreibung: Die lernende Person kann aus einem sicher gewonnenen oder bereitgestellten Winkeldurchmesser der Sonne und ihrer Entfernung mithilfe eines geometrischen Modells den Sonnenradius abschätzen und die Messunsicherheit berücksichtigen.
- `requires`: `["2b700858-bc2e-5ddf-a791-b14d44160480","7c986fca-1129-5eff-a17e-0a04bb7346ee","8d30d241-0247-48ac-83d3-4e0de61584d3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_solar_radius_observation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_SOLAR_RADIUS_OBSERVATION"}}`

## 695. Sonnenmasse aus Bahndaten abschätzen

- ID: `5e9cd796-3887-5457-8a1f-26863ca7eb28`
- Beschreibung: Die lernende Person kann aus Bahndaten eines die Sonne umlaufenden Körpers mit einem Newton-Kepler-Modell die Sonnenmasse abschätzen und die dafür verwendeten Modellannahmen benennen.
- `requires`: `["497f1311-17d6-56ff-afb1-422a738e5c16","7c986fca-1129-5eff-a17e-0a04bb7346ee"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_solar_mass_orbital_data","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_SOLAR_MASS_ORBITAL_DATA"}}`

## 696. Sonnenleuchtkraft aus Solarkonstante und Entfernung abschätzen

- ID: `9851bd02-ca48-5ce4-8e9f-9ec4af1c43b8`
- Beschreibung: Die lernende Person kann aus Solarkonstante und Sonne-Erde-Abstand die Leuchtkraft der Sonne abschätzen und die gemessene Bestrahlungsstärke von der erschlossenen Gesamtleistung unterscheiden.
- `requires`: `["2b700858-bc2e-5ddf-a791-b14d44160480","7c986fca-1129-5eff-a17e-0a04bb7346ee"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_solar_luminosity_solar_constant","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_SOLAR_LUMINOSITY_SOLAR_CONSTANT"}}`

## 697. Rotationsdauer der Sonne aus Beobachtungsreihen abschätzen

- ID: `23335a89-f8e6-5c22-8705-d71193aeac96`
- Beschreibung: Die lernende Person kann in zeitlich getrennten, sicher gewonnenen oder bereitgestellten Sonnenbildern wiedererkennbare Strukturen verfolgen, daraus eine beobachterbezogene synodische Rotationsdauer abschätzen und erläutern, wie Projektion, Strukturentwicklung und differentielle Rotation die Näherung begrenzen.
- `requires`: `["2b700858-bc2e-5ddf-a791-b14d44160480","ca623958-c204-5d1b-bdd0-3f76765674cb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_solar_rotation_observation","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_SOLAR_ROTATION_OBSERVATION"}}`

## 698. Sonnenaktivität und Weltraumwetter fachlich beurteilen

- ID: `4e823349-b60c-5d2a-b96f-d3f23ae50e3a`
- Beschreibung: Die lernende Person kann Zusammenhänge zwischen solarem Magnetfeld, Sonnenflecken und Aktivitätsphasen anhand recherchierter Informationen prüfen und daraus die Bedeutung der Überwachung des Weltraumwetters fachlich beurteilen.
- `requires`: `["4c5c7cb1-f238-52c8-b82c-159c6c299c0e","d2e6f87d-795b-5631-a7cc-0bfb5dc5142e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_solar_activity_space_weather","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_SOLAR_ACTIVITY_SPACE_WEATHER"}}`

## 699. Sternspektren und Temperaturgesetze auswerten

- ID: `a7bec355-48c5-5107-bfab-d6956f9c9205`
- Beschreibung: Die Teilziele verbinden die Deutung von Fraunhoferlinien mit der Bestimmung stellarer Oberflächentemperaturen aus Strahlungsdaten.
- `requires`: `[]`
- `contains`: `["f9c025ce-4327-5de7-8288-a3358e14a576","89124b92-5769-5e13-8a5d-78497936260f"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_stellar_spectra_temperature_laws","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_STELLAR_SPECTRA_TEMPERATURE_LAWS"}}`

## 700. Fraunhoferlinien in Sternspektren deuten

- ID: `f9c025ce-4327-5de7-8288-a3358e14a576`
- Beschreibung: Die lernende Person kann Fraunhoferlinien in Sternspektren als Absorptionslinien deuten und ihre Entstehung durch selektive Absorption in der Sternatmosphäre mithilfe eines Energieniveaumodells erklären.
- `requires`: `["904670af-8e4c-543e-bc9b-e6248d87a10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_fraunhofer_absorption_lines","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_FRAUNHOFER_ABSORPTION_LINES"}}`

## 701. Oberflächentemperaturen von Sternen aus Strahlungsdaten abschätzen

- ID: `89124b92-5769-5e13-8a5d-78497936260f`
- Beschreibung: Die lernende Person kann die Oberflächentemperatur eines Sterns aus dem Spektralmaximum mit dem Wienschen Verschiebungsgesetz oder bei bekannten Größen zu Radius und Strahlungsleistung mit dem Stefan-Boltzmann-Gesetz abschätzen.
- `requires`: `["2b700858-bc2e-5ddf-a791-b14d44160480","f8704a7b-e93d-4e32-b0f9-1b171545fe28"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_stellar_surface_temperature_radiation_laws","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_STELLAR_SURFACE_TEMPERATURE_RADIATION_LAWS"}}`

## 702. Strahlungsgleichgewichte und Lebensbedingungen abschätzen

- ID: `a5031dfc-6d25-5a04-850a-5c7d8a254c21`
- Beschreibung: Die lernende Person kann aus einem begründeten Strahlungsgleichgewicht die Gleichgewichtstemperatur eines Himmelskörpers als Modellnäherung für seine Oberflächentemperatur abschätzen, Modellannahmen und Abweichungen von Messwerten reflektieren und daraus begrenzte Aussagen zu möglichen Lebensbedingungen ableiten.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93","89124b92-5769-5e13-8a5d-78497936260f","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_radiation_equilibrium_habitability","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_RADIATION_EQUILIBRIUM_HABITABILITY"}}`

## 703. Parallaxe, Dopplereffekt und Sternspektren auswerten

- ID: `e07f36de-2819-59f8-a707-fa25b4633ed3`
- Beschreibung: Die Teilziele bündeln astrometrische und spektroskopische Verfahren, mit denen Entfernungen, Bewegungen und Eigenschaften von Sternen erschlossen werden.
- `requires`: `[]`
- `contains`: `["9f85de48-1b3f-5afb-8a34-ce94cf7a1b49","ce037050-f94c-5828-883a-76385c84d1f7","5c5d6698-c056-5850-8ecd-6dd87fb44549"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_parallax_doppler_spectra","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_WELLEN"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_PARALLAX_DOPPLER_SPECTRA"}}`

## 704. Sternentfernungen und Tangentialgeschwindigkeiten astrometrisch bestimmen

- ID: `9f85de48-1b3f-5afb-8a34-ce94cf7a1b49`
- Beschreibung: Die lernende Person kann aus der trigonometrischen Parallaxe die Entfernung eines Sterns bestimmen und zusammen mit seiner Eigenbewegung dessen Tangentialgeschwindigkeit abschätzen sowie Reichweite und Messunsicherheit der Methode beurteilen.
- `requires`: `["db6b8de4-21e0-58e8-a347-2ae39f538f92"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_astrometry_distance_tangential_velocity","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_WELLEN"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_ASTROMETRY_DISTANCE_TANGENTIAL_VELOCITY"}}`

## 705. Radialgeschwindigkeiten aus Dopplerverschiebungen bestimmen

- ID: `ce037050-f94c-5828-883a-76385c84d1f7`
- Beschreibung: Die lernende Person kann Richtung und Betrag der Radialgeschwindigkeit eines Sterns aus der Verschiebung identifizierter Spektrallinien bestimmen und Vorzeichen, Bezugssystem sowie Messunsicherheit erläutern.
- `requires`: `["904670af-8e4c-543e-bc9b-e6248d87a10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_stellar_doppler_radial_velocity","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_WELLEN"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_STELLAR_DOPPLER_RADIAL_VELOCITY"}}`

## 706. Sterne anhand ihrer Spektren klassifizieren

- ID: `5c5d6698-c056-5850-8ecd-6dd87fb44549`
- Beschreibung: Die lernende Person kann Sternspektren anhand charakteristischer Absorptionslinien einer Spektralklasse zuordnen und die Zuordnung mit Linienmustern und Oberflächentemperatur begründen.
- `requires`: `["904670af-8e4c-543e-bc9b-e6248d87a10d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_stellar_spectral_classification","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_WELLEN"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_STELLAR_SPECTRAL_CLASSIFICATION"}}`

## 707. Sternradien, Entfernungen und Hauptreihenzeiten erschließen

- ID: `f67550ac-df22-5a3e-8172-f04642efca64`
- Beschreibung: Cluster für quantitative Sternradius-, Entfernungs- und Hauptreihenzeitmodelle.
- `requires`: `[]`
- `contains`: `["6a73cacc-e86d-5248-a180-fd3da8454b0f","3a4b2f86-5c59-5429-8fb4-75d9b2589cb5","946ecf7b-0fcf-5776-9fb6-d397423c2f12"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_hrd_stellar_evolution_quantitative","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_HRD_STELLAR_EVOLUTION_QUANTITATIVE"}}`

## 708. Sternradien aus HRD-Daten abschätzen

- ID: `6a73cacc-e86d-5248-a180-fd3da8454b0f`
- Beschreibung: Die lernende Person kann aus Leuchtkraft und Oberflächentemperatur eines Sterns im Hertzsprung-Russell-Diagramm seinen Radius mit einem thermischen Strahlungsmodell abschätzen und erklären, wie beide Größen die Schätzung bestimmen.
- `requires`: `["206fe51d-cc78-5422-b139-32cc97eb1c37","89124b92-5769-5e13-8a5d-78497936260f","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_hrd_stellar_radius","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_HRD_STELLAR_RADIUS","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_KOSMOS"]}}`

## 709. Sternentfernungen mit dem HRD abschätzen

- ID: `3a4b2f86-5c59-5429-8fb4-75d9b2589cb5`
- Beschreibung: Die lernende Person kann aus einer begründeten Zuordnung eines Sterns im Hertzsprung-Russell-Diagramm und seiner beobachteten Helligkeit die Entfernung abschätzen und erklären, wie eine falsche Zuordnung oder nicht berücksichtigte Absorption das Ergebnis beeinflusst.
- `requires`: `["206fe51d-cc78-5422-b139-32cc97eb1c37","db6b8de4-21e0-58e8-a347-2ae39f538f92"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_hrd_spectroscopic_distance","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_HRD_SPECTROSCOPIC_DISTANCE","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_KOSMOS"]}}`

## 710. Hauptreihenzeiten mit der Masse-Leuchtkraft-Beziehung abschätzen

- ID: `946ecf7b-0fcf-5776-9fb6-d397423c2f12`
- Beschreibung: Die lernende Person kann die Hauptreihenzeit eines Sterns mithilfe einer für seinen Massenbereich geeigneten Masse-Leuchtkraft-Beziehung und eines vereinfachten Brennstoffmodells abschätzen und die Grenzen dieser Abschätzung begründen.
- `requires`: `["6f896466-e0ec-5f8d-82ad-2890433c82ba","a6469c01-6ca3-5eb2-a82c-94f3d0560b32"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_main_sequence_lifetime_model","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_MAIN_SEQUENCE_LIFETIME_MODEL","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_KOSMOS","LI_ENERGIE"]}}`

## 711. Materiekreislauf, Elemententstehung und Stern-Endstadien

- ID: `7df923a0-6470-595e-8cea-53126fad9506`
- Beschreibung: Dieser fachliche Cluster bündelt die materialgestützte Beurteilung von Argumentationen zur Entstehung schwerer Elemente im kosmischen Materiekreislauf und die Prognose von Stern-Endstadien anhand von Anfangsmasse und Massenverlust.
- `requires`: `[]`
- `contains`: `["e1b21fe9-ab6f-58c4-a0b6-9895061fbabb","69280706-5af6-5788-85b7-93287c2ffe74"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_matter_cycle_heavy_elements","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_MATERIE"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_MATTER_CYCLE_HEAVY_ELEMENTS"}}`

## 712. Massenbestimmung in Doppelsternsystemen und Gravitationswellen deuten

- ID: `7c8f1e34-d81a-51a2-8aa0-a6ee8e1b03a4`
- Beschreibung: Die Teilziele verbinden die Masseninferenz aus optischen Bahn- und Gravitationswellendaten mit einer physikalisch begrenzten Erklärung der Gravitationswellenentstehung.
- `requires`: `[]`
- `contains`: `["4ea39b40-1563-58ab-8d54-5fc20efa5365","09995ab9-86aa-5b02-8a58-62b16a37831d"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_binary_gravitational_wave_mass","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS","LI_WELLEN"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_BINARY_GRAVITATIONAL_WAVE_MASS"}}`

## 713. Massenparameter aus Doppelstern- und Gravitationswellendaten erschließen

- ID: `4ea39b40-1563-58ab-8d54-5fc20efa5365`
- Beschreibung: Die Teilziele trennen die dynamische Gesamtmasseninferenz aus optischen Zweikörperbahndaten von der Chirp-Masseninferenz aus der Frequenzentwicklung eines Gravitationswellensignals und begrenzen beide Verfahren durch ihre jeweiligen Modellannahmen.
- `requires`: `[]`
- `contains`: `["2014791b-af68-58d0-838b-fc9701202096","1b7e800a-1c0d-5faa-886b-7ef2f3b8348c"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_binary_gw_mass_inference","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS","LI_WELLEN"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_BINARY_GW_MASS_INFERENCE"}}`

## 714. Dynamische Gesamtmasse aus optischen Zweikörperbahndaten erschließen

- ID: `2014791b-af68-58d0-838b-fc9701202096`
- Beschreibung: Die lernende Person kann aus Bahnperiode und räumlich kalibrierter Bahnskala eines optisch beobachteten Zweikörpersystems mit einem begründeten Zweikörper- und Gravitationsmodell die dynamische Gesamtmasse des Systems abschätzen sowie Annahmen, Unsicherheiten und Grenzen der Inferenz erläutern.
- `requires`: `["497f1311-17d6-56ff-afb1-422a738e5c16"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_binary_optical_dynamical_mass_inference","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS","LI_WELLEN"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_BINARY_OPTICAL_DYNAMICAL_MASS_INFERENCE"}}`

## 715. Chirp-Masse aus der Frequenzentwicklung eines Gravitationswellensignals erschließen

- ID: `1b7e800a-1c0d-5faa-886b-7ef2f3b8348c`
- Beschreibung: Die lernende Person kann aus Frequenz und Frequenzänderungsrate eines inspiralartigen Gravitationswellensignals mit einem begründeten Näherungsmodell die Chirp-Masse als bestimmte Kombination der Komponentenmassen abschätzen sowie Annahmen, Unsicherheiten und Grenzen dieser Inferenz erläutern.
- `requires`: `["497f1311-17d6-56ff-afb1-422a738e5c16","ba16948b-5e07-54af-b77b-776e677c6906"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_gravitational_wave_chirp_mass_inference","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS","LI_WELLEN"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_GRAVITATIONAL_WAVE_CHIRP_MASS_INFERENCE"}}`

## 716. Entstehung von Gravitationswellen mit begrenzter Analogie erklären

- ID: `09995ab9-86aa-5b02-8a58-62b16a37831d`
- Beschreibung: Die lernende Person kann die Entstehung von Gravitationswellen durch zeitlich veränderliche, nicht kugelsymmetrische Massenverteilungen qualitativ erklären und Gemeinsamkeiten sowie Grenzen der Analogie zu elektromagnetischer Strahlung benennen.
- `requires`: `["ba16948b-5e07-54af-b77b-776e677c6906"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_gravitational_wave_generation_analogy","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS","LI_WELLEN"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_GRAVITATIONAL_WAVE_GENERATION_ANALOGY"}}`

## 717. Exoplanetensuche und Habitabilität quellenkritisch beurteilen

- ID: `e2014db8-c97f-5ce1-82c5-2a42741f4a61`
- Beschreibung: Die lernende Person kann Aussagen zur Habitabilität von Exoplaneten beurteilen, indem sie Nachweismethoden vergleicht, Lebensbedingungen anhand physikalischer Kriterien mit denen der Erde abgleicht und digitale Quellen quellenkritisch auswertet.
- `requires`: `["49bb609a-bfb7-5391-9120-f5fc737efb9a","6dca3b0a-c872-543b-808f-97e855f5fafd","e28381b4-50ef-5cac-bfa4-b7c8e03aef82"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_exoplanet_habitability_sources","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_EXOPLANET_HABITABILITY_SOURCES"}}`

## 718. Teleskope und Spektralbereiche zur Struktur der Milchstraße nutzen

- ID: `826af579-3e51-5ac9-bc2a-208d8a2fc99e`
- Beschreibung: Die lernende Person kann Teleskope für verschiedene Spektralbereiche vergleichen, Beobachtungsdaten aus mehreren Bereichen zusammenführen und daraus die Struktur der Milchstraße beschreiben.
- `requires`: `["2b700858-bc2e-5ddf-a791-b14d44160480","1b060e79-dc2d-5e4e-abb5-42eca39f9cc7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_telescope_milky_way_structure","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS","LI_WELLEN"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_TELESCOPE_MILKY_WAY_STRUCTURE"}}`

## 719. Galaktische Massen und Dunkle Materie aus Bahnbewegungen erschließen

- ID: `f203a552-fcf0-560c-baa2-47d4eb2379c8`
- Beschreibung: Die Teilziele trennen die gravitationsgestützte Abschätzung eingeschlossener astronomischer Massen von der Dunkle-Materie-Inferenz aus Galaxienrotationskurven.
- `requires`: `[]`
- `contains`: `["f3dbcafa-1849-5ee1-8807-81e8d7fed73d","c53b3f0c-b4fe-5509-8803-a36c2883e5d6"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_dark_matter_rotation_curves","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_DARK_MATTER_ROTATION_CURVES"}}`

## 720. Massen aus astronomischen Bahnbewegungen abschätzen

- ID: `f3dbcafa-1849-5ee1-8807-81e8d7fed73d`
- Beschreibung: Die lernende Person kann aus Bahngeschwindigkeiten und Radien mit einem begründeten Gravitationsmodell die innerhalb der jeweiligen Bahn eingeschlossene Masse eines astronomischen Systems abschätzen und erläutern, unter welchen Annahmen daraus etwa die Masse eines zentralen Schwarzen Lochs oder die Massenverteilung einer Galaxie erschlossen werden kann.
- `requires`: `["1b060e79-dc2d-5e4e-abb5-42eca39f9cc7","14d99a65-8d58-5647-88ab-02137b96d55b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_orbital_mass_inference","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_ORBITAL_MASS_INFERENCE"}}`

## 721. Dunkle Materie aus Galaxienrotationskurven erschließen

- ID: `c53b3f0c-b4fe-5509-8803-a36c2883e5d6`
- Beschreibung: Die lernende Person kann eine beobachtete Galaxienrotationskurve mit der aus der sichtbaren Materieverteilung erwarteten Kurve vergleichen, die Abweichung als Hinweis auf zusätzliche nicht leuchtende Materie deuten und Grenzen dieses Schlusses erläutern.
- `requires`: `["f3dbcafa-1849-5ee1-8807-81e8d7fed73d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_dark_matter_rotation_curves_evidence","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_DARK_MATTER_ROTATION_CURVES_EVIDENCE"}}`

## 722. Galaxienentfernungen und Hubble-Alter beurteilen

- ID: `61e84097-57b9-5434-9909-8ed8368a7823`
- Beschreibung: Die Teilziele trennen die Beurteilung astronomischer Galaxienentfernungen von der modellabhängigen Abschätzung eines Hubble-Alters.
- `requires`: `[]`
- `contains`: `["206a7d3d-9b11-56be-89ff-73898445c4f5","44f0eefa-2d93-5954-879f-f6c49e5cebc7"]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"cluster","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_galaxy_distance_ladder_hubble_age","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_GALAXY_DISTANCE_LADDER_HUBBLE_AGE"}}`

## 723. Galaxienentfernungen bestimmen und Verfahren beurteilen

- ID: `206a7d3d-9b11-56be-89ff-73898445c4f5`
- Beschreibung: Die lernende Person kann ein geeignetes Verfahren zur Entfernungsbestimmung von Galaxien anwenden, mit anderen astronomischen Entfernungsverfahren vergleichen und Messunsicherheiten sowie Gültigkeitsgrenzen beurteilen.
- `requires`: `["db6b8de4-21e0-58e8-a347-2ae39f538f92"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_galaxy_distance_methods","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_GALAXY_DISTANCE_METHODS"}}`

## 724. Universumsalter mit der Hubble-Beziehung abschätzen

- ID: `44f0eefa-2d93-5954-879f-f6c49e5cebc7`
- Beschreibung: Die lernende Person kann aus der Hubble-Beziehung ein Hubble-Alter abschätzen und erläutern, warum es nur unter vereinfachenden Annahmen über die Expansionsgeschichte als Universumsalter gedeutet werden darf.
- `requires`: `["aa0fa5fb-7bfb-5f9f-a606-3f7187cfb745","af3d6bff-c5fb-4ec6-a9f0-c0be09fc9186","f2e42af5-67a6-477e-82ea-e65b09cc6cb3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","semanticAtomic":true,"tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_hubble_age_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_HUBBLE_AGE_MODEL"}}`

## 725. Offene kosmologische Fragen quellenkritisch einordnen

- ID: `6ae54ff9-dc3b-563b-b2ee-09a0f0d00162`
- Beschreibung: Die lernende Person kann offene kosmologische Problemstellungen beschreiben, daraus physikalisch untersuchbare Fragen ableiten und populärwissenschaftliche Darstellungen anhand von Evidenz, Unsicherheit und Quellenqualität kritisch bewerten.
- `requires`: `["c52d55c3-b687-586c-b0f9-8ffcd1069424","d2e6f87d-795b-5631-a7cc-0bfb5dc5142e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_cosmology_open_questions_source_review","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_ASTRO_COSMOLOGY_OPEN_QUESTIONS_SOURCE_REVIEW"}}`

## 726. Prüfungsaufgabe: Elektrische Energieumwandlungen beurteilen

- ID: `4996346f-ab5d-4d09-9b9e-b9e559af153d`
- Beschreibung: Die lernende Person kann an einer einfachen elektrischen Anwendung die Energieumwandlungskette beschreiben, nutzbare und unerwünschte Energieübertragungen unterscheiden und die Eignung der Anwendung qualitativ beurteilen.
- `requires`: `["cbb26ed2-6979-46f6-a4ae-128f5c5d9d76"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_sek1_assessment_bw_electrical_energy_conversions","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_ENERGIE","LI_TECHNIK"],"phase":"GLOBAL","area":"Elektrische Energie","topicCode":"CANONICAL.PHYSICS.SEK1.PRACTICE.BW.ELECTRICAL_ENERGY_CONVERSIONS"}}`

## 727. Prüfungsaufgabe: Doppelspalt als Wellenlängenmessgerät

- ID: `caf8fc1e-83d5-5aaf-8863-0f7d4948ace5`
- Beschreibung: Die lernende Person kann eine materialgebundene Prüfungsaufgabe zu diesem optischen Modell selbstständig lösen, die Ergebnisse begründen und Modellgrenzen beurteilen.
- `requires`: `["6270e558-d657-5363-a6b2-e49a032a453b"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3","area":"Klausurtraining"}}`

## 728. Prüfungsaufgabe: Dunkle Streifen am Doppelspalt überprüfen

- ID: `45b3a745-16ec-57b0-8f54-dd36292f4958`
- Beschreibung: Die lernende Person kann eine materialgebundene Prüfungsaufgabe zu diesem optischen Modell selbstständig lösen, die Ergebnisse begründen und Modellgrenzen beurteilen.
- `requires`: `["c64820e1-c0ee-4342-9225-f981650f0c52"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3","area":"Klausurtraining"}}`

## 729. Prüfungsaufgabe: Ein Zweilinienspektrum am Gitter auswerten

- ID: `90f8f0dc-d919-54a2-a487-93547706e40e`
- Beschreibung: Die lernende Person kann eine materialgebundene Prüfungsaufgabe zu diesem optischen Modell selbstständig lösen, die Ergebnisse begründen und Modellgrenzen beurteilen.
- `requires`: `["91683676-01cf-5003-80fa-a04d043b4e61"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3","area":"Klausurtraining"}}`

## 730. Prüfungsaufgabe: Das Einzelspaltbild aus Elementarwellen modellieren

- ID: `e1abfda1-f1c4-5b32-a6bd-da605698bf73`
- Beschreibung: Die lernende Person kann eine materialgebundene Prüfungsaufgabe zu diesem optischen Modell selbstständig lösen, die Ergebnisse begründen und Modellgrenzen beurteilen.
- `requires`: `["f6a3a602-1e45-5018-b0ff-3d49933cf634"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_WELLEN"],"phase":"Q3","area":"Klausurtraining"}}`

## 731. Diskrete Energien im unendlichen Potenzialtopf berechnen

- ID: `d05a146f-7fcd-56ae-b9b9-b54203328579`
- Beschreibung: Die lernende Person kann für ein Elektron im eindimensionalen Potenzialtopf der Breite $L$ mit unendlich hohen Wänden und $V=0$ im Inneren die erlaubten Energien $E_n=n^2h^2/(8m_eL^2)$ für $n=1,2,\ldots$ berechnen und ihre Abhängigkeit von Topfbreite und Quantenzahl physikalisch deuten.
- `requires`: `["51bc5513-6879-548f-b19a-9746b667f1a3"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_infinite_well_discrete_energy_calculate","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4","area":"Quantenphysik","topicCode":"CANONICAL_PHYSICS_INFINITE_WELL_DISCRETE_ENERGY_CALCULATE"}}`

## 732. Intervallwahrscheinlichkeiten im unendlichen Potenzialtopf berechnen

- ID: `f2538793-8b0a-5c3b-b216-5d329a4e87bd`
- Beschreibung: Die lernende Person kann für eine gegebene, auf $[0,L]$ normierte Wellenfunktion eines Elektrons im eindimensionalen Potenzialtopf mit unendlich hohen Wänden die Nachweiswahrscheinlichkeit in einem Intervall durch $P(x_1\le x\le x_2)=\int_{x_1}^{x_2}|\psi(x)|^2\,dx$ mit $0\le x_1\le x_2\le L$ berechnen und als Fläche unter der Wahrscheinlichkeitsdichte deuten.
- `requires`: `["51bc5513-6879-548f-b19a-9746b667f1a3","b9bbd2a8-1379-5ffb-817f-41467d48abef"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_infinite_well_normalized_interval_probability","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4","area":"Quantenphysik","topicCode":"CANONICAL_PHYSICS_INFINITE_WELL_NORMALIZED_INTERVAL_PROBABILITY"}}`

## 733. Prüfungsaufgabe: Nachweisbereiche im Potenzialtopf vergleichen

- ID: `2f8d4250-66c5-54e9-abb8-80735dc408d2`
- Beschreibung: Die lernende Person kann eine materialgestützte Q4-Prüfungsaufgabe zu Intervallwahrscheinlichkeiten im unendlichen Potenzialtopf selbstständig lösen und ihre Ergebnisse anhand der Wahrscheinlichkeitsdichte begründen.
- `requires`: `["f2538793-8b0a-5c3b-b216-5d329a4e87bd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_infinite_well_interval_probability","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN"],"guidingIdeas":["LI_MATERIE"],"phase":"Q4","area":"Klausurtraining"}}`

## 734. Einen Audio-Licht-Übertragungsversuch funktional umsetzen

- ID: `922f32ba-f214-5a82-be5c-1111aca51d4a`
- Beschreibung: Die lernende Person kann einen vorgegebenen Versuch zur Übertragung eines Audiosignals mit Licht funktional erläutern, indem sie Signalumwandlung in Sender und Empfänger sowie den Übertragungsweg erklärt, und ihn bei Auswahl als Schülerexperiment funktionsfähig aufbauen.
- `requires`: `["4a7cbe83-b694-57d3-85ce-1eeca418daaf","58fc7852-722c-5a67-be6a-bfd1be0b527e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_audio_light_transmission_apparatus","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"GLOBAL","area":"Elektromagnetische Wellen","topicCode":"CANONICAL_PHYSICS_AUDIO_LIGHT_TRANSMISSION_APPARATUS"}}`

## 735. Einen Modellversuch zu optischem Multiplexing entwickeln

- ID: `f505f039-3f07-5afe-88b8-f02532e9c2f0`
- Beschreibung: Die lernende Person kann mithilfe vorgegebener Quellen einen Modellversuch zur gemeinsamen optischen Übertragung mehrerer unterscheidbarer Signalkanäle entwickeln und daran erklären und prüfen, wie die Kanäle zusammengeführt und am Empfänger wieder getrennt werden.
- `requires`: `["4a7cbe83-b694-57d3-85ce-1eeca418daaf"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_optical_multiplex_channel_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_WELLEN"],"phase":"GLOBAL","area":"Elektromagnetische Wellen","topicCode":"CANONICAL_PHYSICS_OPTICAL_MULTIPLEX_CHANNEL_MODEL"}}`

## 736. Einen bipolaren Transistor als Schalter funktional untersuchen

- ID: `7d4d6a39-0c78-5fb0-b7bf-182ed00972f7`
- Beschreibung: Die lernende Person kann an einem vorgegebenen npn- oder pnp-Transistoraufbau die Funktion von Basis, Kollektor und Emitter mithilfe eines einfachen Halbleitermodells erklären und daraus das Ein- und Ausschalten des Laststromkreises begründen; wenn die Anwendung als Schülerexperiment vorgesehen ist, kann sie den Aufbau nach Plan herstellen und die Schaltwirkung selbst untersuchen.
- `requires`: `["2084b7d4-300d-5fa0-8b8d-c480c40f853e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_bipolar_transistor_switch_function","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK1_EXPERIMENTIEREN","PK2_MODELLIEREN"],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Festkörperphysik","topicCode":"CANONICAL_PHYSICS_BIPOLAR_TRANSISTOR_SWITCH_FUNCTION"}}`

## 737. Eine bistabile Transistor-Flipflop-Schaltung deuten

- ID: `c2af45aa-e3fc-5119-9159-c5a260b4135a`
- Beschreibung: Die lernende Person kann an einer vorgegebenen bistabilen Transistorschaltung erklären, wie gegenseitige Rückkopplung zwei stabile Zustände ermöglicht, und anhand der Schaltung vorhersagen, wie ein geeigneter Schaltimpuls den gespeicherten Zustand ändert.
- `requires`: `["7d4d6a39-0c78-5fb0-b7bf-182ed00972f7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_bistable_transistor_flipflop_interpret","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Festkörperphysik","topicCode":"CANONICAL_PHYSICS_BISTABLE_TRANSISTOR_FLIPFLOP_INTERPRET"}}`

## 738. Argumentationen zur Entstehung schwerer Elemente beurteilen

- ID: `e1b21fe9-ab6f-58c4-a0b6-9895061fbabb`
- Beschreibung: Die lernende Person kann anhand vorgegebener Sachtexte und Diagramme zum kosmischen Materiekreislauf beurteilen, ob eine Argumentation zur Entstehung schwerer Elemente durch die dargestellten Kernprozesse und die Weitergabe angereicherter Materie begründet ist.
- `requires`: `["6f896466-e0ec-5f8d-82ad-2890433c82ba"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_stellar_heavy_element_argument_evaluate","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_STELLAR_HEAVY_ELEMENT_ARGUMENT_EVALUATE"}}`

## 739. Stern-Endstadien aus Anfangsmasse und Massenverlust prognostizieren

- ID: `69280706-5af6-5788-85b7-93287c2ffe74`
- Beschreibung: Die lernende Person kann mithilfe vorgegebener Entwicklungsmodelle aus Anfangsmasse und Massenverlust eines Sterns ein mögliches Endstadium begründet prognostizieren und dabei zwischen Anfangsmasse, verbleibender Kernmasse und den Grenzen der Modellvorhersage unterscheiden.
- `requires`: `["6f896466-e0ec-5f8d-82ad-2890433c82ba"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_stellar_end_state_mass_loss_predict","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"GLOBAL","area":"Astrophysik","topicCode":"CANONICAL_PHYSICS_STELLAR_END_STATE_MASS_LOSS_PREDICT"}}`

## 740. Die Funktion eines thermischen Kernreaktors erklären

- ID: `68034218-8f3e-5f7f-ae4e-ed057dd4e44e`
- Beschreibung: Die lernende Person kann an einem vorgegebenen vereinfachten Schema eines thermischen Kernreaktors erklären, wie Brennstoff, Moderator, Steuerstäbe und Kühlmittel zusammenwirken, um eine kontrollierte Kettenreaktion und die Abfuhr der frei werdenden Wärme zu ermöglichen.
- `requires`: `["50877233-7abf-54df-b347-6d3224678fc9","7d78da7f-6af5-440a-9d6b-6cab4bee8dd2"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_thermal_reactor_function","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB2","processCompetencies":["PK2_MODELLIEREN"],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Kernphysik","topicCode":"CANONICAL_PHYSICS_THERMAL_REACTOR_FUNCTION"}}`

## 741. Prüfungsaufgabe: Einen Ton über Licht übertragen

- ID: `51af53cb-8866-52cd-b2ca-af8bd8a836e0`
- Beschreibung: Die lernende Person kann die materialgestützte Aufgabe selbstständig bearbeiten, ihre fachlichen Entscheidungen begründen und Grenzen der vorgegebenen Darstellung beachten.
- `requires`: `["922f32ba-f214-5a82-be5c-1111aca51d4a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_audio_light_transmission","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_TECHNIK"],"phase":"Q4","area":"Klausurtraining"}}`

## 742. Prüfungsaufgabe: Zwei Lichtkanäle auf einem Weg trennen

- ID: `4dbe6eb9-4d77-58a9-a15c-f0b8bb110a65`
- Beschreibung: Die lernende Person kann die materialgestützte Aufgabe selbstständig bearbeiten, ihre fachlichen Entscheidungen begründen und Grenzen der vorgegebenen Darstellung beachten.
- `requires`: `["f505f039-3f07-5afe-88b8-f02532e9c2f0"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_optical_multiplex_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_TECHNIK"],"phase":"Q4","area":"Klausurtraining"}}`

## 743. Prüfungsaufgabe: Einen gespeicherten Schaltzustand ändern

- ID: `5902ebe8-2025-5a7c-b95d-13057398d6e6`
- Beschreibung: Die lernende Person kann die materialgestützte Aufgabe selbstständig bearbeiten, ihre fachlichen Entscheidungen begründen und Grenzen der vorgegebenen Darstellung beachten.
- `requires`: `["c2af45aa-e3fc-5119-9159-c5a260b4135a"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","GK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_bistable_transistor_memory","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_TECHNIK"],"phase":"Q4","area":"Klausurtraining"}}`

## 744. Prüfungsaufgabe: Eine Elemententstehungs-Behauptung prüfen

- ID: `6da29199-f086-512c-89f2-1b5ca865eef9`
- Beschreibung: Die lernende Person kann die materialgestützte Aufgabe selbstständig bearbeiten, ihre fachlichen Entscheidungen begründen und Grenzen der vorgegebenen Darstellung beachten.
- `requires`: `["e1b21fe9-ab6f-58c4-a0b6-9895061fbabb"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_stellar_element_argument","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4","area":"Klausurtraining"}}`

## 745. Prüfungsaufgabe: Bedingte Stern-Endstadien prognostizieren

- ID: `6c87a996-9166-5c6e-8cda-01d40720f9c8`
- Beschreibung: Die lernende Person kann die materialgestützte Aufgabe selbstständig bearbeiten, ihre fachlichen Entscheidungen begründen und Grenzen der vorgegebenen Darstellung beachten.
- `requires`: `["69280706-5af6-5788-85b7-93287c2ffe74"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_stellar_end_state_model","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_KOSMOS"],"phase":"Q4","area":"Klausurtraining"}}`

## 746. Prüfungsaufgabe: Neutronensteuerung und Wärmeabfuhr im Reaktor

- ID: `74a32716-2b46-5d96-8b57-3f6edb90e088`
- Beschreibung: Die lernende Person kann die materialgestützte Aufgabe selbstständig bearbeiten, ihre fachlichen Entscheidungen begründen und Grenzen der vorgegebenen Darstellung beachten.
- `requires`: `["68034218-8f3e-5f7f-ae4e-ed057dd4e44e"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","GK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_thermal_reactor_components","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_TECHNIK"],"phase":"GLOBAL","area":"Klausurtraining"}}`

## 747. Prüfungsaufgabe: Arbeitspunkt und Verzerrung einer Emitterschaltung

- ID: `144007cb-e2bc-5c82-bf9d-dda705b15257`
- Beschreibung: Die lernende Person kann die materialgestützte Aufgabe selbstständig bearbeiten, ihre fachlichen Entscheidungen begründen und Grenzen der vorgegebenen Darstellung beachten.
- `requires`: `["af50bb9a-fd7b-50f5-9698-48c4efe99032"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_assessment_bipolar_amplifier_operating_point","dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"],"guidingIdeas":["LI_TECHNIK"],"phase":"Q4","area":"Klausurtraining"}}`

## 748. Aufbau des Sonnensystems beschreiben

- ID: `af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93`
- Beschreibung: Die lernende Person kann den Aufbau des Sonnensystems beschreiben und Sonne, Planeten und Kometen anhand ihrer Rolle und ihrer Bahnen einordnen.
- `requires`: `["5c44b9ba-9b05-4774-95d5-073230d3fc4f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_solar_system_structure","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 749. Gezeiten qualitativ erklären

- ID: `37013646-f13a-5faf-954c-940f2fd7502f`
- Beschreibung: Die lernende Person kann Gezeiten qualitativ durch die unterschiedliche Gravitationswirkung von Mond und Sonne auf verschiedene Bereiche der Erde erklären.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93","eb0ffdea-c12d-56df-b7e8-c0297d2f8aff"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_tides_qualitative","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 750. Urknallmodell anhand kosmologischer Beobachtungen erläutern

- ID: `c52d55c3-b687-586c-b0f9-8ffcd1069424`
- Beschreibung: Die lernende Person kann das heiße Urknallmodell qualitativ erläutern und kosmologische Rotverschiebung sowie Hintergrundstrahlung als Beobachtungsbelege dafür einordnen.
- `requires`: `["1b060e79-dc2d-5e4e-abb5-42eca39f9cc7","2b700858-bc2e-5ddf-a791-b14d44160480"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_big_bang_redshift_cmb","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 751. Dunkle Materie qualitativ einordnen

- ID: `3d466956-04fb-58d7-9008-ad8090f8706d`
- Beschreibung: Die lernende Person kann dunkle Materie als Modellbestandteil zur Erklärung von Gravitationswirkungen erläutern, die sich nicht durch die bekannte gewöhnliche Materie allein erklären lassen.
- `requires`: `["1b060e79-dc2d-5e4e-abb5-42eca39f9cc7","eb0ffdea-c12d-56df-b7e8-c0297d2f8aff"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_dark_matter_qualitative","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 752. Dunkle Energie qualitativ einordnen

- ID: `b4772b06-b10c-52dd-841b-a96ffb7c7e28`
- Beschreibung: Die lernende Person kann dunkle Energie als Modellbegriff zur Beschreibung der beobachteten beschleunigten Expansion des Universums einordnen.
- `requires`: `["c52d55c3-b687-586c-b0f9-8ffcd1069424","4eeab7d5-eeb3-579b-845e-1c52ffe9e89f","80c232f1-8f72-5829-9dbe-5a610ccab3be"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_dark_energy_qualitative","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 753. Kosmische Strukturen einordnen

- ID: `1b060e79-dc2d-5e4e-abb5-42eca39f9cc7`
- Beschreibung: Die lernende Person kann größere kosmische Strukturen wie Galaxien beschreiben und Sternsysteme darin einordnen.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_universe_structural_hierarchy","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 754. Größe und Alter des Universums qualitativ einordnen

- ID: `db0394ca-297c-5892-b414-525ec186f928`
- Beschreibung: Die lernende Person kann qualitative Aussagen zu Größe und Alter des Universums einordnen und dabei räumliche Ausdehnung und vergangene Zeit sowie das beobachtbare und das gesamte Universum unterscheiden.
- `requires`: `["c52d55c3-b687-586c-b0f9-8ffcd1069424","7c986fca-1129-5eff-a17e-0a04bb7346ee"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_universe_size_age_qualitative","dimensionTags":{"framework":"hessen-kc-2024-physics","demandLevel":"AB2","processCompetencies":[],"guidingIdeas":[],"phase":"Q4"}}`

## 755. Rotverschiebung und Hintergrundstrahlung gemeinsam deuten

- ID: `b3b365f4-4988-57d5-97cd-5d8446483ef7`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Rotverschiebung und Hintergrundstrahlung gemeinsam deuten“ selbstständig bearbeiten und ihre Einordnung anhand des Materials fachlich begründen.
- `requires`: `["c52d55c3-b687-586c-b0f9-8ffcd1069424"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_b","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","demandLevel":"AB2","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"]}}`

## 756. Sonne, Planet und Komet im Bahnmodell zuordnen

- ID: `d44eb772-acb3-5449-accc-36a1fb7a25a5`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Sonne, Planet und Komet im Bahnmodell zuordnen“ selbstständig bearbeiten und ihre Einordnung anhand des Materials fachlich begründen.
- `requires`: `["af5dfdbc-5fd6-5c3e-a81b-093cb7c14b93"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_s","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"GLOBAL","demandLevel":"AB2","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"]}}`

## 757. Unser Sonnensystem in der Milchstraße verorten

- ID: `e99d87ac-0024-5f2b-ab47-d4d1cebba027`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Unser Sonnensystem in der Milchstraße verorten“ selbstständig bearbeiten und ihre Einordnung anhand des Materials fachlich begründen.
- `requires`: `["1b060e79-dc2d-5e4e-abb5-42eca39f9cc7"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical","SekI"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_g","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"GLOBAL","demandLevel":"AB2","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"]}}`

## 758. Zwei Gezeitenbereiche im Erdmodell erklären

- ID: `b34f3e03-bbe7-5ede-941c-3f26c9b07bb8`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Zwei Gezeitenbereiche im Erdmodell erklären“ selbstständig bearbeiten und ihre Einordnung anhand des Materials fachlich begründen.
- `requires`: `["37013646-f13a-5faf-954c-940f2fd7502f"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_t","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","demandLevel":"AB2","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"]}}`

## 759. Galaxienbewegung und bekannte Materie vergleichen

- ID: `2874902d-eccd-513e-ab60-98892497911d`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Galaxienbewegung und bekannte Materie vergleichen“ selbstständig bearbeiten und ihre Einordnung anhand des Materials fachlich begründen.
- `requires`: `["3d466956-04fb-58d7-9008-ad8090f8706d"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_dm","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","demandLevel":"AB2","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"]}}`

## 760. Expansion von beschleunigter Expansion unterscheiden

- ID: `c518e9dc-8514-5fde-9811-19caa85cfb1a`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Expansion von beschleunigter Expansion unterscheiden“ selbstständig bearbeiten und ihre Einordnung anhand des Materials fachlich begründen.
- `requires`: `["b4772b06-b10c-52dd-841b-a96ffb7c7e28"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_de","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","demandLevel":"AB2","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"]}}`

## 761. Weltalter, Lichtlaufzeit und Ausdehnung auseinanderhalten

- ID: `c77d28e5-a03e-5518-8c3a-55e9e9a2cea3`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Weltalter, Lichtlaufzeit und Ausdehnung auseinanderhalten“ selbstständig bearbeiten und ihre Einordnung anhand des Materials fachlich begründen.
- `requires`: `["db0394ca-297c-5892-b414-525ec186f928"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_u","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","demandLevel":"AB2","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"]}}`

## 762. Zwei Wellenarten und zwei Messprinzipien vergleichen

- ID: `04832ee1-648a-5421-a01d-0a15c3536c5f`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Zwei Wellenarten und zwei Messprinzipien vergleichen“ selbstständig bearbeiten und ihre Einordnung anhand des Materials fachlich begründen.
- `requires`: `["ba16948b-5e07-54af-b77b-776e677c6906"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_gw","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","demandLevel":"AB2","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"]}}`

## 763. Druckstützung und Stabilität eines Sternmodells beurteilen

- ID: `71af215d-c6d5-59ce-a3f6-4a2e60f1216d`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Druckstützung und Stabilität eines Sternmodells beurteilen“ selbstständig bearbeiten und ihre Einordnung anhand des Materials fachlich begründen.
- `requires`: `["da3169ae-c72a-5782-ad95-408167a5c6da"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_st","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","demandLevel":"AB2","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"]}}`

## 764. Einen Exoplanetenkandidaten und sein Transmissionsspektrum beurteilen

- ID: `f61c424e-f091-5f9d-9d58-c1bd29733fc8`
- Beschreibung: Die lernende Person kann die bereitgestellte Aufgabe „Einen Exoplanetenkandidaten und sein Transmissionsspektrum beurteilen“ selbstständig bearbeiten und ihre Einordnung anhand des Materials fachlich begründen.
- `requires`: `["49bb609a-bfb7-5391-9120-f5fc737efb9a","6dca3b0a-c872-543b-808f-97e855f5fafd","e28381b4-50ef-5cac-bfa4-b7c8e03aef82"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment","canonical"]}`
- Vorhandene Einordnung (Originalwerte): `{"shortKey":"canonical_physics_astro_assessment_ex","dimensionTags":{"framework":"canonical-gymnasium-physics","phase":"Q4","demandLevel":"AB2","guidingIdeas":["LI_KOSMOS"],"processCompetencies":["PK2_MODELLIEREN","PK4_KOMMUNIZIEREN"]}}`

## 765. Senkrechter Wurf: Vorzeichen, Scheitelpunkt und Rückkehr

- ID: `4ab1cf6d-b808-5b86-9291-85df0b9f2496`
- Beschreibung: Die lernende Person kann einen senkrechten Aufwärts- und Abwärtswurf mit konsistenten Vorzeichen, Ereigniszeiten und Orts-, Geschwindigkeits- und Beschleunigungsdiagrammen selbstständig untersuchen und die Ergebnisse begründen. 36 BE.
- `requires`: `["e4b38061-1f28-43ad-8371-a3e7c0e81856"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E","area":"Klausurtraining"}}`

## 766. Waagerechter Wurf: Zwei Bewegungen, eine gemeinsame Zeit

- ID: `6ea3fb3c-abdc-568f-ab13-97c36dc274e4`
- Beschreibung: Die lernende Person kann den waagerechten Wurf in einer schriftlichen Modellprüfung ohne Vektorrechnung aus gleichförmiger horizontaler und gleichmäßig beschleunigter vertikaler Bewegung zusammensetzen, dieselbe Zeit in beiden Richtungen verwenden und Modellgrenzen begründen. 36 BE.
- `requires`: `["e4b38061-1f28-43ad-8371-a3e7c0e81856","971beafa-6ba5-4c82-ac8b-7ebf66eec3dd"]`
- `contains`: `[]`
- Vorhandene Typkennzeichnungen (Originalwerte): `{"type":"atomic","tags":["GK","LK","Practice","Assessment"]}`
- Vorhandene Einordnung (Originalwerte): `{"dimensionTags":{"framework":"canonical-gymnasium-physics","demandLevel":"AB3","processCompetencies":["PK2_MODELLIEREN","PK3_MATHEMATISIEREN","PK4_KOMMUNIZIEREN","PK5_BEWERTEN"],"guidingIdeas":["LI_BEWEGUNG"],"phase":"E","area":"Klausurtraining"}}`

