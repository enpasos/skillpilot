# Herkunft und Lizenzen der Datenexporte

Die beiden vollständigen kanonischen Landschaften stammen aus dem öffentlichen
SkillPilot-Repository von enpasos - Enterprise Patterns & Solutions GmbH.

- Repository: https://github.com/enpasos/skillpilot
- Geprüfter Stand von `origin/main`: `0ce5a8d791eeb9783a919195fd8590bfb79f3595`
- Mathematik: `curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_MATHEMATIK.de.json`
- Physik: `curricula/DE/Gymnasium/canonical/DE_DEU_S_GYM_CANONICAL_PHYSIK.de.json`

Die Dateien unter `curricula/` wurden mit `git show 0ce5a8d791eeb9783a919195fd8590bfb79f3595:<Ursprungspfad>`
bytegenau exportiert. Es wurden keine Ziele, Felder, Beziehungen oder Aufgaben
gefiltert oder verändert. Die Markdowninventare und der Referenzbericht sind
neue, abgeleitete Orientierungshilfen; sie ersetzen die vollständigen JSONs nicht.
Eine Formatierung für die Anzeige ist kein neuer fachlicher Zuschnitt.

Die verbindliche Zuordnung steht in der unveränderten Kopie der Projektregel
[LICENSING.skillpilot.txt](LICENSES/LICENSING.skillpilot.txt).
Darin enthaltene relative Verweise sind Verweise der ursprünglichen Repository-
Dokumentation; die [ursprüngliche Regel auf diesem Commit](https://github.com/enpasos/skillpilot/blob/0ce5a8d791eeb9783a919195fd8590bfb79f3595/LICENSING.md) liefert
den vollständigen Zusammenhang.

- Eigene Skill-Landschaften, Lernzieltexte, Graphbeziehungen und didaktische
  Inhalte sowie die daraus abgeleiteten Lernzielinventare: **CC-BY-4.0**.
  Volltext: [Creative Commons Attribution 4.0 International](LICENSES/CC-BY-4.0.txt).
- Technische Dokumentation und funktionale Anweisungen folgen der Zuordnung
  der Projektregel unter **Apache-2.0**. Volltext: [Apache License 2.0](LICENSE).
  Das ist keine alternative Lizenzwahl für dieselben Lerninhalte und keine
  pauschale Lizenz für jedes in einem Gesamtpaket enthaltene Material.

Für dieses Paket neu verfasst wurden `KONZEPT.md` als didaktische
Konzeptdokumentation (CC-BY-4.0), `AUFGABE.md` als funktionaler Arbeitsauftrag
und `README.md` als technische Nutzungshinweise (jeweils Apache-2.0).
Sie sind keine unveränderten Dateien des oben genannten Commits. Die
Beobachtungen zu Lehrwerken sind eigene Zusammenfassungen; die Lehrwerke
selbst werden nicht mitverteilt oder neu lizenziert.

Attributionsvorschlag für die exportierten eigenen Inhalte:

> SkillPilot — kanonische Mathematik und Physik (Gymnasium, DE), Stand
> `0ce5a8d791eeb9783a919195fd8590bfb79f3595`, https://github.com/enpasos/skillpilot,
> enpasos - Enterprise Patterns & Solutions GmbH und mitgelieferte Beitragende,
> CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
> JSONs unverändert; Lernziel- und Referenzinventare als abgeleitete Darstellung.

Vorhandene Autoren-, Quellen-, Provenienz- und sonstige Hinweise bleiben in den
vollständigen Dateien erhalten. Die Lizenz umfasst nur die Rechte, die die
jeweiligen Rechteinhaber gewähren können. Verlinkte Lehrpläne, Bücher, Medien,
Dienste, fremde Inhalte und Marken behalten ihre eigenen Bedingungen. Dieses
Paket verteilt ihre Linkziele und Medien nicht mit; eine Quellenangabe ist keine
zusätzliche Rechtefreigabe. `AI-generated` oder `SkillPilot-curated` ist kein
Lizenzausdruck und kein selbständiger Rechtebeleg.

Dieser Datenexport enthält statische öffentliche Curriculumdateien und keine
Lernenden-, Chat- oder Sitzungsdaten. Das bereitgestellte Fremd-PDF ist nicht
Teil dieses Exports. Der Export behauptet keine vollständige Lehrplanabdeckung,
keine Qualitätsfreigabe der Prüfungen und keine bereits begutachtete Einteilung
in Lerneinheiten. Eine aufgelöste Referenz ist keine didaktische Anerkennung.
