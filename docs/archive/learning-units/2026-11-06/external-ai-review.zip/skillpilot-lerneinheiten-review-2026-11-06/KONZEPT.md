# Lerneinheiten in SkillPilot: Zweck, Kriterien und offene Fragen

Stand: 6. November 2026. Dieses Papier fasst unsere bisherigen Vereinbarungen
und Erkenntnisse zusammen. Es ist Grundlage einer **neuen fachlichen Gestaltung**,
keine fertige Einteilung und keine Behauptung über bereits implementierte Funktionen.
Die beigefügten Curricula sind ein Bestand, der dabei kritisch geprüft werden soll.

## 1. Wozu wir Lerneinheiten brauchen

Eine **Lerneinheit** bündelt einen zusammenhängenden Erkenntnisschritt und ein
verständliches Lernversprechen: *Was kann ich danach selbstständig tun, und wozu
ist das gut?* Eine motivierende Einführung eröffnet den Zusammenhang; darauf
folgen Erarbeitung, Übung und ein belastbarer Anwendungsnachweis.

Der wichtigste Zweck: Bevor darauf aufgebaut wird, muss die Grundlage tragen.
Es ist besser, in einer Prüfung eine wesentliche Verständnislücke zu entdecken,
gezielt weiterzulernen und erneut geprüft zu werden, als auf scheinbar beherrschtem
Stoff weiterzubauen. Das bedeutet keine Fehlerlosigkeit: Ein Rechenversehen ist
anders zu beurteilen als eine fehlende zentrale Vorstellung.

Eine Einheit kann ein Thema, einen neuen Modellzugang oder eine zusammenführende
Anwendung umfassen. Auch eine abschließende Synthese ohne weiteren Nachfolger ist
sinnvoll. Einheiten dürfen echte Untereinheiten enthalten. Ein zusätzlicher
Elternabschluss ersetzt deren eigene Prüfungen nicht; abgeschlossene Kinder
bleiben abgeschlossen, während die Elternprüfung noch offen ist — wie bei
Studienmodulen und einer zusätzlichen Abschlussprüfung.

## 2. Wie wir Grenzen begründen wollen

- **Gemeinsames Lernversprechen:** Die Ziele ergeben eine verständliche Fähigkeit,
  die sich in zusammenhängenden Anwendungen zeigen lässt.
- **Neuer Erkenntnisschritt:** Eine zentrale Vorstellung muss erst sicher werden,
  bevor darauf anspruchsvollere Arbeit aufbaut.
- **Fachlicher Zusammenhang:** `requires`-Verbindungen und thematische Nähe sind
  Hinweise. Auch eine sparsame Kette kann sehr eng zusammenhängen; gemeinsame
  Grundlagen verbinden umgekehrt nicht automatisch alles zu einer Rieseneinheit.
- **Sinnvoller Abschluss:** Die Prüfungen tragen das gesamte behauptete Versprechen.
  Größere Einheiten dürfen wichtige Zwischenprüfungen brauchen. Nicht jeder
  innere Lernabschnitt muss deshalb eine eigene Untereinheit werden.
- **Tragfähiger Lernweg:** Voraussetzungen müssen rechtzeitig verfügbar sein,
  auch aus anderen Fächern. Unabhängige Zweige dürfen parallel verlaufen.

Es gibt keine feste Mindest- oder Höchstzahl von Lernzielen. **Nicht zulässig ist
die automatische Bildung einer Einheit um jedes vorhandene Prüfungsziel.**
Ein abgebrochener Entwurf produzierte überwiegend winzige Prüfungshüllen;
dieser Ansatz soll ausdrücklich nicht wiederholt werden. Ebenso wenig sind
Jahrgänge, vorhandene Cluster, Kapitelnummern oder hübsche Überschriften allein
eine fachliche Begründung. Eine Elternüberschrift repariert keinen schlechten Schnitt.

Vollständige Zielbeschreibungen zählen, nicht nur Titel. Ein Ziel darf nicht
stillschweigend verkürzt, eine Voraussetzung nicht erfunden oder gelöscht werden,
damit die gewünschte Grenze passt. Zweifel am bestehenden Graphen sind eigene Befunde.

## 3. Welche Prüfungen das tragen können

Die Aufgaben müssen selbstständige Modellwahl, Erklärung und angemessenen
Transfer sichtbar machen. Mit entscheidenden Hilfen gelöste Übungsaufgaben sind
noch kein solcher Nachweis. Aufgabenvarianten müssen dasselbe Versprechen tragen.

Die normale, transparente Bewertungsregel muss verhindern, dass jemand trotz
fehlender wesentlicher beanspruchter Kompetenz besteht. Zugleich soll sie
nachvollziehbare Folgerechnungen und isolierte Fehler fair behandeln. Passt eine
bisherige Punktewertung nicht dazu, müssen Aufgabe, Rubrik oder der behauptete
Anerkennungsumfang dieser Prüfung überarbeitet werden. Die Originalziele werden
dadurch nicht abgeschwächt; für verbleibende Ansprüche fehlen dann noch passende
Nachweise. Es gibt **kein verstecktes zweites Bestehensurteil**.

Eine vorhandene Prüfung ist deshalb ein möglicher Baustein, keine vorgegebene
Einheitsgrenze und kein automatischer Nachweis aller transitiven Voraussetzungen.
Zu jeder behaupteten Abdeckung ist zu fragen: *Könnte jemand bestehen, obwohl
ihm diese wesentliche Fähigkeit fehlt?* Nach einem Fehlschlag folgen konkrete
Rückmeldung, passende Lernarbeit und eine frische gleichwertige Prüfung.

## 4. Graph und Kompetenz: feste Leitplanken

`A.requires = [B]` bedeutet: A benötigt B; der mögliche Lernfluss verläuft von
B nach A. `contains` beschreibt Zusammensetzung. Beides ist azyklisch.
**Transitive Minimalität bleibt gefordert:** Eine durch andere Voraussetzungenpfade
bereits ausgedrückte Abhängigkeit soll nicht als redundante Zusatzkante nötig sein.
Die Auswertung muss trotzdem vollständige transitive, geerbte und über Cluster
ausgedrückte Abhängigkeiten berücksichtigen. Ein beherrschtes Zwischenziel darf
den Bedarf einer noch offenen Prüfung nicht einfach abschneiden.

In einem konkret aufgelösten Kurs erhält jedes atomare Erwerbsziel genau eine
direkt verantwortliche Einheit. Eltern aggregieren ihre Kinder ohne Doppelzählung.
Eine spätere Einheit darf dasselbe Können verwenden, ohne den Erwerb zu duplizieren.
Verschiedene Lehrpläne können dieselbe kanonische Kompetenz anders platzieren.
Eine Voraussetzung für ein einzelnes Ziel verlangt nicht automatisch den Abschluss
der gesamten fremden Einheit. Eine solche Ganz-Einheits-Pflicht braucht eine eigene
fachliche Begründung. Auch ein azyklischer atomarer Graph kann durch einen schlechten
Schnitt widersprüchliche Blockreihenfolgen erzeugen.

Gespeichert bleibt pro atomarem Lernziel nur das binäre explizite Ergebnis:
`mastery ∈ {0,1}`. Direkte Beherrschung zeigt Verständnis; gültig abgeleitete
implizite Beherrschung zeigt Können durch selbstständige Anwendung. Mit expliziten
Ergebnissen M und gültigen Ableitungen I gilt **M_eff = M ∪ I**. Beide zählen als
erledigt und wirken global, auch für spätere Voraussetzungen und den Gesamtfortschritt.
Eine andere Ansicht oder eine offene spätere Prüfung nimmt gültige Kompetenz nicht zurück.

Prüfungen und erforderliche Lernkarten brauchen immer ihre eigenen expliziten
Ergebnisse. Bloße Pfadenden oder fehlende Kanten erzeugen keine Kompetenz. Die
Einheit ist abgeschlossen, wenn ihre eigenen Pflichten und erforderlichen Kinder
erledigt sind; ein reines Aggregat braucht keine künstliche zusätzliche Prüfung.
Es gibt keinen weiteren gespeicherten Einheits-Masterywert. Der Tages-/Wochenplan
zählt explizite Abschlüsse; der Gesamtfortschritt berücksichtigt auch gültige implizite.

## 5. Beispiele, an denen wir den Zuschnitt prüfen

**Physik: eindimensionale Bewegung mit konstanter Beschleunigung.** Ein mögliches
Versprechen ist: „Ich kann eine solche Bewegung selbstständig modellieren,
berechnen und erklären.“ Freier Fall und senkrechter Wurf nutzen dasselbe Modell:
`x(t) = x₀ + v₀t + ½at²`, `v(t) = v₀ + at`. Achse, Vorzeichen, Anfangsbedingungen
und der Zusammenhang von Ort, Geschwindigkeit und Beschleunigung gehören zusammen.
„Am höchsten Punkt ist die Geschwindigkeit null, also auch die Beschleunigung“
ist eine zentrale Fehlvorstellung. Eine andere Abwurfhöhe oder Achsenrichtung
prüft mehr als die Wiederholung eines eingeübten Zahlenbeispiels.

Vielleicht ist jedoch **Kinematik einschließlich Komponenten und Überlagerung**
die bessere Einheit. Eine Zwischenprüfung kann das eindimensionale Verständnis
sichern, bevor räumliche Bewegung darauf aufbaut. Beim idealisierten Wurf werden
Komponenten im selben Bezugssystem zur selben Zeit zusammengesetzt; ihre
Unabhängigkeit folgt aus dem gewählten Modell. Eine weitere Möglichkeit sind echte
Untereinheiten mit einer Synthese. Diese Alternativen sind offen zu vergleichen.
„Gesamte Kinematik“ muss seinen Umfang benennen, etwa ob Kreisbewegung dazugehört.

**Mathematik Klasse 5: Zahlverständnis.** Ein erster Kandidat verbindet
Stellenwertsystem, verschiedene Zahlendarstellungen, Ordnen, Runden und die
Unbegrenztheit natürlicher Zahlen. Ob daraus eine eigene Einheit oder zusammen
mit Rechnen ein besserer Abschluss entsteht, ist noch offen. Ein Einkaufskontext
belegt beispielsweise nicht schon den Vergleich mit einem anderen Zahlensystem
oder das allgemeine Nachfolgerargument. Der Umfang der Originalziele bleibt erhalten.

## 6. Was wir aus Lehrwerken lernen — ohne ihre Gliederung zu kopieren

Am Vorwort und Inhaltsverzeichnis von **Metzler Physik, 5. Auflage (2020),
Krause/Grehn, ISBN 978-3-14-100100-6, S. 3–9**, haben wir verschiedene Muster
betrachtet: Wechsel der Erklärungsperspektive (Bewegung/Ursachen/Erhaltung),
Wechsel der Beschreibungsebene (makroskopisch/mikroskopisch), Übertragung einer
Struktur (mechanische/elektromagnetische Wellen), Befunde für ein neues Modell
(Quanten-/Atomphysik), zusammenführende Anwendungen (etwa Kernphysik/Astrophysik)
und begleitende Methoden. Das sind unsere Deutungen der Struktur; wir haben damit
nicht die vollständigen Lehrtexte und Aufgaben geprüft.

Ein Buch hat eine lineare Darstellungsordnung. Daraus folgt kein `requires`:
Chaos steht dort vor Relativität, ohne dass diese Nachbarschaft eine fachliche
Voraussetzung belegt. Kapitel und große Kapiteltests bestimmen ebenfalls nicht
automatisch unsere Einheitsgrenzen. Ähnliche Themen in verschiedenen Kontexten
begründen weder automatisch identische Ziele noch vollständigen Transfer.

**Mathematik muss in Physik rechtzeitig verfügbar sein.** Im betrachteten
Oberstufeneinstieg ist Differenzieren gerade gelernt, Integrieren noch nicht.
Ein passender Zugang darf deshalb keine formale Integralrechnung voraussetzen.
Bei linearer Geschwindigkeit können geometrische, vorzeichenbehaftete Flächen
oder eine entwickelte/bereitgestellte Modellgleichung genügen. Ortsänderung und
Weglänge bleiben verschieden. Das ist eine Kurssituation, keine allgemeine Aussage
über alle Lehrpläne. „Im selben Schuljahr“ genügt als Verfügbarkeitsnachweis nicht.
Fehlende Methoden müssen zuvor erarbeitet, fachübergreifend eingeplant oder durch
einen fachlich gleichwertigen Zugang vermieden werden; angenommene Vorkenntnisse
sind keine gespeicherte Mastery.

## 7. Noch offen — ausdrücklich kritisch mitdenken

Für die folgende Frage ist die **bisherige lokale Ableitungsregel** wichtig.
`Own(U)` sind die direkt verantworteten atomaren Ziele einer Einheit, Q die
Prüfungsziele, K die Lernkartenziele, M die explizit erledigten Ziele. R ist die
vollständig auf atomare Ziele aufgelöste Voraussetzungskante (Ziel → Voraussetzung):

```text
P_U = Own(U) ∩ (Q ∪ K)                     geschützte eigene Pflichten
N_U = Reach_R*(P_U \ M)                    noch transitiv benötigte Ziele
I_U = Own(U) \ (M ∪ P_U ∪ N_U)             lokal ableitbare Erledigung
```

`Reach_R*` enthält die Startmenge und alle in Voraussetzungsrichtung erreichbaren
Ziele. Dabei wird auch durch beherrschte Zwischenziele und außerhalb der Einheit
weitergegangen. Abgeleitete I werden nicht als explizite M zurückgespeist.
Die Regel ist nur unter einem fachlich gültigen lokalen Vertrag zulässig: Jedes
eigene gewöhnliche Fachziel braucht einen eigenen Prüfungsverbraucher und einen
passenden Anwendungsnachweis. Fehlende Abdeckung ist ein Fehler, keine automatische
Erledigung. Motivationsmarker bescheinigen keine Fachkompetenz. Eine Elternunion
aller Nachfahren darf `Own(U)` nicht ersetzen.

1. **Konkrete Grenzen:** Welche kleinen und großen Einheiten tragen fachlich?
   Wo genügt ein innerer Abschnitt, wo rechtfertigt sich eine echte Untereinheit?
2. **Zwischenprüfung und Anerkennung:** In einer großen Einheit kann eine spätere
   offene Prüfung dieselbe Grundlage noch transitiv benötigen. Nach der bisherigen
   lokalen Ableitungsregel bewirkt eine frühere Zwischenprüfung dann noch keine
   globale implizite Anerkennung dieser Grundlage. Nachweis, inneres Weiterlernen
   und Anerkennungszeitpunkt müssen zusammenpassen. Dies nicht durch künstlich
   kleine Einheiten kaschieren, sondern einen gegebenenfalls nötigen Konzeptwechsel
   offen begründen. Bereits gültige Kompetenz bleibt davon unberührt.
3. **Zugang:** Dass geplantes Weiterlernen eine tragfähige Grundlage braucht,
   entscheidet noch nicht, ob die Software Starts technisch sperrt oder direkte
   diagnostische Prüfungsversuche zulässt. Keine neue allgemeine Sperre ist beschlossen.
4. **Bestandsqualität:** Ziele, Karten, Prüfungen und Voraussetzungen können
   Korrekturen benötigen. Bestehende Ergebnisse dürfen durch neue Grenzen oder
   zusätzliche Ansprüche nicht nachträglich umgedeutet werden.

Gesucht ist zuerst ein fachlich überzeugender, prüfbarer Entwurf. Technische
Machbarkeit allein, eine maschinelle Validierung oder ein gut aussehender Graph
beweisen weder Unterrichtstauglichkeit noch Lernwirksamkeit.
